"""Untimed native-path diagnostics for every fixed comparison callback control."""
import hashlib,json,os,re,shutil,subprocess
from pathlib import Path
root=Path('target/integer-comparison-callback-paths');root.mkdir()
report={'timed_samples':0,'cases':{}}
for name in ('left_int','branch_int','rich_every_0','rich_every_100','miss_burst_recovery'):
    source=Path('target/integer-comparison-inputs/warm/'+name+'.py')
    driver=root/(name+'.py')
    driver.write_text(source.read_text()+'\nfor _ in range(4):\n    print(bench(5000))\n')
    row=report['cases'][name]={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'runs':{}}
    for label,binary in [('cpython',shutil.which('python3.14')),('previous','target/release/weavepy-runtime-jit-assertion-exits'),('new','target/release/weavepy-runtime-integer-comparison-guards')]:
        digest=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
        env=dict(os.environ,WEAVEPY_JIT='1',WEAVEPY_JIT_TRACE='1',WEAVEPY_VM_STATS='1',WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),WEAVEPY_FROZEN_CACHE=str((root/'frozen'/digest).resolve()))
        r=subprocess.run([binary,str(driver)],env=env,text=True,capture_output=True,timeout=180)
        trace=root/(name+'-'+label+'.txt');trace.write_text(r.stderr)
        row['runs'][label]={'binary':binary,'sha256':digest,'returncode':r.returncode,'stdout':r.stdout,'trace_sha256':hashlib.sha256(r.stderr.encode()).hexdigest(),'compiled':re.findall(r'jit compile "([^"]+)"',r.stderr),'rejections':[line for line in r.stderr.splitlines() if line.startswith('jit reject ')],'stats':{n:int(v) for n,v in re.findall(r'- ([^\n*]+): \*\*(\d+)\*\*',r.stderr)}}
        (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
        assert r.returncode==0,(name,label,r.stderr)
    assert len({r['stdout'] for r in row['runs'].values()})==1,name
report['status']='values_match'
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('All five untimed callback controls agree with CPython; traces retained.')

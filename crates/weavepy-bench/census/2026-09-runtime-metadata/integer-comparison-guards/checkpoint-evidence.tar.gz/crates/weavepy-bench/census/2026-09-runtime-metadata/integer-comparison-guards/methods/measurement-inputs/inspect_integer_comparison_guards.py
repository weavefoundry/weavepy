"""Require real native comparison coverage as well as CPython-equivalent results."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

root = Path("target/integer-comparison-guards-coverage")
root.mkdir()
driver = Path("tests/regrtest/test_integer_comparison_guards.py")
shutil.copyfile(driver, root / "driver.py")
report = {"purpose": __doc__, "source_sha256": hashlib.sha256(driver.read_bytes()).hexdigest(), "rows": {}}
for label, binary in [("cpython", shutil.which("python3.14")), ("previous", "target/release/weavepy-runtime-jit-assertion-exits"), ("new", "target/release/weavepy-runtime-integer-comparison-guards")]:
    digest = hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    env = dict(os.environ, WEAVEPY_JIT="1", WEAVEPY_JIT_TRACE="1", WEAVEPY_VM_STATS="1",
               WEAVEPY_STDLIB_CACHE=str(Path("target/performance-stdlib-cache").resolve()),
               WEAVEPY_FROZEN_CACHE=str((root / "frozen" / digest).resolve()))
    result = subprocess.run([binary, str(driver)], env=env, text=True, capture_output=True, timeout=180)
    (root / (label + ".trace.txt")).write_text(result.stderr)
    report["rows"][label] = {"binary": binary, "sha256": digest, "returncode": result.returncode,
        "stdout": result.stdout, "trace_sha256": hashlib.sha256(result.stderr.encode()).hexdigest(),
        "compiled": re.findall(r'jit compile "([^"]+)"', result.stderr),
        "rebuilt": re.findall(r'jit rebuild "([^"]+)" deopt_pc (\d+)', result.stderr)}
    (root / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    assert result.returncode == 0, (label, result.stderr)
assert all(row["stdout"] == report["rows"]["cpython"]["stdout"] for row in report["rows"].values())
required = {"cmp_" + op + "_" + side for op in ("lt", "le", "eq", "ne", "gt", "ge") for side in ("left", "right", "branch")} | {"cmp_loop"}
assert required <= set(report["rows"]["new"]["compiled"]), report["rows"]["new"]["compiled"]
assert required <= {name for name, _ in report["rows"]["new"]["rebuilt"]}, report["rows"]["new"]["rebuilt"]
report["assertions_passed"] = True
(root / "report.json").write_text(json.dumps(report, indent=2) + "\n")
print("All 19 comparison functions compile and rebuild; CPython values/semantics agree.")

"""Freeze component and hook controls before candidate measurements."""
import hashlib
import json
from pathlib import Path

root=Path('target/pickle-special-lookup-inputs');root.mkdir()

def save_group(group, work, cases):
    directory=root/group;directory.mkdir()
    rows={}
    for name,source in cases.items():
        path=directory/(name+'.py');path.write_text(source)
        driver=directory/(name+'-verify.py')
        driver.write_text(f'''import json, sys, types
module = types.ModuleType("_weavepy_bench")
module.__file__ = {str(path)!r}
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
first = module.bench({work})
for unused in range(3):
    module.bench({work})
last = module.bench({work})
print(json.dumps(first, sort_keys=True))
print(json.dumps(last, sort_keys=True))
''')
        rows[name]={'path':str(path),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                    'driver':str(driver),'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest()}
    (directory/'preparation.json').write_text(json.dumps({'work':work,'rows':rows},indent=2)+'\n')

sources={name:Path('target/pickle-component-probes',name+'.py').read_text()
         for name in ['payload_dumps','payload_loads','records_dumps','records_loads']}
save_group('components',20,sources)
common='''class Plain:
    def __init__(self):
        self.value = 7

'''
cases={
 'default_state': ('obj = Plain()\n', 7),
 'function_state': ('''class State(Plain):
    def __getstate__(self):
        return {'value': self.value + 1}
obj = State()
''',8),
 'inherited_newargs': ('''class Base(Plain):
    def __getnewargs__(self):
        return (self.value,)
class Child(Base):
    pass
obj = Child()
''',7),
 'static_state': ('''class State(Plain):
    __getstate__ = staticmethod(lambda: {'value': 23})
obj = State()
''',23),
 'class_state': ('''class State(Plain):
    marker = 41
    @classmethod
    def __getstate__(cls):
        return {'value': cls.marker}
obj = State()
''',41),
 'descriptor_fallback': ('''class Descriptor:
    def __get__(self, obj, owner):
        return lambda: {'value': 31}
class State(Plain):
    __getstate__ = Descriptor()
obj = State()
''',31),
 'metaclass_fallback': ('''class Meta(type):
    pass
class State(Plain, metaclass=Meta):
    def __getstate__(self):
        return {'value': self.value}
obj = State()
''',7),
}
hooks={}
for name,(definition,expected) in cases.items():
    hooks[name]=common+definition+f'''
def bench(n):
    total = 0
    for unused in range(n):
        reduction = object.__reduce_ex__(obj, 5)
        total += reduction[2]['value']
    return total
'''
    assert expected>0
save_group('hooks',1000,hooks)
(root/'protocol.md').write_text('''# Guarded pickle hook lookup comparison

Compare the separately frozen lookup candidate against corrected raise-exit
binary 539c6dd3 and CPython 3.14.7. Use JIT and interpreter modes for both
WeavePy binaries, plus exact result checks with -X gil=0. Preserve all samples,
regressions, failures, frozen-cache identities, and host-load telemetry.

Four unchanged pickle components use work=20 and seven hook-reduction controls
use work=1000. Every case has seven paired timed samples after an explicit
unmeasured cache stabilization cycle; alternating variant order is fixed by
the shared harness. Component byte/value oracles and the new Python regression
must pass first. Native-helper assertions verify that the new path is reached;
custom descriptors and metaclasses must fall back before user callbacks.

Attempt the existing strict load gate (one- and five-minute load <=4, three
observations ten seconds apart, maximum wait 600 seconds). A timeout produces
no measurements. Any later busy-host diagnostic must be separately declared
with fresh outputs and retained telemetry. No sample selection or retries.

Record process wall time, CPU time, peak RSS, and timed workload wall/CPU
metrics. Do not infer energy, controlled build cost, universal superiority,
or free-threaded performance from these results. Run standard full-suite and
startup/import controls after focused correctness/performance, with explicit
21-row historical and 23-workload timing cohorts. Do not run competing builds,
tests, profiles, or edit runtime/active harnesses during measurement.
''')
print('Prepared four component and seven hook controls with source/driver hashes.')

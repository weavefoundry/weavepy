#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-integer-comparison-guards
reference=target/release/weavepy-runtime-jit-assertion-exits
binary=target/release/weavepy-runtime-comparison-call-fusion
test -f "$base"
test -f "$reference"
test ! -e "$binary"
test ! -e target/comparison-call-fusion-build-stage.txt
printf '%s\n' "$base" > target/comparison-call-fusion-previous.txt
printf '%s\n' "$reference" > target/comparison-call-fusion-reference.txt
printf 'VM tests and static checks\n' > target/comparison-call-fusion-build-stage.txt
cargo fmt --all -- --check > target/comparison-call-fusion-format.txt 2>&1
cargo test --offline --locked -p weavepy-jit -j 1 > target/comparison-call-fusion-jit-tests.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/comparison-call-fusion-vm-tests.txt 2>&1
cargo clippy --offline --locked -p weavepy-vm -p weavepy-jit --lib --tests -j 1 -- -D warnings > target/comparison-call-fusion-clippy.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/comparison-call-fusion-no-jit.txt 2>&1
printf 'release build\n' > target/comparison-call-fusion-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/comparison-call-fusion-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/comparison-call-fusion-source-snapshot --extra target/build_comparison_call_fusion.sh target/check_comparison_call_fusion.sh target/validate_comparison_call_fusion.sh target/check_comparison_call_fusion_extra.py target/inspect_comparison_call_fusion.py target/measure_comparison_call_fusion_focused.sh target/measure_comparison_call_fusion_full.sh target/measure_verified_python_components_with_reference.py target/comparison-call-fusion-protocol.md > target/comparison-call-fusion-snapshot.txt 2>&1
printf 'done\n' > target/comparison-call-fusion-build-stage.txt

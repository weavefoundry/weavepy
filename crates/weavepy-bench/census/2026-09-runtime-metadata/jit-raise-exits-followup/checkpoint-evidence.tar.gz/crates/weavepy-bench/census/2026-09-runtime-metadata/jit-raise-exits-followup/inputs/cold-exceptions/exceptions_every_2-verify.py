def checked_value(n):
    if n < 0:
        raise ValueError("negative")
    return n + 1

def bench(n):
    count = 0
    total = 0
    for i in range(n):
        value = -1 if i % 2 == 0 else 7
        try:
            total += checked_value(value)
        except ValueError:
            count += 1
    return count, total

import json
for stage in range(2):
    if stage:
        bench(5000)
    value = bench(207)
    assert value == (104, 824)
    print(json.dumps(value))

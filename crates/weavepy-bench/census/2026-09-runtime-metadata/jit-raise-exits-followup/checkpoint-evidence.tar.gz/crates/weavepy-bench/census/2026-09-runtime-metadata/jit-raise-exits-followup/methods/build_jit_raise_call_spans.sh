#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
binary=target/release/weavepy-runtime-jit-raise-call-spans
base=target/release/weavepy-runtime-weakref-shared-keys
test ! -e "$binary"
test ! -e target/jit-raise-call-spans-stage.txt
printf 'VM tests and static checks\n' > target/jit-raise-call-spans-stage.txt
cargo fmt --all -- --check > target/jit-raise-call-spans-format.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/jit-raise-call-spans-vm-tests.txt 2>&1
cargo clippy --offline --locked -p weavepy-vm -p weavepy-jit --lib --tests -j 1 -- -D warnings > target/jit-raise-call-spans-clippy.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/jit-raise-call-spans-no-jit.txt 2>&1
printf 'release build\n' > target/jit-raise-call-spans-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/jit-raise-call-spans-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/jit-raise-call-spans-source-snapshot --extra target/build_jit_raise_call_spans.sh target/check_jit_raise_call_spans.sh target/jit-raise-exits-io-diagnostic/report.json target/jit_raise_constructed_repro.py target/jit-raise-exits-validation/validation.json > target/jit-raise-call-spans-snapshot.txt 2>&1
printf 'done\n' > target/jit-raise-call-spans-stage.txt

# Consolidate nested native scratch buffers: unapplied follow-up

Finish and archive all four phase 77 timing stages before editing runtime code,
building, testing, or running diagnostics. This is a source-based allocation and
pool-operation lead, not a measured improvement.

try_native_call in tier2.rs currently obtains five owned vectors: u64 locals,
u64 spill, u32 spill tags, u64 call arguments, and u32 call tags. Cleanup returns
all five separately to the thread-local scratch pools. The existing direct
native entry already combines these into two vectors: u64 locals + spill + call
arguments, and u32 spill tags + call tags, using disjoint mutable slices.

Apply that existing pattern to the nested non-leaf native path. Compute n_locals,
cap=max_stack+1, and call_cap=max(max_call_args,1) before allocating. Obtain one
u64 buffer of n_locals+cap+call_cap and one u32 buffer of cap+call_cap, split
without overlapping slices, and keep the owning vectors alive through native
execution and every deoptimization/exception continuation. Bind receivers,
arguments, defaults, and pins exactly as before. Return the two owners only
after no live native code or continuation can access their pointers. Preserve
scalar-leaf early entry, recursion ticks/guards, table refresh, dirty propagation,
result-lane conversion, pin retirement, greenlet stack discipline, and all error
paths. Do not keep any pool borrow across user Python. No new uninitialized
Object storage or raw ownership representation is needed.

Inspect machine code: fewer Vec owners do not automatically imply a smaller
combined stack frame, and different pool size classes can increase capacity.
Measure both pool operations and actual process RSS, including deep recursion,
wide locals/call-argument shapes, object pins, single and repeated calls, and
fallback/deopt controls. Existing direct-native and scalar-leaf paths are useful
unchanged controls. The fib census is currently slower than CPython, but no
claim about its eventual gain follows from the source observation.

Before timing, require native-path coverage and exact output agreement with
CPython. Include mutual/self recursion, positional/default/bound methods,
integer/float/object results, global/code/default mutation, exceptions and
recursion limits, nested generic callbacks, pin pressure and weak lifetimes.
Run appropriate native/C API/compatibility checks and preserve all failures.
Use the same exclusive lease, frozen caches, fixed binaries, alternating pairs,
startup probes, complete census, direct retained-baseline comparison, source/
method identities, and unfiltered raw samples as the current trial. Do not
claim universal superiority or portability from a subset of workload gains.

Pool detail from the current source: JIT_BUFS is a pair of LIFO Vec<Vec<T>>
pools, each capped at 64 entries. There are no explicit size classes. take clears
and resizes a popped vector; reuse can retain or grow its capacity. Combining
buffers reduces take/put operations from five to two for an eligible nested
activation, but it does not prove three fewer allocator calls on every call.
Do not describe pooled vectors as fresh mallocs. Record capacity/retention tradeoffs
and distinguish pool operations from allocations in any instrumentation.

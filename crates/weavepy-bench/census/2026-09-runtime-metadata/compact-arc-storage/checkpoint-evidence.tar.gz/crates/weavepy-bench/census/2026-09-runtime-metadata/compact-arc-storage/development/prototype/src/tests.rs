use super::*;
use std::collections::HashSet;
use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};

#[test]
fn text_hashes_utf8_and_payload_addresses_match_arc() {
    for text in ["", "a", "x\0y", "mañana", "日本語", "🧶🙂", "e\u{301}"] {
        let original: Arc<str> = Arc::from(text);
        let owner = SharedStr::from_arc(original.clone());
        assert_eq!(SharedStr::as_ptr(&owner), Arc::as_ptr(&original));
        assert_eq!(&*owner, text);
        assert_eq!(SharedStr::strong_count(&owner), 2);
        let mut set = HashSet::new();
        set.insert(owner.clone());
        assert!(SharedStr::ptr_eq(set.get(text).unwrap(), &owner));
        assert_eq!(SharedStr::from(text.to_owned()), owner);
        assert_eq!(SharedStr::from(text.to_owned().into_boxed_str()), owner);
        let weak = SharedStr::downgrade(&owner);
        assert_eq!(weak.strong_count(), 3);
        drop(set);
        drop(original);
        assert!(SharedStr::ptr_eq(&owner, &weak.upgrade().unwrap()));
        assert_eq!(SharedStr::weak_count(&owner), 1);
        drop(owner);
        assert_eq!(weak.strong_count(), 0);
        assert!(weak.upgrade().is_none());
    }
}

#[test]
fn moved_and_copied_slices_keep_values_identity_and_alignment() {
    for n in [0, 1, 2, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 65, 257] {
        let values: Vec<u32> = (0..n).map(|i| 0xd800 + i).collect();
        let copied = SharedSlice::from(values.as_slice());
        let moved = SharedSlice::from(values.clone());
        let boxed = SharedSlice::from(values.clone().into_boxed_slice());
        assert_eq!(&*copied, values.as_slice());
        assert_eq!(copied, moved);
        assert_eq!(copied, boxed);
        assert_eq!(SharedSlice::as_ptr(&copied).cast::<u32>(), copied.as_ptr());
        assert!(SharedSlice::ptr_eq(&copied, &copied.clone()));
        assert!(!SharedSlice::ptr_eq(&copied, &moved));
    }
    assert_eq!(&*SharedSlice::from(&[1_u128, u128::MAX]), &[1, u128::MAX]);
    assert_eq!(SharedSlice::from(vec![(); 5]).len(), 5);
    #[repr(align(64))]
    struct Aligned(u32);
    let aligned = SharedSlice::from(vec![Aligned(19), Aligned(23)]);
    assert_eq!(aligned.as_ptr().align_offset(64), 0);
    assert_eq!(aligned.clone()[1].0, 23);
}

#[test]
fn destructible_elements_drop_at_last_strong_before_weak_release() {
    struct Item(Arc<AtomicUsize>, usize);
    impl Drop for Item {
        fn drop(&mut self) {
            self.0.fetch_add(1, Ordering::SeqCst);
        }
    }
    for n in [0, 1, 2, 7, 15, 33, 64] {
        let drops = Arc::new(AtomicUsize::new(0));
        let owner = SharedSlice::from((0..n).map(|i| Item(drops.clone(), i)).collect::<Vec<_>>());
        for (i, value) in owner.iter().enumerate() {
            assert_eq!(value.1, i);
        }
        let clone = owner.clone();
        let weak = SharedSlice::downgrade(&owner);
        let second = weak.clone();
        assert_eq!(weak.weak_count(), 2);
        drop(owner);
        assert_eq!(drops.load(Ordering::SeqCst), 0);
        assert_eq!(weak.upgrade().unwrap().len(), n);
        drop(clone);
        assert_eq!(drops.load(Ordering::SeqCst), n);
        assert!(weak.upgrade().is_none());
        assert!(second.upgrade().is_none());
        drop(weak);
        drop(second);
        assert_eq!(drops.load(Ordering::SeqCst), n);
    }
}

#[test]
fn unique_mutation_rejects_strong_and_weak_aliases() {
    let mut owner = SharedSlice::from(&[11_u128, 22, 33]);
    let clone = owner.clone();
    assert!(SharedSlice::get_mut(&mut owner).is_none());
    drop(clone);
    let weak = SharedSlice::downgrade(&owner);
    assert!(SharedSlice::get_mut(&mut owner).is_none());
    drop(weak);
    SharedSlice::get_mut(&mut owner).unwrap()[1] = 88;
    assert_eq!(&*owner, &[11, 88, 33]);
}

#[test]
fn boxed_and_inline_handles_share_exact_arc_counts_and_identity() {
    let original: Arc<[u8]> = Arc::from(&b"boxed value"[..]);
    let mut boxed = SharedSlice::indirect(original.clone());
    assert_eq!(boxed.metadata, INDIRECT);
    assert_eq!(SharedSlice::as_ptr(&boxed), Arc::as_ptr(&original));
    let clone = boxed.clone();
    assert_ne!(clone.metadata, INDIRECT);
    let weak = SharedSlice::downgrade(&boxed);
    assert_eq!(SharedSlice::strong_count(&boxed), 3);
    assert!(SharedSlice::ptr_eq(&boxed, &clone));
    let upgrade = weak.upgrade().unwrap();
    assert!(SharedSlice::ptr_eq(&boxed, &upgrade));
    assert_eq!(SharedSlice::strong_count(&boxed), 4);
    assert!(SharedSlice::get_mut(&mut boxed).is_none());
    drop(original);
    drop(clone);
    drop(upgrade);
    assert!(SharedSlice::get_mut(&mut boxed).is_none());
    drop(weak);
    SharedSlice::get_mut(&mut boxed).unwrap()[0] = b'B';
    assert_eq!(&*boxed, b"Boxed value");
}

#[test]
fn extreme_zero_sized_lengths_use_full_metadata_without_a_size_cap() {
    let mut max_inline_bytes = [0; POINTER_BYTES];
    max_inline_bytes[..METADATA_BYTES].copy_from_slice(&INDIRECT);
    let escape = usize::from_le_bytes(max_inline_bytes);
    for len in [Some(escape), escape.checked_add(123)]
        .into_iter()
        .flatten()
    {
        // SAFETY: () has no bytes and exactly one valid value. No uninitialized
        // data is read, even at these lengths; the Arc allocation is just its
        // normal reference-count block and the slice has zero total bytes.
        let original: Arc<[()]> = unsafe { Arc::<[()]>::new_uninit_slice(len).assume_init() };
        let mut owner = SharedSlice::from_arc(original.clone());
        assert_eq!(owner.metadata, INDIRECT);
        assert_eq!(owner.len(), len);
        assert_eq!(SharedSlice::as_ptr(&owner), Arc::as_ptr(&original));
        let clone = owner.clone();
        assert_eq!(clone.metadata, INDIRECT);
        assert_eq!(SharedSlice::strong_count(&owner), 3);
        let weak = SharedSlice::downgrade(&owner);
        let upgrade = weak.upgrade().unwrap();
        assert_eq!(upgrade.len(), len);
        assert_eq!(upgrade.metadata, INDIRECT);
        assert!(SharedSlice::ptr_eq(&owner, &upgrade));
        assert_eq!(SharedSlice::strong_count(&owner), 4);
        drop(original);
        drop(clone);
        drop(upgrade);
        assert!(SharedSlice::get_mut(&mut owner).is_none());
        drop(weak);
        assert_eq!(SharedSlice::get_mut(&mut owner).unwrap().len(), len);
    }
}

#[repr(C)]
struct HeaderSlice<T: ?Sized> {
    hash: AtomicU64,
    items: T,
}
impl sealed::Sealed for HeaderSlice<[u128]> {}
// SAFETY: real Arc unsizing supplies the unchanged length of the final slice.
unsafe impl ArcMetadata for HeaderSlice<[u128]> {
    fn metadata(&self) -> usize {
        self.items.len()
    }
    fn pointer(data: *const (), len: usize) -> *const Self {
        ptr::slice_from_raw_parts(data.cast::<u128>(), len) as *const Self
    }
}

#[test]
fn header_and_tail_keep_their_original_arc_layout_and_unique_mutation() {
    let original: Arc<HeaderSlice<[u128]>> = Arc::new(HeaderSlice {
        hash: AtomicU64::new(7),
        items: [11_u128, 22, 33],
    });
    let mut owner = CompactArc::from_arc(original.clone());
    assert_eq!(CompactArc::as_ptr(&owner), Arc::as_ptr(&original));
    assert_eq!(owner.hash.load(Ordering::Relaxed), 7);
    assert_eq!(owner.items, [11, 22, 33]);
    drop(original);
    let weak = CompactArc::downgrade(&owner);
    assert!(CompactArc::get_mut(&mut owner).is_none());
    drop(weak);
    let value = CompactArc::get_mut(&mut owner).unwrap();
    value.hash.store(19, Ordering::Relaxed);
    value.items[1] = 88;
    assert_eq!(owner.hash.load(Ordering::Relaxed), 19);
    assert_eq!(owner.items, [11, 88, 33]);
}

#[test]
fn shared_owners_and_weak_upgrades_survive_thread_handoffs() {
    let owner = SharedStr::from("shared 🧶 text");
    let weak = SharedStr::downgrade(&owner);
    std::thread::scope(|scope| {
        for _ in 0..2 {
            let weak = weak.clone();
            scope.spawn(move || {
                for _ in 0..20 {
                    let value = weak.upgrade().unwrap();
                    assert_eq!(&*value, "shared 🧶 text");
                    assert_eq!(value.chars().count(), 13);
                }
            });
        }
    });
    drop(owner);
    assert!(weak.upgrade().is_none());
}

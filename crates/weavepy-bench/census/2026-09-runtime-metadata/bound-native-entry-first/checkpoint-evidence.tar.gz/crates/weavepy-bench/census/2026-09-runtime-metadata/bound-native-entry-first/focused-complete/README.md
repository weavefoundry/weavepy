# Focused completion through a cold-only continuation

All 18 cases are complete and verified. The original run completed ten call
shapes and four warm exception cases, then failed because its cold probes
lacked a standalone timer. It recorded no cold timing samples. Keep that
failed stage and all completed samples unchanged. A separate continuation
measured only the four cold cases using their original timer-bearing sources.
Both runs met the declared load precondition. The summary records source
locations, hashes, conditions, all ratios, and every regression. No completed
sample was repeated or filtered. This manifest does not turn the original
failed stage into a successful run.

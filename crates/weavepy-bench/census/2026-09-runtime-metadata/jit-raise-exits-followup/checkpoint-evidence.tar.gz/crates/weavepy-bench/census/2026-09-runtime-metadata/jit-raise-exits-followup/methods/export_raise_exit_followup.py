"""Preserve compact, reproducible explicit-raise validation and measurements."""
import hashlib
import json
from pathlib import Path
import shutil
import statistics

parent = Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out = parent / 'jit-raise-exits-followup'
assert not out.exists()
full = Path('target/jit-raise-call-spans-full-diagnostic')
assert (full / 'stage.txt').read_text().strip() == 'done'
assert json.loads(Path('target/jit-raise-call-spans-full-diagnostic-load.json').read_text())['status'] == 'complete'
out.mkdir()
records = []

def copy(source, dest):
    source = Path(source)
    path = out / dest
    path.parent.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    path.write_bytes(data)
    records.append({'path': dest, 'source': str(source), 'bytes': len(data),
                    'sha256': hashlib.sha256(data).hexdigest()})

for name in ['suite.json', 'startup.json', 'summary.json', 'vm-before.txt', 'vm-after.txt',
             'memory-before.txt', 'memory-after.txt']:
    copy(full / name, 'full-diagnostic/' + name)
for group in ['kernels', 'calls', 'exceptions', 'cold-exceptions']:
    copy(Path('target/jit-raise-call-spans-diagnostic-v2') / group / 'measurements.json',
         'focused-diagnostic/' + group + '.json')
for label, folder in [('corrected', 'jit-raise-call-spans'), ('rejected-prototype', 'jit-raise-exits')]:
    for name in ['environment.json', 'source-changes.diff', 'tests/regrtest/test_jit_raise_exits.py']:
        copy(Path('target') / (folder + '-source-snapshot') / name, label + '/' + name)
    copy(Path('target') / (folder + '-validation') / 'validation.json', label + '/compatibility.json')
for name in ['jit-raise-call-spans-jit-tests-final.txt', 'jit-raise-call-spans-vm-tests.txt',
             'jit-raise-call-spans-clippy.txt', 'jit-raise-call-spans-no-jit.txt',
             'jit-raise-call-spans-format.txt', 'jit-raise-call-spans-build.txt']:
    copy(Path('target') / name, 'corrected/checks/' + name)
for name in ['jit-raise-call-spans-focused-load.json', 'jit-raise-call-spans-full-load.json',
             'jit-raise-call-spans-diagnostic-load.json', 'jit-raise-call-spans-diagnostic-load.txt',
             'jit-raise-call-spans-diagnostic-v2-load.json', 'jit-raise-call-spans-full-diagnostic-load.json']:
    copy(Path('target') / name, 'conditions/' + name)
for folder in ['jit-raise-call-spans-diagnostic-v2-inputs', 'jit-raise-call-spans-full-diagnostic-inputs',
               'jit-raise-call-spans-measurement-inputs']:
    for path in sorted((Path('target') / folder).iterdir()):
        if path.is_file():
            copy(path, 'methods/' + folder + '/' + path.name)
for path in sorted(Path('target/jit-raise-call-spans-inputs').rglob('*')):
    if path.is_file() and path.suffix in ['.py', '.json']:
        copy(path, 'inputs/' + str(path.relative_to('target/jit-raise-call-spans-inputs')))
for name in ['check_jit_raise_call_spans.sh', 'validate_jit_raise_call_spans.sh',
             'build_jit_raise_call_spans.sh', 'inspect_raise_pickle_coverage.py',
             'preflight_jit_raise_call_spans.py', 'jit_raise_constructed_repro.py',
             'diagnose_jit_raise_io.py', 'capture_io_diagnostic_child.py',
             'profile_raise_pickle_records.py', 'prepare_jit_raise_call_span_measurements.py',
             'export_raise_exit_followup.py']:
    copy(Path('target') / name, 'methods/' + name)
for source, dest in [
    ('target/jit-raise-exits-io-diagnostic/report.json', 'rejected-prototype/io-diagnostic.json'),
    ('target/jit-raise-call-spans-pickle/report.json', 'corrected/pickle-coverage.json'),
    ('target/jit-raise-call-spans-pickle-profiles/flat-self-samples.json', 'corrected/pickle-cpu-samples.json'),
]:
    copy(source, dest)

focused = {}
for group in ['kernels', 'calls', 'exceptions', 'cold-exceptions']:
    data = json.loads((out / 'focused-diagnostic' / (group + '.json')).read_text())
    for name, row in data['rows'].items():
        ratios = [a['ns'] / b['ns'] for a, b in zip(row['samples']['jit'], row['samples']['previous_jit'])]
        focused[group + '/' + name] = {
            'new_over_previous': row['previous_comparisons'],
            'new_over_cpython': row['cpython_comparisons'],
            'paired_jit_work_ratio_range': [min(ratios), max(ratios)],
        }
summary = {'status': 'provisional under recorded host contention',
           'checkpoint': '8899e3679267f571bc5d50167197c8a558e19c5f3278bf3e74df0a8607213284',
           'candidate': '539c6dd3e022c7ffe839861177ed75c2d733e3960625d28d3e8c8837d10a3589',
           'binary_bytes': {'checkpoint': 44290336, 'candidate': 44290560},
           'focused': focused,
           'full': json.loads((out / 'full-diagnostic/summary.json').read_text())}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
report = '''# Explicit raise exits and pickle coverage

The corrected candidate is 539c6dd3, built from checkpoint 566c7bf plus the
preserved source delta and untracked regression file. The comparison binary
8899e367 is the checkpoint runtime. The binary grew by 224 bytes to 44,290,560.
The runtime goal remains unachieved.

The JIT now compiles normal paths in functions containing explicit raises.
Exception exits preserve operands, locals, and the exact instruction address
for the interpreter. An initial prototype incorrectly restored a call marker
from the other branch of a conditional constructor argument. It failed nine
I/O checks; retain that prototype's delta, environment, validation, and
failure diagnostic. The corrected analyzer excludes proven marker-free raise
exits from call spans and removes duplicate spans. A separate exception fix
clears the reused exception instance's __cause__ slot for `raise from None`.

The corrected build passed 56 JIT tests, 342 VM tests, formatting, Clippy,
a build without default features, 57 targeted checks, and all 275 compatibility
checks. Twelve focused inputs passed 72 mode/oracle checks. Four pickle
components matched CPython's bytes and reconstructed values. Record decoding
additionally compiled `read`; the main pickle drivers still encountered other
unsupported instructions. Source snapshots establish identity, not validation.

Both strict load gates expired without starting measurements. Subsequent
focused and full results are separate busy-host diagnostics, with all raw
samples and load observations retained. The first focused diagnostic launcher
failed before any benchmark sample because of an empty Bash array; its failure
is preserved. No sample was filtered or retried. Small timing changes remain
provisional. These measurements do not replace the earlier quiet-host headline.

The focused guarded integer, float, and list loops took about 1/61, 1/38, and
1/12 of checkpoint workload time. Those three workload timers beat CPython,
but peak RSS stayed near twice CPython. Guarded calls improved about 2.9-fold
but still took 2.9 times CPython workload time. Warm always-raising calls
regressed 9.3%, and cold always-raising calls regressed 6.3%; all seven paired
workload ratios were worse. Ordinary controls and half-raising cases include
mixed results and outliers. `summary.json` retains every comparison and range.

The full diagnostic contains 24 unchanged standard fixtures, five paired
samples each, plus nine startup/import cases with 31 pairs. Startup/import
helper measurements use JIT disabled. The full summary keeps the historical
21-row timing cohort separate from the complete 23-workload timing cohort;
all 24 process wall, CPU, and RSS rows remain present. See `full-diagnostic`
for exact cohort results, sample counts, row values, and frozen-cache checks.

Nested native calls do not apply the ordinary frame's deopt retirement budget.
Coverage recorded 5,374 native-call exits in the always-raising case versus
ten in the checkpoint. A simple permanent retirement was left unapplied
because an early error burst could disable profitable later normal calls.
Native CPU samples for pickle mainly showed interpreter dispatch and object
allocation/cloning; they do not identify a particular Python helper's cost or
establish a performance gain. Raw profiles remain in local target archives.

This is evidence for these workloads on the local host, not universal
superiority. CPython still wins many time and memory comparisons. Energy,
controlled build latency, portability, and free-threaded performance are not
established. The index identifies every selected artifact by checksum; full
local caches, executables, and raw sampling captures remain outside Git.
'''
(out / 'REPORT.md').write_text(report)
for name in ['summary.json', 'REPORT.md']:
    p = out / name
    records.append({'path': name, 'bytes': p.stat().st_size,
                    'sha256': hashlib.sha256(p.read_bytes()).hexdigest()})
(out / 'index.json').write_text(json.dumps(records, indent=2) + '\n')
with (parent / '.gitignore').open('a') as stream:
    stream.write('\n# Corrected explicit raise exits, including failed prototype evidence.\n')
    for path in sorted(p for p in out.rglob('*') if p.is_file()):
        stream.write('!' + str(path.relative_to(parent)) + '\n')
print('Exported', len(records) + 1, 'files,', sum(p.stat().st_size for p in out.rglob('*') if p.is_file()), 'bytes')

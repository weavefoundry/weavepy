# Phase 74: positional and keyword-only default borrowing

Active source is phase73 positional borrowing plus a keyword-only block change
in lib.rs. Skip processing if every keyword-only argument is already filled;
otherwise borrow the override dictionary and clone only missing default values.
Preserve plain-string iteration/order, None clearing, compiled fallback, and
release borrows before user code or errors. No hash probes under the borrow,
new unsafe operation, or owner/layout change. New regression test:
tests/regrtest/test_overridden_keyword_default_ownership.py.

Both new keyword oracle and all24 fixture checksums pass on CPython. The new
oracle passes on bf2 in JIT/interpreter/GIL-disabled modes. Prior12 positional
fixture sources are unchanged in both cold/warm groups. All347 VM tests pass.
Native C API/clippy/no-JIT checks were just launched through
check_borrowed_keyword_defaults_native.sh; collect the tool session completion
before the fresh build_borrowed_keyword_defaults.sh. No release build or timing
gate is active yet. Source freeze should capture338 source identities.

After build, run check_borrowed_keyword_defaults.sh (93 targeted checks), then
validate_borrowed_keyword_defaults.sh outside the sandbox (275), then readiness.
Measure focused-retained and full-retained sequentially against bf2 only, using
the mandatory outside-sandbox run_serial_performance_gate.py exclusive lease.
24 cold and24 warm controls retain the earlier positional cases and add12
keyword-only cases. The primary comparison is the combined change againstbf2;
44c5 is a source predecessor, not a new timed reference. Keep every result.
No builds/tests/profiles/edits while a timing gate can launch or run.

Phase73 is archived in census/.../borrowed-defaults:500 files,5,537,443bytes;
all hashes verified. Consistent2-12% targeted gains, but broader JIT workload
+0.275%, wall+0.990%, CPU+0.866%, RSS+0.186%; interpreter slightly improves.
Decision is refinement, not general acceptance. bf2 remains the retained
acceptance reference; active defaultCLI remains44c5 until this next build.
No new commit/push. Overall CPython performance goal remains unachieved.

## Native checks complete; release build active

C API156, clippy, and no-JIT checks passed. Their session92930 is closed.
Release build is running in session53542 via build_borrowed_keyword_defaults.sh.
Frozen338 source identities and120 method/input identities. No timing gate.
After inspecting build completion, run targeted93 checks and outside-sandbox275
compatibility checks, then verify_borrowed_keyword_defaults_ready.py. Next bounded
stdlib lead is unapplied in target/datetime-format-time-followup.md.

## Release and targeted checks passed

Release completed in an observed4m03s (not a controlled build-time result).
Candidate target/release/weavepy-runtime-borrowed-keyword-defaults is44,080,336bytes,
SHAbc88bf2b02abaaf0ad6a3d7427a17cab11f864a400a8161fc2effe5f396dd695.
All338 source hashes and120 method/input hashes matched after build. All93
targeted checks passed. Compatibility validation and readiness are running in
session39952. No timing gate has started.

While compatibility ran, a separate safe time-format prototype was created at
target/ascii-time-format-prototype. Three ordinary tests, clippy, and a release
build passed; its std-only CLI matched CPython time.isoformat in7320 boundary/
randomized cases (seed740075), saved under target/ascii-time-format-oracle.
The prototype is unapplied; it is not a VM performance result. Its build session
69143 is closed, and the oracle process finished. No extra build/test job remains.

## Fully validated; focused timing active

All93 targeted and275 compatibility checks passed, along with the readiness
verifier. Validation session39952 is closed. Focused timing is active in
session83101 under the serial lease, with borrowed-keyword-defaults-focused-
retained-load.json and borrowed-keyword-defaults-focused-retained outputs.
Cold24 controls completed; warm verification/measurement was progressing at
last inspection. All prototype build/test/oracle processes ended before launch.
Do not launch full timing until focused completion is explicitly inspected.
Then use the same serial gate for borrowed-keyword-defaults-full-retained,
against bf2 only. No source/method changes or owned build/test/profile jobs
while any measurement gate can launch or run. Preserve all outcomes.

## Focused complete; full timing active

Focused session83101 completed successfully and closed. Its summaries retain
all48 controls. Keyword-only override time improves about11-39% in all seven
JIT pairs per affected case, cold and warm; positional gains remain. Wide
positional all-supplied and compiled keyword64 controls retain about1-2%
regressions, with mixed peak RSS. No sample exclusion.
Full timing is now running in session33268, launched only after focused
completion was inspected/asserted, under the serial gate. Paths are
borrowed-keyword-defaults-full-retained and matching *-load.json. Do not edit
runtime/active methods or run owned build/test/profile work until it closes.
Then inspect all cohorts/startup results, verify frozen hashes, decide/record
acceptance or further refinement, and export before another runtime change.

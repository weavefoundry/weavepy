"""Guarded comparisons must preserve producer and rich-comparison behavior."""
import sys

EVENTS = []
VALUE = 0


def produce(ignored):
    EVENTS.append("produce")
    return VALUE


functions = {}
for name, op in (("lt", "<"), ("le", "<="), ("eq", "=="), ("ne", "!="), ("gt", ">"), ("ge", ">=")):
    namespace = {}
    exec("def left(f, n):\n    return f(n) " + op + " 3\n"
         "def right(f, n):\n    return 3 " + op + " f(n)\n"
         "def branch(f, n):\n    if f(n) " + op + " 3:\n        return 7\n    return 9\n", namespace)
    for side in ("left", "right", "branch"):
        function = namespace[side]
        function.__code__ = function.__code__.replace(co_name="cmp_" + name + "_" + side)
    functions[name] = namespace


def exact(value):
    return value


operations = {
    "lt": lambda a, b: a < b,
    "le": lambda a, b: a <= b,
    "eq": lambda a, b: a == b,
    "ne": lambda a, b: a != b,
    "gt": lambda a, b: a > b,
    "ge": lambda a, b: a >= b,
}
for name, namespace in functions.items():
    operation = operations[name]
    for i in range(300):
        assert namespace["left"](exact, i) == operation(i, 3)
        assert namespace["right"](exact, i) == operation(3, i)
        assert namespace["branch"](exact, i) == (7 if operation(i, 3) else 9)

for value in (-(1 << 63), (1 << 63) - 1, -(1 << 63) - 1, 1 << 63,
              -(1 << 100), 1 << 100, -1, 0, 3, 5, False, True, -0.0, 3.0,
              3.5, float("inf"), float("-inf"), float("nan")):
    VALUE = value
    for name, namespace in functions.items():
        operation = operations[name]
        for side in ("left", "right", "branch"):
            expected = operation(3, value) if side == "right" else operation(value, 3)
            if side == "branch":
                expected = 7 if expected else 9
            EVENTS.clear()
            assert namespace[side](produce, 0) == expected
            assert EVENTS == ["produce"]


class Truth:
    def __bool__(self):
        EVENTS.append("truth")
        return True


TOKEN = Truth()


class Rich:
    def __lt__(self, other):
        EVENTS.append("lt")
        return TOKEN

    def __le__(self, other):
        EVENTS.append("le")
        return TOKEN

    def __eq__(self, other):
        EVENTS.append("eq")
        return TOKEN

    def __ne__(self, other):
        EVENTS.append("ne")
        return TOKEN

    def __gt__(self, other):
        EVENTS.append("gt")
        return TOKEN

    def __ge__(self, other):
        EVENTS.append("ge")
        return TOKEN


class IntSubclass(int):
    __lt__ = Rich.__lt__
    __le__ = Rich.__le__
    __eq__ = Rich.__eq__
    __ne__ = Rich.__ne__
    __gt__ = Rich.__gt__
    __ge__ = Rich.__ge__


reflected = {"lt": "gt", "le": "ge", "eq": "eq", "ne": "ne", "gt": "lt", "ge": "le"}
for value in (Rich(), IntSubclass(2)):
    VALUE = value
    for name, namespace in functions.items():
        for side in ("left", "right"):
            EVENTS.clear()
            assert namespace[side](produce, 0) is TOKEN
            assert EVENTS == ["produce", reflected[name] if side == "right" else name]
        EVENTS.clear()
        assert namespace["branch"](produce, 0) == 7
        assert EVENTS == ["produce", name, "truth"]

FAILURE = LookupError("producer failure")


def raises(ignored):
    EVENTS.append("raises")
    raise FAILURE


for namespace in functions.values():
    for side in ("left", "right", "branch"):
        EVENTS.clear()
        try:
            namespace[side](raises, 0)
        except LookupError as error:
            assert error is FAILURE
        else:
            raise RuntimeError("producer exception was lost")
        assert EVENTS == ["raises"]

VALUE = 8
for namespace in functions.values():
    for _ in range(200):
        EVENTS.clear()
        namespace["left"](produce, 0)
        assert EVENTS == ["produce"]

observed = []


def trace(frame, event, arg):
    if frame.f_code.co_name.startswith("cmp_"):
        observed.append(event)
    return trace


sys.settrace(trace)
try:
    assert functions["gt"]["left"](produce, 0) is True
finally:
    sys.settrace(None)
assert "call" in observed and "return" in observed


def cmp_loop(f, n):
    total = 0
    for i in range(n):
        total += i
        if f(i) < 3:
            total += 1
    return total


for _ in range(200):
    assert cmp_loop(exact, 9) == 39


class ExplodingCompare:
    def __lt__(self, other):
        EVENTS.append("compare_error")
        raise FAILURE


EXPLODING = ExplodingCompare()

def loop_produce(i):
    EVENTS.append(i)
    return EXPLODING if i == 4 else i


EVENTS.clear()
try:
    cmp_loop(loop_produce, 9)
except LookupError as error:
    assert error is FAILURE
    tb = error.__traceback__
    while tb.tb_frame.f_code.co_name != "cmp_loop":
        tb = tb.tb_next
    assert tb.tb_frame.f_locals["i"] == 4
    assert tb.tb_frame.f_locals["n"] == 9
    assert tb.tb_frame.f_locals["total"] == 13
    assert tb.tb_lineno == cmp_loop.__code__.co_firstlineno + 4
else:
    raise RuntimeError("rich-comparison exception was lost")
assert EVENTS == [0, 1, 2, 3, 4, "compare_error"]
assert cmp_loop(exact, 9) == 39
print("integer comparison guards: all checks passed")

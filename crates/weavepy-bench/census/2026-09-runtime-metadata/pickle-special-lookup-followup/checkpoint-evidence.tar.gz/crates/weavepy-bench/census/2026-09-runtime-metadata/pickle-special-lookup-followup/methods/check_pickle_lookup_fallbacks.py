"""Record property and exotic-key fallback callbacks without changing runtime."""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path('target/pickle-special-lookup-fallbacks');root.mkdir()
source=Path('target/pickle_lookup_fallback_probe.py');(root/source.name).write_bytes(source.read_bytes())
report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'runs':{}}
variants=[('cpython',shutil.which('python3.14'),None,[]),
 ('base','target/release/weavepy-runtime-jit-raise-call-spans','1',[]),
 ('new_jit','target/release/weavepy-runtime-pickle-special-lookup','1',[]),
 ('new_interp','target/release/weavepy-runtime-pickle-special-lookup','0',[]),
 ('new_gil0','target/release/weavepy-runtime-pickle-special-lookup','1',['-X','gil=0'])]
for label,binary,jit,flags in variants:
 env=dict(os.environ)
 for key in ['WEAVEPY_JIT','WEAVEPY_JIT_TRACE','WEAVEPY_VM_STATS','WEAVEPY_JIT_THRESHOLD']:
  env.pop(key,None)
 digest=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
 if jit is not None:
  env.update(WEAVEPY_JIT=jit,WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),WEAVEPY_FROZEN_CACHE=str((root/'frozen'/digest).resolve()))
 result=subprocess.run([binary,*flags,str(root/source.name)],env=env,text=True,capture_output=True,timeout=120)
 report['runs'][label]={'binary_sha256':digest,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
 (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 print(label,result.returncode,result.stdout,result.stderr[-2000:],flush=True)
assert all(r['returncode']==0 for r in report['runs'].values())
assert all(report['runs'][label]['stdout']==report['runs']['base']['stdout'] for label in ['new_jit','new_interp','new_gil0'])
report['status']='passed';(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')

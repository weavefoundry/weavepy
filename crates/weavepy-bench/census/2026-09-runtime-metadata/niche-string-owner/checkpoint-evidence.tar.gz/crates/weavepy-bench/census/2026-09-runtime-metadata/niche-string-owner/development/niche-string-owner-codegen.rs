#[allow(dead_code)]
#[path = "niche-string-owner-prototype/src/lib.rs"]
mod owner;
#[no_mangle]
pub fn clone_shared_string(value: &owner::SharedStr) -> owner::SharedStr { value.clone() }
#[no_mangle]
pub fn string_length(value: &owner::SharedStr) -> usize { value.len() }

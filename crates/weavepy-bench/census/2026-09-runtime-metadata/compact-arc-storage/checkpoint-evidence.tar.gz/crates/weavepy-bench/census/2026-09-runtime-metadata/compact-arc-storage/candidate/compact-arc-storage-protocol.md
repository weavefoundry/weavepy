# Compact Arc metadata experiment

Primary reference: bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4,
the measured thin-value-storage candidate. Secondary reference:
ed99cdbaf8e403eb7de9e3cbac86687748481596443b0e5055a77057c57a0a29,
the retained assertion-exit build with ordinary wide Arc owners.

The candidate stores pointer metadata in its strong handle, preserving standard
Arc string/slice allocations and restoring the tuple hash-only header. On 64-bit
targets the handle stores a pointer and seven little-endian metadata bytes.
Lengths outside the inline representation use an individually owned Box<Arc<T>>;
this is an escape representation, not an allocation-size cap. Weak references
keep full pointer metadata. The packing may cost time and enlarge shared fields
outside Object. Do not infer a speed or memory result from layout alone.

Preserve every earlier storage test and add ownership, reference-count, weak
lifetime, destruction, unique mutation, aligned element, large zero-sized slice,
and thread-handoff tests. Run VM and C API tests, strict lint/format, a build
without JIT, 29 targeted Python tests in three modes, and the existing complete
compatibility validator. Run the latter outside the tool filesystem sandbox
because two existing fixtures bind local sockets. Extra nonempty bytes, codecs,
and four C API suites must pass. Marshal retains four preexisting, exactly graded
divergences; record and compare those with ed99, never call them clean passes.
Strict-provenance Miri checks the exact two integrated storage modules on ARM64
and i686 with stub Object and CachedHash types. It does not validate the full VM.

Use the unchanged 27 phase69 inputs: 20 cold population controls of 200,000
values and seven warm operation controls of 20,000 repetitions. Their hashes and
all previous verification outcomes remain. The unchanged sampler verifies all
outputs against CPython before each timing stage, including GIL-disabled mode.
For each reference separately, collect seven alternating pairs in JIT and
interpreter modes plus CPython, with one declared stabilization cycle per row.
All per-binary-SHA frozen caches must remain unchanged across measured samples.

For each reference, also measure 31 samples for nine startup/import probes and
five alternating pairs for the unchanged full 24-fixture census. Keep the
historical 21-row, current 23-workload, and all-24 process cohorts distinct.
Use within-run candidate/reference pairs for attribution. Retain every sample,
regression, exception, validation failure, and failed gate attempt.

Run timing outside the tool filesystem sandbox. Use the unchanged load gate:
three 10-second observations with one- and five-minute averages at most half
the CPU count, waiting at most 600 seconds per launch attempt. Once a run starts,
keep all samples regardless of subsequent load. Capture host load, VM, swap,
source, executable, method, input, reference, and cache identities. No owned
build, test, profile, install, runtime edit, or active-harness edit may overlap a
gate that can launch or any measurement stage. Run the four stages sequentially.

The user goal remains unachieved. These measurements provide no universal,
energy, controlled build-time, portability, or native parallel-scaling claim.

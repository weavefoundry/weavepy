# Full pickle lookup diagnostic protocol

Compare 5201c72e with predecessor 539c6dd3 and CPython 3.14.7 after the full
correctness gates and separately declared focused diagnostic have completed.
The machine has remained busy during previous quiet-host preconditions.
This is a diagnostic without a quiet-host requirement. It must not replace the
last qualified headline or establish a small regression or improvement alone.

Use all nine existing startup/import cases with 31 paired samples and every
one of the 24 unchanged standard fixtures with five paired samples, both JIT
and interpreter modes. Preserve all observations, failed checks, and outliers.
Use the existing correctness checks and per-binary frozen caches. Record load
throughout and VM/swap before and after. Do not run competing builds, tests,
profiles, or change runtime or active harness sources during this run.

Report the historical 21-case cohort, full 23 in-process work cases, and all
24 process time, CPU, and peak-RSS cases separately. The ratio convention is
WeavePy time or memory divided by comparison, so lower is better. Report the
candidate/predecessor and candidate/CPython comparisons. No claim of universal,
energy, controlled build-time, portability, or free-threaded improvement.

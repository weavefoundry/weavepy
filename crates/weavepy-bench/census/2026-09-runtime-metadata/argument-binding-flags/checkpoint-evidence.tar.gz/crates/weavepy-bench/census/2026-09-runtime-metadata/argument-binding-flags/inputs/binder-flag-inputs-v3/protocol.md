# Binder flag storage controls

Prepared before any binder flag candidate build or timing. Ten signature controls
span the inline threshold, large default/keyword-only signatures, variadic slots,
and many body locals. Use seven paired samples, both modes, exact CPython values,
and per-binary frozen caches through the unchanged component helper. These add
to, not replace, the ten existing call shapes and four warm/four cold exceptions.
Perform native coverage checks before interpreting any timer as native work.
Preserve every sample and regression. Complete the current early-entry experiment
before applying the separate binder flag change or measuring these inputs.

V2 correction before any timing: many_body_locals now has a third defaulted
parameter omitted at its call site. The v1 trace showed 850 native-to-native
calls and only three generic dynamic calls, so it was not a warm binding-storage
control. Retain v1 inputs, methods, and traces. Require >=500 generic dynamic
calls in v2 before timing. The other nine benchmark source bytes are unchanged.

V3 correction before any timing: v2 also produced 850 native-to-native calls
and only three generic dynamic calls, failing the >=500 generic coverage check.
Preserve that failure. V3 uses the known sparse layout leaf(d=5, a=i) with b/c
omitted in the middle. Only this changed case needs another path inspection;
the other nine source hashes match their already inspected versions.

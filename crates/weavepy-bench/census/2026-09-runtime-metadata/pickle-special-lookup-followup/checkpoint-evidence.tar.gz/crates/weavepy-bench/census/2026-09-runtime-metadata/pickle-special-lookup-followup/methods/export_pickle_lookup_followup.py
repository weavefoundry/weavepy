"""Preserve the complete guarded pickle lookup experiment, including losses."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--decision', choices=['deferred', 'retained'], required=True)
a = p.parse_args()
parent = Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out = parent / 'pickle-special-lookup-followup'
full = Path('target/pickle-special-lookup-full-diagnostic')
focused = Path('target/pickle-special-lookup-diagnostic')
assert not out.exists()
assert (full / 'stage.txt').read_text().strip() == 'done'
assert (focused / 'stage.txt').read_text().strip() == 'done'
for kind in ['diagnostic', 'full-diagnostic']:
    assert json.loads(Path(f'target/pickle-special-lookup-{kind}-load.json').read_text())['status'] == 'complete'
out.mkdir()
records = []


def copy(source, dest):
    source = Path(source)
    path = out / dest
    path.parent.mkdir(parents=True, exist_ok=True)
    data = source.read_bytes()
    path.write_bytes(data)
    records.append({'path': dest, 'source': str(source), 'bytes': len(data),
                    'sha256': hashlib.sha256(data).hexdigest()})


for name in ['suite.json', 'startup.json', 'summary.json', 'vm-before.txt', 'vm-after.txt',
             'memory-before.txt', 'memory-after.txt']:
    copy(full / name, 'full-diagnostic/' + name)
for group in ['components', 'hooks']:
    copy(focused / group / 'measurements.json', 'focused-diagnostic/' + group + '.json')
for name in ['summary.json', 'vm-before.txt', 'vm-after.txt', 'memory-before.txt', 'memory-after.txt']:
    copy(focused / name, 'focused-diagnostic/' + name)
snapshot = Path('target/pickle-special-lookup-v2-source-snapshot')
for name in ['environment.json', 'source-changes.diff',
             'tests/regrtest/test_pickle_special_lookup.py',
             'crates/weavepy-vm/src/stdlib/pickle_accel.rs',
             'crates/weavepy-vm/src/stdlib/python/copyreg.py']:
    copy(snapshot / name, 'candidate/' + name)
for name in ['pickle-special-lookup-v2-vm-tests.txt', 'pickle-special-lookup-v2-clippy.txt',
             'pickle-special-lookup-v2-no-jit.txt', 'pickle-special-lookup-v2-format.txt',
             'pickle-special-lookup-v2-build.txt', 'pickle-special-lookup-vm-tests.txt']:
    copy(Path('target') / name, 'checks/' + name)
copy('target/pickle-special-lookup-draft/pickle_accel-first-build.rs', 'failed-build/pickle_accel.rs')
for folder in ['pickle-special-lookup-baseline-preflight', 'pickle-special-lookup-baseline-preflight-v2',
               'pickle-special-lookup-baseline-preflight-v3', 'pickle-special-lookup-checks',
               'pickle-special-lookup-validation', 'pickle-special-lookup-copy-checks',
               'pickle-special-lookup-fallbacks', 'pickle-special-lookup-paths',
               'pickle-special-lookup-coverage', 'pickle-special-lookup-call-matrix',
               'pickle-special-lookup-individual-calls']:
    for path in sorted((Path('target') / folder).iterdir()):
        if path.is_file() and path.suffix in ['.py', '.json', '.txt']:
            copy(path, 'checks/' + folder + '/' + path.name)
for name in ['pickle-special-lookup-focused-load.json', 'pickle-special-lookup-diagnostic-load.json',
             'pickle-special-lookup-full-diagnostic-load.json']:
    copy(Path('target') / name, 'conditions/' + name)
for folder in ['pickle-special-lookup-measurement-inputs', 'pickle-special-lookup-diagnostic-inputs',
               'pickle-special-lookup-full-diagnostic-inputs']:
    for path in sorted((Path('target') / folder).iterdir()):
        if path.is_file():
            copy(path, 'methods/' + folder + '/' + path.name)
for path in sorted(Path('target/pickle-special-lookup-inputs').rglob('*')):
    if path.is_file() and path.suffix in ['.py', '.json', '.md']:
        copy(path, 'inputs/' + str(path.relative_to('target/pickle-special-lookup-inputs')))
for name in ['build_pickle_special_lookup_v2.sh', 'check_pickle_special_lookup_paths.py',
             'pickle_special_lookup_path_probe.py', 'check_pickle_special_copy.py',
             'check_pickle_lookup_fallbacks.py', 'pickle_lookup_fallback_probe.py',
             'inspect_call_matrix_coverage.py', 'inspect_individual_call_shapes.py',
             'export_pickle_lookup_followup.py']:
    copy(Path('target') / name, 'methods/' + name)

summary = {'decision': a.decision, 'conditions': 'Busy-host diagnostics; every sample retained.',
           'candidate_sha256': '5201c72e5eafcbfd2cb15e6f5bc6726bb21d914356bf7d4ae0988b08be8da66b',
           'previous_sha256': '539c6dd3e022c7ffe839861177ed75c2d733e3960625d28d3e8c8837d10a3589',
           'binary_bytes': {'candidate': 44291776, 'previous': 44290560},
           'focused': json.loads((focused / 'summary.json').read_text()),
           'full': json.loads((full / 'summary.json').read_text())}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
lines = ['# Guarded pickle hook lookup', '',
         f'Decision: **{a.decision}**. The performance goal remains unachieved.', '',
         'Candidate 5201c72e adds a guarded native lookup for ordinary Python pickle',
         'hooks and calls it from copyreg. It probes live MRO dictionaries and binds',
         'exact functions, static methods, and class methods. Other descriptors,',
         'metaclasses, C extensions, native payloads, exotic class keys, and active',
         'type watchers decline before user callbacks. It adds no lookup cache.', '',
         'The first build used a nonexistent Object::NotImplemented variant and',
         'failed before tests. The corrected build uses the existing singleton.',
         'It passed 342 VM tests, formatting, Clippy, the build without default',
         'features, all 275 standard compatibility checks, 45 targeted checks,',
         'explicit copy/copyreg suites, and four exact pickle byte/value oracles.',
         'Instrumented real pickle calls reached the native lookup path.', '',
         'Baseline preflights preserve existing differences: CPython consults',
         'instance lookup for __getstate__ and rejects explicit None newargs hooks;',
         'WeavePy does not. An exotic string class key invokes equality in CPython',
         'but not in either WeavePy binary, which emits its existing warning.',
         'These are recorded gaps, not parity successes. Both WeavePy versions',
         'already bind ordinary Python functions as method objects. This change',
         'does not establish removal of a closure allocation for those functions.', '',
         'The strict load gate expired after 600 seconds without starting a child.',
         'The separately declared focused and full diagnostics retain all samples,',
         'value checks, isolated frozen-cache checks, load, VM, and swap observations.',
         'They do not replace the last qualified headline. Small differences remain',
         'provisional under contention. The binary grew by 1,216 bytes.', '',
         'The table reports paired medians with lower values better. CPU is the',
         'workload CPU timer, and memory is process peak RSS. Raw paired values and',
         'ranges for every metric and both modes are in summary.json.', '',
         '| Focused case | JIT time / previous | JIT CPU / previous | JIT RSS / CPython |',
         '| --- | ---: | ---: | ---: |']
for name, row in summary['focused'].items():
    b = row['previous']['jit']; c = row['cpython']['jit']
    lines.append(f"| {name} | {b['ns']:.4f} | {b['work_cpu_ns']:.4f} | {c['rss_bytes']:.4f} |")
lines += ['',
          'Function, static-method, and class-method hook workloads improved in all',
          'seven pairs. Metaclass fallback regressed in all seven pairs in both',
          'wall and CPU time, about 9.6% at the JIT median. The record-serialization',
          'control had large dispersion and a worse median; preserve that result',
          'rather than dismissing or retrying it. No focused RSS result beat CPython.', '',
          'The full diagnostic uses all 24 unchanged fixtures with five pairs and',
          'nine startup/import cases with 31 pairs. The startup helper disables JIT.',
          'The summary separates the historical 21-case timing cohort, 23 workload',
          'timers, and all 24 process wall/CPU/RSS comparisons. Full row-level results',
          'and cache identities are retained in full-diagnostic.', '',
          'Seven call-shape coverage probes also matched CPython values. Sparse',
          'keyword and variadic keyword calls account for the two generic calls',
          'per loop in the call-overhead fixture. The outer loop and ordinary',
          'bound-method calls already compile. Coverage is not a timing measurement.', '',
          'The index identifies every selected artifact by SHA-256. Complete local',
          'executables, frozen caches, and other raw research archives stay outside',
          'Git. These results do not establish universal, energy, controlled build,',
          'portability, or free-threaded superiority.', '']
(out / 'REPORT.md').write_text('\n'.join(lines))
for name in ['summary.json', 'REPORT.md']:
    path = out / name
    records.append({'path': name, 'bytes': path.stat().st_size,
                    'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(out / 'index.json').write_text(json.dumps(records, indent=2) + '\n')
for row in records:
    assert hashlib.sha256((out / row['path']).read_bytes()).hexdigest() == row['sha256']
with (parent / '.gitignore').open('a') as stream:
    stream.write('\n# Guarded pickle lookup experiment, including regressions.\n')
    for path in sorted(p for p in out.rglob('*') if p.is_file()):
        stream.write('!' + str(path.relative_to(parent)) + '\n')
print('Exported and verified', len(records) + 1, 'files,',
      sum(p.stat().st_size for p in out.rglob('*') if p.is_file()), 'bytes.')


def bench(n):
    values = [str(i).zfill(129) for i in range(n)]
    return [len(values), len(values[0]), len(values[-1]), int(values[-1])]

if __name__ == '__main__':
    import os, time
    n = int(os.environ['WEAVEPY_BENCH_WORK'])
    start = time.perf_counter_ns()
    cpu = time.process_time_ns()
    result = bench(n)
    cpu_elapsed = time.process_time_ns() - cpu
    elapsed = time.perf_counter_ns() - start
    print('WEAVEPY_BENCH_NS=%d' % elapsed)
    print('WEAVEPY_BENCH_CPU_NS=%d' % cpu_elapsed)

# Binder flag storage experiment plan, not launched

Apply the separate inline flag draft only after the early-entry candidate's full
run has finished and all its evidence is preserved. Existing boundary preflight
passes on CPython, retained 539c, and early-entry 95b in JIT/interpreter/gil0.
Require full VM/static, 63 targeted release checks (21 tests x three modes), full
275-check compatibility, five extra call/inspection/copy suites, and explicit
native-entry coverage before timing. Freeze all changed sources and binaries.

Focused timing uses a separate unchanged-order harness copied from the component
helper, with an additional reference binary. The immediate predecessor is 95b,
and the additional reference is retained 539c. Compare both execution modes of
all three binaries and CPython in each seven-pair experiment. This distinguishes
the flag-storage delta from the combined entry-and-storage change. Preserve exact
values, binary-SHA caches, all samples, paired ratios, and regressions.

Measure all ten original call shapes, ten newly prepared signature controls,
four warm exceptions, and four cold exceptions. Inputs retain their frozen bytes
and work sizes. The new controls include 16/17/64/130 default signatures,
16/17/64 keyword-only signatures, 14/15 positional plus two variadic slots,
and 130 body locals with a two-parameter signature.

Run all 24 unchanged fixtures with five pairs and nine startup/import controls
with 31 pairs (startup helper JIT disabled). Full-suite baseline is retained 539c,
so the combined change must account for the earlier entry-path regressions.
Report 21/23/24 cohorts separately and all process wall/CPU/RSS metrics.

Focused and full each require load 1/5 minute averages <=4 for three observations
ten seconds apart, maximum wait 600 seconds. Preserve an expired no-child gate
before any separately declared diagnostic. Never select or rerun completed
samples because of later load or an unfavorable result. No competing owned
build/test/profile or runtime/active-method edits once timing can launch.

This proposal does not establish allocation counts, process-memory reduction,
energy, controlled build-time, portability, or free-threaded performance.

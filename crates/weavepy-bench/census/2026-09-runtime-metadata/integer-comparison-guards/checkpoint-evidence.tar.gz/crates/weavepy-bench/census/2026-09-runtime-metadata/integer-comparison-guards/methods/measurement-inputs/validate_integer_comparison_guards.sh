#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/integer-comparison-guards-validation/frozen"
binary=target/release/weavepy-runtime-integer-comparison-guards
output=target/integer-comparison-guards-validation
test "$(cat target/integer-comparison-guards-check-stage.txt)" = done
test ! -e "$output"
mkdir "$output"
printf 'full compatibility\n' > target/integer-comparison-guards-validation-stage.txt
python3.14 crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py --binary "$binary" --out "$output/validation.json" > "$output/validation.txt" 2>&1
printf 'done\n' > target/integer-comparison-guards-validation-stage.txt

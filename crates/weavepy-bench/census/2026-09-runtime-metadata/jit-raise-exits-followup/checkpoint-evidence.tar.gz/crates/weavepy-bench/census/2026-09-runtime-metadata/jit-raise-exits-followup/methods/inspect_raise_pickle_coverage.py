"""Verify current pickle component values and compare actual JIT coverage."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

root = Path('target/jit-raise-call-spans-pickle')
assert not root.exists()
root.mkdir()
inputs = Path('target/pickle-component-probes')
prepared = json.loads((inputs / 'preparation.json').read_text())
old_oracle = json.loads((inputs / 'oracle.json').read_text())
variants = [('cpython', shutil.which('python3.14'), None),
            ('base', 'target/release/weavepy-runtime-weakref-shared-keys', '1'),
            ('new', 'target/release/weavepy-runtime-jit-raise-call-spans', '1')]
report = {'purpose': __doc__, 'binaries': {}, 'rows': {}}
for label, binary, jit in variants:
    path = Path(binary).resolve()
    report['binaries'][label] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}

def save():
    (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def environment(label, jit):
    env = dict(os.environ)
    for key in ['WEAVEPY_JIT', 'WEAVEPY_JIT_TRACE', 'WEAVEPY_VM_STATS', 'WEAVEPY_JIT_THRESHOLD']:
        env.pop(key, None)
    if jit is not None:
        env.update(WEAVEPY_JIT=jit,
                   WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
                   WEAVEPY_FROZEN_CACHE=str((root / 'frozen' / report['binaries'][label]['sha256']).resolve()))
    return env

for name, case in prepared['rows'].items():
    source = Path(case['path'])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == case['source_sha256']
    original_driver = Path(old_oracle['rows'][name + '_p5']['runs']['cpython']['driver'])
    driver = root / (name + '-verify.py')
    driver.write_bytes(original_driver.read_bytes())
    row = report['rows'][name] = {'case': case, 'verification': {}, 'coverage': {},
                                 'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest()}
    for label, binary, jit in variants:
        result = subprocess.run([binary, str(driver)], env=environment(label, jit), text=True, capture_output=True, timeout=180)
        row['verification'][label] = {'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
        save()
        assert result.returncode == 0, (name, label, result.stderr)
        assert result.stdout == row['verification']['cpython']['stdout'], (name, label)
    value = json.loads(row['verification']['cpython']['stdout'])
    length = value['blob_bytes'] if case['operation'] == 'dumps' else (6 if case['population'] == 'payload' else 20)
    expected = length * case['work']
    counter_driver = root / (name + '-counters.py')
    counter_driver.write_text(f'''import sys, types
module = types.ModuleType("_weavepy_bench")
module.__file__ = {str(source)!r}
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
print(module.bench({case['work']}))
print(module.bench({case['work']}))
''')
    for label, binary, jit in variants[1:]:
        env = environment(label, jit)
        env.update(WEAVEPY_JIT_TRACE='1', WEAVEPY_VM_STATS='1')
        result = subprocess.run([binary, str(counter_driver)], env=env, text=True, capture_output=True, timeout=180)
        trace = root / (name + '-' + label + '.trace.txt')
        trace.write_text(result.stderr)
        row['coverage'][label] = {'returncode': result.returncode, 'stdout': result.stdout,
                                  'trace': str(trace), 'trace_sha256': hashlib.sha256(trace.read_bytes()).hexdigest(),
                                  'compiled': sorted(set(re.findall(r'jit compile "([^"]+)"', result.stderr))),
                                  'rejections': sorted(set(re.findall(r'jit reject .+', result.stderr))),
                                  'stats': {key: int(value.replace(',', '')) for key, value in re.findall(r'^- ([^:]+): \*\*([\d,]+)\*\*', result.stderr, re.M)}}
        save()
        assert result.returncode == 0 and result.stdout == f'{expected}\n{expected}\n', (name, label)
    print(name, 'values and instrumented results verified', flush=True)
report['status'] = 'passed'
save()

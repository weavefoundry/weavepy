def leaf(a, *, b=2):
    return a + b

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(b=3, a=i)
    return total

# Initialized storage for short generic native calls

Source and direct comparison reference is the time formatter candidate:
681043b9f62cbd4fdb3f73756ecdf8ac877c1923b6a509f11ff1128dc973443c.
Retained acceptance reference is bf2:
bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4.
The candidate outlines generic dynamic-call dispatch and uses an initialized
four-Object array for zero through four positional arguments. Larger positional
calls and all keyword calls retain the vector path. Existing compiled-callee
entry precedes the outlined helper. Preserve argument order and ownership,
keyword-tail moves, activation shells, dirty marking, global guards, exceptions,
parked results, and exact-integer exits. No new uninitialized storage, ownership
representation, or interpreter-facing argument limit. Inspect generated stack
frames; an inline source array alone is not evidence of lower overall stack use.

The new Python oracle passes on CPython and the predecessor in JIT, interpreter,
and GIL-disabled modes. It checks arities, aliases, keyword order, nested calls,
weak-reference lifetimes, mixed results, exceptions, global mutation inside a
callback, and frame visibility. The VM test asserts at least 100 executions in
each of seven argument paths using test-only counters. Run all 352 VM tests,
156 C API tests, strict format/lint, no-JIT check, 99 targeted Python checks,
and the unchanged 275-check outside-sandbox compatibility suite.

The original 25 inputs and their baseline traces remain. One original four-
object setup cannot compile because it unpacks a tuple. Keep it as a control,
and add a separate four-object input with explicit assignments. The 26-input
v2 set preserves every original fixture source. Independently check all CPython
checksums. Capture untimed predecessor and candidate paths for every fixture.
Require the intended short, larger, keyword, method, and object call drivers to
compile and make at least 30,000 generic calls; compiled-alias controls must
compile and make at least 30,000 native-to-native calls. These traces are not
timings. Wide 32-argument and original four-object drivers remain interpreted,
as do several unchanged formatter/binding controls. Report their actual paths.

Each focused stage keeps seven alternating pairs and a declared stabilization
cycle for all 26 cold and 26 repeated controls, each with 20,000 calls. Use the
unchanged sampler, CPython output verification before/after warmup, correctness-
only GIL-disabled checks, per-binary-SHA frozen caches, and unchanged-cache
assertions. Each full stage keeps 31 startup/import samples and five alternating
pairs of the unchanged 24-fixture census. Keep 21/23/24-row cohorts distinct.

Freeze source, method, fixture, and binary identities after the release CLI
build. Run four sequential stages: focused-previous, full-previous, focused-
retained, full-retained. Use run_serial_performance_gate.py outside the filesystem
sandbox. Its lease covers the complete load gate and child. Inspect completion
and successful gate JSON before every dependent launch. No owned build, test,
profile, install, runtime edit, or active-harness edit may overlap a gate that
can launch or measure. Keep every launched sample regardless of later load.
The unchanged gate requires three 10-second observations with one- and five-
minute load averages at most half the CPU count, waiting up to 600 seconds.

Preserve all gains, losses, raw samples, errors, source snapshots, identities,
load observations, and VM/swap snapshots. The initial test-only Cell import and
format failures and rejected objdump flag remain alongside corrected results.
Overall superiority to CPython remains unachieved. No universal, energy,
controlled build-time, portability, or native parallel-scaling claim follows.

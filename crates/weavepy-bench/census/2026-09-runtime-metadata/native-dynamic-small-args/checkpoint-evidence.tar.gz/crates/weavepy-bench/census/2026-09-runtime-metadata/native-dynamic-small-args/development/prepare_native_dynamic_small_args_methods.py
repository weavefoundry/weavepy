"""Prepare direct and retained comparisons for generic native-call arguments."""
from pathlib import Path
for name in ['build_ascii_time_format.sh','check_ascii_time_format.sh',
             'validate_ascii_time_format.sh','measure_ascii_time_format_focused.sh',
             'measure_ascii_time_format_full.sh','summarize_ascii_time_format.py',
             'freeze_ascii_time_format_sources.py','verify_ascii_time_format_ready.py']:
    text=(Path('target')/name).read_text().replace('ascii-time-format','native-dynamic-small-args').replace('ascii_time_format','native_dynamic_small_args')
    if name.startswith('build_'):
        text=text.replace('base=target/release/weavepy-runtime-borrowed-keyword-defaults','base=target/release/weavepy-runtime-ascii-time-format')
    if name.startswith('check_'):
        text=text.replace('for test in ','for test in test_dynamic_argument_storage ')
        text=text.replace("printf 'done\\n'",'''WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_dynamic_argument_storage.py > target/native-dynamic-small-args-checks/dynamic-coverage.stdout.txt 2> target/native-dynamic-small-args-checks/dynamic-coverage.stderr.txt
python3.14 target/check_native_dynamic_small_args_coverage.py "$binary" target/native-dynamic-small-args-checks/fixture-coverage target/native-dynamic-small-args-inputs-v2 > target/native-dynamic-small-args-checks/fixture-coverage.txt 2>&1
printf 'done\\n' ''')
    if name.startswith('measure_'):
        text=text.replace('17 first-invocation formatter and binding','26 first-invocation call and inherited').replace('17 repeated formatter and binding','26 repeated call and inherited')
        text=text.replace('target/native-dynamic-small-args-inputs/','target/native-dynamic-small-args-inputs-v2/')
    if name.startswith('summarize_'):
        text=text.replace("[('cold',17),('warm',17)]","[('cold',26),('warm',26)]")
        text=text.replace('paired storage-control','paired call-control')
    if name.startswith('freeze_'):
        text=text.replace('Freeze the time formatter change','Freeze generic native-call argument storage')
        text=text.replace('target/borrowed-keyword-defaults-prebuild.json','target/ascii-time-format-prebuild.json')
        text=text.replace("{'crates/weavepy-vm/src/stdlib/datetime_accel.rs', 'crates/weavepy-vm/src/stdlib/python/_pydatetime.py'}","{'crates/weavepy-vm/src/tier2.rs', 'crates/weavepy-vm/src/lib.rs'}")
        text=text.replace("paths.add('tests/regrtest/test_time_format_fastpath.py')","paths.add('tests/regrtest/test_dynamic_argument_storage.py')")
        text=text.replace("'prepare_native_dynamic_small_args_inputs.py', 'prepare_native_dynamic_small_args_methods.py',","'prepare_native_dynamic_small_args_inputs.py', 'prepare_native_dynamic_small_args_inputs_v2.py', 'prepare_native_dynamic_small_args_methods.py',\n    'check_native_dynamic_small_args_coverage.py', 'apply_native_dynamic_small_args.py', 'native-dynamic-small-args-input-oracles-v2.json',")
        text=text.replace("Path('target/native-dynamic-small-args-inputs')","Path('target/native-dynamic-small-args-inputs-v2')")
    if name.startswith('verify_'):
        text=text.replace('Require complete formatter validation','Require complete generic-call validation')
        text=text.replace('351 passed','352 passed').replace('vm-tests-01.txt','vm-tests-02.txt').replace('== 32','== 33').replace('96 targeted','99 targeted')
        text=text.replace('bc88bf2b02abaaf0ad6a3d7427a17cab11f864a400a8161fc2effe5f396dd695','681043b9f62cbd4fdb3f73756ecdf8ac877c1923b6a509f11ff1128dc973443c')
        text=text.replace('time formatting semantics: ok','dynamic argument storage: semantics and ownership ok').replace('test_time_format_fastpath-','test_dynamic_argument_storage-')
        text=text.replace('oracle-{label}.txt','oracle-{label}-complete.txt')
        pos=text.index("print('All source/")
        text=text[:pos]+'''for folder in ['target/native-dynamic-small-args-baseline-coverage-v2', 'target/native-dynamic-small-args-checks/fixture-coverage']:
    coverage = read(folder + '/report.json')
    assert len(coverage['rows']) == 26
    for name, row in coverage['rows'].items():
        assert row['returncode'] == 0
        generic = name.startswith(('generic_pos_', 'generic_kw_', 'generic_method_', 'generic_object_')) and name not in ['generic_pos_32', 'generic_object_4']
        if generic:
            assert row['bench_compiled'] and row['stats']['generic dyn calls'] >= 30000, (folder, name)
        if name.startswith('compiled_alias_'):
            assert row['bench_compiled'] and row['stats']['native-to-native calls'] >= 30000, (folder, name)
assert 'generic dyn calls:' in Path('target/native-dynamic-small-args-checks/dynamic-coverage.stderr.txt').read_text()
'''+text[pos:]
    out=Path('target')/name.replace('ascii_time_format','native_dynamic_small_args')
    assert not out.exists(),out
    out.write_text(text)
print('Prepared fresh generic-call trial methods.')

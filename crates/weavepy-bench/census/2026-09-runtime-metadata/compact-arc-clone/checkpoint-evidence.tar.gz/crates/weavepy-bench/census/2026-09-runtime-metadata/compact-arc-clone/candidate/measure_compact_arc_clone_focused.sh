#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/compact-arc-clone-validation-stage.txt)" = done
python3.14 target/verify_compact_arc_clone_ready.py
base="$1"
output="$2"
test ! -e "$output"
mkdir "$output"
binary=target/release/weavepy-runtime-compact-arc-clone
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf '20 population controls\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/thin-value-storage-inputs/cold --out "$output/cold" --samples 7 --cold > "$output/cold.txt" 2>&1
printf 'seven repeated-operation controls\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/thin-value-storage-inputs/warm --out "$output/warm" --samples 7 > "$output/warm.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
printf 'done\n' > "$output/stage.txt"

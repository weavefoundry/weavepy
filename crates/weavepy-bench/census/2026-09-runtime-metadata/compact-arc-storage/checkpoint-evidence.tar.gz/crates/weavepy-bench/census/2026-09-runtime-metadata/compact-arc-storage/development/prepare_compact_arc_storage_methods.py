"""Prepare fresh methods; keep prior experiment scripts and all inputs intact."""
from pathlib import Path

def write(name, text):
    path = Path('target') / name
    assert not path.exists(), path
    path.write_text(text)

for old, new in [('check_thin_value_storage.sh', 'check_compact_arc_storage.sh'),
                 ('validate_thin_value_storage.sh', 'validate_compact_arc_storage.sh')]:
    write(new, (Path('target') / old).read_text().replace('thin-value-storage', 'compact-arc-storage'))

extra = Path('target/check_thin_value_storage_extra_v2.py').read_text()
extra = extra.replace('thin-value-storage-extra-checks-v2', 'compact-arc-storage-extra-checks')
extra = extra.replace('weavepy-runtime-thin-value-storage', 'weavepy-runtime-compact-arc-storage')
extra = extra.replace("['test_capi/test_bytes'", "['test_bytes','test_codecs','test_marshal','test_capi/test_bytes'")
extra = extra.replace("'--expectations','target/thin-value-storage-capi-selection.toml',", "*(['--expectations','target/thin-value-storage-capi-selection.toml'] if case.startswith('test_capi/') else []),")
extra = extra.replace("        run['nonempty_and_passed']=passed(run)", """        run['nonempty_and_passed']=passed(run)
        run['expected_marshal_divergence'] = case == 'test_marshal' and run['returncode'] == 0 and '1 total' in run['stdout'] and 'divergence 1' in run['stdout'] and 'unexpected 0' in run['stdout'] and '| divergence | divergence |' in run['stdout']
        run['accepted'] = run['nonempty_and_passed'] or run['expected_marshal_divergence']""")
extra = extra.replace("if run['nonempty_and_passed']:", "if run['nonempty_and_passed']:")
extra = extra.replace("all(r['new']['nonempty_and_passed'] for r in report['runs'].values())", "all(r['new']['accepted'] for r in report['runs'].values()) and all(r['accepted'] for r in report['runs']['test_marshal'].values())")
write('check_compact_arc_storage_extra.py', extra)

focused = Path('target/measure_thin_value_storage_focused_v2.sh').read_text()
focused = focused.replace('thin-value-storage-validation-corrected-stage', 'compact-arc-storage-validation-stage')
focused = focused.replace('verify_thin_value_storage_ready_v2.py', 'verify_compact_arc_storage_ready.py')
focused = focused.replace('output=target/thin-value-storage-focused', 'base="$1"\noutput="$2"')
focused = focused.replace('base=target/release/weavepy-runtime-jit-assertion-exits\n', '')
focused = focused.replace('weavepy-runtime-thin-value-storage', 'weavepy-runtime-compact-arc-storage')
write('measure_compact_arc_storage_focused.sh', focused)
full = Path('target/measure_thin_value_storage_full_v2.sh').read_text()
full = full.replace('thin-value-storage-validation-corrected-stage', 'compact-arc-storage-validation-stage')
full = full.replace('base="$(cat target/thin-value-storage-previous.txt)"', 'base="$3"\npython3.14 target/verify_compact_arc_storage_ready.py')
full = full.replace('weavepy-runtime-thin-value-storage', 'weavepy-runtime-compact-arc-storage')
write('measure_compact_arc_storage_full.sh', full)

summary = Path('target/summarize_thin_value_storage.py').read_text()
summary = summary.replace('import json,math,statistics', 'import json,math,statistics,sys')
summary = summary.replace("root=Path('target/thin-value-storage-focused')", 'root=Path(sys.argv[1])')
write('summarize_compact_arc_storage.py', summary)

build = '''#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-thin-value-storage
binary=target/release/weavepy-runtime-compact-arc-storage
test ! -e "$binary"
test ! -e target/compact-arc-storage-build-stage.txt
cargo fmt --all -- --check > target/compact-arc-storage-format.txt 2>&1
python3.14 target/freeze_compact_arc_storage_sources.py
printf 'release build\\n' > target/compact-arc-storage-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/compact-arc-storage-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/compact-arc-storage-source-snapshot --extra target/build_compact_arc_storage.sh target/check_compact_arc_storage.sh target/validate_compact_arc_storage.sh target/check_compact_arc_storage_extra.py target/measure_compact_arc_storage_focused.sh target/measure_compact_arc_storage_full.sh target/measure_verified_python_components.py target/compact-arc-storage-protocol.md target/verify_compact_arc_storage_ready.py target/freeze_compact_arc_storage_sources.py target/summarize_compact_arc_storage.py > target/compact-arc-storage-snapshot.txt 2>&1
printf 'done\\n' > target/compact-arc-storage-build-stage.txt
'''
write('build_compact_arc_storage.sh', build)
print('Prepared fresh build, validation, and two-reference timing methods.')

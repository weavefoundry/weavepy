def checked_value(n):
    if n < 0:
        raise ValueError("negative")
    return n + 1

def bench(n):
    count = 0
    total = 0
    for i in range(n):
        value = -1 if False else 7
        try:
            total += checked_value(value)
        except ValueError:
            count += 1
    return count, total

if __name__ == '__main__':
    import os
    import time
    n = int(os.environ['WEAVEPY_BENCH_WORK'])
    start = time.perf_counter_ns()
    bench(n)
    print('WEAVEPY_BENCH_NS=%d' % (time.perf_counter_ns() - start))

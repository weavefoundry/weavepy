#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/ascii-time-format-checks/frozen"
binary=target/release/weavepy-runtime-ascii-time-format
test "$(cat target/ascii-time-format-build-stage.txt)" = done
test ! -e target/ascii-time-format-checks
mkdir target/ascii-time-format-checks
printf 'targeted binding, native calls, and observability\n' > target/ascii-time-format-check-stage.txt
for test in test_time_format_fastpath test_overridden_keyword_default_ownership test_overridden_default_ownership test_shared_value_storage test_tuple_storage test_tuple_hash_cache test_marshal_roundtrip test_rfc0050_unicode_codecs test_json_buffers test_jit_assertion_exits test_compact_intern_pools test_argument_binding_storage test_bound_native_entry test_default_suffix test_extcall_kwonly_messages test_jit_calls test_jit_dyn_calls test_jit_unboxed_calls test_jit_scalar_leaf_calls test_jit_object_lanes test_jit_raise_exits test_native_call_scratch test_native_pin_retirement test_native_pin_pressure test_frame_recycling test_recursion_guard test_cross_thread_heap test_native_generator_pin_retirement test_jit_cells test_small_slot_storage test_pickle_callables test_weakref_basic; do
    WEAVEPY_JIT=1 "$binary" "tests/regrtest/$test.py" > "target/ascii-time-format-checks/$test-jit.txt" 2>&1
    WEAVEPY_JIT=0 "$binary" "tests/regrtest/$test.py" > "target/ascii-time-format-checks/$test-interp.txt" 2>&1
    WEAVEPY_JIT=1 "$binary" -X gil=0 "tests/regrtest/$test.py" > "target/ascii-time-format-checks/$test-gil0.txt" 2>&1
done
WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_bound_native_entry.py > target/ascii-time-format-checks/native-coverage.stdout.txt 2> target/ascii-time-format-checks/native-coverage.stderr.txt
WEAVEPY_JIT=1 "$binary" -c 'import _pydatetime as p; import _weave_datetime as n; assert p._format_time_parts is n.format_time_parts; assert p._format_time_parts(3, 4, 5, 1999, "milliseconds") == "03:04:05.001"; print("native formatter active")' > target/ascii-time-format-checks/native-format-coverage.txt 2>&1
printf 'done\n' > target/ascii-time-format-check-stage.txt

import importlib.util, json
spec = importlib.util.spec_from_file_location('call_control', '/Users/owencarey/Documents/weavefoundry/weavepy/target/native-dynamic-small-args-inputs-v2/cold/kw_override_16_omitted.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(20000)
for _ in range(6):
    module.bench(64)
last = module.bench(20000)
print(json.dumps(first))
print(json.dumps(last))

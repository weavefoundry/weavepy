# Format ordinary time fields without a Python format map

Direct reference is bc88:
bc88bf2b02abaaf0ad6a3d7427a17cab11f864a400a8161fc2effe5f396dd695.
Retained acceptance reference is bf2:
bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4.
The candidate preserves the experimental default-binding changes and adds
format_time_parts to _weave_datetime, called through a separate optional import
at the top of _pydatetime._format_time. Accept only exact integer fields in
ordinary time ranges and exact strings naming supported precision. Use a safe
15-byte ASCII buffer and checked UTF-8 conversion. All other values, callbacks,
and errors retain the complete original Python formatter. No unsafe code.

The standalone three-test prototype and 7,320-case CPython time.isoformat oracle
are correctness evidence, not VM performance measurements. The new Python test
must pass on CPython and bc88 in JIT, interpreter, and GIL-disabled modes. It
covers precisions, field boundaries, randomized valid fields, timezone/fold,
negative/huge/bool fields, unused custom fields, custom format/truth/floor
callbacks, integer/string subclasses, errors, and optional-helper rebinding.
Run 351 VM tests, the full C API package, strict lint/format, and no-JIT check.
After building the release CLI, freeze source/method/input/binary identities.
Run 96 targeted Python checks, assert the native helper is active in the loaded
module, and run the unchanged 275-check outside-sandbox compatibility suite.

Focused controls: six private precisions; three public time.isoformat cases;
UTC datetime.isoformat; custom-format, invalid-precision, and negative-field
fallbacks; ordinary str.format; and three unchanged binding controls retaining
earlier wide-signature losses and the keyword-default gain. Each of 17 cold
and 17 warm controls performs 20,000 calls. Independently check CPython results.
The unchanged sampler verifies all variants against CPython before/after warmup,
including GIL-disabled correctness, then keeps seven alternating pairs with one
declared stabilization cycle and unchanged per-binary-SHA frozen caches.

Run four stages sequentially: focused then full against bc88, followed by focused
then full against bf2. Each full stage collects 31 startup/import samples and
five alternating pairs of the unchanged 24-fixture census. Keep historical
21-row, 23-workload, and 24-process cohorts separate. Never infer a new bf2 result
by multiplying unrelated historical ratios. Retain every sample, loss, failure,
load observation, VM/swap snapshot, and identity.

Use run_serial_performance_gate.py outside the filesystem sandbox. Its lease
covers the entire load gate and child; inspect completion before each dependent
stage. The unchanged gate requires three 10-second observations with one- and
five-minute load averages at most half the CPU count, waiting up to 600 seconds
per attempt. No owned build/test/profile/install, runtime edit, or active-harness
edit may overlap a gate that can launch or a measurement. Keep every launched
sample regardless of later load. Preflight prototypes must be finished first.

Overall superiority to CPython remains unachieved. No universal, energy,
controlled build-time, portability, or native parallel-scaling claim follows.

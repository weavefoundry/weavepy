
target/release/weavepy-runtime-outlined-bound-entry:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100909c88 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound>:
100909c88:     	ldr	x8, [x3]
100909c8c:     	ldrb	w9, [x8, #0x1e0]
100909c90:     	tbnz	w9, #0x0, 0x100909cd8 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound+0x50>
100909c94:     	ldrb	w9, [x8, #0x1e1]
100909c98:     	cmp	w9, #0x1
100909c9c:     	b.eq	0x100909cd8 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound+0x50>
100909ca0:     	ldr	w9, [x8, #0x1d8]
100909ca4:     	cbnz	w9, 0x100909cd8 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound+0x50>
100909ca8:     	ldr	x9, [x2]
100909cac:     	ldr	x9, [x9, #0x68]
100909cb0:     	cbnz	x9, 0x100909cd8 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound+0x50>
100909cb4:     	ldrb	w9, [x8, #0x1e3]
100909cb8:     	tbnz	w9, #0x0, 0x100909cd8 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound+0x50>
100909cbc:     	ldrb	w9, [x8, #0x1e4]
100909cc0:     	tbnz	w9, #0x0, 0x100909cd8 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound+0x50>
100909cc4:     	ldrb	w9, [x8, #0x1e5]
100909cc8:     	tbnz	w9, #0x0, 0x100909cd8 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound+0x50>
100909ccc:     	ldr	w8, [x8, #0x1d0]
100909cd0:     	cmp	x5, x8
100909cd4:     	b.hs	0x100909ce4 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound+0x5c>
100909cd8:     	mov	x8, #-0x3               ; =-3
100909cdc:     	str	x8, [x0]
100909ce0:     	ret
100909ce4:     	mov	x5, x8
100909ce8:     	b	0x100909cec <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier222try_call_native_direct>

#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-early-bound-entry
reference=target/release/weavepy-runtime-jit-raise-call-spans
binary=target/release/weavepy-runtime-binder-flags
test -f "$base"
test -f "$reference"
test ! -e "$binary"
test ! -e target/binder-flags-build-stage.txt
printf '%s\n' "$base" > target/binder-flags-previous.txt
printf '%s\n' "$reference" > target/binder-flags-reference.txt
printf 'VM tests and static checks\n' > target/binder-flags-build-stage.txt
cargo fmt --all -- --check > target/binder-flags-format.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/binder-flags-vm-tests.txt 2>&1
cargo clippy --offline --locked -p weavepy-vm -p weavepy-jit --lib --tests -j 1 -- -D warnings > target/binder-flags-clippy.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/binder-flags-no-jit.txt 2>&1
printf 'release build\n' > target/binder-flags-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/binder-flags-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/binder-flags-source-snapshot --extra target/build_binder_flags.sh target/check_binder_flags.sh target/validate_binder_flags.sh target/inspect_binder_flags.py target/measure_binder_flags_focused.sh target/measure_binder_flags_full.sh target/summarize_binder_flags.py target/measure_verified_python_components_with_reference.py target/binder-flags-experiment-protocol.md > target/binder-flags-snapshot.txt 2>&1
printf 'done\n' > target/binder-flags-build-stage.txt

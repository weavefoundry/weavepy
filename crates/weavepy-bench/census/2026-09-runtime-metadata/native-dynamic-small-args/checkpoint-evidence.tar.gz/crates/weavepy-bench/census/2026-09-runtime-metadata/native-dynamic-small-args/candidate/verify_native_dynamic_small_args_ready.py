"""Require complete generic-call validation and unchanged measured identities."""
from pathlib import Path
import hashlib
import json
import re

def read(path):
    return json.loads(Path(path).read_text())
for group in read('target/native-dynamic-small-args-prebuild.json').values():
    for path, digest in group.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
env = read('target/native-dynamic-small-args-source-snapshot/environment.json')
for label in ['new', 'previous']:
    item = env['binaries'][label]
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256'], label
assert env['binaries']['previous']['sha256'] == '681043b9f62cbd4fdb3f73756ecdf8ac877c1923b6a509f11ff1128dc973443c'
assert hashlib.sha256(Path('target/release/weavepy-runtime-thin-value-storage').read_bytes()).hexdigest() == 'bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'
assert 'test result: ok. 352 passed' in Path('target/native-dynamic-small-args-vm-tests-02.txt').read_text()
text = Path('target/native-dynamic-small-args-capi-tests-01.txt').read_text()
assert 'test result: FAILED' not in text
assert sum(map(int, re.findall(r'test result: ok\. (\d+) passed', text))) == 156
for label in ['clippy-01', 'nojit-check']:
    assert 'Finished' in Path(f'target/native-dynamic-small-args-{label}.txt').read_text()
expected = 'dynamic argument storage: semantics and ownership ok\n'
for label in ['cpython', 'baseline-jit', 'baseline-interp', 'baseline-gil0']:
    assert Path(f'target/native-dynamic-small-args-oracle-{label}-complete.txt').read_text() == expected
assert Path('target/native-dynamic-small-args-check-stage.txt').read_text().strip() == 'done'
checks = Path('target/native-dynamic-small-args-checks')
for mode in ['jit', 'interp', 'gil0']:
    assert len(list(checks.glob(f'*-{mode}.txt'))) == 33
    assert (checks / f'test_dynamic_argument_storage-{mode}.txt').read_text() == expected
validation = read('target/native-dynamic-small-args-validation/validation.json')
assert len(validation) == 275 and all(r['passed'] for r in validation)
assert Path('target/native-dynamic-small-args-checks/native-format-coverage.txt').read_text() == 'native formatter active\n'
for folder in ['target/native-dynamic-small-args-baseline-coverage-v2', 'target/native-dynamic-small-args-checks/fixture-coverage']:
    coverage = read(folder + '/report.json')
    assert len(coverage['rows']) == 26
    for name, row in coverage['rows'].items():
        assert row['returncode'] == 0
        generic = name.startswith(('generic_pos_', 'generic_kw_', 'generic_method_', 'generic_object_')) and name not in ['generic_pos_32', 'generic_object_4']
        if generic:
            assert row['bench_compiled'] and row['stats']['generic dyn calls'] >= 30000, (folder, name)
        if name.startswith('compiled_alias_'):
            assert row['bench_compiled'] and row['stats']['native-to-native calls'] >= 30000, (folder, name)
assert 'generic dyn calls:' in Path('target/native-dynamic-small-args-checks/dynamic-coverage.stderr.txt').read_text()
print('All source/method identities, native checks, 99 targeted checks, and 275 compatibility checks verified.')

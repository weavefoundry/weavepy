"""Preserve the measured binder-storage experiment and all preparation failures."""
import hashlib,json
from pathlib import Path
parent=Path('crates/weavepy-bench/census/2026-09-runtime-metadata');out=parent/'argument-binding-flags'
assert not out.exists()
for g in ['focused','full']:
    assert Path('target/binder-flags-'+g+'/stage.txt').read_text().strip()=='done'
    assert json.loads(Path('target/binder-flags-'+g+'-load.json').read_text())['status']=='complete'
focused=json.loads(Path('target/binder-flags-focused/summary.json').read_text());full=json.loads(Path('target/binder-flags-full/summary.json').read_text())
out.mkdir();records=[]
def copy(src,dst):
    src=Path(src);p=out/dst;p.parent.mkdir(parents=True,exist_ok=True);b=src.read_bytes();p.write_bytes(b)
    records.append({'path':str(dst),'source':str(src),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
def folder(src,dst,recursive=False):
    src=Path(src)
    for p in sorted(src.rglob('*') if recursive else src.iterdir()):
        if p.is_file() and p.suffix in ['.py','.txt','.json','.md','.sh','.patch']:
            copy(p,str(Path(dst)/p.relative_to(src)))
for g in ['focused','full']:folder('target/binder-flags-'+g,g)
for g in ['calls','signatures','exceptions','cold-exceptions']:
    copy('target/binder-flags-focused/'+g+'/measurements.json','focused/'+g+'.json')
for g in ['checks','validation','extra-checks','coverage','signature-paths','signature-paths-v2','signature-paths-v3']:
    folder('target/binder-flags-'+g,'checks/'+g)
folder('target/argument-binder-flags-baseline-preflight','checks/baseline-preflight')
for g in ['measurement-inputs','v2-measurement-inputs','v3-measurement-inputs','signature-path-method']:
    folder('target/binder-flags-'+g,'methods/'+g)
for g in ['binder-flag-inputs','binder-flag-inputs-v2','binder-flag-inputs-v3']:
    folder('target/'+g,'inputs/'+g)
folder('target/bound-native-entry-inputs','inputs/original-entry-controls',True)
for p in sorted(Path('target').glob('binder-flags-*.txt')):copy(p,'logs/'+p.name)
for name in ['binder-flags-focused-load.json','binder-flags-full-load.json','binder-flags-prebuild-sources.json','performance_phase63_status.md','argument-binder-flags-baseline-preflight.txt']:
    copy('target/'+name,'conditions/'+name)
for name in ['environment.json','source-changes.diff','tests/regrtest/test_bound_native_entry.py','tests/regrtest/test_argument_binding_storage.py']:
    copy('target/binder-flags-source-snapshot/'+name,'candidate/'+name)
for name in ['candidate.patch','index.json']:
    copy('target/argument-binder-flags-draft/'+name,'draft/'+name)
copy(__file__,'methods/'+Path(__file__).name)
work=full['cohorts']['all_23_workloads_excluding_startup']['metrics']['jit']['ns']
hist=full['cohorts']['historical_21_including_startup']['metrics']['jit']
proc=full['cohorts']['all_processes_including_startup']['metrics']['jit']
lines=['# Inline argument-binding flags','','Status: **under refinement**. The overall performance goal remains unachieved.','',
'Candidate e5077bba stores flags for up to 16 argument slots inline and retains',
'a heap slice for larger signatures. The flag extent includes positional,',
'keyword-only, and variadic slots, without covering unused body locals. Separate',
'flags preserve internal Object::Unbound behavior. Argument movement, default',
'handling, duplicate/missing checks, raw keyword ownership, and error precedence',
'are unchanged. The candidate includes the prior post-binding native-entry path.',
'The executable is 44,290,720 bytes, unchanged from immediate predecessor95b.','',
'All 342 VM tests, formatting, Clippy, no-default-feature build, 63 targeted',
'release checks, 275 standard compatibility checks, five extra call/inspection/',
'copy suites, and original native-entry oracles pass. The new boundary test',
'covers inline and heap limits, large signatures, variadic/keyword-only slots,',
'excess defaults, errors, and many body locals. Its baseline preflight matches',
'CPython, retained539c, and 95b in all three checked modes.','',
'Path inspection corrected the new many-body-local control before timing. V1',
'supplied every argument and bypassed the binder. V2 omitted a trailing default',
'but still bypassed it, failing the explicit generic-call coverage assertion.',
'Both returned correct CPython values; keep the failed coverage result. V3',
'supplies a/d and omits b/c in the middle. It records 854 generic dynamic calls',
'in both binaries. The other nine new source hashes are unchanged. V1/v2 inputs,',
'methods, traces, and failure remain archived. No timing sample was replaced.','',
'The focused run has 28 cases and seven paired samples for seven variants:',
'both modes of the new candidate, immediate95b, retained539c, and CPython.',
'All exact values and isolated frozen-cache checks pass. The load precondition',
'qualified, and every later sample/load observation is retained. The table',
'reports JIT workload-time paired medians; lower is better. All CPU, process',
'wall, RSS, ranges, and paired samples for both modes are preserved in JSON.','',
'| Case | Time / 95b | Time / 539c | Time / CPython | Faster than 539c pairs |',
'| --- | ---: | ---: | ---: | ---: |']
for name,r in focused['rows'].items():
    lines.append(f"| {name} | {r['new_over_previous']['jit']['ns']:.4f} | {r['new_over_reference']['jit']['ns']:.4f} | {r['new_over_cpython']['jit']['ns']:.4f} | {r['pairs']['reference']['jit']['ns']['improved_pairs']}/7 |")
lines += ['',
'Several keyword-call medians improve about 2-3 percent relative to95b, but the',
'combined variadic/keyword-only/closure medians remain about 5-6 percent slower',
'than retained539c. Those earlier regressions are not resolved. The corrected',
'many-body-local workload timer beats CPython; one added control is not a full-',
'suite, process-memory, or universal win. Cold exceptions have no separate',
'workload CPU timer; their process CPU samples remain available. No measured',
'malloc-count reduction is claimed because no allocation-history profile ran.','',
'The full run retains all 24 unchanged fixtures with five paired samples and',
'nine startup/import controls with 31 pairs. Startup helper JIT is disabled.',
'Full-suite baseline is retained539c, so it measures the combined change.','',
f"The 23-workload JIT mean is {work['new_over_base']:.6f} of retained539c and",
f"{work['new_over_cpython']:.6f} of CPython, with {work['weavepy_wins']} of 23 time wins. The",
f"historical 21-fixture cohort is {hist['ns']['new_over_cpython']:.6f} of CPython, or",
f"{hist['ratio_of_medians_new_over_cpython']:.6f} using ratios of medians. Keep those cohorts distinct.",'',
f"All-24 process wall/CPU/RSS ratios to539c are {proc['wall_ns']['new_over_base']:.6f},",
f"{proc['cpu_ns']['new_over_base']:.6f}, and {proc['rss_bytes']['new_over_base']:.6f}. Peak RSS is",
f"{proc['rss_bytes']['new_over_cpython']:.6f} of CPython, with {proc['rss_bytes']['weavepy_wins']} wins.",'',
'The index identifies every selected artifact by SHA-256. Local executables,',
'frozen caches, and unselected intermediate outputs stay outside Git. These',
'results do not establish energy, controlled build-time, portability, or',
'free-threaded superiority. Any later outlining or memory-region experiment',
'is separate; neither is evidence for this candidate until actually measured.','']
text='\n'.join(lines)
for old,new in [('predecessor95b','predecessor 95b'),('immediate95b','immediate 95b'),('retained539c','retained 539c'),('to95b','to 95b'),('to539c','to 539c')]:text=text.replace(old,new)
(out/'REPORT.md').write_text(text);p=out/'REPORT.md';records.append({'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'index.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:assert hashlib.sha256((out/r['path']).read_bytes()).hexdigest()==r['sha256']
with (parent/'.gitignore').open('a') as f:
    f.write('\n# Inline binding flags, corrected probes, and complete results.\n')
    for p in sorted(out.rglob('*')):
        if p.is_file():f.write('!'+str(p.relative_to(parent))+'\n')
with (parent/'README.md').open('a') as f:
    f.write('\nThe [inline argument-binding flags experiment](argument-binding-flags/REPORT.md)\nreduces small-signature flag storage and preserves large signatures. All\ncorrectness gates pass, but the combined entry/storage change retains fallback\nregressions. Both predecessor comparisons, all original samples, and the failed\nprobe that bypassed binding are archived. The performance goal remains unachieved.\n')
print('Exported',len(records)+1,'files;',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes; every indexed SHA verified.')

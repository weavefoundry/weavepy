
types = [type("CompactInternType%d" % i, (), {}) for i in range(256)]
names = [cls.__name__ for cls in types]
def bench(n):
    total = 0
    for i in range(n):
        k = i & 255
        total += types[k].__name__ is names[k]
    return total

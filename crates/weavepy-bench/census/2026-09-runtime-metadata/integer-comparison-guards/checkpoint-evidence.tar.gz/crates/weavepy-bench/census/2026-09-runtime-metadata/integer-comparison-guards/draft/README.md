# Guarded opaque/integer comparisons

The assertion candidate's datetime trace still rejects _ymd2ord and field
validators with MixedArithTypes. Arithmetic already uses integer_operand_guard
and UnboxInt for an opaque value beside an integral peer; comparisons don't.
This draft reuses that existing exact-Object::Int guard at COMPARE_OP, after
all producer calls. Two opaque values and opaque/float pairs remain unchanged.
Bool objects, large integers, integer subclasses, and rich-comparison objects
miss the exact guard and resume comparison in the interpreter. Scalar bool
peers retain normal integral comparison behavior.

No new runtime helper, native layout, unsafe code, cache, or execution policy.
This initial draft doesn't fuse the producing call; that is a separate possible
optimization after correctness and measurements. It might make frequently
noninteger callbacks slower and may not unblock datetime's other barriers.

The two source copies include the currently applied assertion-exit changes.
Don't overwrite them with older source copies. Apply only after assertion
measurements and evidence preservation, with exact baseline hashes rechecked.
Before use, test all comparisons in both orders, exact integer boundaries,
bool/float/huge integers, subclasses/reflected methods, arbitrary rich-comparison
results and truth conversion, callback effects/exceptions, locals/tracebacks,
tracing, cold/warm fallback and recovery, and actual native guard coverage.
No test or performance result exists for this draft yet.

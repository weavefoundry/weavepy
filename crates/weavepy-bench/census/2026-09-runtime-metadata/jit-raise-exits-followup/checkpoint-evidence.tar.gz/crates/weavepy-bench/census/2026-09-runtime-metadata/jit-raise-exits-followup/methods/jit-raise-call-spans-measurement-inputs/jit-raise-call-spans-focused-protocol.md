# Corrected explicit raise exit measurements

This follows the rejected ae1560b2 prototype, whose full compatibility run
passed 274/275 checks and exposed nine I/O errors. That binary and all original
failures remain archived locally. The corrected candidate is
`target/release/weavepy-runtime-jit-raise-call-spans`; its build snapshot records
the exact binary and source checksums. Compare against checkpoint binary
8899e367 and CPython 3.14.7, never against the faulty prototype as the primary
performance baseline. Require all expanded correctness checks first.

Measure the same twelve predeclared warm cases: integer, float, and list
loops with input validation and matched ordinary controls; scalar calls with
and without validation; and exception rates of zero, 1, 50, and 100 percent.
Add all four exception cases without in-process warmup so compilation and
retirement costs remain visible. The sixteen cases are fixed before timing.
Use seven paired samples in baseline/candidate JIT and interpreter modes plus
CPython, alternating order. Discard the first external cache-warming cycle;
keep every subsequent wall-time, CPU-time, and peak-RSS sample. Verify values
before and after warming and verify GIL-disabled candidate results.

Freeze separate caches by binary hash and require their bytes to remain
unchanged throughout measurement. Require one- and five-minute load averages
at most 4 for three observations ten seconds apart, waiting no more than 600
seconds. Gate expiry means no samples start. Once running, keep all samples
and load observations, even if load rises. Record VM and swap context before
and after the run. No sample filtering or automatic retries.

Do not run builds, other tests, or profiles, or edit runtime sources or active
measurement inputs during timing. These are local observations and cannot
establish universal speed, memory, or energy superiority over CPython.

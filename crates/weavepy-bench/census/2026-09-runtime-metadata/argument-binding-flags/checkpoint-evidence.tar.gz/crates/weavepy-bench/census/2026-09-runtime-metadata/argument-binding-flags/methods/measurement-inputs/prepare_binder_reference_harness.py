"""Prepare a separate two-reference harness without changing active methods."""
from pathlib import Path
src=Path('target/measure_verified_python_components.py').read_text()
src=src.replace('p.add_argument(\'--previous\')',"p.add_argument('--previous')\np.add_argument('--reference', required=True)")
old="if a.previous:\n    variants[:0] = [('previous_jit', a.previous, '1'), ('previous_interp', a.previous, '0')]"
new=old+"\nvariants[:0] = [('reference_jit', a.reference, '1'), ('reference_interp', a.reference, '0')]"
assert old in src;src=src.replace(old,new)
old="    save()\n    print(name, row.get('previous_comparisons'), row['cpython_comparisons'], flush=True)"
new="    row['reference_comparisons'] = {mode: bench['relative_metrics'](row['samples'][mode], row['samples']['reference_' + mode]) for mode in ['jit', 'interp']}\n"+old
assert old in src;src=src.replace(old,new)
p=Path('target/measure_verified_python_components_with_reference.py');assert not p.exists();p.write_text(src)

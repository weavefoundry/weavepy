#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-ascii-time-format
binary=target/release/weavepy-runtime-native-dynamic-small-args
test ! -e "$binary"
test ! -e target/native-dynamic-small-args-build-stage.txt
cargo fmt --all -- --check > target/native-dynamic-small-args-format.txt 2>&1
python3.14 target/freeze_native_dynamic_small_args_sources.py
printf 'release build\n' > target/native-dynamic-small-args-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/native-dynamic-small-args-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/native-dynamic-small-args-source-snapshot --extra target/build_native_dynamic_small_args.sh target/check_native_dynamic_small_args.sh target/validate_native_dynamic_small_args.sh target/measure_native_dynamic_small_args_focused.sh target/measure_native_dynamic_small_args_full.sh target/measure_verified_python_components.py target/native-dynamic-small-args-protocol.md target/verify_native_dynamic_small_args_ready.py target/freeze_native_dynamic_small_args_sources.py target/summarize_native_dynamic_small_args.py > target/native-dynamic-small-args-snapshot.txt 2>&1
printf 'done\n' > target/native-dynamic-small-args-build-stage.txt

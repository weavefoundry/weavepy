#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-thin-value-storage
binary=target/release/weavepy-runtime-borrowed-defaults
test ! -e "$binary"
test ! -e target/borrowed-defaults-build-stage.txt
cargo fmt --all -- --check > target/borrowed-defaults-format.txt 2>&1
python3.14 target/freeze_borrowed_defaults_sources.py
printf 'release build\n' > target/borrowed-defaults-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/borrowed-defaults-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/borrowed-defaults-source-snapshot --extra target/build_borrowed_defaults.sh target/check_borrowed_defaults.sh target/validate_borrowed_defaults.sh target/measure_borrowed_defaults_focused.sh target/measure_borrowed_defaults_full.sh target/measure_verified_python_components.py target/borrowed-defaults-protocol.md target/verify_borrowed_defaults_ready.py target/freeze_borrowed_defaults_sources.py target/summarize_borrowed_defaults.py > target/borrowed-defaults-snapshot.txt 2>&1
printf 'done\n' > target/borrowed-defaults-build-stage.txt

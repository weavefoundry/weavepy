"""Summarize every focused early-exclusion sample, including regressions."""
import hashlib,json,statistics
from pathlib import Path
root=Path('target/early-bound-entry-focused')
assert not (root/'summary.json').exists()
summary={'purpose':__doc__,'groups':{},'rows':{}}
ids=None
for group,count in [('calls',10),('exceptions',4),('cold-exceptions',4)]:
    p=root/group/'measurements.json';data=json.loads(p.read_text())
    assert len(data['rows'])==count
    new_ids={k:v['sha256'] for k,v in data['binaries'].items()}
    if ids is None: ids=new_ids
    assert ids==new_ids
    summary['groups'][group]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'samples':data['samples'],'cold_workload':data['cold_workload']}
    for name,row in data['rows'].items():
        assert row['frozen_cache']['unchanged']
        assert all(len(samples)==7 for samples in row['samples'].values())
        values=data['verification'][name]
        assert all(v['returncode']==0 and v['stdout']==values['cpython']['stdout'] for v in values.values())
        pairs={}
        for mode in ['jit','interp']:
            pairs[mode]={}
            for metric in row['previous_comparisons'][mode]:
                ratios=[a[metric]/b[metric] for a,b in zip(row['samples'][mode],row['samples']['previous_'+mode])]
                pairs[mode][metric]={'ratios':ratios,'median':statistics.median(ratios),'range':[min(ratios),max(ratios)],'improved_pairs':sum(r<1 for r in ratios)}
        summary['rows'][group+'/'+name]={'new_over_previous':row['previous_comparisons'],'new_over_cpython':row['cpython_comparisons'],'pairs':pairs}
summary['binaries']=ids
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('All 18 cases, values, frozen caches, and 7 samples per variant verified.')
for name,r in summary['rows'].items():
    print(name,'JIT time/base',r['new_over_previous']['jit']['ns'],'time/CPython',r['new_over_cpython']['jit']['ns'])

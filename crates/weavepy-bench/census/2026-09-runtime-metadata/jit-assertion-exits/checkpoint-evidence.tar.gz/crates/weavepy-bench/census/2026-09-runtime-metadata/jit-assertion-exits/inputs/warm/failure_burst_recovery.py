def leaf(value):
    assert value >= 0, f"negative value {value}"
    return value * 3 + 1
def wrapper(value):
    return leaf(value) + 2
def bench(n):
    total = 0
    for _ in range(100):
        try:
            total += wrapper(-1)
        except AssertionError as error:
            total += len(error.args[0])
    for i in range(n):
        total += wrapper(i)
    return total


import marshal
import sys
original = [("marshal name / %d / " % i) + "x" * 128 for i in range(256)]
canonical = [sys.intern(text) for text in original]
texts = canonical if False else [text.encode().decode() for text in canonical]
def bench(n):
    total = 0
    for i in range(n):
        encoded = marshal.dumps(texts[i & 255], 4)
        total += len(encoded)
    return total

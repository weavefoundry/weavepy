from pathlib import Path
import re

for crate in ['weavepy-vm', 'weavepy-capi', 'weavepy-cli']:
    for folder in ['src', 'tests']:
        for p in (Path('crates') / crate / folder).rglob('*.rs'):
            if p.name == 'shared_value.rs':
                continue
            s = p.read_text()
            prefix = 'crate' if crate == 'weavepy-vm' else 'weavepy_vm'
            module = prefix+'::shared_value::'
            positions = [m.start() for m in re.finditer(r'#\[cfg\(test\)\]\s*mod ', s)]
            test_start = min(positions) if positions else len(s)
            names = []
            for name in ['SharedStr', 'SharedSlice', 'ThinArc', 'ThinWeak', 'WeakStr', 'WeakSlice']:
                # Keep test-only references qualified to avoid production imports.
                code = '\n'.join(line for line in s[:test_start].splitlines() if not line.lstrip().startswith('//'))
                if module+name in code:
                    names.append(name)
            if not names:
                continue
            for name in names:
                s = s.replace(module+name, name)
            first_use = re.search(r'^use ', s, re.M)
            assert first_use, p
            declaration = 'use '+module+'{'+', '.join(names)+'};\n'
            s = s[:first_use.start()] + declaration + s[first_use.start():]
            p.write_text(s)

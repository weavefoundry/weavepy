import gc
import sys
import weakref

capture = False
seen = []
calls = []
fail_at = -1
flag = 3
mutate = False

class Stop(Exception):
    pass

class Callback:
    def __call__(self, value):
        global flag
        calls.append(value)
        if capture:
            seen.append(sys._getframe(1))
        if mutate and value == 4:
            flag = 100
        if value == fail_at:
            raise Stop(value)
        return value

callback = Callback()

def driver(n):
    total = 0
    for i in range(n):
        total += callback(i)
    return total

def changing_driver(n):
    total = 0
    for i in range(n):
        total += callback(i)
        total += flag
    return total

for _ in range(60):
    assert driver(10) == 45
    assert changing_driver(10) == 75
calls.clear()
assert driver(200) == 19900
assert calls == list(range(200))

capture = True
seen.clear()
assert driver(10) == 45
assert len(seen) == 10
assert all(frame.f_code is driver.__code__ for frame in seen)
held = list(seen)
capture = False
for _ in range(10):
    assert changing_driver(10) == 75
assert all(frame.f_code is driver.__code__ for frame in held)
assert all(frame.f_code.co_filename == driver.__code__.co_filename for frame in held)
held.clear()
seen.clear()

calls.clear()
fail_at = 4
try:
    driver(10)
except Stop as error:
    assert error.args == (4,)
else:
    raise AssertionError("callback exception was lost")
assert calls == [0, 1, 2, 3, 4]
fail_at = -1
calls.clear()
assert driver(10) == 45
assert calls == list(range(10))

calls.clear()
mutate = True
assert changing_driver(10) == 657
assert calls == list(range(10))
mutate = False
flag = 3

class Payload:
    pass

refs = []
class Forward:
    def __call__(self, value):
        return value
forward = Forward()

def identity(value):
    return forward(value)

for _ in range(60):
    value = Payload()
    refs.append(weakref.ref(value))
    assert identity(value) is value
    del value
gc.collect()
assert all(ref() is None for ref in refs)

class Nested:
    def __call__(self, n):
        return driver(n)
nested = Nested()

def outer(n):
    total = 0
    for i in range(n):
        total += nested(5)
    return total

for _ in range(60):
    assert outer(10) == 100
calls.clear()
assert outer(10) == 100
assert calls == list(range(5)) * 10
print("native activation shell reuse: semantics and ownership ok")

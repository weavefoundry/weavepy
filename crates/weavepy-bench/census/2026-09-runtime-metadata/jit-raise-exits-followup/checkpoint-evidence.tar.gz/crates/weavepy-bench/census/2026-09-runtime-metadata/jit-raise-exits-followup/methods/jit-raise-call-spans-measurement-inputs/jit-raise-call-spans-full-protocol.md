# Complete raise-exit controls

Compare baseline 8899e367 and the corrected candidate identified in the call-span build snapshot in both execution modes plus
CPython 3.14.7. Require full correctness and focused measurements first.
Measure nine startup/import cases with 31 paired samples and every standard
fixture at its unchanged work parameter with five paired samples. Keep all
results, including regressions, and separate caches by binary checksum.

Report the original 21-fixture timing cohort (startup included, three
accelerator rows excluded), the complete 23-workload cohort (startup excluded,
all accelerator rows included), full-process wall/CPU time and peak RSS, and
each startup case. Preserve both ratio-of-medians and median-of-paired-ratios
for the historical cohort; use paired ratios for incremental comparisons.

Use the same strict load gate as the focused protocol: one- and five-minute
averages at most 4, three consecutive observations ten seconds apart, a
600-second maximum wait. Keep every subsequent sample even if load rises.
If the gate expires, no measurements start. Do not silently relax it or retry
measurements. Record VM statistics and swap before and after the run.

No concurrent builds, tests, profiles, source edits, or active harness edits.
This measures the local host and these programs; energy, controlled build
latency, portability, and universal performance superiority remain unproven.

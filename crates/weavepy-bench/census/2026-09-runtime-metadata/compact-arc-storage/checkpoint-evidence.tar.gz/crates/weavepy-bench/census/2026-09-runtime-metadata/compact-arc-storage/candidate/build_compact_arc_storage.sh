#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-thin-value-storage
binary=target/release/weavepy-runtime-compact-arc-storage
test ! -e "$binary"
test ! -e target/compact-arc-storage-build-stage.txt
cargo fmt --all -- --check > target/compact-arc-storage-format.txt 2>&1
python3.14 target/freeze_compact_arc_storage_sources.py
printf 'release build\n' > target/compact-arc-storage-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/compact-arc-storage-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/compact-arc-storage-source-snapshot --extra target/build_compact_arc_storage.sh target/check_compact_arc_storage.sh target/validate_compact_arc_storage.sh target/check_compact_arc_storage_extra.py target/measure_compact_arc_storage_focused.sh target/measure_compact_arc_storage_full.sh target/measure_verified_python_components.py target/compact-arc-storage-protocol.md target/verify_compact_arc_storage_ready.py target/freeze_compact_arc_storage_sources.py target/summarize_compact_arc_storage.py > target/compact-arc-storage-snapshot.txt 2>&1
printf 'done\n' > target/compact-arc-storage-build-stage.txt

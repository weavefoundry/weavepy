import os
values = tuple("default-%d-" % i + "shared-text" * 3 for i in range(4))
provided = "provided-" + "string" * 3
def target(a0, a1, a2, a3):
    return a3
target.__defaults__ = values
def bench(n):
    total = 0
    for _ in range(n):
        total += len(target(provided, provided, provided, provided))
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

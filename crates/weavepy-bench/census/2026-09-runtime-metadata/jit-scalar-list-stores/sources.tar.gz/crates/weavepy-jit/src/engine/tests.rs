//! Scalar-leaf certification excludes helpers and nonlocal effects.
use super::is_scalar_leaf;
use crate::ir::{ArithKind, TBlock, TFunc, TOp, TStmt, TTerm};
use crate::value::JitType;

fn function(ops: &[TOp]) -> TFunc {
    TFunc {
        n_locals: 2,
        local_types: vec![Some(JitType::Int), Some(JitType::Int)],
        livein_locals: vec![0, 1],
        max_stack: 2,
        entry_block: 0,
        global_guards: vec![],
        range_loops: vec![],
        list_loops: vec![],
        iter_loops: vec![],
        comp_saved: vec![],
        resume_entries: vec![],
        callee_spans: vec![],
        len_spans: vec![],
        method_spans: vec![],
        attr_sites: vec![],
        method_sites: vec![],
        str_method_sites: vec![],
        str_method_spans: vec![],
        math_guards: vec![],
        math_spans: vec![],
        null_spans: vec![],
        osr_entries: vec![],
        max_call_args: 0,
        ret_lane: Some(JitType::Int),
        ret_none: false,
        blocks: vec![TBlock {
            entry_stack: vec![],
            stmts: ops
                .iter()
                .enumerate()
                .map(|(pc, &op)| TStmt { pc: pc as u32, op })
                .collect(),
            term: TTerm::Return,
        }],
    }
}

#[test]
fn scalar_leaf_allowlist_is_conservative() {
    let pure = function(&[
        TOp::LoadLocal(0),
        TOp::LoadLocal(1),
        TOp::IntArith(ArithKind::Add),
    ]);
    assert!(is_scalar_leaf(&pure));
    let mut changed = pure.clone();
    changed.blocks.push(changed.blocks[0].clone());
    assert!(!is_scalar_leaf(&changed));
    let mut changed = pure.clone();
    changed.local_types[0] = Some(JitType::Obj);
    assert!(!is_scalar_leaf(&changed));
    let mut changed = pure.clone();
    changed.ret_lane = Some(JitType::Obj);
    assert!(!is_scalar_leaf(&changed));
    let mut changed = pure.clone();
    changed.blocks[0].stmts.resize(
        65,
        TStmt {
            pc: 0,
            op: TOp::Pop,
        },
    );
    assert!(!is_scalar_leaf(&changed));
    for op in [
        TOp::FloatArith(ArithKind::FloorDiv),
        TOp::FloatArith(ArithKind::Mod),
        TOp::UnboxInt { depth: 0 },
        TOp::PushConstStr { idx: 0 },
        TOp::PushConstTuple { idx: 0 },
        TOp::TupleLen,
        TOp::CallDyn {
            argc: 0,
            kwc: 0,
            names: 0,
            int_result: true,
        },
        TOp::ListLen,
        TOp::DynAttrGet { name: 0 },
        TOp::ObjGetItemInt,
    ] {
        assert!(!is_scalar_leaf(&function(&[op])), "{op:?}");
    }
}

#[test]
fn scalar_leaf_returns_and_deopts_with_no_embedder_context() {
    use crate::runtime::{JitFrame, JitStatus, SlotTag};
    let tfunc = function(&[
        TOp::LoadLocal(0),
        TOp::LoadLocal(1),
        TOp::IntArith(ArithKind::Add),
    ]);
    let mut engine = super::JitEngine::new().expect("host ISA");
    let cf = engine.compile_tfunc(&tfunc).expect("compile scalar leaf");
    assert!(cf.is_scalar_leaf());
    for (a, b, expected) in [
        (40, 2, JitStatus::Returned),
        (i64::MAX, 1, JitStatus::Deopt),
    ] {
        let mut locals = [a as u64, b as u64];
        let mut spill = [0u64; 3];
        let mut tags = [0u32; 3];
        let mut local_written = vec![0u32; locals.len()];
        let mut frame = JitFrame {
            locals: locals.as_mut_ptr(),
            local_written: local_written.as_mut_ptr(),
            n_locals: 2,
            entry_pc: 0,
            ret_bits: 0,
            ret_tag: 0,
            deopt_pc: 0,
            stack_spill: spill.as_mut_ptr(),
            stack_tags: tags.as_mut_ptr(),
            stack_len: 0,
            stack_cap: 3,
            ctx: std::ptr::null_mut(),
            call_args: std::ptr::null_mut(),
            call_tags: std::ptr::null_mut(),
        };
        // SAFETY: the certified scalar leaf needs no helper context, all
        // buffers fit its metadata, and the owning engine is still alive.
        assert_eq!(unsafe { cf.enter(&raw mut frame) }, expected);
        if expected == JitStatus::Returned {
            assert_eq!(frame.ret_bits, 42);
            assert_eq!(frame.ret_tag, SlotTag::Int as u32);
        } else {
            assert_eq!(frame.deopt_pc, 2);
            assert_eq!(frame.stack_len, 2);
            assert_eq!(&spill[..2], &[a as u64, b as u64]);
            assert_eq!(&tags[..2], &[SlotTag::Int as u32; 2]);
        }
    }
}

#[test]
fn explicit_exit_preserves_operands_and_updated_locals() {
    use crate::runtime::{JitFrame, JitStatus, SlotTag};
    let mut tf = function(&[
        TOp::LoadLocal(0),
        TOp::PushConstInt(99),
        TOp::StoreLocal(0),
        TOp::LoadLocal(1),
    ]);
    tf.blocks[0].term = TTerm::Deopt { pc: 17 };
    assert!(!is_scalar_leaf(&tf));
    let mut engine = super::JitEngine::new().expect("host ISA");
    let compiled = engine.compile_tfunc(&tf).expect("compile explicit exit");
    let mut locals = [41u64, 7];
    let mut spill = [0u64; 3];
    let mut tags = [0u32; 3];
    let mut local_written = vec![0u32; locals.len()];
    let mut frame = JitFrame {
        locals: locals.as_mut_ptr(),
        local_written: local_written.as_mut_ptr(),
        n_locals: 2,
        entry_pc: 0,
        ret_bits: 0,
        ret_tag: 0,
        deopt_pc: 0,
        stack_spill: spill.as_mut_ptr(),
        stack_tags: tags.as_mut_ptr(),
        stack_len: 0,
        stack_cap: 3,
        ctx: std::ptr::null_mut(),
        call_args: std::ptr::null_mut(),
        call_tags: std::ptr::null_mut(),
    };
    // SAFETY: this IR uses only scalar loads/stores and an explicit exit,
    // needs no helpers, and all buffers fit the live compiled metadata.
    assert_eq!(unsafe { compiled.enter(&raw mut frame) }, JitStatus::Deopt);
    assert_eq!(frame.deopt_pc, 17);
    assert_eq!(frame.stack_len, 2);
    assert_eq!(&spill[..2], &[41, 7]);
    assert_eq!(&tags[..2], &[SlotTag::Int as u32; 2]);
    assert_eq!(locals, [99, 7]);
}

fn oversized_function(kind: ArithKind) -> TFunc {
    // Distinct dead constants grow compiler IR without requiring helpers or
    // performing extra work when the resulting native function is entered.
    let mut ops = Vec::new();
    for value in 0..=super::MAX_RETAINED_IR_INSTRUCTIONS {
        ops.push(TOp::PushConstInt(value as i64));
        ops.push(TOp::Pop);
    }
    ops.extend([TOp::LoadLocal(0), TOp::LoadLocal(1), TOp::IntArith(kind)]);
    function(&ops)
}

fn check_scalar_entry(compiled: &super::CompiledFrame, a: i64, b: i64, expected: Result<i64, u32>) {
    use crate::runtime::{JitFrame, JitStatus, SlotTag};
    let mut locals = [a as u64, b as u64];
    let mut spill = [0u64; 3];
    let mut tags = [0u32; 3];
    let mut local_written = vec![0u32; locals.len()];
    let mut frame = JitFrame {
        locals: locals.as_mut_ptr(),
        local_written: local_written.as_mut_ptr(),
        n_locals: 2,
        entry_pc: 0,
        ret_bits: 0,
        ret_tag: 0,
        deopt_pc: 0,
        stack_spill: spill.as_mut_ptr(),
        stack_tags: tags.as_mut_ptr(),
        stack_len: 0,
        stack_cap: 3,
        ctx: std::ptr::null_mut(),
        call_args: std::ptr::null_mut(),
        call_tags: std::ptr::null_mut(),
    };
    // SAFETY: the tests keep the owning engine alive. These functions use only
    // scalar operations with no helpers, and all exchange buffers fit their IR.
    let status = unsafe { compiled.enter(&raw mut frame) };
    match expected {
        Ok(value) => {
            assert_eq!(status, JitStatus::Returned);
            assert_eq!(frame.ret_bits, value as u64);
            assert_eq!(frame.ret_tag, SlotTag::Int as u32);
        }
        Err(pc) => {
            assert_eq!(status, JitStatus::Deopt);
            assert_eq!(frame.deopt_pc, pc);
            assert_eq!(frame.stack_len, 2);
            assert_eq!(&spill[..2], &[a as u64, b as u64]);
            assert_eq!(&tags[..2], &[SlotTag::Int as u32; 2]);
        }
    }
    assert_eq!(locals, [a as u64, b as u64]);
}

#[test]
fn compiler_scratch_reset_preserves_old_code_and_exact_exits() {
    let mut engine = super::JitEngine::new().expect("host ISA");
    let small = |kind| function(&[TOp::LoadLocal(0), TOp::LoadLocal(1), TOp::IntArith(kind)]);
    let first = engine.compile_tfunc(&small(ArithKind::Add)).unwrap();
    let large_ir = oversized_function(ArithKind::Sub);
    let large_pc = large_ir.blocks[0].stmts.last().unwrap().pc;
    let large = engine.compile_tfunc(&large_ir).unwrap();
    let last = engine.compile_tfunc(&small(ArithKind::Mul)).unwrap();

    // Enter every function after subsequent compilations have recycled the
    // contexts. Distinct results also catch an accidentally replaced entry.
    for _ in 0..3 {
        check_scalar_entry(&first, 40, 2, Ok(42));
        check_scalar_entry(&large, 40, 2, Ok(38));
        check_scalar_entry(&last, 40, 2, Ok(80));
        check_scalar_entry(&first, i64::MAX, 1, Err(2));
        check_scalar_entry(&large, i64::MIN, 1, Err(large_pc));
        check_scalar_entry(&last, i64::MAX, 2, Err(2));
    }
}

#[test]
fn failed_definition_clears_scratch_and_preserves_old_code() {
    let mut engine = super::JitEngine::new().expect("host ISA");
    let small = function(&[
        TOp::LoadLocal(0),
        TOp::LoadLocal(1),
        TOp::IntArith(ArithKind::Add),
    ]);
    let first = engine.compile_tfunc(&small).unwrap();
    // Reuse an already-defined symbol to make module definition fail after
    // lowering a large body. No invalid IR or platform-specific ISA is needed.
    engine.next_id = 0;
    let large_ir = oversized_function(ArithKind::Sub);
    assert!(matches!(
        engine.compile_tfunc(&large_ir),
        Err(crate::analyze::JitVerdict::NotConverged)
    ));
    assert_eq!(engine.ctx.func.dfg.num_insts(), 0);
    assert!(engine.ctx.compiled_code().is_none());
    check_scalar_entry(&first, 40, 2, Ok(42));
    check_scalar_entry(&first, i64::MAX, 1, Err(2));

    let recovered = engine.compile_tfunc(&large_ir).unwrap();
    let last = engine.compile_tfunc(&small).unwrap();
    check_scalar_entry(&recovered, 40, 2, Ok(38));
    check_scalar_entry(&last, 40, 2, Ok(42));
    check_scalar_entry(&first, 40, 2, Ok(42));
}

fn run_local_exit_probe(
    compiled: &super::CompiledFrame,
    entry_pc: u32,
    locals: &mut [u64],
    spill: &mut [u64],
    tags: &mut [u32],
    expected: crate::runtime::JitStatus,
) -> crate::runtime::JitFrame {
    use crate::runtime::JitFrame;
    assert_eq!(locals.len(), compiled.n_locals as usize);
    assert!(spill.len() >= compiled.max_stack as usize);
    assert!(tags.len() >= spill.len());
    let mut local_written = vec![0u32; locals.len()];
    let mut frame = JitFrame {
        locals: locals.as_mut_ptr(),
        local_written: local_written.as_mut_ptr(),
        n_locals: compiled.n_locals,
        entry_pc,
        ret_bits: 0,
        ret_tag: 0,
        deopt_pc: 0,
        stack_spill: spill.as_mut_ptr(),
        stack_tags: tags.as_mut_ptr(),
        stack_len: 0,
        stack_cap: spill.len() as u32,
        ctx: std::ptr::null_mut(),
        call_args: std::ptr::null_mut(),
        call_tags: std::ptr::null_mut(),
    };
    // SAFETY: these tests retain the owning engine and use only local scalar
    // operations and explicit exits. Opaque pin bits are copied, never read
    // through a helper. All buffers fit the compiled metadata and stay alive.
    assert_eq!(unsafe { compiled.enter(&raw mut frame) }, expected);
    frame.local_written = std::ptr::null_mut();
    frame
}

#[test]
fn arithmetic_exits_preserve_each_pc_and_assignment_point() {
    use crate::runtime::{JitStatus, SlotTag};
    let tf = function(&[
        TOp::LoadLocal(0),
        TOp::PushConstInt(1),
        TOp::IntArith(ArithKind::Add),
        TOp::StoreLocal(0),
        TOp::LoadLocal(1),
        TOp::PushConstInt(2),
        TOp::IntArith(ArithKind::Add),
        TOp::StoreLocal(1),
        TOp::LoadLocal(0),
        TOp::LoadLocal(1),
        TOp::IntArith(ArithKind::Add),
    ]);
    let mut engine = super::JitEngine::new().expect("host ISA");
    let cf = engine.compile_tfunc(&tf).expect("compile arithmetic exits");
    for (input, pc, expected_locals, expected_spill) in [
        ([i64::MAX, 7], 2, [i64::MAX, 7], [i64::MAX, 1]),
        ([5, i64::MAX], 6, [6, i64::MAX], [i64::MAX, 2]),
        (
            [i64::MAX - 10, 9],
            10,
            [i64::MAX - 9, 11],
            [i64::MAX - 9, 11],
        ),
    ] {
        let mut locals = input.map(|v| v as u64);
        let mut spill = [0; 2];
        let mut tags = [u32::MAX; 2];
        let frame =
            run_local_exit_probe(&cf, 0, &mut locals, &mut spill, &mut tags, JitStatus::Deopt);
        assert_eq!(frame.deopt_pc, pc);
        assert_eq!(frame.stack_len, 2);
        assert_eq!(locals, expected_locals.map(|v| v as u64));
        assert_eq!(spill, expected_spill.map(|v| v as u64));
        assert_eq!(tags, [SlotTag::Int as u32; 2]);
    }
    let mut locals = [5, 7];
    let frame = run_local_exit_probe(
        &cf,
        0,
        &mut locals,
        &mut [0; 2],
        &mut [0; 2],
        JitStatus::Returned,
    );
    // Normal returns expose the result without writing back dead locals.
    assert_eq!(locals, [5, 7]);
    assert_eq!(frame.ret_bits, 15);
    assert_eq!(frame.ret_tag, SlotTag::Int as u32);
}

#[test]
fn branch_exits_preserve_mixed_snapshots_and_distinct_locals() {
    use crate::runtime::{JitStatus, SlotTag};
    let mut tf = function(&[TOp::LoadLocal(0)]);
    tf.local_types[1] = Some(JitType::Float);
    tf.blocks[0].term = TTerm::BranchFalse {
        target: 2,
        fallthrough: 1,
    };
    for (value, operand, pc) in [(99, TOp::LoadLocal(0), 17), (-7, TOp::PushConstInt(6), 29)] {
        let mut block = function(&[
            TOp::PushConstInt(value),
            TOp::StoreLocal(0),
            TOp::LoadLocal(1),
            operand,
        ])
        .blocks
        .remove(0);
        block.term = TTerm::Deopt { pc };
        tf.blocks.push(block);
    }
    let mut engine = super::JitEngine::new().expect("host ISA");
    let cf = engine.compile_tfunc(&tf).expect("compile mixed exits");
    for (condition, pc, local, operand) in [(1, 17, 99_i64, 99), (0, 29, -7, 6)] {
        let bits = 1.25_f64.to_bits();
        let mut locals = [condition, bits];
        let mut spill = [0; 2];
        let mut tags = [u32::MAX; 2];
        let frame =
            run_local_exit_probe(&cf, 0, &mut locals, &mut spill, &mut tags, JitStatus::Deopt);
        assert_eq!(frame.deopt_pc, pc);
        assert_eq!(frame.stack_len, 2);
        assert_eq!(locals, [local as u64, bits]);
        assert_eq!(spill, [bits, operand]);
        assert_eq!(tags, [SlotTag::Float as u32, SlotTag::Int as u32]);
    }
}

#[test]
fn exit_tags_distinguish_bool_int_and_opaque_pin_bits() {
    use crate::runtime::{JitStatus, SlotTag};
    let mut tf = function(&[TOp::LoadLocal(0)]);
    tf.n_locals = 3;
    tf.local_types = vec![Some(JitType::Int), Some(JitType::Bool), Some(JitType::Obj)];
    tf.livein_locals = vec![0, 1, 2];
    tf.blocks[0].term = TTerm::BranchFalse {
        target: 2,
        fallthrough: 1,
    };
    let mut bool_exit = function(&[TOp::LoadLocal(1)]).blocks.remove(0);
    bool_exit.term = TTerm::Deopt { pc: 31 };
    tf.blocks.push(bool_exit);
    let mut choose = function(&[TOp::LoadLocal(1)]).blocks.remove(0);
    choose.term = TTerm::BranchFalse {
        target: 3,
        fallthrough: 4,
    };
    tf.blocks.push(choose);
    for (slot, pc) in [(0, 41), (2, 51)] {
        let mut block = function(&[TOp::LoadLocal(slot)]).blocks.remove(0);
        block.term = TTerm::Deopt { pc };
        tf.blocks.push(block);
    }
    let mut engine = super::JitEngine::new().expect("host ISA");
    let cf = engine.compile_tfunc(&tf).expect("compile tagged exits");
    for (input, pc, operand, tag) in [
        ([1, 1, 7], 31, 1, SlotTag::Bool),
        ([0, 0, 7], 41, 0, SlotTag::Int),
        ([0, 1, 7], 51, 7, SlotTag::ObjPin),
    ] {
        let mut locals = input;
        let mut spill = [0; 2];
        let mut tags = [u32::MAX; 2];
        let frame =
            run_local_exit_probe(&cf, 0, &mut locals, &mut spill, &mut tags, JitStatus::Deopt);
        assert_eq!(frame.deopt_pc, pc);
        assert_eq!(frame.stack_len, 1);
        assert_eq!(locals, input);
        assert_eq!(spill[0], operand);
        assert_eq!(tags[0], tag as u32);
    }
}

#[test]
fn loop_exits_preserve_iteration_values_from_normal_and_osr_entries() {
    use crate::ir::{CmpKind, OsrEntry};
    use crate::runtime::{JitStatus, SlotTag};
    let mut tf = function(&[]);
    tf.n_locals = 3;
    tf.local_types = vec![Some(JitType::Int); 3];
    tf.livein_locals = vec![0, 1, 2];
    tf.blocks[0].term = TTerm::Jump(1);
    let mut header = function(&[
        TOp::LoadLocal(0),
        TOp::PushConstInt(0),
        TOp::IntCmp(CmpKind::Gt),
    ])
    .blocks
    .remove(0);
    header.term = TTerm::BranchFalse {
        target: 3,
        fallthrough: 2,
    };
    tf.blocks.push(header);
    let mut body = function(&[
        TOp::LoadLocal(1),
        TOp::LoadLocal(2),
        TOp::IntArith(ArithKind::Add),
        TOp::StoreLocal(1),
        TOp::LoadLocal(0),
        TOp::PushConstInt(1),
        TOp::IntArith(ArithKind::Sub),
        TOp::StoreLocal(0),
    ])
    .blocks
    .remove(0);
    for stmt in &mut body.stmts {
        stmt.pc += 50;
    }
    body.term = TTerm::Jump(1);
    tf.blocks.push(body);
    tf.blocks
        .push(function(&[TOp::LoadLocal(1)]).blocks.remove(0));
    tf.osr_entries.push(OsrEntry {
        pc: 42,
        block: 1,
        unassigned_reads: vec![0, 1, 2],
    });
    let mut engine = super::JitEngine::new().expect("host ISA");
    let cf = engine.compile_tfunc(&tf).expect("compile loop exits");
    for entry_pc in [0, 42] {
        let mut locals = [3, (i64::MAX - 1) as u64, 1];
        let mut spill = [0; 2];
        let mut tags = [u32::MAX; 2];
        let frame = run_local_exit_probe(
            &cf,
            entry_pc,
            &mut locals,
            &mut spill,
            &mut tags,
            JitStatus::Deopt,
        );
        assert_eq!(frame.deopt_pc, 52);
        assert_eq!(frame.stack_len, 2);
        assert_eq!(locals, [2, i64::MAX as u64, 1]);
        assert_eq!(spill, [i64::MAX as u64, 1]);
        assert_eq!(tags, [SlotTag::Int as u32; 2]);

        let mut locals = [3, 4, 2];
        let frame = run_local_exit_probe(
            &cf,
            entry_pc,
            &mut locals,
            &mut spill,
            &mut tags,
            JitStatus::Returned,
        );
        assert_eq!(locals, [3, 4, 2]);
        assert_eq!(frame.ret_bits, 10);
        assert_eq!(frame.ret_tag, SlotTag::Int as u32);
    }
}

fn run_local_exit_probe_flags(
    compiled: &super::CompiledFrame,
    entry_pc: u32,
    locals: &mut [u64],
    spill: &mut [u64],
    tags: &mut [u32],
    local_written: &mut [u32],
    expected: crate::runtime::JitStatus,
) -> crate::runtime::JitFrame {
    use crate::runtime::JitFrame;
    assert_eq!(locals.len(), compiled.n_locals as usize);
    assert!(spill.len() >= compiled.max_stack as usize);
    assert!(tags.len() >= spill.len());
    assert_eq!(local_written.len(), locals.len());
    let mut frame = JitFrame {
        locals: locals.as_mut_ptr(),
        local_written: local_written.as_mut_ptr(),
        n_locals: compiled.n_locals,
        entry_pc,
        ret_bits: 0,
        ret_tag: 0,
        deopt_pc: 0,
        stack_spill: spill.as_mut_ptr(),
        stack_tags: tags.as_mut_ptr(),
        stack_len: 0,
        stack_cap: spill.len() as u32,
        ctx: std::ptr::null_mut(),
        call_args: std::ptr::null_mut(),
        call_tags: std::ptr::null_mut(),
    };
    // SAFETY: these tests retain the owning engine and use only local scalar
    // operations and explicit exits. Opaque pin bits are copied, never read
    // through a helper. All buffers fit the compiled metadata and stay alive.
    assert_eq!(unsafe { compiled.enter(&raw mut frame) }, expected);
    frame
}

#[test]
fn assignment_flags_follow_conditional_stores_at_a_shared_exit() {
    use crate::runtime::JitStatus;
    for lane in [JitType::Int, JitType::Float, JitType::Bool, JitType::Obj] {
        let mut tf = function(&[TOp::LoadLocal(0)]);
        tf.n_locals = 3;
        tf.local_types = vec![Some(JitType::Int), Some(lane), Some(lane)];
        tf.livein_locals = vec![0, 2];
        tf.blocks[0].term = TTerm::BranchFalse {
            target: 2,
            fallthrough: 1,
        };
        let mut assigned = function(&[TOp::LoadLocal(2), TOp::StoreLocal(1)])
            .blocks
            .remove(0);
        assigned.term = TTerm::Jump(3);
        let mut skipped = function(&[]).blocks.remove(0);
        skipped.term = TTerm::Jump(3);
        let mut exit = function(&[]).blocks.remove(0);
        exit.term = TTerm::Deopt { pc: 31 };
        tf.blocks.extend([assigned, skipped, exit]);
        let mut engine = super::JitEngine::new().unwrap();
        let cf = engine.compile_tfunc(&tf).unwrap();
        for condition in [0, 1] {
            let mut locals = [condition, 99, 1];
            let mut written = [0; 3];
            let mut spill = [0; 2];
            let mut tags = [0; 2];
            let frame = run_local_exit_probe_flags(
                &cf,
                0,
                &mut locals,
                &mut spill,
                &mut tags,
                &mut written,
                JitStatus::Deopt,
            );
            assert_eq!(frame.deopt_pc, 31);
            assert_eq!(written, [0, condition as u32, 0]);
            assert_eq!(locals[1], if condition == 0 { 99 } else { 1 });
        }
    }
}

#[test]
fn assignment_flags_distinguish_empty_loops_and_osr_assignments() {
    use crate::ir::OsrEntry;
    use crate::runtime::JitStatus;
    let mut tf = function(&[]);
    tf.n_locals = 3;
    tf.local_types = vec![Some(JitType::Int); 3];
    tf.livein_locals = vec![0, 1];
    tf.blocks[0].term = TTerm::Jump(1);
    let mut header = function(&[]).blocks.remove(0);
    header.term = TTerm::ForRange {
        cur_slot: 0,
        stop_slot: 1,
        var_slot: 2,
        body: 2,
        exit: 3,
    };
    let mut body = function(&[]).blocks.remove(0);
    body.term = TTerm::Jump(1);
    let mut exit = function(&[]).blocks.remove(0);
    exit.term = TTerm::Deopt { pc: 80 };
    tf.blocks.extend([header, body, exit]);
    tf.osr_entries.push(OsrEntry {
        pc: 42,
        block: 1,
        unassigned_reads: vec![0, 1],
    });
    let mut engine = super::JitEngine::new().unwrap();
    let cf = engine.compile_tfunc(&tf).unwrap();
    for entry in [0, 42] {
        for (start, assigned, final_target) in [(1, 1, 2), (3, 0, 99)] {
            let mut locals = [start, 3, 99];
            let mut written = [0; 3];
            let mut spill = [0; 2];
            let mut tags = [0; 2];
            let frame = run_local_exit_probe_flags(
                &cf,
                entry,
                &mut locals,
                &mut spill,
                &mut tags,
                &mut written,
                JitStatus::Deopt,
            );
            assert_eq!(frame.deopt_pc, 80);
            assert_eq!(locals, [3, 3, final_target]);
            assert_eq!(written, [assigned, 0, assigned]);
        }
    }
}

#[test]
fn assignment_flags_survive_a_native_generator_resume() {
    use crate::ir::OsrEntry;
    use crate::runtime::JitStatus;
    let mut tf = function(&[TOp::PushConstInt(7), TOp::StoreLocal(1), TOp::LoadLocal(0)]);
    tf.local_types[0] = Some(JitType::Obj);
    tf.livein_locals = vec![0];
    tf.blocks[0].term = TTerm::Yield { pc: 10 };
    let mut resume = function(&[TOp::Pop]).blocks.remove(0);
    resume.entry_stack = vec![JitType::Obj];
    resume.term = TTerm::Deopt { pc: 32 };
    tf.blocks.push(resume);
    tf.resume_entries.push(OsrEntry {
        pc: 11,
        block: 1,
        unassigned_reads: vec![],
    });
    let mut engine = super::JitEngine::new().unwrap();
    let cf = engine.compile_tfunc(&tf).unwrap();
    let mut locals = [u64::MAX, 99];
    let mut written = [0; 2];
    let mut spill = [0; 2];
    let mut tags = [0; 2];
    let first = run_local_exit_probe_flags(
        &cf,
        0,
        &mut locals,
        &mut spill,
        &mut tags,
        &mut written,
        JitStatus::Yielded,
    );
    assert_eq!(first.deopt_pc, 10);
    assert_eq!(locals[1], 7);
    assert_eq!(written, [0, 1]);
    let last = run_local_exit_probe_flags(
        &cf,
        11,
        &mut locals,
        &mut spill,
        &mut tags,
        &mut written,
        JitStatus::Deopt,
    );
    assert_eq!(last.deopt_pc, 32);
    assert_eq!(locals[1], 7);
    assert_eq!(written, [0, 1]);
}

#[test]
fn object_indexing_requires_its_registered_helper() {
    let mut tf = function(&[TOp::LoadLocal(0), TOp::LoadLocal(1), TOp::ObjGetItemInt]);
    tf.local_types[0] = Some(JitType::Obj);
    let mut engine = super::JitEngine::new().unwrap();
    assert!(matches!(
        engine.compile_tfunc(&tf),
        Err(crate::JitVerdict::UnsupportedOpcode(
            "object subscription (no helper registered)"
        ))
    ));
}

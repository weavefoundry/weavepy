import importlib.util, json
spec = importlib.util.spec_from_file_location('storage_control', '/Users/owencarey/Documents/weavefoundry/weavepy/target/thin-value-storage-inputs/cold/unique_ascii_129.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(200000)
for _ in range(6):
    module.bench(64)
last = module.bench(200000)
print(json.dumps(first))
print(json.dumps(last))

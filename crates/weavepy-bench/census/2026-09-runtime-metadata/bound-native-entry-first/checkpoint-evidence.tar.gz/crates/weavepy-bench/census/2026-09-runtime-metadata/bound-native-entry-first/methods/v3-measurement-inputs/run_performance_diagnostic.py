"""Record a deliberately busy-host diagnostic without claiming a quiet run.

Use fresh outputs and retain every sample and load observation. This controller
does not select favorable host conditions or retry a benchmark.
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import subprocess
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--out', type=Path, required=True)
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
command = a.command[1:] if a.command[:1] == ['--'] else a.command
assert command and not a.out.exists()
started = time.monotonic()
report = {'purpose': __doc__, 'command': command, 'logical_cpus': os.cpu_count(),
          'quiet_host_precondition': False, 'status': 'starting', 'observations': [],
          'selection_policy': 'One diagnostic run; no sample exclusion or automatic retry.'}

def save():
    temporary = a.out.with_name(a.out.name + '.partial')
    temporary.write_text(json.dumps(report, indent=2) + '\n')
    temporary.replace(a.out)

def observe(phase):
    report['observations'].append({'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'elapsed_seconds': time.monotonic() - started, 'phase': phase,
        'load_1_5_15_minutes': list(os.getloadavg())})
    save()

observe('before')
try:
    child = subprocess.Popen(command)
    report.update(status='running', child_pid=child.pid)
    save()
    while True:
        try:
            rc = child.wait(timeout=10)
            break
        except subprocess.TimeoutExpired:
            observe('command')
    observe('finished')
    report.update(status='complete' if rc == 0 else 'command_failed', returncode=rc)
    save()
except Exception as error:
    report.update(status='launch_or_monitor_error', error=repr(error))
    save()
    raise
raise SystemExit(rc)

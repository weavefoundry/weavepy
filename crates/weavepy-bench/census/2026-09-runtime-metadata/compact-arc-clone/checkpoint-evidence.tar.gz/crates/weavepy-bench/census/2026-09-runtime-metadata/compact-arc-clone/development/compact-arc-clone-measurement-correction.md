# Correction of overlapping measurement stages

The direct-reference focused run completed in isolation. During the subsequent
full comparison against 65ff, the retained-reference focused gate was scheduled
before the first run had finished. This was a scheduling error. The second gate
launched a measurement child before the first attempt to stop it checked its
state; that attempted stop correctly refused to treat it as a waiting gate.
The second stage's owned process tree was then stopped. Its tool session ended
with exit 143. No unrelated process was stopped. A later process inventory
confirmed that no owned measurement children remained after the original full
comparison completed.

Preserve compact-arc-clone-full-previous in full, labeled as affected by overlap.
Preserve compact-arc-clone-focused-retained in full, labeled as interrupted and
affected by overlap. Its raw gate JSON still says running because its controller
was terminated; the incident record and exit 143 give its terminal state. It
contains partial cold samples and complete cold verification outputs. Neither
affected run is an isolated headline result. Do not remove or select individual
samples from either run. The incident JSON retains gate states, timestamps, and
the exact owned process IDs stopped.

After every original stage has finished or been stopped, collect fresh complete
comparisons in this explicit order:

1. Full against 65ff in compact-arc-clone-full-previous-isolated.
2. Focused against bf2 in compact-arc-clone-focused-retained-isolated.
3. Full against bf2 in compact-arc-clone-full-retained-isolated.

The reason for replacement is the known protocol violation, independent of the
timing outcomes. Keep both the affected diagnostics and every replacement sample.
Do not repeat the valid earlier focused comparison. The original source, inputs,
timing samplers, and launchers remain unchanged. Record the added controller and
this correction document in a separate method-hash manifest.

Use run_serial_performance_gate.py for every subsequent stage. It holds a
nonblocking exclusive file lock through the complete original load gate and
its measured command, and rejects known older controllers or orphaned samplers
before launch. A busy lease causes no measurement to start. The original load,
stabilization, sample-count, cache, telemetry, and no-other-owned-work rules remain.
Inspect each completed tool result before scheduling any dependent stage.

"""Add an error-burst recovery control before any candidate timing or oracle run."""
from pathlib import Path
import hashlib
import json

root = Path("target/assertion-exit-inputs/warm")
p = root / "failure_burst_recovery.py"
assert not p.exists()
p.write_text('''def leaf(value):
    assert value >= 0, f"negative value {value}"
    return value * 3 + 1
def wrapper(value):
    return leaf(value) + 2
def bench(n):
    total = 0
    for _ in range(100):
        try:
            total += wrapper(-1)
        except AssertionError as error:
            total += len(error.args[0])
    for i in range(n):
        total += wrapper(i)
    return total
''')
driver = root / "failure_burst_recovery-verify.py"
driver.write_text(f'''import importlib.util
import json
spec = importlib.util.spec_from_file_location("assertion_control", {str(p.resolve())!r})
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(5000)
for _ in range(6):
    module.bench(5000)
last = module.bench(5000)
print(json.dumps(first))
print(json.dumps(last))
''')
manifest = root / "preparation.json"
data = json.loads(manifest.read_text())
assert len(data["rows"]) == 12
for row in data["rows"].values():
    assert hashlib.sha256(Path(row["path"]).read_bytes()).hexdigest() == row["source_sha256"]
    assert hashlib.sha256(Path(row["driver"]).read_bytes()).hexdigest() == row["driver_sha256"]
data["rows"]["failure_burst_recovery"] = {"path": str(p), "source_sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
    "driver": str(driver), "driver_sha256": hashlib.sha256(driver.read_bytes()).hexdigest()}
manifest.write_text(json.dumps(data, indent=2) + "\n")
print("Added recovery control; all 12 existing warm inputs remain byte-identical.")

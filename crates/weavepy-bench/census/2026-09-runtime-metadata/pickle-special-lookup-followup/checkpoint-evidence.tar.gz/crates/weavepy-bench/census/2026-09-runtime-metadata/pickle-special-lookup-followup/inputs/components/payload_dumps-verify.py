import json, sys, types
module = types.ModuleType("_weavepy_bench")
module.__file__ = 'target/pickle-special-lookup-inputs/components/payload_dumps.py'
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
first = module.bench(20)
for unused in range(3):
    module.bench(20)
last = module.bench(20)
print(json.dumps(first, sort_keys=True))
print(json.dumps(last, sort_keys=True))

"""Call-shape matrix: positional, defaults, kwargs, bound methods,
builtins — the pure function-call overhead benchmark."""

import os


def pos2(a, b):
    return a + b


def with_defaults(a, b=10, c=20):
    return a + b + c


def with_kwargs(a, **kw):
    return a + kw.get("delta", 0)


class Counter:
    def __init__(self):
        self.n = 0

    def bump(self, by):
        self.n += by
        return self.n


def bench(n):
    c = Counter()
    bump = c.bump
    total = 0
    seq = (1, 2, 3)
    for i in range(n):
        total += bump(1)
    return total

for unused in range(3):
    print(bench(300))


def bench(n):
    values = [tuple(range(i, i + 1)) for i in range(n)]
    return [len(values), sum(values[0]), sum(values[-1])]

if __name__ == '__main__':
    import os, time
    n = int(os.environ['WEAVEPY_BENCH_WORK'])
    start = time.perf_counter_ns()
    cpu = time.process_time_ns()
    result = bench(n)
    cpu_elapsed = time.process_time_ns() - cpu
    elapsed = time.perf_counter_ns() - start
    print('WEAVEPY_BENCH_NS=%d' % elapsed)
    print('WEAVEPY_BENCH_CPU_NS=%d' % cpu_elapsed)

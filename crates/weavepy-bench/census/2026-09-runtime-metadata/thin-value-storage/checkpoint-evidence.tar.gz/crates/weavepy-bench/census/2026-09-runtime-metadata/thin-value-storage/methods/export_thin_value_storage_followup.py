"""Archive the measured length-prefixed owner candidate and every retained outcome."""
import gzip,hashlib,json
from pathlib import Path

parent=Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out=parent/'thin-value-storage'
assert not out.exists()
for group in ['focused','full']:
    assert Path('target/thin-value-storage-'+group+'/stage.txt').read_text().strip()=='done'
    assert json.loads(Path('target/thin-value-storage-'+group+'-load.json').read_text())['status']=='complete'
focus=json.loads(Path('target/thin-value-storage-focused/summary.json').read_text())
full=json.loads(Path('target/thin-value-storage-full/summary.json').read_text())
checks=json.loads(Path('target/thin-value-storage-validation-corrected/validation.json').read_text())
assert len(checks)==275 and all(r['passed'] for r in checks)
pre=json.loads(Path('target/thin-value-storage-prebuild.json').read_text())
for group in ['sources','methods']:
    for name,digest in pre[group].items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
env=json.loads(Path('target/thin-value-storage-source-snapshot/environment.json').read_text())
assert env['binaries']['new']['sha256']=='bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'
out.mkdir()
records=[]
def copy(source,destination):
    source=Path(source);raw=source.read_bytes();data=raw
    if len(raw)>=65536 and source.suffix in ['.json','.jsonl','.txt','.diff','.rs','.py']:
        destination+='.gz';data=gzip.compress(raw,compresslevel=9,mtime=0)
    p=out/destination;assert not p.exists(),destination
    p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    records.append({'path':destination,'source':str(source),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'uncompressed_bytes':len(raw),'uncompressed_sha256':hashlib.sha256(raw).hexdigest()})
def folder(source,destination):
    for p in sorted(Path(source).iterdir()):
        if p.is_file() and p.suffix in ['.py','.json','.txt','.md','.sh','.toml','.lock','.rs','.diff']:
            copy(p,str(Path(destination)/p.name))

for group in ['focused','full']:
    folder('target/thin-value-storage-'+group,group)
for group in ['cold','warm']:
    copy('target/thin-value-storage-focused/'+group+'/measurements.json','focused/'+group+'.json')
    folder('target/thin-value-storage-inputs/'+group,'inputs/'+group)
for group in ['checks','validation','validation-corrected','extra-checks','extra-checks-v2','input-baseline']:
    folder('target/thin-value-storage-'+group,'checks/'+group)
for name in env['sources']:
    copy('target/thin-value-storage-source-snapshot/'+name,'candidate/sources/'+name)
for name in ['environment.json','source-changes.diff']:
    copy('target/thin-value-storage-source-snapshot/'+name,'candidate/'+name)
for name in pre['methods']:
    copy(name,'methods/original/'+name)
corrected=json.loads(Path('target/thin-value-storage-corrected-methods.json').read_text())
for name,digest in corrected.items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest
    copy(name,'methods/corrected/'+name)
for pattern in ['thin-value-storage-*.txt','thin-value-storage-check-*.jsonl','shared_value_storage_*baseline*.txt','thin_value_storage_api_*.txt']:
    for p in sorted(Path('target').glob(pattern)):
        copy(p,'logs/'+p.name)
for name in ['thin-value-storage-focused-load.json','thin-value-storage-full-load.json','thin-value-storage-prebuild.json','thin-value-storage-corrected-methods.json','thin-value-storage-integrated-miri-report.json','thin-value-storage-layout.json','thin-value-storage-review.diff','performance_phase69_status.md','performance_phase69_timing_status.md']:
    copy('target/'+name,'conditions/'+name)
copy('target/thin-value-storage-preimages/index.json','development/preimages-index.json')
for name in ['shared_value.rs','tuple_storage.rs']:
    copy('target/thin-value-storage-preimages/tested-draft/'+name,'development/tested-draft/'+name)
for crate in ['thin-value-storage-api','thin-value-storage-integrated-api']:
    for name in ['Cargo.toml','Cargo.lock','src/lib.rs']:
        copy('target/'+crate+'/'+name,'development/'+crate+'/'+name)
copy('target/test_shared_value_storage_initial.py','development/initial-python-test.py')
for name in ['prepare_thin_value_storage.py','apply_thin_value_storage_initial.py','fix_thin_value_owner_calls.py','tidy_thin_value_imports.py','prepare_thin_value_methods.py','summarize_thin_value_storage.py']:
    copy('target/'+name,'methods/development/'+name)
copy(__file__,'methods/'+Path(__file__).name)

work=full['cohorts']['all_23_workloads_excluding_startup']['metrics']['jit']['ns']
historical=full['cohorts']['historical_21_including_startup']['metrics']['jit']
process=full['cohorts']['all_processes_including_startup']['metrics']['jit']
lines=['# Move slice lengths into shared allocations','',
'Decision: retain as a measured candidate under refinement. The overall goal',
'remains unachieved. Short allocation and call regressions remain explicit.','',
'The bf2db3c5 candidate uses one-word strong owners for Str, WStr, Bytes,',
'and Tuple. Slice lengths live in the immutable allocation, while ordinary',
'Arc controls reference counts and full Weak pointers retain metadata after',
'payload destruction. Tuple hash publication and unique free-list mutation',
'remain intact. Intern tables, iterator/buffer owners, native pins, C API weak',
'buffer caches, identity probes, and tracing owners use the new handles.',
'Compiler behavior and the independent non-atomic type-cache names are unchanged.',
'The JIT crate has only a storage-name documentation update in this experiment.','',
'On ARM64, Object and DictKey are 16 bytes instead of 24. Shared handles are',
'8 bytes each. The extra per-allocation length word can increase short-object',
'allocator classes. The release binary is 44,097,168 bytes, 192,352 bytes smaller',
'than ed99. Layout and file size are not process-memory or execution-time results.','',
'All 347 final VM unit tests, 34 C API unit tests, and nine loader integration',
'tests pass. Formatting, strict Clippy, and the build without JIT pass. Miri',
'passes eight tests on each of ARM64 and i686 using the exact storage modules',
'but stub Object/CachedHash definitions. This is not whole-VM Miri validation',
'or a formal soundness proof. Source, manifests, logs, and hashes are retained.','',
'All 87 targeted release checks pass in JIT, interpreter, and GIL-disabled',
'modes. Standard validation passed 273 of 275 inside the tool sandbox; exactly',
'two loopback fixtures failed to bind. Both passed outside the sandbox with',
'the same binary, sources, and expected outputs. The combined 275-check file',
'preserves each original failure beneath its recheck. Other records retain',
'their original execution context. All oracle results remain available.','',
'Additional bytes/codecs suites pass, as do four explicitly selected nested',
'C API bytes/Unicode/list/dict suites. Existing unittest skips are visible.',
'The initial nonexistent Unicode filter and empty nested selections are not',
'passes. The standard test_str suite covers Unicode behavior. The extra marshal',
'suite has the same four exact expected failure ids on ed99 and bf2: int/float',
'instance identity and two recursive tuple reconstruction cases. It is not a',
'clean marshal-suite pass. See the validation corrections and unchanged',
'expectations for the full limitation. All development failures remain.','',
'The first Python hash test incorrectly assumed successful tuple hashes were',
'not cached; CPython 3.14 rejected that assertion. The corrected test checks',
'repeated hash failures followed by cached success. Both baseline and candidate',
'pass corrected semantics. No runtime or Python regression source changed',
'after the release build; only separately frozen validation/timing launchers',
'were corrected. Timing used only their v2 forms.','',
'The original prebuild manifest has 336 source/configuration hashes and 75',
'method/input hashes. The executable snapshot includes 165 sources. Twenty',
'cold 200,000-value populations and seven warm 20,000-operation controls use',
'seven alternating pairs of ed99/candidate in both modes and CPython. All',
'values agree and frozen caches remain unchanged. GIL-disabled runs verify',
'correctness only. Every measured sample, range, loss, and host observation',
'is retained; one declared stabilization cycle is discarded per row.','',
'| Control | JIT time / ed99 | JIT RSS / ed99 | Time wins / 7 | RSS wins / 7 |',
'| --- | ---: | ---: | ---: | ---: |']
for name,row in focus['rows'].items():
    v=row['new_over_previous']['jit'];p=row['pairs']['jit']
    lines.append(f"| {name} | {v['ns']:.5f} | {v['rss_bytes']:.5f} | {p['ns']['wins']} | {p['rss_bytes']['wins']} |")
lines+=['',
'The focused summary includes both modes and all workload/process wall/CPU',
'and peak-RSS fields. Cold controls retain process CPU; the unchanged sampler',
'extracts the separate workload CPU timer only for warm controls. Nine-byte',
'ASCII and bytes allocations lose about 3.9 percent RSS in all seven pairs.',
'Every ASCII/bytes construction control is slower in all seven pairs. Those',
'losses coexist with substantial shared-container and tuple memory savings.','',
'The full run keeps 24 unchanged fixtures at five pairs plus nine startup/import',
'controls at 31 pairs. Both timing gates qualified and completed outside the',
'tool filesystem sandbox. All later load, VM, and swap data remain; there was',
'no sample filtering or automatic timing retry.','',
f"The 23-workload JIT mean is {work['new_over_base']:.9f} of ed99 and",
f"{work['new_over_cpython']:.9f} of CPython, with {work['weavepy_wins']} time wins",
f"and {work['base_regressions']} workload medians slower than ed99.",
f"The historical 21-fixture paired mean is {historical['ns']['new_over_cpython']:.9f}",
f"of CPython, or {historical['ratio_of_medians_new_over_cpython']:.9f} as ratios of medians.",'',
f"All-24 process wall/CPU/RSS ratios to ed99 are {process['wall_ns']['new_over_base']:.9f},",
f"{process['cpu_ns']['new_over_base']:.9f}, and {process['rss_bytes']['new_over_base']:.9f}.",
f"Peak RSS is {process['rss_bytes']['new_over_cpython']:.9f} of CPython with",
f"{process['rss_bytes']['weavepy_wins']} wins. All full-suite RSS medians improve versus ed99.",'',
'Keep 21/23/24 cohorts distinct and use current same-run pairs for attribution.',
'No universal, energy, controlled build-time, portability, or native parallel',
'performance superiority follows. File-size and memory reductions do not erase',
'the retained execution-time and allocation regressions.','',
'Large evidence files are compressed losslessly with stored and uncompressed',
'hashes. Executables, frozen caches, and unselected raw artifacts remain local.',
'Only indexed, explicitly allowlisted evidence is selected for version control.','']
(out/'REPORT.md').write_text('\n'.join(lines))
p=out/'REPORT.md';records.append({'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'index.json').write_text(json.dumps(records,indent=2)+'\n')
for record in records:
    data=(out/record['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==record['sha256']
    if 'uncompressed_sha256' in record:
        raw=gzip.decompress(data) if record['path'].endswith('.gz') else data
        assert hashlib.sha256(raw).hexdigest()==record['uncompressed_sha256']
with (parent/'.gitignore').open('a') as f:
    f.write('\n# Shared value layout, corrected validation, and every measurement.\n')
    for p in sorted(out.rglob('*')):
        if p.is_file():f.write('!'+str(p.relative_to(parent))+'\n')
with (parent/'README.md').open('a') as f:
    f.write('\nThe [shared value-storage follow-up](thin-value-storage/REPORT.md) records\n16-byte values, broad memory savings, short-allocation regressions, and all\ncorrected validation and paired results. It remains a candidate under refinement.\n')
print('Exported',len(records)+1,'files;',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes; all stored/uncompressed hashes verified.')


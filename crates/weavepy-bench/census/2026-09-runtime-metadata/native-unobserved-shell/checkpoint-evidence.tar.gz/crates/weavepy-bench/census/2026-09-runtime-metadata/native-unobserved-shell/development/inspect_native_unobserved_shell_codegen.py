"""Preserve static stack prologues for native call helpers and entry points."""
from pathlib import Path
import hashlib,json,re,subprocess
root=Path('target/native-unobserved-shell-codegen')
assert not root.exists();root.mkdir()
report={'purpose':__doc__,'variants':{}}
for label,binary in [('previous','target/release/weavepy-runtime-ascii-time-format'),('new','target/release/weavepy-runtime-native-unobserved-shell')]:
    p=subprocess.run(['xcrun','nm','-n',binary],capture_output=True,text=True,check=True)
    (root/(label+'-symbols.txt')).write_text(p.stdout)
    item={'binary':binary,'sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'functions':{}}
    for name in ['wpjit_call_dyn','wpjit_call_dyn_int','try_native_call','try_enter_bound_native']:
        matches=[line.split()[-1] for line in p.stdout.splitlines() if line.split() and line.split()[-1].endswith('5tier2'+str(len(name))+name)]
        entries=[]
        for index,symbol in enumerate(matches):
            result=subprocess.run(['xcrun','llvm-objdump','--macho','--disassemble','--dis-symname',symbol,binary],capture_output=True,text=True,check=True)
            path=root/(label+'-'+name+'-'+str(index)+'.txt');path.write_text(result.stdout)
            lines=result.stdout.splitlines();start=next((i for i,line in enumerate(lines) if line.strip()==symbol+':'),None)
            assert start is not None,(name,symbol)
            prologue=lines[start+1:start+15]
            entries.append({'symbol':symbol,'assembly':str(path),'sha256':hashlib.sha256(result.stdout.encode()).hexdigest(),'prologue':prologue})
        item['functions'][name]=entries
        if name in ['wpjit_call_dyn','wpjit_call_dyn_int']:assert len(entries)==1,(label,name,matches)
    report['variants'][label]=item
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print('Static prologues captured. Interpret combined live frames explicitly; no stack or RSS reduction is assumed.')

"""Prepare independent binder methods while keeping active runtime/methods frozen."""
from pathlib import Path
for old,new in [('check_early_bound_entry.sh','check_binder_flags.sh'),('validate_early_bound_entry.sh','validate_binder_flags.sh'),('inspect_early_bound_entry.py','inspect_binder_flags.py'),('check_early_bound_entry_extra.py','check_binder_flags_extra.py'),('measure_early_bound_entry_full.sh','measure_binder_flags_full.sh')]:
    dest=Path('target')/new;assert not dest.exists()
    s=(Path('target')/old).read_text().replace('early-bound-entry','binder-flags')
    if new=='check_binder_flags.sh':s=s.replace('for test in test_bound_native_entry ', 'for test in test_argument_binding_storage test_bound_native_entry ')
    if new in ['inspect_binder_flags.py','measure_binder_flags_full.sh']:
        s=s.replace('binder-flags-previous.txt','binder-flags-reference.txt')
    dest.write_text(s)

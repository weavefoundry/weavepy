"""Check accelerator refusal before custom descriptor and key callbacks."""
import copyreg
import json

try:
    from _weave_pickle import lookup_special as native
except ImportError:
    native = None

events = []

class WithProperty:
    @property
    def __getstate__(self):
        events.append('property')
        return lambda: {'value': 7}

value = WithProperty()
if native is not None:
    assert native(value, '__getstate__') is NotImplemented
    assert events == []
assert object.__reduce_ex__(value, 5)[2] == {'value': 7}
assert events == ['property']

class Ordinary:
    def __getnewargs__(self):
        return (19,)

value = Ordinary()
if native is not None:
    assert native(value, '__getnewargs__')() == (19,)

class Key(str):
    __hash__ = str.__hash__
    def __eq__(self, other):
        events.append('key equality')
        return str.__eq__(self, other)

Exotic = type('Exotic', (), {
    Key('__getnewargs__'): lambda self: (23,),
    '__module__': __name__,
})
exotic = Exotic()
events.clear()
if native is not None:
    assert native(exotic, '__getnewargs__') is NotImplemented
    assert native(value, '__getnewargs__') is NotImplemented
    assert events == []
assert object.__reduce_ex__(exotic, 5)[1] == (Exotic, 23)
# The established Python lookup may probe the custom key more than once.
# Preserve its callback sequence relative to the predecessor, not a guess.
print(json.dumps({'key_events': events, 'newargs': [23]}, sort_keys=True))

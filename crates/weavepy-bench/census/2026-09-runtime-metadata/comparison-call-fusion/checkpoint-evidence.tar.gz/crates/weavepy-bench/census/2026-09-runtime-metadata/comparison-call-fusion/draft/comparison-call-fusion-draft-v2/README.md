# Fuse integer results into comparisons

The unfused comparison candidate improves simple integer controls but regresses
complex callback controls, including 12.5 percent warm and 15.1 percent cold
with no rich-comparison misses. This draft is a separate proposed refinement.
It reuses CallDyn int_result, already used by integer arithmetic, for an adjacent
comparison or one separated only by a non-guarding integer/bool constant load.
A noninteger completed result parks and resumes after the producer; the constant
and comparison then execute in the interpreter. General shapes retain the
original exact-COMPARE_OP guard. No helper, pin ownership, cache, policy, or
unsafe code changes. The old field's documentation is updated accordingly.

Check side effects, arbitrary rich results and truth conversion, producer/compare
exceptions, loop locals and exact traceback lines, native caller reconstruction,
tracing, guard invalidation, pin pressure, and all cold/warm/failure/recovery
controls. Never fuse across another operand load, callback, or guarding opcode.
The existing source snapshots and every prior regression must remain preserved.
Apply only after the unfused candidate's full measurements and archival, with
exact baseline hashes rechecked. No correctness or performance claim yet.

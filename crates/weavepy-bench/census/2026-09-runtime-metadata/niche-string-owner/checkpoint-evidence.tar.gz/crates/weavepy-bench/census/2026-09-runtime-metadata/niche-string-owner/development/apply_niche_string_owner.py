"""Apply only the independently checked aligned string owner to retained bf2."""
from pathlib import Path
import hashlib
import json
import textwrap

root = Path('target/niche-string-owner-preimages')
assert not root.exists()
before = json.loads(Path('target/thin-value-storage-prebuild.json').read_text())['sources']
for name, digest in before.items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
root.mkdir()
p = Path('crates/weavepy-vm/src/shared_value.rs')
original = p.read_text()
(root / 'shared_value.rs').write_text(original)
(root / 'index.json').write_text(json.dumps({'sources': before}, indent=2) + '\n')
prototype = Path('target/niche-string-owner-prototype/src/lib.rs').read_text()
body = prototype[prototype.index('const POINTER_BYTES:'):prototype.index('#[cfg(test)]')]
body = body.replace('pub fn from_arc(value: Arc<str>)', 'pub(crate) fn from_arc(value: Arc<str>)')
body = body.replace('/// A standard Arc<str> owner whose metadata leaves a reserved enum-tag byte.', '''/// Shared UTF-8 text backed by a standard `Arc<str>` allocation.
///
/// The initialized zero-only byte provides invalid values that Rust can use
/// for an enclosing enum's tag. On 64-bit targets, this keeps `Object` compact
/// while allowing a word load of string length without a payload-header read.
/// Lengths that need the reserved byte use an individually owned boxed Arc.
/// No pointer bits are stored in integer metadata or discarded.''')
start = original.index('/// Shared UTF-8 text.')
end = original.index('impl sealed::Sealed for crate::tuple_storage::TupleStorage {}', start)
updated = original[:start] + body + '\n' + original[end:]
updated = updated.replace('''//! Shared immutable values whose slice metadata lives in their allocation.
//!
//! Reference counts and weak-reference synchronization remain with `Arc`.
//! Only strong handles omit metadata; weak handles retain their original DST
//! pointers, so they never read a payload after its last strong owner dies.''', '''//! Compact owners for shared immutable values.
//!
//! Byte slices and tuples keep metadata in their allocation. UTF-8 strings
//! keep aligned metadata in their handle, with a reserved byte for enum tags.
//! Reference counts and weak-reference synchronization remain with `Arc`.
//! Weak handles retain full pointers and never read a destroyed payload.''')
tests = Path('target/niche-string-owner-prototype/src/tests.rs').read_text()
updated += '\n#[cfg(test)]\nmod aligned_string_tests {\n' + textwrap.indent(tests, '    ') + '}\n'
p.write_text(updated)
prototype_files = [q for q in Path('target/niche-string-owner-prototype').rglob('*')
                   if q.is_file() and 'target' not in q.relative_to('target/niche-string-owner-prototype').parts]
prototype_files += list(Path('target').glob('niche-string-owner-prototype-*.txt'))
prototype_files += list(Path('target').glob('niche-string-owner-codegen.*'))
prototype_files += [Path('target/niche-string-layout.json'), Path('target/niche_string_layout_preflight.rs'),
                    Path('target/niche_string_layout_preflight.s')]
report = {'change': str(p), 'before': hashlib.sha256(original.encode()).hexdigest(),
          'note': 'Six ordinary and six strict-provenance Miri tests per ARM64 and i686. Standalone codegen is not a VM timing result.',
          'hashes': {str(q): hashlib.sha256(q.read_bytes()).hexdigest() for q in sorted(prototype_files)}}
Path('target/niche-string-owner-preflight-report.json').write_text(json.dumps(report, indent=2) + '\n')
print('Applied aligned UTF-8 owner; retained all other thin owners and tuple storage.')

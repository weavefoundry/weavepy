#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base="$1"
binary=target/release/weavepy-runtime-bound-native-entry
test -f "$base"
test ! -e "$binary"
test ! -e target/bound-native-entry-v2-stage.txt
printf '%s\n' "$base" > target/bound-native-entry-v2-previous.txt
printf 'VM tests and static checks\n' > target/bound-native-entry-v2-stage.txt
cargo fmt --all -- --check > target/bound-native-entry-v2-format.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/bound-native-entry-v2-vm-tests.txt 2>&1
cargo clippy --offline --locked -p weavepy-vm -p weavepy-jit --lib --tests -j 1 -- -D warnings > target/bound-native-entry-v2-clippy.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/bound-native-entry-v2-no-jit.txt 2>&1
printf 'release build\n' > target/bound-native-entry-v2-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/bound-native-entry-v2-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/bound-native-entry-v2-source-snapshot --extra target/build_bound_native_entry_v2.sh target/prepare_bound_native_entry_draft.py target/check_bound_native_entry.sh target/validate_bound_native_entry.sh > target/bound-native-entry-v2-snapshot.txt 2>&1
printf 'done\n' > target/bound-native-entry-v2-stage.txt

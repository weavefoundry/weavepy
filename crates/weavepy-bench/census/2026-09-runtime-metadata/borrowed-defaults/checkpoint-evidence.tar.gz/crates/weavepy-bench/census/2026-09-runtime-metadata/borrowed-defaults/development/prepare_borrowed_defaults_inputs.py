"""Prepare independent default-binding controls with unchanged timing machinery."""
from pathlib import Path
import hashlib
import json

root = Path('target/borrowed-defaults-inputs')
assert not root.exists()
rows = {}
for width in [1, 4, 16, 64]:
    for mode in ['omitted', 'partial_keyword']:
        rows[f'override_{width}_{mode}'] = (width, mode, True)
for width in [4, 64]:
    rows[f'override_{width}_all_supplied'] = (width, 'all_supplied', True)
    rows[f'compiled_{width}_omitted'] = (width, 'omitted', False)
for group in ['cold', 'warm']:
    folder = root / group
    folder.mkdir(parents=True)
    prepared = {'purpose': __doc__, 'work': 20000, 'rows': {}}
    for name, (width, mode, overridden) in rows.items():
        params = ', '.join(f'a{i}' + ('' if overridden else f'=values[{i}]') for i in range(width))
        argument = {'omitted': '', 'partial_keyword': f'a{width-1}=provided',
                    'all_supplied': ', '.join('provided' for _ in range(width))}[mode]
        text = f'''import os
values = tuple("default-%d-" % i + "shared-text" * 3 for i in range({width}))
provided = "provided-" + "string" * 3
def target({params}):
    return a{width-1}
'''
        if overridden:
            text += 'target.__defaults__ = values\n'
        text += f'''def bench(n):
    total = 0
    for _ in range(n):
        total += len(target({argument}))
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))
'''
        path = folder / (name + '.py')
        path.write_text(text)
        driver = folder / (name + '-verify.py')
        driver.write_text(f'''import importlib.util, json
spec = importlib.util.spec_from_file_location('default_control', {str(path.resolve())!r})
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(20000)
for _ in range(6):
    module.bench(64)
last = module.bench(20000)
print(json.dumps(first))
print(json.dumps(last))
''')
        prepared['rows'][name] = {'path': str(path), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                 'driver': str(driver), 'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest()}
    (folder / 'preparation.json').write_text(json.dumps(prepared, indent=2) + '\n')
print('Prepared 12 cold and 12 warm default-binding controls.')

"""Capture CPU stacks for verified record pickling, without timing claims."""
import hashlib
import json
import os
from pathlib import Path
import selectors
import subprocess

root = Path('target/jit-raise-call-spans-pickle-profiles')
assert not root.exists()
root.mkdir()
checked = json.loads(Path('target/jit-raise-call-spans-pickle/report.json').read_text())
assert checked['status'] == 'passed'
report = {'purpose': __doc__, 'verification': 'target/jit-raise-call-spans-pickle/report.json',
          'binaries': checked['binaries'], 'rows': {}}
for name in ['records_dumps', 'records_loads']:
    case = checked['rows'][name]['case']
    source = Path(case['path'])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == case['source_sha256']
    result = json.loads(checked['rows'][name]['verification']['cpython']['stdout'])
    expected = (result['blob_bytes'] if case['operation'] == 'dumps' else 20) * case['work']
    driver = root / (name + '.py')
    driver.write_text(f'''import sys, types, os
module = types.ModuleType("_weavepy_bench")
module.__file__ = {str(source)!r}
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
for _ in range(3):
    assert module.bench({case['work']}) == {expected}
print(os.getpid(), flush=True)
while True:
    module.bench({case['work']})
''')
    for label in ['base', 'new']:
        info = checked['binaries'][label]
        assert hashlib.sha256(Path(info['path']).read_bytes()).hexdigest() == info['sha256']
        env = dict(os.environ, WEAVEPY_JIT='1',
                   WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
                   WEAVEPY_FROZEN_CACHE=str((root / 'frozen' / info['sha256']).resolve()))
        for key in ['WEAVEPY_JIT_TRACE', 'WEAVEPY_VM_STATS', 'WEAVEPY_JIT_THRESHOLD']:
            env.pop(key, None)
        proc = subprocess.Popen([info['path'], str(driver)], env=env, text=True,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(proc.stdout, selectors.EVENT_READ)
                assert selector.select(90), 'Profile child did not become ready'
            assert int(proc.stdout.readline().strip()) == proc.pid and proc.poll() is None
            path = root / (name + '-' + label + '.sample.txt')
            command = ['/usr/bin/sample', str(proc.pid), '5', '1', '-file', str(path)]
            sampled = subprocess.run(command, text=True, capture_output=True, timeout=30)
            report['rows'][name + '-' + label] = {'case': case, 'binary': info,
                'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest(),
                'command': command, 'returncode': sampled.returncode, 'stdout': sampled.stdout,
                'stderr': sampled.stderr, 'load_1_5_15': list(os.getloadavg())}
            (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
            assert sampled.returncode == 0
            print(name, label, 'sampled', flush=True)
        finally:
            if proc.poll() is None:
                proc.terminate()
            try:
                _, errors = proc.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
                _, errors = proc.communicate(timeout=5)
            (root / (name + '-' + label + '.child-stderr.txt')).write_text(errors)
report['status'] = 'complete'
(root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

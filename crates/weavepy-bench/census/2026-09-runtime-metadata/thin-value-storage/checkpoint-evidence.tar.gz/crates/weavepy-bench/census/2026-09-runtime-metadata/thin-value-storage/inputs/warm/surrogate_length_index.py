
values = [str(i) + '\ud800\udfff' for i in range(256)]
def bench(n):
    total = 0
    for i in range(n):
        value = values[i & 255]
        total += len(value) + ord(value[-1])
    return total

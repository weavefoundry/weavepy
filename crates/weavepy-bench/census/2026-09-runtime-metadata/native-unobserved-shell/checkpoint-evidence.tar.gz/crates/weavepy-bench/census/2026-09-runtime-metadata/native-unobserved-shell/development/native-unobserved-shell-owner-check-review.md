# Recheck observation after exclusive ownership

The first shell-reuse draft reads has_materialized before Rc::get_mut. A check
made before acquiring exclusive ownership should not be relied on after another
observer releases its reference. The conservative predicate first obtains the
exclusive mutable shell reference and then reads has_materialized through it.
This removes dependence on GIL scheduling or a pre-acquisition flag read. It is
a source-review correction, not an observed failing Python run or measured
performance regression. The first draft passed all 353 VM and 156 C API tests,
lint, and no-JIT checks. Preserve those results and its complete source/method
snapshot. It has not been timed. Finish its active build before changing source,
then retain the executable separately. Re-run validation for the corrected
predicate and freeze new identities before any measurements.

# Post-binding native entry experiment

Compare one frozen candidate against its declared retained predecessor and
CPython 3.14.7. Before timing, pass the baseline and candidate argument-binding
regressions, native coverage proof, VM/static checks, targeted observer/lifetime/
recursion/side-exit tests, and full standard compatibility checks. Source and
executable identities must be preserved. No competing heavy work or runtime or
active harness edits during timing.

Ten call shapes use work=10000 with seven paired samples, JIT and interpreter
modes for each WeavePy binary and CPython. This includes positional/defaults,
sparse and variadic keywords, methods, bound methods, builtins, keyword-only,
closure, and extra-local-slot cases. Value checks additionally use -X gil=0.
Keep all samples, failures, and cache/load/VM/swap observations. The shared
harness uses one declared unmeasured cache stabilization cycle and alternating
variant order. No sample filtering or automatic retry.

Run the historical full 24-fixture census and nine startup/import cases after
the focused screen; report the 21-row historical cohort separately from the
23 workload timers and all 24 process metric rows. Busy-host diagnostics cannot
replace the preceding qualified headline. Any declared quiet-host gate must
retain its result even if it expires without starting measurements. No claims
of universal, energy, controlled build, portability, or free-threaded gains.


Before collecting any samples, add the four unchanged exception-frequency
controls from the corrected raise-exit experiment, work=5000. Measure each in
both warm and cold form with seven pairs. This makes 18 focused timing cases:
ten call shapes, four warm exception cases, and four cold exception cases.
Keep the groups and every individual result separate; these additions do not
change the historical or standard-suite cohorts. Existing no/rare/half/always
raising cases must all remain present, including the earlier always-raising
regression. Source bytes and work parameters are unchanged; verification
drivers point to the new copied input directory and have fresh hashes.

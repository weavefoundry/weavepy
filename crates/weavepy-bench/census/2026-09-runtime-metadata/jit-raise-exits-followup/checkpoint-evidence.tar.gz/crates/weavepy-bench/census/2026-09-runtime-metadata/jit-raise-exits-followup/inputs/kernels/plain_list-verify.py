VALUES = list(range(256))
def plain_list(values):
    total = 0
    for value in values:
        total += value
    return total

def bench(n):
    total = 0
    for i in range(n):
        total += plain_list(VALUES)
    return total

import json
for stage in range(2):
    if stage:
        bench(1000)
    value = bench(7)
    assert value == 228480
    print(json.dumps(value))

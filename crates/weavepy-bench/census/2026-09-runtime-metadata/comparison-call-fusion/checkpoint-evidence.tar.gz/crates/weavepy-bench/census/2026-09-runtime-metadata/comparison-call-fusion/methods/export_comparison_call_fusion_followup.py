"""Archive comparison-result fusion, corrected coverage, and all timing results."""
import gzip,hashlib,json,sys
from pathlib import Path
assert len(sys.argv)==2 and sys.argv[1] in ('deferred','retained-under-refinement')
decision=sys.argv[1]
parent=Path('crates/weavepy-bench/census/2026-09-runtime-metadata');out=parent/'comparison-call-fusion';assert not out.exists()
for group in ('focused','full'):
 assert Path('target/comparison-call-fusion-'+group+'/stage.txt').read_text().strip()=='done'
 assert json.loads(Path('target/comparison-call-fusion-'+group+'-load.json').read_text())['status']=='complete'
focused=json.loads(Path('target/comparison-call-fusion-focused/summary.json').read_text());full=json.loads(Path('target/comparison-call-fusion-full/summary.json').read_text())
checks=json.loads(Path('target/comparison-call-fusion-validation/validation.json').read_text());assert len(checks)==275 and all(r['passed'] for r in checks)
assert json.loads(Path('target/comparison-call-fusion-coverage-v2/report.json').read_text())['assertions_passed']
assert json.loads(Path('target/comparison-call-fusion-corrected-semantics/report.json').read_text())['status']=='passed'
assert json.loads(Path('target/comparison-call-fusion-extra-checks/report.json').read_text())['status']=='passed'
out.mkdir();records=[]
def copy(src,dst):
 src=Path(src);raw=src.read_bytes();data=raw
 if len(raw)>=65536 and src.suffix in ('.json','.txt','.diff') and not src.name.startswith('summary'):
  dst+='.gz';data=gzip.compress(raw,compresslevel=9,mtime=0)
 p=out/dst;assert not p.exists(),dst;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 records.append({'path':dst,'source':str(src),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'uncompressed_bytes':len(raw),'uncompressed_sha256':hashlib.sha256(raw).hexdigest()})
def folder(src,dst):
 for p in sorted(Path(src).iterdir()):
  if p.is_file() and p.suffix in ('.py','.json','.txt','.md','.sh','.patch'):copy(p,str(Path(dst)/p.name))
for group in ('focused','full'):folder('target/comparison-call-fusion-'+group,group)
for group in ('warm','cold'):
 copy('target/comparison-call-fusion-focused/'+group+'/measurements.json','focused/'+group+'.json')
 folder('target/integer-comparison-inputs/'+group,'inputs/'+group)
for group in ('checks','validation','extra-checks','coverage','coverage-v2','corrected-semantics'):
 folder('target/comparison-call-fusion-'+group,'checks/'+group)
for group in ('measurement-inputs','corrected-measurement-inputs'):
 folder('target/comparison-call-fusion-'+group,'methods/'+group)
for group in ('comparison-fusion-baseline-preflight','comparison-fusion-baseline-preflight-v2'):
 folder('target/'+group,'checks/'+group)
for group in ('source-snapshot','corrected-source-snapshot'):
 for name in ('environment.json','source-changes.diff','tests/regrtest/test_comparison_call_fusion.py'):
  copy('target/comparison-call-fusion-'+group+'/'+name,'candidate/'+group+'/'+name)
for group in ('comparison-call-fusion-draft','comparison-call-fusion-draft-v2'):
 for name in ('candidate.patch','index.json','README.md'):copy('target/'+group+'/'+name,'draft/'+group+'/'+name)
for p in sorted(Path('target').glob('comparison-call-fusion-*.txt')):copy(p,'logs/'+p.name)
for name in ('comparison-fusion-baseline-preflight.txt','comparison-fusion-baseline-preflight-v2.txt'):copy('target/'+name,'logs/'+name)
for name in ('comparison-call-fusion-focused-load.json','comparison-call-fusion-full-load.json','comparison-call-fusion-prebuild-sources.json','comparison-call-fusion-corrected-sources.json','performance_phase68_status.md'):copy('target/'+name,'conditions/'+name)
copy('target/test_comparison_call_fusion.py','checks/original-semantic-test.py');copy('target/test_comparison_call_fusion_v2.py','checks/corrected-semantic-test.py');copy(__file__,'methods/'+Path(__file__).name)
work=full['cohorts']['all_23_workloads_excluding_startup']['metrics']['jit']['ns'];hist=full['cohorts']['historical_21_including_startup']['metrics']['jit'];proc=full['cohorts']['all_processes_including_startup']['metrics']['jit']
lines=['# Fuse comparison call results','',f'Decision: {decision}. The overall performance goal remains unachieved.','',
'Candidate c27713f0 reuses the existing exact-integer CallDyn result for an',
'adjacent comparison or one separated only by a non-guarding scalar constant.',
'Other shapes retain their comparison-PC guard. Noninteger values and invalidated',
'globals park the completed return and resume after its producing call. Callback',
'effects, comparison results, and errors are preserved. No runtime helper, pin',
'lifetime, cache, execution policy, object field, or unsafe code changes.',
'The binary is 44,289,664 bytes, 128 bytes larger than immediate e709 and 144',
'bytes larger than the preceding assertion build ed99. Earlier optimizations',
'and their regressions are included. No build-time advantage is established.','',
'All 60 JIT tests, 342 VM tests, formatting, Clippy, and no-default-feature',
'checks pass. The original 75 targeted release checks and all six nonempty',
'extra comparison/integer/call/unittest suites pass. All 275 standard',
'compatibility checks pass. Original and corrected baseline evidence remains.','',
'The first native-coverage assertion failed: cmp_fusion_local remained in the',
'interpreter after an unseeded MixedArithTypes rejection. Its semantic pass was',
'not native coverage. The corrected integer-only fixture adds n = n + 0 before',
'comparison to establish the local lane, then passes CPython and unchanged e709',
'in three modes. It also passes all three c277 modes, and all 23 required',
'functions actually compile and rebuild. Only the Python test changed after',
'building; Rust sources and binary identity stayed unchanged. Original and',
'post-build corrected snapshots, methods, and failure logs remain separate.',
'Timing used only the v2 launcher requiring both corrected checks.','',
'The focused comparison retains 15 warm and four cold controls, work 5000,',
'seven pairs, and both modes of candidate, immediate e709, retained ed99, and',
'CPython. All inputs and drivers match the unfused experiment. All values and',
'frozen caches agree. GIL-disabled execution is a correctness control only.',
'Lower ratios are better. The ed99 reference measures the combined comparison',
'change; the e709 predecessor isolates this fusion refinement.','',
'| Case | Mode | Time / unfused e709 | Time / ed99 | RSS / ed99 | Time / CPython |',
'| --- | --- | ---: | ---: | ---: | ---: |']
for name,row in focused['rows'].items():
 for mode in ('jit','interp'):
  prev=row['new_over_previous'][mode];ref=row['new_over_reference'][mode];cp=row['new_over_cpython'][mode]
  lines.append(f"| {name} | {mode} | {prev['ns']:.4f} | {ref['ns']:.4f} | {ref['rss_bytes']:.4f} | {cp['ns']:.4f} |")
lines+=['','All paired samples, ranges, regressions, workload/process wall and CPU, RSS,',
'and cache observations remain. Four cold controls have process CPU but no',
'separate workload CPU timer. The persistent complex-callback regression must',
'not be hidden by the successful simple integer/branch controls.','',
'The full suite uses ed99 as baseline, with 24 unchanged fixtures at five pairs',
'and nine startup/import controls at 31 pairs. The startup helper disables JIT.',
'Both strict timing gates qualified; all later load, VM, and swap observations',
'remain. No outcome-based filtering or retry was performed.','',
f"The JIT 23-workload mean is {work['new_over_base']:.6f} of ed99 and",
f"{work['new_over_cpython']:.6f} of CPython, with {work['weavepy_wins']} time wins.",
f"The historical 21-fixture mean is {hist['ns']['new_over_cpython']:.6f} of CPython,",
f"or {hist['ratio_of_medians_new_over_cpython']:.6f} using ratios of medians.",'',
f"All-24 process wall/CPU/RSS ratios to ed99 are {proc['wall_ns']['new_over_base']:.6f},",
f"{proc['cpu_ns']['new_over_base']:.6f}, and {proc['rss_bytes']['new_over_base']:.6f}.",
f"Peak RSS is {proc['rss_bytes']['new_over_cpython']:.6f} of CPython with {proc['rss_bytes']['weavepy_wins']} wins.",'',
'Keep 21/23/24 cohorts distinct and use same-run pairs for attribution. No',
'universal, energy, controlled build-time, portability, or native parallel',
'performance superiority is established. Large raw text is compressed losslessly;',
'both stored and uncompressed hashes/sizes are indexed. Executables, frozen',
'caches, and unselected temporary files remain local. The separate thin-owner',
'prototype evidence is in ../thin-owner-prototypes/REPORT.md; no runtime memory',
'layout change is included in this comparison candidate.','']
(out/'REPORT.md').write_text('\n'.join(lines));p=out/'REPORT.md';records.append({'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});(out/'index.json').write_text(json.dumps(records,indent=2)+'\n')
for row in records:
 data=(out/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
 if 'uncompressed_sha256' in row:
  raw=gzip.decompress(data) if row['path'].endswith('.gz') else data;assert hashlib.sha256(raw).hexdigest()==row['uncompressed_sha256']
with (parent/'.gitignore').open('a') as f:
 f.write('\n# Comparison return fusion, corrected coverage, and every measurement.\n')
 for p in sorted(out.rglob('*')):
  if p.is_file():f.write('!'+str(p.relative_to(parent))+'\n')
with (parent/'README.md').open('a') as f:
 f.write('\nThe [comparison call-fusion follow-up](comparison-call-fusion/REPORT.md) retains\nsimple-call gains, persistent complex-callback regressions, full-suite results,\nand the corrected native-coverage fixture. Its decision is '+decision+'.\n')
print('Exported',len(records)+1,'files;',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes; stored/uncompressed hashes verified.')

#!/opt/homebrew/bin/python3.14
"""Capture the untruncated conformance child output for the I/O regression."""
import json
import os
from pathlib import Path
import subprocess
import sys

out = Path(os.environ['WEAVEPY_IO_DIAGNOSTIC_OUT'])
child = Path(os.environ['WEAVEPY_IO_DIAGNOSTIC_BINARY'])
assert out.is_dir() and not (out / 'child.json').exists()
command = [str(child), *sys.argv[1:]]
(out / 'child.json').write_text(json.dumps({'command': command, 'environment': {
    key: os.environ.get(key) for key in ['WEAVEPY_JIT', 'WEAVEPY_REGRTEST_CHILD',
        'WEAVEPY_CPYTHON_LIB', 'WEAVEPY_REGRTEST_RESOURCES', 'WEAVEPY_STDLIB_CACHE',
        'WEAVEPY_FROZEN_CACHE']}}, indent=2) + '\n')
result = subprocess.run(command, capture_output=True)
(out / 'child.stdout.txt').write_bytes(result.stdout)
(out / 'child.stderr.txt').write_bytes(result.stderr)
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
sys.exit(result.returncode)

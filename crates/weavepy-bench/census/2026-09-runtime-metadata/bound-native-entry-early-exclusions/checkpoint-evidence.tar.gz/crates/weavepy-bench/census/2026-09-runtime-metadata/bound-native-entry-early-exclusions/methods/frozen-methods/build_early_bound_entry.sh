#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-jit-raise-call-spans
binary=target/release/weavepy-runtime-early-bound-entry
test -f "$base"
test ! -e "$binary"
test ! -e target/early-bound-entry-build-stage.txt
printf '%s\n' "$base" > target/early-bound-entry-previous.txt
printf 'VM tests and static checks\n' > target/early-bound-entry-build-stage.txt
cargo fmt --all -- --check > target/early-bound-entry-format.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/early-bound-entry-vm-tests.txt 2>&1
cargo clippy --offline --locked -p weavepy-vm -p weavepy-jit --lib --tests -j 1 -- -D warnings > target/early-bound-entry-clippy.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/early-bound-entry-no-jit.txt 2>&1
printf 'release build\n' > target/early-bound-entry-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/early-bound-entry-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/early-bound-entry-source-snapshot --extra target/build_early_bound_entry.sh target/check_early_bound_entry.sh target/validate_early_bound_entry.sh target/inspect_early_bound_entry.py > target/early-bound-entry-snapshot.txt 2>&1
printf 'done\n' > target/early-bound-entry-build-stage.txt

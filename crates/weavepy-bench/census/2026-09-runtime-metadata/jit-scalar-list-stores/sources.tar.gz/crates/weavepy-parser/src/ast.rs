//! Abstract syntax tree for WeavePy.
//!
//! Node names and field names track CPython's `ast` module so that
//! tools written against `ast.parse` are easy to port. Each node has
//! a [`Span`] into the original source; spans are byte-based to match
//! the lexer.
//!
//! # Compatibility level
//!
//! - **Tracks CPython** for node names (`Module`, `FunctionDef`, etc.)
//!   and field names (`body`, `orelse`, `args`, `kwargs`, `target`,
//!   `iter`, `value`, …).
//! - **Experimental** for the slice of the grammar represented. The
//!   async statement / expression nodes (`AsyncFunctionDef`,
//!   `AsyncFor`, `AsyncWith`, `Await`) are produced by the parser
//!   from RFC 0016 onwards.

use weavepy_lexer::Span;

// ---------- top-level ----------

/// A complete Python module — the result of parsing a source file.
#[derive(Debug, Clone, Default, PartialEq)]
pub struct Module {
    pub body: Vec<Stmt>,
}

// ---------- statements ----------

#[derive(Debug, Clone, PartialEq)]
pub struct Stmt {
    pub kind: StmtKind,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq)]
pub enum StmtKind {
    /// `def name[T](args) -> returns: body`
    FunctionDef {
        name: String,
        args: Arguments,
        body: Vec<Stmt>,
        decorator_list: Vec<Expr>,
        /// PEP 695 type parameters (`def f[T, U](…)`).
        type_params: Vec<TypeParam>,
        /// `-> annotation`, evaluated at definition time.
        returns: Option<Box<Expr>>,
    },
    /// `async def name(args): body` (PEP 492, RFC 0016). Same shape
    /// as [`StmtKind::FunctionDef`]; the compiler routes the body
    /// through the coroutine-aware code path.
    AsyncFunctionDef {
        name: String,
        args: Arguments,
        body: Vec<Stmt>,
        decorator_list: Vec<Expr>,
        /// PEP 695 type parameters.
        type_params: Vec<TypeParam>,
        /// `-> annotation`, evaluated at definition time.
        returns: Option<Box<Expr>>,
    },
    /// `class name(bases, **keywords): body`
    ClassDef {
        name: String,
        bases: Vec<Expr>,
        keywords: Vec<Keyword>,
        body: Vec<Stmt>,
        decorator_list: Vec<Expr>,
        /// PEP 695 type parameters (`class C[T](…)`).
        type_params: Vec<TypeParam>,
    },
    /// PEP 695 `type Name[T, …] = value`. The compiler emits
    /// `CALL_INTRINSIC_1 INTRINSIC_TYPEALIAS` over the name, the
    /// type-parameter tuple, and a lazy value thunk (CPython
    /// `codegen_typealias`).
    TypeAlias {
        name: String,
        /// Span of the alias-name token (for `ast.TypeAlias.name`).
        name_span: Span,
        /// PEP 695 type parameters (`type X[T, U] = …`).
        type_params: Vec<TypeParam>,
        value: Box<Expr>,
    },
    /// `return value`
    Return(Option<Expr>),
    /// `target = value` (and multi-target: `a = b = c = ...`)
    Assign {
        targets: Vec<Expr>,
        value: Expr,
    },
    /// `target op= value`
    AugAssign {
        target: Expr,
        op: BinOp,
        value: Expr,
    },
    /// `target: annotation = value` (annotation kept for parity with CPython;
    /// not interpreted by the compiler yet).
    AnnAssign {
        target: Expr,
        annotation: Expr,
        value: Option<Expr>,
        /// CPython's `simple` flag: a bare (unparenthesized) `Name`
        /// target. Only simple targets are recorded in
        /// `__annotations__` (`(pars): bool = True` binds but does not
        /// annotate).
        simple: bool,
    },
    /// `if test: body [else: orelse]` with elif chains folded into `orelse`.
    If {
        test: Expr,
        body: Vec<Stmt>,
        orelse: Vec<Stmt>,
    },
    /// `while test: body else: orelse`
    While {
        test: Expr,
        body: Vec<Stmt>,
        orelse: Vec<Stmt>,
    },
    /// `for target in iter: body else: orelse`
    For {
        target: Expr,
        iter: Expr,
        body: Vec<Stmt>,
        orelse: Vec<Stmt>,
    },
    /// `async for target in iter: body else: orelse` (PEP 492,
    /// RFC 0016). Valid only inside an `async def`; we don't
    /// enforce that at parse time — the compiler does.
    AsyncFor {
        target: Expr,
        iter: Expr,
        body: Vec<Stmt>,
        orelse: Vec<Stmt>,
    },
    /// `try: body except: handlers else: orelse finally: finalbody`
    Try {
        body: Vec<Stmt>,
        handlers: Vec<ExceptHandler>,
        orelse: Vec<Stmt>,
        finalbody: Vec<Stmt>,
    },
    /// `raise [exc [from cause]]`
    Raise {
        exc: Option<Expr>,
        cause: Option<Expr>,
    },
    /// `with items: body`
    With {
        items: Vec<WithItem>,
        body: Vec<Stmt>,
    },
    /// `async with items: body` (PEP 492, RFC 0016).
    AsyncWith {
        items: Vec<WithItem>,
        body: Vec<Stmt>,
    },
    /// `import a, b as c`
    Import(Vec<Alias>),
    /// `from m import a, b as c` (or `from m import *`)
    ImportFrom {
        module: Option<String>,
        names: Vec<Alias>,
        level: u32,
    },
    /// `global a, b`
    Global(Vec<String>),
    /// `nonlocal a, b`
    Nonlocal(Vec<String>),
    /// `match subject: case ...:` (PEP 634 / RFC 0009).
    Match {
        subject: Expr,
        cases: Vec<MatchCase>,
    },
    /// Expression statement.
    Expr(Expr),
    Pass,
    Break,
    Continue,
    /// `del a, b[idx], c.attr`. Each target is one of the assignable
    /// expression forms (`Name`, `Subscript`, `Attribute`, `Tuple`,
    /// or `List`); the compiler lowers each to its delete opcode.
    Delete(Vec<Expr>),
    /// `assert test [, msg]`. Lowered to a conditional `raise
    /// AssertionError(msg)`; elided entirely under `-O` (the
    /// compiler honours `optimize >= 1`).
    Assert {
        test: Expr,
        msg: Option<Expr>,
    },
}

/// One PEP 695 type parameter (`T`, `T: bound`, `T: (c1, c2)`,
/// `*Ts`, `**P`), optionally with a PEP 696 `= default`.
///
/// Mirrors CPython's `ast.TypeVar` / `ast.TypeVarTuple` /
/// `ast.ParamSpec` nodes.
#[derive(Debug, Clone, PartialEq)]
pub struct TypeParam {
    pub name: String,
    /// The verbatim source spelling, for the runtime object's
    /// `__name__`. Stays fixed when private-name mangling rewrites
    /// `name` (and when the source literally spells a mangled-looking
    /// name like `_ClassA__A`, which must *not* be demangled).
    pub source_name: String,
    pub kind: TypeParamKind,
    /// PEP 696 `= default` expression (lazily evaluated at runtime).
    /// For a `TypeVarTuple`, a starred default (`*Ts = *tuple[int]`)
    /// is stored as `Starred(...)` and unpacks at evaluation time.
    pub default: Option<Box<Expr>>,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq)]
pub enum TypeParamKind {
    /// `T` or `T: bound`. A parenthesized tuple bound
    /// (`T: (int, str)`) means *constraints*, per PEP 695; the
    /// compiler keys off `ExprKind::Tuple`.
    TypeVar { bound: Option<Box<Expr>> },
    /// `*Ts`.
    TypeVarTuple,
    /// `**P`.
    ParamSpec,
}

/// One `case` clause inside a `match` statement (RFC 0009).
#[derive(Debug, Clone, PartialEq)]
pub struct MatchCase {
    pub pattern: Pattern,
    pub guard: Option<Expr>,
    pub body: Vec<Stmt>,
    pub span: Span,
}

/// A pattern in a `case` clause: variant plus source span (CPython
/// `pattern` nodes carry positions like every other AST node).
#[derive(Debug, Clone, PartialEq)]
pub struct Pattern {
    pub kind: PatternKind,
    pub span: Span,
}

/// Pattern variants. Each corresponds 1:1 to a CPython `Match*` AST
/// node so `ast.dump` output lines up.
#[derive(Debug, Clone, PartialEq)]
pub enum PatternKind {
    /// Literal value patterns: `0`, `"x"`, `Color.RED`. The `Expr`
    /// must be a constant or a dotted attribute chain.
    Value(Expr),
    /// `None` / `True` / `False`.
    Singleton(Constant),
    /// Capture pattern (`x`) or wildcard (`_` → `None`).
    Capture(Option<String>),
    /// `[p1, p2, *rest]` or `(p1, p2)`.
    Sequence(Vec<Pattern>),
    /// `*rest` inside a sequence (or `*_` to discard).
    Star(Option<String>),
    /// `{k: p, **rest}`.
    Mapping {
        keys: Vec<Expr>,
        patterns: Vec<Pattern>,
        rest: Option<Option<String>>,
    },
    /// `Cls(pos1, pos2, key=val)`.
    Class {
        cls: Expr,
        positionals: Vec<Pattern>,
        keywords: Vec<(String, Pattern)>,
    },
    /// `p1 | p2 | p3`.
    Or(Vec<Pattern>),
    /// `pattern as name`.
    As { pattern: Box<Pattern>, name: String },
}

/// `except [E [as e]]: body` clause.
#[derive(Debug, Clone, PartialEq)]
pub struct ExceptHandler {
    /// `None` means a bare `except:` clause.
    pub type_: Option<Expr>,
    pub name: Option<String>,
    pub body: Vec<Stmt>,
    pub span: Span,
    /// PEP 654 / RFC 0018: `True` when the source uses
    /// `except*` to match against an exception group. The
    /// compiler emits the splitting variant instead of the plain
    /// `CheckExcMatch` path.
    pub is_star: bool,
}

/// `with expr [as target]` element. Multi-context `with` carries one per
/// listed item.
#[derive(Debug, Clone, PartialEq)]
pub struct WithItem {
    pub context_expr: Expr,
    pub optional_vars: Option<Expr>,
}

/// `import x as y` / `from m import (n[, n]…)` element.
#[derive(Debug, Clone, PartialEq)]
pub struct Alias {
    pub name: String,
    pub asname: Option<String>,
    /// Covers `name [as asname]` (CPython `alias` nodes carry positions).
    pub span: Span,
}

// ---------- function arguments ----------

/// Parameter list of a function or lambda. Mirrors CPython's
/// `ast.arguments` shape (with `posonlyargs`/`args`/`vararg`/
/// `kwonlyargs`/`kwarg`).
#[derive(Debug, Clone, Default, PartialEq)]
pub struct Arguments {
    pub posonlyargs: Vec<Arg>,
    pub args: Vec<Arg>,
    pub vararg: Option<Arg>,
    pub kwonlyargs: Vec<Arg>,
    pub kw_defaults: Vec<Option<Expr>>,
    pub kwarg: Option<Arg>,
    pub defaults: Vec<Expr>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Arg {
    pub name: String,
    pub annotation: Option<Box<Expr>>,
    pub span: Span,
}

// ---------- expressions ----------

#[derive(Debug, Clone, PartialEq)]
pub struct Expr {
    pub kind: ExprKind,
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq)]
pub enum ExprKind {
    /// Literal constant: `None`, `True`, `42`, `"hello"`, etc.
    Constant(Constant),
    /// Bare name reference.
    Name(String),
    /// `obj.attr`
    Attribute {
        value: Box<Expr>,
        attr: String,
    },
    /// `obj[idx]` — `idx` may be a `Slice`.
    Subscript {
        value: Box<Expr>,
        slice: Box<Expr>,
    },
    /// `a:b:c` — explicit slice node, used inside `Subscript.slice`.
    Slice {
        lower: Option<Box<Expr>>,
        upper: Option<Box<Expr>>,
        step: Option<Box<Expr>>,
    },
    BinOp {
        left: Box<Expr>,
        op: BinOp,
        right: Box<Expr>,
    },
    BoolOp {
        op: BoolOp,
        values: Vec<Expr>,
    },
    UnaryOp {
        op: UnaryOp,
        operand: Box<Expr>,
    },
    Compare {
        left: Box<Expr>,
        ops: Vec<CmpOp>,
        comparators: Vec<Expr>,
    },
    /// `value if test else orelse`
    IfExp {
        test: Box<Expr>,
        body: Box<Expr>,
        orelse: Box<Expr>,
    },
    /// `target := value`
    NamedExpr {
        target: Box<Expr>,
        value: Box<Expr>,
    },
    /// `lambda args: body`
    Lambda {
        args: Arguments,
        body: Box<Expr>,
    },
    /// A compiler-generated PEP 695 *annotation scope* function — never
    /// produced by user syntax. Shaped like a lambda, but the compiler
    /// gives it CPython's lazy-evaluation scoping: inside a class body
    /// its free names resolve through the live class dict first
    /// (`LOAD_FROM_DICT_OR_DEREF` / `__classdict__`). Used for
    /// TypeVar bounds/constraints/defaults, `type X = …` alias values,
    /// and the per-parameter binder lambdas of a generic alias.
    TypeParamFn {
        args: Arguments,
        body: Box<Expr>,
    },
    Call {
        func: Box<Expr>,
        args: Vec<Expr>,
        keywords: Vec<Keyword>,
    },
    Tuple(Vec<Expr>),
    List(Vec<Expr>),
    Set(Vec<Expr>),
    Dict {
        keys: Vec<Option<Expr>>,
        values: Vec<Expr>,
    },
    ListComp {
        elt: Box<Expr>,
        generators: Vec<Comprehension>,
    },
    SetComp {
        elt: Box<Expr>,
        generators: Vec<Comprehension>,
    },
    DictComp {
        key: Box<Expr>,
        value: Box<Expr>,
        generators: Vec<Comprehension>,
    },
    GeneratorExp {
        elt: Box<Expr>,
        generators: Vec<Comprehension>,
    },
    /// `*expr` in a call / tuple / list. (CPython has a `Starred` node.)
    Starred(Box<Expr>),
    /// `yield` or `yield value` (RFC 0006). The optional value is the
    /// expression yielded; bare `yield` yields `None`.
    Yield(Option<Box<Expr>>),
    /// `yield from value` (RFC 0006).
    YieldFrom(Box<Expr>),
    /// `await value` (PEP 492, RFC 0016). Valid only inside an
    /// `async def`; the compiler enforces that.
    Await(Box<Expr>),
    /// f-string body — a list of `Constant(Str)` and `FormattedValue`
    /// nodes. Plain f-strings like `f"abc"` lower to a single
    /// `Constant`; `JoinedStr` wraps anything with interpolations
    /// (RFC 0005).
    JoinedStr(Vec<Expr>),
    /// One `{value!conv:spec}` inside an f-string (RFC 0005).
    /// `conversion` is `-1` (none), `'s'`, `'r'`, or `'a'`.
    FormattedValue {
        value: Box<Expr>,
        conversion: i32,
        /// `None` for `{x}`; `Some(JoinedStr(...))` for `{x:spec}`.
        format_spec: Option<Box<Expr>>,
    },
    /// PEP 750 t-string body (`-X lang=next` preview, RFC 0076 WS15) — a
    /// list of `Constant(Str)` and `Interpolation` nodes, mirroring
    /// CPython 3.14's `TemplateStr`.
    TemplateStr(Vec<Expr>),
    /// One `{value!conv:spec}` inside a t-string (CPython 3.14
    /// `Interpolation`). Unlike `FormattedValue`, the verbatim source
    /// text of the expression is kept for `Interpolation.expression`.
    Interpolation {
        value: Box<Expr>,
        /// Source text of the interpolated expression.
        text: String,
        /// `-1` (none), `'s'`, `'r'`, or `'a'`.
        conversion: i32,
        /// `None` for `{x}`; `Some(JoinedStr(...))` for `{x:spec}` —
        /// eagerly evaluated to a `str` at template construction time.
        format_spec: Option<Box<Expr>>,
    },
}

/// CPython's `_PyPegen_get_expr_name`: how an expression is described in
/// "cannot assign to X" / "cannot delete X" syntax errors.
pub fn expr_name(expr: &Expr) -> &'static str {
    match &expr.kind {
        ExprKind::Constant(c) => match c {
            Constant::None => "None",
            Constant::Bool(true) => "True",
            Constant::Bool(false) => "False",
            Constant::Ellipsis => "ellipsis",
            _ => "literal",
        },
        ExprKind::Name(_) => "name",
        ExprKind::Attribute { .. } => "attribute",
        ExprKind::Subscript { .. } => "subscript",
        ExprKind::Starred(_) => "starred expression",
        ExprKind::Tuple(_) => "tuple",
        ExprKind::List(_) => "list",
        ExprKind::Dict { .. } => "dict literal",
        ExprKind::Set(_) => "set display",
        ExprKind::Lambda { .. } | ExprKind::TypeParamFn { .. } => "lambda",
        ExprKind::Call { .. } => "function call",
        ExprKind::BoolOp { .. } | ExprKind::BinOp { .. } | ExprKind::UnaryOp { .. } => "expression",
        ExprKind::GeneratorExp { .. } => "generator expression",
        ExprKind::Yield(_) | ExprKind::YieldFrom(_) => "yield expression",
        ExprKind::Await(_) => "await expression",
        ExprKind::ListComp { .. } => "list comprehension",
        ExprKind::SetComp { .. } => "set comprehension",
        ExprKind::DictComp { .. } => "dict comprehension",
        ExprKind::JoinedStr(_) | ExprKind::FormattedValue { .. } => "f-string expression",
        ExprKind::TemplateStr(_) | ExprKind::Interpolation { .. } => "t-string expression",
        ExprKind::Compare { .. } => "comparison",
        ExprKind::IfExp { .. } => "conditional expression",
        ExprKind::NamedExpr { .. } => "named expression",
        ExprKind::Slice { .. } => "slice",
    }
}

/// `**kw=value` keyword argument in a call.
#[derive(Debug, Clone, PartialEq)]
pub struct Keyword {
    /// `None` represents `**kwargs` splat.
    pub arg: Option<String>,
    pub value: Expr,
    /// Covers `name=value` / `**value` (CPython `keyword` nodes carry
    /// positions since 3.9).
    pub span: Span,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Comprehension {
    pub target: Expr,
    pub iter: Expr,
    pub ifs: Vec<Expr>,
    pub is_async: bool,
}

// ---------- literal constants ----------

#[derive(Debug, Clone, PartialEq)]
pub enum Constant {
    None,
    Bool(bool),
    Int(i64),
    /// Arbitrary-precision integer literal (RFC 0019).
    ///
    /// The compiler emits `Object::Long` for these. Represented as a
    /// decimal-string + sign so the AST stays cheap to clone and
    /// `PartialEq`-able without reaching for `num_bigint::BigInt` here.
    BigInt(String),
    Float(f64),
    /// `(real, imag)` for complex literals (RFC 0019). The lexer
    /// already accepts the trailing `j`/`J`; the parser routes the
    /// numeric body here.
    Complex(f64, f64),
    Str(String),
    /// A `str` literal containing at least one lone surrogate
    /// (U+D800..U+DFFF), which Rust's UTF-8 `String` cannot represent —
    /// produced by `'\udxxx'`/`\uXXXX`/`\xXX`/`\N{}` escapes that resolve to a
    /// surrogate. Stored as code points; the compiler lowers it to an
    /// `Object::WStr` constant. Disjoint from [`Constant::Str`]: a value with
    /// no surrogate always canonicalises back to `Str`.
    WStr(Vec<u32>),
    Bytes(Vec<u8>),
    Tuple(Vec<Constant>),
    /// `frozenset` constant. Never produced by the parser (there is no
    /// frozenset literal); appears only when `compile()` lowers a
    /// caller-built `ast.Constant(frozenset(...))` node.
    FrozenSet(Vec<Constant>),
    Ellipsis,
}

// ---------- operators ----------

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BinOp {
    Add,
    Sub,
    Mult,
    MatMult,
    Div,
    Mod,
    Pow,
    LShift,
    RShift,
    BitOr,
    BitXor,
    BitAnd,
    FloorDiv,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BoolOp {
    And,
    Or,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UnaryOp {
    Invert,
    Not,
    UAdd,
    USub,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CmpOp {
    Eq,
    NotEq,
    Lt,
    LtE,
    Gt,
    GtE,
    Is,
    IsNot,
    In,
    NotIn,
}

impl CmpOp {
    pub fn as_str(self) -> &'static str {
        match self {
            CmpOp::Eq => "Eq",
            CmpOp::NotEq => "NotEq",
            CmpOp::Lt => "Lt",
            CmpOp::LtE => "LtE",
            CmpOp::Gt => "Gt",
            CmpOp::GtE => "GtE",
            CmpOp::Is => "Is",
            CmpOp::IsNot => "IsNot",
            CmpOp::In => "In",
            CmpOp::NotIn => "NotIn",
        }
    }
}

impl BinOp {
    pub fn as_str(self) -> &'static str {
        match self {
            BinOp::Add => "Add",
            BinOp::Sub => "Sub",
            BinOp::Mult => "Mult",
            BinOp::MatMult => "MatMult",
            BinOp::Div => "Div",
            BinOp::Mod => "Mod",
            BinOp::Pow => "Pow",
            BinOp::LShift => "LShift",
            BinOp::RShift => "RShift",
            BinOp::BitOr => "BitOr",
            BinOp::BitXor => "BitXor",
            BinOp::BitAnd => "BitAnd",
            BinOp::FloorDiv => "FloorDiv",
        }
    }
}

impl UnaryOp {
    pub fn as_str(self) -> &'static str {
        match self {
            UnaryOp::Invert => "Invert",
            UnaryOp::Not => "Not",
            UnaryOp::UAdd => "UAdd",
            UnaryOp::USub => "USub",
        }
    }
}

impl BoolOp {
    pub fn as_str(self) -> &'static str {
        match self {
            BoolOp::And => "And",
            BoolOp::Or => "Or",
        }
    }
}

// ---------- ast.dump-style rendering ----------

/// Render a [`Module`] in a form close to CPython's
/// `ast.dump(tree, indent=2)`. Used by the conformance harness.
pub fn dump_module(module: &Module) -> String {
    let mut out = String::new();
    out.push_str("Module(\n  body=[");
    if !module.body.is_empty() {
        out.push('\n');
        for s in &module.body {
            indent(&mut out, 4);
            dump_stmt(&mut out, s, 4);
            out.push_str(",\n");
        }
        indent(&mut out, 2);
    }
    out.push_str("],\n  type_ignores=[])");
    out
}

fn indent(out: &mut String, n: usize) {
    for _ in 0..n {
        out.push(' ');
    }
}

fn dump_stmt(out: &mut String, s: &Stmt, depth: usize) {
    use StmtKind as S;
    match &s.kind {
        S::FunctionDef {
            name,
            args,
            body,
            decorator_list,
            returns,
            ..
        } => {
            out.push_str("FunctionDef(name='");
            out.push_str(name);
            out.push_str("', args=");
            dump_arguments(out, args, depth + 2);
            out.push_str(", body=");
            dump_stmt_block(out, body, depth + 2);
            out.push_str(", decorator_list=[");
            for (i, d) in decorator_list.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, d, depth);
            }
            out.push_str("], returns=");
            match returns {
                Some(r) => dump_expr(out, r, depth),
                None => out.push_str("None"),
            }
            out.push_str(", type_comment=None)");
        }
        S::TypeAlias {
            name,
            type_params,
            value,
            ..
        } => {
            out.push_str("TypeAlias(name=Name(id='");
            out.push_str(name);
            out.push_str("', ctx=Store()), type_params=[");
            for (i, tp) in type_params.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                let ctor = match tp.kind {
                    TypeParamKind::TypeVar { .. } => "TypeVar",
                    TypeParamKind::TypeVarTuple => "TypeVarTuple",
                    TypeParamKind::ParamSpec => "ParamSpec",
                };
                out.push_str(ctor);
                out.push_str("(name='");
                out.push_str(&tp.source_name);
                out.push_str("')");
            }
            out.push_str("], value=");
            dump_expr(out, value, depth);
            out.push(')');
        }
        S::AsyncFunctionDef {
            name,
            args,
            body,
            decorator_list,
            returns,
            ..
        } => {
            out.push_str("AsyncFunctionDef(name='");
            out.push_str(name);
            out.push_str("', args=");
            dump_arguments(out, args, depth + 2);
            out.push_str(", body=");
            dump_stmt_block(out, body, depth + 2);
            out.push_str(", decorator_list=[");
            for (i, d) in decorator_list.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, d, depth);
            }
            out.push_str("], returns=");
            match returns {
                Some(r) => dump_expr(out, r, depth),
                None => out.push_str("None"),
            }
            out.push_str(", type_comment=None)");
        }
        S::ClassDef {
            name,
            bases,
            keywords,
            body,
            decorator_list,
            ..
        } => {
            out.push_str("ClassDef(name='");
            out.push_str(name);
            out.push_str("', bases=[");
            for (i, b) in bases.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, b, depth);
            }
            out.push_str("], keywords=[");
            for (i, k) in keywords.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push_str("keyword(arg=");
                match &k.arg {
                    Some(n) => {
                        out.push('\'');
                        out.push_str(n);
                        out.push('\'');
                    }
                    None => out.push_str("None"),
                }
                out.push_str(", value=");
                dump_expr(out, &k.value, depth);
                out.push(')');
            }
            out.push_str("], body=");
            dump_stmt_block(out, body, depth + 2);
            out.push_str(", decorator_list=[");
            for (i, d) in decorator_list.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, d, depth);
            }
            out.push_str("])");
        }
        S::Try {
            body,
            handlers,
            orelse,
            finalbody,
        } => {
            out.push_str("Try(body=");
            dump_stmt_block(out, body, depth + 2);
            out.push_str(", handlers=[");
            for (i, h) in handlers.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push_str("ExceptHandler(type=");
                match &h.type_ {
                    Some(t) => dump_expr(out, t, depth),
                    None => out.push_str("None"),
                }
                out.push_str(", name=");
                match &h.name {
                    Some(n) => {
                        out.push('\'');
                        out.push_str(n);
                        out.push('\'');
                    }
                    None => out.push_str("None"),
                }
                out.push_str(", body=");
                dump_stmt_block(out, &h.body, depth + 2);
                out.push(')');
            }
            out.push_str("], orelse=");
            dump_stmt_block(out, orelse, depth + 2);
            out.push_str(", finalbody=");
            dump_stmt_block(out, finalbody, depth + 2);
            out.push(')');
        }
        S::Raise { exc, cause } => {
            out.push_str("Raise(exc=");
            match exc {
                Some(e) => dump_expr(out, e, depth),
                None => out.push_str("None"),
            }
            out.push_str(", cause=");
            match cause {
                Some(c) => dump_expr(out, c, depth),
                None => out.push_str("None"),
            }
            out.push(')');
        }
        S::With { items, body } => {
            out.push_str("With(items=[");
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push_str("withitem(context_expr=");
                dump_expr(out, &it.context_expr, depth);
                out.push_str(", optional_vars=");
                match &it.optional_vars {
                    Some(v) => dump_expr(out, v, depth),
                    None => out.push_str("None"),
                }
                out.push(')');
            }
            out.push_str("], body=");
            dump_stmt_block(out, body, depth + 2);
            out.push(')');
        }
        S::AsyncWith { items, body } => {
            out.push_str("AsyncWith(items=[");
            for (i, it) in items.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push_str("withitem(context_expr=");
                dump_expr(out, &it.context_expr, depth);
                out.push_str(", optional_vars=");
                match &it.optional_vars {
                    Some(v) => dump_expr(out, v, depth),
                    None => out.push_str("None"),
                }
                out.push(')');
            }
            out.push_str("], body=");
            dump_stmt_block(out, body, depth + 2);
            out.push(')');
        }
        S::Return(value) => {
            out.push_str("Return(value=");
            if let Some(v) = value {
                dump_expr(out, v, depth);
            } else {
                out.push_str("None");
            }
            out.push(')');
        }
        S::Assign { targets, value } => {
            out.push_str("Assign(targets=[");
            for (i, t) in targets.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, t, depth);
            }
            out.push_str("], value=");
            dump_expr(out, value, depth);
            out.push(')');
        }
        S::AugAssign { target, op, value } => {
            out.push_str("AugAssign(target=");
            dump_expr(out, target, depth);
            out.push_str(", op=");
            out.push_str(op.as_str());
            out.push_str("(), value=");
            dump_expr(out, value, depth);
            out.push(')');
        }
        S::AnnAssign {
            target,
            annotation,
            value,
            simple,
        } => {
            out.push_str("AnnAssign(target=");
            dump_expr(out, target, depth);
            out.push_str(", annotation=");
            dump_expr(out, annotation, depth);
            out.push_str(", value=");
            if let Some(v) = value {
                dump_expr(out, v, depth);
            } else {
                out.push_str("None");
            }
            out.push_str(if *simple {
                ", simple=1)"
            } else {
                ", simple=0)"
            });
        }
        S::If { test, body, orelse } => {
            out.push_str("If(test=");
            dump_expr(out, test, depth);
            out.push_str(", body=");
            dump_stmt_block(out, body, depth + 2);
            out.push_str(", orelse=");
            dump_stmt_block(out, orelse, depth + 2);
            out.push(')');
        }
        S::While { test, body, orelse } => {
            out.push_str("While(test=");
            dump_expr(out, test, depth);
            out.push_str(", body=");
            dump_stmt_block(out, body, depth + 2);
            out.push_str(", orelse=");
            dump_stmt_block(out, orelse, depth + 2);
            out.push(')');
        }
        S::For {
            target,
            iter,
            body,
            orelse,
        } => {
            out.push_str("For(target=");
            dump_expr(out, target, depth);
            out.push_str(", iter=");
            dump_expr(out, iter, depth);
            out.push_str(", body=");
            dump_stmt_block(out, body, depth + 2);
            out.push_str(", orelse=");
            dump_stmt_block(out, orelse, depth + 2);
            out.push(')');
        }
        S::AsyncFor {
            target,
            iter,
            body,
            orelse,
        } => {
            out.push_str("AsyncFor(target=");
            dump_expr(out, target, depth);
            out.push_str(", iter=");
            dump_expr(out, iter, depth);
            out.push_str(", body=");
            dump_stmt_block(out, body, depth + 2);
            out.push_str(", orelse=");
            dump_stmt_block(out, orelse, depth + 2);
            out.push(')');
        }
        S::Import(aliases) => {
            out.push_str("Import(names=[");
            for (i, a) in aliases.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_alias(out, a);
            }
            out.push_str("])");
        }
        S::ImportFrom {
            module,
            names,
            level,
        } => {
            out.push_str("ImportFrom(module=");
            match module {
                Some(m) => {
                    out.push('\'');
                    out.push_str(m);
                    out.push('\'');
                }
                None => out.push_str("None"),
            }
            out.push_str(", names=[");
            for (i, a) in names.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_alias(out, a);
            }
            out.push_str("], level=");
            out.push_str(&level.to_string());
            out.push(')');
        }
        S::Global(names) => {
            out.push_str("Global(names=[");
            for (i, n) in names.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push('\'');
                out.push_str(n);
                out.push('\'');
            }
            out.push_str("])");
        }
        S::Nonlocal(names) => {
            out.push_str("Nonlocal(names=[");
            for (i, n) in names.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push('\'');
                out.push_str(n);
                out.push('\'');
            }
            out.push_str("])");
        }
        S::Match { subject, cases } => {
            out.push_str("Match(subject=");
            dump_expr(out, subject, depth);
            out.push_str(", cases=[");
            for (i, c) in cases.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push_str("match_case(pattern=");
                dump_pattern(out, &c.pattern, depth);
                out.push_str(", guard=");
                match &c.guard {
                    Some(g) => dump_expr(out, g, depth),
                    None => out.push_str("None"),
                }
                out.push_str(", body=");
                dump_stmt_block(out, &c.body, depth + 2);
                out.push(')');
            }
            out.push_str("])");
        }
        S::Expr(e) => {
            out.push_str("Expr(value=");
            dump_expr(out, e, depth);
            out.push(')');
        }
        S::Pass => out.push_str("Pass()"),
        S::Break => out.push_str("Break()"),
        S::Continue => out.push_str("Continue()"),
        S::Delete(targets) => {
            out.push_str("Delete(targets=[");
            for (i, t) in targets.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, t, depth);
            }
            out.push_str("])");
        }
        S::Assert { test, msg } => {
            out.push_str("Assert(test=");
            dump_expr(out, test, depth);
            out.push_str(", msg=");
            match msg {
                Some(m) => dump_expr(out, m, depth),
                None => out.push_str("None"),
            }
            out.push(')');
        }
    }
}

fn dump_pattern(out: &mut String, p: &Pattern, depth: usize) {
    match &p.kind {
        PatternKind::Value(e) => {
            out.push_str("MatchValue(value=");
            dump_expr(out, e, depth);
            out.push(')');
        }
        PatternKind::Singleton(c) => {
            out.push_str("MatchSingleton(value=");
            dump_constant(out, c);
            out.push(')');
        }
        PatternKind::Capture(name) => match name {
            Some(n) => {
                out.push_str("MatchAs(pattern=None, name='");
                out.push_str(n);
                out.push_str("')");
            }
            None => out.push_str("MatchAs(pattern=None, name=None)"),
        },
        PatternKind::Sequence(items) => {
            out.push_str("MatchSequence(patterns=[");
            for (i, x) in items.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_pattern(out, x, depth);
            }
            out.push_str("])");
        }
        PatternKind::Star(name) => match name {
            Some(n) => {
                out.push_str("MatchStar(name='");
                out.push_str(n);
                out.push_str("')");
            }
            None => out.push_str("MatchStar(name=None)"),
        },
        PatternKind::Mapping {
            keys,
            patterns,
            rest,
        } => {
            out.push_str("MatchMapping(keys=[");
            for (i, k) in keys.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, k, depth);
            }
            out.push_str("], patterns=[");
            for (i, p) in patterns.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_pattern(out, p, depth);
            }
            out.push_str("], rest=");
            match rest {
                Some(Some(n)) => {
                    out.push('\'');
                    out.push_str(n);
                    out.push('\'');
                }
                Some(None) => out.push_str("None"),
                None => out.push_str("None"),
            }
            out.push(')');
        }
        PatternKind::Class {
            cls,
            positionals,
            keywords,
        } => {
            out.push_str("MatchClass(cls=");
            dump_expr(out, cls, depth);
            out.push_str(", patterns=[");
            for (i, p) in positionals.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_pattern(out, p, depth);
            }
            out.push_str("], kwd_attrs=[");
            for (i, (n, _)) in keywords.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push('\'');
                out.push_str(n);
                out.push('\'');
            }
            out.push_str("], kwd_patterns=[");
            for (i, (_, p)) in keywords.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_pattern(out, p, depth);
            }
            out.push_str("])");
        }
        PatternKind::Or(items) => {
            out.push_str("MatchOr(patterns=[");
            for (i, x) in items.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_pattern(out, x, depth);
            }
            out.push_str("])");
        }
        PatternKind::As { pattern, name } => {
            out.push_str("MatchAs(pattern=");
            dump_pattern(out, pattern, depth);
            out.push_str(", name='");
            out.push_str(name);
            out.push_str("')");
        }
    }
}

fn dump_stmt_block(out: &mut String, stmts: &[Stmt], depth: usize) {
    out.push('[');
    for (i, s) in stmts.iter().enumerate() {
        if i > 0 {
            out.push_str(", ");
        }
        dump_stmt(out, s, depth);
    }
    out.push(']');
}

fn dump_alias(out: &mut String, a: &Alias) {
    out.push_str("alias(name='");
    out.push_str(&a.name);
    out.push_str("', asname=");
    match &a.asname {
        Some(n) => {
            out.push('\'');
            out.push_str(n);
            out.push('\'');
        }
        None => out.push_str("None"),
    }
    out.push(')');
}

fn dump_arguments(out: &mut String, a: &Arguments, depth: usize) {
    out.push_str("arguments(posonlyargs=[");
    for (i, x) in a.posonlyargs.iter().enumerate() {
        if i > 0 {
            out.push_str(", ");
        }
        dump_arg(out, x);
    }
    out.push_str("], args=[");
    for (i, x) in a.args.iter().enumerate() {
        if i > 0 {
            out.push_str(", ");
        }
        dump_arg(out, x);
    }
    out.push_str("], vararg=");
    match &a.vararg {
        Some(x) => dump_arg(out, x),
        None => out.push_str("None"),
    }
    out.push_str(", kwonlyargs=[");
    for (i, x) in a.kwonlyargs.iter().enumerate() {
        if i > 0 {
            out.push_str(", ");
        }
        dump_arg(out, x);
    }
    out.push_str("], kw_defaults=[");
    for (i, d) in a.kw_defaults.iter().enumerate() {
        if i > 0 {
            out.push_str(", ");
        }
        match d {
            Some(e) => dump_expr(out, e, depth),
            None => out.push_str("None"),
        }
    }
    out.push_str("], kwarg=");
    match &a.kwarg {
        Some(x) => dump_arg(out, x),
        None => out.push_str("None"),
    }
    out.push_str(", defaults=[");
    for (i, e) in a.defaults.iter().enumerate() {
        if i > 0 {
            out.push_str(", ");
        }
        dump_expr(out, e, depth);
    }
    out.push_str("])");
}

fn dump_arg(out: &mut String, a: &Arg) {
    out.push_str("arg(arg='");
    out.push_str(&a.name);
    out.push_str("', annotation=");
    match &a.annotation {
        Some(e) => dump_expr(out, e.as_ref(), 0),
        None => out.push_str("None"),
    }
    out.push_str(", type_comment=None)");
}

fn dump_expr(out: &mut String, e: &Expr, depth: usize) {
    use ExprKind as E;
    match &e.kind {
        E::Constant(c) => {
            out.push_str("Constant(value=");
            dump_constant(out, c);
            out.push_str(", kind=None)");
        }
        E::Name(n) => {
            out.push_str("Name(id='");
            out.push_str(n);
            out.push_str("', ctx=Load())");
        }
        E::Attribute { value, attr } => {
            out.push_str("Attribute(value=");
            dump_expr(out, value, depth);
            out.push_str(", attr='");
            out.push_str(attr);
            out.push_str("', ctx=Load())");
        }
        E::Subscript { value, slice } => {
            out.push_str("Subscript(value=");
            dump_expr(out, value, depth);
            out.push_str(", slice=");
            dump_expr(out, slice, depth);
            out.push_str(", ctx=Load())");
        }
        E::Slice { lower, upper, step } => {
            out.push_str("Slice(lower=");
            match lower {
                Some(e) => dump_expr(out, e, depth),
                None => out.push_str("None"),
            }
            out.push_str(", upper=");
            match upper {
                Some(e) => dump_expr(out, e, depth),
                None => out.push_str("None"),
            }
            out.push_str(", step=");
            match step {
                Some(e) => dump_expr(out, e, depth),
                None => out.push_str("None"),
            }
            out.push(')');
        }
        E::BinOp { left, op, right } => {
            out.push_str("BinOp(left=");
            dump_expr(out, left, depth);
            out.push_str(", op=");
            out.push_str(op.as_str());
            out.push_str("(), right=");
            dump_expr(out, right, depth);
            out.push(')');
        }
        E::BoolOp { op, values } => {
            out.push_str("BoolOp(op=");
            out.push_str(op.as_str());
            out.push_str("(), values=[");
            for (i, v) in values.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, v, depth);
            }
            out.push_str("])");
        }
        E::UnaryOp { op, operand } => {
            out.push_str("UnaryOp(op=");
            out.push_str(op.as_str());
            out.push_str("(), operand=");
            dump_expr(out, operand, depth);
            out.push(')');
        }
        E::Compare {
            left,
            ops,
            comparators,
        } => {
            out.push_str("Compare(left=");
            dump_expr(out, left, depth);
            out.push_str(", ops=[");
            for (i, o) in ops.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push_str(o.as_str());
                out.push_str("()");
            }
            out.push_str("], comparators=[");
            for (i, c) in comparators.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, c, depth);
            }
            out.push_str("])");
        }
        E::IfExp { test, body, orelse } => {
            out.push_str("IfExp(test=");
            dump_expr(out, test, depth);
            out.push_str(", body=");
            dump_expr(out, body, depth);
            out.push_str(", orelse=");
            dump_expr(out, orelse, depth);
            out.push(')');
        }
        E::NamedExpr { target, value } => {
            out.push_str("NamedExpr(target=");
            dump_expr(out, target, depth);
            out.push_str(", value=");
            dump_expr(out, value, depth);
            out.push(')');
        }
        E::Lambda { args, body } | E::TypeParamFn { args, body } => {
            out.push_str("Lambda(args=");
            dump_arguments(out, args, depth + 2);
            out.push_str(", body=");
            dump_expr(out, body, depth);
            out.push(')');
        }
        E::Call {
            func,
            args,
            keywords,
        } => {
            out.push_str("Call(func=");
            dump_expr(out, func, depth);
            out.push_str(", args=[");
            for (i, a) in args.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, a, depth);
            }
            out.push_str("], keywords=[");
            for (i, k) in keywords.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                out.push_str("keyword(arg=");
                match &k.arg {
                    Some(n) => {
                        out.push('\'');
                        out.push_str(n);
                        out.push('\'');
                    }
                    None => out.push_str("None"),
                }
                out.push_str(", value=");
                dump_expr(out, &k.value, depth);
                out.push(')');
            }
            out.push_str("])");
        }
        E::Tuple(items) | E::List(items) | E::Set(items) => {
            let label = match &e.kind {
                E::Tuple(_) => "Tuple",
                E::List(_) => "List",
                E::Set(_) => "Set",
                _ => unreachable!(),
            };
            out.push_str(label);
            out.push_str("(elts=[");
            for (i, x) in items.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, x, depth);
            }
            out.push_str("], ctx=Load())");
        }
        E::Dict { keys, values } => {
            out.push_str("Dict(keys=[");
            for (i, k) in keys.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                match k {
                    Some(e) => dump_expr(out, e, depth),
                    None => out.push_str("None"),
                }
            }
            out.push_str("], values=[");
            for (i, v) in values.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, v, depth);
            }
            out.push_str("])");
        }
        E::ListComp { elt, generators }
        | E::SetComp { elt, generators }
        | E::GeneratorExp { elt, generators } => {
            let label = match &e.kind {
                E::ListComp { .. } => "ListComp",
                E::SetComp { .. } => "SetComp",
                E::GeneratorExp { .. } => "GeneratorExp",
                _ => unreachable!(),
            };
            out.push_str(label);
            out.push_str("(elt=");
            dump_expr(out, elt, depth);
            out.push_str(", generators=[");
            for (i, g) in generators.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_comprehension(out, g, depth);
            }
            out.push_str("])");
        }
        E::DictComp {
            key,
            value,
            generators,
        } => {
            out.push_str("DictComp(key=");
            dump_expr(out, key, depth);
            out.push_str(", value=");
            dump_expr(out, value, depth);
            out.push_str(", generators=[");
            for (i, g) in generators.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_comprehension(out, g, depth);
            }
            out.push_str("])");
        }
        E::Starred(e) => {
            out.push_str("Starred(value=");
            dump_expr(out, e, depth);
            out.push_str(", ctx=Load())");
        }
        E::Yield(value) => {
            out.push_str("Yield(value=");
            match value {
                Some(v) => dump_expr(out, v, depth),
                None => out.push_str("None"),
            }
            out.push(')');
        }
        E::YieldFrom(v) => {
            out.push_str("YieldFrom(value=");
            dump_expr(out, v, depth);
            out.push(')');
        }
        E::Await(v) => {
            out.push_str("Await(value=");
            dump_expr(out, v, depth);
            out.push(')');
        }
        E::JoinedStr(parts) => {
            out.push_str("JoinedStr(values=[");
            for (i, p) in parts.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, p, depth);
            }
            out.push_str("])");
        }
        E::FormattedValue {
            value,
            conversion,
            format_spec,
        } => {
            out.push_str("FormattedValue(value=");
            dump_expr(out, value, depth);
            out.push_str(", conversion=");
            out.push_str(&conversion.to_string());
            out.push_str(", format_spec=");
            match format_spec {
                Some(s) => dump_expr(out, s, depth),
                None => out.push_str("None"),
            }
            out.push(')');
        }
        E::TemplateStr(parts) => {
            out.push_str("TemplateStr(values=[");
            for (i, p) in parts.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_expr(out, p, depth);
            }
            out.push_str("])");
        }
        E::Interpolation {
            value,
            text,
            conversion,
            format_spec,
        } => {
            out.push_str("Interpolation(value=");
            dump_expr(out, value, depth);
            out.push_str(", str=");
            dump_constant(out, &Constant::Str(text.clone()));
            out.push_str(", conversion=");
            out.push_str(&conversion.to_string());
            out.push_str(", format_spec=");
            match format_spec {
                Some(s) => dump_expr(out, s, depth),
                None => out.push_str("None"),
            }
            out.push(')');
        }
    }
}

fn dump_comprehension(out: &mut String, c: &Comprehension, depth: usize) {
    out.push_str("comprehension(target=");
    dump_expr(out, &c.target, depth);
    out.push_str(", iter=");
    dump_expr(out, &c.iter, depth);
    out.push_str(", ifs=[");
    for (i, x) in c.ifs.iter().enumerate() {
        if i > 0 {
            out.push_str(", ");
        }
        dump_expr(out, x, depth);
    }
    out.push_str("], is_async=");
    out.push_str(if c.is_async { "1" } else { "0" });
    out.push(')');
}

fn dump_constant(out: &mut String, c: &Constant) {
    match c {
        Constant::None => out.push_str("None"),
        Constant::Bool(b) => out.push_str(if *b { "True" } else { "False" }),
        Constant::Int(i) => out.push_str(&i.to_string()),
        Constant::BigInt(repr) => out.push_str(repr),
        Constant::Complex(real, imag) => {
            if *real == 0.0 {
                out.push_str(&format!("{imag}j"));
            } else {
                out.push('(');
                out.push_str(&format!("{real}"));
                if imag.is_sign_positive() {
                    out.push('+');
                }
                out.push_str(&format!("{imag}j)"));
            }
        }
        Constant::Float(f) => {
            // Match CPython repr style for common floats; full
            // parity is out of scope for the slice.
            if f.fract() == 0.0 && f.is_finite() {
                out.push_str(&format!("{:.1}", f));
            } else {
                out.push_str(&format!("{}", f));
            }
        }
        Constant::Str(s) => {
            out.push('\'');
            for ch in s.chars() {
                match ch {
                    '\\' => out.push_str("\\\\"),
                    '\'' => out.push_str("\\'"),
                    '\n' => out.push_str("\\n"),
                    '\r' => out.push_str("\\r"),
                    '\t' => out.push_str("\\t"),
                    c => out.push(c),
                }
            }
            out.push('\'');
        }
        Constant::WStr(cps) => {
            // A str literal carrying lone surrogates; escape surrogates as
            // `\uXXXX` and dump scalar code points like `Constant::Str`.
            out.push('\'');
            for &cp in cps {
                match char::from_u32(cp) {
                    Some('\\') => out.push_str("\\\\"),
                    Some('\'') => out.push_str("\\'"),
                    Some('\n') => out.push_str("\\n"),
                    Some('\r') => out.push_str("\\r"),
                    Some('\t') => out.push_str("\\t"),
                    Some(c) => out.push(c),
                    None => out.push_str(&format!("\\u{cp:04x}")),
                }
            }
            out.push('\'');
        }
        Constant::Bytes(b) => {
            out.push_str("b'");
            for byte in b {
                match *byte {
                    b'\\' => out.push_str("\\\\"),
                    b'\'' => out.push_str("\\'"),
                    b'\n' => out.push_str("\\n"),
                    b'\r' => out.push_str("\\r"),
                    b'\t' => out.push_str("\\t"),
                    c if (0x20..0x7f).contains(&c) => out.push(c as char),
                    c => out.push_str(&format!("\\x{:02x}", c)),
                }
            }
            out.push('\'');
        }
        Constant::Tuple(items) => {
            out.push('(');
            for (i, x) in items.iter().enumerate() {
                if i > 0 {
                    out.push_str(", ");
                }
                dump_constant(out, x);
            }
            if items.len() == 1 {
                out.push(',');
            }
            out.push(')');
        }
        Constant::FrozenSet(items) => {
            if items.is_empty() {
                out.push_str("frozenset()");
            } else {
                out.push_str("frozenset({");
                for (i, x) in items.iter().enumerate() {
                    if i > 0 {
                        out.push_str(", ");
                    }
                    dump_constant(out, x);
                }
                out.push_str("})");
            }
        }
        Constant::Ellipsis => out.push_str("Ellipsis"),
    }
}

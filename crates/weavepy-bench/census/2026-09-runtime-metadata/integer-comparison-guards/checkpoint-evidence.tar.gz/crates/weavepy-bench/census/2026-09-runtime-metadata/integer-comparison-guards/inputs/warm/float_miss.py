def produce(i):
    return i + 0.5
def compare(f, i):
    return f(i) < 2500
def bench(n):
    total = 0
    for i in range(n):
        total += compare(produce, i)
    return total


import sys
serial = 0
def bench(n):
    global serial
    serial += 1
    # Each invocation grows the pool, including the verification warmups.
    prefix = "intern growth %d / " % serial
    keep = []
    for i in range(n):
        value = prefix + str(i) + " / " + 'x' * 1024
        keep.append(sys.intern(value))
    return [len(keep), sum(len(value) for value in keep)]

if __name__ == "__main__":
    import os
    import time
    n = int(os.environ["WEAVEPY_BENCH_WORK"])
    start = time.perf_counter_ns()
    result = bench(n)
    elapsed = time.perf_counter_ns() - start
    print("WEAVEPY_BENCH_NS=%d" % elapsed)

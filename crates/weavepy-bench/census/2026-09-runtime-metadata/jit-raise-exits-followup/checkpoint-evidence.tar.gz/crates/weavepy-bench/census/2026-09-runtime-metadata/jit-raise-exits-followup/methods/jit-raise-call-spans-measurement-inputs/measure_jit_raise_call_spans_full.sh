#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/jit-raise-call-spans-validation-stage.txt)" = done
test "$(cat target/jit-raise-call-spans-focused/stage.txt)" = done
test ! -e target/jit-raise-call-spans-full
mkdir target/jit-raise-call-spans-full
base=target/release/weavepy-runtime-weakref-shared-keys
binary=target/release/weavepy-runtime-jit-raise-call-spans
vm_stat > target/jit-raise-call-spans-full/vm-before.txt
sysctl hw.memsize vm.swapusage > target/jit-raise-call-spans-full/memory-before.txt
printf 'startup and imports\n' > target/jit-raise-call-spans-full/stage.txt
python3.14 target/shared_slot_keys_startup_probes.py --base "$base" --new "$binary" --samples 31 --out target/jit-raise-call-spans-full/startup.json > target/jit-raise-call-spans-full/startup.txt 2>&1
printf 'full 24-fixture census\n' > target/jit-raise-call-spans-full/stage.txt
python3.14 tools/bench_compare.py --base "$base" --new "$binary" --samples 5 --frozen-cache-root target/jit-raise-call-spans-full/frozen --out target/jit-raise-call-spans-full/suite.json > target/jit-raise-call-spans-full/suite.txt 2>&1
vm_stat > target/jit-raise-call-spans-full/vm-after.txt
sysctl hw.memsize vm.swapusage > target/jit-raise-call-spans-full/memory-after.txt
printf 'done\n' > target/jit-raise-call-spans-full/stage.txt

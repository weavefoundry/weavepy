#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/pickle-special-lookup-checks/frozen"
binary=target/release/weavepy-runtime-pickle-special-lookup
test "$(cat target/pickle-special-lookup-v2-stage.txt)" = done
test ! -e target/pickle-special-lookup-checks
mkdir target/pickle-special-lookup-checks
printf 'targeted pickle and lifetime checks\n' > target/pickle-special-lookup-check-stage.txt
for test in test_pickle_special_lookup test_pickle_builtin_data test_pickle_callables test_weakref_basic test_weakref_wrapper_keys test_jit_raise_exits test_native_call_scratch test_native_pin_retirement test_native_pin_pressure test_frame_recycling test_cross_thread_heap test_lazy_instance_dict test_small_slot_storage test_type_cache_names test_class_version_tokens; do
    WEAVEPY_JIT=1 "$binary" "tests/regrtest/$test.py" > "target/pickle-special-lookup-checks/$test-jit.txt" 2>&1
    WEAVEPY_JIT=0 "$binary" "tests/regrtest/$test.py" > "target/pickle-special-lookup-checks/$test-interp.txt" 2>&1
    WEAVEPY_JIT=1 "$binary" -X gil=0 "tests/regrtest/$test.py" > "target/pickle-special-lookup-checks/$test-gil0.txt" 2>&1
done
WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_pickle_special_lookup.py > target/pickle-special-lookup-checks/native-coverage.stdout.txt 2> target/pickle-special-lookup-checks/native-coverage.stderr.txt
printf 'done\n' > target/pickle-special-lookup-check-stage.txt

class Plain:
    def __init__(self):
        self.value = 7

class Descriptor:
    def __get__(self, obj, owner):
        return lambda: {'value': 31}
class State(Plain):
    __getstate__ = Descriptor()
obj = State()

def bench(n):
    total = 0
    for unused in range(n):
        reduction = object.__reduce_ex__(obj, 5)
        total += reduction[2]['value']
    return total

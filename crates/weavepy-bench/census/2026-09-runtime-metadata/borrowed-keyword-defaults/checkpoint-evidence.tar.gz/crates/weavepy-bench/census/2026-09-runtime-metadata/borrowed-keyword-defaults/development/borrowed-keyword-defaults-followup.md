# Unapplied keyword-only default borrowing follow-up

lib.rs near the positional-default block still copies each overridden keyword-
only dictionary into Vec<(String, Object)> before filling missing arguments.
This allocates a vector, copies every plain-string key, and clones every value,
even when supplied arguments make most entries unnecessary.

A bounded follow-up can preserve existing iteration order and accepted key
kinds while borrowing the dictionary for the binding loop. A small local
closure can locate matching keyword-only varnames and clone only into unfilled
slots. Match an owned kwd_override by reference: Some(Dict) borrows/iterates its
plain Object::Str entries; Some(None) fills nothing; other cases iterate the
unchanged f.kw_defaults. Release the dictionary borrow before errors/calls.
Unfilled positional slots contain Unbound, so assigning a default cannot run
a displaced object's finalizer. Object cloning only retains native owners.

Do not replace iteration with StrKey hash lookup without a separate semantic
audit. StrKey invokes Python equality for hash-colliding exotic keys, whereas
the current binder ignores non-Object::Str keys. A raw probe under a dictionary
borrow would introduce callback/re-entrancy behavior and can deadlock. Preserve
current behavior in a borrowing-only change and document any existing CPython
divergence separately. Concurrent mutation should see one borrowed snapshot;
never keep a RefCell/GIL guard across user execution or error rendering.

Tests should cover sparse/all-supplied kwargs, None/deletion, code replacement,
ignored extra keys, default-value aliases/liveness, and dictionary mutation from
inside the callee. Focused controls should separate compiled defaults, overrides,
and unaffected no-keyword-only calls. Finish phase 73 measurement first.

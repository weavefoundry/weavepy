def leaf(a0=0, a1=1, a2=2, a3=3, a4=4, a5=5, a6=6, a7=7, a8=8, a9=9, a10=10, a11=11, a12=12, a13=13, *args, **kwargs):
    return a0 + a13 + len(args) + len(kwargs)

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(a13=5, a0=i, spare=2)
    return total

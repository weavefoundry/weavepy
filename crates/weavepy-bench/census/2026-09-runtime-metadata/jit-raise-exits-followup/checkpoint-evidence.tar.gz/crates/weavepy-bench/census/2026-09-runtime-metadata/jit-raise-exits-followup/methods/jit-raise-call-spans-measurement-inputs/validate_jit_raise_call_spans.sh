#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/jit-raise-call-spans-validation/frozen"
binary=target/release/weavepy-runtime-jit-raise-call-spans
output=target/jit-raise-call-spans-validation
test "$(cat target/jit-raise-call-spans-check-stage.txt)" = done
test ! -e "$output"
mkdir "$output"
printf 'full compatibility\n' > target/jit-raise-call-spans-validation-stage.txt
python3.14 crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py --binary "$binary" --out "$output/validation.json" > "$output/validation.txt" 2>&1
printf 'done\n' > target/jit-raise-call-spans-validation-stage.txt

class Plain:
    def __init__(self):
        self.value = 7

class Base(Plain):
    def __getnewargs__(self):
        return (self.value,)
class Child(Base):
    pass
obj = Child()

def bench(n):
    total = 0
    for unused in range(n):
        reduction = object.__reduce_ex__(obj, 5)
        total += reduction[2]['value']
    return total

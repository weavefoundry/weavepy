"""Preserve generic-call arguments, ownership, and exits across buffer sizes."""
import gc
import sys
import weakref


class Recorder:
    def __init__(self):
        self.calls = 0
        self.last = None

    def __call__(self, *args, **kwargs):
        self.calls += 1
        self.last = (args, kwargs)
        return sum((i + 1) * value for i, value in enumerate(args)) + sum(kwargs.values())


def make_driver(width):
    arguments = ', '.join(str(i + 1) for i in range(width))
    namespace = {}
    exec('def invoke(fn, n):\n    total = 0\n    for _ in range(n):\n        total += fn(' + arguments + ')\n    return total\n', namespace)
    return namespace['invoke']


for width in [0, 1, 2, 3, 4, 5, 8, 32, 64]:
    driver = make_driver(width)
    recorder = Recorder()
    checksum = width * (width + 1) * (2 * width + 1) // 6
    for _ in range(60):
        assert driver(recorder, 10) == 10 * checksum
    assert recorder.calls == 600
    assert recorder.last == (tuple(range(1, width + 1)), {})


def keyword_driver(fn, n):
    total = 0
    for i in range(n):
        total += fn(i, second=7, first=3)
    return total


recorder = Recorder()
for _ in range(60):
    assert keyword_driver(recorder, 10) == 145
assert recorder.calls == 600
assert recorder.last == ((9,), {'second': 7, 'first': 3})
assert tuple(recorder.last[1]) == ('second', 'first')


def forward(fn, value):
    return fn(value)


class Echo:
    def __init__(self):
        self.calls = 0

    def __call__(self, value):
        self.calls += 1
        return value


echo = Echo()
for _ in range(60):
    assert forward(echo, 9) == 9
for value in [None, False, 3.25, 10**40, 'text', [1, 2], {'x': 7}, object()]:
    before = echo.calls
    assert forward(echo, value) is value
    assert echo.calls == before + 1


def add_result(fn, value):
    return 100 + fn(value)


for _ in range(60):
    assert add_result(echo, 3) == 103
for value, expected in [(2.5, 102.5), (10**40, 10**40 + 100), (True, 101)]:
    before = echo.calls
    assert add_result(echo, value) == expected
    assert echo.calls == before + 1
before = echo.calls
try:
    add_result(echo, [])
except TypeError:
    pass
else:
    raise AssertionError('invalid result arithmetic succeeded')
assert echo.calls == before + 1


class Nested:
    def __call__(self, value):
        before = value
        inner = Recorder()
        assert make_driver(8)(inner, 3) == 612
        assert value is before
        return value


nested = Nested()
for _ in range(60):
    value = object()
    assert forward(nested, value) is value


class Payload:
    pass


class Observe:
    def __init__(self):
        self.ref = None
        self.calls = 0

    def __call__(self, value):
        self.calls += 1
        self.ref = weakref.ref(value)
        assert self.ref() is value
        return 7


observer = Observe()
for _ in range(60):
    assert forward(observer, Payload()) == 7
    gc.collect()
    assert observer.ref() is None
assert observer.calls == 60


class Raise:
    def __init__(self):
        self.calls = 0

    def __call__(self, value):
        self.calls += 1
        if value:
            raise ValueError('generic call failure')
        return 7


raiser = Raise()
for _ in range(60):
    assert forward(raiser, 0) == 7
before = raiser.calls
try:
    forward(raiser, 1)
except ValueError as error:
    assert str(error) == 'generic call failure'
else:
    raise AssertionError('callee exception disappeared')
assert raiser.calls == before + 1
assert forward(raiser, 0) == 7


flag = 3


def global_driver(fn, n):
    total = 0
    for i in range(n):
        total += flag + fn(i)
    return total


class Rebind:
    def __init__(self):
        self.change = False
        self.calls = 0

    def __call__(self, value):
        global flag
        self.calls += 1
        if self.change and value == 4:
            flag = 100
        return value


rebinder = Rebind()
for _ in range(60):
    assert global_driver(rebinder, 10) == 75
rebinder.change = True
before = rebinder.calls
assert global_driver(rebinder, 10) == 560
assert rebinder.calls == before + 10
assert flag == 100


class FrameName:
    def __call__(self, value):
        return sys._getframe(1).f_code.co_name


for _ in range(60):
    assert forward(FrameName(), None) == 'forward'


class Fixed:
    def __call__(self, first, /, second):
        return first + second


fixed = Fixed()
for _ in range(60):
    assert keyword_driver(recorder, 2) == 21
for action in [lambda: fixed(1), lambda: fixed(1, 2, 3),
               lambda: fixed(first=1, second=2), lambda: fixed(1, 2, second=3)]:
    try:
        action()
    except TypeError:
        pass
    else:
        raise AssertionError('invalid call arguments succeeded')
print('dynamic argument storage: semantics and ownership ok')


keys = ['key-' + str(i) for i in range(256)]
values = {key: i for i, key in enumerate(keys)}
def bench(n):
    total = 0
    for i in range(n):
        key = ('!' + keys[i & 255])[1:]
        total += values[key]
    return total

class Plain:
    def __init__(self):
        self.value = 7

class Meta(type):
    pass
class State(Plain, metaclass=Meta):
    def __getstate__(self):
        return {'value': self.value}
obj = State()

def bench(n):
    total = 0
    for unused in range(n):
        reduction = object.__reduce_ex__(obj, 5)
        total += reduction[2]['value']
    return total

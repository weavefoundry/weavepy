"""Prepare isolated methods for the value-storage experiment."""
from pathlib import Path

pairs = [
 ('check_jit_assertion_exits.sh','check_thin_value_storage.sh'),
 ('validate_jit_assertion_exits.sh','validate_thin_value_storage.sh'),
 ('measure_jit_assertion_exits_full.sh','measure_thin_value_storage_full.sh'),
]
for old,new in pairs:
    p=Path('target')/new
    assert not p.exists()
    s=(Path('target')/old).read_text().replace('jit-assertion-exits','thin-value-storage')
    if new.startswith('check_'):
        s=s.replace('for test in ', 'for test in test_shared_value_storage test_tuple_storage test_tuple_hash_cache test_marshal_roundtrip test_rfc0050_unicode_codecs test_json_buffers ',1)
        # The assertion regression remains an earlier retained optimization.
        s=s.replace('test_thin_value_storage','test_jit_assertion_exits')
    p.write_text(s)

Path('target/measure_thin_value_storage_focused.sh').write_text('''#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/thin-value-storage-validation-stage.txt)" = done
python3.14 target/verify_thin_value_storage_ready.py
output=target/thin-value-storage-focused
test ! -e "$output"
mkdir "$output"
base=target/release/weavepy-runtime-jit-assertion-exits
binary=target/release/weavepy-runtime-thin-value-storage
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf '20 population controls\\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/thin-value-storage-inputs/cold --out "$output/cold" --samples 7 --cold > "$output/cold.txt" 2>&1
printf 'seven repeated-operation controls\\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/thin-value-storage-inputs/warm --out "$output/warm" --samples 7 > "$output/warm.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
printf 'done\\n' > "$output/stage.txt"
''')
Path('target/build_thin_value_storage.sh').write_text('''#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-jit-assertion-exits
binary=target/release/weavepy-runtime-thin-value-storage
test -f "$base"
test ! -e "$binary"
test ! -e target/thin-value-storage-build-stage.txt
printf '%s\\n' "$base" > target/thin-value-storage-previous.txt
printf 'final static and VM checks\\n' > target/thin-value-storage-build-stage.txt
cargo fmt --all -- --check > target/thin-value-storage-format.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/thin-value-storage-vm-tests-final.txt 2>&1
python3.14 target/freeze_thin_value_sources.py
printf 'release build\\n' > target/thin-value-storage-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/thin-value-storage-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/thin-value-storage-source-snapshot --extra target/build_thin_value_storage.sh target/check_thin_value_storage.sh target/validate_thin_value_storage.sh target/check_thin_value_storage_extra.py target/measure_thin_value_storage_focused.sh target/measure_thin_value_storage_full.sh target/measure_verified_python_components.py target/thin-value-storage-protocol.md target/prepare_thin_value_inputs.py target/check_thin_value_input_baseline.py target/verify_thin_value_storage_ready.py target/freeze_thin_value_sources.py > target/thin-value-storage-snapshot.txt 2>&1
printf 'done\\n' > target/thin-value-storage-build-stage.txt
''')
print('Prepared build, targeted/compatibility checks, and focused/full measurement launchers.')


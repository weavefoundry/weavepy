
import sys
texts = [("intern hit %d / " % i) + "x" * 128 for i in range(256)]
canonical = [sys.intern(text) for text in texts]
duplicates = [text.encode().decode() for text in texts]
def bench(n):
    total = 0
    for i in range(n):
        k = i & 255
        total += sys.intern(duplicates[k]) is canonical[k]
    return total

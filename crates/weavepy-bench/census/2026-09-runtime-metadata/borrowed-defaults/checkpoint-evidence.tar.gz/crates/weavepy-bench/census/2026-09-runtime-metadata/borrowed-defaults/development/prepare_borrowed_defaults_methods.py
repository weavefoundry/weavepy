"""Prepare a safe borrowing change, without repeating unrelated ownership experiments."""
from pathlib import Path

def fresh(name, text):
    p = Path('target') / name
    assert not p.exists(), p
    p.write_text(text)

for name in ['build_niche_string_owner.sh', 'check_niche_string_owner.sh',
             'validate_niche_string_owner.sh', 'measure_niche_string_owner_focused.sh',
             'measure_niche_string_owner_full.sh', 'summarize_niche_string_owner.py']:
    text = (Path('target') / name).read_text().replace('niche-string-owner', 'borrowed-defaults').replace('niche_string_owner', 'borrowed_defaults')
    if name.startswith('build_'):
        text = text.replace(' target/check_borrowed_defaults_extra.py', '')
    if name.startswith('check_'):
        text = text.replace('for test in ', 'for test in test_overridden_default_ownership ')
    if name.startswith('measure_') and 'focused' in name:
        text = text.replace('thin-value-storage-inputs', 'borrowed-defaults-inputs')
        text = text.replace('20 population controls', '12 first-invocation binding controls').replace('seven repeated-operation controls', '12 repeated binding controls')
    if name.startswith('summarize_'):
        text = text.replace("[('cold',20),('warm',7)]", "[('cold',12),('warm',12)]")
    fresh(name.replace('niche_string_owner', 'borrowed_defaults'), text)

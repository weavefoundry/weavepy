class Plain:
    def __init__(self):
        self.value = 7

class State(Plain):
    marker = 41
    @classmethod
    def __getstate__(cls):
        return {'value': cls.marker}
obj = State()

def bench(n):
    total = 0
    for unused in range(n):
        reduction = object.__reduce_ex__(obj, 5)
        total += reduction[2]['value']
    return total

#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/comparison-call-fusion-validation-stage.txt)" = done
python3.14 - <<'CHECK'
import json
from pathlib import Path
assert json.loads(Path('target/comparison-call-fusion-extra-checks/report.json').read_text())['status']=='passed'
assert json.loads(Path('target/comparison-call-fusion-coverage-v2/report.json').read_text())['assertions_passed']
assert json.loads(Path('target/comparison-call-fusion-corrected-semantics/report.json').read_text())['status']=='passed'
CHECK
output=target/comparison-call-fusion-focused
test ! -e "$output"
mkdir "$output"
base="$(cat target/comparison-call-fusion-previous.txt)"
reference="$(cat target/comparison-call-fusion-reference.txt)"
binary=target/release/weavepy-runtime-comparison-call-fusion
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf '15 warm comparison/datetime/recovery controls\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/integer-comparison-inputs/warm --out "$output/warm" --samples 7 > "$output/warm.txt" 2>&1
printf 'four cold comparison frequencies\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/integer-comparison-inputs/cold --out "$output/cold" --samples 7 --cold > "$output/cold.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
printf 'done\n' > "$output/stage.txt"

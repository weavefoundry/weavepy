# Direct cloning of compact Arc metadata

Primary reference is the fully measured packed-owner build 65ff:
65ff081f8d85851c247cee8cc9e64bd3ebb1f80d49b617cbd6115ab44141c883.
Retained reference is the earlier thin-owner build bf2:
bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4.

Change only shared_value.rs. Ordinary inline-metadata clones increment the
standard Arc strong count, then copy the existing data pointer and metadata.
An outlined cold helper retains the original clone/repack behavior for indirect
owners, including individually owned boxes and exact strong/weak counts. No
allocation layout, tuple header, weak owner, or Python test changes in this trial.

Preserve both preliminary prototypes, tests, Miri results, and generated code.
The initial direct-clone prototype retains its modeled 64-byte wrapper frame;
outlining the exceptional path removes that frame from the ordinary standalone
str/byte clone wrapper. This is not a full-VM code-generation or speed result.
Run all 355 VM tests, the full C API test package, strict lint/format, the no-JIT
check, and the real VM layout example. Run exact integrated storage modules under
strict-provenance Miri on ARM64 and i686 with Object/CachedHash stubs. Preserve
the 16 ownership tests; this does not prove whole-VM soundness.

After building the CLI release package, freeze its identity and exact source
and methods. All 87 targeted Python checks in three modes must pass. Run the
unchanged 275-check compatibility validator outside the filesystem sandbox so
its existing local socket fixtures work. Additional nonempty bytes, codecs,
and four C API suites must pass. Marshal must retain the exact four graded
baseline divergences against 65ff; never report them as clean passes.

Use unchanged phase69 inputs: 20 cold population controls of 200,000 values and
seven warm operation controls of 20,000 repetitions. For each reference, the
unchanged sampler verifies results against CPython before timing and includes
GIL-disabled correctness checks. Collect seven alternating pairs in JIT and
interpreter modes plus CPython, with one declared stabilization cycle per row.
Per-binary-SHA frozen caches must remain unchanged over measured samples.

For each reference also collect 31 startup/import samples and five alternating
pairs for the unchanged full 24-fixture census. Keep historical 21-row, current
23-workload, and all-24 process cohorts distinct. Use same-run pairs for causal
attribution, never multiply unrelated historical ratios to claim a new ed99
comparison. Retain all samples, losses, failures, and load observations.

Run four stages sequentially: focused and full against 65ff, then focused and
full against bf2. Use the unchanged outside-sandbox load gate: three 10-second
observations with one- and five-minute averages at most half the CPU count,
waiting at most 600 seconds per attempt. Preserve all samples after launch,
even if load later rises. Retain VM/swap, executable, source, input, method,
and cache identities. No owned build, test, profile, install, runtime edit, or
active-harness edit may overlap a gate that can launch or any measurement stage.

The goal remains unachieved. No universal, energy, controlled build-time,
portability, or native parallel-scaling claim follows from these measurements.

def checked_value(n):
    if n < 0:
        raise ValueError("negative")
    return n + 1

def bench(n):
    count = 0
    total = 0
    for i in range(n):
        value = -1 if i % 100 == 0 else 7
        try:
            total += checked_value(value)
        except ValueError:
            count += 1
    return count, total

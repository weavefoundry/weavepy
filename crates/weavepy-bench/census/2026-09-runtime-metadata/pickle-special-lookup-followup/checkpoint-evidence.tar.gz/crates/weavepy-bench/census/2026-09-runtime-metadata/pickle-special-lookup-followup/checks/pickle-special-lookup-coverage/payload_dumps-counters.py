import sys, types
module = types.ModuleType("_weavepy_bench")
module.__file__ = 'target/pickle-component-probes/payload_dumps.py'
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
print(module.bench(20))
print(module.bench(20))

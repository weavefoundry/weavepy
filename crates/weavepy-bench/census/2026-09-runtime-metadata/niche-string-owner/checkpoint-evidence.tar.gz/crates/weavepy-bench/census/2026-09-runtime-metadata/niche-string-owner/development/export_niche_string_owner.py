"""Archive the complete aligned-string experiment, including its regressions."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

subprocess.run(['python3.14', 'target/verify_niche_string_owner_ready.py'], check=True)
base = Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out = base / 'niche-string-owner'
assert not out.exists()
for label in ['focused-retained', 'full-retained']:
    gate = json.loads(Path(f'target/niche-string-owner-{label}-load.json').read_text())
    assert gate['status'] == 'complete' and gate['returncode'] == 0
    assert Path(f'target/niche-string-owner-{label}/stage.txt').read_text().strip() == 'done'
out.mkdir()
index, destinations = [], set()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def add(source, relative):
    source = Path(source)
    raw = source.read_bytes()
    data = raw
    relative = Path(relative)
    if len(raw) > 32768 and source.suffix in {'.json', '.jsonl', '.txt', '.rs', '.diff', '.s'}:
        data = gzip.compress(raw, mtime=0)
        relative = Path(str(relative) + '.gz')
    assert str(relative) not in destinations, relative
    destinations.add(str(relative))
    dest = out / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    index.append({'path': str(relative), 'source': str(source), 'bytes': len(data), 'sha256': sha(data),
                  'uncompressed_bytes': len(raw), 'uncompressed_sha256': sha(raw)})
def tree(source, prefix, exclude=()):
    for path in sorted(Path(source).rglob('*')):
        relative = path.relative_to(source)
        if path.is_file() and not any(part in exclude for part in relative.parts):
            add(path, Path(prefix) / relative)
tree('target/niche-string-owner-source-snapshot', 'candidate')
for label in ['focused-retained', 'full-retained']:
    tree(f'target/niche-string-owner-{label}', label, ['frozen', 'startup'])
for group in ['checks', 'validation', 'extra-checks', 'preimages']:
    tree(f'target/niche-string-owner-{group}', group, ['frozen'])
for path in sorted(Path('target').glob('niche-string-owner*')):
    if path.is_file() and path.name != 'niche-string-owner-export.txt':
        add(path, Path('development') / path.name)
for name in ['niche-string-owner-prototype', 'niche-string-owner-integrated-api']:
    tree(Path('target') / name / 'src', 'development/' + name + '/src')
    for file in ['Cargo.toml', 'Cargo.lock']:
        add(Path('target') / name / file, Path('development') / name / file)
for name in ['performance_phase72_status.md', 'prepare_niche_string_owner_methods.py',
             'apply_niche_string_owner.py', 'check_niche_string_owner_native.sh', 'export_niche_string_owner.py',
             'niche-string-layout.json', 'niche-string-layout-build.txt',
             'niche_string_layout_preflight.rs', 'niche_string_layout_preflight.s',
             'compact-arc-clone-restoration.json']:
    add(Path('target') / name, Path('development') / name)
for name in json.loads(Path('target/niche-string-owner-prebuild.json').read_text())['methods']:
    add(name, Path('methods') / name)

full = json.loads(Path('target/niche-string-owner-full-retained/summary.json').read_text())
focused = json.loads(Path('target/niche-string-owner-focused-retained/summary.json').read_text())
lines = ['# Aligned UTF-8 ownership with a reserved enum byte', '',
    'Decision: deferred. Restore retained bf2 after preserving this record.',
    'The candidate regresses workload time, process time, CPU use, and peak RSS',
    'overall. Its local allocation benefits do not justify retaining the change.',
    'Overall superiority to CPython remains unachieved.', '',
    'Candidate: `6b4d28aa0f39d9cd64c863d954f9af8355811aab79c9b26ed5f21a3bdaadcd3b`,',
    '44,137,120 bytes. Reference: retained bf2,',
    '`bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4`,',
    '44,097,168 bytes. This is a same-run comparison against bf2 only.', '',
    'Only shared_value.rs changes. UTF-8 text uses standard Arc<str> allocations',
    'and aligned inline length metadata. A zero-only byte supplies invalid values',
    'for enclosing Rust enum tags; exceptionally large lengths use individually',
    'owned boxed Arc handles. Bytes, surrogate text, and tuples retain their thin',
    'owners and allocation headers. Actual Object, Option<Object>, and DictKey',
    'remain 16 bytes. SharedStr becomes 16 bytes; the other strong owners stay',
    '8 bytes. The tuple payload remains 16 + 16*n bytes, excluding Arc counts.', '',
    'Standalone layout and owning prototypes are preserved. Six ordinary tests',
    'and six strict-provenance Miri tests on each of ARM64 and i686 passed, as',
    'did clippy. The initial format failure was a missing tests.rs module that',
    'had not yet been created; its log remains. Generated ordinary clone code',
    'uses an aligned metadata load and no stack frame. Dereference includes an',
    'exceptional-length check. These observations are not whole-VM speed proof.', '',
    'Integrated validation passed 353 VM tests, 156 C API tests, strict lint and',
    'format, a no-JIT check, all 87 targeted Python checks, and all 275 outside-',
    'sandbox compatibility checks. Optional extension tests may check availability',
    'internally. Exact storage modules passed 14 strict-provenance Miri tests per',
    'architecture with documented Object/CachedHash stubs. This is not whole-VM',
    'Miri validation. Bytes, codecs, and four extra C API suites passed. Marshal',
    'received the expected divergence grade on both builds; the runner requires',
    'the exact four enumerated IDs in expectations.toml, not an arbitrary failure.', '',
    'All 336 source hashes and 78 method/input hashes remained unchanged through',
    'the build and measurements. The observed release build took 4m04s, which is',
    'not a controlled build-time comparison. Both timing stages used the exclusive',
    'serial lease and unchanged host-load gate outside the filesystem sandbox.',
    'The focused gate waited for load to qualify. Both stages then completed',
    'sequentially. No measurement overlap or sample exclusion occurred.', '',
    'Ratios below 1 favor the candidate. These means aggregate per-fixture',
    'medians of paired ratios. Keep the 21-, 23-, and 24-row cohorts distinct.', '',
    '| Metric | Candidate / bf2 | Candidate / CPython | Wins over CPython |',
    '| --- | ---: | ---: | ---: |']
cohorts = full['cohorts']
w = cohorts['all_23_workloads_excluding_startup']['metrics']
m = cohorts['all_processes_including_startup']['metrics']
for label, row in [('JIT workload time (23)', w['jit']['ns']),
                   ('Interpreter workload time (23)', w['interp']['ns']),
                   ('JIT process wall time (24)', m['jit']['wall_ns']),
                   ('JIT CPU time (24)', m['jit']['cpu_ns']),
                   ('JIT peak RSS (24)', m['jit']['rss_bytes'])]:
    lines.append(f"| {label} | {row['new_over_base']:.9f} | {row['new_over_cpython']:.9f} | {row['weavepy_wins']} |")
lines += ['', 'The win column counts fixtures where the candidate beats CPython.',
    'The 23 JIT workloads have 20 regressions against bf2. Twenty-two of 24 JIT',
    'peak-RSS medians regress. All nine startup/import wall-time medians regress.',
    'The focused shared string/bytes/tuple populations regress in every pair,',
    'as does integer population. Nine-byte strings and shared dictionary population',
    'use less peak memory in every pair; the overall tradeoff is unfavorable.', '',
    '| Focused control | Time / bf2 | RSS / bf2 | Time wins (7 pairs) |',
    '| --- | ---: | ---: | ---: |']
for name, row in focused['rows'].items():
    v = row['new_over_previous']['jit']
    lines.append(f"| {name} | {v['ns']:.6f} | {v['rss_bytes']:.6f} | {row['pairs']['jit']['ns']['wins']} |")
lines += ['', 'All raw samples, losses, validation outcomes, load observations, VM/swap',
    'snapshots, methods, inputs, source snapshots, and code-generation artifacts',
    'remain. Larger text artifacts use lossless gzip; index.json records both',
    'stored and original hashes. Executables and frozen caches remain local.',
    'Intermediate status notes are historical; this report records the decision.', '',
    'No universal, energy, controlled build-time, portability, or native parallel-',
    'scaling conclusion follows from these measurements.', '']
data = '\n'.join(lines).encode()
(out / 'REPORT.md').write_bytes(data)
index.append({'path': 'REPORT.md', 'bytes': len(data), 'sha256': sha(data)})
(out / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
for row in index:
    data = (out / row['path']).read_bytes()
    assert sha(data) == row['sha256']
    if 'uncompressed_sha256' in row:
        raw = gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert sha(raw) == row['uncompressed_sha256']
allow = {'!niche-string-owner/'}
for path in out.rglob('*'):
    allow.add('!' + str(path.relative_to(base)) + ('/' if path.is_dir() else ''))
with (base / '.gitignore').open('a') as f:
    f.write('\n# Deferred aligned UTF-8 owner experiment.\n' + '\n'.join(sorted(allow)) + '\n')
with (base / 'README.md').open('a') as f:
    f.write('\nThe [aligned string-owner experiment](niche-string-owner/REPORT.md) preserves\nvalidated ownership and compact layouts alongside measured runtime regressions.\nIt is deferred in favor of the retained bf2 implementation.\n')
print('Archived', len(index) + 1, 'files;', sum(p.stat().st_size for p in out.rglob('*') if p.is_file()), 'bytes. All hashes verified.')

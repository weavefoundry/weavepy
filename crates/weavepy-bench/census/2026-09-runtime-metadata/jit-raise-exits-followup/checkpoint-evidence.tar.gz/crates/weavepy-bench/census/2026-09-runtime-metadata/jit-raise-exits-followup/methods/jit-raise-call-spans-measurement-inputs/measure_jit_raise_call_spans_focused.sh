#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/jit-raise-call-spans-validation-stage.txt)" = done
test ! -e target/jit-raise-call-spans-focused
mkdir target/jit-raise-call-spans-focused
vm_stat > target/jit-raise-call-spans-focused/vm-before.txt
sysctl hw.memsize vm.swapusage > target/jit-raise-call-spans-focused/memory-before.txt
for group in kernels calls exceptions cold-exceptions; do
    extra=()
    if [ "$group" = cold-exceptions ]; then extra=(--cold); fi
    printf '%s\n' "$group" > target/jit-raise-call-spans-focused/stage.txt
    python3.14 target/measure_verified_python_components.py --binary target/release/weavepy-runtime-jit-raise-call-spans --previous target/release/weavepy-runtime-weakref-shared-keys --inputs "target/jit-raise-call-spans-inputs/$group" --out "target/jit-raise-call-spans-focused/$group" --samples 7 "${extra[@]}" > "target/jit-raise-call-spans-focused/$group.txt" 2>&1
done
vm_stat > target/jit-raise-call-spans-focused/vm-after.txt
sysctl hw.memsize vm.swapusage > target/jit-raise-call-spans-focused/memory-after.txt
printf 'done\n' > target/jit-raise-call-spans-focused/stage.txt

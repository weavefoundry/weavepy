import os
values = tuple("default-%d-" % i + "shared-text" * 3 for i in range(4))
provided = "provided-" + "string" * 3
def target(*, a0, a1, a2, a3):
    return a3
target.__kwdefaults__ = {"a%d" % i: values[i] for i in range(4)}
def bench(n):
    total = 0
    for _ in range(n):
        total += len(target(a0=provided, a1=provided, a2=provided, a3=provided))
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

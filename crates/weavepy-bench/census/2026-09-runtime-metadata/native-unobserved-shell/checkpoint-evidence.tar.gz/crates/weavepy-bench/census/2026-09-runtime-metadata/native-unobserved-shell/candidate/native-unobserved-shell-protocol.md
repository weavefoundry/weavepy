# Reuse unobserved native activation frame shells

Phase 76 is deferred and its two source preimages and CLI were restored to 6810.
All 339 predecessor source hashes matched before this change. The direct
reference is 681043b9f62cbd4fdb3f73756ecdf8ac877c1923b6a509f11ff1128dc973443c.
The retained acceptance reference is bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4.

Each CallCtx has a Cell containing at most one exclusively owned, unmaterialized
shell. Take it before a callback, refresh the exact call-site lasti, push a
clone, and release the spine clone after the callback. No cache or mutable shell
borrow crosses arbitrary Python. Retain the allocation only after Rc::get_mut excludes both strong and weak
observers, then read has_materialized through that exclusive reference. The flag
must still be false. The first draft checked the flag before exclusivity; source
review tightened that order before any timing. Its executable, full source and
method snapshot, and passing validation logs are preserved separately. Re-run
all declared validation for the corrected predicate. All four
context constructors initialize the cache empty; framed entries pass through.
The cache lasts only for this activation. Code, globals, builtins, and cells
already have owners in that context. Callback arguments/results are not cached.
There is no new raw pointer, allocator, or ownership representation.

Observed frames keep the predecessor's behavior. Native frame identity, full
locals materialization, clear/continuation semantics, and final instruction
positions are separate work. Preserve the independent frame-identity diagnostic:
CPython and interpreter mode keep one identity; predecessor JIT returns distinct
frames. Require no new divergence in that diagnostic. No identity-fix claim.

Require all 353 VM tests, 156 C API tests, strict format/lint, no-JIT check,
99 targeted Python checks, and the unchanged 275-check outside-sandbox suite.
The new Python oracle passes on CPython and predecessor JIT/interpreter/GIL0.
Test-only counters must show actual native allocation, at least 100 shell reuses,
and at least 10 observer exclusions. A Rust test excludes strong, weak, and
materialized observers. No release counters. Capture static stack prologues;
an additional context field and cached shells are potential memory tradeoffs.

All original 26 measured fixture sources are unchanged. The initial 28-input
set adds single-callback and observed-callback controls; retain it and its
baseline traces. The v2 set preserves all 28 and adds a recursive-callback
control to expose retention across nested native activations. All 29 independent
CPython checksums must pass twice. Before timing, capture untimed predecessor
and candidate paths and prove the intended generic drivers and compiled alias
controls compile. Single and recursive controls must compile their native
callee too. Require at least 30,000 relevant calls in the verification driver.
Document the original wide-argument and tuple-unpack controls that remain
interpreted, plus inherited formatter and binding controls with their actual
paths. Coverage traces are not timing evidence.

Freeze all source, method, input, and binary identities after the correct
release CLI build. Run four sequential timing stages: focused-previous,
full-previous, focused-retained, full-retained. Each focused stage keeps seven
alternating pairs for all 29 cold and warm controls with 20,000 work units.
Use the unchanged sampler, stabilization, CPython output checks before/after
warmup, correctness-only GIL0 checks, per-binary-SHA frozen caches, and unchanged
cache assertions. Each full stage retains 31 samples for nine startup/import
controls and five alternating pairs for the unchanged 24-fixture census.

Every stage runs outside the filesystem sandbox through the exclusive serial
lease and unchanged load gate. Inspect session completion, complete/0 gate JSON,
and stage done before a dependent launch. The gate requires three 10-second
observations with both one- and five-minute loads at most half the CPU count,
waiting at most 600 seconds before declining to launch. No owned build, test,
profile, install, runtime edit, or active-harness edit may overlap a gate that
can launch or measure. Do not filter or retry launched samples. Keep all gains,
losses, failures, raw samples, sources, identities, VM/swap snapshots, and load
observations. Separate the historical 21-row, 23-workload, and 24-process cohorts.
The user goal remains unachieved. No universal, energy, controlled build-time,
portability, or native parallel-scaling claim follows.

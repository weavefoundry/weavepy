def plain_float(n):
    value = 1.0
    for i in range(n):
        value = value * 1.00001 + 0.00003
    return value

def bench(n):
    total = 0.0
    for i in range(n):
        total += plain_float(512)
    return total

import json
for stage in range(2):
    if stage:
        bench(1000)
    value = bench(7)
    expected = 1.0
    for i in range(512):
        expected = expected * 1.00001 + 0.00003
    assert abs(value - expected * 7) < 1e-10
    print(json.dumps(round(value, 8)))

"""Prepare isolated validation and measurement methods for assertion exits."""
from pathlib import Path

pairs = [
    ("build_compact_intern_pools.sh", "build_jit_assertion_exits.sh"),
    ("check_compact_intern_pools.sh", "check_jit_assertion_exits.sh"),
    ("validate_compact_intern_pools.sh", "validate_jit_assertion_exits.sh"),
    ("check_outlined_bound_entry_extra.py", "check_jit_assertion_exits_extra.py"),
    ("measure_compact_intern_pools_full.sh", "measure_jit_assertion_exits_full.sh"),
]
for old, new in pairs:
    p = Path("target") / new
    assert not p.exists()
    s = (Path("target") / old).read_text().replace("compact-intern-pools", "jit-assertion-exits")
    if old.endswith("extra.py"):
        s = s.replace("outlined-bound-entry", "jit-assertion-exits")
        s = s.replace("runtime-jit-raise-call-spans", "runtime-compact-intern-pools")
        s = s.replace("'test_copyreg']", "'test_copyreg','test_unittest/test_assertions']")
    for a, b in pairs:
        s = s.replace(a, b)
    if new.startswith("build_"):
        s = s.replace("base=target/release/weavepy-runtime-outlined-bound-entry", "base=target/release/weavepy-runtime-compact-intern-pools")
        s = s.replace("cargo test --offline --locked -p weavepy-vm", "cargo test --offline --locked -p weavepy-jit -j 1 > target/jit-assertion-exits-jit-tests.txt 2>&1\ncargo test --offline --locked -p weavepy-vm", 1)
        start = s.index(" --extra ")
        end = s.index(" > target/jit-assertion-exits-snapshot.txt", start)
        extras = [new, "check_jit_assertion_exits.sh", "validate_jit_assertion_exits.sh", "check_jit_assertion_exits_extra.py", "inspect_jit_assertion_exits.py", "measure_jit_assertion_exits_focused.sh", "measure_jit_assertion_exits_full.sh", "measure_verified_python_components_with_reference.py", "jit-assertion-exits-protocol.md"]
        s = s[:start] + " --extra " + " ".join("target/" + x for x in extras) + s[end:]
    if new.startswith("check_") and new.endswith(".sh"):
        s = s.replace("for test in ", "for test in test_jit_assertion_exits ", 1)
    p.write_text(s)

p = Path("target/measure_jit_assertion_exits_focused.sh")
assert not p.exists()
p.write_text('''#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/jit-assertion-exits-validation-stage.txt)" = done
python3.14 - <<'CHECK'
import json
from pathlib import Path
assert json.loads(Path('target/jit-assertion-exits-extra-checks/report.json').read_text())['status']=='passed'
assert json.loads(Path('target/jit-assertion-exits-coverage/report.json').read_text())['assertions_passed']
CHECK
output=target/jit-assertion-exits-focused
test ! -e "$output"
mkdir "$output"
base="$(cat target/jit-assertion-exits-previous.txt)"
reference="$(cat target/jit-assertion-exits-reference.txt)"
binary=target/release/weavepy-runtime-jit-assertion-exits
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf '13 warm assertion/datetime/recovery controls\\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/assertion-exit-inputs/warm --out "$output/warm" --samples 7 > "$output/warm.txt" 2>&1
printf 'four cold assertion frequencies\\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/assertion-exit-inputs/cold --out "$output/cold" --samples 7 --cold > "$output/cold.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
printf 'done\\n' > "$output/stage.txt"
''')
s = Path("target/summarize_compact_intern_pools.py").read_text()
s = s.replace("compact-intern-pools-focused", "jit-assertion-exits-focused").replace("intern-pool", "assertion-exit")
s = s.replace('[("warm", 6), ("cold", 3)]', '[("warm", 13), ("cold", 4)]').replace('== 9', '== 17').replace('All nine controls', 'All 17 controls')
p = Path("target/summarize_jit_assertion_exits.py")
assert not p.exists()
p.write_text(s)
print("Prepared assertion build, checks, and 17-control focused/full methods.")

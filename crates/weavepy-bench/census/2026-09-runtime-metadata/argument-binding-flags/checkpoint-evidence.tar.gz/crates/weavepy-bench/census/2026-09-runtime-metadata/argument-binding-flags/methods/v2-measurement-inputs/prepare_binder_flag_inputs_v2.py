"""Correct the new many-local control before any timing; preserve v1 evidence."""
import hashlib,json
from pathlib import Path
old=Path('target/binder-flag-inputs');root=Path('target/binder-flag-inputs-v2');root.mkdir()
prepared=json.loads((old/'preparation.json').read_text());rows={}
for name,row in prepared['rows'].items():
    p=Path(row['path']);source=p.read_text();assert hashlib.sha256(source.encode()).hexdigest()==row['source_sha256']
    if name=='many_body_locals':
        assert 'def leaf(a, b=2):' in source
        source=source.replace('def leaf(a, b=2):','def leaf(a, b=2, c=3):').replace('return body0 + body129 + b','return body0 + body129 + b + c')
    p=root/(name+'.py');p.write_text(source)
    driver=Path(row['driver']).read_text().replace(str(old)+'/',str(root)+'/')
    d=root/(name+'-verify.py');d.write_text(driver)
    rows[name]={'path':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'driver':str(d),'driver_sha256':hashlib.sha256(d.read_bytes()).hexdigest()}
(root/'preparation.json').write_text(json.dumps({'work':prepared['work'],'rows':rows,'supersedes_before_timing':str(old),'reason':'The original many-body-local call supplied every argument and bypassed the binder. V2 omits one defaulted parameter. Other nine source hashes remain identical.'},indent=2)+'\n')
(root/'protocol.md').write_text((old/'protocol.md').read_text()+'''\nV2 correction before any timing: many_body_locals now has a third defaulted
parameter omitted at its call site. The v1 trace showed 850 native-to-native
calls and only three generic dynamic calls, so it was not a warm binding-storage
control. Retain v1 inputs, methods, and traces. Require >=500 generic dynamic
calls in v2 before timing. The other nine benchmark source bytes are unchanged.
''')
for name in rows:
 if name!='many_body_locals':assert rows[name]['source_sha256']==prepared['rows'][name]['source_sha256']
p=Path('target/inspect_binder_signature_paths_v2.py');assert not p.exists()
s=Path('target/inspect_binder_signature_paths.py').read_text().replace('target/binder-flag-inputs','target/binder-flag-inputs-v2').replace('target/binder-flags-signature-paths','target/binder-flags-signature-paths-v2')
s=s.replace("report['assertions_passed'] = True", "assert report['rows']['many_body_locals']['runs']['new']['stats']['generic dyn calls'] >= 500\nreport['assertions_passed'] = True")
p.write_text(s)
p=Path('target/measure_binder_flags_focused_v2.sh');assert not p.exists()
s=Path('target/measure_binder_flags_focused.sh').read_text().replace('--inputs target/binder-flag-inputs ', '--inputs target/binder-flag-inputs-v2 ')
s=s.replace("assert json.loads(Path('target/binder-flags-coverage/report.json').read_text())['assertions_passed']", "assert json.loads(Path('target/binder-flags-coverage/report.json').read_text())['assertions_passed']\nassert json.loads(Path('target/binder-flags-signature-paths-v2/report.json').read_text())['assertions_passed']")
p.write_text(s)
root=Path('target/binder-flags-v2-measurement-inputs');root.mkdir()
paths=list(json.loads(Path('target/binder-flags-measurement-inputs/index.json').read_text()))
paths+=['target/inspect_binder_signature_paths.py','target/inspect_binder_signature_paths_v2.py','target/prepare_binder_flag_inputs_v2.py','target/measure_binder_flags_focused_v2.sh']
records={}
for name in paths:
 p=Path(name);b=p.read_bytes();(root/p.name).write_bytes(b);records[name]=hashlib.sha256(b).hexdigest()
(root/'index.json').write_text(json.dumps(records,indent=2)+'\n')
print('Preserved v1; froze corrected v2 controls and',len(records),'method files before timing.')

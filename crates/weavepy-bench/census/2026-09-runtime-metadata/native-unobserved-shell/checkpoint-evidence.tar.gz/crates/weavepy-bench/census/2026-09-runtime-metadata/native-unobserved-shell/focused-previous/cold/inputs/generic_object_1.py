import os
class Fn:
    def __call__(self, value):
        return len(value)
FN = Fn()
VALUE = "shared payload"

def bench(n):
    f = FN
    value = VALUE
    total = 0
    for i in range(n):
        total += f(value)
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

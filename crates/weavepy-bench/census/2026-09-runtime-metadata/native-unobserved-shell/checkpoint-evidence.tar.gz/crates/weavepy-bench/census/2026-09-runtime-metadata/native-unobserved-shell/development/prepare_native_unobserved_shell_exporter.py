"""Prepare archival of the corrected shell trial and its untimed first draft."""
from pathlib import Path
s=Path('target/export_native_dynamic_small_args.py').read_text().replace('native-dynamic-small-args','native-unobserved-shell').replace('native_dynamic_small_args','native_unobserved_shell')
s=s.replace('Preserve the complete short-argument trial, including stack and timing losses.','Preserve native shell reuse, every measurement, and the untimed ownership correction.')
s=s.replace("['checks','validation','preimages','baseline-coverage','baseline-coverage-v2','codegen']", "['checks','validation','preimages','baseline-oracles','baseline-coverage','baseline-coverage-v2','codegen']")
s=s.replace("tree('target/native-frame-shell-identity-audit','frame-identity-followup',['frozen'])", "tree('target/native-unobserved-shell-pre-owner-check-v1','pre-owner-check-v1')")
s=s.replace("'check_native_unobserved_shell_native.sh','apply_native_unobserved_shell.py',", "'check_native_unobserved_shell_native.sh','check_native_unobserved_shell_native_02.sh',\n             'prepare_native_unobserved_shell_exporter.py','check_native_unobserved_shell_frame_identity.py',\n             'inspect_native_unobserved_shell_codegen.py',")
s=s.replace('performance_phase76_status.md','performance_phase77_status.md')
start=s.index("lines=['# Initialized arguments")
end=s.index("for ref in ['previous','retained']:",start)
s=s[:start]+'''lines=['# Reuse unobserved native activation shells','',
    'Decision: '+decision['decision'],'',*decision['findings'],'',
    'Next step: '+decision['next_step'],'',
    f"Candidate: `{binary['sha256']}`, {binary['bytes']:,} bytes.",
    'Direct reference: time formatter 6810,',
    '`681043b9f62cbd4fdb3f73756ecdf8ac877c1923b6a509f11ff1128dc973443c`.',
    'Retained acceptance reference: thin value storage bf2,',
    '`bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4`.','',
    'The preceding short-argument trial was deferred. Both source preimages and',
    'the 6810 CLI were restored, and all 339 predecessor source identities matched',
    'before this experiment. The new candidate keeps the preceding default-binding',
    'and time-formatter experiments but excludes the short-argument implementation.','',
    'A native CallCtx retains at most one unobserved shell. The cache is empty',
    'throughout each callback, with no cache or mutable shell borrow across Python.',
    'The exact call-site lasti is refreshed before pushing the shell. After the',
    'callback, exclusive ownership is established with Rc::get_mut before the',
    'materialization flag is read. Strong, weak, and frame observers all exclude',
    'reuse. Each of four context constructors starts empty; framed entries pass',
    'through. No new raw pointer, allocator, or ownership representation is added.',
    'Callback arguments and results are not cached. The cache lasts only for its',
    'activation, whose context already owns the shell metadata.','',
    'Source review tightened the observation-check order before timing. The first',
    'draft had read the flag before checking exclusive ownership. Its executable',
    'identity, source/method snapshot, and passing 353 VM / 156 C API / lint / no-JIT',
    'results remain under pre-owner-check-v1. This was a source-review correction,',
    'not an observed Python failure or timed regression. Validation was rerun for',
    'the corrected predicate before its source and method identities were frozen.','',
    'Validation passes 353 VM tests, 156 C API tests, strict format/lint, no-JIT',
    'checking, 99 targeted Python checks, and all 275 outside-sandbox compatibility',
    'checks. Test-only native counters require actual allocation, at least 100',
    'reuses, and at least 10 observer exclusions. The separate Rust test exercises',
    'strong, weak, and materialized observers. No counters are present in release.',
    'The portable oracle covers nested calls, captured code identity, exceptions',
    'without replay, global mutation/deoptimization, and weak-reference lifetimes.',
    'It passes on CPython and predecessor JIT/interpreter/GIL0. GIL0 disables JIT',
    'and provides correctness evidence only. Optional extension checks may test',
    'availability internally.','',
    f"All {len(frozen['sources'])} source and {len(frozen['methods'])} method/input identities remain unchanged.",
    'Static helper and native-entry prologues are preserved under codegen. Reduced',
    'allocation alone is not evidence of lower stack use or peak RSS. A cache per',
    'nested activation is a possible memory cost, covered by the recursive control.',
    'Observed build durations are not controlled build-time comparisons.','',
    'The original 26 fixture sources are unchanged. The first 28-input set adds',
    'single-callback and observed-frame controls; it and its baseline traces remain.',
    'The v2 set preserves all 28 and adds recursive callbacks. All 29 independent',
    'CPython checksums pass twice. Untimed traces prove intended generic drivers',
    'compile and exceed 30,000 generic calls, while compiled aliases and the single/',
    'recursive native callees compile and exceed 30,000 native calls. The original',
    'wide-argument and tuple-unpack controls remain interpreted. Inherited formatter',
    'and binding controls retain their observed paths. Coverage is not timing.','',
    'A separate frame-identity audit confirms the same known mismatch: five calls',
    'observe one parent-frame identity on CPython and WeavePy interpreter/GIL0,',
    'but distinct identities on both predecessor and candidate JIT. The driver',
    'compiles without deoptimizing. Observed shells are excluded from reuse. This',
    'candidate does not fix native frame identity, full locals materialization,',
    'frame.clear/continuation behavior, or final instruction positions.','',
    'Four timing stages run sequentially under the exclusive lease and unchanged',
    'load gate. Every dependent launch follows inspected completion. No owned',
    'build, test, profile, install, runtime edit, or active-harness edit overlaps a',
    'stage. Keep every launched sample, all frozen-cache assertions, failures,',
    'losses, load observations, and VM/swap snapshots. Ratios below 1 favor the',
    'candidate. Means aggregate per-fixture medians of paired ratios. Keep the',
    'historical 21-row, 23-workload, and 24-process cohorts separate. Retained-',
    'baseline results are measured directly, not multiplied across unrelated runs.','']
''' + s[end:]
s=s.replace('# Short generic native-call arguments and all observed tradeoffs.','# Native activation shell reuse and all observed tradeoffs.')
s=s.replace('The [short generic-call argument trial]','The [unobserved native-shell trial]').replace('call-path validation, stack tradeoffs, and complete direct and retained-baseline comparisons.','observer exclusion, ownership review, and complete direct and retained-baseline comparisons.')
p=Path('target/export_native_unobserved_shell.py');assert not p.exists();p.write_text(s)
print(p)

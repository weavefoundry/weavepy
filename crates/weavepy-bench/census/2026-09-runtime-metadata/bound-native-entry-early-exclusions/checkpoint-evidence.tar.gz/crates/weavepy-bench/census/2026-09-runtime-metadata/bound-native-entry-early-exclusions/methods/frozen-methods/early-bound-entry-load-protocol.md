# Narrow early-exclusion measurement protocol

Compare the new candidate to retained 539c, independently of archived ca6b.
Use the same ten call shapes and four warm/four cold exception cases and work
sizes as the completed ca6b experiment. Cold cases use the original timer-bearing
sources from its continuation. Seven paired samples, exact CPython value checks
in JIT/interpreter/gil0, and isolated binary-SHA frozen caches. No samples yet.

After full compatibility and explicit native coverage pass, require load 1/5
minute averages <=4 for three observations ten seconds apart, maximum wait 600s.
If the gate expires without a child, preserve it before deciding on a separate
explicit diagnostic. Never filter/retry samples after a child starts. Record
VM/swap before/after and load throughout. No competing owned build/test/profile.

Then measure all 24 unchanged fixtures, five paired samples in both modes and
CPython, plus nine startup/import cases with 31 pairs (helper JIT disabled).
Use a fresh strict gate. Record all 21/23/24 cohorts and every wall/CPU/RSS metric,
including regressions. Do not infer universal, energy, portability, controlled
build-time, or free-threaded performance from this experiment.

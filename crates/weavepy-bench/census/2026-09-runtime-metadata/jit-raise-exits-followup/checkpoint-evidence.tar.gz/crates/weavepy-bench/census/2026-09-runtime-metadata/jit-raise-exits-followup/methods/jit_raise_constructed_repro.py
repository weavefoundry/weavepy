"""Reproduce constructed exception loss in a warmed validation method."""
import _pyio

class Check:
    def __init__(self):
        self.closed = False

    def plain(self):
        if self.closed:
            raise ValueError('closed')

    def conditional(self, msg=None):
        if self.closed:
            raise ValueError('closed' if msg is None else msg)

    def conditional_return(self, msg=None):
        if self.closed:
            raise ValueError('closed' if msg is None else msg)
        return 7

for name in ('plain', 'conditional', 'conditional_return'):
    node = Check()
    method = getattr(node, name)
    for i in range(400):
        method()
    node.closed = True
    try:
        method()
    except BaseException as error:
        print(name, type(error).__name__, str(error))

stream = _pyio.IOBase()
for i in range(400):
    stream.flush()
stream.close()
try:
    stream.flush()
except BaseException as error:
    print('io', type(error).__name__, str(error))

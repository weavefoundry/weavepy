//! Bridge between the C-API and the running WeavePy interpreter.
//!
//! When the VM dispatches into a C function it briefly publishes a
//! pointer to itself plus the callee's globals/builtins via a thread-
//! local cell. The C-API helpers ([`crate::abstract_::PyObject_Call`],
//! [`crate::module::PyImport_ImportModule`], etc.) read from that
//! cell to find the live interpreter.
//!
//! Calls *into* the C extension always run on the same OS thread
//! that owns the interpreter (WeavePy is single-threaded today),
//! so the cell can be a plain `RefCell<Option<…>>`.

use std::sync::atomic::{AtomicPtr, Ordering};
use std::sync::Once;
use weavepy_vm::sync::Rc;
use weavepy_vm::sync::RefCell;

use weavepy_vm::object::{DictData, Object};
use weavepy_vm::Interpreter;

thread_local! {
    /// The interpreter currently executing C code. `None` when no
    /// extension call is on the stack.
    static ACTIVE: RefCell<Option<ActiveContext>> = const { RefCell::new(None) };
}

/// Snapshot of "what's running right now" — the live interpreter,
/// the globals dict the active call site is binding into, and the
/// extension module that was the target of the import. The C-API
/// helpers consult this to (a) call back into the VM and (b)
/// publish module-level state.
pub struct ActiveContext {
    pub interp: *mut Interpreter,
    pub globals: Option<Rc<weavepy_vm::sync::RefCell<DictData>>>,
    pub current_module: Option<Object>,
}

/// Push an active context for the duration of `body`. Also caches
/// the live interpreter pointer in [`LAST_INTERPRETER`] so post-
/// extension callbacks (dunder shims, class methods) can find a
/// VM even after `body` returns.
pub fn with_active<R>(ctx: ActiveContext, body: impl FnOnce() -> R) -> R {
    // In an embedding host (`Py_Initialize*`) the fallback pointer stays
    // pinned to the owned main interpreter: a bridged call made while a
    // `Py_NewInterpreter` sub-interpreter is current must not leave the
    // cache pointing at an interpreter `Py_EndInterpreter` is about to
    // drop (test_embed test_repeated_init_and_subinterpreters).
    if !ctx.interp.is_null() && crate::embed::owned_interpreter().is_none() {
        LAST_INTERPRETER.store(ctx.interp, Ordering::SeqCst);
    }
    ACTIVE.with(|cell| {
        let prev = cell.borrow_mut().replace(ctx);
        let out = body();
        *cell.borrow_mut() = prev;
        out
    })
}

/// Read the active context. Returns `None` when no extension call
/// is on the stack.
///
/// `try_with` on the read paths: C++ static destructors in extensions
/// probe the C-API (`Py_IsInitialized`, `Py_DECREF`) from `exit()`
/// after this thread's TLS is destroyed — answer "no context" instead
/// of aborting (RFC 0076 WS5, libtorch shm-manager child).
pub fn with_current<R>(f: impl FnOnce(&ActiveContext) -> R) -> Option<R> {
    ACTIVE
        .try_with(|cell| cell.borrow().as_ref().map(f))
        .unwrap_or(None)
}

/// Live interpreter pointer if any.
pub fn current_interpreter_mut() -> Option<*mut Interpreter> {
    ACTIVE
        .try_with(|cell| cell.borrow().as_ref().map(|c| c.interp))
        .unwrap_or(None)
}

/// Run a closure with a `&mut Interpreter` borrow if a context is
/// active, returning `None` otherwise.
pub fn with_interp_mut<R>(f: impl FnOnce(&mut Interpreter) -> R) -> Option<R> {
    let p = effective_interpreter_mut()?;
    if p.is_null() {
        return None;
    }
    Some(f(unsafe { &mut *p }))
}

/// "Last known" interpreter pointer. Updated whenever an
/// extension call sets up an active context, and consulted by
/// re-entrant C-API calls (dunder shims, method wrappers) that
/// happen *after* the original entry point unwound — at that point
/// the ACTIVE thread-local has been cleared but we still need to
/// route `PyObject_CallObject(cls, …)` back into the VM.
static LAST_INTERPRETER: AtomicPtr<Interpreter> = AtomicPtr::new(std::ptr::null_mut());

/// Resolve the most relevant interpreter pointer:
///   1. The currently-active extension context, if any.
///   2. The interpreter on the VM's `publish_interpreter_ptr` stack
///      (set on every `call_object` / `iter_object` /
///      `iter_next_object` entry — guaranteed to be live for the
///      duration of that call).
///   3. Otherwise the most recently seen interpreter from any
///      `with_active` call on this process. (Fallback for legacy
///      paths; the pointer here may be stale if the owning frame
///      has unwound, so it's only consulted as a last resort.)
pub fn effective_interpreter_mut() -> Option<*mut Interpreter> {
    if let Some(p) = current_interpreter_mut() {
        if !p.is_null() {
            return Some(p);
        }
    }
    if let Some(p) = weavepy_vm::vm_singletons::current_interpreter_ptr() {
        if !p.is_null() {
            return Some(p);
        }
    }
    let last = LAST_INTERPRETER.load(Ordering::SeqCst);
    if last.is_null() {
        None
    } else {
        Some(last)
    }
}

/// If no active context is on the stack, push a temporary one
/// pointing at the most recent known interpreter. Otherwise run
/// `body` directly. Used by dunder shims and class-method wrappers
/// so re-entrant `PyObject_CallObject` calls find a live VM even
/// when the original entry point left no ACTIVE behind.
///
/// Resolves the interpreter pointer using the same priority as
/// [`effective_interpreter_mut`]: VM-published first (always
/// live for the duration of the call), then `LAST_INTERPRETER`
/// (best-effort, may be stale).
/// Cached `WEAVEPY_TRACE_EA` gate — [`ensure_active`] wraps every
/// bridged C invocation, so it must not `getenv` per call.
fn ea_trace_enabled() -> bool {
    use std::sync::OnceLock;
    static ON: OnceLock<bool> = OnceLock::new();
    *ON.get_or_init(|| std::env::var_os("WEAVEPY_TRACE_EA").is_some())
}

pub fn ensure_active<R>(body: impl FnOnce() -> R) -> R {
    // RFC 0047 (wave 5): mark a C-extension call live on this thread for
    // the duration of `body`. Every bridged C invocation (dunder shims,
    // `PyCFunction`s, descriptors, tp_call, foreign hooks) funnels through
    // here, so the VM's prompt reaper can tell "plain bytecode, no
    // extension frame below" (`depth == 0` — reclaiming a dead escaped
    // subgraph is as safe as CPython's own `tp_dealloc`) from "inside a C
    // call that may hold borrowed body pointers" (`depth > 0` — defer
    // memory reclamation to the tracing collector).
    let _cext_guard = weavepy_vm::vm_singletons::enter_cext_call();
    if current_interpreter_mut().is_some() {
        if ea_trace_enabled() {
            eprintln!("[EA] nested (skip flush)");
        }
        // Context is already live here — a safe point to publish the static
        // builtins' `tp_bases`/`tp_mro` (run-once; needs the allocator).
        crate::types::publish_static_type_hierarchy();
        let r = body();
        // A `PySequence_Fast` result is read through raw macros between the
        // extension's nested VM callbacks; republish just those watched
        // lists so a callback's mutation is visible immediately (RFC 0076
        // WS1 — numpy's "Content of sequences changed" detection). The
        // empty-set check is one TLS read in the steady state.
        if !crate::mirror::no_watched_lists() {
            unsafe { crate::mirror::sync_watched_lists() };
        }
        return r;
    }
    if ea_trace_enabled() {
        eprintln!("[EA] outermost (flush)");
    }
    // Outermost VM→C transition. Re-publish any VM-mutated faithful list
    // mirrors into their `ob_item` buffers first, so a stock extension's
    // inlined `PyList_GET_ITEM` macro reads the VM's latest mutations rather
    // than the buffer that was current when the list was last seeded. This is
    // the single choke point through which *every* bridged C call (foreign
    // hooks, tp_call, dunder shims, descriptors) passes (RFC 0047, wave 5).
    unsafe { crate::mirror::flush_seeded_lists() };
    let interp = if let Some(p) = weavepy_vm::vm_singletons::current_interpreter_ptr() {
        p
    } else {
        let last = LAST_INTERPRETER.load(Ordering::SeqCst);
        if last.is_null() {
            return body();
        }
        last
    };
    let ctx = ActiveContext {
        interp,
        globals: None,
        current_module: None,
    };
    let r = with_active(ctx, || {
        // First VM→C transition with a fresh context: publish the static
        // builtins' `tp_bases`/`tp_mro` (run-once) now that the allocator is
        // reachable, before any extension C code can read those slots.
        crate::types::publish_static_type_hierarchy();
        body()
    });
    // Outermost C→VM return: adopt macro writes into seeded lists that were
    // attached to a parent container mid-call and never crossed again on
    // their own (orjson's iterative deserializer; see
    // `reconcile_seeded_lists`).
    unsafe { crate::mirror::reconcile_seeded_lists() };
    // The macro-read watches (RFC 0076 WS1) are scoped to one extension-call
    // window; the extension's `PySequence_Fast` results are dead past this
    // return.
    crate::mirror::clear_watched_lists();
    r
}

/// RFC 0075 (embedding): publish an interpreter the capi layer owns
/// (created by `Py_Initialize*` in a C host process) so every entry
/// point that consults [`effective_interpreter_mut`] finds it.
pub(crate) fn note_interpreter(ptr: *mut Interpreter) {
    LAST_INTERPRETER.store(ptr, Ordering::SeqCst);
}

/// RFC 0075 (embedding): forget the published interpreter at
/// `Py_FinalizeEx` so a post-fini capi call fails cleanly instead of
/// dereferencing a dropped interpreter.
pub(crate) fn clear_interpreter() {
    LAST_INTERPRETER.store(std::ptr::null_mut(), Ordering::SeqCst);
}

static INIT: Once = Once::new();

/// Initialise everything that needs to be live before any
/// extension code runs: static type bridges, singleton `ob_type`s,
/// statically-initialised exception pointers.
pub fn ensure_initialised() {
    INIT.call_once(|| {
        // RFC 0046 (wave 4): optional native crash backtrace for debugging
        // faults inside a freshly-loaded extension's initialiser.
        if std::env::var_os("WEAVEPY_CRASH_BT").is_some() {
            extern "C" {
                fn weavepy_install_crash_handler();
            }
            unsafe { weavepy_install_crash_handler() };
        }
        crate::types::init_static_types();
        crate::singletons::init_singleton_types(
            crate::types::_PyNone_Type.as_ptr(),
            crate::types::PyBool_Type.as_ptr(),
            crate::types::_PyNotImplemented_Type.as_ptr(),
            crate::types::PyEllipsis_Type.as_ptr(),
        );
        crate::errors::init_static_exceptions();
        // Bridge C `tp_traverse` / `tp_clear` into the tracing collector
        // (RFC 0044, WS4) before any extension GC type can be created.
        crate::gc_bridge::install();
        // Install the hook that frees an inline instance's faithful body
        // when its native instance is collected (RFC 0045, WS1).
        crate::instance::install();
        // Install the hook that releases a capsule's retained box when its
        // VM-side soul drops (RFC 0045, WS5 — the `import_array()` idiom).
        crate::capsule::install();
        // Install the foreign-object proxy bridge so a `PyObject` the
        // extension minted itself (numpy ndarray/descr/ufunc) round-trips
        // through the VM opaquely (RFC 0046, wave 4).
        crate::foreign::install();
    });
}

/// Execute `body` with `ctx` active and clear the per-thread
/// "current exception" cell on entry. Mirrors the CPython
/// invariant that a fresh C call sees no pending error.
pub fn enter_extension_call<R>(ctx: ActiveContext, body: impl FnOnce() -> R) -> R {
    ensure_initialised();
    crate::errors::clear_thread_local();
    with_active(ctx, body)
}

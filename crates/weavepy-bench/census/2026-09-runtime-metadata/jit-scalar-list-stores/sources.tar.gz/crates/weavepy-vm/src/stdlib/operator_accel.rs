//! The `_operator` accelerator module.
//!
//! WeavePy ships a pure-Python `operator` (`stdlib/python/operator_mod.py`)
//! whose function bodies are written in Python, guarded by
//! `from _operator import *`. CPython's real `operator.py` does the same and
//! relies on `_operator` being a **C** module: its functions are
//! `builtin_function_or_method`s, which (unlike a Python `def`) are *not*
//! descriptors and so do **not** bind `self` when stored as a class
//! attribute. The stdlib leans on this — e.g.
//! `glob._StringGlobber.concat_path = operator.add` then calls
//! `self.concat_path(path, text)` expecting `operator.add(path, text)`, not
//! `add(self, path, text)`. If `operator.add` were a plain Python function it
//! would bind `self` and raise "add() takes 2 positional arguments but 3 were
//! given".
//!
//! So we expose the operator surface here as non-binding native builtins that
//! delegate to the interpreter's own operation machinery (identical to what
//! the `BINARY_OP`/`COMPARE_OP`/`UNARY_OP` bytecodes do, dunders and all).
//! `_compare_digest` also lives here (constant-time compare for `hmac`).

use crate::sync::Rc;
use crate::sync::RefCell;

use crate::error::{type_error, RuntimeError};
use crate::import::ModuleCache;
use crate::object::{BuiltinFn, DictData, DictKey, Object, PyModule};
use weavepy_compiler::{BinOpKind, CompareKind, UnaryKind};

pub fn build(_cache: &ModuleCache) -> Rc<PyModule> {
    let dict = Rc::new(RefCell::new(DictData::default()));
    {
        let mut d = dict.borrow_mut();
        d.insert(
            DictKey(Object::from_static("__name__")),
            Object::from_static("_operator"),
        );
        d.insert(
            DictKey(Object::from_static("__doc__")),
            Object::from_static("Operator interface."),
        );

        // Names exported, in declaration order, so `from _operator import *`
        // is deterministic (CPython's C module relies on dir() minus
        // underscores; we publish an explicit `__all__`).
        let mut names: Vec<Object> = Vec::new();

        macro_rules! reg {
            ($name:literal, $f:expr) => {{
                let f = Object::Builtin(Rc::new(BuiltinFn {
                    name: $name,
                    binds_instance: false,
                    call: Box::new($f),
                    call_kw: None,
                }));
                // Attribute `__module__ == "_operator"` (CPython's C module)
                // so `pickle` can round-trip `operator.<op>` — it resolves
                // `getattr(_operator, qualname) is obj`. Without this the
                // builtin would default to `"builtins"` and pickle would find
                // the unrelated builtin of the same name (e.g. `pow`).
                crate::descr_registry::register_module(&f, "_operator");
                d.insert(DictKey(Object::from_static($name)), f);
                names.push(Object::from_static($name));
            }};
        }

        // -- binary arithmetic / bitwise --------------------------------
        reg!("add", |a| binary(a, BinOpKind::Add, "add"));
        reg!("sub", |a| binary(a, BinOpKind::Sub, "sub"));
        reg!("mul", |a| binary(a, BinOpKind::Mult, "mul"));
        reg!("truediv", |a| binary(a, BinOpKind::Div, "truediv"));
        reg!("floordiv", |a| binary(a, BinOpKind::FloorDiv, "floordiv"));
        reg!("mod", |a| binary(a, BinOpKind::Mod, "mod"));
        reg!("pow", |a| binary(a, BinOpKind::Pow, "pow"));
        reg!("lshift", |a| binary(a, BinOpKind::LShift, "lshift"));
        reg!("rshift", |a| binary(a, BinOpKind::RShift, "rshift"));
        reg!("and_", |a| binary(a, BinOpKind::BitAnd, "and_"));
        reg!("or_", |a| binary(a, BinOpKind::BitOr, "or_"));
        reg!("xor", |a| binary(a, BinOpKind::BitXor, "xor"));
        reg!("matmul", |a| binary(a, BinOpKind::MatMult, "matmul"));

        // -- sequence concatenation ---------------------------------------
        // CPython's `_operator.concat` is `PySequence_Concat` — the *left
        // slot* protocol, not the expression `a + b`: no `__radd__`
        // fallback, and a C type's real `sq_concat` runs even when it
        // only exists to raise (numpy's `array_concat`; RFC 0076 WS1,
        // test_shape_base.test_operator_concat).
        reg!("concat", op_concat);

        // -- in-place variants ------------------------------------------
        reg!("iadd", |a| inplace(a, BinOpKind::Add, "iadd"));
        reg!("isub", |a| inplace(a, BinOpKind::Sub, "isub"));
        reg!("imul", |a| inplace(a, BinOpKind::Mult, "imul"));
        reg!("itruediv", |a| inplace(a, BinOpKind::Div, "itruediv"));
        reg!("ifloordiv", |a| inplace(
            a,
            BinOpKind::FloorDiv,
            "ifloordiv"
        ));
        reg!("imod", |a| inplace(a, BinOpKind::Mod, "imod"));
        reg!("ipow", |a| inplace(a, BinOpKind::Pow, "ipow"));
        reg!("ilshift", |a| inplace(a, BinOpKind::LShift, "ilshift"));
        reg!("irshift", |a| inplace(a, BinOpKind::RShift, "irshift"));
        reg!("iand", |a| inplace(a, BinOpKind::BitAnd, "iand"));
        reg!("ior", |a| inplace(a, BinOpKind::BitOr, "ior"));
        reg!("ixor", |a| inplace(a, BinOpKind::BitXor, "ixor"));
        reg!("imatmul", |a| inplace(a, BinOpKind::MatMult, "imatmul"));

        // -- rich comparisons -------------------------------------------
        reg!("lt", |a| compare(a, CompareKind::Lt, "lt"));
        reg!("le", |a| compare(a, CompareKind::LtE, "le"));
        reg!("eq", |a| compare(a, CompareKind::Eq, "eq"));
        reg!("ne", |a| compare(a, CompareKind::NotEq, "ne"));
        reg!("gt", |a| compare(a, CompareKind::Gt, "gt"));
        reg!("ge", |a| compare(a, CompareKind::GtE, "ge"));

        // -- unary ------------------------------------------------------
        reg!("neg", |a| unary(a, UnaryKind::Neg, "neg"));
        reg!("pos", |a| unary(a, UnaryKind::Pos, "pos"));
        reg!("invert", |a| unary(a, UnaryKind::Invert, "invert"));
        reg!("inv", |a| unary(a, UnaryKind::Invert, "inv"));
        reg!("not_", op_not);
        reg!("truth", op_truth);
        reg!("is_", op_is);
        reg!("is_not", op_is_not);

        d.insert(
            DictKey(Object::from_static("__all__")),
            Object::new_list(names),
        );

        // CPython's `attrgetter` / `itemgetter` / `methodcaller` are C types:
        // calling one pushes no Python frame. pandas'
        // `find_stack_level()`-based warnings count stack frames between the
        // warn site and the caller, so the pure-Python `__call__` of the
        // frozen `operator` module misattributes warnings (a
        // `<frozen operator>` frame where CPython has none). The frozen
        // module splices these natives in as `__call__`.
        type CallBox = Box<dyn Fn(&[Object]) -> Result<Object, RuntimeError> + Send + Sync>;
        // The dotted-internal names display as `__call__`
        // (`builtin_display_name`) while keeping each function's
        // `__text_signature__` distinct (`builtin_text_signature`), so
        // `inspect.signature(attrgetter('a'))` reports CPython's `(obj, /)`.
        for (export, name, f) in [
            (
                "_attrgetter_call",
                ".attrgetter.__call__",
                Box::new(attrgetter_call) as CallBox,
            ),
            (
                "_itemgetter_call",
                ".itemgetter.__call__",
                Box::new(itemgetter_call) as CallBox,
            ),
            (
                "_methodcaller_call",
                ".methodcaller.__call__",
                Box::new(methodcaller_call) as CallBox,
            ),
        ] {
            let obj = Object::Builtin(Rc::new(BuiltinFn {
                name,
                binds_instance: false,
                call: f,
                call_kw: None,
            }));
            d.insert(DictKey(Object::from_static(export)), obj);
        }

        // Post-splice registration hook: `operator_mod.py` assigns the
        // natives above into the class dicts (`attrgetter.__call__ = …`)
        // and then calls this with the three classes. Tagging each
        // class's `__call__` as a Method descriptor makes it present as
        // CPython's `method_descriptor` — crucially giving it the
        // type-level `__get__` that `inspect._descriptor_get` uses to
        // bind it, so `inspect.signature(attrgetter('a'))` strips the
        // clinic `$self` and reports `(obj, /)`
        // (test_operator.test_attrgetter_signature and friends).
        let register_calls = Object::Builtin(Rc::new(BuiltinFn {
            name: "_register_call_descriptors",
            binds_instance: false,
            call: Box::new(|args: &[Object]| {
                for arg in args {
                    let Object::Type(cls) = arg else {
                        return Err(type_error(
                            "_register_call_descriptors: arguments must be classes",
                        ));
                    };
                    let call_obj = cls
                        .dict
                        .borrow()
                        .get(&DictKey(Object::from_static("__call__")))
                        .cloned();
                    if let Some(obj) = call_obj {
                        crate::descr_registry::register(
                            &obj,
                            crate::descr_registry::DescrKind::Method,
                            cls.clone(),
                            "__call__",
                            None,
                        );
                    }
                }
                Ok(Object::None)
            }),
            call_kw: None,
        }));
        d.insert(
            DictKey(Object::from_static("_register_call_descriptors")),
            register_calls,
        );

        let compare_digest_fn = Object::Builtin(Rc::new(BuiltinFn {
            name: "_compare_digest",
            binds_instance: false,
            call: Box::new(compare_digest),
            call_kw: None,
        }));
        crate::descr_registry::register_module(&compare_digest_fn, "_operator");
        d.insert(
            DictKey(Object::from_static("_compare_digest")),
            compare_digest_fn,
        );
    }
    Rc::new(PyModule {
        name: "_operator".to_owned(),
        filename: None,
        dict,
    })
}

/// Borrow the active interpreter published on this thread by the dispatch
/// loop. Always present while a builtin runs.
fn with_interp<F, R>(f: F) -> Result<R, RuntimeError>
where
    F: FnOnce(&mut crate::Interpreter) -> Result<R, RuntimeError>,
{
    let ptr = crate::vm_singletons::current_interpreter_ptr()
        .ok_or_else(|| type_error("_operator: no active interpreter"))?;
    // SAFETY: published by the enclosing VM frame on this thread.
    let interp = unsafe { &mut *ptr };
    f(interp)
}

fn two_args<'a>(args: &'a [Object], name: &str) -> Result<(&'a Object, &'a Object), RuntimeError> {
    match (args.first(), args.get(1)) {
        (Some(a), Some(b)) if args.len() == 2 => Ok((a, b)),
        _ => Err(type_error(format!(
            "{name} expected 2 arguments, got {}",
            args.len()
        ))),
    }
}

fn one_arg<'a>(args: &'a [Object], name: &str) -> Result<&'a Object, RuntimeError> {
    match args.first() {
        Some(a) if args.len() == 1 => Ok(a),
        _ => Err(type_error(format!(
            "{name} expected 1 argument, got {}",
            args.len()
        ))),
    }
}

fn binary(args: &[Object], op: BinOpKind, name: &str) -> Result<Object, RuntimeError> {
    let (a, b) = two_args(args, name)?;
    with_interp(|interp| interp.op_binary(a, b, op))
}

fn inplace(args: &[Object], op: BinOpKind, name: &str) -> Result<Object, RuntimeError> {
    let (a, b) = two_args(args, name)?;
    with_interp(|interp| interp.op_inplace(a, b, op))
}

fn compare(args: &[Object], op: CompareKind, name: &str) -> Result<Object, RuntimeError> {
    let (a, b) = two_args(args, name)?;
    // `operator.gt(a, b)` is the *expression* `a > b`, not `bool(a > b)`: it
    // must return the raw rich-comparison result, so a foreign object (a numpy
    // `ndarray`) yields its element-wise bool array rather than a coerced
    // scalar. pandas' `comparison_op` dispatches `Series > x` through
    // `operator.gt`; a scalar result there makes pandas treat the whole
    // comparison as invalid (`invalid_comparison`) and boolean masks break.
    with_interp(|interp| interp.rich_compare_public(a, b, op))
}

fn unary(args: &[Object], op: UnaryKind, name: &str) -> Result<Object, RuntimeError> {
    let a = one_arg(args, name)?;
    with_interp(|interp| interp.op_unary(a, op))
}

fn op_not(args: &[Object]) -> Result<Object, RuntimeError> {
    let a = one_arg(args, "not_")?;
    Ok(Object::Bool(!with_interp(|interp| interp.op_truth(a))?))
}

fn op_truth(args: &[Object]) -> Result<Object, RuntimeError> {
    let a = one_arg(args, "truth")?;
    Ok(Object::Bool(with_interp(|interp| interp.op_truth(a))?))
}

/// `operator.concat` — `PySequence_Concat` semantics (see the `reg!`
/// site). Native sequences take the VM's left-slot concat directly;
/// C-typed operands (foreign objects, instances wearing a real C type)
/// go through the cpyext bridge so an extension's `sq_concat` slot
/// runs; everything else is CPython's "can't be concatenated".
fn op_concat(args: &[Object]) -> Result<Object, RuntimeError> {
    let (a, b) = two_args(args, "concat")?;
    match a {
        Object::List(_)
        | Object::Tuple(_)
        | Object::Str(_)
        | Object::WStr(_)
        | Object::Bytes(_)
        | Object::ByteArray(_) => crate::sequence_concat_native(a, b),
        Object::Foreign(_) | Object::Instance(_) if crate::foreign::has_seq_concat() => {
            crate::foreign::seq_concat(a, b)
        }
        // No bridge (pure-VM build): a user class defining `__getitem__`
        // is a sequence, so the `nb_add` fallback applies; anything else
        // can't be concatenated (CPython `PySequence_Concat`'s tail).
        Object::Instance(inst) if inst.cls().lookup("__getitem__").is_some() => {
            with_interp(|interp| interp.op_binary(a, b, BinOpKind::Add))
        }
        _ => Err(type_error(format!(
            "'{}' object can't be concatenated",
            a.type_name_owned()
        ))),
    }
}

fn op_is(args: &[Object]) -> Result<Object, RuntimeError> {
    let (a, b) = two_args(args, "is_")?;
    Ok(Object::Bool(a.is_same(b)))
}

fn op_is_not(args: &[Object]) -> Result<Object, RuntimeError> {
    let (a, b) = two_args(args, "is_not")?;
    Ok(Object::Bool(!a.is_same(b)))
}

/// `attrgetter.__call__(self, obj, /)` without a Python frame. Reads the
/// stored `_attrs` tuple and traverses each (possibly dotted) attribute
/// path through the interpreter's attribute machinery.
fn attrgetter_call(args: &[Object]) -> Result<Object, RuntimeError> {
    let (slf, obj) = two_args(args, "attrgetter.__call__")?;
    with_interp(|interp| {
        let attrs = interp.load_attr_public(slf, "_attrs")?;
        let Object::Tuple(attrs) = &attrs else {
            return Err(type_error("attrgetter '_attrs' must be a tuple"));
        };
        let mut results = Vec::with_capacity(attrs.len());
        for attr in attrs.iter() {
            let Object::Str(path) = attr else {
                return Err(type_error("attribute name must be a string"));
            };
            let mut cur = obj.clone();
            for name in path.split('.') {
                cur = interp.load_attr_public(&cur, name)?;
            }
            results.push(cur);
        }
        if results.len() == 1 {
            Ok(results.pop().expect("one result"))
        } else {
            Ok(Object::new_tuple(results))
        }
    })
}

/// `itemgetter.__call__(self, obj, /)` without a Python frame. Subscripts
/// `obj` with each stored item through the interpreter (dunders and all).
fn itemgetter_call(args: &[Object]) -> Result<Object, RuntimeError> {
    let (slf, obj) = two_args(args, "itemgetter.__call__")?;
    with_interp(|interp| {
        let items = interp.load_attr_public(slf, "_items")?;
        let Object::Tuple(items) = &items else {
            return Err(type_error("itemgetter '_items' must be a tuple"));
        };
        let mut results = Vec::with_capacity(items.len());
        for item in items.iter() {
            results.push(interp.subscr_get_public(obj, item)?);
        }
        if results.len() == 1 {
            Ok(results.pop().expect("one result"))
        } else {
            Ok(Object::new_tuple(results))
        }
    })
}

/// `methodcaller.__call__(self, obj, /)` without a Python frame. Looks up
/// the stored method name on `obj` and tail-calls it with the stored
/// args/kwargs through the interpreter.
fn methodcaller_call(args: &[Object]) -> Result<Object, RuntimeError> {
    let (slf, obj) = two_args(args, "methodcaller.__call__")?;
    with_interp(|interp| {
        let name = interp.load_attr_public(slf, "_name")?;
        let Object::Str(name) = &name else {
            return Err(type_error("method name must be a string"));
        };
        let stored_args = interp.load_attr_public(slf, "_args")?;
        let stored_kwargs = interp.load_attr_public(slf, "_kwargs")?;
        let call_args: Vec<Object> = match &stored_args {
            Object::Tuple(xs) => xs.to_vec(),
            _ => return Err(type_error("methodcaller '_args' must be a tuple")),
        };
        let mut call_kwargs: Vec<(String, Object)> = Vec::new();
        if let Object::Dict(d) = &stored_kwargs {
            for (k, v) in d.borrow().iter() {
                let Object::Str(s) = &k.0 else {
                    return Err(type_error("keywords must be strings"));
                };
                call_kwargs.push((s.to_string(), v.clone()));
            }
        }
        let method = interp.load_attr_public(obj, name)?;
        let globals = interp.builtins_dict();
        interp.call(&method, &call_args, &call_kwargs, &globals)
    })
}

/// Constant-time comparison, ported from CPython's `_tscmp`. Returns `true`
/// when the inputs are equal. Branch-free over the byte contents so the
/// running time leaks only the (already public) length.
fn tscmp(a: &[u8], b: &[u8]) -> bool {
    // On a length mismatch CPython compares `b` against itself (so the loop
    // body always XORs to zero) but seeds `result` with 1 → never equal.
    let (left, len, mut result) = if a.len() != b.len() {
        (b, b.len(), 1u8)
    } else {
        (a, a.len(), 0u8)
    };
    for i in 0..len {
        result |= left[i] ^ b[i];
    }
    result == 0
}

/// `_operator._compare_digest(a, b)` — constant-time equality for two
/// ASCII `str`s or two bytes-like objects (mixing the two, or passing
/// anything else, raises `TypeError`), matching `Modules/_operator.c`.
fn compare_digest(args: &[Object]) -> Result<Object, RuntimeError> {
    let a = args
        .first()
        .ok_or_else(|| type_error("_compare_digest expected 2 arguments, got 0"))?;
    let b = args
        .get(1)
        .ok_or_else(|| type_error("_compare_digest expected 2 arguments, got 1"))?;
    // `str`/`bytes` subclasses (which may override `__eq__`) compare by their
    // underlying value, so unwrap to the native primitive first.
    let an = a.native_value();
    let bn = b.native_value();
    let a = an.as_ref().unwrap_or(a);
    let b = bn.as_ref().unwrap_or(b);
    let equal = match (a, b) {
        (Object::Str(sa), Object::Str(sb)) => {
            if !sa.is_ascii() || !sb.is_ascii() {
                return Err(type_error(
                    "comparing strings with non-ASCII characters is not supported",
                ));
            }
            tscmp(sa.as_bytes(), sb.as_bytes())
        }
        _ => {
            // Reject a str paired with a non-str (and any non-buffer type)
            // before touching the buffer protocol, exactly as CPython does.
            if matches!(a, Object::Str(_)) || matches!(b, Object::Str(_)) {
                return Err(compare_type_error(a, b));
            }
            match (a.as_bytes_view(), b.as_bytes_view()) {
                (Some(ba), Some(bb)) => tscmp(&ba, &bb),
                _ => return Err(compare_type_error(a, b)),
            }
        }
    };
    Ok(Object::Bool(equal))
}

fn compare_type_error(a: &Object, b: &Object) -> RuntimeError {
    type_error(format!(
        "unsupported operand types(s) or combination of types: '{}' and '{}'",
        a.type_name_owned(),
        b.type_name_owned()
    ))
}

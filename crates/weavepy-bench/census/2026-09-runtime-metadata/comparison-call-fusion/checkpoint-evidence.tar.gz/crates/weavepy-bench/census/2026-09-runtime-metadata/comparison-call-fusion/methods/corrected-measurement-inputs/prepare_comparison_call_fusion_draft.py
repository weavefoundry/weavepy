"""Prepare an unapplied comparison-return fusion experiment after guard regressions."""
from pathlib import Path
import difflib,hashlib,json
root=Path('target/comparison-call-fusion-draft');root.mkdir()
records={};patch=''
def save(name,before,after):
    global patch
    assert before!=after
    (root/Path(name).name).write_text(after)
    records[name]={'base_sha256':hashlib.sha256(before.encode()).hexdigest(),'draft_sha256':hashlib.sha256(after.encode()).hexdigest()}
    patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),'a/'+name,'b/'+name))
name='crates/weavepy-jit/src/analyze.rs';before=Path(name).read_text()
old='''                // Guard after producing calls, at the comparison itself.
                // A surprise restores both original operands so rich
                // comparisons and their callbacks execute exactly once.
                stack.push(ESlot::val(a));
                stack.push(ESlot::val(b));
                push(TOp::UnboxInt { depth }, None, stack, stmts);
                stack.pop();
                stack.pop();'''
new='''                // Reuse the existing exact-integer call result when the
                // consumer is adjacent, or separated only by a scalar
                // constant. A miss resumes after the completed call, so
                // the constant and comparison execute once in the VM.
                let candidate = if depth == 0 {
                    stmts.len().checked_sub(1).filter(|&idx| {
                        stmts[idx].pc.checked_add(1) == Some(pc)
                    })
                } else {
                    stmts.len().checked_sub(2).filter(|&idx| {
                        matches!(stmts[idx + 1].op, TOp::ConstInt(_) | TOp::ConstBool(_))
                            && stmts[idx].pc.checked_add(1) == Some(stmts[idx + 1].pc)
                            && stmts[idx + 1].pc.checked_add(1) == Some(pc)
                    })
                };
                let fused = candidate.is_some_and(|idx| {
                    if let TOp::CallDyn { int_result, .. } = &mut stmts[idx].op {
                        *int_result = true;
                        true
                    } else {
                        false
                    }
                });
                if !fused {
                    // General producers retain both original operands at
                    // COMPARE_OP; rich callbacks aren't repeated.
                    stack.push(ESlot::val(a));
                    stack.push(ESlot::val(b));
                    push(TOp::UnboxInt { depth }, None, stack, stmts);
                    stack.pop();
                    stack.pop();
                }'''
assert before.count(old)==1;save(name,before,before.replace(old,new))
name='crates/weavepy-jit/src/ir.rs';before=Path(name).read_text()
old='''    /// If `int_result` is set, the immediately following integer consumer
    /// is fused into the call: exact integers return unboxed, and other
    /// completed values park and resume at the next bytecode instruction.'''
new='''    /// If `int_result` is set, an integer consumer is fused into the call,
    /// optionally after one non-guarding scalar constant load. Exact integers
    /// return unboxed; other completed values park and resume at the next
    /// bytecode instruction without repeating the producing call.'''
assert before.count(old)==1;save(name,before,before.replace(old,new))
name='crates/weavepy-jit/tests/frame_coverage.rs';before=Path(name).read_text()
start=before.index('#[test]\nfn opaque_integer_comparisons_guard_at_the_comparison_opcode()')
after=before[:start]+'''#[test]
fn opaque_integer_comparisons_fuse_exact_call_results() {
    for op in ["<", "<=", "==", "!=", ">", ">="] {
        for expression in [format!("produce(n) {op} 3"), format!("3 {op} produce(n)")] {
            let code = compile_first_fn(&format!("def k(produce, n):\\n    return {expression}\\n"));
            let cfg = Cfg { obj_params: vec![0], typed_params: vec![(1, JitType::Int)], ..Cfg::default() };
            let tf = analyze_code_cfg(&code, &cfg).expect("fused comparison should compile");
            assert!(has_op(&tf, |op| matches!(op, TOp::CallDyn { int_result: true, .. })));
            assert!(!has_op(&tf, |op| matches!(op, TOp::UnboxInt { .. })));
            assert!(has_op(&tf, |op| matches!(op, TOp::IntCmp(_))));
            assert_eq!(tf.ret_lane, Some(JitType::Bool));
        }
    }
}

#[test]
fn comparison_guards_do_not_fuse_across_other_operand_loads() {
    use weavepy_compiler::OpCode;
    let code = compile_first_fn("def k(produce, n):\\n    return produce(n) < n\\n");
    let cfg = Cfg { obj_params: vec![0], typed_params: vec![(1, JitType::Int)], ..Cfg::default() };
    let tf = analyze_code_cfg(&code, &cfg).expect("unfused comparison should compile");
    let pc = code.instructions.iter().position(|i| i.op == OpCode::CompareOp).unwrap() as u32;
    assert!(tf.blocks.iter().flat_map(|b| &b.stmts).any(|s| s.pc == pc && s.op == TOp::UnboxInt { depth: 1 }));
    assert!(has_op(&tf, |op| matches!(op, TOp::CallDyn { int_result: false, .. })));
}
'''
# The currently last fixture is replaced; don't drop future additions.
assert before[start:].count('#[test]')==1
save(name,before,after)
(root/'candidate.patch').write_text(patch)
(root/'index.json').write_text(json.dumps({'status':'Unapplied, unformatted, uncompiled, unvalidated, unmeasured.','sources':records},indent=2)+'\n')
(root/'README.md').write_text('''# Fuse integer results into comparisons

The unfused comparison candidate improves simple integer controls but regresses
complex callback controls, including 12.5 percent warm and 15.1 percent cold
with no rich-comparison misses. This draft is a separate proposed refinement.
It reuses CallDyn int_result, already used by integer arithmetic, for an adjacent
comparison or one separated only by a non-guarding integer/bool constant load.
A noninteger completed result parks and resumes after the producer; the constant
and comparison then execute in the interpreter. General shapes retain the
original exact-COMPARE_OP guard. No helper, pin ownership, cache, policy, or
unsafe code changes. The old field's documentation is updated accordingly.

Check side effects, arbitrary rich results and truth conversion, producer/compare
exceptions, loop locals and exact traceback lines, native caller reconstruction,
tracing, guard invalidation, pin pressure, and all cold/warm/failure/recovery
controls. Never fuse across another operand load, callback, or guarding opcode.
The existing source snapshots and every prior regression must remain preserved.
Apply only after the unfused candidate's full measurements and archival, with
exact baseline hashes rechecked. No correctness or performance claim yet.
''')
print('Prepared three-file comparison fusion draft; active sources unchanged.')

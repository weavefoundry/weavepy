import os
class Fn:
    def __call__(self, *args):
        return len(args) + 1
FN = Fn()

def bench(n):
    f = FN
    total = 0
    for i in range(n):
        total += f()
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

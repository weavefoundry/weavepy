#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/jit-raise-call-spans-checks/frozen"
binary=target/release/weavepy-runtime-jit-raise-call-spans
test "$(cat target/jit-raise-call-spans-stage.txt)" = done
test ! -e target/jit-raise-call-spans-checks
mkdir target/jit-raise-call-spans-checks
printf 'targeted exception and JIT lifetime checks\n' > target/jit-raise-call-spans-check-stage.txt
for test in test_jit_raise_exits test_exceptions test_exceptions_context test_jit_calls test_jit_dyn_calls test_jit_osr test_jit_cells test_jit_object_lanes test_jit_enumerate test_jit_list_lifetime test_jit_list_builders test_native_pin_retirement test_native_generator_pin_retirement test_native_pin_pressure test_frame_recycling test_cross_thread_heap test_weakref_wrapper_keys test_pickle_builtin_data test_pickle_callables; do
    WEAVEPY_JIT=1 "$binary" "tests/regrtest/$test.py" > "target/jit-raise-call-spans-checks/$test-jit.txt" 2>&1
    WEAVEPY_JIT=0 "$binary" "tests/regrtest/$test.py" > "target/jit-raise-call-spans-checks/$test-interp.txt" 2>&1
    WEAVEPY_JIT=1 "$binary" -X gil=0 "tests/regrtest/$test.py" > "target/jit-raise-call-spans-checks/$test-gil0.txt" 2>&1
done
WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_jit_raise_exits.py > target/jit-raise-call-spans-checks/native-coverage.stdout.txt 2> target/jit-raise-call-spans-checks/native-coverage.stderr.txt
printf 'done\n' > target/jit-raise-call-spans-check-stage.txt

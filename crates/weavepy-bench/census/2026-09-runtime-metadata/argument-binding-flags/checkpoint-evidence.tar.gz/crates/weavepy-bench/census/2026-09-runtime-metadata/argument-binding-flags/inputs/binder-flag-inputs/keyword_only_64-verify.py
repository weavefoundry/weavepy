import json, sys, types
module = types.ModuleType("_weavepy_bench")
module.__file__ = 'target/binder-flag-inputs/keyword_only_64.py'
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
first = module.bench(10000)
for unused in range(3):
    module.bench(10000)
last = module.bench(10000)
print(json.dumps(first, sort_keys=True))
print(json.dumps(last, sort_keys=True))

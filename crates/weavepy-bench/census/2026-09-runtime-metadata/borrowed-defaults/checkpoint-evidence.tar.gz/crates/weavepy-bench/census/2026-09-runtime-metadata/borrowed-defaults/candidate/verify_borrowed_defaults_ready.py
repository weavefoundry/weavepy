"""Require complete binding validation and unchanged measured identities."""
from pathlib import Path
import hashlib
import json
import re

def read(path):
    return json.loads(Path(path).read_text())
for group in read('target/borrowed-defaults-prebuild.json').values():
    for path, digest in group.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
env = read('target/borrowed-defaults-source-snapshot/environment.json')
for label in ['new', 'previous']:
    item = env['binaries'][label]
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256'], label
assert env['binaries']['previous']['sha256'] == 'bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'
assert 'test result: ok. 347 passed' in Path('target/borrowed-defaults-vm-tests-01.txt').read_text()
text = Path('target/borrowed-defaults-capi-tests-01.txt').read_text()
assert 'test result: FAILED' not in text
assert sum(map(int, re.findall(r'test result: ok\. (\d+) passed', text))) == 156
for label in ['clippy-01', 'nojit-check']:
    assert 'Finished' in Path(f'target/borrowed-defaults-{label}.txt').read_text()
expected = 'overridden positional defaults: ownership and binding ok\n'
for label in ['cpython', 'baseline-jit', 'baseline-interp', 'baseline-gil0']:
    assert Path(f'target/borrowed-defaults-oracle-{label}.txt').read_text() == expected
assert Path('target/borrowed-defaults-check-stage.txt').read_text().strip() == 'done'
checks = Path('target/borrowed-defaults-checks')
for mode in ['jit', 'interp', 'gil0']:
    assert len(list(checks.glob(f'*-{mode}.txt'))) == 30
    assert (checks / f'test_overridden_default_ownership-{mode}.txt').read_text() == expected
validation = read('target/borrowed-defaults-validation/validation.json')
assert len(validation) == 275 and all(r['passed'] for r in validation)
print('All source/method identities, native checks, 90 targeted checks, and 275 compatibility checks verified.')

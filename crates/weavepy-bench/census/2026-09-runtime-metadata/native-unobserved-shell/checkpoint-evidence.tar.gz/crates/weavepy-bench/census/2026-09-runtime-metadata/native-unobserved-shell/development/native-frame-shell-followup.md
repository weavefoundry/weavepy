# Reuse native activation frame shells: unapplied follow-up

Finish the active native-dynamic-small-args timing stages and archive their
results before changing runtime code, building, testing, or running diagnostics.

The completed native-frame-shell-identity-audit is untimed. CPython and the new
candidate in interpreter mode return one parent-frame identity for five callbacks
within one driver invocation. Both the 6810 predecessor and ebb5 candidate in
JIT mode return different frame identities. All five frames have the correct
driver code name. The driver compiles; the trace shows no driver deoptimization.
This is a verified preexisting mismatch, not a regression in argument storage.

call_with_activation_shell currently allocates a FrameShell and an empty locals
cell for each interpreter callback from a frameless native activation. A native
activation could create one shell lazily, reuse it across callbacks, and keep
public frame identity stable. Avoid allocating shells for calls that never need
them. This is a source-based allocation lead, not a measured speed or RSS gain.

Important implementation constraints:

- CallCtx already has non-Send per-thread state. An activation-owned lazy shell
  can use interior mutability while call_with_activation_shell retains its shared
  context borrow. No shared pool or pin-table borrow may cross arbitrary Python.
- FrameShell.materialize caches the PyFrame and sets on_stack to one. The current
  native helper pops the raw frame_stack directly. Interpreter.pop_frame_shell
  decrements the materialized count. Determine the correct entire-activation
  lifetime; a native parent still executes between callbacks and must not become
  clearable from another thread just because its shell is temporarily off-spine.
- A materialized shell's lasti and the PyFrame lasti both need synchronization;
  f_back, frame.clear, retained locals, tracing, traceback position, and return/
  exception behavior require independent oracles. The current shell has an empty
  locals mirror, so caching that mirror alone does not establish correct f_locals.
- finish_deopted_callee constructs a new interpreter Frame with py_frame and
  shell_cache set to None. Preserve an already observed native frame when handing
  off to that continuation, update its locals mirror, invalidate cached locals,
  and transfer execution-count ownership without a double increment or decrement.
  Native returns and raised exits need proper completion as well.
- Interpreter push_frame_shell adopts a cached materialized frame and increments
  on_stack. Existing generator identity handling is useful precedent, but native
  activation ownership and deoptimization are different. Audit before reusing it.
- Lowering emits TTerm::Return without passing its bytecode PC into emit_return.
  Do not invent a last instruction position for a retained frame after return;
  inspect available block metadata or carry the exact return PC if needed.

Test nested native/interpreter chains, repeated callback identity, exceptions,
guard invalidation after a callback, locals/frame retention and clearing, tracing,
generators, weak-reference lifetimes, and multi-thread observation. Measure the
unchanged short-call controls and census against fixed binaries. Keep the current
argument-storage stack tradeoff and all existing losses visible. No source change
or performance claim follows from this audit.

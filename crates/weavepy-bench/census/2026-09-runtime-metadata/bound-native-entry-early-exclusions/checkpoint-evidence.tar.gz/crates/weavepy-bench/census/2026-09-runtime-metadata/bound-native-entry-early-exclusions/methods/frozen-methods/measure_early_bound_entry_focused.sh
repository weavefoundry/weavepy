#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/early-bound-entry-validation-stage.txt)" = done
python3.14 - <<'CHECK'
import json
from pathlib import Path
assert json.loads(Path('target/early-bound-entry-coverage/report.json').read_text())['assertions_passed']
assert json.loads(Path('target/early-bound-entry-extra-checks/report.json').read_text())['status']=='passed'
CHECK
output=target/early-bound-entry-focused
test ! -e "$output"
mkdir "$output"
base="$(cat target/early-bound-entry-previous.txt)"
binary=target/release/weavepy-runtime-early-bound-entry
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf 'ten call shapes\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/bound-native-entry-inputs/calls --out "$output/calls" --samples 7 > "$output/calls.txt" 2>&1
printf 'four warm exception frequencies\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/bound-native-entry-inputs/exceptions --out "$output/exceptions" --samples 7 > "$output/exceptions.txt" 2>&1
printf 'four cold exception frequencies\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/bound-native-entry-inputs/cold-exceptions --out "$output/cold-exceptions" --samples 7 --cold > "$output/cold-exceptions.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
python3.14 target/summarize_early_bound_entry.py > "$output/summary.txt" 2>&1
printf 'done\n' > "$output/stage.txt"

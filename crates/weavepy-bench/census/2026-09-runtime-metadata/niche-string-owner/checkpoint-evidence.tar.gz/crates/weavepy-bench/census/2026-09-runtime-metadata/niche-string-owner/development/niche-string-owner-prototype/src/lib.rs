//! Unapplied aligned string owner with a reserved metadata byte for enum layout.
use std::borrow::Borrow;
use std::fmt;
use std::hash::{Hash, Hasher};
use std::marker::PhantomData;
use std::mem::{size_of, ManuallyDrop};
use std::ops::Deref;
use std::ptr::{self, NonNull};
use std::sync::{Arc, Weak};

const POINTER_BYTES: usize = size_of::<usize>();
const LENGTH_BYTES: usize = if POINTER_BYTES == 8 { 7 } else { POINTER_BYTES };
const INDIRECT_LENGTH: usize = usize::MAX >> ((POINTER_BYTES - LENGTH_BYTES) * 8);

#[repr(u8)]
#[derive(Clone, Copy)]
enum ZeroByte {
    Zero = 0,
}
#[repr(C)]
#[derive(Clone, Copy)]
struct StringMetadata {
    low: [u8; LENGTH_BYTES],
    high: ZeroByte,
}
impl StringMetadata {
    fn new(length: usize) -> Self {
        let mut low = [0; LENGTH_BYTES];
        low.copy_from_slice(&length.to_le_bytes()[..LENGTH_BYTES]);
        Self {
            low,
            high: ZeroByte::Zero,
        }
    }
    #[inline]
    fn word(&self) -> usize {
        // SAFETY: on 64-bit targets, exactly the seven initialized length bytes
        // and initialized zero marker occupy this word. On other targets the
        // word contains exactly the full initialized length byte array. The
        // read includes neither padding nor pointer-representation bytes, and
        // read_unaligned doesn't assume StringMetadata has word alignment.
        let raw = unsafe { ptr::read_unaligned(ptr::from_ref(self).cast::<usize>()) };
        usize::from_le(raw)
    }
}

/// A standard Arc<str> owner whose metadata leaves a reserved enum-tag byte.
#[repr(C)]
pub struct SharedStr {
    data: NonNull<()>,
    metadata: StringMetadata,
    ownership: PhantomData<Arc<str>>,
}
// SAFETY: fields are immutable and own exactly one standard Arc<str> reference.
// All sharing, overflow handling, and destruction use Arc's reference counts.
unsafe impl Send for SharedStr {}
unsafe impl Sync for SharedStr {}
#[derive(Clone, Debug)]
pub struct WeakStr(Weak<str>);

impl SharedStr {
    pub fn from_arc(value: Arc<str>) -> Self {
        let length = value.len();
        if length >= INDIRECT_LENGTH {
            return Self::indirect(value);
        }
        let raw = Arc::into_raw(value).cast::<()>().cast_mut();
        Self {
            // SAFETY: Arc::into_raw always returns a live non-null data pointer.
            data: unsafe { NonNull::new_unchecked(raw) },
            metadata: StringMetadata::new(length),
            ownership: PhantomData,
        }
    }
    #[cold]
    #[inline(never)]
    fn indirect(value: Arc<str>) -> Self {
        Self {
            data: NonNull::from(Box::leak(Box::new(value))).cast(),
            metadata: StringMetadata::new(INDIRECT_LENGTH),
            ownership: PhantomData,
        }
    }
    #[inline]
    fn inline_raw(&self, length: usize) -> *const str {
        ptr::slice_from_raw_parts(self.data.as_ptr().cast::<u8>(), length) as *const str
    }
    #[cold]
    #[inline(never)]
    fn indirect_raw(&self) -> *const str {
        // SAFETY: the escape representation owns its own Box<Arc<str>>.
        Arc::as_ptr(unsafe { &*self.data.cast::<Arc<str>>().as_ptr() })
    }
    #[inline]
    fn raw(&self) -> *const str {
        let length = self.metadata.word();
        if length == INDIRECT_LENGTH {
            self.indirect_raw()
        } else {
            self.inline_raw(length)
        }
    }
    #[inline]
    fn arc_view(&self) -> ManuallyDrop<Arc<str>> {
        // SAFETY: borrow our accounted strong reference without releasing it.
        ManuallyDrop::new(unsafe { Arc::from_raw(self.raw()) })
    }
    #[cold]
    #[inline(never)]
    fn clone_indirect(&self) -> Self {
        Self::from_arc(Arc::clone(&self.arc_view()))
    }
    #[cold]
    #[inline(never)]
    fn drop_indirect(&mut self) {
        // SAFETY: this handle uniquely owns this box and its one Arc reference.
        unsafe { drop(Box::from_raw(self.data.cast::<Arc<str>>().as_ptr())) }
    }
    pub fn as_ptr(this: &Self) -> *const str {
        this.raw()
    }
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        Arc::ptr_eq(&this.arc_view(), &other.arc_view())
    }
    pub fn strong_count(this: &Self) -> usize {
        Arc::strong_count(&this.arc_view())
    }
    pub fn weak_count(this: &Self) -> usize {
        Arc::weak_count(&this.arc_view())
    }
    pub fn downgrade(this: &Self) -> WeakStr {
        WeakStr(Arc::downgrade(&this.arc_view()))
    }
}
impl Clone for SharedStr {
    #[inline]
    fn clone(&self) -> Self {
        let length = self.metadata.word();
        if length == INDIRECT_LENGTH {
            return self.clone_indirect();
        }
        // SAFETY: the source keeps the original, correctly reconstructed Arc
        // pointee alive. Account for the new owner with Arc's checked increment.
        unsafe { Arc::increment_strong_count(self.inline_raw(length)) };
        Self {
            data: self.data,
            metadata: self.metadata,
            ownership: PhantomData,
        }
    }
}
impl Drop for SharedStr {
    #[inline]
    fn drop(&mut self) {
        let length = self.metadata.word();
        if length == INDIRECT_LENGTH {
            self.drop_indirect();
        } else {
            // SAFETY: release exactly the reference consumed or cloned above.
            unsafe { drop(Arc::from_raw(self.inline_raw(length))) }
        }
    }
}
impl Deref for SharedStr {
    type Target = str;
    #[inline]
    fn deref(&self) -> &str {
        // SAFETY: only valid Arc<str> pointees enter; ownership keeps one alive.
        unsafe { &*self.raw() }
    }
}
impl From<&str> for SharedStr {
    fn from(value: &str) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl From<String> for SharedStr {
    fn from(value: String) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl From<&String> for SharedStr {
    fn from(value: &String) -> Self {
        Self::from(value.as_str())
    }
}
impl From<Box<str>> for SharedStr {
    fn from(value: Box<str>) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl AsRef<str> for SharedStr {
    fn as_ref(&self) -> &str {
        self
    }
}
impl Borrow<str> for SharedStr {
    fn borrow(&self) -> &str {
        self
    }
}
impl Hash for SharedStr {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state)
    }
}
impl fmt::Debug for SharedStr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}
impl fmt::Display for SharedStr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}
impl PartialEq for SharedStr {
    fn eq(&self, other: &Self) -> bool {
        **self == **other
    }
}
impl Eq for SharedStr {}
impl PartialOrd for SharedStr {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}
impl Ord for SharedStr {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        (**self).cmp(&**other)
    }
}
impl WeakStr {
    pub fn upgrade(&self) -> Option<SharedStr> {
        self.0.upgrade().map(SharedStr::from_arc)
    }
    pub fn strong_count(&self) -> usize {
        self.0.strong_count()
    }
    pub fn weak_count(&self) -> usize {
        self.0.weak_count()
    }
}

#[cfg(test)]
mod tests;

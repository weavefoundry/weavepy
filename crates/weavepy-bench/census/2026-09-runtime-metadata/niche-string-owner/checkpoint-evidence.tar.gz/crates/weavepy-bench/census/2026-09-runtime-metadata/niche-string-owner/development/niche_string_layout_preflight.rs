#![allow(dead_code)]
use std::mem::{align_of, offset_of, size_of};
use std::ptr::{self, NonNull};

#[repr(u8)]
#[derive(Clone, Copy)]
enum Zero { Value = 0 }
#[repr(C)]
struct Metadata { low: [u8; 7], high: Zero }
#[repr(C)]
struct StringOwner { pointer: NonNull<()>, metadata: Metadata }
#[repr(C, packed)]
struct PackedOwner { pointer: NonNull<()>, metadata: [u8;7] }
struct ThinOwner(NonNull<()>);
enum CurrentValue { None, Bool(bool), Int(i64), Float(f64), Str(ThinOwner), Bytes(ThinOwner), Tuple(ThinOwner), WStr(ThinOwner), Heap(NonNull<()>) }
enum NicheValue { None, Bool(bool), Int(i64), Float(f64), Str(StringOwner), Bytes(ThinOwner), Tuple(ThinOwner), WStr(ThinOwner), Heap(NonNull<()>) }
enum PackedValue { None, Bool(bool), Int(i64), Float(f64), Str(PackedOwner), Bytes(PackedOwner), Tuple(PackedOwner), WStr(PackedOwner), Heap(NonNull<()>) }

#[no_mangle]
fn string_length(owner: &StringOwner) -> usize {
    // A model-only complete-word read: the seven length bytes and initialized
    // zero marker occupy exactly these eight bytes within the StringOwner.
    // No pointer representation or padding bytes are part of this read.
    assert_eq!(size_of::<usize>(),8);
    let address = ptr::from_ref(owner).cast::<u8>();
    usize::from_le(unsafe { ptr::read_unaligned(address.add(offset_of!(StringOwner, metadata)).cast::<usize>()) })
}

fn main() {
    let value = StringOwner { pointer: NonNull::dangling(), metadata: Metadata { low: [0x56,0x34,0x12,0,0,0,0], high: Zero::Value } };
    assert_eq!(string_length(&value),0x123456);
    println!("{{\"StringOwner\":{},\"owner_alignment\":{},\"metadata_offset\":{},\"metadata_bytes\":{},\"marker_offset_in_metadata\":{},\"CurrentValue\":{},\"PackedValue\":{},\"NicheValue\":{},\"NicheValue_alignment\":{}}}",size_of::<StringOwner>(),align_of::<StringOwner>(),offset_of!(StringOwner, metadata),size_of::<Metadata>(),offset_of!(Metadata,high),size_of::<CurrentValue>(),size_of::<PackedValue>(),size_of::<NicheValue>(),align_of::<NicheValue>());
}

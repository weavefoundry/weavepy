"""Freeze the time formatter change and declared measurement methods."""
from pathlib import Path
import hashlib
import json
import difflib

out = Path('target/ascii-time-format-prebuild.json')
assert not out.exists()
original = json.loads(Path('target/borrowed-keyword-defaults-prebuild.json').read_text())['sources']
changed = [p for p, digest in original.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest() != digest]
assert set(changed) == {'crates/weavepy-vm/src/stdlib/datetime_accel.rs', 'crates/weavepy-vm/src/stdlib/python/_pydatetime.py'}, changed
paths = set(original)
paths.add('tests/regrtest/test_time_format_fastpath.py')
methods = [Path('target') / name for name in [
    'build_ascii_time_format.sh', 'check_ascii_time_format.sh', 'check_ascii_time_format_native.sh',
    'validate_ascii_time_format.sh', 'measure_ascii_time_format_focused.sh', 'measure_ascii_time_format_full.sh',
    'summarize_ascii_time_format.py', 'verify_ascii_time_format_ready.py', 'freeze_ascii_time_format_sources.py',
    'ascii-time-format-protocol.md', 'prepare_ascii_time_format_inputs.py', 'prepare_ascii_time_format_methods.py',
    'measure_verified_python_components.py', 'freeze_runtime_candidate.py', 'capture_runtime_environment.py',
    'run_serial_performance_gate.py', 'run_performance_under_load_gate.py', 'shared_slot_keys_startup_probes.py',
    'summarize_runtime_suite.py',
]]
methods += [Path('tools/bench_compare.py'), Path('tests/regrtest/expectations.toml'),
            Path('crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py')]
methods += list(Path('target/ascii-time-format-inputs').rglob('*.py'))
methods += list(Path('target/ascii-time-format-inputs').rglob('preparation.json'))
def hashes(names):
    return {str(p): hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(names)}
out.write_text(json.dumps({'sources': hashes(paths), 'methods': hashes(methods)}, indent=2) + '\n')
diff = []
for name in changed:
    before = (Path('target/ascii-time-format-preimages') / Path(name).name).read_text()
    after = Path(name).read_text()
    diff += difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='predecessor/' + name, tofile='candidate/' + name)
Path('target/ascii-time-format-review.diff').write_text(''.join(diff))
print('Frozen', len(paths), 'source identities and', len(methods), 'methods/inputs.')

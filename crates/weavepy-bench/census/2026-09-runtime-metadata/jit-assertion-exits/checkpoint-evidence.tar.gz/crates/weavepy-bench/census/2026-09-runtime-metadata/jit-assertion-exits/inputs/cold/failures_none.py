
def leaf(value):
    assert value >= 0, f"negative value {value}"
    return value * 3 + 1
def wrapper(value):
    return leaf(value) + 2
def bench(n):
    total = 0
    for i in range(n):
        value = -1 if 0 and i % 1 == 0 else i
        try:
            total += wrapper(value)
        except AssertionError as error:
            total += len(error.args[0])
    return total

if __name__ == "__main__":
    import os
    import time
    n = int(os.environ["WEAVEPY_BENCH_WORK"])
    start = time.perf_counter_ns()
    result = bench(n)
    elapsed = time.perf_counter_ns() - start
    print("WEAVEPY_BENCH_NS=%d" % elapsed)

"""Verify completed groups without concealing the original cold-stage failure."""
import hashlib
import json
from pathlib import Path
import statistics

root = Path('target/bound-native-entry-focused-complete')
assert not root.exists()
sources = {
    'calls': ('target/bound-native-entry-focused/calls/measurements.json', 10),
    'exceptions': ('target/bound-native-entry-focused/exceptions/measurements.json', 4),
    'cold-exceptions': ('target/bound-native-entry-cold-continuation/cold-exceptions/measurements.json', 4),
}
summary = {'status': 'Completed through a separate cold-only continuation; original failure retained.',
           'original_failure': 'target/bound-native-entry-focused/cold-exceptions.txt',
           'conditions': {}, 'groups': {}, 'rows': {}}
for label, filename in [('original', 'target/bound-native-entry-focused-load.json'),
                        ('cold_continuation', 'target/bound-native-entry-cold-continuation-load.json')]:
    p = Path(filename)
    data = json.loads(p.read_text())
    assert data['status'] == ('command_failed' if label == 'original' else 'complete')
    launch = data['launch_observation']
    before = data['observations'][launch - 2:launch + 1]
    assert len(before) == 3 and all(max(row['load_1_5_15_minutes'][:2]) <= 4 for row in before)
    summary['conditions'][label] = {'path': filename, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                                    'status': data['status'], 'precondition_met': True,
                                    'last_observation': data['observations'][-1]}
binary_ids = None
for group, (filename, count) in sources.items():
    path = Path(filename)
    data = json.loads(path.read_text())
    assert len(data['rows']) == count
    ids = {name: row['sha256'] for name, row in data['binaries'].items()}
    if binary_ids is None:
        binary_ids = ids
    assert ids == binary_ids
    summary['groups'][group] = {'path': filename, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                'count': count, 'samples_per_variant': data['samples'], 'cold_workload': data['cold_workload']}
    for name, row in data['rows'].items():
        assert 'previous_comparisons' in row and row['frozen_cache']['unchanged']
        assert all(len(samples) == 7 for samples in row['samples'].values())
        values = data['verification'][name]
        assert all(r['returncode'] == 0 and r['stdout'] == values['cpython']['stdout'] for r in values.values())
        pairs = {}
        for mode in ['jit', 'interp']:
            pairs[mode] = {}
            for metric in row['previous_comparisons'][mode]:
                ratios = [a[metric] / b[metric] for a, b in zip(row['samples'][mode], row['samples']['previous_' + mode])]
                pairs[mode][metric] = {'ratios': ratios, 'median': statistics.median(ratios),
                                       'range': [min(ratios), max(ratios)], 'improved_pairs': sum(r < 1 for r in ratios)}
        summary['rows'][group + '/' + name] = {'new_over_previous': row['previous_comparisons'],
                                               'new_over_cpython': row['cpython_comparisons'], 'pairs': pairs}
summary['binary_sha256'] = binary_ids
assert len(summary['rows']) == 18
root.mkdir()
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
(root / 'README.md').write_text('''# Focused completion through a cold-only continuation

All 18 cases are complete and verified. The original run completed ten call
shapes and four warm exception cases, then failed because its cold probes
lacked a standalone timer. It recorded no cold timing samples. Keep that
failed stage and all completed samples unchanged. A separate continuation
measured only the four cold cases using their original timer-bearing sources.
Both runs met the declared load precondition. The summary records source
locations, hashes, conditions, all ratios, and every regression. No completed
sample was repeated or filtered. This manifest does not turn the original
failed stage into a successful run.
''')
(root / 'stage.txt').write_text('done\n')
print('Verified all 18 cases, every sample and cache, both load gates, and preserved failure provenance.')

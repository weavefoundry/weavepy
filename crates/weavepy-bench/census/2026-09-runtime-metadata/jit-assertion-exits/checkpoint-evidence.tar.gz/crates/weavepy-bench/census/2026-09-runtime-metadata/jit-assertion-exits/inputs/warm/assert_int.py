
def leaf(value):
    assert value >= 0, f"negative value {value}"
    return value * 3 + 1
def bench(n):
    total = 0
    for i in range(n):
        total += leaf(i)
    return total

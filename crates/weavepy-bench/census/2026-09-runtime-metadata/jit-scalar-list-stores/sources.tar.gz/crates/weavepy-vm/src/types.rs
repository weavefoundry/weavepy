//! Runtime type objects.
//!
//! Every Python value at runtime has a `type` — for built-in values
//! that mapping is computed from the [`Object`] enum tag; for
//! user-defined classes it lives directly on the instance.
//!
//! `TypeObject` itself is a Python object — `type(x)` returns one —
//! so the `Object::Type` variant carries an `Rc<TypeObject>`. The MRO
//! is C3 linearised at class-creation time and cached on the type.

use crate::sync::Cell;
use crate::sync::Rc;
use crate::sync::RefCell;
use crate::sync::Weak;

use crate::error::{type_error, RuntimeError};
use crate::object::{DictData, DictKey, Object};

/// The C-API bridge's metaclass-drift probe (RFC 0076 WS5): given a
/// readied stock type's own `PyTypeObject*` and its VM bridge, adopt any
/// raw `Py_SET_TYPE` re-seat of the struct's `ob_type` into the bridge's
/// metaclass slot. See [`TypeObject::c_ext_ptr`].
static METACLASS_DRIFT_HOOK: std::sync::OnceLock<fn(usize, &TypeObject)> =
    std::sync::OnceLock::new();

/// Process-wide allocator for [`AttrVersion`] values. Starts at 1 so a
/// zeroed [`type_cache`] entry can never match a live type.
static NEXT_TYPE_VERSION: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);

/// A type's attribute-resolution version, WeavePy's `tp_version_tag`.
///
/// Values are *globally unique across all types and their lifetimes*
/// (drawn from [`NEXT_TYPE_VERSION`]) rather than a per-type counter, so
/// `(version)` alone identifies one resolution state of one type: a class
/// freed and another allocated at the same address can never alias a
/// cached entry (RFC 0077 WS4, [`type_cache`]). Reads are relaxed atomic
/// loads — the previous `Cell<u32>` paid a `GilCell` lock round-trip on
/// every inline-cache guard.
pub struct AttrVersion(std::sync::atomic::AtomicU64);

impl AttrVersion {
    /// A never-before-used version.
    pub fn fresh() -> Self {
        Self(std::sync::atomic::AtomicU64::new(next_type_version()))
    }

    #[inline]
    pub fn get(&self) -> u64 {
        self.0.load(std::sync::atomic::Ordering::Relaxed)
    }

    /// Move to a fresh, never-before-used version.
    #[inline]
    pub fn bump(&self) {
        self.0
            .store(next_type_version(), std::sync::atomic::Ordering::Relaxed);
    }
}

impl std::fmt::Debug for AttrVersion {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.get())
    }
}

fn next_type_version() -> u64 {
    allocate_type_version(&NEXT_TYPE_VERSION).expect("type version space exhausted")
}

/// Never publish zero or reuse a token, including at counter exhaustion.
fn allocate_type_version(counter: &std::sync::atomic::AtomicU64) -> Option<u64> {
    use std::sync::atomic::Ordering::Relaxed;
    counter
        .fetch_update(Relaxed, Relaxed, |value| {
            if value == 0 {
                None
            } else {
                value.checked_add(1)
            }
        })
        .ok()
}

#[cfg(test)]
mod attr_version_tests {
    use super::{allocate_type_version, AttrVersion};
    use std::sync::atomic::{AtomicU64, Ordering::Relaxed};

    #[test]
    fn exhausted_tokens_never_wrap_or_reuse_zero() {
        let counter = AtomicU64::new(u64::MAX - 1);
        assert_eq!(allocate_type_version(&counter), Some(u64::MAX - 1));
        assert_eq!(allocate_type_version(&counter), None);
        assert_eq!(allocate_type_version(&counter), None);
        assert_eq!(counter.load(Relaxed), u64::MAX);
        let zero = AtomicU64::new(0);
        assert_eq!(allocate_type_version(&zero), None);
        assert_eq!(zero.load(Relaxed), 0);
    }

    #[test]
    fn concurrent_classes_and_mutations_have_distinct_tokens() {
        let values = std::thread::scope(|scope| {
            let threads: Vec<_> = (0..8)
                .map(|_| {
                    scope.spawn(|| {
                        let mut values = Vec::new();
                        for _ in 0..256 {
                            let version = AttrVersion::fresh();
                            values.push(version.get());
                            version.bump();
                            values.push(version.get());
                        }
                        values
                    })
                })
                .collect();
            threads
                .into_iter()
                .flat_map(|thread| thread.join().unwrap())
                .collect::<Vec<_>>()
        });
        let count = values.len();
        let mut unique = values;
        unique.sort_unstable();
        unique.dedup();
        assert_eq!(unique.len(), count);
        assert!(unique.iter().all(|&value| value != 0));
    }
}

/// RFC 0077 WS4: the per-thread type attribute cache, WeavePy's analogue
/// of CPython's `_PyType_Lookup` method cache.
///
/// Keyed by `(type address, attr_version, name)`, an entry records
/// *where* the MRO walk found `name` — the owning class's MRO index and
/// the key's slot in that class dict — or that the walk found nothing.
/// It deliberately stores no `Object`: a cached value would pin class
/// attributes past their `del`, visible to weakref tests, and a cached
/// owner `Rc` would pin the class itself. On a hit the value is re-read
/// through `mro[idx].dict.get_index(slot)`, so the cost is two `GilCell`
/// borrows and a key compare instead of one siphash plus one probe per
/// MRO level; negative hits (the common `__getattr__`/`__set_name__`-style
/// probes) return without touching any dict.
///
/// Validity rests on the same invariant the LOAD_ATTR inline caches
/// already depend on: every class-dict mutation or `__bases__` reshaping
/// that can change resolution goes through [`TypeObject::bump_attr_version`]
/// (for the type and its transitive subclasses). Versions are globally
/// unique ([`AttrVersion`]), so a freed-and-reallocated type cannot alias
/// a stale entry; positive hits additionally confirm the key at the
/// recorded slot spells `name`, falling back to the walk otherwise. The
/// name hash selects a cache slot, but every hit also compares the exact
/// spelling. In particular, a negative hit must not hide a different name
/// whose hash and length happen to collide.
pub(crate) mod type_cache {
    use std::cell::RefCell;
    use std::hash::Hasher;
    use std::rc::Rc;

    /// Entries per thread (CPython's `MCACHE_SIZE_EXP` is 12 too). The
    /// table is allocated on first use. Names are owned by this
    /// thread's entries and released when those entries are replaced.
    const SIZE: usize = 1 << 12;
    const MASK: usize = SIZE - 1;
    /// `mro_idx` value recording "the walk found nothing".
    const ABSENT: u32 = u32::MAX;

    #[derive(Clone)]
    struct Entry {
        name: Option<Rc<str>>,
        ver: u64,
        mro_idx: u32,
        dict_idx: u32,
    }

    const EMPTY: Entry = Entry {
        name: None,
        ver: 0,
        mro_idx: ABSENT,
        dict_idx: 0,
    };

    thread_local! {
        static CACHE: RefCell<Option<Box<[Entry]>>> = const { RefCell::new(None) };
    }

    /// Where an MRO walk for a name landed.
    #[derive(Clone, Copy, PartialEq, Eq, Debug)]
    pub(crate) enum Hit {
        /// The name resolves at `mro[mro_idx].dict[dict_idx]`.
        At { mro_idx: u32, dict_idx: u32 },
        /// The whole MRO was walked and the name is absent.
        Absent,
    }

    #[inline]
    pub(crate) fn name_hash(name: &str) -> u64 {
        let mut h = crate::fasthash::FxHasher::default();
        h.write(name.as_bytes());
        h.finish()
    }

    #[inline]
    fn slot(ty: usize, ver: u64, name_hash: u64) -> usize {
        // Mix the type identity in so the same dunder on many classes
        // does not pile into one slot; the version keeps a class's
        // entries moving after each mutation so stale slots recycle.
        ((name_hash ^ (ty as u64 >> 4).wrapping_mul(0x9E37_79B9_7F4A_7C15) ^ ver) as usize) & MASK
    }

    /// Probe the cache. `ver` is the type's *current* version.
    #[inline]
    pub(crate) fn probe(ty: usize, ver: u64, name: &str, name_hash: u64) -> Option<Hit> {
        CACHE.with(|c| {
            let c = c.try_borrow().ok()?;
            let table = c.as_ref()?;
            let e = &table[slot(ty, ver, name_hash)];
            if e.ver == ver && e.name.as_deref() == Some(name) {
                Some(if e.mro_idx == ABSENT {
                    Hit::Absent
                } else {
                    Hit::At {
                        mro_idx: e.mro_idx,
                        dict_idx: e.dict_idx,
                    }
                })
            } else {
                None
            }
        })
    }

    /// Record the outcome of a full walk.
    #[inline]
    pub(crate) fn fill(ty: usize, ver: u64, name: &str, name_hash: u64, hit: Hit) {
        CACHE.with(|c| {
            let Ok(mut c) = c.try_borrow_mut() else {
                return;
            };
            let table = c.get_or_insert_with(|| vec![EMPTY; SIZE].into_boxed_slice());
            let (mro_idx, dict_idx) = match hit {
                Hit::At { mro_idx, dict_idx } => (mro_idx, dict_idx),
                Hit::Absent => (ABSENT, 0),
            };
            let entry = &mut table[slot(ty, ver, name_hash)];
            if entry.name.as_deref() != Some(name) {
                entry.name = Some(Rc::from(name));
            }
            entry.ver = ver;
            entry.mro_idx = mro_idx;
            entry.dict_idx = dict_idx;
        });
    }

    #[cfg(test)]
    mod tests {
        use super::{fill, probe, Hit};

        #[test]
        fn colliding_slots_require_the_current_class_token() {
            let first_type = 0x100;
            let second_type = 0x200;
            let first_version = 41;
            let second_version = 42;
            let first_hash = 17;
            let mix = |ty: usize| (ty as u64 >> 4).wrapping_mul(0x9E37_79B9_7F4A_7C15);
            let second_hash =
                first_hash ^ mix(first_type) ^ first_version ^ mix(second_type) ^ second_version;
            assert_eq!(
                super::slot(first_type, first_version, first_hash),
                super::slot(second_type, second_version, second_hash)
            );
            fill(first_type, first_version, "value", first_hash, Hit::Absent);
            assert_eq!(
                probe(second_type, second_version, "value", second_hash),
                None
            );
            let hit = Hit::At {
                mro_idx: 0,
                dict_idx: 0,
            };
            fill(second_type, second_version, "value", second_hash, hit);
            assert_eq!(
                probe(second_type, second_version, "value", second_hash),
                Some(hit)
            );
            assert_eq!(probe(first_type, first_version, "value", first_hash), None);
        }

        #[test]
        fn unique_version_cache_entries_fit_in_thirty_two_bytes() {
            assert!(std::mem::size_of::<super::Entry>() <= 32);
        }

        #[test]
        fn colliding_names_do_not_share_positive_or_negative_hits() {
            let collision = 17;
            fill(123, 4, "missing", collision, Hit::Absent);
            assert_eq!(probe(123, 4, "missing", collision), Some(Hit::Absent));
            assert_eq!(probe(123, 4, "present", collision), None);
            let hit = Hit::At {
                mro_idx: 2,
                dict_idx: 3,
            };
            fill(123, 4, "present", collision, hit);
            assert_eq!(probe(123, 4, "present", collision), Some(hit));
            assert_eq!(probe(123, 4, "missing", collision), None);
            assert_eq!(probe(123, 5, "present", collision), None);
        }
    }
}

/// A Python class.
///
/// The dict stores methods and class attributes — the same dict you
/// see as `cls.__dict__`. The MRO is precomputed at construction
/// time so attribute lookups are linear in the depth of inheritance.
pub struct TypeObject {
    pub name: String,
    /// PEP 3155 `__qualname__`. CPython's `type_new` *pops* the
    /// compiler-stored `__qualname__` out of the class namespace into
    /// `tp_qualname` (it is not visible in `cls.__dict__`); mirrored
    /// here. `None` falls back to `name` (dynamic `type(...)` classes).
    pub qualname: RefCell<Option<String>>,
    /// Direct bases. Mutable because CPython supports `cls.__bases__ = …`
    /// assignment (with layout/MRO validation and subclass re-resolution).
    pub bases: RefCell<Vec<Rc<TypeObject>>>,
    pub mro: RefCell<Vec<Rc<TypeObject>>>,
    pub dict: Rc<RefCell<DictData>>,
    pub flags: TypeFlags,
    /// The class's *class* — i.e. its metaclass. Defaults to `type`
    /// (set by the constructor builders). User-defined classes pick
    /// up a custom metaclass either via the `metaclass=` keyword or
    /// by inheriting the highest-priority metaclass of their bases.
    /// Wrapped in a `RefCell` so the [`crate::builtin_types`] startup
    /// path can self-reference (`type.__class__ is type`) by patching
    /// the slot after construction.
    pub metaclass: RefCell<Option<Rc<TypeObject>>>,
    /// Explicit `__slots__` declarations, in declaration order.
    /// Empty when the class does not use slots. Used at class
    /// creation to install [`crate::object::SlotDescriptor`]s, and at
    /// attribute-set time to enforce slot-only access on classes
    /// whose entire MRO declares slots.
    pub slot_names: RefCell<Vec<String>>,
    /// `True` when the class body *declared* `__slots__` (even an empty
    /// one). Distinguishes `__slots__ = []` (no `__weakref__` support
    /// contributed) from a plain class (which contributes both
    /// `__dict__` and `__weakref__`), mirroring CPython's tp_weaklistoffset
    /// computation.
    pub declares_slots: Cell<bool>,
    /// `True` for slot-using classes whose MRO carries `__slots__`
    /// every step of the way (so the instance has no implicit
    /// `__dict__`). Set when the user neither omits `__slots__` from
    /// any base nor lists `"__dict__"` in slots.
    pub forbids_dict: bool,
    /// Direct subclasses of this type, tracked as *weak* references so
    /// the parent→child edge doesn't form an uncollectable `Rc` cycle
    /// with the strong child→parent `bases` edge. Mirrors CPython's
    /// `tp_subclasses`; surfaced by `type.__subclasses__()` and used by
    /// the ABC virtual-subclass machinery.
    pub subclasses: RefCell<Vec<Weak<TypeObject>>>,
    /// Cached classification of this type's `__getattribute__` slot, so the
    /// hot attribute path can skip an MRO walk: `0` = not yet computed,
    /// `1` = default (`object.__getattribute__`), `2` = a user override.
    /// Invalidated (reset to `0`) for the type and its subclasses whenever
    /// `__getattribute__` is assigned to / deleted from a type's dict.
    pub getattribute_kind: Cell<u8>,
    /// Cached classification of this type's `__setattr__` slot, same
    /// protocol as [`Self::getattribute_kind`]: `0` = not yet computed,
    /// `1` = default (`object.__setattr__`), `2` = a user override.
    /// Consulted on every instance attribute store — the default routes
    /// straight to the generic setter instead of a full builtin call
    /// dispatch. Invalidated alongside `getattribute_kind` (same walk)
    /// and on `__setattr__` assignment / deletion / MRO changes.
    pub setattr_kind: Cell<u8>,
    /// Cached MRO-membership answers for the hot "is this a subclass of
    /// `super` / of `type`?" questions (RFC 0077 WS4), as a bitset:
    /// `1` = super answer known, `2` = is a `super` subclass, `4` = type
    /// answer known, `8` = is a `type` subclass. The generic instance
    /// attribute load consults the first to skip the three super-proxy
    /// dict probes (`__self_class__`/`__self__`/`__thisclass__`, each a
    /// siphash) on ordinary instances; `instantiate` consults the second
    /// on every constructor call. Reset by [`Self::bump_attr_version`],
    /// which every MRO reshaping runs.
    pub mro_kind: std::sync::atomic::AtomicU8,
    /// Attribute-resolution version, WeavePy's analogue of CPython's
    /// `tp_version_tag`: bumped (for the type and every transitive
    /// subclass) whenever the class dict or MRO changes in a way that can
    /// alter attribute resolution — a class attribute set/delete or a
    /// `__bases__` reshaping. LOAD_ATTR/STORE_ATTR inline caches embed
    /// the value observed at specialisation time and deopt on mismatch,
    /// so installing e.g. a `property` over a name that instances carry
    /// in `__dict__` is seen by already-specialised call sites. Also keys
    /// the per-thread [`type_cache`] (RFC 0077 WS4).
    pub attr_version: AttrVersion,
    /// Cached "do instances of this type carry a `__del__` finalizer
    /// anywhere in their MRO?" answer, so [`crate::object::PyInstance`]'s
    /// `Drop` safety net can skip an MRO walk on the hot per-instance drop
    /// path: `0` = not yet computed, `1` = no finalizer, `2` = has one.
    /// Invalidated (reset to `0`) for the type and its subclasses whenever
    /// `__del__` is assigned to / deleted from a type's dict or the MRO is
    /// recomputed (`__bases__` assignment).
    pub has_del: Cell<u8>,
    /// Memoised instantiation plan (`type(…)` call protocol resolution:
    /// `__new__`/`__init__`/native-payload classification), stamped with
    /// the [`Self::attr_version`] observed when it was built. Rebuilt
    /// lazily whenever the version moved on. See
    /// `Interpreter::instance_plan`.
    pub instance_plan: RefCell<Option<(u64, Rc<InstancePlan>)>>,
    /// The C `tp_name` of the extension type this class bridges, when it
    /// differs from the bare [`Self::name`] (`"numpy.ndarray"` vs
    /// `"ndarray"`). CPython's `tp_name`-based error text (the
    /// "unsupported operand type(s)" family) prints this full dotted
    /// string while `__name__` stays bare; set by the C-API bridge when a
    /// stock extension type is readied. The `&'static` is a leaked copy —
    /// bridged types are immortal.
    pub c_tp_name: crate::sync::RefCell<Option<&'static str>>,
    /// The bridged C type carries a real `tp_as_sequence->sq_item` (RFC
    /// 0047, wave 5). Set by the C-API bridge when an extension type is
    /// readied/spec-built. `PyObject_GetIter`'s legacy fallback keys on
    /// exactly this (`PySequence_Check`): a C type with `sq_item` but no
    /// `tp_iter` is iterable through `PySeqIter` (numpy's
    /// `_array_converter`), while a mapping whose `__getitem__` shim comes
    /// from `mp_subscript` (numpy's parametric dtypes) is not. The VM's
    /// `make_iter` consults this to replicate that distinction, which the
    /// synthesised `__getitem__` dunder alone cannot express.
    pub c_sq_item: Cell<bool>,
    /// WeavePy analogue of `Py_TPFLAGS_IMMUTABLETYPE` for *frozen-stdlib*
    /// classes standing in for CPython's static C types (decimal's
    /// `Decimal`/`Context`, typing's `TypeAliasType`, …): attribute
    /// set/delete on the class raises TypeError, exactly like
    /// `flags.is_builtin` types, while `type(cls)` stays plain `type`.
    /// Opted into with a `__weave_immutable_type__ = True` class-body
    /// marker (stripped from the namespace at class creation). A visible
    /// metaclass emulation is not equivalent: Cython's `cdef type x =
    /// Decimal` compiles to `PyType_CheckExact`, which demands
    /// `Py_TYPE(Decimal) == &PyType_Type` (pandas `_libs.missing`).
    pub immutable: Cell<bool>,
    /// Set alongside [`Self::immutable`] when a *heap* type was frozen at
    /// runtime (`PyType_Freeze`, RFC 0077 WS12) rather than standing in
    /// for a static C type: the immutability errors then print the bare
    /// `tp_name` (`'MyType'`) CPython prints for heap types instead of
    /// the dotted static-type spelling.
    pub frozen_heap_type: Cell<bool>,
    /// The extension's own static `PyTypeObject*` when this class bridges
    /// a *readied stock* C type, else 0 (RFC 0076 WS5). A C extension may
    /// re-seat such a type's metaclass with a raw `Py_SET_TYPE(&MyType,
    /// meta)` field write that no C-API call announces (torch's
    /// `_set_generator_metaclass`); [`Self::metaclass_or_type`] hands this
    /// pointer to the bridge-installed [`install_metaclass_drift_hook`]
    /// so the drift is adopted the moment Python asks for the class of
    /// the class.
    pub c_ext_ptr: Cell<usize>,
}

/// Per-class resolution of the `type.__call__` protocol, cached on the
/// class ([`TypeObject::instance_plan`]) and invalidated by
/// [`TypeObject::attr_version`]. Everything here is a pure function of
/// the class dict / MRO — the *per-call* work (allocating the instance,
/// running `__init__`) stays in `Interpreter::instantiate`.
#[derive(Debug)]
pub struct InstancePlan {
    /// `Some(message)` when the class still carries unimplemented
    /// abstract methods: instantiation fails with exactly this TypeError.
    pub abstract_error: Option<String>,
    /// The resolved user `__new__` (already unwrapped from its
    /// static/classmethod wrapper, pre-bound for the classmethod form).
    /// `None` when the default allocator (`object.__new__`) applies.
    pub user_new: Option<Object>,
    /// The MRO resolution of `__new__` was `object.__new__` itself.
    pub is_object_new: bool,
    /// Native payload classification for built-in value subclasses
    /// (`class C(int)`, `class D(dict)`, …) and descriptor wrappers.
    pub native: NativeKind,
    /// The raw `__init__` MRO hit (may be a `Property` or any object; the
    /// call-time match handles the shapes).
    pub init_fn: Option<Object>,
    /// That `__init__` is `object.__init__` (so the default-arity rules
    /// apply and the call can be skipped when `__new__` is overridden).
    pub init_from_object: bool,
    /// Instances descend from `BaseException`: seed `.args` at allocation.
    pub seeds_exception_args: bool,
    /// The MRO beyond the class itself is just `object` — the strict
    /// "takes no arguments" arity check applies when no `__init__` exists.
    pub only_object_init: bool,
}

/// How a fresh instance's `native` payload is provisioned (see
/// [`InstancePlan::native`]).
#[derive(Debug, Clone)]
pub enum NativeKind {
    /// Plain Python instance — no native payload.
    Plain,
    /// Subclass of `property` — wrap a fresh property built from args.
    Property,
    /// Subclass of `classmethod`.
    ClassMethod,
    /// Subclass of `staticmethod`.
    StaticMethod,
    /// Subclass of a built-in value/container type: seed from the base's
    /// constructor (`mutable` bases with a user `__init__` get an empty
    /// payload instead — the `__init__` owns the filling).
    Value { base: Rc<TypeObject>, mutable: bool },
}

impl std::fmt::Debug for TypeObject {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "<class '{}'>", self.name)
    }
}

#[derive(Default, Clone, Copy, Debug)]
pub struct TypeFlags {
    /// `True` for types whose MRO contains `BaseException`.
    pub is_exception: bool,
    /// `True` for the small set of types created by the interpreter
    /// itself at startup (vs user-defined `class` statements).
    pub is_builtin: bool,
}

impl TypeObject {
    /// Construct a built-in type that inherits from `bases`. The MRO
    /// is computed via C3 linearisation.
    pub fn new_builtin(name: &str, bases: Vec<Rc<TypeObject>>) -> Result<Rc<Self>, RuntimeError> {
        Self::new_with_flags(
            name,
            bases,
            DictData::default(),
            TypeFlags {
                is_exception: false,
                is_builtin: true,
            },
        )
    }

    /// Construct a built-in exception type. Convenience wrapper.
    pub fn new_exception(name: &str, base: Rc<TypeObject>) -> Result<Rc<Self>, RuntimeError> {
        Self::new_with_flags(
            name,
            vec![base],
            DictData::default(),
            TypeFlags {
                is_exception: true,
                is_builtin: true,
            },
        )
    }

    /// Is this built-in type one whose instances "own" a distinct memory
    /// layout (CPython: `tp_basicsize`/`tp_itemsize` extended past the
    /// base)? Determines the `solid_base` used for multiple-inheritance
    /// layout-conflict checks. Plain exceptions all share
    /// `BaseException`'s layout; the listed ones add fields.
    fn owns_layout(&self) -> bool {
        if !self.flags.is_builtin || self.name == "object" {
            return false;
        }
        if self.flags.is_exception {
            return matches!(
                self.name.as_str(),
                "BaseException"
                    | "OSError"
                    | "SyntaxError"
                    | "SystemExit"
                    | "StopIteration"
                    | "ImportError"
                    | "NameError"
                    | "AttributeError"
                    | "UnicodeDecodeError"
                    | "UnicodeEncodeError"
                    | "UnicodeTranslateError"
                    | "BaseExceptionGroup"
            );
        }
        true
    }

    /// CPython's `solid_base`: the most-derived class on the MRO whose
    /// instance layout this type shares. `None` means plain `object`.
    pub fn solid_base(&self) -> Option<Rc<TypeObject>> {
        self.mro.borrow().iter().find(|t| t.owns_layout()).cloned()
    }

    /// Recompute this type's C3 linearisation from its *current* bases
    /// (used by `type.mro()` and `__bases__` assignment).
    pub fn recompute_c3(ty: &Rc<TypeObject>) -> Result<Vec<Rc<TypeObject>>, RuntimeError> {
        let bases = ty.bases.borrow().clone();
        compute_c3(ty, &bases, &ty.name)
    }

    /// CPython `type_new` base validation (`best_base`): every base must
    /// be subclassable, and the solid bases of all bases must form a
    /// single inheritance chain (no instance lay-out conflict).
    pub fn validate_bases(name: &str, bases: &[Rc<TypeObject>]) -> Result<(), RuntimeError> {
        let _ = name;
        for b in bases {
            if b.flags.is_builtin
                && matches!(
                    b.name.as_str(),
                    "bool"
                        | "NoneType"
                        | "NotImplementedType"
                        | "ellipsis"
                        | "range"
                        | "slice"
                        | "lock"
                        | "memoryview"
                        | "function"
                        | "builtin_function_or_method"
                        | "method"
                        | "generator"
                        | "coroutine"
                        | "async_generator"
                        | "frame"
                        | "traceback"
                        | "code"
                        | "cell"
                        | "mappingproxy"
                        | "ProxyType"
                        | "CallableProxyType"
                        | "member_descriptor"
                        | "method_descriptor"
                        | "getset_descriptor"
                        | "wrapper_descriptor"
                        | "method-wrapper"
                        | "Union"
                )
            {
                // `tp_name` spelling: `typing.Union` is the one heap-less
                // builtin here whose C name carries its module
                // (test_typing.UnionTests.test_cannot_subclass).
                let shown = if b.name.as_str() == "Union" {
                    "typing.Union"
                } else {
                    b.name.as_str()
                };
                return Err(type_error(format!(
                    "type '{shown}' is not an acceptable base type"
                )));
            }
            // A user class whose MRO is still unset is mid-creation (its
            // custom metaclass `mro()` is running); CPython refuses to
            // extend such an incomplete type (`best_base` error path).
            if !b.flags.is_builtin && b.mro.borrow().is_empty() {
                return Err(type_error(format!(
                    "Cannot extend an incomplete type '{}'",
                    b.name
                )));
            }
        }
        let mut winner: Option<Rc<TypeObject>> = None;
        for b in bases {
            let Some(sb) = b.solid_base() else { continue };
            match &winner {
                None => winner = Some(sb),
                Some(w) => {
                    if w.is_subclass_of(&sb) {
                        // current winner already extends sb — keep it
                    } else if sb.is_subclass_of(w) {
                        winner = Some(sb);
                    } else {
                        return Err(type_error("multiple bases have instance lay-out conflict"));
                    }
                }
            }
        }
        Ok(())
    }

    /// `type_new`-only base validation: a foreign C type advertises
    /// subclassability through `Py_TPFLAGS_BASETYPE`, and CPython's
    /// `best_base` refuses a base without it — but only on the *Python*
    /// class-statement / `type()` path. `PyType_Ready` never checks the
    /// flag: static C types legally extend non-BASETYPE bases (numpy's
    /// `PyCharacterArrType` extends the abstract `flexible` scalar whose
    /// Python subclassing must still raise — test_gh_23737, RFC 0076 WS1).
    pub fn validate_python_bases(bases: &[Rc<TypeObject>]) -> Result<(), RuntimeError> {
        for b in bases {
            let ext = b.c_ext_ptr.get();
            if ext != 0 {
                const BASETYPE: u64 = 1 << 10;
                let fl = crate::foreign::type_flags(ext);
                if fl != 0 && fl & BASETYPE == 0 {
                    return Err(type_error(format!(
                        "type '{}' is not an acceptable base type",
                        b.name
                    )));
                }
            }
        }
        Ok(())
    }

    /// Construct a user-defined class from a class statement.
    pub fn new_user(
        name: &str,
        bases: Vec<Rc<TypeObject>>,
        mut dict: DictData,
    ) -> Result<Rc<Self>, RuntimeError> {
        Self::validate_bases(name, &bases)?;
        let is_exception = bases.iter().any(|b| b.flags.is_exception);
        // CPython `type_new`: a class that defines `__eq__` without
        // defining `__hash__` is unhashable (`__hash__` is set to None
        // in the new class's dict).
        if dict.contains_key(&DictKey(Object::from_static("__eq__")))
            && !dict.contains_key(&DictKey(Object::from_static("__hash__")))
        {
            dict.insert(DictKey(Object::from_static("__hash__")), Object::None);
        }
        Self::new_with_flags(
            name,
            bases,
            dict,
            TypeFlags {
                is_exception,
                is_builtin: false,
            },
        )
    }

    pub fn new_with_flags(
        name: &str,
        bases: Vec<Rc<TypeObject>>,
        mut dict: DictData,
        flags: TypeFlags,
    ) -> Result<Rc<Self>, RuntimeError> {
        // CPython `type_new`: a *string* `__qualname__` in the class
        // namespace is removed and stored on the type itself.
        //
        // A getset/member *descriptor* named `__qualname__` is different:
        // it describes the type's *instances* (Cython's
        // `cython_function_or_method`, the generator/coroutine getsets, a
        // `__slots__ = ["__qualname__"]` member) and must stay in the dict
        // — the type's own qualname then falls back to its name, exactly as
        // CPython does (those descriptors arrive via `tp_getset`/
        // `tp_members`, never the `type_new` namespace). The C-API spec/
        // ready bridge merges harvested descriptors into this same dict, so
        // we recognise that case here rather than choking on it.
        let qualname = match dict.get(&DictKey(Object::from_static("__qualname__"))) {
            Some(Object::Str(_)) => {
                match dict.shift_remove(&DictKey(Object::from_static("__qualname__"))) {
                    Some(Object::Str(s)) => Some(s.to_string()),
                    _ => None,
                }
            }
            Some(v) if is_instance_descriptor(v) => None,
            Some(other) => {
                return Err(type_error(format!(
                    "type __qualname__ must be a str, not {}",
                    other.type_name()
                )))
            }
            None => None,
        };
        // Class dicts are the domain of `TypeObject::lookup`'s
        // allocation-free fast pass; note any non-`str` namespace key so
        // the Python-`__eq__` fallback probe knows it can be needed.
        for k in dict.keys() {
            crate::object::note_class_dict_key(k);
        }
        let ty = Rc::new(TypeObject {
            name: name.to_owned(),
            qualname: RefCell::new(qualname),
            bases: RefCell::new(bases.clone()),
            mro: RefCell::new(Vec::new()),
            dict: Rc::new(RefCell::new(dict)),
            flags,
            metaclass: RefCell::new(None),
            slot_names: RefCell::new(Vec::new()),
            declares_slots: Cell::new(false),
            forbids_dict: false,
            subclasses: RefCell::new(Vec::new()),
            getattribute_kind: Cell::new(0),
            setattr_kind: Cell::new(0),
            mro_kind: std::sync::atomic::AtomicU8::new(0),
            attr_version: AttrVersion::fresh(),
            has_del: Cell::new(0),
            instance_plan: RefCell::new(None),
            c_tp_name: crate::sync::RefCell::new(None),
            c_sq_item: Cell::new(false),
            immutable: Cell::new(false),
            frozen_heap_type: Cell::new(false),
            c_ext_ptr: Cell::new(0),
        });
        let mro = compute_c3(&ty, &bases, name)?;
        *ty.mro.borrow_mut() = mro;
        // Register the new class as a (weak) direct subclass of each of
        // its bases so `base.__subclasses__()` reports it.
        for base in &bases {
            base.subclasses.borrow_mut().push(Rc::downgrade(&ty));
        }
        // RFC 0024: user classes join the cycle collector. Every class
        // is born in a self-cycle (its own `mro` holds an `Rc` to
        // itself), so without tracking, `del SomeClass` could never
        // free it — and weakrefs to it (or to methods in its dict)
        // would never clear. Built-ins are immortal; skip them.
        if !ty.flags.is_builtin {
            crate::gc_trace::track(Object::Type(ty.clone()));
        }
        Ok(ty)
    }

    /// Does this type have a CPython "managed `__dict__`" — i.e. do its
    /// instances carry an attribute dict? True for user-defined classes
    /// whose MRO doesn't declare slots-without-dict the whole way down.
    pub fn has_managed_dict(&self) -> bool {
        !self.flags.is_builtin && !self.forbids_dict
    }

    /// Does this type inherit from a *variable-sized* built-in
    /// (`tp_itemsize != 0` in CPython: `int`, `tuple`, `str`, `bytes`,
    /// `type`)? Such types get a managed dict but no inline values.
    pub fn has_var_sized_base(&self) -> bool {
        self.mro.borrow().iter().any(|t| {
            t.flags.is_builtin
                && matches!(t.name.as_str(), "int" | "tuple" | "str" | "bytes" | "type")
        })
    }

    /// The first built-in class in the MRO other than `object` — the
    /// moral equivalent of CPython's `solid_base`, which determines
    /// instance memory layout for `__class__` assignment checks.
    /// `None` for plain `object`-rooted classes.
    pub fn solid_base_name(&self) -> Option<String> {
        self.mro
            .borrow()
            .iter()
            .find(|t| t.flags.is_builtin && t.name != "object")
            .map(|t| t.name.clone())
    }

    /// Does this type install its own `__dict__` slot (CPython's
    /// `tp_dictoffset` added at this level)? Used by the `__class__`
    /// assignment layout check (`same_slots_added`).
    pub fn adds_own_dict(&self) -> bool {
        self.dict
            .borrow()
            .contains_key(&DictKey(Object::from_static("__dict__")))
    }

    /// Does this type install its own `__weakref__` slot (CPython's
    /// `tp_weaklistoffset` added at this level)?
    pub fn adds_own_weakref(&self) -> bool {
        self.dict
            .borrow()
            .contains_key(&DictKey(Object::from_static("__weakref__")))
    }

    /// This type's own `__slots__` member names, sorted, excluding the
    /// pseudo-slots `__dict__`/`__weakref__` (which are accounted for
    /// separately, exactly like CPython's `ht_slots`).
    pub fn member_slots_sorted(&self) -> Vec<String> {
        let mut v: Vec<String> = self
            .slot_names
            .borrow()
            .iter()
            .filter(|s| s.as_str() != "__dict__" && s.as_str() != "__weakref__")
            .cloned()
            .collect();
        v.sort();
        v
    }

    /// Does this type change the instance C-struct relative to its base
    /// (CPython: `!compatible_with_tp_base`)? A built-in value type owns
    /// its layout; a heap type changes it by adding member slots, a
    /// `__dict__`, or a `__weakref__`.
    pub fn changes_layout(&self) -> bool {
        if self.flags.is_builtin {
            return self.name != "object";
        }
        !self.member_slots_sorted().is_empty() || self.adds_own_dict() || self.adds_own_weakref()
    }

    /// CPython `best_base`: the base contributing the instance layout —
    /// the one whose solid base is the most derived. Ties resolve to the
    /// first base (matching `type_new`'s left-to-right scan).
    pub fn best_base(self: &Rc<Self>) -> Option<Rc<TypeObject>> {
        let bases = self.bases.borrow();
        let mut best: Option<Rc<TypeObject>> = None;
        for b in bases.iter() {
            if b.name == "object" && bases.len() > 1 {
                // `object` only wins when it is the sole base.
                if best.is_none() {
                    best = Some(b.clone());
                }
                continue;
            }
            match &best {
                None => best = Some(b.clone()),
                Some(cur) => {
                    if b.is_subclass_of(cur) {
                        best = Some(b.clone());
                    }
                }
            }
        }
        best
    }

    /// CPython `compatible_for_assignment`'s `newbase`/`oldbase` walk:
    /// climb the `best_base` chain past every level that doesn't change
    /// the struct, returning the most-derived type that *does*.
    pub fn layout_struct_base(self: &Rc<Self>) -> Rc<TypeObject> {
        let mut cur = self.clone();
        while !cur.changes_layout() {
            match cur.best_base() {
                Some(b) => cur = b,
                None => break,
            }
        }
        cur
    }

    /// CPython `type.__flags__` (`tp_flags`), computed from this type's
    /// observable properties. Covers the documented/queried bits:
    /// inline-values + managed-dict (`test_class`), heap/base/ready/gc,
    /// abstractness, and the `*_SUBCLASS` fast-classification bits.
    pub fn flags_bits(&self) -> i64 {
        const INLINE_VALUES: i64 = 1 << 2;
        const MANAGED_WEAKREF: i64 = 1 << 3;
        const MANAGED_DICT: i64 = 1 << 4;
        const IMMUTABLETYPE: i64 = 1 << 8;
        const HEAPTYPE: i64 = 1 << 9;
        const BASETYPE: i64 = 1 << 10;
        const READY: i64 = 1 << 12;
        const HAVE_GC: i64 = 1 << 14;
        const HAVE_VECTORCALL: i64 = 1 << 11;
        const METHOD_DESCRIPTOR: i64 = 1 << 17;
        const IS_ABSTRACT: i64 = 1 << 20;
        const LONG_SUBCLASS: i64 = 1 << 24;
        const LIST_SUBCLASS: i64 = 1 << 25;
        const TUPLE_SUBCLASS: i64 = 1 << 26;
        const BYTES_SUBCLASS: i64 = 1 << 27;
        const UNICODE_SUBCLASS: i64 = 1 << 28;
        const DICT_SUBCLASS: i64 = 1 << 29;
        const BASE_EXC_SUBCLASS: i64 = 1 << 30;
        const TYPE_SUBCLASS: i64 = 1 << 31;

        let mut bits = READY;
        // Frozen-stdlib stand-ins for CPython static C types (see
        // [`TypeObject::immutable`]) report the immutability bit exactly
        // as their CPython counterparts do.
        if self.immutable.get() {
            bits |= IMMUTABLETYPE;
        }
        if self.flags.is_builtin {
            bits |= IMMUTABLETYPE;
            // Built-ins that refuse subclassing.
            let is_final = matches!(
                self.name.as_str(),
                "bool"
                    | "NoneType"
                    | "NotImplementedType"
                    | "ellipsis"
                    | "range"
                    | "slice"
                    | "memoryview"
                    | "generator"
                    | "coroutine"
                    | "async_generator"
                    | "function"
                    | "builtin_function_or_method"
                    | "method_wrapper"
                    | "mappingproxy"
            );
            if !is_final {
                bits |= BASETYPE;
            }
            if matches!(
                self.name.as_str(),
                "list" | "dict" | "set" | "frozenset" | "tuple" | "type"
            ) || self.flags.is_exception
            {
                bits |= HAVE_GC;
            }
            // gh-89653: the `_io` classes were converted to *immutable heap
            // types* (`PyType_FromModuleAndSpec`) in CPython 3.11+, so they
            // report `HEAPTYPE` in addition to `IMMUTABLETYPE`. This is
            // observable: `copyreg._reduce_ex` walks `__mro__` until a
            // non-heap base, so without `HEAPTYPE` an `_io` subclass with
            // `__getstate__`/`__setstate__` cannot pickle at protocols 0/1
            // (`test_io.test_pickling_subclass`).
            if matches!(
                self.name.as_str(),
                "FileIO"
                    | "BytesIO"
                    | "StringIO"
                    | "BufferedReader"
                    | "BufferedWriter"
                    | "BufferedRandom"
                    | "BufferedRWPair"
                    | "TextIOWrapper"
                    | "IncrementalNewlineDecoder"
                    | "IOBase"
                    | "RawIOBase"
                    | "BufferedIOBase"
                    | "TextIOBase"
            ) {
                bits |= HEAPTYPE;
            }
        } else {
            bits |= HEAPTYPE | BASETYPE | HAVE_GC | MANAGED_WEAKREF;
            if self.has_managed_dict() {
                bits |= MANAGED_DICT;
                if !self.has_var_sized_base() {
                    bits |= INLINE_VALUES;
                }
            }
        }
        // `Py_TPFLAGS_METHOD_DESCRIPTOR` (PEP 590): types whose instances
        // behave like unbound methods under vectorcall. Matches CPython's
        // static-type set; heap types never inherit the bit.
        if self.flags.is_builtin
            && matches!(
                self.name.as_str(),
                "function" | "method_descriptor" | "wrapper_descriptor"
            )
        {
            bits |= METHOD_DESCRIPTOR | HAVE_VECTORCALL;
        }
        // `functools.lru_cache`'s C wrapper type is a *static* method
        // descriptor in CPython; WeavePy builds it as a heap type
        // (`functools_mod::lru_type`), so match it by name.
        if self.name == "_lru_cache_wrapper" {
            bits |= METHOD_DESCRIPTOR | HAVE_VECTORCALL;
        }
        // RFC 0060 — the `_testcapi` vectorcall fixtures answer these two
        // bits from their registries (gated so ordinary programs skip it).
        if crate::stdlib::testcapi_call::fixtures_active() {
            if crate::stdlib::testcapi_call::type_is_method_descriptor(self) {
                bits |= METHOD_DESCRIPTOR;
            }
            if crate::stdlib::testcapi_call::type_has_vectorcall(self) {
                bits |= HAVE_VECTORCALL;
            }
        }
        match self
            .dict
            .borrow()
            .get(&DictKey(Object::from_static("__abstractmethods__")))
        {
            Some(Object::Set(s)) if !s.borrow().is_empty() => bits |= IS_ABSTRACT,
            Some(Object::FrozenSet(s)) if !s.is_empty() => bits |= IS_ABSTRACT,
            _ => {}
        }
        for t in self.mro.borrow().iter() {
            if t.flags.is_builtin {
                match t.name.as_str() {
                    "int" => bits |= LONG_SUBCLASS,
                    "list" => bits |= LIST_SUBCLASS,
                    "tuple" => bits |= TUPLE_SUBCLASS,
                    "bytes" => bits |= BYTES_SUBCLASS,
                    "str" => bits |= UNICODE_SUBCLASS,
                    "dict" => bits |= DICT_SUBCLASS,
                    "type" => bits |= TYPE_SUBCLASS,
                    _ => {}
                }
            }
        }
        bits |= self.collection_flags();
        if self.flags.is_exception {
            bits |= BASE_EXC_SUBCLASS;
        }
        bits
    }

    /// PEP 634 collection flag for this type: `Py_TPFLAGS_SEQUENCE`
    /// (1 << 5) or `Py_TPFLAGS_MAPPING` (1 << 6), driving `MATCH_SEQUENCE`
    /// / `MATCH_MAPPING`. CPython inherits these bits from the dominant
    /// base, so the *first* flag-bearing entry along the MRO wins —
    /// `class M1(UserDict, Sequence)` is MAPPING only, and
    /// `class Both(Sequence, Mapping)` is SEQUENCE only
    /// (test_patma.TestInheritance). Sources of the flag, per MRO entry:
    /// the flag-carrying C builtins (list/tuple/range/memoryview are
    /// sequences; dict/mappingproxy are mappings; str/bytes/bytearray are
    /// deliberately excluded by the PEP), and `_abc_collection_flags` —
    /// where ABCMeta stows a class's `__abc_tpflags__` declaration and
    /// where `ABC.register()` stamps virtual registrations.
    pub fn collection_flags(&self) -> i64 {
        const SEQUENCE: i64 = 1 << 5;
        const MAPPING: i64 = 1 << 6;
        let mro: Vec<Rc<TypeObject>> = self.mro.borrow().clone();
        for t in mro.iter() {
            if t.flags.is_builtin {
                match t.name.as_str() {
                    "list" | "tuple" | "range" | "memoryview" => return SEQUENCE,
                    "dict" | "mappingproxy" => return MAPPING,
                    _ => {}
                }
            }
            if let Some(v) = t
                .dict
                .borrow()
                .get(&DictKey(Object::from_static("_abc_collection_flags")))
                .and_then(Object::as_i64)
            {
                if v & (SEQUENCE | MAPPING) != 0 {
                    return v & (SEQUENCE | MAPPING);
                }
            }
            // A bridged extension type declares the bit straight in its C
            // `tp_flags` — numpy 2.x stamps `Py_TPFLAGS_SEQUENCE` on
            // `ndarray`, so `match arr: case [a, b, c]` matches, memmap
            // included (RFC 0075 WS8, test_memmap TestPatternMatching).
            if let Some(c_flags) = crate::descr_registry::ext_type_c_flags(t) {
                let v = c_flags as i64 & (SEQUENCE | MAPPING);
                if v != 0 {
                    return v;
                }
            }
        }
        0
    }

    /// Reset the cached `__getattribute__` / `__setattr__` classifications
    /// for this type and every (transitive) subclass. Called when either
    /// dunder is assigned to or deleted from a type's dict, since that can
    /// change the resolved slot for the type *and* anything inheriting from
    /// it. Class hierarchies are acyclic, so the recursion terminates.
    pub fn invalidate_getattribute_cache(&self) {
        // Iterative walk with a visited set: reentrant `__bases__`
        // assignment can leave a *cycle* through the subclass registry
        // (gh-92112), which naive recursion would loop on forever.
        let mut visited: Vec<*const TypeObject> = vec![std::ptr::from_ref::<TypeObject>(self)];
        self.getattribute_kind.set(0);
        self.setattr_kind.set(0);
        let mut queue: Vec<Rc<TypeObject>> = self.subclasses();
        while let Some(t) = queue.pop() {
            let ptr = Rc::as_ptr(&t);
            if visited.contains(&ptr) {
                continue;
            }
            visited.push(ptr);
            t.getattribute_kind.set(0);
            t.setattr_kind.set(0);
            queue.extend(t.subclasses());
        }
    }

    /// Advance [`Self::attr_version`] for this type and every transitive
    /// subclass. Call after any class-dict mutation or MRO reshaping that
    /// can change what an attribute name resolves to; specialised
    /// LOAD_ATTR/STORE_ATTR sites guard on the version and deopt.
    pub fn bump_attr_version(&self) {
        use std::sync::atomic::Ordering::Relaxed;
        let mut visited: Vec<*const TypeObject> = vec![std::ptr::from_ref::<TypeObject>(self)];
        self.attr_version.bump();
        self.mro_kind.store(0, Relaxed);
        let mut queue: Vec<Rc<TypeObject>> = self.subclasses();
        while let Some(t) = queue.pop() {
            let ptr = Rc::as_ptr(&t);
            if visited.contains(&ptr) {
                continue;
            }
            visited.push(ptr);
            t.attr_version.bump();
            t.mro_kind.store(0, Relaxed);
            queue.extend(t.subclasses());
        }
    }

    /// Cached MRO-membership probe behind [`Self::mro_kind`]: `known` and
    /// `yes` are the bit pair for one question.
    #[inline]
    fn mro_kind_probe(&self, known: u8, yes: u8, target: &TypeObject) -> bool {
        use std::sync::atomic::Ordering::Relaxed;
        let bits = self.mro_kind.load(Relaxed);
        if bits & known != 0 {
            return bits & yes != 0;
        }
        let is = self.is_subclass_of(target);
        // Other bits may have been filled concurrently; keep them.
        self.mro_kind
            .fetch_or(known | if is { yes } else { 0 }, Relaxed);
        is
    }

    /// Is this `super` itself or a user subclass of it, i.e. can its
    /// instances be super proxies carrying `__self_class__`? Cached in
    /// [`Self::mro_kind`].
    #[inline]
    pub fn is_super_proxy_type(&self) -> bool {
        self.mro_kind_probe(1, 2, &crate::builtin_types::builtin_types().super_)
    }

    /// Is this `type` itself or a metaclass (a subclass of `type`)?
    /// Cached in [`Self::mro_kind`].
    #[inline]
    pub fn is_type_subclass(&self) -> bool {
        self.mro_kind_probe(4, 8, &crate::builtin_types::builtin_types().type_)
    }

    /// Classify this type's resolved `__setattr__`: `true` when it is the
    /// stock `object.__setattr__` default (so an instance attribute store
    /// may run the generic setter directly), `false` when any class in the
    /// MRO overrides it. Cached in [`Self::setattr_kind`].
    pub fn setattr_is_default(&self) -> bool {
        match self.setattr_kind.get() {
            1 => return true,
            2 => return false,
            _ => {}
        }
        let default = match self.lookup_with_owner("__setattr__") {
            // The stock default: `object`'s own builtin. Owner identity —
            // not value shape — so a user class *shadowing* the name with
            // a copied builtin still dispatches through the full path.
            Some((Object::Builtin(_), owner)) => {
                Rc::ptr_eq(&owner, &crate::builtin_types::builtin_types().object_)
            }
            None => true,
            Some(_) => false,
        };
        self.setattr_kind.set(if default { 1 } else { 2 });
        default
    }

    /// Do instances of this type carry a `__del__` finalizer anywhere in
    /// their MRO? Cached (see [`TypeObject::has_del`]) so the per-instance
    /// `Drop` safety net pays an MRO walk at most once per type, then a
    /// single `Cell` read. The result only changes when `__del__` is
    /// assigned to / deleted from a class in the MRO, or the MRO itself is
    /// reshaped — both of which reset the cache via
    /// [`Self::invalidate_finalizer_cache`].
    ///
    /// **Drop-safe.** This is called from [`crate::object::PyInstance`]'s
    /// `Drop`, which can fire at *any* moment — including while this very
    /// type's `dict`/`mro` is mutably borrowed (a class attribute that is an
    /// instance of its own class, evicted mid-`__setattr__`). It therefore
    /// probes with `try_borrow` and never re-enters Python (the `__del__`
    /// key is an interned `str`, so dict lookup is pure), falling back to a
    /// conservative `true` on any borrow conflict: a spurious resurrection
    /// is harmless because `Vm::invoke_finalizer` simply no-ops when the
    /// instance turns out to have no `__del__`.
    pub fn instances_need_finalize(&self) -> bool {
        match self.has_del.get() {
            1 => return false,
            2 => return true,
            _ => {}
        }
        let Ok(mro) = self.mro.try_borrow() else {
            return true;
        };
        let key = DictKey(Object::from_static("__del__"));
        for ty in mro.iter() {
            match ty.dict.try_borrow() {
                Ok(d) => {
                    if d.get(&key).is_some() {
                        self.has_del.set(2);
                        return true;
                    }
                }
                // The type is mid-mutation; don't risk a panic, and don't
                // poison the cache — assume finalizable for this one drop.
                Err(_) => return true,
            }
        }
        self.has_del.set(1);
        false
    }

    /// Reset the cached `__del__` classification for this type and every
    /// (transitive) subclass. Called when `__del__` is assigned to / deleted
    /// from a type's dict, or when the MRO is recomputed — either can change
    /// which `__del__` (if any) an instance resolves. Mirrors
    /// [`Self::invalidate_getattribute_cache`]'s acyclic-with-visited walk.
    pub fn invalidate_finalizer_cache(&self) {
        let mut visited: Vec<*const TypeObject> = vec![std::ptr::from_ref::<TypeObject>(self)];
        self.has_del.set(0);
        let mut queue: Vec<Rc<TypeObject>> = self.subclasses();
        while let Some(t) = queue.pop() {
            let ptr = Rc::as_ptr(&t);
            if visited.contains(&ptr) {
                continue;
            }
            visited.push(ptr);
            t.has_del.set(0);
            queue.extend(t.subclasses());
        }
    }

    /// Live direct subclasses, in registration order. Dead weak refs
    /// (subclasses that have been dropped) are pruned as a side effect.
    pub fn subclasses(&self) -> Vec<Rc<TypeObject>> {
        let mut subs = self.subclasses.borrow_mut();
        subs.retain(|w| w.strong_count() > 0);
        subs.iter().filter_map(Weak::upgrade).collect()
    }

    /// Internal: install a metaclass on this type. Used at startup
    /// to wire `type.__class__ is type` for the built-in `type`
    /// itself, and by [`crate::Vm::build_class`] when honouring the
    /// `metaclass=` keyword.
    pub fn set_metaclass(&self, meta: Rc<TypeObject>) {
        *self.metaclass.borrow_mut() = Some(meta);
    }

    /// Install the C-API bridge's metaclass-drift probe (RFC 0076 WS5,
    /// see [`TypeObject::c_ext_ptr`]). Idempotent.
    pub fn install_metaclass_drift_hook(f: fn(usize, &TypeObject)) {
        let _ = METACLASS_DRIFT_HOOK.set(f);
    }

    /// The metaclass slot, falling back to `type` for any type that
    /// hasn't had one installed yet.
    pub fn metaclass_or_type(&self) -> Rc<TypeObject> {
        // A readied stock C type first re-checks its struct's live
        // `ob_type` for a raw `Py_SET_TYPE` metaclass re-seat (RFC 0076
        // WS5, see [`Self::c_ext_ptr`]); the hook installs any drift into
        // `self.metaclass` before the read below.
        let ext = self.c_ext_ptr.get();
        if ext != 0 {
            if let Some(h) = METACLASS_DRIFT_HOOK.get() {
                h(ext, self);
            }
        }
        if let Some(m) = self.metaclass.borrow().as_ref() {
            return m.clone();
        }
        crate::builtin_types::builtin_types().type_.clone()
    }

    /// `True` when `self` is a subclass of `other` (including itself).
    pub fn is_subclass_of(&self, other: &TypeObject) -> bool {
        let other_ptr = std::ptr::from_ref::<TypeObject>(other);
        self.mro
            .borrow()
            .iter()
            .any(|t| std::ptr::eq(Rc::as_ptr(t), other_ptr))
    }

    /// Look up `name` in this type's MRO.
    pub fn lookup(&self, name: &str) -> Option<Object> {
        // Fast pass: allocation-free `StrKey` probes, walking the MRO
        // under its borrow. Holding the borrow across the probes is
        // safe while every class-dict key in the process is a plain
        // `str` — the comparisons are then pure native code and can
        // never re-enter Python to reassign `__bases__` mid-walk.
        if !crate::object::exotic_str_keys_possible() {
            return self.lookup_cached(name).map(|(v, _)| v);
        }
        let key = DictKey(Object::from_str(name));
        // Snapshot the MRO before walking it (CPython `_PyType_Lookup`
        // holds a strong reference for the same reason): a dict probe
        // can re-enter Python (`__eq__` on a non-string class-dict key)
        // and reassign `__bases__` mid-lookup. The in-flight lookup
        // must keep resolving against the *old* linearisation.
        let mro: Vec<Rc<TypeObject>> = self.mro.borrow().clone();
        for ty in mro.iter() {
            if let Some(v) = ty.dict.borrow().get(&key).cloned() {
                if ty.flags.is_builtin && crate::descr_registry::is_surface_only(&v) {
                    continue;
                }
                return Some(v);
            }
        }
        None
    }

    /// Like [`Self::lookup`], but also report the MRO entry that owns
    /// the attribute. Lets callers distinguish a dunder *supplied by a
    /// user class* from one inherited off a built-in (e.g. `object`'s
    /// identity `__hash__`).
    pub fn lookup_with_owner(&self, name: &str) -> Option<(Object, Rc<TypeObject>)> {
        // Fast pass — see `lookup` for the gate rationale.
        if !crate::object::exotic_str_keys_possible() {
            let (v, idx) = self.lookup_cached(name)?;
            let owner = self.mro.borrow().get(idx)?.clone();
            return Some((v, owner));
        }
        let key = DictKey(Object::from_str(name));
        // Snapshot for reentrancy — see `lookup`.
        let mro: Vec<Rc<TypeObject>> = self.mro.borrow().clone();
        for ty in mro.iter() {
            if let Some(v) = ty.dict.borrow().get(&key).cloned() {
                if ty.flags.is_builtin && crate::descr_registry::is_surface_only(&v) {
                    continue;
                }
                return Some((v, ty.clone()));
            }
        }
        None
    }

    /// The plain-`str`-keys MRO walk behind [`Self::lookup`] and
    /// [`Self::lookup_with_owner`], fronted by the per-thread
    /// [`type_cache`]. Returns the value and the MRO index of its owner.
    #[inline]
    fn lookup_cached(&self, name: &str) -> Option<(Object, usize)> {
        let ty = std::ptr::from_ref::<TypeObject>(self) as usize;
        let ver = self.attr_version.get();
        let h = type_cache::name_hash(name);
        match type_cache::probe(ty, ver, name, h) {
            Some(type_cache::Hit::Absent) => return None,
            Some(type_cache::Hit::At { mro_idx, dict_idx }) => {
                let mro = self.mro.borrow();
                if let Some(owner) = mro.get(mro_idx as usize) {
                    let d = owner.dict.borrow();
                    if let Some((k, v)) = d.get_index(dict_idx as usize) {
                        if matches!(&k.0, Object::Str(s) if s.as_ref() == name) {
                            return Some((v.clone(), mro_idx as usize));
                        }
                    }
                }
                // The slot moved under an unbumped mutation: fall through
                // to the walk, which refreshes the entry.
            }
            None => {}
        }
        let key = crate::object::StrKey(name);
        let mro = self.mro.borrow();
        for (i, owner) in mro.iter().enumerate() {
            let d = owner.dict.borrow();
            if let Some((dict_idx, _, v)) = d.get_full(&key) {
                // Introspection-only entries (RFC 0056 WS4) are invisible
                // to dispatch — keep walking as if absent. Only in
                // *builtin* dicts, where the docs surface pass installed
                // them: a user class that aliases one
                // (`__str__ = object.__str__`) means it, per CPython.
                if owner.flags.is_builtin && crate::descr_registry::is_surface_only(v) {
                    continue;
                }
                let v = v.clone();
                drop(d);
                type_cache::fill(
                    ty,
                    ver,
                    name,
                    h,
                    type_cache::Hit::At {
                        mro_idx: i as u32,
                        dict_idx: dict_idx as u32,
                    },
                );
                return Some((v, i));
            }
        }
        type_cache::fill(ty, ver, name, h, type_cache::Hit::Absent);
        None
    }

    pub fn class_name(&self) -> &str {
        &self.name
    }

    /// CPython `type_repr` name: `__module__.__qualname__`, with the
    /// module prefix omitted for `builtins` (so `<class 'int'>` but
    /// `<class 'collections.abc.Iterable'>` / `<class '__main__.Foo'>`).
    /// The `tp_name` CPython prints in "immutable type" errors: the
    /// dotted static-type spelling for built-ins and the frozen-stdlib
    /// stand-ins, the bare class name for a heap type frozen at runtime.
    pub fn immutable_type_display_name(&self) -> String {
        if self.frozen_heap_type.get() {
            self.name.clone()
        } else {
            self.qualified_display_name()
        }
    }

    pub fn qualified_display_name(&self) -> String {
        let dict = self.dict.borrow();
        // Only honour *string* entries — some built-in types carry a
        // `__qualname__`/`__module__` *property descriptor* (for their
        // instances) in the dict, which must not leak into the class
        // repr (`type(gen)` printing `<class '<property object>'>`).
        let as_str = |name: &'static str| match dict.get(&DictKey(Object::from_static(name))) {
            Some(Object::Str(s)) => Some(s.as_ref().to_owned()),
            _ => None,
        };
        // A *static* extension type carries no `__module__` dict entry
        // (CPython leaves it out so pickle's `whichmodule` scan works; RFC
        // 0075 WS8) — its module is the dotted prefix of the C `tp_name`,
        // exactly how CPython's `type_repr` → `type_module` derives it
        // (`<class 'numpy.timedelta64'>`, not `<class 'timedelta64'>`).
        let module = as_str("__module__").or_else(|| {
            let full = self.c_tp_name.get()?;
            let (m, _) = full.rsplit_once('.')?;
            Some(m.to_owned())
        });
        let qual = as_str("__qualname__")
            .or_else(|| self.qualname.borrow().clone())
            .unwrap_or_else(|| self.name.clone());
        match module.as_deref() {
            None | Some("builtins") | Some("") => qual,
            Some(m) => format!("{m}.{qual}"),
        }
    }

    /// The name CPython's `tp_name`-based error text prints: the full
    /// dotted C `tp_name` for a bridged/static-emulating type
    /// (`'numpy.ndarray'`, `'re.Pattern'`), the bare `__name__` otherwise.
    pub fn error_tp_name(&self) -> String {
        match self.c_tp_name.get() {
            Some(full) => full.to_owned(),
            None => self.name.clone(),
        }
    }
}

/// Is `obj` a descriptor that describes a type's *instances* (rather than
/// being a plain class attribute)? Used by [`TypeObject::new_with_flags`]
/// to tell a getset/member `__qualname__` (which must stay in the dict)
/// from a class-body `__qualname__` string/value.
fn is_instance_descriptor(obj: &Object) -> bool {
    match obj {
        Object::Property(_) | Object::SlotDescriptor(_) => true,
        Object::Instance(inst) => {
            inst.cls().lookup("__get__").is_some()
                || inst.cls().lookup("__set__").is_some()
                || inst.cls().lookup("__delete__").is_some()
        }
        _ => false,
    }
}

fn compute_c3(
    self_ty: &Rc<TypeObject>,
    bases: &[Rc<TypeObject>],
    name: &str,
) -> Result<Vec<Rc<TypeObject>>, RuntimeError> {
    let mut lists: Vec<Vec<Rc<TypeObject>>> =
        bases.iter().map(|b| b.mro.borrow().clone()).collect();
    lists.push(bases.to_vec());
    let mut merged: Vec<Rc<TypeObject>> = vec![self_ty.clone()];
    loop {
        lists.retain(|l| !l.is_empty());
        if lists.is_empty() {
            break;
        }
        let mut chosen: Option<Rc<TypeObject>> = None;
        for list in &lists {
            let head = &list[0];
            let head_in_other_tails = lists
                .iter()
                .any(|other| other.iter().skip(1).any(|t| Rc::ptr_eq(t, head)));
            if !head_in_other_tails {
                chosen = Some(head.clone());
                break;
            }
        }
        let Some(c) = chosen else {
            // CPython `set_mro_error`: list each unmerged list's *head*
            // by `__name__`, in first-appearance order, deduplicated.
            let _ = name;
            let mut seen: Vec<String> = Vec::new();
            for list in &lists {
                if let Some(t) = list.first() {
                    if !seen.iter().any(|n| n == &t.name) {
                        seen.push(t.name.clone());
                    }
                }
            }
            return Err(type_error(format!(
                "Cannot create a consistent method resolution order (MRO) for bases {}",
                seen.join(", ")
            )));
        };
        merged.push(c.clone());
        for list in &mut lists {
            if let Some(h) = list.first() {
                if Rc::ptr_eq(h, &c) {
                    list.remove(0);
                }
            }
        }
    }
    Ok(merged)
}

/// The stable, layout-faithful C "inline body" a C-extension instance
/// owns once it has crossed into an extension that reads its fields at
/// fixed offsets (RFC 0045, wave 3). Holds the body pointer as a
/// `usize` (`0` = no body). `Send + Sync` because the underlying
/// [`Cell`] is.
///
/// **Excluded from the structural clone of [`PyInstance`].** A cloned
/// instance is a *distinct* object that owns no body — most importantly
/// the wave-2 finalizer-resurrection net (`PyInstance::drop`) shallow-
/// copies a dying instance, and duplicating the raw body pointer there
/// would double-free it. `Clone` therefore yields the empty state; the
/// freshly-cloned instance lazily mints its own body if it ever crosses
/// into C again.
#[derive(Debug, Default)]
pub struct CBody(Cell<usize>);

impl CBody {
    /// The body pointer (`0` when the instance has no faithful body).
    #[inline]
    pub fn get(&self) -> usize {
        self.0.get()
    }
    /// Record the body pointer this instance now owns.
    #[inline]
    pub fn set(&self, p: usize) {
        self.0.set(p);
    }
}

impl Clone for CBody {
    fn clone(&self) -> Self {
        CBody(Cell::new(0))
    }
}

/// Process-global hook that frees a C-extension instance's faithful
/// inline body. Registered once by `weavepy-capi` at interpreter init
/// (the same additive-hook pattern wave 2 used for
/// `register_traverse`/`register_clear`); inert in a pure-VM build, so a
/// run with no C extension loaded is byte-for-byte unchanged.
static INSTANCE_BODY_FREE: std::sync::OnceLock<fn(usize)> = std::sync::OnceLock::new();

/// Register the faithful-instance-body free hook (RFC 0045, wave 3).
/// Idempotent — a second registration is ignored.
pub fn register_instance_body_free(f: fn(usize)) {
    let _ = INSTANCE_BODY_FREE.set(f);
}

/// Slot values stored separately from an instance's `__dict__`.
///
/// Empty and single-slot instances need no dictionary allocation. A
/// second distinct slot promotes to a small ordered vector; the ninth
/// promotes to the same ordered table used by larger instances. Rust can
/// place the single-entry payload in the table representation's unused niche
/// without enlarging the field on 64-bit targets. Smaller targets retain
/// ordinary table storage.
#[cfg(target_pointer_width = "64")]
#[derive(Debug, Clone)]
pub struct SlotStorage {
    data: SlotData,
}

#[cfg(target_pointer_width = "64")]
#[derive(Debug, Clone)]
enum SlotData {
    Single { key: Option<DictKey>, value: Object },
    Small(Vec<(DictKey, Object)>),
    Many(DictData),
}

#[cfg(target_pointer_width = "64")]
impl Default for SlotStorage {
    fn default() -> Self {
        Self {
            data: SlotData::Single {
                key: None,
                value: Object::None,
            },
        }
    }
}

#[cfg(target_pointer_width = "64")]
impl SlotStorage {
    /// The current ordered position of a populated slot. Positions can
    /// change after deletion or differ between instances of the same class.
    pub fn index_of(&self, name: &str) -> Option<u32> {
        match &self.data {
            SlotData::Single { .. } => self.get(name).map(|_| 0),
            SlotData::Small(entries) => entries
                .iter()
                .position(
                    |(key, _)| matches!(&key.0, Object::Str(stored) if stored.as_ref() == name),
                )
                .map(|index| index as u32),
            SlotData::Many(table) => table
                .get_index_of(&crate::object::StrKey(name))
                .and_then(|index| u32::try_from(index).ok()),
        }
    }

    /// Read an ordered entry. Callers caching an index must also validate
    /// its key; the class identity alone does not determine slot order.
    #[inline]
    pub fn get_index(&self, index: usize) -> Option<(&DictKey, &Object)> {
        match &self.data {
            SlotData::Single { key, value } if index == 0 => key.as_ref().map(|key| (key, value)),
            SlotData::Small(entries) => entries.get(index).map(|(key, value)| (key, value)),
            SlotData::Many(table) => table.get_index(index),
            _ => None,
        }
    }

    #[inline]
    pub fn get_index_mut(&mut self, index: usize) -> Option<(&DictKey, &mut Object)> {
        match &mut self.data {
            SlotData::Single { key, value } if index == 0 => key.as_ref().map(|key| (key, value)),
            SlotData::Small(entries) => entries.get_mut(index).map(|(key, value)| (&*key, value)),
            SlotData::Many(table) => table.get_index_mut(index),
            _ => None,
        }
    }

    pub fn get(&self, name: &str) -> Option<&Object> {
        match &self.data {
            SlotData::Single {
                key: Some(DictKey(Object::Str(stored))),
                value,
            } if stored.as_ref() == name => Some(value),
            SlotData::Small(entries) => entries.iter().find_map(|(key, value)| {
                matches!(&key.0, Object::Str(stored) if stored.as_ref() == name).then_some(value)
            }),
            SlotData::Many(table) => table.get(&crate::object::StrKey(name)),
            _ => None,
        }
    }

    pub fn insert(&mut self, name: &str, value: Object) -> Option<Object> {
        self.insert_with_key(name, value, || {
            DictKey(Object::Str(crate::shared_value::SharedStr::from(name)))
        })
    }

    /// Reuse an existing name allocation when populating a new slot.
    /// Updating a populated slot keeps its original key allocation.
    pub fn insert_shared(
        &mut self,
        name: &crate::shared_value::SharedStr,
        value: Object,
    ) -> Option<Object> {
        self.insert_with_key(name, value, || DictKey(Object::Str(name.clone())))
    }

    fn insert_with_key(
        &mut self,
        name: &str,
        value: Object,
        make_key: impl FnOnce() -> DictKey,
    ) -> Option<Object> {
        match &mut self.data {
            SlotData::Single { key, value: slot } if key.is_none() => {
                *key = Some(make_key());
                *slot = value;
                return None;
            }
            SlotData::Single {
                key: Some(DictKey(Object::Str(stored))),
                value: slot,
            } if stored.as_ref() == name => return Some(std::mem::replace(slot, value)),
            SlotData::Small(entries) => {
                if let Some((_, slot)) = entries.iter_mut().find(
                    |(key, _)| matches!(&key.0, Object::Str(stored) if stored.as_ref() == name),
                ) {
                    return Some(std::mem::replace(slot, value));
                }
                if entries.len() < 8 {
                    entries.push((make_key(), value));
                    return None;
                }
            }
            SlotData::Many(table) => {
                // Updating a populated slot keeps its existing key allocation.
                if let Some(slot) = table.get_mut(&crate::object::StrKey(name)) {
                    return Some(std::mem::replace(slot, value));
                }
                table.insert(make_key(), value);
                return None;
            }
            _ => {}
        }
        self.data = match std::mem::take(self).data {
            SlotData::Single {
                key: Some(key),
                value: previous,
            } => SlotData::Small(vec![(key, previous), (make_key(), value)]),
            SlotData::Small(entries) => {
                let mut table = DictData::with_capacity_and_hasher(
                    entries.len() + 1,
                    crate::fasthash::FxBuildHasher,
                );
                for (key, previous) in entries {
                    table.insert(key, previous);
                }
                table.insert(make_key(), value);
                SlotData::Many(table)
            }
            _ => unreachable!("only populated single or small slots need promotion"),
        };
        None
    }

    pub fn remove(&mut self, name: &str) -> Option<Object> {
        match &mut self.data {
            SlotData::Single { key, value } if matches!(key.as_ref(), Some(DictKey(Object::Str(stored))) if stored.as_ref() == name) =>
            {
                *key = None;
                Some(std::mem::replace(value, Object::None))
            }
            SlotData::Small(entries) => entries
                .iter()
                .position(
                    |(key, _)| matches!(&key.0, Object::Str(stored) if stored.as_ref() == name),
                )
                .map(|index| entries.remove(index).1),
            SlotData::Many(table) => table.shift_remove(&crate::object::StrKey(name)),
            _ => None,
        }
    }

    pub fn iter(&self) -> impl Iterator<Item = (&DictKey, &Object)> {
        let (single, small, many) = match &self.data {
            SlotData::Single { key, value } => (key.as_ref().map(|key| (key, value)), None, None),
            SlotData::Small(entries) => (None, Some(entries), None),
            SlotData::Many(table) => (None, None, Some(table)),
        };
        single
            .into_iter()
            .chain(small.into_iter().flatten().map(|(key, value)| (key, value)))
            .chain(many.into_iter().flat_map(|table| table.iter()))
    }
}

/// Slot storage for targets where an inline object pair would enlarge
/// every instance. An empty table allocates no backing storage.
#[cfg(not(target_pointer_width = "64"))]
#[derive(Debug, Clone, Default)]
pub struct SlotStorage(DictData);

#[cfg(not(target_pointer_width = "64"))]
impl SlotStorage {
    pub fn index_of(&self, name: &str) -> Option<u32> {
        self.0
            .get_index_of(&crate::object::StrKey(name))
            .and_then(|index| u32::try_from(index).ok())
    }

    #[inline]
    pub fn get_index(&self, index: usize) -> Option<(&DictKey, &Object)> {
        self.0.get_index(index)
    }

    #[inline]
    pub fn get_index_mut(&mut self, index: usize) -> Option<(&DictKey, &mut Object)> {
        self.0.get_index_mut(index)
    }

    pub fn get(&self, name: &str) -> Option<&Object> {
        self.0.get(&crate::object::StrKey(name))
    }

    pub fn insert(&mut self, name: &str, value: Object) -> Option<Object> {
        self.insert_with_key(name, value, || {
            DictKey(Object::Str(crate::shared_value::SharedStr::from(name)))
        })
    }

    /// Share the name allocation only for a newly populated slot.
    pub fn insert_shared(
        &mut self,
        name: &crate::shared_value::SharedStr,
        value: Object,
    ) -> Option<Object> {
        self.insert_with_key(name, value, || DictKey(Object::Str(name.clone())))
    }

    fn insert_with_key(
        &mut self,
        name: &str,
        value: Object,
        make_key: impl FnOnce() -> DictKey,
    ) -> Option<Object> {
        if let Some(slot) = self.0.get_mut(&crate::object::StrKey(name)) {
            return Some(std::mem::replace(slot, value));
        }
        self.0.insert(make_key(), value)
    }

    pub fn remove(&mut self, name: &str) -> Option<Object> {
        self.0.shift_remove(&crate::object::StrKey(name))
    }

    pub fn iter(&self) -> impl Iterator<Item = (&DictKey, &Object)> {
        self.0.iter()
    }
}

/// An instance of a user-defined class.
///
/// `dict` mirrors CPython's `__dict__` — attribute writes land here
/// directly without descriptor checks (the slice doesn't have data
/// descriptors yet; see RFC 0010).
#[derive(Debug, Clone)]
pub struct PyInstance {
    /// The instance's type. Interior-mutable because Python permits
    /// `obj.__class__ = OtherClass` for layout-compatible heap types;
    /// read through [`PyInstance::cls`].
    pub class: RefCell<Rc<TypeObject>>,
    /// Instance attributes, allocated on the first write or exported handle.
    /// Reads through `get()` preserve the absence of an unused dictionary.
    pub dict: crate::sync::LazyArc<RefCell<DictData>>,
    /// For instances of a subclass of an immutable built-in
    /// (`int`, `str`, `float`, `bytes`, `tuple`, …) this holds the
    /// underlying primitive value the instance *is* — the moral
    /// equivalent of CPython storing the C-level value in the object
    /// struct. Unset for ordinary objects. Set once — normally at
    /// construction (the wrapped builtins are themselves immutable), or
    /// on the first C-boundary crossing for a faithful C-built subtype
    /// body (numpy's `str_`/`bytes_`, whose value is stamped into the
    /// inline body by the extension's `tp_new` chain after allocation).
    /// Unwrapped by the numeric / comparison / hashing / conversion
    /// fast paths so e.g. `class C(int)` instances behave like real ints.
    pub native: std::sync::OnceLock<Object>,
    /// Mirrors CPython 3.13's "inline values" state observable through
    /// `_testinternalcapi.has_inline_values`: starts `true` and is
    /// permanently cleared when the instance's `__dict__` is deleted or
    /// replaced wholesale (`del obj.__dict__` / `obj.__dict__ = d`).
    /// The capacity-overflow half of the state (too many attributes)
    /// is computed at query time from the dict size.
    pub inline_values: Cell<bool>,
    /// `__slots__` storage. CPython lays slot values out as C struct
    /// members *outside* the instance `__dict__`; we mirror that
    /// separation with a side table so `vars(obj)` never exposes slot
    /// values and `object.__getstate__` can report them separately.
    /// Empty and single-slot storage stays inline; two to eight slots
    /// use an ordered vector, and larger instances use an ordered table.
    pub slots: RefCell<SlotStorage>,
    /// Memoised Python `__hash__` result, populated lazily *only* for
    /// instances that wrap an **immutable** builtin value (an `int`/`str`/
    /// `tuple`/… subclass). Such an instance's value can't change, so its
    /// `__hash__` is genuinely constant and may be cached — which is what
    /// lets CPython's hash-table reuse (`set(dict)`, `dict.fromkeys(set)`,
    /// …) observe exactly one `__hash__` call per element
    /// (`test_set`/`test_dict` `test_do_not_rehash_dict_keys`). A plain
    /// `object` subclass with a side-effecting or conditionally-raising
    /// `__hash__` (test_dict's `BadHash`) wraps no native value and is
    /// never cached here, so it is re-invoked on every probe like CPython.
    pub hash_cache: crate::sync::CachedHash,
    /// One-shot "has `__del__` already run for this instance?" guard,
    /// mirroring [`crate::object::PyGenerator::finalize_ran`] and CPython's
    /// `_PyGC_FINALIZED` bit. Set by `Vm::invoke_finalizer` the moment the
    /// finalizer is dispatched; read by [`PyInstance`]'s `Drop` to decide
    /// whether the dying instance still needs its `__del__` resurrected onto
    /// the pending-finalizer queue. Without this, an acyclic finalizable
    /// instance whose last `Arc` is dropped on a code path that *didn't*
    /// route through the prompt-reap cascade (e.g. a cross-thread handoff
    /// where a transient clone briefly inflated the refcount so the reap
    /// bailed) is freed silently, skipping `__del__` (RFC 0040:
    /// `test_multiprocessing_*` `test_release_task_refs` leaked one
    /// `CountedObject` per race).
    pub finalize_ran: Cell<bool>,
    /// The stable C "inline body" this instance owns once it has crossed
    /// into a C extension that reads its fields at fixed `tp_basicsize`
    /// offsets (RFC 0045, wave 3). `0` for the overwhelmingly common case
    /// (pure-Python instances, and C instances that store state in
    /// `__dict__`). Freed exactly once, in [`PyInstance`]'s `Drop`, via
    /// the [`register_instance_body_free`] hook.
    pub c_body: CBody,
}

impl PyInstance {
    pub fn new(class: Rc<TypeObject>) -> Self {
        Self {
            class: RefCell::new(class),
            dict: crate::sync::LazyArc::new(),
            native: std::sync::OnceLock::new(),
            inline_values: Cell::new(true),
            slots: RefCell::new(SlotStorage::default()),
            hash_cache: crate::sync::CachedHash::new(None),
            finalize_ran: Cell::new(false),
            c_body: CBody::default(),
        }
    }

    /// Build an instance that wraps a primitive `native` value
    /// (subclass of `int`/`str`/…).
    pub fn with_native(class: Rc<TypeObject>, native: Object) -> Self {
        Self {
            class: RefCell::new(class),
            dict: crate::sync::LazyArc::new(),
            native: std::sync::OnceLock::from(native),
            inline_values: Cell::new(true),
            slots: RefCell::new(SlotStorage::default()),
            hash_cache: crate::sync::CachedHash::new(None),
            finalize_ran: Cell::new(false),
            c_body: CBody::default(),
        }
    }

    /// The instance's current class (honours `__class__` assignment).
    #[inline]
    pub fn cls(&self) -> Rc<TypeObject> {
        self.class.borrow().clone()
    }

    /// Re-point the instance at a new class (`obj.__class__ = C`).
    pub fn set_cls(&self, class: Rc<TypeObject>) {
        *self.class.borrow_mut() = class;
    }

    /// Read slot `name` from the side table (a `__slots__` member).
    /// Keys in the side table are always plain `Str` (only `slot_set`
    /// writes it), so the allocation-free probe is authoritative.
    pub fn slot_get(&self, name: &str) -> Option<Object> {
        self.slots.borrow().get(name).cloned()
    }

    /// Write slot `name` into the side table.
    pub fn slot_set(&self, name: &str, value: Object) {
        self.slots.borrow_mut().insert(name, value);
    }

    /// Delete slot `name` from the side table; `false` when unset.
    pub fn slot_del(&self, name: &str) -> bool {
        self.slots.borrow_mut().remove(name).is_some()
    }

    /// Snapshot of the populated slot values (for `__getstate__`,
    /// `copy`, and GC tracing).
    pub fn slots_snapshot(&self) -> Vec<(String, Object)> {
        self.slots
            .borrow()
            .iter()
            .filter_map(|(k, v)| match &k.0 {
                Object::Str(name) => Some((name.to_string(), v.clone())),
                _ => None,
            })
            .collect()
    }
}

impl Drop for PyInstance {
    /// Last-resort finalizer safety net, mirroring
    /// [`crate::object::PyGenerator`]'s `Drop`. WeavePy normally runs an
    /// instance's `__del__` through the prompt-reap cascade the instant its
    /// last program reference is dropped (matching CPython's refcount
    /// timing). But that cascade is driven from specific eval-loop sites and
    /// is gated on a refcount-dead test; when the final `Arc` is released
    /// somewhere else — most often a cross-thread object handoff where a
    /// transient clone on another thread briefly inflated the strong count so
    /// the reap conservatively bailed — the instance would otherwise be freed
    /// by a plain `Arc` drop with its `__del__` silently skipped (the cycle
    /// collector never revisits acyclic objects). Catch that here: resurrect
    /// a shallow copy that shares the dying instance's `__dict__`/slots/native
    /// value onto the VM's pending-finalizer queue so `__del__` still runs.
    fn drop(&mut self) {
        if crate::hot_gates::env_flags::reap_trace() {
            let name = self.cls().name.clone();
            if name.contains("Block") || name.contains("DataFrame") {
                eprintln!("[INST-DROP] {name} body={:#x}", self.c_body.get());
            }
        }
        // RFC 0045 (wave 3): release the faithful C inline body this
        // instance owns, if it ever crossed into a C extension that reads
        // its fields at fixed `tp_basicsize` offsets. Runs before the
        // finalizer net (and its early returns) so the body is freed
        // exactly once regardless of `__del__` state. Inert (one `Cell`
        // read) for every instance that never grew a body — i.e. all
        // pure-Python instances and all dict-backed C instances.
        let body = self.c_body.get();
        if body != 0 {
            self.c_body.set(0);
            if let Some(free) = INSTANCE_BODY_FREE.get() {
                free(body);
            }
        }
        // Already finalized (cascade/GC/this net's resurrected copy): the
        // common case for finalizable instances and the *only* path for the
        // overwhelmingly common finalizer-free instance — a single `Cell`
        // read keeps the hot drop path cheap.
        if self.finalize_ran.get() {
            return;
        }
        // No `__del__` anywhere in the MRO ⇒ nothing to do. Cached on the
        // type, so this is one more `Cell` read after the first instance.
        if !self.cls().instances_need_finalize() {
            return;
        }
        // CPython runs `tp_finalize` once: claim it so the resurrected copy
        // (and any re-drop after the finalizer completes) can't loop.
        self.finalize_ran.set(true);
        // Can't run Python from `Drop`; resurrect onto the pending queue. The
        // copy shares `dict`/`slots`/`native` (cloning the `Arc`s/contents),
        // so `__del__` observes the same attributes; `try_*` tolerates TLS
        // teardown and re-entrant borrows by dropping the request.
        let resurrected = Object::Instance(Rc::new(PyInstance {
            class: RefCell::new(self.cls()),
            dict: self.dict.clone(),
            native: match self.native.get() {
                Some(v) => std::sync::OnceLock::from(v.clone()),
                None => std::sync::OnceLock::new(),
            },
            inline_values: Cell::new(self.inline_values.get()),
            slots: RefCell::new(self.slots.borrow().clone()),
            hash_cache: crate::sync::CachedHash::new(self.hash_cache.get()),
            finalize_ran: Cell::new(true),
            // The resurrected copy is a distinct object that owns no C
            // body (the dying `self` already freed its own above).
            c_body: CBody::default(),
        }));
        crate::vm_singletons::try_push_pending_finalizer(resurrected);
    }
}

#[cfg(all(test, target_pointer_width = "64"))]
mod slot_storage_tests {
    use super::*;

    #[test]
    fn shared_slot_names_survive_promotion_and_release_with_their_owners() {
        let names: Vec<crate::shared_value::SharedStr> = (0..16)
            .map(|i| crate::shared_value::SharedStr::from(format!("slot{i}")))
            .collect();
        let mut first = SlotStorage::default();
        let mut second = SlotStorage::default();
        for (i, name) in names.iter().enumerate() {
            first.insert_shared(name, Object::Int(i as i64));
            second.insert_shared(name, Object::None);
            assert_eq!(crate::shared_value::SharedStr::strong_count(name), 3);
            for slots in [&first, &second] {
                let (key, _) = slots.get_index(i).unwrap();
                let Object::Str(stored) = &key.0 else {
                    panic!("slot key must be a string");
                };
                assert!(crate::shared_value::SharedStr::ptr_eq(stored, name));
            }
        }
        let replacement: crate::shared_value::SharedStr =
            crate::shared_value::SharedStr::from("slot5");
        assert_eq!(
            first
                .insert_shared(&replacement, Object::Int(100))
                .and_then(|v| v.as_i64()),
            Some(5)
        );
        assert_eq!(
            crate::shared_value::SharedStr::strong_count(&replacement),
            1
        );
        assert_eq!(crate::shared_value::SharedStr::strong_count(&names[5]), 3);
        first.remove("slot5");
        first.insert_shared(&replacement, Object::Int(200));
        assert_eq!(first.index_of("slot5"), Some(15));
        assert_eq!(crate::shared_value::SharedStr::strong_count(&names[5]), 2);
        assert_eq!(
            crate::shared_value::SharedStr::strong_count(&replacement),
            2
        );
        let cloned = first.clone();
        assert_eq!(
            crate::shared_value::SharedStr::strong_count(&replacement),
            3
        );
        drop(first);
        assert_eq!(cloned.get("slot5").and_then(Object::as_i64), Some(200));
        drop(cloned);
        drop(second);
        assert!(names
            .iter()
            .all(|name| crate::shared_value::SharedStr::strong_count(name) == 1));
        assert_eq!(
            crate::shared_value::SharedStr::strong_count(&replacement),
            1
        );
    }

    #[test]
    fn existing_slots_do_not_request_a_replacement_key() {
        let mut slots = SlotStorage::default();
        for i in 0..16 {
            let name = format!("slot{i}");
            slots.insert(&name, Object::Int(i));
            assert_eq!(
                slots
                    .insert_with_key(&name, Object::None, || {
                        panic!("updating a populated slot must not construct a key")
                    })
                    .and_then(|v| v.as_i64()),
                Some(i)
            );
        }
    }

    #[test]
    fn inline_slot_storage_does_not_enlarge_instances() {
        assert!(
            std::mem::size_of::<RefCell<SlotStorage>>()
                <= std::mem::size_of::<RefCell<Option<DictData>>>()
        );
    }

    #[test]
    fn single_slot_replaces_deletes_and_reuses_inline_storage() {
        let mut slots = SlotStorage::default();
        assert_eq!(slots.iter().count(), 0);
        assert!(slots.get("value").is_none());
        assert!(slots.insert("value", Object::Int(1)).is_none());
        assert_eq!(slots.get("value").and_then(Object::as_i64), Some(1));
        assert_eq!(
            slots
                .insert("value", Object::Int(2))
                .and_then(|v| v.as_i64()),
            Some(1)
        );
        assert!(matches!(slots.data, SlotData::Single { .. }));
        assert!(slots.remove("missing").is_none());
        assert_eq!(slots.remove("value").and_then(|v| v.as_i64()), Some(2));
        assert_eq!(slots.iter().count(), 0);
        assert!(slots.insert("α", Object::None).is_none());
        assert!(matches!(slots.get("α"), Some(Object::None)));
        assert_eq!(slots.iter().count(), 1);
        assert!(matches!(slots.data, SlotData::Single { .. }));
    }

    #[test]
    fn ninth_slot_promotes_without_replacing_existing_keys() {
        let mut slots = SlotStorage::default();
        let mut keys = Vec::new();
        for i in 0..16 {
            let name = format!("slot{i}");
            assert!(slots.insert(&name, Object::Int(i)).is_none());
            keys.push(slots.iter().last().unwrap().0 .0.clone());
            match i {
                0 => assert!(matches!(slots.data, SlotData::Single { .. })),
                1..=7 => assert!(matches!(slots.data, SlotData::Small(_))),
                _ => assert!(matches!(slots.data, SlotData::Many(_))),
            }
            for (index, (key, value)) in slots.iter().enumerate() {
                assert!(key.0.is_same(&keys[index]));
                assert_eq!(value.as_i64(), Some(index as i64));
            }
        }
        let mut cloned = slots.clone();
        for i in (0..16).rev() {
            let name = format!("slot{i}");
            assert_eq!(slots.remove(&name).and_then(|v| v.as_i64()), Some(i));
            assert!(slots.get(&name).is_none());
            assert_eq!(cloned.get(&name).and_then(Object::as_i64), Some(i));
        }
        assert_eq!(slots.iter().count(), 0);
        cloned.insert("slot0", Object::None);
        assert!(matches!(cloned.get("slot0"), Some(Object::None)));
    }

    #[test]
    fn small_vector_preserves_order_after_removal() {
        let mut slots = SlotStorage::default();
        for name in [
            "one", "two", "three", "four", "five", "six", "seven", "eight",
        ] {
            slots.insert(name, Object::None);
        }
        assert!(matches!(&slots.data, SlotData::Small(entries) if entries.len() == 8));
        assert!(slots.remove("two").is_some());
        slots.insert("α", Object::Int(9));
        assert!(matches!(&slots.data, SlotData::Small(entries) if entries.len() == 8));
        assert!(
            matches!(&slots.iter().last().unwrap().0 .0, Object::Str(name) if name.as_ref() == "α")
        );
        let mut cloned = slots.clone();
        cloned.insert("α", Object::Int(10));
        assert_eq!(slots.get("α").and_then(Object::as_i64), Some(9));
        assert_eq!(cloned.get("α").and_then(Object::as_i64), Some(10));
    }

    #[test]
    fn ordered_slot_indices_track_promotions_and_removals() {
        let mut slots = SlotStorage::default();
        assert!(slots.get_index(0).is_none());
        assert!(slots.get_index_mut(usize::MAX).is_none());
        for i in 0..16 {
            let name = format!("slot{i}");
            slots.insert(&name, Object::Int(i));
            assert_eq!(slots.index_of(&name), Some(i as u32));
            assert_eq!(slots.get_index(i as usize).unwrap().1.as_i64(), Some(i));
        }
        for i in (0..16).step_by(2) {
            slots.remove(&format!("slot{i}"));
        }
        for index in 0..8 {
            let name = format!("slot{}", 2 * index + 1);
            assert_eq!(slots.index_of(&name), Some(index));
            let (key, value) = slots.get_index_mut(index as usize).unwrap();
            assert!(matches!(&key.0, Object::Str(stored) if stored.as_ref() == name));
            *value = Object::Int(100 + i64::from(index));
            assert_eq!(
                slots.get(&name).and_then(Object::as_i64),
                Some(100 + i64::from(index))
            );
        }
        assert!(slots.index_of("slot0").is_none());
        slots.insert("slot0", Object::Int(900));
        assert_eq!(slots.index_of("slot0"), Some(8));
        assert!(slots.get_index(9).is_none());
    }

    #[test]
    fn promotion_preserves_keys_order_and_independent_clones() {
        let mut slots = SlotStorage::default();
        slots.insert("first", Object::Int(1));
        let original_key = slots.iter().next().unwrap().0 .0.clone();
        slots.insert("second", Object::Int(2));
        assert!(matches!(slots.data, SlotData::Small(_)));
        assert!(slots.iter().next().unwrap().0 .0.is_same(&original_key));
        let names = |slots: &SlotStorage| {
            slots
                .iter()
                .map(|(key, _)| match &key.0 {
                    Object::Str(name) => name.to_string(),
                    _ => panic!("slot key must be a string"),
                })
                .collect::<Vec<_>>()
        };
        assert_eq!(names(&slots), ["first", "second"]);
        slots.insert("first", Object::Int(3));
        assert_eq!(names(&slots), ["first", "second"]);
        slots.remove("first");
        slots.insert("first", Object::Int(4));
        assert_eq!(names(&slots), ["second", "first"]);
        let mut cloned = slots.clone();
        cloned.insert("first", Object::Int(5));
        assert_eq!(slots.get("first").and_then(Object::as_i64), Some(4));
        assert_eq!(cloned.get("first").and_then(Object::as_i64), Some(5));
    }
}

"""Require completed shell-cache validation and unchanged measurement identities."""
from pathlib import Path
import hashlib,json,re

def read(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
for group in read('target/native-unobserved-shell-prebuild.json').values():
    for path,digest in group.items():assert sha(path)==digest,path
env=read('target/native-unobserved-shell-source-snapshot/environment.json')
for label in ['new','previous']:
    item=env['binaries'][label];assert sha(item['path'])==item['sha256'],label
assert env['binaries']['previous']['sha256']=='681043b9f62cbd4fdb3f73756ecdf8ac877c1923b6a509f11ff1128dc973443c'
assert sha('target/release/weavepy-runtime-thin-value-storage')=='bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'
vm=Path('target/native-unobserved-shell-vm-tests-02.txt').read_text()
assert 'test result: ok. 353 passed' in vm
counts=list(map(int,re.search(r'native shell allocation/reuse/exclusion counts: \[(\d+), (\d+), (\d+)\]',vm).groups()))
assert counts[0]>0 and counts[1]>=100 and counts[2]>=10,counts
assert 'activation_shell_reuse_excludes_strong_weak_and_frame_observers ... ok' in vm
text=Path('target/native-unobserved-shell-capi-tests-02.txt').read_text()
assert 'test result: FAILED' not in text
assert sum(map(int,re.findall(r'test result: ok\. (\d+) passed',text)))==156
for label in ['clippy-02','nojit-check-02']:assert 'Finished' in Path(f'target/native-unobserved-shell-{label}.txt').read_text()
expected='native activation shell reuse: semantics and ownership ok\n'
oracles=read('target/native-unobserved-shell-baseline-oracles/report.json')
assert sha('tests/regrtest/test_native_activation_shell_reuse.py')==oracles['source_sha256']
assert len(oracles['variants'])==4
assert all(r['returncode']==0 and r['stdout']==expected for r in oracles['variants'].values())
assert Path('target/native-unobserved-shell-check-stage.txt').read_text().strip()=='done'
checks=Path('target/native-unobserved-shell-checks')
for mode in ['jit','interp','gil0']:
    assert len(list(checks.glob(f'*-{mode}.txt')))==33
    assert (checks/f'test_native_activation_shell_reuse-{mode}.txt').read_text()==expected
validation=read('target/native-unobserved-shell-validation/validation.json')
assert len(validation)==275 and all(r['passed'] for r in validation)
assert (checks/'native-format-coverage.txt').read_text()=='native formatter active\n'
for folder in ['target/native-unobserved-shell-baseline-coverage-v2','target/native-unobserved-shell-checks/fixture-coverage']:
    coverage=read(folder+'/report.json');assert len(coverage['rows'])==29
    for name,row in coverage['rows'].items():
        assert row['returncode']==0
        generic=name.startswith(('generic_pos_','generic_kw_','generic_method_','generic_object_')) and name not in ['generic_pos_32','generic_object_4']
        if generic or name.startswith('native_'):
            assert row['bench_compiled'] and row['stats']['generic dyn calls']>=30000,(folder,name)
        if name.startswith('compiled_alias_') or name in ['native_single_callback','native_recursive_callback']:
            assert row['bench_compiled'] and row['stats']['native-to-native calls']>=30000,(folder,name)
        if name=='native_single_callback':assert row['single_compiled']
        if name=='native_recursive_callback':assert 'jit compile "descend"' in Path(folder,name+'.trace.txt').read_text()
identity=read(checks/'frame-identity/report.json')
assert len(identity['variants'])==5
for label,row in identity['variants'].items():
    assert row['returncode']==0
    assert row['result']=={'frames':5,'same':label not in ['previous-jit','new-jit'],'names':['driver']*5}
    if label.endswith('-jit'):assert row['driver_compiled'] and not row['driver_deopts']
codegen=read('target/native-unobserved-shell-codegen/report.json')
assert codegen['variants']['new']['sha256']==env['binaries']['new']['sha256']
print('All source/method identities, 353 VM tests, 156 C API tests, 99 targeted checks, 275 compatibility checks, and 29 fixture paths verified.')

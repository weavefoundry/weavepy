"""Require complete validation and unchanged binary, source, and method identities."""
import hashlib
import json
from pathlib import Path

def read(name):
    return json.loads(Path(name).read_text())

for group in read('target/niche-string-owner-prebuild.json').values():
    for name, digest in group.items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
env = read('target/niche-string-owner-source-snapshot/environment.json')
for label in ['new', 'previous']:
    value = env['binaries'][label]
    assert hashlib.sha256(Path(value['path']).read_bytes()).hexdigest() == value['sha256'], label
assert hashlib.sha256(Path('target/release/weavepy-runtime-thin-value-storage').read_bytes()).hexdigest() == 'bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'
validation = read('target/niche-string-owner-validation/validation.json')
assert len(validation) == 275 and all(r['passed'] for r in validation)
assert read('target/niche-string-owner-extra-checks/report.json')['status'] == 'passed'
assert Path('target/niche-string-owner-check-stage.txt').read_text().strip() == 'done'
assert 'test result: ok. 353 passed' in Path('target/niche-string-owner-vm-tests-01.txt').read_text()
assert 'test result: ok. 34 passed' in Path('target/niche-string-owner-capi-tests-01.txt').read_text()
assert 'test result: FAILED' not in Path('target/niche-string-owner-capi-tests-01.txt').read_text()
for arch in ['arm64', 'i686']:
    assert 'test result: ok. 14 passed' in Path(f'target/niche-string-owner-integrated-miri-{arch}-01.txt').read_text()
for name in ['clippy-01', 'nojit-check']:
    assert 'Finished' in Path(f'target/niche-string-owner-{name}.txt').read_text()
layout = read('target/niche-string-owner-layout.json')
assert all(layout[k] == 16 for k in ['Object', 'Option<Object>', 'DictKey', 'SharedStr'])
assert all(layout[k] == 8 for k in ['SharedSlice<u8>', 'SharedSlice<u32>', 'SharedTuple'])
print('Unchanged candidate and methods verified; marshal divergences remain explicit.')

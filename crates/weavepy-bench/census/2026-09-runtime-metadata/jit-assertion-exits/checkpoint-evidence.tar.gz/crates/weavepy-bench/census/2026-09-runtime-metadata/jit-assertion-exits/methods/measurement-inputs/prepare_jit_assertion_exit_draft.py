"""Prepare, but don't apply, exact-PC exits for common exception constants."""
import difflib
import hashlib
import json
from pathlib import Path

root = Path("target/jit-assertion-exit-draft")
root.mkdir()
records = {}
patch = ""


def save(path, source, changed):
    global patch
    assert source != changed
    p = Path(path)
    (root / p.name).write_text(changed)
    records[path] = {"base_sha256": hashlib.sha256(source.encode()).hexdigest(),
                     "draft_sha256": hashlib.sha256(changed.encode()).hexdigest()}
    patch += "".join(difflib.unified_diff(source.splitlines(True), changed.splitlines(True),
                                        fromfile="a/" + path, tofile="b/" + path))


path = "crates/weavepy-jit/src/analyze.rs"
source = Path(path).read_text()
s = source
old = "/// Build the basic blocks, resolving relative jumps to absolute indices."
new = '''/// The interpreter materializes canonical exception classes at these exits.
/// Other common constants retain their existing analysis and fallback behavior.
fn common_error_constant(ins: weavepy_compiler::Instruction) -> bool {
    use weavepy_compiler::bytecode::{
        COMMON_CONSTANT_ASSERTION_ERROR, COMMON_CONSTANT_NOT_IMPLEMENTED_ERROR,
    };
    ins.op == OpCode::LoadCommonConstant
        && matches!(
            ins.arg,
            COMMON_CONSTANT_ASSERTION_ERROR | COMMON_CONSTANT_NOT_IMPLEMENTED_ERROR
        )
}

/// Build the basic blocks, resolving relative jumps to absolute indices.'''
assert s.count(old) == 1
s = s.replace(old, new)
old = '''            OpCode::ReturnValue | OpCode::RaiseVarargs if i + 1 < n => {
                leaders.insert(i + 1);
            }'''
new = old + '''
            OpCode::LoadCommonConstant if common_error_constant(*ins) && i + 1 < n => {
                leaders.insert(i + 1);
            }'''
assert s.count(old) == 1
s = s.replace(old, new)
old = "            OpCode::ReturnValue | OpCode::RaiseVarargs => Vec::new(),"
new = old + "\n            OpCode::LoadCommonConstant if common_error_constant(ins) => Vec::new(),"
assert s.count(old) == 1
s = s.replace(old, new)
old = '''        OpCode::RaiseVarargs => {
            if ins.arg > 2 {
                return Err(JitVerdict::UnsupportedOpcode("RAISE_VARARGS (arity)"));
            }
            if stack.len() < ins.arg as usize {
                return Err(JitVerdict::StackUnderflow);
            }'''
new = '''        OpCode::RaiseVarargs | OpCode::LoadCommonConstant
            if ins.op == OpCode::RaiseVarargs || common_error_constant(ins) =>
        {
            if ins.op == OpCode::RaiseVarargs {
                if ins.arg > 2 {
                    return Err(JitVerdict::UnsupportedOpcode("RAISE_VARARGS (arity)"));
                }
                if stack.len() < ins.arg as usize {
                    return Err(JitVerdict::StackUnderflow);
                }
            }'''
assert s.count(old) == 1
s = s.replace(old, new)
old = '''        OpCode::RaiseVarargs => {
            for (index, value) in stack.iter().enumerate() {'''
new = '''        OpCode::RaiseVarargs | OpCode::LoadCommonConstant
            if ins.op == OpCode::RaiseVarargs || common_error_constant(ins) =>
        {
            for (index, value) in stack.iter().enumerate() {'''
assert s.count(old) == 1
s = s.replace(old, new)
s = s.replace("// An admitted explicit raise has no pending call markers: emission", "// An admitted explicit error exit has no pending call markers: emission")
s = s.replace("\"RAISE_VARARGS (operand shape)\"", "\"error exit (operand shape)\"")
save(path, source, s)

path = "crates/weavepy-jit/src/ir.rs"
source = Path(path).read_text()
old = '''    /// Resume interpretation at an explicit raise without consuming its
    /// operands. The interpreter handles chaining, traceback, and handlers.'''
new = '''    /// Resume interpretation at an explicit error operation without consuming
    /// its operands. The interpreter handles construction, chaining, and handlers.'''
assert source.count(old) == 1
save(path, source, source.replace(old, new))

path = "crates/weavepy-jit/tests/frame_coverage.rs"
source = Path(path).read_text()
s = source + '''

#[test]
fn assertions_exit_before_constructing_the_exception_or_message() {
    use weavepy_compiler::OpCode;
    for assertion in [
        "assert n >= 0",
        "assert n >= 0, n",
        "assert n >= 0, f'value: {n}'",
        "assert n >= 0, factory('bad' if n < -1 else 'worse')",
    ] {
        let source = format!("def k(n):\\n    {assertion}\\n    return n + 1\\n");
        let code = compile_first_fn(&source);
        let pc = code.instructions.iter().position(|i| i.op == OpCode::LoadCommonConstant).unwrap();
        let tf = analyze_code_cfg(&code, &Cfg::default()).expect("successful assertion should compile");
        assert!(tf.blocks.iter().any(|b| b.term == TTerm::Deopt { pc: pc as u32 }));
        assert!(tf.blocks.iter().any(|b| b.term == TTerm::Return));
        assert_eq!(tf.ret_lane, Some(JitType::Int));
        for span in &tf.null_spans {
            assert!(!(span.live_from <= pc as u32 && (pc as u32) < span.live_to));
        }
        for span in &tf.callee_spans {
            assert!(!(span.live_from <= pc as u32 && (pc as u32) < span.live_to));
        }
    }
}

#[test]
fn common_constant_exits_are_limited_to_exception_classes() {
    use weavepy_compiler::bytecode::{COMMON_CONSTANT_ASSERTION_ERROR, COMMON_CONSTANT_NOT_IMPLEMENTED_ERROR, COMMON_CONSTANT_TUPLE, COMMON_CONSTANT_ALL, COMMON_CONSTANT_ANY};
    use weavepy_compiler::OpCode;
    for arg in [COMMON_CONSTANT_ASSERTION_ERROR, COMMON_CONSTANT_NOT_IMPLEMENTED_ERROR, COMMON_CONSTANT_TUPLE, COMMON_CONSTANT_ALL, COMMON_CONSTANT_ANY, u32::MAX] {
        let mut code = compile_first_fn("def k(n):\\n    assert n >= 0\\n    return n + 1\\n");
        let ins = code.instructions.iter_mut().find(|i| i.op == OpCode::LoadCommonConstant).unwrap();
        ins.arg = arg;
        let result = analyze_code_cfg(&code, &Cfg::default());
        assert_eq!(result.is_ok(), matches!(arg, COMMON_CONSTANT_ASSERTION_ERROR | COMMON_CONSTANT_NOT_IMPLEMENTED_ERROR), "common constant {arg}");
    }
}
'''
save(path, source, s)
(root / "candidate.patch").write_text(patch)
(root / "index.json").write_text(json.dumps({"status": "Unapplied, unformatted, uncompiled, unvalidated, unmeasured.", "sources": records}, indent=2) + "\n")
(root / "README.md").write_text('''# JIT exits before common exception constants

An untimed CPython-checked datetime trace rejects _ymd2ord, _cmp, and other
functions at LOAD_COMMON_CONSTANT. This draft permits canonical AssertionError
and NotImplementedError constants as exact-PC interpreter exits. The normal
path can compile while exception construction, formatted messages, callbacks,
and handlers execute through the interpreter. All other common constants stay
on their existing unsupported path. This does not implement arbitrary constants
or assert that every affected function will become JITable.

The existing Deopt terminator spills values and locals without consuming the
operation. The existing marker-free operand checks and call-span exclusion apply
to these exits too. Blocks following an exit don't become native successors;
other incoming branches must retain normal reachability. Enclosing loop iterator
and generator state must remain intact. No new native helper or execution policy.

The draft is unapplied and uncompiled. Verify the loop's instruction reference
type when formatting/building; no test has established this implementation yet.
Before applying, finish and archive compact intern-pool measurements. Preflight
Python assertions against CPython and the unchanged predecessor, then verify
message side effects, canonical builtins under shadowing, tracebacks/locals,
causes, cleanup, conditional expressions, loops, handlers, and observability.
Measure never/rare/often/always failures, recovery after an error burst, ordinary
calls, datetime components, startup, and the unchanged full suite in both modes.
No new performance, memory, or universal superiority claim is established.
''')
print("Prepared three-file assertion-exit draft; active runtime unchanged.")

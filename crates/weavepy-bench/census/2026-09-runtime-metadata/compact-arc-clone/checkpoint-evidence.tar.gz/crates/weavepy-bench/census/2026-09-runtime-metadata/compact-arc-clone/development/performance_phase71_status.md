# Direct cloning of compact Arc metadata

Phase70 candidate 65ff is fully measured and archived in the census directory
compact-arc-storage (717 files, 7,312,493 bytes, all hashes verified). Its full
23-workload JIT mean regresses 1.22% versus bf2 and 0.76% versus ed99. Full peak
RSS is 0.64% worse than bf2 and 1.71% better than ed99. Both runs still have six
JIT workload wins against CPython and zero peak-RSS wins. All four gates are
complete. No timing job, build, or validation remains active from phase70.

Current VM/default CLI remains 65ff. Prototype-only follow-up changes cloning
of ordinary inline-metadata owners: Arc::increment_strong_count, then copy the
existing pointer and seven metadata bytes. The indirect path retains standard
Arc cloning and repacking, including separately owned boxes and exact counts.
No VM source is changed yet. Prototype correctness/Miri and generated-code
checks precede integration. Exact shared/tuple preimages are preserved.

The goal remains unachieved. No new commit or push has been made.

## Integration update

Prototype v1 and v2 both pass eight ordinary tests, eight ARM64 Miri tests,
eight i686 Miri tests, and clippy. v1 copies inline metadata after standard
Arc::increment_strong_count, but the generated clone wrapper retains its old
64-byte stack frame. v2 outlines clone_indirect with cold/inline(never), and
the standalone str/byte clone wrapper becomes a leaf ordinary path without
that frame. This is a generated-code observation, not a VM speed result.
All prototype versions, assembly, and source hashes are retained.

v2 is now applied to shared_value.rs only. No allocation layout, tuple header,
weak owner, or Python test was changed. Active validation pipeline session13437
runs VM355, full C API tests, strict lint, no-JIT check, and actual layout.
Session98179 runs exact integrated-module Miri on ARM64 and i686. Both started
after every phase70 timing gate finished. Current release CLI still remains65ff.
Next: prepare a fresh release and the same 27 focused/24 full controls, using
65ff as the direct reference and bf2 as the retained reference; do not infer
new versus ed99 effects from unrelated historical ratios. No timing may start
until owned validations/builds end and all hashes and correctness checks pass.

## Static validation complete, release build next

VM355, C API156, strict clippy, no-JIT check, and exact integrated Miri16 on
both architectures passed without source corrections. Every actual layout
field matches65ff, including Object16 and owners15. Miri report hashes identify
exact integrated modules, stubs, and logs. Fresh build/validation/focused/full
methods are prepared and syntax-checked. build_compact_arc_clone.sh is now
launched; its source freeze must precede release compilation. No timing gate
is active. After build, run targeted checks, then outside-sandbox main validator
and extra suites; close every test/build before launching performance gates.

## Release and Python checks

Release completed in an observed4m02s (not a controlled build-time result).
Binary target/release/weavepy-runtime-compact-arc-clone is44,317,952bytes,
SHA75ea4029cf0b323ab53dfb7015485bfa2803b039779db62ba433fc9332972eb2.
All339 frozen source and77 method/input hashes matched after building.
Targeted87 Python checks passed. Extra bytes/codecs/four C API suites passed;
marshal matches the four expected baseline divergences on new and65ff.
Outside-sandbox standard compatibility validation is active in session76504.
No build or extra-check job remains active. No timing gate has started.

After validation passes275/275, verify_compact_arc_clone_ready.py must pass.
Launch gates outside the sandbox with these fresh names, sequentially:
- compact-arc-clone-focused-previous versus weavepy-runtime-compact-arc-storage;
- compact-arc-clone-full-previous versus the same65ff reference;
- compact-arc-clone-focused-retained versus weavepy-runtime-thin-value-storage;
- compact-arc-clone-full-retained versus the samebf2 reference.
Each uses a matching *-load.json telemetry file. Focused launcher args are
BASE OUTPUT. Full launcher args are FOCUSED OUTPUT BASE. Summarizer accepts
the focused output directory. No owned build/test/profile or runtime/active
harness edit may overlap any gate that can launch or any running measurements.
The older ed99 build and all previous results remain; do not infer new/ed99
performance from products of historical ratios. No commit/push this turn.

## Measurement scheduling incident and correction

The focused comparison against65ff completed cleanly. The full comparison
against65ff overlapped an accidentally launched focused stage againstbf2.
The latter was stopped with exit143; its partial data remains. The original
full stage completed, and both affected outputs are diagnostic only. Incident
JSON retains timing states, timestamps, and stopped owned PIDs. No unrelated
process was stopped, and a process inventory found no remaining measurement
children. Session43070 still needs its completed result collected;72703 isclosed.

Read compact-arc-clone-measurement-correction.md before continuing. A new exclusive
lease wrapper run_serial_performance_gate.py must guard all further stages.
Original source/method hashes remain unchanged; corrected-methods.json hashes
the wrapper and correction separately. Fresh planned sequence: full-previous-
isolated against65ff, focused-retained-isolated againstbf2, full-retained-
isolated againstbf2. Keep affected runs and all replacement samples. Do not
repeat the valid earlier focused run. Inspect completion before every launch.

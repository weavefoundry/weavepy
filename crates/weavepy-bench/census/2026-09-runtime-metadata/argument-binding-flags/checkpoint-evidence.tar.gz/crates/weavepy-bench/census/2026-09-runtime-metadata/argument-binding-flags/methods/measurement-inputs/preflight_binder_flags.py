"""Establish argument-boundary behavior before changing binder flag storage."""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
root=Path('target/argument-binder-flags-baseline-preflight');root.mkdir()
source=Path('target/argument-binder-flags-draft/test_argument_binding_storage.py')
variants=[('cpython',shutil.which('python3.14'),None,[]),('retained','target/release/weavepy-runtime-jit-raise-call-spans','1',[]),('entry_jit','target/release/weavepy-runtime-early-bound-entry','1',[]),('entry_interp','target/release/weavepy-runtime-early-bound-entry','0',[]),('entry_gil0','target/release/weavepy-runtime-early-bound-entry','1',['-X','gil=0'])]
report={'purpose':__doc__,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'rows':{}}
for name,binary,jit,flags in variants:
    env=dict(os.environ)
    for key in ['WEAVEPY_JIT','WEAVEPY_GIL','WEAVEPY_JIT_TRACE','WEAVEPY_VM_STATS','WEAVEPY_JIT_THRESHOLD']:env.pop(key,None)
    digest=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    if jit is not None:
        env.update(WEAVEPY_JIT=jit,WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),WEAVEPY_FROZEN_CACHE=str((root/'frozen'/digest).resolve()))
    result=subprocess.run([binary,*flags,str(source)],env=env,text=True,capture_output=True,timeout=120)
    report['rows'][name]={'binary':binary,'sha256':digest,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(name,result.returncode,result.stdout,result.stderr[-1000:],flush=True)
    assert result.returncode==0,name
assert len({row['stdout'] for row in report['rows'].values()})==1
report['status']='passed';(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')

"""Attribute generic native call sites without collecting performance samples."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

root = Path('target/pickle-special-lookup-individual-calls')
root.mkdir()
fixture = Path('crates/weavepy-bench/fixtures/call_overhead.py')
definitions = fixture.read_text().split('\ndef bench(n):')[0]
shapes = {
    'positional': 'pos2(i, 1)',
    'defaults': 'with_defaults(i)',
    'sparse_keyword': 'with_defaults(i, c=5)',
    'variadic_keyword': 'with_kwargs(i, delta=2)',
    'method': 'c.bump(1)',
    'bound_method': 'bump(1)',
    'builtin': 'len(seq)',
}
binary = Path('target/release/weavepy-runtime-pickle-special-lookup')
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
report = {'purpose': __doc__, 'binary_sha256': digest,
          'fixture_sha256': hashlib.sha256(fixture.read_bytes()).hexdigest(),
          'cases': {}}
for label, expression in shapes.items():
    source = root / (label + '.py')
    source.write_text(definitions + f'''
def bench(n):
    c = Counter()
    bump = c.bump
    total = 0
    seq = (1, 2, 3)
    for i in range(n):
        total += {expression}
    return total

for unused in range(3):
    print(bench(300))
''')
    row = {'expression': expression, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'runs': {}}
    for runtime, executable in [('cpython', shutil.which('python3.14')), ('weavepy', str(binary))]:
        env = dict(os.environ)
        for key in ['WEAVEPY_JIT', 'WEAVEPY_JIT_TRACE', 'WEAVEPY_VM_STATS', 'WEAVEPY_JIT_THRESHOLD']:
            env.pop(key, None)
        if runtime == 'weavepy':
            env.update(WEAVEPY_JIT='1', WEAVEPY_JIT_TRACE='1', WEAVEPY_VM_STATS='1',
                       WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
                       WEAVEPY_FROZEN_CACHE=str((root / 'frozen' / digest).resolve()))
        result = subprocess.run([executable, str(source)], env=env, text=True, capture_output=True, timeout=120)
        trace = root / (label + '-' + runtime + '.trace.txt')
        trace.write_text(result.stderr)
        row['runs'][runtime] = {
            'returncode': result.returncode, 'stdout': result.stdout,
            'trace_sha256': hashlib.sha256(trace.read_bytes()).hexdigest(),
            'compiled': sorted(set(re.findall(r'jit compile "([^"]+)"', result.stderr))),
            'rejections': sorted(set(re.findall(r'jit reject .+', result.stderr))),
            'stats': {k: int(v.replace(',', '')) for k, v in re.findall(r'^- ([^:]+): \*\*([\d,]+)\*\*', result.stderr, re.M)},
        }
        report['cases'][label] = row
        (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
        assert result.returncode == 0, (label, runtime, result.stderr[-3000:])
    assert row['runs']['cpython']['stdout'] == row['runs']['weavepy']['stdout'], label
    print(label, row['runs']['weavepy']['compiled'], row['runs']['weavepy']['stats'], flush=True)
print('All seven shape results match CPython. Coverage only, no timing claims.')

def leaf(a, b=2, c=3, d=4):
    x = a + b
    y = x + c
    z = y + d
    w = z + a
    return w

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(d=5, a=i)
    return total

for unused in range(3):
    print(bench(300))

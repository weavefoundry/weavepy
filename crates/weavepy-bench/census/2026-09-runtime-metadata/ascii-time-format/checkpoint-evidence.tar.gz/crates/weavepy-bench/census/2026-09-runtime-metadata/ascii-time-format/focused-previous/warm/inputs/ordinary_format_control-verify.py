import importlib.util, json
spec = importlib.util.spec_from_file_location('format_control', '/Users/owencarey/Documents/weavefoundry/weavepy/target/ascii-time-format-inputs/warm/ordinary_format_control.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(20000)
for _ in range(6):
    module.bench(64)
last = module.bench(20000)
print(json.dumps(first))
print(json.dumps(last))

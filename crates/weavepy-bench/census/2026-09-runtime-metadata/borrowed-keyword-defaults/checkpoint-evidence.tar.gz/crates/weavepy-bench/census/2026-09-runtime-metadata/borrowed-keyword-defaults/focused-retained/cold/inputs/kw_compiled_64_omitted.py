import os
values = tuple("default-%d-" % i + "shared-text" * 3 for i in range(64))
provided = "provided-" + "string" * 3
def target(*, a0=values[0], a1=values[1], a2=values[2], a3=values[3], a4=values[4], a5=values[5], a6=values[6], a7=values[7], a8=values[8], a9=values[9], a10=values[10], a11=values[11], a12=values[12], a13=values[13], a14=values[14], a15=values[15], a16=values[16], a17=values[17], a18=values[18], a19=values[19], a20=values[20], a21=values[21], a22=values[22], a23=values[23], a24=values[24], a25=values[25], a26=values[26], a27=values[27], a28=values[28], a29=values[29], a30=values[30], a31=values[31], a32=values[32], a33=values[33], a34=values[34], a35=values[35], a36=values[36], a37=values[37], a38=values[38], a39=values[39], a40=values[40], a41=values[41], a42=values[42], a43=values[43], a44=values[44], a45=values[45], a46=values[46], a47=values[47], a48=values[48], a49=values[49], a50=values[50], a51=values[51], a52=values[52], a53=values[53], a54=values[54], a55=values[55], a56=values[56], a57=values[57], a58=values[58], a59=values[59], a60=values[60], a61=values[61], a62=values[62], a63=values[63]):
    return a63
def bench(n):
    total = 0
    for _ in range(n):
        total += len(target())
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

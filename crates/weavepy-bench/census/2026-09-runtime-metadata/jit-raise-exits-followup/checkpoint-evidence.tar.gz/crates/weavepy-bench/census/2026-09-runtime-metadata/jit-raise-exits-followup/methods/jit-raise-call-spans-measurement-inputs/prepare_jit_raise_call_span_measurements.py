"""Prepare the corrected candidate's inputs, including cold exception controls."""
import hashlib
import json
from pathlib import Path
import shutil

original = Path('target/jit-raise-exits-inputs')
root = Path('target/jit-raise-call-spans-inputs')
assert not root.exists()
shutil.copytree(original, root)
for group in ['kernels', 'calls', 'exceptions']:
    path = root / group / 'preparation.json'
    report = json.loads(path.read_text())
    for case in report['rows'].values():
        for key in ['path', 'driver']:
            case[key] = str(root / Path(case[key]).relative_to(original))
    path.write_text(json.dumps(report, indent=2) + '\n')

cold = root / 'cold-exceptions'
cold.mkdir()
report = json.loads((root / 'exceptions' / 'preparation.json').read_text())
report['purpose'] = 'Cold-process exception controls, including JIT compilation and retirement.'
for name, case in report['rows'].items():
    path = cold / (name + '.py')
    driver = cold / (name + '-verify.py')
    path.write_text(Path(case['path']).read_text() + '''
if __name__ == '__main__':
    import os
    import time
    n = int(os.environ['WEAVEPY_BENCH_WORK'])
    start = time.perf_counter_ns()
    bench(n)
    print('WEAVEPY_BENCH_NS=%d' % (time.perf_counter_ns() - start))
''')
    driver.write_bytes(Path(case['driver']).read_bytes())
    case.update(path=str(path), source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                driver=str(driver), driver_sha256=hashlib.sha256(driver.read_bytes()).hexdigest())
(cold / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')

runner = Path('target/measure_verified_python_components.py')
assert not runner.exists()
source = Path('target/check_datetime_components_isolated.py').read_text()
source = source.replace('Measure verified datetime components', 'Measure verified Python workloads')
source = source.replace("p.add_argument('--samples'", "p.add_argument('--cold', action='store_true', help='Measure the first invocation in each process')\np.add_argument('--samples'")
source = source.replace("'work': prepared['work']", "'cold_workload': a.cold, 'work': prepared['work']")
source = source.replace("prepared['work'], True, fixture_root", "prepared['work'], not a.cold, fixture_root")
runner.write_text(source)

preflight = Path('target/preflight_jit_raise_call_spans.py')
assert not preflight.exists()
source = Path('target/preflight_jit_raise_probes.py').read_text().replace('jit-raise-exits', 'jit-raise-call-spans')
preflight.write_text(source)
validation = Path('target/validate_jit_raise_call_spans.sh')
assert not validation.exists()
validation.write_text(Path('target/validate_jit_raise_exits.sh').read_text().replace('jit-raise-exits', 'jit-raise-call-spans'))

focused = Path('target/measure_jit_raise_call_spans_focused.sh')
assert not focused.exists()
source = Path('target/measure_jit_raise_exits_focused.sh').read_text().replace('jit-raise-exits', 'jit-raise-call-spans')
source = source.replace('target/check_datetime_components_isolated.py', 'target/measure_verified_python_components.py')
source = source.replace('for group in kernels calls exceptions; do', 'for group in kernels calls exceptions cold-exceptions; do\n    extra=()\n    if [ "$group" = cold-exceptions ]; then extra=(--cold); fi')
source = source.replace('--samples 7 >', '--samples 7 "${extra[@]}" >')
focused.write_text(source)
full = Path('target/measure_jit_raise_call_spans_full.sh')
assert not full.exists()
full.write_text(Path('target/measure_jit_raise_exits_full.sh').read_text().replace('jit-raise-exits', 'jit-raise-call-spans'))
print('Prepared 12 warm cases, 4 cold controls, verification, validation, and measurement scripts.')

"""Prepare an isolated formatter comparison and a retained-reference comparison."""
from pathlib import Path

for name in ['build_borrowed_keyword_defaults.sh', 'check_borrowed_keyword_defaults.sh',
             'validate_borrowed_keyword_defaults.sh', 'measure_borrowed_keyword_defaults_focused.sh',
             'measure_borrowed_keyword_defaults_full.sh', 'summarize_borrowed_keyword_defaults.py',
             'freeze_borrowed_keyword_defaults_sources.py', 'verify_borrowed_keyword_defaults_ready.py']:
    text = (Path('target') / name).read_text().replace('borrowed-keyword-defaults', 'ascii-time-format').replace('borrowed_keyword_defaults', 'ascii_time_format')
    if name.startswith('build_'):
        text = text.replace('base=target/release/weavepy-runtime-thin-value-storage', 'base=target/release/weavepy-runtime-borrowed-keyword-defaults')
    if name == 'check_borrowed_keyword_defaults.sh':
        text = text.replace('for test in ', 'for test in test_time_format_fastpath ')
        text = text.replace("printf 'done\\n'", "WEAVEPY_JIT=1 \"$binary\" -c 'import _pydatetime as p; import _weave_datetime as n; assert p._format_time_parts is n.format_time_parts; assert p._format_time_parts(3, 4, 5, 1999, \"milliseconds\") == \"03:04:05.001\"; print(\"native formatter active\")' > target/ascii-time-format-checks/native-format-coverage.txt 2>&1\nprintf 'done\\n'")
    if name == 'measure_borrowed_keyword_defaults_focused.sh':
        text = text.replace('24 first-invocation binding controls', '17 first-invocation formatter and binding controls').replace('24 repeated binding controls', '17 repeated formatter and binding controls')
    if name == 'summarize_borrowed_keyword_defaults.py':
        text = text.replace("[('cold',24),('warm',24)]", "[('cold',17),('warm',17)]")
    if name == 'freeze_borrowed_keyword_defaults_sources.py':
        text = text.replace('Freeze the one-block binding change', 'Freeze the time formatter change')
        text = text.replace('target/borrowed-defaults-prebuild.json', 'target/borrowed-keyword-defaults-prebuild.json')
        text = text.replace("assert changed == ['crates/weavepy-vm/src/lib.rs'], changed", "assert set(changed) == {'crates/weavepy-vm/src/stdlib/datetime_accel.rs', 'crates/weavepy-vm/src/stdlib/python/_pydatetime.py'}, changed")
        text = text.replace("paths.add('tests/regrtest/test_overridden_keyword_default_ownership.py')", "paths.add('tests/regrtest/test_time_format_fastpath.py')")
        text = text[:text.index("before = Path('target/ascii-time-format-preimages/lib.rs')")] + '''diff = []
for name in changed:
    before = (Path('target/ascii-time-format-preimages') / Path(name).name).read_text()
    after = Path(name).read_text()
    diff += difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='predecessor/' + name, tofile='candidate/' + name)
Path('target/ascii-time-format-review.diff').write_text(''.join(diff))
print('Frozen', len(paths), 'source identities and', len(methods), 'methods/inputs.')
'''
    if name == 'verify_borrowed_keyword_defaults_ready.py':
        text = text.replace('Require complete binding validation', 'Require complete formatter validation')
        text = text.replace('347 passed', '351 passed').replace('== 31', '== 32').replace('93 targeted', '96 targeted')
        text = text.replace('overridden keyword defaults: ownership and binding ok', 'time formatting semantics: ok')
        text = text.replace('test_overridden_keyword_default_ownership-', 'test_time_format_fastpath-')
        text = text.replace("assert env['binaries']['previous']['sha256'] == 'bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'", "assert env['binaries']['previous']['sha256'] == 'bc88bf2b02abaaf0ad6a3d7427a17cab11f864a400a8161fc2effe5f396dd695'\nassert hashlib.sha256(Path('target/release/weavepy-runtime-thin-value-storage').read_bytes()).hexdigest() == 'bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'")
        pos = text.index("print('All source/")
        text = text[:pos] + "assert Path('target/ascii-time-format-checks/native-format-coverage.txt').read_text() == 'native formatter active\\n'\n" + text[pos:]
    out = Path('target') / name.replace('borrowed_keyword_defaults', 'ascii_time_format')
    assert not out.exists(), out
    out.write_text(text)
print('Prepared fresh formatter trial methods.')

# Phase 61 preparation: native entry after argument binding

The goal remains unachieved. Phase 60's full pickle-lookup diagnostic is still
active. Do not edit runtime or active harnesses, compile, test, or profile until
it completes. No phase 61 runtime change or measurement has been applied yet.

Current source draft: target/bound-native-entry-draft, generated once by
prepare_bound_native_entry_draft.py. It adds guarded try_call_native_direct
in call_python_owned after the existing binder succeeds and before make_frame.
Only plain positional layouts without cells, closure, keyword-only, variadic,
or generator/coroutine flags are eligible. The existing native helper checks
compilation eligibility, lanes, observers, pending work, guards, and recursion.
It receives only bound parameter slots, not extra unbound locals. On completion,
the positional buffer returns to the existing scratch pool. Native side exits
retain the existing materialization path. No unsafe code or new call cache.

The new source test is target/test_bound_native_entry_draft.py. It passed
CPython 3.14.7 and current 5201 JIT/interpreter/actual -X gil=0 in
bound-native-entry-baseline-preflight/report.json. This is baseline evidence,
not candidate validation. It covers live defaults including changed lengths and
None, replaced code, methods, invalid/positional-only arguments, excluded
keyword-only/variadic/closure/generator/coroutine layouts, tracing/profiling
locals/events, raised-object identity and traceback locals, and immediate
temporary-argument finalization. Native coverage of the candidate remains required.

Build script: target/build_bound_native_entry.sh takes the retained previous
binary as its required first argument and uses fresh phase-61 paths. It runs
VM tests, formatting, Clippy, no-default-features checking, then the correct
release CLI build and source snapshot. Check and validation scripts are also
prepared, with 20 targeted tests in three modes and the full 275 standard
checks. Copy the prepared regression into tests/regrtest/test_bound_native_entry.py
and format the applied source before invoking the build script. The draft's
original source hash must still match before applying it.

Ten focused controls have been prepared and hashed in bound-native-entry-inputs:
seven call-matrix shapes plus keyword-only, closure, and many-locals cases,
work=10000, seven paired samples planned. Prepared inputs are unmeasured.
Per-shape coverage on 5201 confirms sparse keywords and variadic keywords each
add 850 generic calls; the sparse-keyword callee already compiles but enters
through a full frame. Ordinary bound methods are already native. Full standard
and startup controls, exact CPython values, binary/cache identity, and all raw
samples and load observations remain required before any performance claim.

The earlier combined inline pin-memo draft remains unapplied and unmeasured.
Phase 60 may be deferred because its metaclass fallback regressed in all seven
pairs; decide only after the full results are preserved. If it is deferred,
restore only its two exact runtime files and retain the candidate/test/results
in its experiment archive. The post-binding source draft modifies lib.rs,
which has no phase-60 runtime delta, so its base hash should remain applicable.

Phase 60 is now archived and DEFERRED; its two runtime files were restored and
its exact regression preserved outside the active tests. Phase 61 source is
APPLIED in lib.rs (formatted) with tests/regrtest/test_bound_native_entry.py.
Both 5201 and the retained predecessor 539c pass its baseline regression in
JIT/interpreter/gil0, as does CPython. 144 source hashes were captured before
build. No candidate runtime validation or timing yet.

18433 CLOSED 101 before compilation: offline Cargo couldn't find the aes 0.8.4
archive despite the extracted source directory. Original pipeline, format,
VM-test logs and stage are preserved. No source hashes changed. 29841 CLOSED 0:
cargo fetch --locked restored the locked dependencies. Build v2 now uses fresh
bound-native-entry-v2-* outputs, takes 539c as predecessor, and will preserve
weavepy-runtime-bound-native-entry plus bound-native-entry-v2-source-snapshot.
The unstarted targeted script now requires the v2 done stage. Don't edit
runtime/active scripts or run competing heavy work while this build runs.

60346 CLOSED 101: the full VM run passed 341/342 tests. The sole failure was
the existing jit_slot_writes_share_code_names_after_deletion coverage assertion,
which counted only framed entries. All Python slot values, key identities, and
both compilations passed. 67458 CLOSED 101: an isolated diagnostic preserved
the original assertion and printed compiled=2, framed=2, direct=199, proving
that it overlooked direct native entries. The original source and diagnostic
patch/log are preserved. The test now keeps its >=100 native-execution threshold
but counts framed plus direct entries; its value/identity checks are unchanged.

30851 ACTIVE: fresh v3 pipeline. The corrected isolated test passed (2 compiled,
2 framed, 199 direct); formatting, Clippy, and no-default-features checks passed.
The release CLI is building. This is 341 passing cases from the initial full
run plus the corrected case passing separately, not a second complete VM run.
144 v3 source hashes are recorded in bound-native-entry-v3-prebuild-sources.json.
Expected new snapshot: bound-native-entry-v3-source-snapshot. Actual binary is
not available or validated yet. No timing. Do not edit runtime or active scripts
or run competing heavy work until this build completes.

Prepared coverage and measurement scripts now reference v3 stage/previous files.
The earlier bound-native-entry-measurement-inputs bundle remains unchanged and
contains v2 prerequisites; preserve it as preparation history. Create a fresh
updated bundle before timing. No measurement scripts have run. Native coverage
will compare ten cases against 539c and CPython and assert >=500 more direct
calls and >=500 fewer framed entries for sparse keywords and many locals.

Precision: the previous frame path uses pooled stack and locals storage. The
new path proves avoidance of frame construction and framed dispatch, not a
count of malloc calls. Full argument binding and boxed argument staging still
happen. Allocation, CPU, wall, and RSS gains remain unmeasured. Sparse native
keyword argument mapping is a separate possible follow-up, not implemented.

30851 CLOSED 0. Release CLI build completed in 6m58s (observed rebuild duration,
not a controlled build-time metric). Candidate
ca6b541dfe19056fc8df73744ab7f60c927570ad3e179914925cdd5c63c15291
is 44,290,720 bytes, +160 versus 539c. Snapshot v3 contains 144 sources and 37
original measurement inputs. All snapshot, previous/new binary, and prebuild
source hashes were verified unchanged after the build.

33457 CLOSED 0: all 60 targeted release checks passed in JIT/interpreter/gil0,
plus the instrumented regression. inspect_bound_native_entry.py CLOSED 0:
all ten CPython outputs match and native-entry assertions pass. Sparse-keyword
and many-local cases: framed entries 855 -> 3, direct calls 2 -> 854, generic
dynamic calls 854 -> 854, zero deopts. This saves framed entry, not the generic
argument binder. Bound methods were already native. Raw traces are preserved.

65358 ACTIVE: full standard compatibility validation, last 265 completed checks
passed including I/O. No candidate performance measurements have started.
Five extra standard suites omitted by the 275-check gate are prepared in
check_bound_native_entry_extra.py: test_call, test_extcall, test_inspect,
test_copy, test_copyreg. Run them after the active validation; the script keeps
any candidate failure and checks its predecessor rather than hiding the failure.

Before timing, the focused protocol now also carries all four original
exception-frequency cases, work=5000, in warm and cold forms. Eighteen focused
cases total: ten call shapes, four warm and four cold exception controls.
No samples were collected before this addition. Original bytes/work unchanged,
verification drivers newly hashed. Fresh v4 measurement-input bundle contains
17 files, including the new preparation and extra-check script. Preserve v2/v3
preparation snapshots too. The active build/source snapshot is still v3; v4
names only the updated measurement-input bundle. No runtime changes.

Focused strict gate protocol: load 1/5 min <=4, 3 observations 10s apart, max
600s. Conditional diagnostic launcher requires actual no-child/no-output gate
expiration. Full script takes the completed focused directory and a fresh
output directory. If focused qualified, try full strict gate; if focused was
busy diagnostic, use a separately recorded full diagnostic. Retain all samples,
cache identities, load and VM/swap data, with explicit 21/23/24 cohorts.

65358 CLOSED 0: all 275 standard compatibility checks passed. 63632 CLOSED 0:
all five extra call/inspection/copy suites passed. Original focused 48586 CLOSED
1 after all ten calls and four warm exceptions completed. First cold stabilization
had no main timer and emitted empty stdout, so no cold timing samples existed.
A declared cold-only continuation 51799 CLOSED 0 used the original cold sources;
completed cases were not rerun. Both load gates qualified. Completion manifest
bound-native-entry-focused-complete verifies all 18 cases and keeps the failure.

46624 CLOSED 0: full qualified measurement completed, 24 fixtures x 5 pairs and
nine startup/import cases x 31 pairs, all value and cache checks passed. JIT
23-workload new/539c = 0.996497508, new/CPython = 3.433604873; historical 21 paired
= 2.116516911, ratios-of-medians = 2.118446814. All-24 RSS new/539c = 1.000686257,
new/CPython = 2.073197672, zero CPython RSS wins. Call overhead = 0.93540, but
list_ops = 1.06479 and several other controls regressed. Every sample retained.
Focused sparse keyword and many locals improved 16.9/19.2% in all seven pairs;
variadic keyword, keyword-only, closure regressed 8.3/10.2/5.9% in all seven pairs.
This experiment remains under refinement, not accepted as an all-metrics win.

Generated-code diagnostic shows call_python_owned's reserved stack shrank by
80 bytes. A larger stack frame is not the explanation; code layout/register
allocation remains a hypothesis. Narrow early-bound-entry-draft moves existing
bound signature exclusions ahead of remaining flags and drops redundant code
cell checks already enforced by memoized direct-entry eligibility. It keeps
live closures and generator families on the existing path. Draft is unapplied.

"""Check argument binding, inspection, and copying; retain baseline failures."""
import hashlib,json,os,subprocess
from pathlib import Path

root=Path('target/binder-flags-extra-checks');root.mkdir()
report={'runs':{}, 'runner_sha256': hashlib.sha256(Path('target/release/weavepy-conformance').read_bytes()).hexdigest()}
new='target/release/weavepy-runtime-binder-flags'
base='target/release/weavepy-runtime-jit-raise-call-spans'
for case in ['test_call','test_extcall','test_inspect','test_copy','test_copyreg']:
    report['runs'][case]={}
    for label,binary in [('new',new),('base',base)]:
        digest=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
        env=dict(os.environ)
        env.update(WEAVEPY_JIT='1',WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
                   WEAVEPY_FROZEN_CACHE=str((root/'frozen'/digest).resolve()))
        command=['target/release/weavepy-conformance','regrtest','--all-cpython','--mode','subprocess',
                 '--weavepy',binary,'--filter','cpython/Lib/test/'+case+'.py','--stream']
        result=subprocess.run(command,env=env,text=True,capture_output=True,timeout=900)
        report['runs'][case][label]={'binary_sha256':digest,'command':command,'returncode':result.returncode,
                                    'stdout':result.stdout,'stderr':result.stderr}
        (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
        print(case,label,result.returncode,result.stdout[-2200:],flush=True)
        if label=='new' and result.returncode==0:
            break
report['status']='passed' if all(v['new']['returncode']==0 for v in report['runs'].values()) else 'needs_review'
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if report['status']=='passed' else 1)

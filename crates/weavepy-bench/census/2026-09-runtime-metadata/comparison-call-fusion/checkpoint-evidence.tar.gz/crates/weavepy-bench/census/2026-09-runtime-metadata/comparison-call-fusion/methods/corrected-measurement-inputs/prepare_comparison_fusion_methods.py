"""Prespecify a comparison-return fusion follow-up without changing prior evidence."""
from pathlib import Path
items=[('build_integer_comparison_guards.sh','build_comparison_call_fusion.sh'),('check_integer_comparison_guards.sh','check_comparison_call_fusion.sh'),('validate_integer_comparison_guards.sh','validate_comparison_call_fusion.sh'),('check_integer_comparison_guards_extra.py','check_comparison_call_fusion_extra.py'),('inspect_integer_comparison_guards.py','inspect_comparison_call_fusion.py'),('measure_integer_comparison_guards_focused.sh','measure_comparison_call_fusion_focused.sh'),('measure_integer_comparison_guards_full.sh','measure_comparison_call_fusion_full.sh'),('summarize_integer_comparison_guards.py','summarize_comparison_call_fusion.py')]
for old,new in items:
 s=Path('target',old).read_text().replace('integer-comparison-guards','comparison-call-fusion').replace('integer_comparison_guards','comparison_call_fusion')
 s=s.replace('weavepy-runtime-jit-assertion-exits','weavepy-runtime-integer-comparison-guards').replace('weavepy-runtime-jit-raise-call-spans','weavepy-runtime-jit-assertion-exits')
 if old.startswith('check_') and old.endswith('.sh'):
  s=s.replace('for test in test_comparison_call_fusion ','for test in test_comparison_call_fusion test_integer_comparison_guards ')
 if old.startswith('inspect_'):
  # Reuse all 19 established compile/rebuild controls, then check the four new forms.
  s=s.replace('driver = Path("tests/regrtest/test_comparison_call_fusion.py")','driver = root / "combined-driver.py"\ndriver.write_text(Path("tests/regrtest/test_integer_comparison_guards.py").read_text() + "\\n" + Path("tests/regrtest/test_comparison_call_fusion.py").read_text())')
  s=s.replace('| {"cmp_loop"}','| {"cmp_loop", "cmp_fusion_kw", "cmp_fusion_bool", "cmp_fusion_global", "cmp_fusion_local"}')
  s=s.replace('All 19 comparison functions','All 23 comparison functions')
 if old.startswith('measure_') and 'full' in old:
  s=s.replace('base="$(cat target/comparison-call-fusion-previous.txt)"','base="$(cat target/comparison-call-fusion-reference.txt)"')
 p=Path('target',new);assert not p.exists();p.write_text(s)
print('Prepared eight follow-up methods; prior methods unchanged.')

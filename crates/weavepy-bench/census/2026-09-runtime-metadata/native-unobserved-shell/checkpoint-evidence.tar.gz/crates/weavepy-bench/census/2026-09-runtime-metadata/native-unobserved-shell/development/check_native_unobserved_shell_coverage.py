"""Verify fixture values and capture untimed JIT paths before measurement."""
from pathlib import Path
import hashlib,json,os,re,subprocess,sys
binary=Path(sys.argv[1])
out=Path(sys.argv[2])
assert not out.exists()
out.mkdir(parents=True)
input_root=Path(sys.argv[3]) if len(sys.argv)>3 else Path('target/native-unobserved-shell-inputs')
manifest=input_root/'cold/preparation.json'
inputs=json.loads(manifest.read_text())
report={'purpose':__doc__,'binary':str(binary),'sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'rows':{},'input_manifest':str(manifest),'input_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'method_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
for name,row in inputs['rows'].items():
    env={**os.environ,'WEAVEPY_STDLIB_CACHE':str(Path('target/performance-stdlib-cache').resolve()),
         'WEAVEPY_FROZEN_CACHE':str((out/'frozen').resolve()),'WEAVEPY_JIT':'1','WEAVEPY_JIT_TRACE':'1','WEAVEPY_VM_STATS':'1'}
    p=subprocess.run([str(binary),row['driver']],env=env,capture_output=True,text=True,timeout=120)
    (out/(name+'.stdout.txt')).write_text(p.stdout)
    (out/(name+'.trace.txt')).write_text(p.stderr)
    assert p.returncode==0 and p.stdout==(str(row['expected_checksum'])+'\n')*2,(name,p.returncode,p.stdout,p.stderr[-2000:])
    stats={label:int(value) for label,value in re.findall(r'^- (.+?): \*\*(\d+)\*\*$',p.stderr,re.M)}
    report['rows'][name]={'returncode':p.returncode,'stdout':p.stdout,'stats':stats,
                        'bench_compiled':'jit compile "bench"' in p.stderr,
                        'single_compiled':'jit compile "single"' in p.stderr,
                        'bench_rejections':[line for line in p.stderr.splitlines() if 'jit reject "bench"' in line],
                        'trace_sha256':hashlib.sha256(p.stderr.encode()).hexdigest()}
    print(name,'bench_compiled',report['rows'][name]['bench_compiled'],'generic calls',stats.get('generic dyn calls'),'native calls',stats.get('native-to-native calls'),flush=True)
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')

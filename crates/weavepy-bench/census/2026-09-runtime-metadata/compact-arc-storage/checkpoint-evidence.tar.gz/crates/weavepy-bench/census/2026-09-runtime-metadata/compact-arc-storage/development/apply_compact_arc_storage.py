"""Preserve bf2, then apply the already Miri-checked compact owner prototype."""
import gzip
import hashlib
import json
from pathlib import Path

def sha(data):
    return hashlib.sha256(data).hexdigest()

archive = Path('crates/weavepy-bench/census/2026-09-runtime-metadata/thin-value-storage')
records = json.loads((archive / 'index.json').read_text())
for row in records:
    data = (archive / row['path']).read_bytes()
    assert sha(data) == row['sha256'], row['path']
    if 'uncompressed_sha256' in row:
        raw = gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert sha(raw) == row['uncompressed_sha256'], row['path']
assert sha(Path('target/release/weavepy-runtime-thin-value-storage').read_bytes()) == 'bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'
for name in ['tests', 'miri-arm64', 'miri-i686']:
    assert '8 passed; 0 failed' in Path(f'target/compact-arc-prototype-{name}.txt').read_text()
assert 'Finished' in Path('target/compact-arc-prototype-clippy-01.txt').read_text()

backup = Path('target/compact-arc-storage-preimages')
backup.mkdir()
sources = {}
roots = ['crates/weavepy-vm', 'crates/weavepy-capi', 'crates/weavepy-cli', 'crates/weavepy-jit']
for root in roots:
    for path in Path(root).rglob('*.rs'):
        data = path.read_bytes()
        dest = backup / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        sources[str(path)] = sha(data)
prototype = {}
for path in [*Path('target/compact-arc-prototype/src').glob('*.rs'), Path('target/compact-arc-prototype/Cargo.toml'), Path('target/compact-arc-prototype/Cargo.lock')]:
    prototype[str(path)] = sha(path.read_bytes())
(backup / 'index.json').write_text(json.dumps({'sources': sources, 'prototype': prototype, 'verified_archive_files': len(records)}, indent=2) + '\n')

shared = Path('crates/weavepy-vm/src/shared_value.rs')
old_tests = shared.read_text().split('#[cfg(test)]\nmod tests {', 1)[1]
old_tests = old_tests.replace('ThinArc', 'CompactArc').replace('get_mut(&mut value).unwrap().view()', 'get_mut(&mut value).unwrap()')
code = Path('target/compact-arc-prototype/src/lib.rs').read_text().split('#[cfg(test)]', 1)[0]
code = code.replace('//! Unapplied compact Arc owner. Allocation layout and all reference counts stay with Arc.', '''//! Shared immutable values with compact pointer metadata.
//!
//! Keeping a 64-bit pointer and seven metadata bytes in each owner leaves room
//! for the Object discriminant in a 16-byte value slot. Strings and slices keep
//! their standard Arc allocation layout, without a separate length header.
//! Full-size metadata remains available through an escape representation.''')
code += '''impl sealed::Sealed for crate::tuple_storage::TupleStorage {}
// SAFETY: TupleStorage is repr(C) with a final [Object] tail. Its metadata is
// exactly that tail's element count. Reconstructing the original data address
// and length preserves the hash header, payload alignment, and Arc destruction.
unsafe impl ArcMetadata for crate::tuple_storage::TupleStorage {
    fn metadata(&self) -> usize {
        self.len()
    }
    fn pointer(data: *const (), len: usize) -> *const Self {
        ptr::slice_from_raw_parts(data.cast::<crate::object::Object>(), len) as *const Self
    }
}

#[cfg(test)]
mod tests {'''
code += old_tests
code += '\n#[cfg(test)]\nmod compact_metadata_tests {\n' + Path('target/compact-arc-prototype/src/tests.rs').read_text() + '\n}\n'
shared.write_text(code)

tuple_path = Path('crates/weavepy-vm/src/tuple_storage.rs')
code = tuple_path.read_text().replace('ThinArc', 'CompactArc')
code = code.replace('/// Immutable tuple storage with length and cached hash in its allocation.', '/// Immutable tuple storage with its cached hash in the allocation.\n/// The compact owner carries the slice length.')
code = code.replace('    len: usize,\n', '').replace('            len: N,\n', '')
code = code.replace('''        let (prefix, _) = Layout::new::<usize>()
            .extend(Layout::new::<CachedHash>())
            .expect("tuple prefix exceeds layout limit");
        let (layout, _) = prefix''', '''        let (layout, _) = Layout::new::<CachedHash>()''')
code = code.replace('repr(C) places length and hash before', 'repr(C) places the hash before')
code = code.replace('            std::ptr::addr_of_mut!((*tuple).len).write(len);\n', '')
tuple_path.write_text(code)

for source in sources:
    path = Path(source)
    if path == shared or path == tuple_path:
        continue
    code = path.read_text()
    replaced = code.replace('ThinArc', 'CompactArc').replace('ThinWeak', 'CompactWeak')
    if replaced != code:
        path.write_text(replaced)
print(json.dumps({'preserved_sources': len(sources), 'archive_verified': len(records), 'applied': True}))

#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/pickle-special-lookup-validation-stage.txt)" = done
python3.14 - <<'CHECK'
import json
from pathlib import Path
report = json.loads(Path('target/pickle-special-lookup-focused-load.json').read_text())
assert report['status'] == 'not_started' and 'child_pid' not in report
assert not Path('target/pickle-special-lookup-focused').exists()
CHECK
test ! -e target/pickle-special-lookup-diagnostic
mkdir target/pickle-special-lookup-diagnostic
base=target/release/weavepy-runtime-jit-raise-call-spans
binary=target/release/weavepy-runtime-pickle-special-lookup
vm_stat > target/pickle-special-lookup-diagnostic/vm-before.txt
sysctl hw.memsize vm.swapusage > target/pickle-special-lookup-diagnostic/memory-before.txt
for group in components hooks; do
    printf '%s\n' "$group" > target/pickle-special-lookup-diagnostic/stage.txt
    python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs "target/pickle-special-lookup-inputs/$group" --out "target/pickle-special-lookup-diagnostic/$group" --samples 7 > "target/pickle-special-lookup-diagnostic/$group.txt" 2>&1
done
vm_stat > target/pickle-special-lookup-diagnostic/vm-after.txt
sysctl hw.memsize vm.swapusage > target/pickle-special-lookup-diagnostic/memory-after.txt
printf 'done\n' > target/pickle-special-lookup-diagnostic/stage.txt

"""Verify raise-exit performance inputs and record native coverage before timing."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

out = Path('target/jit-raise-call-spans-preflight')
assert not out.exists()
out.mkdir()
inputs = Path('target/jit-raise-call-spans-inputs')
shutil.copytree(inputs, out / 'inputs')
base = str(Path('target/release/weavepy-runtime-weakref-shared-keys').resolve())
new = str(Path('target/release/weavepy-runtime-jit-raise-call-spans').resolve())
variants = [('cpython', shutil.which('python3.14'), [], None),
            ('previous_jit', base, [], '1'), ('previous_interp', base, [], '0'),
            ('jit', new, [], '1'), ('interp', new, [], '0'), ('gil0', new, ['-X', 'gil=0'], '1')]
report = {'purpose': __doc__, 'binaries': {}, 'rows': {}, 'coverage': {}}
for label, binary, _, _ in variants:
    report['binaries'][label] = {'path': binary, 'sha256': hashlib.sha256(Path(binary).read_bytes()).hexdigest()}

def save():
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def environment(label, jit):
    env = dict(os.environ)
    for key in ['WEAVEPY_JIT', 'WEAVEPY_GIL', 'WEAVEPY_VM_STATS', 'WEAVEPY_JIT_TRACE', 'WEAVEPY_JIT_THRESHOLD']:
        env.pop(key, None)
    if jit is not None:
        env['WEAVEPY_JIT'] = jit
        env['WEAVEPY_FROZEN_CACHE'] = str((out / 'frozen' / report['binaries'][label]['sha256']).resolve())
        env['WEAVEPY_STDLIB_CACHE'] = str(Path('target/performance-stdlib-cache').resolve())
    return env

for group in ['kernels', 'calls', 'exceptions']:
    prepared = json.loads((inputs / group / 'preparation.json').read_text())
    for name, case in prepared['rows'].items():
        for key, hashkey in [('path', 'source_sha256'), ('driver', 'driver_sha256')]:
            assert hashlib.sha256(Path(case[key]).read_bytes()).hexdigest() == case[hashkey]
        row = report['rows'][group + '/' + name] = {'case': case, 'checks': {}}
        for label, binary, flags, jit in variants:
            command = [binary, *flags, case['driver']]
            result = subprocess.run(command, env=environment(label, jit), capture_output=True, text=True, timeout=180)
            row['checks'][label] = {'command': command, 'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
            save()
            assert result.returncode == 0, (group, name, label, result.stderr)
            values = [json.loads(line) for line in result.stdout.splitlines()]
            assert len(values) == 2 and values[0] == values[1], (name, label, values)
            assert result.stdout == row['checks']['cpython']['stdout'], (name, label, row['checks'])
        print(group, name, 'passed all six modes', flush=True)
        coverage = report['coverage'][name] = {}
        for label, binary in [('previous_jit', base), ('jit', new)]:
            env = environment(label, '1')
            env.update(WEAVEPY_JIT_TRACE='1', WEAVEPY_VM_STATS='1')
            result = subprocess.run([binary, case['driver']], env=env, capture_output=True, text=True, timeout=180)
            path = out / (name + '-' + label + '.trace.txt')
            path.write_text(result.stderr)
            coverage[label] = {'returncode': result.returncode, 'stdout': result.stdout,
                               'trace': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            save()
            assert result.returncode == 0 and result.stdout == row['checks']['cpython']['stdout']
assert len(report['rows']) == 12
report['status'] = 'passed'
save()

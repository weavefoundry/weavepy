#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-compact-intern-pools
reference=target/release/weavepy-runtime-jit-raise-call-spans
binary=target/release/weavepy-runtime-jit-assertion-exits
test -f "$base"
test -f "$reference"
test ! -e "$binary"
test ! -e target/jit-assertion-exits-build-stage.txt
printf '%s\n' "$base" > target/jit-assertion-exits-previous.txt
printf '%s\n' "$reference" > target/jit-assertion-exits-reference.txt
printf 'VM tests and static checks\n' > target/jit-assertion-exits-build-stage.txt
cargo fmt --all -- --check > target/jit-assertion-exits-format.txt 2>&1
cargo test --offline --locked -p weavepy-jit -j 1 > target/jit-assertion-exits-jit-tests.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/jit-assertion-exits-vm-tests.txt 2>&1
cargo clippy --offline --locked -p weavepy-vm -p weavepy-jit --lib --tests -j 1 -- -D warnings > target/jit-assertion-exits-clippy.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/jit-assertion-exits-no-jit.txt 2>&1
printf 'release build\n' > target/jit-assertion-exits-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/jit-assertion-exits-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/jit-assertion-exits-source-snapshot --extra target/build_jit_assertion_exits.sh target/check_jit_assertion_exits.sh target/validate_jit_assertion_exits.sh target/check_jit_assertion_exits_extra.py target/inspect_jit_assertion_exits.py target/measure_jit_assertion_exits_focused.sh target/measure_jit_assertion_exits_full.sh target/measure_verified_python_components_with_reference.py target/jit-assertion-exits-protocol.md > target/jit-assertion-exits-snapshot.txt 2>&1
printf 'done\n' > target/jit-assertion-exits-build-stage.txt

"""Migrate explicit owner types and directly typed constructors; retain preimages."""
from pathlib import Path
import hashlib, json, re, shutil

root = Path(__file__).resolve().parents[1]
out = root / 'target/thin-value-storage-preimages'
assert not out.exists()
out.mkdir()
report = {'sources': {}, 'drafts': {}, 'checks': {}}
for name in ['shared_value.rs', 'tuple_storage.rs']:
    p = root / 'target/thin-value-storage-draft' / name
    q = out / 'tested-draft' / name
    q.parent.mkdir(exist_ok=True)
    shutil.copy2(p, q)
    report['drafts'][name] = hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['thin_value_storage_api_test.txt', 'thin_value_storage_api_test_v2.txt',
             'thin_value_storage_api_miri_arm64.txt', 'thin_value_storage_api_miri_i686.txt',
             'shared_value_storage_cpython_baseline.txt',
             'shared_value_storage_cpython_baseline_v2.txt',
             'shared_value_storage_jit_baseline_v2.txt',
             'shared_value_storage_interp_baseline_v2.txt',
             'shared_value_storage_gil0_baseline_v2.txt']:
    p = root / 'target' / name
    report['checks'][name] = hashlib.sha256(p.read_bytes()).hexdigest()
paths = []
for crate in (root / 'crates').iterdir():
    for sub in ['src', 'tests', 'examples']:
        paths.extend((crate / sub).rglob('*.rs'))
for p in paths:
    old = p.read_text()
    q = out / p.relative_to(root)
    q.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, q)
    report['sources'][str(p.relative_to(root))] = hashlib.sha256(p.read_bytes()).hexdigest()
    prefix = 'crate' if 'weavepy-vm' in p.parts else 'weavepy_vm'
    types = {'Rc<str>': 'SharedStr', 'Rc<[u8]>': 'SharedSlice<u8>',
             'Rc<[u32]>': 'SharedSlice<u32>', 'Weak<str>': 'WeakStr',
             'Weak<[u8]>': 'WeakSlice<u8>', 'Weak<[u32]>': 'WeakSlice<u32>'}
    new = old
    for spelling, replacement in types.items():
        pattern = r'(?:(?:crate|weavepy_vm)::sync::|std::sync::)?' + re.escape(spelling)
        new = re.sub(pattern, prefix+'::shared_value::'+replacement, new)
    new = re.sub(r'Rc<(?:crate::object::)?TupleStorage>', prefix+'::object::SharedTuple', new)
    new = re.sub(r'Weak<(?:crate::object::)?TupleStorage>', prefix+'::shared_value::ThinWeak<'+prefix+'::object::TupleStorage>', new)
    for variant, owner in [('Str','SharedStr'), ('Bytes','SharedSlice'), ('WStr','SharedSlice')]:
        new = re.sub(r'(Object::'+variant+r'\(\s*)(?:(?:crate|weavepy_vm)::sync::)?Rc::from', r'\g<1>'+prefix+'::shared_value::'+owner+'::from', new)
        new = re.sub(r'(\(Object::'+variant+r'\(a\), Object::'+variant+r'\(b\)\) => )Rc::ptr_eq', r'\g<1>'+prefix+'::shared_value::'+owner+'::ptr_eq', new)
    new = new.replace('(Object::Tuple(a), Object::Tuple(b)) => Rc::ptr_eq', '(Object::Tuple(a), Object::Tuple(b)) => '+prefix+'::shared_value::ThinArc::ptr_eq')
    if p.name == 'lib.rs' and 'weavepy-vm' in p.parts:
        new = new.replace('pub mod sync;', 'pub mod sync;\npub mod shared_value;')
    if p.name == 'object.rs' and 'weavepy-vm' in p.parts:
        new = new.replace('pub use crate::tuple_storage::TupleStorage;', 'pub use crate::tuple_storage::{SharedTuple, TupleStorage};')
    if new != old:
        p.write_text(new)
for name in ['shared_value.rs', 'tuple_storage.rs']:
    shutil.copy2(out / 'tested-draft' / name, root / 'crates/weavepy-vm/src' / name)
(out / 'index.json').write_text(json.dumps(report, indent=2)+'\n')
print('Saved', len(report['sources']), 'source preimages; applied initial owner migration.')

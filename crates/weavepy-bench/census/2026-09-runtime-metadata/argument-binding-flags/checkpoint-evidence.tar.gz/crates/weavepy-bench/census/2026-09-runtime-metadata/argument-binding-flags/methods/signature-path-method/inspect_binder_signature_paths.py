"""Observe native and fallback paths for every binder signature control."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

assert Path('target/binder-flags-build-stage.txt').read_text().strip() == 'done'
root = Path('target/binder-flags-signature-paths')
root.mkdir()
previous = Path('target/binder-flags-reference.txt').read_text().strip()
variants = [('cpython', shutil.which('python3.14')),
            ('previous', previous), ('new', 'target/release/weavepy-runtime-binder-flags')]
prepared = json.loads(Path('target/binder-flag-inputs/preparation.json').read_text())
report = {'purpose': __doc__, 'binaries': {}, 'rows': {}, 'assertions_passed': False}
for label, binary in variants:
    report['binaries'][label] = {'path': binary, 'sha256': hashlib.sha256(Path(binary).read_bytes()).hexdigest()}


def save():
    (root / 'report.json').write_text(json.dumps(report, indent=2) + '\n')


for name, case in prepared['rows'].items():
    source = Path(case['path'])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == case['source_sha256']
    driver = root / (name + '.py')
    driver.write_text(source.read_text() + '\nfor unused in range(3):\n    print(bench(300))\n')
    row = report['rows'][name] = {'source_sha256': case['source_sha256'],
                                 'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest(), 'runs': {}}
    for label, binary in variants:
        env = dict(os.environ)
        for key in ['WEAVEPY_JIT', 'WEAVEPY_GIL', 'WEAVEPY_JIT_TRACE', 'WEAVEPY_VM_STATS', 'WEAVEPY_JIT_THRESHOLD']:
            env.pop(key, None)
        if label != 'cpython':
            env.update(WEAVEPY_JIT='1', WEAVEPY_JIT_TRACE='1', WEAVEPY_VM_STATS='1',
                       WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
                       WEAVEPY_FROZEN_CACHE=str((root / 'frozen' / report['binaries'][label]['sha256']).resolve()))
        result = subprocess.run([binary, str(driver)], env=env, text=True, capture_output=True, timeout=120)
        trace = root / (name + '-' + label + '.trace.txt')
        trace.write_text(result.stderr)
        row['runs'][label] = {
            'returncode': result.returncode, 'stdout': result.stdout,
            'trace_sha256': hashlib.sha256(trace.read_bytes()).hexdigest(),
            'compiled': sorted(set(re.findall(r'jit compile "([^"]+)"', result.stderr))),
            'rejections': sorted(set(re.findall(r'jit reject .+', result.stderr))),
            'stats': {k: int(v.replace(',', '')) for k, v in re.findall(r'^- ([^:]+): \*\*([\d,]+)\*\*', result.stderr, re.M)},
        }
        save()
        assert result.returncode == 0, (name, label, result.stderr[-2500:])
    assert len({r['stdout'] for r in row['runs'].values()}) == 1, name
    print(name, {label: row['runs'][label]['stats'] for label in ['previous', 'new']}, flush=True)

# Every row records actual compiled functions, rejections, and counters.
# A large signature may legitimately stay on the interpreter path.
report['assertions_passed'] = True
save()
print('All ten signature-control values match CPython; actual native/fallback paths recorded.')

"""Keep all prior controls and add single-callback and observed-frame controls."""
from pathlib import Path
import hashlib,json,subprocess

root=Path('target/native-unobserved-shell-inputs')
assert not root.exists()
work=20000
extra={
    'native_single_callback': ('''import os
class Fn:
    def __call__(self, value):
        return value
FN = Fn()
def single(value):
    return FN(value) + 1

def bench(n):
    total = 0
    for i in range(n):
        total += single(i)
    return total
''', work*(work-1)//2 + work),
    'native_observed_callback': ('''import os
import sys
class Fn:
    def __call__(self, value):
        frame = sys._getframe(1)
        return value + len(frame.f_code.co_name)
FN = Fn()

def bench(n):
    total = 0
    for i in range(n):
        total += FN(i)
    return total
''', work*(work-1)//2 + work*len('bench')),
}
tail='''
if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))
'''
oracles={}
for group in ['cold','warm']:
    folder=root/group;folder.mkdir(parents=True)
    original=json.loads(Path(f'target/native-dynamic-small-args-inputs-v2/{group}/preparation.json').read_text())
    cases={name:(Path(row['path']).read_text(),row['expected_checksum']) for name,row in original['rows'].items()}
    cases.update({name:(text+tail,checksum) for name,(text,checksum) in extra.items()})
    prepared={'purpose':__doc__,'work':work,'inherited_manifest':f'target/native-dynamic-small-args-inputs-v2/{group}/preparation.json','rows':{}}
    for name,(text,checksum) in cases.items():
        path=folder/(name+'.py');path.write_text(text)
        if name in original['rows']:
            assert hashlib.sha256(path.read_bytes()).hexdigest()==original['rows'][name]['source_sha256']
        driver=folder/(name+'-verify.py')
        driver.write_text(f'''import importlib.util, json
spec = importlib.util.spec_from_file_location('shell_control', {str(path.resolve())!r})
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(20000)
for _ in range(6):
    module.bench(64)
last = module.bench(20000)
print(json.dumps(first))
print(json.dumps(last))
''')
        prepared['rows'][name]={'path':str(path),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'driver':str(driver),'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'expected_checksum':checksum}
        if group=='cold':
            result=subprocess.run(['python3.14',str(driver)],text=True,capture_output=True,check=True)
            assert result.stdout==(str(checksum)+'\n')*2,(name,result.stdout,checksum)
            oracles[name]={'expected_checksum':checksum,'stdout':result.stdout,'returncode':result.returncode}
    (folder/'preparation.json').write_text(json.dumps(prepared,indent=2)+'\n')
Path('target/native-unobserved-shell-input-oracles.json').write_text(json.dumps(oracles,indent=2)+'\n')
print('All',len(oracles),'independent CPython checksums passed twice; all original 26 fixture sources unchanged.')

"""Preserve complete intern-pool evidence, compressing large raw text artifacts."""
import gzip
import hashlib
import json
from pathlib import Path

parent = Path("crates/weavepy-bench/census/2026-09-runtime-metadata")
out = parent / "compact-intern-pools"
assert not out.exists()
for group in ("focused", "full"):
    assert Path("target/compact-intern-pools-" + group + "/stage.txt").read_text().strip() == "done"
    assert json.loads(Path("target/compact-intern-pools-" + group + "-load.json").read_text())["status"] == "complete"
focused = json.loads(Path("target/compact-intern-pools-focused/summary.json").read_text())
full = json.loads(Path("target/compact-intern-pools-full/summary.json").read_text())
validation = json.loads(Path("target/compact-intern-pools-validation/validation.json").read_text())
assert len(validation) == 275 and all(row["passed"] for row in validation)
out.mkdir()
records = []


def copy(src, dst):
    src = Path(src)
    raw = src.read_bytes()
    data = raw
    # Preserve every raw byte; compression avoids repeated large JSON/log blobs.
    if len(raw) >= 65536 and src.suffix in (".json", ".txt", ".diff") and not src.name.startswith("summary"):
        dst += ".gz"
        data = gzip.compress(raw, compresslevel=9, mtime=0)
    p = out / dst
    assert not p.exists(), dst
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    records.append({"path": dst, "source": str(src), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                     "uncompressed_bytes": len(raw), "uncompressed_sha256": hashlib.sha256(raw).hexdigest()})


def folder(src, dst, recursive=False):
    src = Path(src)
    for p in sorted(src.rglob("*") if recursive else src.iterdir()):
        if p.is_file() and p.suffix in (".py", ".json", ".txt", ".md", ".sh", ".patch"):
            copy(p, str(Path(dst) / p.relative_to(src)))


for group in ("focused", "full"):
    folder("target/compact-intern-pools-" + group, group)
for group in ("warm", "cold"):
    copy("target/compact-intern-pools-focused/" + group + "/measurements.json", "focused/" + group + ".json")
    folder("target/compact-intern-inputs/" + group, "inputs/" + group)
for group in ("checks", "validation", "extra-checks", "startup-memory-regions"):
    folder("target/compact-intern-pools-" + group, "checks/" + group)
folder("target/compact-intern-pools-baseline-preflight", "checks/identity-baseline")
folder("target/compact-intern-inputs-baseline", "checks/workload-baseline")
folder("target/compact-intern-pools-measurement-inputs", "methods/frozen")
folder("target/compact-intern-pools-summary-method", "methods/postprocessing")
folder("target/compact-intern-datetime-paths", "diagnostics/datetime-paths")
for p in sorted(Path("target").glob("compact-intern-pools-*.txt")):
    copy(p, "logs/" + p.name)
copy("target/compact-intern-inputs-baseline.txt", "logs/compact-intern-inputs-baseline.txt")
for name in ("compact-intern-pools-focused-load.json", "compact-intern-pools-full-load.json", "compact-intern-pools-prebuild-sources.json", "performance_phase65_status.md"):
    copy("target/" + name, "conditions/" + name)
for name in ("environment.json", "source-changes.diff", "tests/regrtest/test_compact_intern_pools.py"):
    copy("target/compact-intern-pools-source-snapshot/" + name, "candidate/" + name)
for name in ("candidate.patch", "index.json"):
    copy("target/compact-intern-pools-draft/" + name, "draft/" + name)
copy(__file__, "methods/" + Path(__file__).name)

work = full["cohorts"]["all_23_workloads_excluding_startup"]["metrics"]["jit"]["ns"]
hist = full["cohorts"]["historical_21_including_startup"]["metrics"]["jit"]
proc = full["cohorts"]["all_processes_including_startup"]["metrics"]["jit"]
lines = ["# Compact canonical-string intern pools", "",
    "The overall performance goal remains unachieved.", "",
    "Candidate a1e87c1a replaces two private String-keyed maps with sets of the",
    "existing canonical Rc<str> objects. It removes duplicate key text and copies",
    "on intern/status lookups. The per-thread sys pool and separate global stable-",
    "name pool retain their boundaries, strong ownership, and object identities.",
    "Pointer-sensitive marshal status, single-character construction, and existing",
    "WStr behavior remain intact. No dependency, unsafe code, public API, object",
    "representation, new cache, or pool-lifetime change is introduced.", "",
    "The binary is 44,289,520 bytes, 1,280 fewer than immediate predecessor",
    "5b299d93. The candidate includes preceding experimental JIT/call changes and",
    "their recorded regressions. Comparisons with 5b299d93 isolate the intern work.", "",
    "All 342 VM tests, formatting, Clippy, no-default-feature check, 66 targeted",
    "release checks, 275 standard compatibility checks, and six extra CPython",
    "sys/marshal/inspection/pathlib/copy/copyreg suites pass. The new identity test",
    "and all nine workload oracles first passed on CPython and unchanged WeavePy",
    "in JIT, interpreter-only, and gil=0 correctness modes. Runtime snapshots",
    "identify all sources and binaries. GIL-disabled correctness isn't a native",
    "parallel-performance measurement.", "",
    "The nine focused controls use seven paired samples of both modes of the",
    "candidate, immediate predecessor, retained 539c, and CPython. Warm cases",
    "exercise lookups and marshal status; first-invocation cases grow fresh pools.",
    "All values and per-binary frozen-cache checks pass. Lower ratios are better.", "",
    "| Case | Mode | Time / predecessor | RSS / predecessor | Time / CPython | RSS / CPython |",
    "| --- | --- | ---: | ---: | ---: | ---: |"]
for name, row in focused["rows"].items():
    for mode in ("jit", "interp"):
        prev = row["new_over_previous"][mode]
        cp = row["new_over_cpython"][mode]
        lines.append(f"| {name} | {mode} | {prev['ns']:.4f} | {prev['rss_bytes']:.4f} | {cp['ns']:.4f} | {cp['rss_bytes']:.4f} |")
lines += ["",
    "JIT intern-hit times improve about 6 percent, with all seven pairs faster in",
    "each size. Pooled/plain marshal times improve about 4/3 percent, also with",
    "all pairs faster. Long-string growth uses about 25 percent less peak RSS and",
    "Unicode growth about 13 percent less; every focused JIT RSS pair improves.",
    "Short-string growth JIT time regresses about 1.4 percent, with six of seven",
    "pairs slower. Type-name access has a 0.13 percent slower JIT median. These",
    "regressions remain in the evidence; no focused CPython win is claimed.", "",
    "The full suite retains all 24 unchanged fixtures with five pairs and nine",
    "startup/import controls with 31 pairs. Its baseline is the immediate",
    "predecessor, isolating this memory change. The startup helper disables JIT.", "",
    f"The 23-workload JIT mean is {work['new_over_base']:.6f} of its predecessor and",
    f"{work['new_over_cpython']:.6f} of CPython, with {work['weavepy_wins']} of 23 time wins.",
    f"The historical 21-fixture cohort is {hist['ns']['new_over_cpython']:.6f} of CPython,",
    f"or {hist['ratio_of_medians_new_over_cpython']:.6f} using ratios of medians.", "",
    f"All-24 process wall/CPU/RSS ratios to its predecessor are {proc['wall_ns']['new_over_base']:.6f},",
    f"{proc['cpu_ns']['new_over_base']:.6f}, and {proc['rss_bytes']['new_over_base']:.6f}.",
    f"Peak RSS is {proc['rss_bytes']['new_over_cpython']:.6f} of CPython, with {proc['rss_bytes']['weavepy_wins']} wins.", "",
    "A separate startup snapshot shows 29,638,656 bytes RSS for the predecessor",
    "and 29,229,056 for the candidate, a 409,600-byte reduction. The malloc zone",
    "reports 6344K versus 6176K allocated and 2680K versus 2416K fragmentation.",
    "These are point-in-time region diagnostics, not peak-RSS census samples.",
    "Readiness values agree; seeded caches stay unchanged; owned children were",
    "terminated after inspection. An untimed datetime coverage diagnostic also",
    "matches CPython, but its proposed assertion-exit JIT change is unapplied",
    "and isn't evidence for this candidate.", "",
    "Both timing gates qualified; every later sample and load/VM/swap observation",
    "is retained. The reports include all process wall, CPU, workload CPU where",
    "available, peak RSS, paired ranges, and regressions. Keep the 21/23/24 cohorts",
    "distinct and use same-run paired ratios for change attribution. No universal,",
    "energy, controlled build-time, portability, or free-threaded superiority is",
    "established. The observed release build duration isn't a controlled metric.", "",
    "Large raw JSON/log artifacts are compressed losslessly. The index records",
    "both stored and uncompressed SHA-256 hashes and sizes. No measurement sample",
    "is removed. Executables, frozen caches, and unselected temporary files stay",
    "local and outside Git. Summaries, protocols, and code remain directly readable.", ""]
(out / "REPORT.md").write_text("\n".join(lines))
p = out / "REPORT.md"
records.append({"path": p.name, "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
(out / "index.json").write_text(json.dumps(records, indent=2) + "\n")
for row in records:
    data = (out / row["path"]).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row["sha256"]
    if "uncompressed_sha256" in row:
        raw = gzip.decompress(data) if row["path"].endswith(".gz") else data
        assert hashlib.sha256(raw).hexdigest() == row["uncompressed_sha256"]
with (parent / ".gitignore").open("a") as f:
    f.write("\n# Compact intern pools, with lossless raw-result compression.\n")
    for p in sorted(out.rglob("*")):
        if p.is_file():
            f.write("!" + str(p.relative_to(parent)) + "\n")
with (parent / "README.md").open("a") as f:
    f.write("\nThe [compact intern-pool experiment](compact-intern-pools/REPORT.md) removes\nduplicate string keys, improving intern-hit and marshal controls while reducing\nstring-pool memory. Complete paired results retain the short-string insertion\nregression and the remaining CPython gaps. Large raw artifacts are compressed\nlosslessly, with stored and original hashes recorded.\n")
print("Exported", len(records) + 1, "files;", sum(p.stat().st_size for p in out.rglob("*") if p.is_file()), "bytes; all stored and uncompressed hashes verified.")

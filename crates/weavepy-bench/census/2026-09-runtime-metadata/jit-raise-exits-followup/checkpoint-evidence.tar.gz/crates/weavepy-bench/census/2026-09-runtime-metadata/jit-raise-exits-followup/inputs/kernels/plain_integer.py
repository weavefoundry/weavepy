def plain_integer(n):
    total = 0
    for i in range(n):
        total += i
    return total

def bench(n):
    total = 0
    for i in range(n):
        total += plain_integer(512)
    return total

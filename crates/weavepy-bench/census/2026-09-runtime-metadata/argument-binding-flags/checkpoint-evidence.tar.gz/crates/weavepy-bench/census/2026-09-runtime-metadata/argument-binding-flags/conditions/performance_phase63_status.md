# Inline binding flags for small signatures

Early-entry experiment 95b is complete and archived in 219 files, 2,806,700
bytes; every indexed SHA verified. Its full workload mean is 0.995867409 to
retained539c and 3.396538607 to CPython. All-24 RSS is 1.001810284 to 539c and
2.072558215 to CPython, zero wins. Focused dispersion and regressions remain
explicitly recorded; the early-entry path remains experimental.

No owned build/test/timing job was active when the hash-verified binder draft
was applied. Only bind_python_args flag storage changes: up to 16 argument
slots stay inline, larger signatures use a heap slice, and flags no longer
cover unused body locals. Every positional, keyword-only, *args, and **kwargs
flag still exists independently of Object::Unbound. No new unsafe/cache/field.
Argument value movement, error precedence, defaults, and flag accesses remain
unchanged. cargo fmt completed before freezing prebuild hashes and 19 methods.

The new test covers counts 0/1/14/15/16/17/31/32/33/64/65/130, keyword-only and
variadic slots, excess defaults, duplicate/missing errors, and many body locals.
Its baseline preflight passes CPython, 539c, and 95b in JIT/interpreter/gil0.
The candidate itself is not compiled, validated, or measured yet.

Focused comparison will include both immediate 95b and retained539c references,
28 cases, seven paired samples per mode/binary and CPython, with exact values
and frozen caches. Full census uses retained539c. Both have fresh strict load
gates. Preserve all samples, failures, regressions, and source identities.

96897 CLOSED 0. All 342 VM tests passed, formatting/Clippy/no-default-features
passed, and the release CLI built in an observed 5m55s (not a controlled build
metric). Candidate e5077bbae5256f8c4f8e7d9c38a636fb21ff5dc467a15418477e71f224199d70
is 44,290,720 bytes, unchanged from immediate 95b. Snapshot, prebuild sources,
19 method hashes, and both executable hashes verified. 60853 is running the
63 targeted release checks; independent 73783 is running five extra suites.
No performance timing has begun.

A separate signature-path inspection script was frozen after the build began,
in binder-flags-signature-path-method. It records actual compiled functions,
rejections, and native/generic counters for all ten new signature controls.
Large signatures may validly stay interpreted; matching values and reported
paths don't establish native execution for every benchmark.

60853 CLOSED 0: all 63 targeted checks plus instrumented regression passed.
73783 CLOSED 0: all five extra suites passed. 59881 CLOSED 0: original ten
native-entry oracles and ten new signature controls match CPython. However,
many_body_locals v1 showed 850 native-to-native calls and only three generic
calls: specifying both parameters let it bypass the binder. No timing existed.

Preserved v1 inputs, methods, and traces. Prepared binder-flag-inputs-v2: only
many_body_locals source changes, adding an omitted third defaulted parameter.
The other nine source hashes are identical. V2 signature inspection asserts
>=500 generic dynamic calls for that case. New focused_v2 launcher requires
this inspection; original scripts and snapshot remain unchanged. Frozen v2
measurement bundle has 23 method files. Full runtime/hash still e507, unchanged.
56445 continues full compatibility validation. No candidate timing has begun.

67970 CLOSED 1: the v2 generic-path assertion correctly failed. Trailing omitted
defaults are already optimized too: 850 native-to-native calls, three generic
calls, exact CPython values still match. No timing samples exist. Preserve v2
inputs, method bundle, report, log, and failed assertion. V3 supplies a and d
while omitting b/c in the middle, the same sparse layout already proven in the
original call controls. Only that changed case is re-inspected; the other nine
source hashes match v1/v2. Frozen v3 method bundle contains 26 files. Runtime
sources and release identity remain unchanged. Use focused_v3 only after its
explicit >=500 generic dynamic call assertion passes.

V3 coverage CLOSED 0: the corrected many-body-local control records 854 generic
dynamic calls in both binaries. The retained539c run has 855 framed entries and
two direct calls; candidate e507 has three framed entries and 854 direct calls.
All exact CPython values match. Its sparse layout now exercises the binder.

56445 CLOSED 0: all 275 compatibility checks passed. All owned validation jobs
are finished. Verified runtime and all 26 v3 method hashes unchanged before
launching the focused strict gate. The v1/v2 preparation history and v2 failed
coverage assertion remain preserved. No previous candidate timing is replaced.
No allocation-history profile was run; source storage changes and future RSS
timers must not be presented as measured malloc counts.

73968 CLOSED 0: all 28 focused cases completed, seven samples for all seven
variants (both modes of e507/95b/539c plus CPython). Exact values and frozen
cache checks all pass. Gate qualified; all later load and samples retained.
Small sparse-keyword, keyword-only, and many-local timers improve about 2-3%
relative to 95b, while combined variadic/keyword-only/closure cases remain
about 5-6% slower than retained539c. The corrected many-body-local case is
0.9726 of 95b, 0.5951 of 539c, and 0.6454 of CPython workload time, but this
single new control is not a full-suite or process-memory win. Every exception,
method, large-signature, process, and memory result remains in the summary.
The earlier entry regression is not resolved. No candidate acceptance yet.

49002 CLOSED 0. Full qualified run completed all 24 fixtures x five pairs and
nine startup/import controls x 31 pairs, with every sample/load/VM/swap record
retained. All source hashes remained unchanged. JIT 23-workload new/539c mean
is 0.988700693 (about 1.1% lower time); process wall/CPU ratios are 0.993514116
and 0.993400576. Peak RSS is 1.000465336 of 539c, essentially unchanged.
Call overhead = 0.918578089 of 539c, while list_ops = 1.015435059. The full
23-workload CPython ratio is 3.442986859, with six wins. Historical 21 paired
ratio = 2.117416509, ratio of medians = 2.119443631. All-24 RSS/CPython =
2.072177776, zero wins. Raw CPython ratios from different runs are not a
controlled progression; same-run paired reference comparisons remain primary.

The combined entry/storage change remains experimental because fallback
regressions persist. Preserve its archive before changing runtime code. A
separate outlined helper draft is prepared but unapplied. A startup region
snapshot diagnostic will run now, after timing, to guide memory investigation.

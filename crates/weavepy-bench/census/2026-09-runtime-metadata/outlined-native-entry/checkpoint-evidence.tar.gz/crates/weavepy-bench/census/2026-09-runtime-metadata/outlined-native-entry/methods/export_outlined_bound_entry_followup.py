"""Archive the complete outlined-entry experiment without executable/cache trees."""
import hashlib
import json
from pathlib import Path

parent = Path("crates/weavepy-bench/census/2026-09-runtime-metadata")
out = parent / "outlined-native-entry"
assert not out.exists()
for group in ("focused", "full"):
    assert Path("target/outlined-bound-entry-" + group + "/stage.txt").read_text().strip() == "done"
    assert json.loads(Path("target/outlined-bound-entry-" + group + "-load.json").read_text())["status"] == "complete"
focused = json.loads(Path("target/outlined-bound-entry-focused/summary.json").read_text())
full = json.loads(Path("target/outlined-bound-entry-full/summary.json").read_text())
validation = json.loads(Path("target/outlined-bound-entry-validation/validation.json").read_text())
assert len(validation) == 275 and all(row["passed"] for row in validation)
out.mkdir()
records = []


def copy(src, dst):
    src = Path(src)
    p = out / dst
    p.parent.mkdir(parents=True, exist_ok=True)
    data = src.read_bytes()
    p.write_bytes(data)
    records.append({"path": str(dst), "source": str(src), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})


def folder(src, dst, recursive=False):
    src = Path(src)
    for p in sorted(src.rglob("*") if recursive else src.iterdir()):
        if p.is_file() and p.suffix in (".py", ".json", ".txt", ".md", ".sh", ".s", ".patch"):
            copy(p, str(Path(dst) / p.relative_to(src)))


for group in ("focused", "full"):
    folder("target/outlined-bound-entry-" + group, group)
for group in ("calls", "signatures", "exceptions", "cold-exceptions"):
    copy("target/outlined-bound-entry-focused/" + group + "/measurements.json", "focused/" + group + ".json")
for group in ("checks", "validation", "extra-checks", "coverage", "signature-paths-v3"):
    folder("target/outlined-bound-entry-" + group, "checks/" + group)
folder("target/outlined-bound-entry-measurement-inputs", "methods/frozen")
folder("target/binder-flag-inputs-v3", "inputs/signatures")
folder("target/bound-native-entry-inputs", "inputs/original-controls", True)
folder("target/outlined-bound-entry-call-assembly", "assembly/new")
folder("target/binder-flags-call-assembly", "assembly/previous")
for p in sorted(Path("target").glob("outlined-bound-entry-*.txt")):
    copy(p, "logs/" + p.name)
for name in ("outlined-bound-entry-focused-load.json", "outlined-bound-entry-full-load.json", "outlined-bound-entry-prebuild-sources.json", "performance_phase64_status.md"):
    copy("target/" + name, "conditions/" + name)
for name in ("environment.json", "source-changes.diff", "tests/regrtest/test_bound_native_entry.py", "tests/regrtest/test_argument_binding_storage.py"):
    copy("target/outlined-bound-entry-source-snapshot/" + name, "candidate/" + name)
for name in ("candidate.patch", "index.json"):
    copy("target/outlined-bound-entry-draft/" + name, "draft/" + name)
copy(__file__, "methods/" + Path(__file__).name)

work = full["cohorts"]["all_23_workloads_excluding_startup"]["metrics"]["jit"]["ns"]
hist = full["cohorts"]["historical_21_including_startup"]["metrics"]["jit"]
proc = full["cohorts"]["all_processes_including_startup"]["metrics"]["jit"]
lines = ["# Outlined native-entry eligibility", "",
    "Status: **under refinement**. The overall performance goal remains unachieved.", "",
    "Candidate 5b299d93 moves the existing post-binding eligibility predicates into",
    "a helper with inlining disabled, then delegates to the existing guarded",
    "native-entry routine. It adds no cache, allocation, object field, unsafe code,",
    "or permanent deoptimization policy. It includes the preceding inline binding",
    "flags and post-binding entry changes. The binary is 44,290,800 bytes, 80 more",
    "than e507 and 240 more than retained 539c.", "",
    "All 342 VM tests, formatting, Clippy, no-default-feature check, 63 targeted",
    "release checks, 275 compatibility checks, five extra call/inspection/copy",
    "suites, and native-entry coverage checks pass. The corrected many-body-local",
    "control retains 854 generic calls and replaces 852 framed entries with direct",
    "entries. All focused outputs agree with CPython before and after warmup.", "",
    "Assembly confirms a separate helper and a tail branch to native entry. The",
    "caller reserves 0x700 bytes after saved registers, versus e507's 0x6a0. The",
    "proposed stack reduction did not materialize. An initial symbol search also",
    "selected a closure and stopped before disassembly; corrected exact-symbol",
    "captures are preserved. Stack reservation alone does not establish timing.", "",
    "The same 28 focused cases use seven paired samples of both modes of the",
    "candidate, immediate e507, retained 539c, and CPython. The table gives JIT",
    "workload-time paired medians. Lower is better. Every sample, range, CPU,",
    "process wall, RSS, interpreter-only result, and frozen-cache check is in JSON.", "",
    "| Case | Time / e507 | Time / 539c | Time / CPython | Faster than 539c pairs |",
    "| --- | ---: | ---: | ---: | ---: |"]
for name, row in focused["rows"].items():
    lines.append(f"| {name} | {row['new_over_previous']['jit']['ns']:.4f} | {row['new_over_reference']['jit']['ns']:.4f} | {row['new_over_cpython']['jit']['ns']:.4f} | {row['pairs']['reference']['jit']['ns']['improved_pairs']}/7 |")
lines += ["",
    "Several original call shapes improve about 2-4 percent versus e507. Sparse",
    "keyword and many-local controls remain faster than retained 539c, while",
    "variadic, keyword-only, and closure controls remain about 4-6 percent slower.",
    "Some large-default controls regress about 1 percent against e507. This",
    "experiment does not resolve those fallback regressions.", "",
    "The full run uses all 24 unchanged fixtures with five pairs and nine startup/",
    "import controls with 31 pairs. The startup helper disables JIT. The full",
    "baseline is retained 539c, so this measures the combined entry/binding work.", "",
    f"The 23-workload JIT mean is {work['new_over_base']:.6f} of retained 539c and",
    f"{work['new_over_cpython']:.6f} of CPython, with {work['weavepy_wins']} of 23 time wins.",
    f"The historical 21-fixture mean is {hist['ns']['new_over_cpython']:.6f} of CPython,",
    f"or {hist['ratio_of_medians_new_over_cpython']:.6f} using ratios of medians.", "",
    f"All-24 process wall/CPU/RSS ratios to 539c are {proc['wall_ns']['new_over_base']:.6f},",
    f"{proc['cpu_ns']['new_over_base']:.6f}, and {proc['rss_bytes']['new_over_base']:.6f}.",
    f"Peak RSS is {proc['rss_bytes']['new_over_cpython']:.6f} of CPython, with {proc['rss_bytes']['weavepy_wins']} wins.", "",
    "Both timing gates qualified. All later load observations and samples remain",
    "preserved. Compare candidates within the same paired run; different CPython",
    "means across separate runs are not a controlled performance trend. Keep the",
    "21/23/24 cohorts distinct. No universal, energy, controlled build-time,",
    "portability, or free-threaded superiority is established.", "",
    "The index identifies selected artifacts by SHA-256. Executables, frozen",
    "caches, and unselected temporary files remain local and outside Git. The",
    "proposed compact intern pools are a separate, unmeasured change.", ""]
(out / "REPORT.md").write_text("\n".join(lines))
p = out / "REPORT.md"
records.append({"path": p.name, "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
(out / "index.json").write_text(json.dumps(records, indent=2) + "\n")
for row in records:
    assert hashlib.sha256((out / row["path"]).read_bytes()).hexdigest() == row["sha256"]
with (parent / ".gitignore").open("a") as f:
    f.write("\n# Outlined native eligibility and complete paired evidence.\n")
    for p in sorted(out.rglob("*")):
        if p.is_file():
            f.write("!" + str(p.relative_to(parent)) + "\n")
with (parent / "README.md").open("a") as f:
    f.write("\nThe [outlined native-entry experiment](outlined-native-entry/REPORT.md)\nimproves several call controls versus its immediate predecessor but retains\nfallback regressions against the earlier reference. Its complete focused and\nfull results, assembly, correctness checks, and load telemetry are preserved.\nThe performance goal remains unachieved.\n")
print("Exported", len(records) + 1, "files;", sum(p.stat().st_size for p in out.rglob("*") if p.is_file()), "bytes; all indexed hashes verified.")

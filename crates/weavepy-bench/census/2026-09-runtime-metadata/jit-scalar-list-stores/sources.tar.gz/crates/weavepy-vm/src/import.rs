//! Module loading and `sys.modules` cache.
//!
//! Implements the runtime half of RFC 0012:
//!
//! - [`ModuleCache`] owns `sys.modules` and `sys.path`, plus a
//!   registry of *built-in* (Rust-defined) module factories.
//! - The cache is consulted on every `IMPORT_NAME`; the loader walks
//!   the dotted name, asking the registry first, then the filesystem.
//! - Loaded modules are executed in their own globals dict so
//!   submodule globals don't leak into siblings.
//!
//! Anything user-visible — `Object::Module`, `__name__`,
//! attribute access — lives in `object.rs` and the dispatch loop.
//! This file is the *plumbing* that turns a dotted name into a
//! cached `Rc<PyModule>`.

use crate::sync::Rc;
use crate::sync::RefCell;
use std::collections::HashMap;
use std::path::{Path, PathBuf};

use crate::object::{DictData, DictKey, Object, PyModule, StrKey};

/// Build a fresh built-in module given the live cache (so factories
/// can read `sys.argv` / `sys.path` at construction time).
pub type BuiltinModuleFactory = fn(&ModuleCache) -> Rc<PyModule>;

pub use crate::stdlib::frozen_sources::FrozenSource;

/// Shared runtime state for the import machinery.
///
/// All three `Rc`-wrapped fields double as the corresponding `sys`
/// attributes so mutations from Python code (e.g.
/// `sys.path.append("…")`) flow straight back to the loader, and CLI
/// updates (`set_argv` / `add_to_path`) are immediately visible to
/// the running script.
#[allow(missing_debug_implementations)]
#[derive(Clone)]
pub struct ModuleCache {
    pub modules: Rc<RefCell<DictData>>,
    pub path: Rc<RefCell<Vec<Object>>>,
    pub argv: Rc<RefCell<Vec<Object>>>,
    pub builtins: Rc<RefCell<HashMap<&'static str, BuiltinModuleFactory>>>,
    /// Pure-Python modules baked into the binary. Looked up after
    /// Rust-defined built-ins so a host can override frozen stdlib by
    /// registering a builtin with the same name.
    pub frozen: Rc<RefCell<HashMap<&'static str, FrozenSource>>>,
    /// RFC 0057 WS3 — `_imp._override_frozen_modules_for_tests` state:
    /// `0` default, `1` force-enabled, `-1` force-disabled. CPython's
    /// override disables every *non-essential* frozen module (imports
    /// fall back to the on-disk stdlib); WeavePy's frozen registry *is*
    /// the stdlib with no disk twin on `sys.path`, so every module is
    /// "essential" except the CPython frozen *test* modules
    /// (`__hello__` / `__phello__…`), which `test_frozen` toggles via
    /// `test.support.import_helper.frozen_modules()`.
    pub frozen_tests_override: Rc<crate::sync::Cell<i32>>,
    /// Names whose module body is currently executing — CPython's
    /// `spec._initializing` window — mapped to the executing thread's
    /// id. Attribute misses and `IMPORT_FROM` failures on these modules
    /// carry the "(most likely due to a circular import)" hint
    /// (test_import.CircularImportTests); the holder id lets a *racing*
    /// import from another thread block until the body finishes, like
    /// CPython's per-module import lock (bpo-34572,
    /// test_pickle test_unpickle_module_race).
    pub initializing: Rc<RefCell<std::collections::HashMap<String, u64>>>,
    /// Names currently inside `load_one`'s find+create+exec sequence,
    /// mapped to the loading thread — CPython's per-module
    /// `_ModuleLockManager` window, which is *wider* than
    /// `spec._initializing`: it opens before the finders run. Without
    /// it, two threads that both miss `sys.modules` race into loading
    /// the same source and the body executes twice (bpo-34572;
    /// test_pickle test_unpickle_module_race).
    pub loading: Rc<RefCell<std::collections::HashMap<String, u64>>>,
    /// Which module each blocked thread is currently waiting to import
    /// — CPython `_bootstrap._blocking_on`, used for import-lock
    /// deadlock detection (`_ModuleLock.has_deadlock`).
    pub import_waiting: Rc<RefCell<std::collections::HashMap<u64, String>>>,
    /// The script directory / cwd the host prepended at startup —
    /// CPython's `config->sys_path_0`. The module-shadowing diagnostics
    /// compare against this snapshot, not live `sys.path`, so user
    /// mutations don't defeat the hint (test_import's
    /// test_script_shadowing_stdlib_sys_path_modification).
    pub startup_path0: Rc<RefCell<Option<String>>>,
    /// Whether the *startup* `os` import (the native fast path — the
    /// analogue of CPython's frozen `os`) has already run. CPython 3.13
    /// imports `os` frozen during startup but a later fresh import
    /// resolves the real `Lib/os.py` source (`os.__spec__.loader` is
    /// `SourceFileLoader`, `cached` a real pyc —
    /// test.support.import_helper.import_fresh_module('os') +
    /// test_pydoc test_synopsis_sourceless observe exactly this). Once
    /// set, a fresh `import os` skips the builtin factory and executes
    /// the projected source like any frozen module.
    pub os_native_done: Rc<crate::sync::Cell<bool>>,
}

impl Default for ModuleCache {
    fn default() -> Self {
        Self {
            modules: Rc::new(RefCell::new(DictData::default())),
            path: Rc::new(RefCell::new(Vec::new())),
            argv: Rc::new(RefCell::new(Vec::new())),
            builtins: Rc::new(RefCell::new(HashMap::new())),
            frozen: Rc::new(RefCell::new(HashMap::new())),
            frozen_tests_override: Rc::new(crate::sync::Cell::new(0)),
            initializing: Rc::new(RefCell::new(std::collections::HashMap::new())),
            loading: Rc::new(RefCell::new(std::collections::HashMap::new())),
            import_waiting: Rc::new(RefCell::new(std::collections::HashMap::new())),
            startup_path0: Rc::new(RefCell::new(None)),
            os_native_done: Rc::new(crate::sync::Cell::new(false)),
        }
    }
}

/// Whether `name` is one of CPython's frozen *test* modules — the
/// only frozen names `_imp._override_frozen_modules_for_tests` can
/// actually disable in WeavePy (see `ModuleCache::frozen_source`).
/// Mirrors the TEST section of CPython's frozen-module table.
pub fn is_test_frozen_name(name: &str) -> bool {
    name == "__hello__"
        || name == "__hello_alias__"
        || name == "__hello_only__"
        || name == "__phello_alias__"
        || name.starts_with("__phello_alias__.")
        || name == "__phello__"
        || name.starts_with("__phello__.")
}

impl ModuleCache {
    pub fn register_builtin(&self, name: &'static str, factory: BuiltinModuleFactory) {
        self.builtins.borrow_mut().insert(name, factory);
    }

    /// Cache hit lookup. Returns `None` if not yet loaded.
    pub fn get(&self, full_name: &str) -> Option<Object> {
        self.modules.borrow().get(&StrKey(full_name)).cloned()
    }

    /// Install a loaded module in the cache. CPython treats
    /// `sys.modules` writes as authoritative — subsequent imports
    /// of the same name return whatever is in the cache, regardless
    /// of whether the original loader has finished.
    pub fn insert(&self, full_name: &str, module: Object) {
        // CPython tracks module objects with the cycle GC (`gc.is_tracked(gc)`
        // is True); a module's globals routinely close cycles (a function
        // defined in the module captures the module's dict). Track on install.
        if matches!(module, Object::Module(_)) {
            crate::gc_trace::track(module.clone());
        }
        self.modules
            .borrow_mut()
            .insert(DictKey(Object::from_str(full_name)), module);
    }

    pub fn remove(&self, full_name: &str) {
        self.modules.borrow_mut().shift_remove(&StrKey(full_name));
    }

    /// Mark/unmark `full_name`'s body as executing (the
    /// `spec._initializing` window) and query membership.
    pub fn begin_initializing(&self, full_name: &str) {
        self.initializing
            .borrow_mut()
            .insert(full_name.to_owned(), crate::gil::current_thread_id());
    }
    pub fn end_initializing(&self, full_name: &str) {
        self.initializing.borrow_mut().remove(full_name);
    }
    pub fn is_initializing(&self, full_name: &str) -> bool {
        self.initializing.borrow().contains_key(full_name)
    }
    /// The thread currently executing `full_name`'s body, if any.
    pub fn initializing_holder(&self, full_name: &str) -> Option<u64> {
        self.initializing.borrow().get(full_name).copied()
    }
    /// Atomically claim the find+load window for `full_name`. Returns
    /// `true` when this call took the claim (the caller must release it
    /// via [`Self::end_loading`]); `false` when `me` already holds it
    /// (nested re-entry — the outer frame owns the release).
    pub fn try_begin_loading(&self, full_name: &str, me: u64) -> Option<bool> {
        let mut map = self.loading.borrow_mut();
        match map.get(full_name) {
            Some(&h) if h != me => None,
            Some(_) => Some(false),
            None => {
                map.insert(full_name.to_owned(), me);
                Some(true)
            }
        }
    }
    pub fn end_loading(&self, full_name: &str) {
        self.loading.borrow_mut().remove(full_name);
    }
    /// The thread currently inside `load_one` for `full_name`, if any.
    pub fn loading_holder(&self, full_name: &str) -> Option<u64> {
        self.loading.borrow().get(full_name).copied()
    }
    /// Record / clear which module `thread` is blocked importing —
    /// CPython's `_blocking_on` table, consulted by
    /// [`Self::import_wait_would_deadlock`].
    pub fn set_import_waiting(&self, thread: u64, module: Option<&str>) {
        let mut map = self.import_waiting.borrow_mut();
        match module {
            Some(m) => {
                map.insert(thread, m.to_owned());
            }
            None => {
                map.remove(&thread);
            }
        }
    }
    /// Whether `me` blocking on `full_name` closes a holder→waiter
    /// cycle — CPython `_ModuleLock.has_deadlock`. Walk holder(module)
    /// → module-that-holder-waits-on → … until the chain dies out or
    /// reaches `me`.
    pub fn import_wait_would_deadlock(&self, me: u64, full_name: &str) -> bool {
        let initializing = self.initializing.borrow();
        let loading = self.loading.borrow();
        let waiting = self.import_waiting.borrow();
        let mut name = full_name.to_owned();
        // Bounded walk: chains are at most one hop per live thread.
        for _ in 0..128 {
            // A name can be held at either lock level: the body-executing
            // window (`initializing`) or the wider find+load window.
            let holder = initializing.get(&name).or_else(|| loading.get(&name));
            let Some(&holder) = holder else {
                return false;
            };
            if holder == me {
                return true;
            }
            let Some(next) = waiting.get(&holder) else {
                return false;
            };
            name = next.clone();
        }
        false
    }

    pub fn builtin_factory(&self, name: &str) -> Option<BuiltinModuleFactory> {
        self.builtins.borrow().get(name).copied()
    }

    /// The `&'static` registration name for a built-in module, if one is
    /// registered under `name`. Lets the loader attribute a freshly built
    /// module's functions to it (`fn.__module__`) without leaking a new
    /// `&'static str` on every import.
    pub fn builtin_static_name(&self, name: &str) -> Option<&'static str> {
        self.builtins.borrow().get_key_value(name).map(|(k, _)| *k)
    }

    /// Register a Python-source module that ships inside the binary.
    /// The loader compiles and executes it lazily on first import.
    pub fn register_frozen(&self, source: FrozenSource) {
        self.frozen.borrow_mut().insert(source.name, source);
    }

    pub fn frozen_source(&self, name: &str) -> Option<FrozenSource> {
        // `frozen_modules(enabled=False)` (i.e. the override at `-1`)
        // hides the frozen test modules from every consumer — the
        // loader, `_imp.is_frozen`/`find_frozen`, `sys._is_frozen` —
        // exactly as CPython's `find_frozen` reports "not frozen" for
        // non-essential names under the override. Imports then fall
        // through to the on-disk copy (see `find_source`).
        if self.frozen_tests_override.get() < 0 && is_test_frozen_name(name) {
            return None;
        }
        self.frozen.borrow().get(name).copied()
    }

    /// Set the `_imp._override_frozen_modules_for_tests` knob
    /// (`0` reset / `1` force-enabled / `-1` force-disabled).
    pub fn set_frozen_tests_override(&self, value: i32) {
        self.frozen_tests_override.set(value);
    }

    /// The *live* `sys.path` list. The loader must read this rather than
    /// the cached `self.path` Rc because Python code can **rebind**
    /// `sys.path` (`sys.path = [...]`) — replacing the list object
    /// instead of mutating the shared one. `multiprocessing`'s spawn
    /// child does exactly this in `spawn.prepare()` (`sys.path =
    /// data['sys_path']`), so a child that only sees the stale `self.path`
    /// can't locate on-disk submodules. CPython's import system always
    /// consults `sys.modules['sys'].path`; mirror that, falling back to
    /// the aliased Rc when the `sys` module isn't built yet (early init).
    pub(crate) fn live_sys_path(&self) -> Vec<Object> {
        if let Some(Object::Module(sys_mod)) = self.get("sys") {
            if let Some(Object::List(l)) = sys_mod
                .dict
                .borrow()
                .get(&DictKey(Object::from_static("path")))
            {
                return l.borrow().clone();
            }
        }
        self.path.borrow().clone()
    }

    /// Whether any *live* `sys.path` entry is a zip/archive candidate:
    /// the entry itself is a file, or — a directory *inside* an archive
    /// (`pkgs.zip/subdir`) — some ancestor is. Namespace-package
    /// assembly hands off to the Python `PathFinder` in that case so
    /// `zipimport` portions merge in.
    pub fn has_archive_path_entry(&self) -> bool {
        fn is_archive_entry(p: &Path) -> bool {
            for anc in p.ancestors() {
                if anc.is_file() {
                    return true;
                }
                if anc.exists() {
                    return false;
                }
            }
            false
        }
        self.live_sys_path()
            .iter()
            .any(|entry| matches!(entry, Object::Str(s) if is_archive_entry(Path::new(s.as_ref()))))
    }

    /// Snapshot the current `sys.path` as a list of `PathBuf`s,
    /// dropping entries that aren't strings. Cheap enough for the
    /// inner loop because `sys.path` is short.
    pub fn search_dirs(&self) -> Vec<PathBuf> {
        self.live_sys_path()
            .iter()
            .filter_map(|o| match o {
                Object::Str(s) => Some(PathBuf::from(s.as_ref())),
                _ => None,
            })
            .collect()
    }

    /// CPython `FileFinder`'s case check (`_relax_case`): the on-disk
    /// spelling of `path`'s final component must match the requested
    /// name byte-for-byte, even on case-insensitive filesystems —
    /// `import RAnDoM` must not resolve `random.py`
    /// (test_import.test_case_sensitivity). `PYTHONCASEOK` relaxes it.
    pub(crate) fn entry_case_ok(path: &Path) -> bool {
        if std::env::var_os("PYTHONCASEOK").is_some() {
            return true;
        }
        let (Some(dir), Some(name)) = (path.parent(), path.file_name()) else {
            return true;
        };
        match std::fs::read_dir(dir) {
            Ok(rd) => rd.flatten().any(|e| e.file_name() == name),
            Err(_) => true,
        }
    }

    /// Locate a module's source on disk by walking `sys.path`.
    ///
    /// Returns:
    /// - `Some((path, is_package))` where `is_package` is `true` for
    ///   `<dir>/<leaf>/__init__.py` matches.
    /// - `None` if the module is not present anywhere on the path.
    pub fn find_source(&self, full_name: &str) -> Option<(PathBuf, bool)> {
        // While frozen imports are enabled, CPython's FrozenImporter sits
        // *ahead* of PathFinder on `sys.meta_path`, so a disk copy of a
        // frozen test module (e.g. a vendored CPython `Lib/__phello__/`)
        // never wins — `test_frozen` asserts `__spec__.loader is
        // FrozenImporter` even with `Lib/` on `sys.path`. Only the `-1`
        // override (`frozen_modules(enabled=False)`) re-enables the disk
        // fallback below.
        if self.frozen_tests_override.get() >= 0
            && is_test_frozen_name(full_name)
            && self.frozen.borrow().contains_key(full_name)
        {
            return None;
        }
        let rel: PathBuf = full_name.split('.').collect();
        // The materialized stdlib tree also projects the bundled
        // *third-party facades* (`numpy.py`, `packaging.py`, …) to disk,
        // and in a venv the tree directory sits on `sys.path` ahead of
        // site-packages. Those projections are identity labels for the
        // frozen sources, not installations — a real `pip install numpy`
        // in site-packages must win over them (RFC 0055 WS5), so the
        // facade names skip tree-resident matches and keep scanning.
        let skip_tree_facade = Self::is_third_party_facade(full_name);
        for dir in self.search_dirs() {
            if skip_tree_facade && crate::stdlib_tree::contains(&dir) {
                continue;
            }
            // CPython's FileFinder probes the package directory before
            // the module file within each path entry, so `t4/__init__.py`
            // shadows a sibling `t4.py` (test_pkg.test_4).
            let pkg_init = dir.join(&rel).join("__init__.py");
            if pkg_init.is_file() && Self::entry_case_ok(pkg_init.parent().unwrap_or(&pkg_init)) {
                return Some((pkg_init, true));
            }
            let module_file = dir.join(&rel).with_extension("py");
            if module_file.is_file() && Self::entry_case_ok(&module_file) {
                return Some((module_file, false));
            }
        }
        // A frozen test module hidden by the `-1` override must still be
        // importable *unfrozen*: in CPython the stdlib directory is on
        // `sys.path` and carries `__hello__.py` / `__phello__/`, so the
        // import falls through to SourceFileLoader. WeavePy's stdlib
        // position (the materialized tree) is *not* a `sys.path` entry,
        // so resolve the same fallback against the tree explicitly —
        // it holds byte-identical projections of the frozen sources.
        if self.frozen_tests_override.get() < 0 && is_test_frozen_name(full_name) {
            if let Some(frozen) = self.frozen.borrow().get(full_name) {
                if let Some(path) =
                    crate::stdlib_tree::test_frozen_disk_path(full_name, frozen.is_package)
                {
                    if path.is_file() {
                        return Some((path, frozen.is_package));
                    }
                }
            }
        }
        None
    }

    /// Locate a module on the `sys.path` entries that *precede* the
    /// stdlib's position. In CPython the stdlib resolves through its
    /// `sys.path` slot, so a `uuid.py` next to the script shadows the
    /// standard module (`test_cmd_line.test_isolatedmode`); WeavePy's
    /// frozen registry would otherwise always win. The stdlib position
    /// is the `pythonXY.zip` landmark or any directory that is itself a
    /// stdlib tree (contains `os.py` — the landmark CPython's `getpath`
    /// uses), e.g. a vendored `Lib/`; scanning stops there.
    pub fn find_source_shadowing_stdlib(&self, full_name: &str) -> Option<(PathBuf, bool)> {
        let rel: PathBuf = full_name.split('.').collect();
        for dir in self.search_dirs() {
            let leaf = dir.file_name().and_then(|n| n.to_str()).unwrap_or("");
            if leaf.starts_with("python")
                && std::path::Path::new(leaf).extension() == Some("zip".as_ref())
            {
                return None;
            }
            if dir.join("os.py").is_file() {
                return None;
            }
            // Package directory before module file, as in `find_source`.
            let pkg_init = dir.join(&rel).join("__init__.py");
            if pkg_init.is_file() && Self::entry_case_ok(pkg_init.parent().unwrap_or(&pkg_init)) {
                return Some((pkg_init, true));
            }
            let module_file = dir.join(&rel).with_extension("py");
            if module_file.is_file() && Self::entry_case_ok(&module_file) {
                return Some((module_file, false));
            }
        }
        None
    }

    /// Whether a frozen name is a bundled *third-party facade* rather
    /// than stdlib. These are PyPI projects WeavePy freezes as a
    /// convenience (`packaging`, `numpy`, `pytest`, …). In CPython they
    /// are not stdlib at all, so a real installation *anywhere* on
    /// `sys.path` — site-packages included — must win over the facade;
    /// the frozen copy is only the fallback for bare environments.
    /// (`pip install packaging` must actually change what `import
    /// packaging` returns: the facade's `Version` diverges from real
    /// packaging's — RFC 0055 WS5.)
    pub fn is_third_party_facade(full_name: &str) -> bool {
        let top = full_name.split('.').next().unwrap_or(full_name);
        matches!(
            top,
            "packaging" | "numpy" | "pytest" | "pluggy" | "iniconfig" | "exceptiongroup" | "pip"
        )
    }

    /// Locate a PEP 420 namespace package — a directory on `sys.path`
    /// with the given name that does *not* contain an `__init__.py`.
    /// Returns the list of contributing directories (matching CPython's
    /// `_NamespacePath`), or empty if no candidates exist.
    pub fn find_namespace_package(&self, full_name: &str) -> Vec<PathBuf> {
        let rel: PathBuf = full_name.split('.').collect();
        let mut hits = Vec::new();
        for dir in self.search_dirs() {
            let pkg_dir = dir.join(&rel);
            // A directory with a sourceless `__init__.pyc` is a *regular*
            // package (CPython's FileFinder checks both suffixes); it must
            // reach the Python-level fallback's SourcelessFileLoader, not
            // be swallowed as a PEP 420 namespace portion.
            if pkg_dir.is_dir()
                && !pkg_dir.join("__init__.py").is_file()
                && !pkg_dir.join("__init__.pyc").is_file()
            {
                hits.push(pkg_dir);
            }
        }
        hits
    }
}

/// Resolution of a relative import (`from . import x` /
/// `from ..pkg import y`).
///
/// `level` is the count of leading dots; `name` is the explicit
/// suffix after the dots (may be empty for bare `from . import …`).
/// Returns the fully-qualified module name to load — the same string
/// CPython's `__import__` builds internally via `_bootstrap._resolve_name`.
pub fn resolve_relative(
    package: Option<&str>,
    name: &str,
    level: u32,
) -> Result<String, &'static str> {
    if level == 0 {
        return Ok(name.to_owned());
    }
    let pkg = match package {
        Some(p) if !p.is_empty() => p,
        _ => return Err("attempted relative import with no known parent package"),
    };
    // CPython equivalent:
    //   bits = package.rsplit('.', level - 1)
    //   if len(bits) < level: raise ImportError
    //   base = bits[0]
    //
    // Rust's `rsplitn(n, '.')` matches Python's `rsplit('.', n - 1)`:
    // it yields *at most* `n` parts, rightmost first. The leftmost
    // chunk (the base we want) is therefore the last element.
    let parts: Vec<&str> = pkg.rsplitn(level as usize, '.').collect();
    if parts.len() < level as usize {
        return Err("attempted relative import beyond top-level package");
    }
    let base = parts.last().copied().unwrap_or("");
    let resolved = if name.is_empty() {
        base.to_owned()
    } else if base.is_empty() {
        name.to_owned()
    } else {
        format!("{base}.{name}")
    };
    if resolved.is_empty() {
        Err("relative import produced empty module name")
    } else {
        Ok(resolved)
    }
}

/// `__path__` for a freshly loaded package — the directory the
/// `__init__.py` was found in, wrapped in a Python list.
pub fn package_search_path(init_file: &Path) -> Object {
    let dir = init_file.parent().map_or(PathBuf::new(), Path::to_path_buf);
    let lossy = dir.to_string_lossy().into_owned();
    Object::new_list(vec![Object::from_str(lossy)])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn resolve_absolute_passes_through() {
        assert_eq!(
            resolve_relative(None, "os.path", 0).unwrap(),
            "os.path".to_owned()
        );
    }

    #[test]
    fn resolve_relative_one_level_drops_last_component() {
        // Inside package `pkg.sub`, `from . import x` reaches `pkg.sub.x`.
        assert_eq!(
            resolve_relative(Some("pkg.sub"), "x", 1).unwrap(),
            "pkg.sub.x".to_owned()
        );
    }

    #[test]
    fn resolve_relative_two_levels_drops_two() {
        // Inside `pkg.sub`, `from .. import y` reaches `pkg.y`.
        assert_eq!(
            resolve_relative(Some("pkg.sub"), "y", 2).unwrap(),
            "pkg.y".to_owned()
        );
    }

    #[test]
    fn resolve_relative_overshoot_errors() {
        let err = resolve_relative(Some("pkg"), "x", 2).unwrap_err();
        assert!(err.contains("beyond top-level"));
    }
}

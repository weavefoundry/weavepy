"""Freeze all candidate sources and methods immediately before the release build."""
import hashlib
import json
from pathlib import Path

out = Path('target/niche-string-owner-prebuild.json')
assert not out.exists()
for name, digest in json.loads(Path('target/niche-string-owner-integrated-miri-report.json').read_text())['hashes'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
paths = set(json.loads(Path('target/thin-value-storage-prebuild.json').read_text())['sources'])
paths.update(['Cargo.toml', 'Cargo.lock'])
methods = [Path('target') / name for name in [
    'build_niche_string_owner.sh', 'check_niche_string_owner.sh',
    'validate_niche_string_owner.sh', 'check_niche_string_owner_extra.py',
    'measure_niche_string_owner_focused.sh', 'measure_niche_string_owner_full.sh',
    'niche-string-owner-protocol.md', 'verify_niche_string_owner_ready.py',
    'freeze_niche_string_owner_sources.py', 'summarize_niche_string_owner.py',
    'measure_verified_python_components.py', 'freeze_runtime_candidate.py',
    'capture_runtime_environment.py', 'run_performance_under_load_gate.py', 'run_serial_performance_gate.py',
    'summarize_runtime_suite.py', 'shared_slot_keys_startup_probes.py',
    'thin-value-storage-capi-selection.toml',
    'niche-string-owner-integrated-miri-report.json',
]]
methods += [Path('tools/bench_compare.py'), Path('tests/regrtest/expectations.toml'),
    Path('crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py')]
methods += list(Path('target/thin-value-storage-inputs').rglob('*.py'))
methods += list(Path('target/thin-value-storage-inputs').rglob('preparation.json'))
def hashes(names):
    return {str(p): hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(names)}
report = {'sources': hashes(paths), 'methods': hashes(methods)}
out.write_text(json.dumps(report, indent=2) + '\n')
print('Frozen', len(report['sources']), 'sources and', len(report['methods']), 'methods/inputs.')

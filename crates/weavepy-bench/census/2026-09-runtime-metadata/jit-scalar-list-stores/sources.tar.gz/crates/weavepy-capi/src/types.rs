//! `PyTypeObject` and the `PyType_FromSpec` family.
//!
//! The C-API bridges WeavePy's `Rc<TypeObject>` (the native type
//! representation) to the C surface CPython exposes. From C the
//! type is just a pointer to a `PyObject` whose `ob_type` is
//! `PyType_Type`; from Rust we hold an `Rc<TypeObject>` so the
//! native type machinery (MRO, `__dict__`, `lookup`) keeps working.
//!
//! Three flavours of types live in this crate:
//!
//! 1. **Static built-ins** (`PyType_Type`, `PyLong_Type`,
//!    `PyUnicode_Type`, …). One static [`PyTypeObject`] per type;
//!    refcount is immortal; `bridge` points at a thread-local
//!    `Rc<TypeObject>` cloned from `BuiltinTypes` at startup.
//! 2. **Heap types from `PyType_FromSpec`**. The spec is interpreted
//!    at the call site, a fresh `Rc<TypeObject>` is built, and a
//!    heap-allocated [`PyTypeObjectBox`] is returned to the
//!    extension.
//! 3. **Capsule / module / NotImplemented types**. Single-instance
//!    types whose only role is to give their (one) instance a
//!    distinct `ob_type`.

use std::cell::UnsafeCell;
use std::ffi::CStr;
use std::os::raw::{c_char, c_int, c_void};
use std::ptr;
use std::sync::Mutex;
use weavepy_vm::sync::Rc;

use weavepy_vm::object::{BoundMethod, DictData, DictKey, Object};
use weavepy_vm::types::TypeObject;

use crate::object::{PyObject, PySsizeT, IMMORTAL_REFCNT};
use crate::slottable::SlotTable;

/// Layout of a type object as the C side sees it.
///
/// As of RFC 0043 (wave 1) this is **byte-faithful to CPython 3.13's
/// full `PyTypeObject`** for the entire documented prefix (offsets `0`
/// through `416`, i.e. `ob_base` … `tp_vectorcall` + the
/// `tp_watched`/`tp_versions_used` tail). The exact field offsets are
/// pinned, and machine-checked against the host's stock headers, in
/// [`crate::layout::PyTypeObjectFull`]; `debug_assert_type_layout`
/// cross-checks this live struct against that spec.
///
/// WeavePy's *private* bookkeeping (`tp_slots`, the native `bridge`)
/// lives **after** the 416-byte faithful region. Because CPython types
/// are variable-size (`tp_itemsize`) and extensions only ever read the
/// documented slots, those trailing fields are invisible to stock code
/// while letting native dispatch keep its `Rc<TypeObject>`.
#[repr(C)]
pub struct PyTypeObject {
    // --- byte-faithful CPython 3.13 prefix (offsets 0..416) ---
    pub head: PyObject, // 0
    /// `PyVarObject.ob_size`. Types are var-objects; this is 0 for the
    /// built-ins (CPython keeps it 0 too).
    pub ob_size: PySsizeT, // 16
    /// Type's qualified name (`module.Name` for heap types).
    pub tp_name: *const c_char, // 24
    pub tp_basicsize: PySsizeT, // 32
    pub tp_itemsize: PySsizeT, // 40
    /// Instance destructor. Stock inlined `Py_DECREF` → `_Py_Dealloc`
    /// reads this slot, so it must sit at offset 48 and be valid: for
    /// faithful built-ins it routes to the mirror/box free path.
    pub tp_dealloc: Option<crate::layout::destructor>, // 48
    pub tp_vectorcall_offset: PySsizeT, // 56
    pub tp_getattr: *mut c_void, // 64
    pub tp_setattr: *mut c_void, // 72
    pub tp_as_async: *mut c_void, // 80
    pub tp_repr: *mut c_void, // 88
    pub tp_as_number: *mut c_void, // 96
    pub tp_as_sequence: *mut c_void, // 104
    pub tp_as_mapping: *mut c_void, // 112
    pub tp_hash: *mut c_void, // 120
    pub tp_call: *mut c_void, // 128
    pub tp_str: *mut c_void, // 136
    pub tp_getattro: *mut c_void, // 144
    pub tp_setattro: *mut c_void, // 152
    pub tp_as_buffer: *mut c_void, // 160
    /// CPython `unsigned long tp_flags`. 64-bit, at offset 168.
    pub tp_flags: u64, // 168
    pub tp_doc: *const c_char, // 176
    pub tp_traverse: *mut c_void, // 184
    pub tp_clear: *mut c_void, // 192
    pub tp_richcompare: *mut c_void, // 200
    pub tp_weaklistoffset: PySsizeT, // 208
    pub tp_iter: *mut c_void, // 216
    pub tp_iternext: *mut c_void, // 224
    pub tp_methods: *mut c_void, // 232
    pub tp_members: *mut c_void, // 240
    pub tp_getset: *mut c_void, // 248
    pub tp_base: *mut PyTypeObject, // 256
    pub tp_dict: *mut PyObject, // 264
    pub tp_descr_get: *mut c_void, // 272
    pub tp_descr_set: *mut c_void, // 280
    pub tp_dictoffset: PySsizeT, // 288
    pub tp_init: *mut c_void, // 296
    pub tp_alloc: *mut c_void, // 304
    pub tp_new: *mut c_void, // 312
    pub tp_free: *mut c_void, // 320
    pub tp_is_gc: *mut c_void, // 328
    pub tp_bases: *mut PyObject, // 336
    pub tp_mro: *mut PyObject, // 344
    pub tp_cache: *mut PyObject, // 352
    pub tp_subclasses: *mut c_void, // 360
    pub tp_weaklist: *mut PyObject, // 368
    pub tp_del: *mut c_void, // 376
    pub tp_version_tag: u64, // 384 (unsigned int + pad)
    pub tp_finalize: *mut c_void, // 392
    pub tp_vectorcall: *mut c_void, // 400
    /// `unsigned char tp_watched` + `uint16_t tp_versions_used` + pad.
    pub tp_tail: [u8; 8], // 408
    // --- WeavePy private fields (offset >= 416, invisible to C) ---
    /// Extension-supplied [`crate::ffi::PyType_Slot`] table, or null.
    pub tp_slots: *mut PyType_Slot,
    /// Bridge to the WeavePy native type. Boxed `Rc<TypeObject>`.
    pub bridge: *mut Rc<TypeObject>,
    _filler: [usize; 2],
}

unsafe impl Sync for PyTypeObject {}

impl PyTypeObject {
    /// A fully-zeroed faithful type with only the head set. Used as the
    /// `..` base for the initialisers so each site spells out just the
    /// fields it cares about.
    pub const fn new_zeroed() -> Self {
        PyTypeObject {
            head: PyObject {
                ob_refcnt: IMMORTAL_REFCNT,
                ob_type: ptr::null_mut(),
            },
            ob_size: 0,
            tp_name: ptr::null(),
            tp_basicsize: 0,
            tp_itemsize: 0,
            tp_dealloc: None,
            tp_vectorcall_offset: 0,
            tp_getattr: ptr::null_mut(),
            tp_setattr: ptr::null_mut(),
            tp_as_async: ptr::null_mut(),
            tp_repr: ptr::null_mut(),
            tp_as_number: ptr::null_mut(),
            tp_as_sequence: ptr::null_mut(),
            tp_as_mapping: ptr::null_mut(),
            tp_hash: ptr::null_mut(),
            tp_call: ptr::null_mut(),
            tp_str: ptr::null_mut(),
            tp_getattro: ptr::null_mut(),
            tp_setattro: ptr::null_mut(),
            tp_as_buffer: ptr::null_mut(),
            tp_flags: 0,
            tp_doc: ptr::null(),
            tp_traverse: ptr::null_mut(),
            tp_clear: ptr::null_mut(),
            tp_richcompare: ptr::null_mut(),
            tp_weaklistoffset: 0,
            tp_iter: ptr::null_mut(),
            tp_iternext: ptr::null_mut(),
            tp_methods: ptr::null_mut(),
            tp_members: ptr::null_mut(),
            tp_getset: ptr::null_mut(),
            tp_base: ptr::null_mut(),
            tp_dict: ptr::null_mut(),
            tp_descr_get: ptr::null_mut(),
            tp_descr_set: ptr::null_mut(),
            tp_dictoffset: 0,
            tp_init: ptr::null_mut(),
            tp_alloc: ptr::null_mut(),
            tp_new: ptr::null_mut(),
            tp_free: ptr::null_mut(),
            tp_is_gc: ptr::null_mut(),
            tp_bases: ptr::null_mut(),
            tp_mro: ptr::null_mut(),
            tp_cache: ptr::null_mut(),
            tp_subclasses: ptr::null_mut(),
            tp_weaklist: ptr::null_mut(),
            tp_del: ptr::null_mut(),
            tp_version_tag: 0,
            tp_finalize: ptr::null_mut(),
            tp_vectorcall: ptr::null_mut(),
            tp_tail: [0; 8],
            tp_slots: ptr::null_mut(),
            bridge: ptr::null_mut(),
            _filler: [0; 2],
        }
    }
}

/// Cross-check the live [`PyTypeObject`] against the machine-checked
/// faithful spec in [`crate::layout`]. Compile-time; zero runtime cost.
const _: () = {
    use crate::layout::PyTypeObjectFull as F;
    assert!(std::mem::offset_of!(PyTypeObject, tp_name) == std::mem::offset_of!(F, tp_name));
    assert!(
        std::mem::offset_of!(PyTypeObject, tp_basicsize) == std::mem::offset_of!(F, tp_basicsize)
    );
    assert!(
        std::mem::offset_of!(PyTypeObject, tp_itemsize) == std::mem::offset_of!(F, tp_itemsize)
    );
    assert!(std::mem::offset_of!(PyTypeObject, tp_dealloc) == std::mem::offset_of!(F, tp_dealloc));
    assert!(std::mem::offset_of!(PyTypeObject, tp_flags) == std::mem::offset_of!(F, tp_flags));
    assert!(std::mem::offset_of!(PyTypeObject, tp_base) == std::mem::offset_of!(F, tp_base));
    assert!(
        std::mem::offset_of!(PyTypeObject, tp_finalize) == std::mem::offset_of!(F, tp_finalize)
    );
    assert!(
        std::mem::offset_of!(PyTypeObject, tp_vectorcall) == std::mem::offset_of!(F, tp_vectorcall)
    );
    // The private fields must begin at or after the faithful region.
    assert!(std::mem::offset_of!(PyTypeObject, tp_slots) >= std::mem::size_of::<F>());
};

/// Re-export of the C `PyType_Slot` shape.
#[repr(C)]
#[derive(Debug, Clone, Copy)]
pub struct PyType_Slot {
    pub slot: c_int,
    pub pfunc: *mut c_void,
}

/// Re-export of the C `PyType_Spec` shape.
#[repr(C)]
#[derive(Debug)]
pub struct PyType_Spec {
    pub name: *const c_char,
    pub basicsize: c_int,
    pub itemsize: c_int,
    pub flags: u32,
    pub slots: *mut PyType_Slot,
}

/// Heap-allocated wrapper around a [`PyTypeObject`] that owns its
/// `Rc<TypeObject>` bridge. Returned by `PyType_FromSpec` etc.
///
/// The [`SlotTable`] embedded here is the lookup-side mirror of the
/// extension-supplied `tp_slots` array. Call sites that want to
/// dispatch into a heap type's protocol slot (the buffer protocol,
/// vectorcall, descriptor `tp_descr_get`, generic allocation, …) all
/// route through [`crate::slottable::slot_table_for`] which reads
/// this field.
#[repr(C)]
pub struct PyTypeObjectBox {
    pub head: PyTypeObject,
    pub owned_name: Vec<u8>,
    /// O(1)-lookup table of slot pointers populated at FromSpec time.
    pub slot_table: SlotTable,
}

/// Convenience cast.
pub fn as_pyobject(ty: *mut PyTypeObject) -> *mut PyObject {
    ty as *mut PyObject
}

/// Convenience cast.
pub fn as_pytype(ob: *mut PyObject) -> *mut PyTypeObject {
    ob as *mut PyTypeObject
}

// ----------------------------------------------------------------
// Static type registry.
//
// We pre-allocate a `PyTypeObject` per built-in WeavePy class.
// At interpreter startup the bridge slot is populated from
// `BuiltinTypes`. Extensions that compile against `Python.h` see
// these symbols as `extern PyTypeObject *`-style data — but we
// expose them via `static`s with a `Sync`-safe `UnsafeCell` wrapper.
// ----------------------------------------------------------------

/// Sync wrapper used for the static type table.
#[repr(transparent)]
pub struct StaticType(pub UnsafeCell<PyTypeObject>);

unsafe impl Sync for StaticType {}

impl StaticType {
    pub const fn new() -> Self {
        Self(UnsafeCell::new(PyTypeObject::new_zeroed()))
    }

    pub fn as_ptr(&self) -> *mut PyTypeObject {
        self.0.get()
    }
}

macro_rules! decl_static_type {
    ($($vis:vis $name:ident);* $(;)?) => {
        $(
            #[no_mangle]
            $vis static $name: StaticType = StaticType::new();
        )*
    };
}

// Static types we expose to extensions. Names match CPython.
decl_static_type! {
    pub PyType_Type;
    pub PyBaseObject_Type;
    pub PyLong_Type;
    pub PyFloat_Type;
    pub PyBool_Type;
    pub PyComplex_Type;
    pub PyUnicode_Type;
    pub PyBytes_Type;
    pub PyByteArray_Type;
    pub PyTuple_Type;
    pub PyList_Type;
    pub PyDict_Type;
    pub PySet_Type;
    pub PyFrozenSet_Type;
    pub PyRange_Type;
    pub PyModule_Type;
    pub _PyNone_Type;
    pub _PyNotImplemented_Type;
    pub PyEllipsis_Type;
    pub PyCapsule_Type;
    pub PySlice_Type;
    pub PyFunction_Type;
    pub PyCFunction_Type;
    pub PyMethod_Type;
    pub PyGen_Type;
    pub PyCoro_Type;
    pub PyAsyncGen_Type;
    // RFC 0047 (wave 5): the umbrella type for WeavePy's native iterators
    // (`Object::Iter` — list/tuple/range/dict/set/... iterators). Macro-heavy
    // Cython reads `Py_TYPE(it)->tp_iternext` *directly* in its `for` loop and
    // `next()` codegen; without a non-NULL slot a compiled `for x in range(n)`
    // (numpy.random's `SeedSequence.generate_state`) jumps to its error label
    // with no exception set. The type carries `tp_iter` (return self) +
    // `tp_iternext` (→ `PyIter_Next`).
    pub PySeqIter_Type;
    // RFC 0046 (wave 4): types numpy's `_multiarray_umath` references by
    // address (`Py_TYPE(x) == &PyMemoryView_Type`, descriptor/proxy slots).
    pub PyMemoryView_Type;
    pub PyDictProxy_Type;
    pub PyGetSetDescr_Type;
    pub PyMemberDescr_Type;
    pub PyMethodDescr_Type;
    // RFC 0047 (wave 5): `wrapper_descriptor` (slot wrappers like
    // `object.__init__`); numpy.random / pandas reference the type by
    // address. A synthetic minimal type satisfies symbol + identity.
    pub PyWrapperDescr_Type;
    // RFC 0046 (wave 4): tags a `PyModuleDef` returned by
    // `PyModuleDef_Init`, so the loader can recognise a multi-phase
    // (PEP 489) extension and run its create/exec slots.
    pub PyModuleDef_Type;
    // RFC 0055 WS5: types the mypyc runtime (`CPy.h`) references by
    // address — `CPyDictKeys_Check`/`Values`/`Items` compare `Py_TYPE(x)`
    // against the view types, and `CPy_Super` *calls* `PySuper_Type`.
    // All four bridge to the corresponding real VM types.
    pub PyDictKeys_Type;
    pub PyDictValues_Type;
    pub PyDictItems_Type;
    pub PySuper_Type;
    // RFC 0062 WS2: types source-built extensions reference by address
    // (wrapt's `_wrappers.c` reads `PyClassMethod_Type` for its
    // descriptor handling; property/staticmethod are the natural
    // siblings). All bridge to the real VM types.
    pub PyClassMethod_Type;
    pub PyStaticMethod_Type;
    pub PyProperty_Type;
    pub PyReversed_Type;
    // RFC 0066 WS3: `instancemethod` — pybind11 wraps every registered
    // method in one (`PYBIND11_INSTANCE_METHOD_NEW`) and identity-checks
    // the type by address. Instances carry CPython's faithful 24-byte
    // layout (see `crate::instancemethod`).
    pub PyInstanceMethod_Type;
    // RFC 0076 WS5 (torch): data symbols `libtorch_python` binds at
    // dlopen. `PyCell_Type` bridges to the VM's real `cell`; the weakref
    // trio are the identity anchors for `PyWeakref_Check*` macros —
    // `_PyWeakref_RefType`'s storage doubles as the faithful
    // `PyWeakReference` shell minted by [`crate::weakref_api`], so
    // `Py_IS_TYPE(wr, &_PyWeakref_RefType)` holds for crossed VM refs.
    pub PyCell_Type;
    pub _PyWeakref_RefType;
    pub _PyWeakref_ProxyType;
    pub _PyWeakref_CallableProxyType;
}

/// Initialise the static type table from the running interpreter's
/// [`weavepy_vm::builtin_types::BuiltinTypes`]. Idempotent; the
/// initialisation is gated on a `Once`-style mutex so concurrent
/// callers see a fully-populated table.
pub fn init_static_types() {
    static INIT_LOCK: Mutex<bool> = Mutex::new(false);
    let mut done = INIT_LOCK.lock().unwrap();
    if *done {
        return;
    }
    *done = true;
    let bt = weavepy_vm::builtin_types::builtin_types();

    fn install(slot: &StaticType, name: &'static [u8], rc: Rc<TypeObject>) {
        unsafe {
            let ty = &mut *slot.as_ptr();
            ty.head.ob_refcnt = IMMORTAL_REFCNT;
            ty.head.ob_type = PyType_Type.as_ptr();
            ty.tp_name = name.as_ptr() as *const c_char;
            // `_Py_Dealloc` (stock inlined `Py_DECREF`) reads
            // `Py_TYPE(inst)->tp_dealloc`; route to the host free path so
            // a stock extension that drops the last ref to one of our
            // objects releases the mirror/box instead of jumping through
            // a garbage slot.
            ty.tp_dealloc = Some(crate::object::_PyWeavePy_Dealloc);
            ty.bridge = Box::into_raw(Box::new(rc));
        }
    }

    install(&PyType_Type, b"type\0", bt.type_.clone());
    install(&PyBaseObject_Type, b"object\0", bt.object_.clone());
    install(&PyLong_Type, b"int\0", bt.int_.clone());
    install(&PyFloat_Type, b"float\0", bt.float_.clone());
    install(&PyBool_Type, b"bool\0", bt.bool_.clone());
    install(&PyUnicode_Type, b"str\0", bt.str_.clone());
    install(&PyBytes_Type, b"bytes\0", bt.bytes_.clone());
    install(&PyByteArray_Type, b"bytearray\0", bt.bytearray_.clone());
    install(&PyTuple_Type, b"tuple\0", bt.tuple_.clone());
    install(&PyList_Type, b"list\0", bt.list_.clone());
    install(&PyDict_Type, b"dict\0", bt.dict_.clone());
    install(&PySet_Type, b"set\0", bt.set_.clone());
    install(&PyFrozenSet_Type, b"frozenset\0", bt.frozenset_.clone());
    install(&PyRange_Type, b"range\0", bt.range_.clone());
    install(&PyModule_Type, b"module\0", bt.module_.clone());
    install(&_PyNone_Type, b"NoneType\0", bt.none_type.clone());
    // RFC 0055 WS5 (mypyc tail): dict views + super bridge to the real VM
    // types, so `type(d.keys())` identity and `super(...)` construction
    // through the C surface behave exactly like the Python-level ones.
    install(&PyDictKeys_Type, b"dict_keys\0", bt.dict_keys_.clone());
    install(
        &PyDictValues_Type,
        b"dict_values\0",
        bt.dict_values_.clone(),
    );
    install(&PyDictItems_Type, b"dict_items\0", bt.dict_items_.clone());
    install(&PySuper_Type, b"super\0", bt.super_.clone());
    // RFC 0062 WS2 — descriptor types source-built extensions
    // (wrapt) reference by address.
    install(
        &PyClassMethod_Type,
        b"classmethod\0",
        bt.classmethod_.clone(),
    );
    install(
        &PyStaticMethod_Type,
        b"staticmethod\0",
        bt.staticmethod_.clone(),
    );
    install(&PyProperty_Type, b"property\0", bt.property_.clone());
    install(&PyReversed_Type, b"reversed\0", bt.reversed_.clone());
    install(&PyFunction_Type, b"function\0", bt.function_.clone());
    install(&PyGen_Type, b"generator\0", bt.generator_.clone());
    install(&PyCoro_Type, b"coroutine\0", bt.coroutine_.clone());
    install(
        &PyAsyncGen_Type,
        b"async_generator\0",
        bt.async_generator_.clone(),
    );

    // `complex` bridges to the VM's real builtin `complex` (like `float`),
    // so `PyComplex_Type`'s bridged type is *identity-equal* to the VM
    // `complex`. numpy's `complex128` dual-inherits from it
    // (`tp_bases == (complexfloating, complex)`), and
    // `isinstance(np.complex128(z), complex)` / `issubclass(...)` only hold
    // when the MRO's `complex` entry *is* the builtin one.
    install(&PyComplex_Type, b"complex\0", bt.complex_.clone());

    // The NotImplemented/Ellipsis/Capsule/CFunction/Slice/Method types
    // don't correspond directly to BuiltinTypes entries; we synthesise
    // minimal native types so `type(Py_None) is _PyNone_Type` (and
    // friends) round-trips correctly.
    fn install_synth(slot: &StaticType, name: &'static [u8], display: &str) {
        let rc = TypeObject::new_builtin(
            display,
            vec![weavepy_vm::builtin_types::builtin_types().object_.clone()],
        )
        .expect("synthetic builtin type must linearise");
        install(slot, name, rc);
    }
    install_synth(
        &_PyNotImplemented_Type,
        b"NotImplementedType\0",
        "NotImplementedType",
    );
    install_synth(&PyEllipsis_Type, b"ellipsis\0", "ellipsis");
    install_synth(&PyCapsule_Type, b"PyCapsule\0", "PyCapsule");
    install_synth(&PySlice_Type, b"slice\0", "slice");
    install_synth(
        &PyCFunction_Type,
        b"builtin_function_or_method\0",
        "builtin_function_or_method",
    );
    install_synth(&PyMethod_Type, b"method\0", "method");
    // `memoryview` bridges to the VM's *real* builtin class: Cython caches
    // `_memoryview = memoryview` as `&PyMemoryView_Type` and later *calls*
    // it (gevent's `get_memory`), so `type_tp_call` must instantiate a
    // working memoryview, not a synthetic shell (RFC 0072 WS2). Pointer
    // identity for numpy's `Py_TYPE(x) == &PyMemoryView_Type` checks is
    // unchanged.
    install(&PyMemoryView_Type, b"memoryview\0", bt.memoryview_.clone());
    // RFC 0046 (wave 4): numpy references these by address. Synthetic
    // minimal types are enough for symbol resolution + pointer identity.
    install_synth(&PyDictProxy_Type, b"mappingproxy\0", "mappingproxy");
    install_synth(
        &PyGetSetDescr_Type,
        b"getset_descriptor\0",
        "getset_descriptor",
    );
    install_synth(
        &PyMemberDescr_Type,
        b"member_descriptor\0",
        "member_descriptor",
    );
    install_synth(
        &PyMethodDescr_Type,
        b"method_descriptor\0",
        "method_descriptor",
    );
    install_synth(
        &PyWrapperDescr_Type,
        b"wrapper_descriptor\0",
        "wrapper_descriptor",
    );
    install_synth(&PyModuleDef_Type, b"moduledef\0", "moduledef");
    install_synth(&PySeqIter_Type, b"iterator\0", "iterator");
    // RFC 0066 WS3: pybind11's method wrapper. The synthetic bridge gives
    // `type(im)` identity; the faithful layout + protocol slots live in
    // `crate::instancemethod`.
    install_synth(
        &PyInstanceMethod_Type,
        b"instancemethod\0",
        "instancemethod",
    );
    crate::instancemethod::init_type_slots();
    // RFC 0076 WS5 (torch): `cell` bridges to the VM's real cell class;
    // the weakref proxy types are synthetic (symbol + identity only —
    // proxy behaviour lives VM-side in `weakref_real`). The `ref` static
    // is populated lazily by `crate::weakref_api::ensure_weakref_type`
    // (it needs the faithful 64-byte `PyWeakReference` shell, not the
    // generic install).
    install(&PyCell_Type, b"cell\0", bt.cell_.clone());
    install_synth(&_PyWeakref_ProxyType, b"weakproxy\0", "weakproxy");
    install_synth(
        &_PyWeakref_CallableProxyType,
        b"weakcallableproxy\0",
        "weakcallableproxy",
    );

    // RFC 0047 (wave 5): wire the iteration protocol (`tp_iter` → self,
    // `tp_iternext` → `PyIter_Next`) onto the iterator umbrella type and the
    // generator type. Stock Cython reads these slots off `Py_TYPE(it)`
    // directly when compiling `for`/`next()`, so a WeavePy iterator handed to
    // a C extension must advertise them or the loop silently errors.
    unsafe {
        crate::builtin_slots::install_iterator(&PySeqIter_Type);
        crate::builtin_slots::install_iterator(&PyGen_Type);
    }

    // RFC 0047 (wave 5): wire the descriptor `tp_descr_get` onto the
    // callable types so a WeavePy function / instance-binding builtin method
    // found via `_PyType_Lookup` *binds* to the instance. Stock Cython's
    // special-method protocol (`with`, `for`, operator dunders) reads this
    // slot directly off `Py_TYPE(descr)`; without it a bound special method
    // (a `threading.Lock`'s `__exit__`) was used unbound and called with no
    // `self`, failing inside extension module init.
    unsafe {
        (*PyFunction_Type.as_ptr()).tp_descr_get = callable_descr_get as *mut c_void;
        (*PyCFunction_Type.as_ptr()).tp_descr_get = callable_descr_get as *mut c_void;
        (*PyMethodDescr_Type.as_ptr()).tp_descr_get = callable_descr_get as *mut c_void;
        // RFC 0062 WS2: classmethod/staticmethod/property carry a *binding*
        // `tp_descr_get` (CPython's `cm_descr_get`/`sm_descr_get`/
        // `property_descr_get`). wrapt's C `FunctionWrapper.__get__` binds
        // its wrapped descriptor through this slot; NULL here made a wrapped
        // classmethod cross unbound and fail with "'classmethod' object is
        // not callable".
        (*PyClassMethod_Type.as_ptr()).tp_descr_get = descriptor_descr_get as *mut c_void;
        (*PyStaticMethod_Type.as_ptr()).tp_descr_get = descriptor_descr_get as *mut c_void;
        (*PyProperty_Type.as_ptr()).tp_descr_get = descriptor_descr_get as *mut c_void;
        (*PyProperty_Type.as_ptr()).tp_descr_set = property_descr_set as *mut c_void;
        // RFC 0076 WS5: a harvested C getset crosses as a faithful
        // `getset_descriptor` box (see `object::GetSetDescrBox`) whose
        // VM payload is still a property — give the shell type the same
        // descriptor slots so numpy's `tp_descr_set != NULL` gate and
        // C-level `tp_descr_get` binding keep working on those boxes.
        (*PyGetSetDescr_Type.as_ptr()).tp_descr_get = descriptor_descr_get as *mut c_void;
        (*PyGetSetDescr_Type.as_ptr()).tp_descr_set = property_descr_set as *mut c_void;
        // RFC 0066 WS3: `type`'s attribute slots. pybind11's metaclass
        // reads `PyType_Type.tp_getattro` / `tp_setattro` straight off
        // the struct and chains to them from its own overrides; NULL was
        // a jump through address zero. The shims run the VM's default
        // (non-dispatching) `type.__getattribute__` / `type.__setattr__`
        // bodies, so the chain cannot recurse into the override.
        (*PyType_Type.as_ptr()).tp_getattro = type_generic_getattro as *mut c_void;
        (*PyType_Type.as_ptr()).tp_setattro = type_generic_setattro as *mut c_void;
        // RFC 0066 WS6: `type`'s call slot. pybind11's metaclass `tp_call`
        // (`pybind11_meta_call`, the entry point of *every* pybind11 class
        // instantiation) chains to `PyType_Type.tp_call(type, args, kwargs)`
        // read straight off the struct; NULL was a jump through address
        // zero the moment matplotlib's font manager built `ft2font.FT2Font`.
        (*PyType_Type.as_ptr()).tp_call = type_tp_call as *mut c_void;
        // RFC 0076 WS5: `type`/`object` init slots, for extension
        // metaclasses that chain `PyType_Type.tp_init(...)` off the
        // struct (torch's `THPVariableMetaType_init`).
        (*PyType_Type.as_ptr()).tp_init = type_tp_init as *mut c_void;
        (*PyBaseObject_Type.as_ptr()).tp_init = object_tp_init as *mut c_void;
    }

    // RFC 0047 (wave 5): advertise `tp_call` on the callable built-in types.
    // CPython sets `tp_call` on `function`/`builtin_function_or_method`/
    // `method`; stock Cython reads `Py_TYPE(f)->tp_call` *directly* both to
    // implement `callable(f)` (inlined `PyCallable_Check`) and to invoke `f`
    // (`__Pyx_PyObject_Call`). Left NULL, a WeavePy function handed to a C
    // extension looked "not callable": pandas' C parser
    // (`parsers.pyx`: `not callable(self.usecols)` → `len(usecols)`,
    // `not callable(self.skiprows)` → `for _ in skiprows`) then treated a
    // callable `usecols`/`skiprows` as a sequence, raising
    // "object of type 'function' has no len()". `synth_tp_call` forwards to
    // the abstract `PyObject_Call`, which dispatches on the Rust `Object`.
    unsafe {
        (*PyFunction_Type.as_ptr()).tp_call = synth_tp_call as *mut c_void;
        (*PyCFunction_Type.as_ptr()).tp_call = synth_tp_call as *mut c_void;
        (*PyMethod_Type.as_ptr()).tp_call = synth_tp_call as *mut c_void;
    }

    // Set the `Py_TPFLAGS_*_SUBCLASS` fast-subclass bits (and a
    // baseline `Py_TPFLAGS_DEFAULT`) on the built-in static types.
    // Stock CPython 3.13 headers inline the `PyX_Check` family as
    // `PyType_FastSubclass(Py_TYPE(o), Py_TPFLAGS_X_SUBCLASS)`, reading
    // `tp_flags` directly, and the *full*-API macros (`PyTuple_GET_ITEM`
    // etc.) `assert(PyX_Check(o))` in non-`NDEBUG` builds. Without these
    // bits a stock extension aborts the moment it touches one of our
    // objects. (RFC 0043 WS3/WS4.)
    use crate::layout::tpflags;
    unsafe fn add_flags(slot: &StaticType, flags: u64) {
        unsafe {
            (*slot.as_ptr()).tp_flags |= tpflags::DEFAULT | flags;
        }
    }
    unsafe {
        add_flags(&PyType_Type, tpflags::TYPE_SUBCLASS | tpflags::BASETYPE);
        add_flags(&PyBaseObject_Type, tpflags::BASETYPE);
        add_flags(&PyLong_Type, tpflags::LONG_SUBCLASS | tpflags::BASETYPE);
        // bool is an int subclass, so `PyLong_Check(True)` must hold.
        add_flags(&PyBool_Type, tpflags::LONG_SUBCLASS);
        add_flags(&PyList_Type, tpflags::LIST_SUBCLASS | tpflags::BASETYPE);
        add_flags(&PyTuple_Type, tpflags::TUPLE_SUBCLASS | tpflags::BASETYPE);
        add_flags(&PyBytes_Type, tpflags::BYTES_SUBCLASS | tpflags::BASETYPE);
        add_flags(
            &PyUnicode_Type,
            tpflags::UNICODE_SUBCLASS | tpflags::BASETYPE,
        );
        add_flags(&PyDict_Type, tpflags::DICT_SUBCLASS | tpflags::BASETYPE);
        // Types that have no fast-subclass bit still want DEFAULT.
        add_flags(&PyFloat_Type, tpflags::BASETYPE);
        add_flags(&PyComplex_Type, tpflags::BASETYPE);
        add_flags(&PyByteArray_Type, tpflags::BASETYPE);
        add_flags(&PySet_Type, tpflags::BASETYPE);
        add_flags(&PyFrozenSet_Type, 0);
        // The iterator umbrella type needs the baseline DEFAULT feature bit so
        // `PyType_HasFeature`/`PyIter_Check` behave; no fast-subclass bit.
        add_flags(&PySeqIter_Type, 0);
    }

    // RFC 0047 (wave 5): faithful `tp_basicsize` / `tp_itemsize` for the
    // static built-ins. A Cython extension imports a builtin and validates
    // it with `__Pyx_ImportType`, which reads `Py_TYPE(builtins.X)->
    // tp_basicsize` and raises `ValueError("X size changed, may indicate
    // binary incompatibility. Expected N from C header, got M from
    // PyObject")` when the live value is smaller than the `sizeof(...)` its
    // stock CPython 3.14 headers baked in (numpy.random's `bit_generator`
    // checks `builtins.type` == `sizeof(PyHeapTypeObject)` = 936, and a
    // zero tripped it). WeavePy stores these objects as managed
    // `PyObjectBox` mirrors, so the field is **reporting-only**: it never
    // diverts allocation, which is gated by the separate `INLINE_TYPES`
    // registry these are never entered into. The values mirror stock
    // CPython 3.14 (`<type>.__basicsize__` / `.__itemsize__`) byte-for-byte.
    unsafe fn set_size(slot: &StaticType, basicsize: PySsizeT, itemsize: PySsizeT) {
        unsafe {
            let ty = &mut *slot.as_ptr();
            ty.tp_basicsize = basicsize;
            ty.tp_itemsize = itemsize;
        }
    }
    // CPython's `PyType_Ready` gives every readied type `tp_alloc =
    // PyType_GenericAlloc` / `tp_free = PyObject_Free`. A *static Cython
    // subtype* of a built-in (sqlalchemy's `cdef class immutabledict(dict)`)
    // inherits `tp_alloc` byte-wise from our exported static and calls it
    // straight off the struct in its `tp_new`; a NULL slot there is a jump
    // to address zero. Backfill the defaults on every exported static.
    unsafe {
        let alloc_fp: unsafe extern "C" fn(*mut PyTypeObject, PySsizeT) -> *mut PyObject =
            crate::genericalloc::PyType_GenericAlloc;
        let new_fp: unsafe extern "C" fn(
            *mut PyTypeObject,
            *mut PyObject,
            *mut PyObject,
        ) -> *mut PyObject = crate::genericalloc::PyType_GenericNew;
        let free_fp: unsafe extern "C" fn(*mut c_void) = crate::memory::PyObject_Free;
        for slot in STATIC_TYPE_TABLE {
            let ty = &mut *slot.as_ptr();
            if ty.tp_alloc.is_null() {
                ty.tp_alloc = alloc_fp as *mut c_void;
            }
            // `object.__new__` and friends: PyO3's
            // `PyNativeTypeInitializer` resolves its base's `tp_new`
            // through `PyType_GetSlot` and refuses a NULL ("base type
            // without tp_new" — pydantic-core's module init). The value
            // built-ins with faithful constructors (float/str/bytes/
            // complex) are overridden later by `builtin_new::install`.
            if ty.tp_new.is_null() {
                ty.tp_new = new_fp as *mut c_void;
            }
            if ty.tp_free.is_null() {
                ty.tp_free = free_fp as *mut c_void;
            }
        }
    }

    unsafe {
        set_size(&PyType_Type, 936, 40);
        set_size(&PyBaseObject_Type, 16, 0);
        set_size(&PyLong_Type, 24, 4);
        set_size(&PyFloat_Type, 24, 0);
        set_size(&PyBool_Type, 24, 4);
        set_size(&PyComplex_Type, 32, 0);
        set_size(&PyUnicode_Type, 64, 0);
        set_size(&PyBytes_Type, 33, 1);
        set_size(&PyByteArray_Type, 56, 0);
        // 3.14: `sizeof(PyTupleObject) - sizeof(PyObject*)` — the var head
        // plus the `ob_hash` cache (gh-131525).
        set_size(
            &PyTuple_Type,
            crate::layout::TUPLE_HEAD_BYTES as PySsizeT,
            8,
        );
        set_size(&PyList_Type, 40, 0);
        set_size(&PyDict_Type, 48, 0);
        set_size(&PySet_Type, 200, 0);
        set_size(&PyFrozenSet_Type, 200, 0);
    }

    // RFC 0046 (wave 4): give the exported value built-ins a faithful
    // `tp_new`. A C type that subclasses one of them (numpy's
    // `float64 ← float`, `str_ ← str`, `bytes_ ← bytes`) inherits and may
    // directly call the base's `tp_new`; a NULL slot is a jump through
    // address 0 (`np.float64(1.0)` and numpy's import self-checks crash).
    crate::builtin_new::install_builtin_constructors();

    // RFC 0047 (wave 5): populate the C-level protocol suites
    // (`tp_as_sequence`/`tp_as_mapping`/`tp_iter`) on the built-in
    // containers. Macro-heavy Cython reads these slots directly off the
    // type struct (`__Pyx_PyObject_GetItem` → `tp_as_mapping->mp_subscript`),
    // so without them a WeavePy list/tuple/dict appears "not subscriptable"
    // to an extension even though the VM handles the operation.
    crate::builtin_slots::install();

    // RFC 0047 (wave 5): populate `tp_as_number` on the exported numeric
    // built-ins (`int`/`float`/`bool`/`complex`). Macro-heavy Cython casts a
    // scalar to a C integer/double by reading `Py_TYPE(x)->tp_as_number->nb_int`
    // (`__Pyx_PyNumber_IntOrLong`) / `nb_float` directly; a NULL suite made
    // `<int64_t>(some_float)` raise "an integer is required" — the exact break
    // in pandas' `Timedelta("1 day")` string parser (`cast_from_unit`).
    crate::builtin_slots::install_numbers();

    // RFC 0047 (wave 5): wire `tp_repr` / `tp_str` / `tp_hash` on every
    // exported built-in static type. Stock Cython/C code reaches the
    // stringify + hash slots *directly* off `Py_TYPE(o)` — e.g. pandas'
    // `lib.ensure_string_array` compiles `f"{val}"` on an `int`/`float`
    // element to `Py_TYPE(val)->tp_repr(val)` (via `PyObject_Format` →
    // `object.__format__` → `PyObject_Str` → `tp_str`/`tp_repr`), and dict
    // /set keying reads `Py_TYPE(key)->tp_hash`. A NULL slot is a jump
    // through address 0 (`s.astype(str)` on an int64 Series crashed with
    // `pc=0x0` inside `ensure_string_array.cold`). The `synth_*` bridges
    // forward to `PyObject_Repr` / `PyObject_Str` / `PyObject_Hash`, which
    // dispatch on the runtime `Object` enum and never re-read these C slots,
    // so the forward is recursion-safe. Only fill a slot left NULL so a
    // faithful per-type slot (datetime, `PyType_FromSpec`) is untouched;
    // `list`/`dict`/`set` get the hash bridge too, which raises
    // `unhashable type` via the VM exactly as CPython's
    // `PyObject_HashNotImplemented` does.
    // `object.__hash__` / `type.__hash__` are CPython's identity hash
    // (`_Py_HashPointer`), **not** the VM-forwarding `synth_tp_hash` bridge.
    // A stock extension reads `PyBaseObject_Type->tp_hash` straight off the
    // struct and calls it directly (numpy's `datetime`/`timedelta` scalar hash
    // does this for a `NaT`); the forwarding bridge would ping-pong `object
    // slot → PyObject_Hash → py_hash_value(Foreign) → fwd_hash → numpy slot →
    // object slot` and overflow the stack. Set them before the NULL-fill loop
    // so the loop leaves them untouched. See [`object_generic_hash`].
    unsafe {
        (*PyBaseObject_Type.as_ptr()).tp_hash = object_generic_hash as *mut c_void;
        (*PyType_Type.as_ptr()).tp_hash = object_generic_hash as *mut c_void;
        // `str.__hash__` / `bytes.__hash__` are CPython's value hashes,
        // self-contained like the identity hash above: a subtype (numpy's
        // `str_`/`bytes_`) inherits these slots via `inherit_slots` and the
        // VM resolves such an instance's `__hash__` back to them, so a
        // VM-forwarding bridge here would recurse `VM → C → VM`.
        (*PyUnicode_Type.as_ptr()).tp_hash = unicode_value_hash as *mut c_void;
        (*PyBytes_Type.as_ptr()).tp_hash = bytes_value_hash as *mut c_void;
    }
    unsafe {
        for slot in STATIC_TYPE_TABLE {
            let ty = &mut *slot.as_ptr();
            if ty.tp_repr.is_null() {
                ty.tp_repr = synth_tp_repr as *mut c_void;
            }
            if ty.tp_str.is_null() {
                ty.tp_str = synth_tp_str as *mut c_void;
            }
            if ty.tp_hash.is_null() {
                ty.tp_hash = synth_tp_hash as *mut c_void;
            }
        }
    }
    // The static bridges wired above are registry events for the
    // negative `find_type_ptr` cache.
    bump_type_registry_gen();
}

/// Map a runtime [`Object`] to the static [`PyTypeObject`] pointer
/// representing its type. Used by [`crate::object::into_owned`] to
/// fill in the `ob_type` slot.
pub fn type_for_object(o: &Object) -> *mut PyTypeObject {
    use Object as O;
    match o {
        O::None => _PyNone_Type.as_ptr(),
        O::Bool(_) => PyBool_Type.as_ptr(),
        O::Int(_) | O::Long(_) => PyLong_Type.as_ptr(),
        O::Float(_) => PyFloat_Type.as_ptr(),
        O::Complex(_) => PyComplex_Type.as_ptr(),
        O::Str(_) => PyUnicode_Type.as_ptr(),
        // A surrogate-bearing string is still a `str` to C: the compiled
        // `PyUnicode_Check` macro reads `ob_type->tp_flags` directly, so a
        // `WStr` crossing with any other type pointer silently demotes it to
        // a "generic object" (pandas' ujson then encoded `"'\udac0'"` as `{}`
        // instead of raising UnicodeEncodeError).
        O::WStr(_) => PyUnicode_Type.as_ptr(),
        O::Bytes(_) => PyBytes_Type.as_ptr(),
        O::ByteArray(_) => PyByteArray_Type.as_ptr(),
        O::Tuple(_) => PyTuple_Type.as_ptr(),
        O::List(_) => PyList_Type.as_ptr(),
        O::Dict(_) => PyDict_Type.as_ptr(),
        O::Set(_) => PySet_Type.as_ptr(),
        O::FrozenSet(_) => PyFrozenSet_Type.as_ptr(),
        O::Range(_) => PyRange_Type.as_ptr(),
        O::MemoryView(_) => PyMemoryView_Type.as_ptr(),
        O::Module(_) => PyModule_Type.as_ptr(),
        O::Function(_) => PyFunction_Type.as_ptr(),
        O::Builtin(_) => PyCFunction_Type.as_ptr(),
        O::BoundMethod(_) => PyMethod_Type.as_ptr(),
        // RFC 0062 WS2: descriptor objects cross wearing their faithful
        // types so an extension's `Py_TYPE(wrapped)->tp_descr_get` binds
        // them (wrapt wrapping a classmethod/staticmethod/property).
        O::ClassMethod(_) => PyClassMethod_Type.as_ptr(),
        O::StaticMethod(_) => PyStaticMethod_Type.as_ptr(),
        O::Property(_) => PyProperty_Type.as_ptr(),
        O::Generator(_) => PyGen_Type.as_ptr(),
        O::Iter(_) => PySeqIter_Type.as_ptr(),
        O::Coroutine(_) => PyCoro_Type.as_ptr(),
        O::AsyncGenerator(_) => PyAsyncGen_Type.as_ptr(),
        O::Slice(_) => PySlice_Type.as_ptr(),
        O::Type(t) => find_type_ptr(t).unwrap_or_else(|| PyType_Type.as_ptr()),
        O::Instance(inst) => {
            let cls = inst.cls();
            // RFC 0029 (wave 5): an instance crosses wearing its *real* type,
            // not a bare `object`. A pure-Python subclass of a faithful C base
            // — pytz's `UTC ← BaseTzInfo ← datetime.tzinfo`, consumed by
            // pandas' `cdef tzinfo utc_pytz = pytz.utc` (a Cython
            // `__Pyx_TypeTest(obj, datetime.tzinfo)`) — only passes the C-side
            // subtype check if `Py_TYPE(obj)`'s `tp_base` chain reaches the
            // `tzinfo` shell. `install_user_type` builds that chain (minting
            // intermediate bases), so use it as the final fallback rather than
            // collapsing every unregistered instance to `object`.
            find_type_ptr(&cls)
                .or_else(|| synth_type_for_class(&cls))
                .unwrap_or_else(|| install_user_type(&cls))
        }
        // RFC 0045 (wave 3): capsules round-trip as their retained box in
        // `into_owned`, but report the faithful `PyCapsule_Type` for any
        // direct `Py_TYPE`-style query that reaches here.
        O::Capsule(_) => PyCapsule_Type.as_ptr(),
        // RFC 0072 WS2: a mappingproxy crosses wearing `PyDictProxy_Type`
        // (with mapping slots installed), not a bare `object`. gevent's
        // compiled `_local_find_descriptors` does `base.__dict__[attr]` —
        // Cython's `__Pyx_PyObject_GetItem` reads `tp_as_mapping` straight
        // off `ob_type` and reported "'object' object is not subscriptable".
        O::MappingProxy(_) | O::MappingProxyObj(_) => PyDictProxy_Type.as_ptr(),
        // RFC 0076 WS3: tracebacks and frames cross wearing their
        // identity statics so compiled `PyTraceBack_Check` /
        // `PyFrame_Check` pass. Cython's `__Pyx_Raise` guards its
        // third argument with `PyTraceBack_Check(tb)` — a traceback
        // boxed as bare `object` failed every 3-arg
        // `raise T, v, tb` in lxml's error-propagation paths
        // ("raise: arg 3 must be a traceback or None").
        O::Traceback(_) => crate::code_obj::traceback_type_ptr(),
        O::Frame(_) => crate::code_obj::frame_type_ptr(),
        // RFC 0076 WS5: VM code objects wear the faithful `PyCode_Type`
        // (they cross as facades — see `code_obj::facade_for_vm_code`).
        O::Code(_) => crate::code_obj::code_type_ptr(),
        _ => PyBaseObject_Type.as_ptr(),
    }
}

/// Positive-result cache for [`find_type_ptr`]: `Rc<TypeObject>`
/// address → resolved `PyTypeObject *`. The linear registry scans
/// below made this — which runs on *every* instance crossing into C —
/// O(registered types); under pandas (hundreds of readied/heap types,
/// millions of crossings) it dominated whole test files. Safe to cache
/// because a resolved mapping never changes: registered type structs
/// are immortal, a `bridge` is written once (never re-pointed at a
/// different class), and the scan order is deterministic. Negative
/// results are *not* cached — a bridge can be wired lazily after the
/// type registers (e.g. the datetime shells), so a miss must re-scan.
static TYPE_PTR_CACHE: Mutex<Option<weavepy_vm::fasthash::FxHashMap<usize, usize>>> =
    Mutex::new(None);

/// Monotonic stamp of the C-type registry: bumped whenever an event
/// occurs that could make a previously-unresolvable class resolvable
/// (a heap/readied type registers, a static bridge is wired). Guards
/// the *negative* cache below: a cached miss is only trusted while the
/// registry is unchanged since the miss was recorded.
static TYPE_REGISTRY_GEN: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

/// Negative-result cache for [`find_type_ptr`]: class address → the
/// registry generation at which the full scan came up empty. Pure
/// Python classes (the overwhelmingly common case on the GC traverse /
/// crossing paths) otherwise pay the whole linear scan on *every*
/// lookup, since only positive results are memoised. Cleared on every
/// generation bump so entries never outlive the scan they summarise.
/// `datetime`-named classes are excluded: their resolution runs through
/// [`crate::datetime_api::faithful_type_for_class`], which mints shells
/// and wires bridges outside the generation counter's view.
static NEG_TYPE_PTR_CACHE: Mutex<Option<weavepy_vm::fasthash::FxHashMap<usize, u64>>> =
    Mutex::new(None);

/// Note a registry event that could change [`find_type_ptr`] results:
/// invalidate the negative cache and advance the generation.
pub(crate) fn bump_type_registry_gen() {
    TYPE_REGISTRY_GEN.fetch_add(1, std::sync::atomic::Ordering::AcqRel);
    if let Ok(mut g) = NEG_TYPE_PTR_CACHE.lock() {
        if let Some(m) = g.as_mut() {
            m.clear();
        }
    }
}

/// Walk the static type registry plus the heap-type registry
/// looking for a slot whose bridge matches `t`. Used by
/// [`type_for_object`]. Linear in the number of registered types
/// (small static set + however many `PyType_FromSpec` produced),
/// memoised per class through [`TYPE_PTR_CACHE`] (hits) and
/// [`NEG_TYPE_PTR_CACHE`] (generation-stamped misses).
fn find_type_ptr(t: &Rc<TypeObject>) -> Option<*mut PyTypeObject> {
    let target = Rc::as_ptr(t);
    if let Some(p) = TYPE_PTR_CACHE
        .lock()
        .ok()
        .and_then(|g| g.as_ref().and_then(|m| m.get(&(target as usize)).copied()))
    {
        return Some(p as *mut PyTypeObject);
    }
    // A miss recorded at the current generation is authoritative — the
    // registry hasn't changed since the last full scan for this class.
    // Safe against address reuse: a class allocated over a dead one's
    // address can only *gain* a C type through a registry event, and
    // every such event clears this cache.
    let neg_cacheable = !crate::datetime_api::is_datetime_class_name(&t.name);
    let gen = TYPE_REGISTRY_GEN.load(std::sync::atomic::Ordering::Acquire);
    if neg_cacheable
        && NEG_TYPE_PTR_CACHE
            .lock()
            .ok()
            .and_then(|g| g.as_ref().and_then(|m| m.get(&(target as usize)).copied()))
            == Some(gen)
    {
        return None;
    }
    match find_type_ptr_uncached(t) {
        Some(found) => {
            if let Ok(mut g) = TYPE_PTR_CACHE.lock() {
                g.get_or_insert_with(weavepy_vm::fasthash::FxHashMap::default)
                    .insert(target as usize, found as usize);
            }
            Some(found)
        }
        None => {
            if neg_cacheable {
                if let Ok(mut g) = NEG_TYPE_PTR_CACHE.lock() {
                    g.get_or_insert_with(weavepy_vm::fasthash::FxHashMap::default)
                        .insert(target as usize, gen);
                }
            }
            None
        }
    }
}

fn find_type_ptr_uncached(t: &Rc<TypeObject>) -> Option<*mut PyTypeObject> {
    // RFC 0029 (wave 5): the `datetime` module's classes resolve to the
    // faithful, size-correct C types (minted on first use). Authoritative
    // and identity-checked, so it runs *before* the generic registry scan
    // and never collides with a coincidentally-named user class.
    if let Some(p) = crate::datetime_api::faithful_type_for_class(t) {
        return Some(p);
    }
    // RFC 0072 WS1: the VM `greenlet` class resolves to the byte-faithful
    // `PyGreenlet` shell (`tp_basicsize == sizeof(PyGreenlet)`), never the
    // generic identity-box mirror — gevent's Cython subclasses compute
    // their field offsets from the upstream struct size.
    if let Some(p) = crate::greenlet_api::faithful_type_for_class(t) {
        return Some(p);
    }
    // RFC 0072 WS2: the builtin `weakref.ref` (`ReferenceType`) class
    // resolves to the byte-faithful `PyWeakReference` shell
    // (`tp_basicsize == 64`) — gevent's `_gevent_c_ident` imports it
    // with a `sizeof(PyWeakReference)` check and subclasses it with a
    // cdef field at that offset.
    if let Some(p) = crate::weakref_api::faithful_type_for_class(t) {
        return Some(p);
    }
    let target = Rc::as_ptr(t);
    for slot in STATIC_TYPE_TABLE {
        let p = slot.as_ptr();
        unsafe {
            let bridge = (*p).bridge;
            if !bridge.is_null() && Rc::as_ptr(&*bridge) == target {
                return Some(p);
            }
        }
    }
    let from_heap = HEAP_TYPES.lock().ok().and_then(|g| {
        for &addr in g.iter() {
            let p = addr as *mut PyTypeObject;
            unsafe {
                let bridge = (*p).bridge;
                if !bridge.is_null() && Rc::as_ptr(&*bridge) == target {
                    return Some(p);
                }
            }
        }
        None
    });
    if from_heap.is_some() {
        return from_heap;
    }
    // Readied stock types (RFC 0044): match on the bridge and return
    // the extension's own pointer so instances carry its `ob_type`.
    let readied = READIED_TYPES.lock().ok()?;
    for rt in readied.iter() {
        if Rc::as_ptr(&rt.bridge) == target {
            return Some(rt.ext_ptr);
        }
    }
    None
}

/// Registry of heap-allocated `PyTypeObject *` produced by
/// `PyType_FromSpec[WithBases]` (and the bridged `PyExc_*` statics,
/// installed via [`install_user_type`]). Looked up by [`find_type_ptr`]
/// when an `Object::Instance` is materialised back into a boxed
/// `*mut PyObject`, so the box's `ob_type` matches the extension's
/// declared type, and by [`is_weavepy_owned_type`] to decide whether
/// `bridge_type` may read the trailing `bridge` field.
///
/// RFC 0046 (wave 4): process-global, **not** thread-local. A heap
/// type's identity is a property of the process, not of one OS thread:
/// the boxes are `Box::leak`'d (immortal, stable pointers) and their
/// bridge is an `Arc<TypeObject>` (`Send + Sync`). The `PyExc_*`
/// statics in particular are published once (under a global lock) on
/// whatever thread first initialises the runtime, then read from
/// *every* thread — so a thread-local registry made
/// `clone_object(PyExc_ValueError)` resolve to a foreign proxy on any
/// other thread, collapsing `PyErr_SetString(PyExc_ValueError, …)` to a
/// bare `RuntimeError`. Stored as `usize` addresses so the `static` is
/// `Send` (mirrors [`crate::object`]'s `MINTED` set). The interpreter
/// runs single-threaded under the GIL, so the mutex is uncontended.
static HEAP_TYPES: Mutex<Vec<usize>> = Mutex::new(Vec::new());

/// O(1) membership companion to [`HEAP_TYPES`] (which stays a `Vec`
/// for its deterministic scan order). [`is_weavepy_owned_type`] runs on
/// hot free/crossing paths; a `Vec::contains` scan there was O(types).
static HEAP_TYPE_SET: Mutex<Option<weavepy_vm::fasthash::FxHashSet<usize>>> = Mutex::new(None);

/// Register a heap-allocated type pointer so subsequent
/// `Object::Instance` boxes get the extension's declared
/// `ob_type` instead of falling back to `PyBaseObject_Type`.
pub fn register_heap_type(p: *mut PyTypeObject) {
    if p.is_null() {
        return;
    }
    let fresh = HEAP_TYPE_SET
        .lock()
        .map(|mut g| {
            g.get_or_insert_with(weavepy_vm::fasthash::FxHashSet::default)
                .insert(p as usize)
        })
        .unwrap_or(false);
    if fresh {
        if let Ok(mut g) = HEAP_TYPES.lock() {
            g.push(p as usize);
        }
        bump_type_registry_gen();
    }
}

// ---------------------------------------------------------------------------
// RFC 0047 (wave 5): synthesize a faithful C `PyTypeObject` for a *Python*
// class that crosses into a C extension.
//
// WeavePy classes (incl. stdlib ones written in Python like
// `itertools.cycle`) have no `PyType_FromSpec`-registered C type, so a
// bare `Object::Instance` previously crossed into C wearing
// `PyBaseObject_Type`. Macro-heavy Cython then reads protocol slots
// (`Py_TYPE(it)->tp_iternext`, `->tp_call`, …) straight off that struct,
// finds them NULL, and silently errors (`numpy.random.SeedSequence.
// generate_state` iterates `cycle(self.pool)`).
//
// We mint one immortal type per class, populated from the class's dunders
// with bridges that forward to the recursion-safe abstract C-API (which
// dispatches on the Rust `Object`, never re-reading these slots). Scoped
// to iterables/iterators to keep the blast radius small: every other
// instance keeps the historic `PyBaseObject_Type` crossing.

unsafe extern "C" fn synth_tp_iter(o: *mut PyObject) -> *mut PyObject {
    unsafe { crate::abstract_::PyObject_GetIter(o) }
}
unsafe extern "C" fn synth_tp_iternext(o: *mut PyObject) -> *mut PyObject {
    // Value-preserving: a `StopIteration(value)` stays pending so compiled
    // yield-from delegation can fetch the result (see `tp_iternext_bridge`).
    unsafe { crate::builtin_slots::tp_iternext_bridge(o) }
}
unsafe extern "C" fn synth_tp_call(
    o: *mut PyObject,
    a: *mut PyObject,
    k: *mut PyObject,
) -> *mut PyObject {
    unsafe { crate::abstract_::PyObject_Call(o, a, k) }
}
/// `PyType_Type.tp_call` — CPython's `type_call` (the *default*
/// `type.__call__` body: `tp_new` + conditional `tp_init`), reachable
/// when an extension invokes the slot directly off the exported static
/// struct. The only known caller is pybind11's `pybind11_meta_call`,
/// which is itself the metaclass `__call__` — so this body must run the
/// default construction sequence and never re-dispatch through the
/// metaclass, or the pair would recurse. The VM equivalent of that
/// sequence is `Interpreter::instantiate`, which resolves the mirrored
/// class's (shimmed) `__new__`/`__init__` through the normal MRO
/// machinery.
unsafe extern "C" fn type_tp_call(
    ty: *mut PyObject,
    args: *mut PyObject,
    kwds: *mut PyObject,
) -> *mut PyObject {
    crate::interp::ensure_active(|| {
        let cls = unsafe { crate::object::clone_object(ty) };
        let Object::Type(cls) = cls else {
            crate::errors::set_type_error("type_call: self is not a type");
            return ptr::null_mut();
        };
        let arg_vec: Vec<Object> = if args.is_null() {
            Vec::new()
        } else {
            match unsafe { crate::object::clone_object(args) } {
                Object::Tuple(items) => items.iter().cloned().collect(),
                other => vec![other],
            }
        };
        let kw_pairs: Vec<(String, Object)> = if kwds.is_null() {
            Vec::new()
        } else {
            match unsafe { crate::object::clone_object(kwds) } {
                Object::Dict(rc) => rc
                    .borrow()
                    .iter()
                    .filter_map(|(k, v)| match &k.0 {
                        Object::Str(s) => Some((s.to_string(), v.clone())),
                        _ => None,
                    })
                    .collect(),
                _ => Vec::new(),
            }
        };
        if std::env::var_os("WEAVEPY_TRACE_CALL").is_some() {
            eprintln!(
                "[TYPE_TP_CALL] cls={} nargs={} nkw={}",
                cls.name,
                arg_vec.len(),
                kw_pairs.len()
            );
        }
        let result = crate::interp::with_interp_mut(|interp| {
            interp.instantiate(cls.clone(), &arg_vec, &kw_pairs)
        });
        match result {
            Some(Ok(v)) => crate::object::into_owned(v),
            Some(Err(err)) => {
                crate::errors::set_pending_from_runtime(err);
                ptr::null_mut()
            }
            None => {
                crate::errors::set_type_error("type_call: no active interpreter");
                ptr::null_mut()
            }
        }
    })
}

/// `type.__init__` (CPython `type_init`): everything real happened in
/// `tp_new`, so the body only validates arity. Exists so an extension
/// metaclass `tp_init` can chain to `PyType_Type.tp_init(cls, args,
/// kwargs)` read straight off the exported static — torch's
/// `THPVariableMetaType_init` does exactly that before patching
/// `tp_dealloc` onto every `Tensor` subclass (RFC 0076 WS5); NULL was a
/// jump through address zero at `class Tensor(torch._C.TensorBase)`.
unsafe extern "C" fn type_tp_init(
    _cls: *mut PyObject,
    args: *mut PyObject,
    _kwds: *mut PyObject,
) -> c_int {
    let nargs = if args.is_null() {
        0
    } else {
        unsafe { crate::containers::PyTuple_Size(args) }
    };
    if !(1..=3).contains(&nargs) {
        crate::errors::set_type_error("type.__init__() takes 1 or 3 arguments");
        return -1;
    }
    0
}

/// `object.__init__` (CPython `object_init`) for the same
/// chain-off-the-static pattern on `PyBaseObject_Type.tp_init`. The
/// excess-argument diagnostics live in the VM's real `__init__`; a
/// direct C caller chaining here gets the successful no-op.
unsafe extern "C" fn object_tp_init(
    _slf: *mut PyObject,
    _args: *mut PyObject,
    _kwds: *mut PyObject,
) -> c_int {
    0
}

unsafe extern "C" fn synth_tp_repr(o: *mut PyObject) -> *mut PyObject {
    unsafe { crate::abstract_::PyObject_Repr(o) }
}
unsafe extern "C" fn synth_tp_str(o: *mut PyObject) -> *mut PyObject {
    unsafe { crate::abstract_::PyObject_Str(o) }
}

/// True when `slot` is one of the VM-forwarding repr/str bridges above.
/// `foreign_repr_or_str` consults this to break the `foreign tp_repr →
/// synth bridge → PyObject_Repr → foreign tp_repr` cycle.
pub(crate) fn is_synth_repr_str_slot(slot: *mut c_void) -> bool {
    slot == synth_tp_repr as *mut c_void || slot == synth_tp_str as *mut c_void
}

/// True when `slot` is the VM-forwarding call bridge. `PyObject_Call`'s
/// direct foreign `tp_call` dispatch consults this to break the
/// `PyObject_Call → synth_tp_call → PyObject_Call` cycle.
pub(crate) fn is_synth_call_slot(slot: *mut c_void) -> bool {
    slot == synth_tp_call as *mut c_void
}
unsafe extern "C" fn synth_tp_hash(o: *mut PyObject) -> crate::object::PyHashT {
    unsafe { crate::abstract_::PyObject_Hash(o) }
}

// ---------------------------------------------------------------------------
// Synthesized number suite (RFC 0047, wave 5) — CPython's `slot_nb_*`.
//
// CPython's `fixup_slot_dispatchers` wires every class-dict numeric dunder
// into `tp_as_number` via shared `slot_nb_*` trampolines, so C code that
// dispatches through the slot protocol (`binary_op1`, Cython's inlined
// `PyNumber_*` calls) reaches Python-level `__add__`/`__rmod__`/… methods.
// WeavePy's synthesized types previously left the whole suite NULL: a
// binary op between a *foreign* operand and a VM instance
// (`np.timedelta64 % pandas.Timedelta`, evaluated **inside** Cython's
// `__rmod__ → __rdivmod__ → PyNumber_FloorDivide`) found no slot on either
// side and raised "unsupported operand type" even though the VM class
// defines the dunder.
//
// Each trampoline mirrors CPython's `SLOT1BIN` exactly: it computes
// whether each operand's type *owns* this very trampoline for the slot
// (the `SLOTNAME == TESTFUNC` test, emulated with a `tp_base` walk since
// WeavePy types aren't flattened), then runs only the Python-level dunder
// pair through the VM — never the full dispatch protocol, which would
// recurse back into these slots.

/// Shared `SLOT1BIN` body. `me` is the calling trampoline's own address;
/// `getter` projects this trampoline's slot out of a `PyNumberMethods`.
unsafe fn synth_nb_binop(
    x: *mut PyObject,
    y: *mut PyObject,
    dunder: &'static str,
    rdunder: &'static str,
    getter: fn(*mut crate::layout::PyNumberMethods) -> *mut c_void,
    me: *mut c_void,
) -> *mut PyObject {
    let resolve = |o: *mut PyObject| -> *mut c_void {
        let mut ty = unsafe { (*o).ob_type } as *mut crate::layout::PyTypeObjectFull;
        let mut guard = 0;
        while !ty.is_null() && guard < 100 {
            let nb = unsafe { (*ty).tp_as_number };
            if !nb.is_null() {
                let s = getter(nb);
                if !s.is_null() {
                    return s;
                }
            }
            ty = unsafe { (*ty).tp_base };
            guard += 1;
        }
        ptr::null_mut()
    };
    let a_owns = resolve(x) == me;
    let b_owns = resolve(y) == me;
    let same_type = unsafe { (*x).ob_type == (*y).ob_type };
    let ox = unsafe { crate::object::clone_object(x) };
    let oy = unsafe { crate::object::clone_object(y) };
    match crate::interp::ensure_active(|| {
        crate::interp::with_interp_mut(|interp| {
            interp.slot_nb_binop_public(&ox, &oy, dunder, rdunder, a_owns, b_owns, same_type)
        })
    }) {
        Some(Ok(v)) => crate::object::into_owned(v),
        Some(Err(e)) => {
            crate::errors::set_pending_from_runtime(e);
            ptr::null_mut()
        }
        None => {
            let ni = crate::singletons::not_implemented_ptr();
            unsafe { crate::object::Py_IncRef(ni) };
            ni
        }
    }
}

macro_rules! synth_nb_binary {
    ($fname:ident, $field:ident, $dunder:literal, $rdunder:literal) => {
        unsafe extern "C" fn $fname(x: *mut PyObject, y: *mut PyObject) -> *mut PyObject {
            unsafe {
                synth_nb_binop(
                    x,
                    y,
                    $dunder,
                    $rdunder,
                    |nb| unsafe { (*nb).$field },
                    $fname as *mut c_void,
                )
            }
        }
    };
}

synth_nb_binary!(synth_nb_add, nb_add, "__add__", "__radd__");
synth_nb_binary!(synth_nb_subtract, nb_subtract, "__sub__", "__rsub__");
synth_nb_binary!(synth_nb_multiply, nb_multiply, "__mul__", "__rmul__");
synth_nb_binary!(synth_nb_remainder, nb_remainder, "__mod__", "__rmod__");
synth_nb_binary!(synth_nb_divmod, nb_divmod, "__divmod__", "__rdivmod__");
synth_nb_binary!(synth_nb_lshift, nb_lshift, "__lshift__", "__rlshift__");
synth_nb_binary!(synth_nb_rshift, nb_rshift, "__rshift__", "__rrshift__");
synth_nb_binary!(synth_nb_and, nb_and, "__and__", "__rand__");
synth_nb_binary!(synth_nb_xor, nb_xor, "__xor__", "__rxor__");
synth_nb_binary!(synth_nb_or, nb_or, "__or__", "__ror__");
synth_nb_binary!(
    synth_nb_floor_divide,
    nb_floor_divide,
    "__floordiv__",
    "__rfloordiv__"
);
synth_nb_binary!(
    synth_nb_true_divide,
    nb_true_divide,
    "__truediv__",
    "__rtruediv__"
);
synth_nb_binary!(
    synth_nb_matrix_multiply,
    nb_matrix_multiply,
    "__matmul__",
    "__rmatmul__"
);

/// `slot_nb_power`: the binary dance for a `None` modulus, else only
/// `x.__pow__(y, m)` (CPython consults no reflected form with a modulus).
unsafe extern "C" fn synth_nb_power(
    x: *mut PyObject,
    y: *mut PyObject,
    m: *mut PyObject,
) -> *mut PyObject {
    if m.is_null() || m == crate::singletons::none_ptr() {
        return unsafe {
            synth_nb_binop(
                x,
                y,
                "__pow__",
                "__rpow__",
                |nb| unsafe { (*nb).nb_power },
                synth_nb_power as *mut c_void,
            )
        };
    }
    let ox = unsafe { crate::object::clone_object(x) };
    let oy = unsafe { crate::object::clone_object(y) };
    let om = unsafe { crate::object::clone_object(m) };
    match crate::interp::ensure_active(|| {
        crate::interp::with_interp_mut(|interp| interp.slot_nb_pow3_public(&ox, &oy, &om))
    }) {
        Some(Ok(v)) => crate::object::into_owned(v),
        Some(Err(e)) => {
            crate::errors::set_pending_from_runtime(e);
            ptr::null_mut()
        }
        None => {
            let ni = crate::singletons::not_implemented_ptr();
            unsafe { crate::object::Py_IncRef(ni) };
            ni
        }
    }
}

macro_rules! synth_nb_inplace {
    ($fname:ident, $dunder:literal) => {
        unsafe extern "C" fn $fname(x: *mut PyObject, y: *mut PyObject) -> *mut PyObject {
            let ox = unsafe { crate::object::clone_object(x) };
            let oy = unsafe { crate::object::clone_object(y) };
            match crate::interp::ensure_active(|| {
                crate::interp::with_interp_mut(|interp| {
                    interp.slot_nb_inplace_public(&ox, &oy, $dunder)
                })
            }) {
                Some(Ok(v)) => crate::object::into_owned(v),
                Some(Err(e)) => {
                    crate::errors::set_pending_from_runtime(e);
                    ptr::null_mut()
                }
                None => {
                    let ni = crate::singletons::not_implemented_ptr();
                    unsafe { crate::object::Py_IncRef(ni) };
                    ni
                }
            }
        }
    };
}

synth_nb_inplace!(synth_nb_inplace_add, "__iadd__");
synth_nb_inplace!(synth_nb_inplace_subtract, "__isub__");
synth_nb_inplace!(synth_nb_inplace_multiply, "__imul__");
synth_nb_inplace!(synth_nb_inplace_remainder, "__imod__");
synth_nb_inplace!(synth_nb_inplace_lshift, "__ilshift__");
synth_nb_inplace!(synth_nb_inplace_rshift, "__irshift__");
synth_nb_inplace!(synth_nb_inplace_and, "__iand__");
synth_nb_inplace!(synth_nb_inplace_xor, "__ixor__");
synth_nb_inplace!(synth_nb_inplace_or, "__ior__");
synth_nb_inplace!(synth_nb_inplace_floor_divide, "__ifloordiv__");
synth_nb_inplace!(synth_nb_inplace_true_divide, "__itruediv__");
synth_nb_inplace!(synth_nb_inplace_matrix_multiply, "__imatmul__");

macro_rules! synth_nb_unary {
    ($fname:ident, $dunder:literal) => {
        unsafe extern "C" fn $fname(o: *mut PyObject) -> *mut PyObject {
            let oo = unsafe { crate::object::clone_object(o) };
            match crate::interp::ensure_active(|| {
                crate::interp::with_interp_mut(|interp| interp.slot_nb_unary_public(&oo, $dunder))
            }) {
                Some(Ok(v)) => crate::object::into_owned(v),
                Some(Err(e)) => {
                    crate::errors::set_pending_from_runtime(e);
                    ptr::null_mut()
                }
                None => {
                    crate::errors::set_type_error("no active interpreter for unary slot");
                    ptr::null_mut()
                }
            }
        }
    };
}

synth_nb_unary!(synth_nb_negative, "__neg__");
synth_nb_unary!(synth_nb_positive, "__pos__");
synth_nb_unary!(synth_nb_absolute, "__abs__");
synth_nb_unary!(synth_nb_invert, "__invert__");
synth_nb_unary!(synth_nb_int, "__int__");
synth_nb_unary!(synth_nb_float, "__float__");
synth_nb_unary!(synth_nb_index, "__index__");

/// `slot_nb_bool` (an `inquiry`): call `__bool__`, demanding a `bool`
/// result exactly as CPython does.
unsafe extern "C" fn synth_nb_bool(o: *mut PyObject) -> c_int {
    let oo = unsafe { crate::object::clone_object(o) };
    match crate::interp::ensure_active(|| {
        crate::interp::with_interp_mut(|interp| interp.slot_nb_unary_public(&oo, "__bool__"))
    }) {
        Some(Ok(Object::Bool(b))) => c_int::from(b),
        Some(Ok(other)) => {
            crate::errors::set_type_error(format!(
                "__bool__ should return bool, returned {}",
                other.type_name()
            ));
            -1
        }
        Some(Err(e)) => {
            crate::errors::set_pending_from_runtime(e);
            -1
        }
        None => -1,
    }
}

/// CPython's `slot_tp_richcompare` analogue: dispatch a rich comparison
/// through the VM so a Python-level `__eq__`/`__lt__`/… override on a
/// VM-defined class wins over any C `tp_richcompare` inherited from a
/// readied extension base. Installed by [`synth_protocol_slots`] only when
/// the class (or a VM ancestor below `object`) defines a rich-compare
/// dunder in its own class dict, so `inherit_slots` keeps the base's C
/// slot for pure pass-through subclasses. Must **not** route through
/// `PyObject_RichCompare` (which reads this very slot — instant
/// recursion); `richcompare_via_vm` enters the VM protocol directly.
unsafe extern "C" fn synth_tp_richcompare(
    a: *mut PyObject,
    b: *mut PyObject,
    op: std::os::raw::c_int,
) -> *mut PyObject {
    // Slot semantics (CPython `slot_tp_richcompare`): dispatch only the
    // receiver's own dunder and *decline* with `NotImplemented` otherwise.
    // The calling protocol (`do_richcompare`) owns the reflected leg and
    // the final unsupported-ordering `TypeError` — running the VM's full
    // compare protocol here raised that error from the reflected slot call
    // with swapped operands/operator.
    if let Some(r) = unsafe { crate::abstract_::richcompare_slot_via_vm(a, b, op) } {
        return r;
    }
    // No interpreter active: decline so the caller's protocol continues.
    let ni = crate::singletons::not_implemented_ptr();
    unsafe { crate::object::Py_IncRef(ni) };
    ni
}

/// `object.__hash__` — CPython's `_Py_HashPointer` identity hash, used for
/// `PyBaseObject_Type.tp_hash`.
///
/// This must be **self-contained** (no re-entry into the VM), because stock C
/// extensions read `PyBaseObject_Type->tp_hash` *directly off the struct* and
/// call it — numpy's `datetime_arrtype_hash`/`timedelta_arrtype_hash` do
/// exactly this for a `NaT` scalar (`Py_TYPE == object`'s slot, hash by
/// identity). Routing that through the VM-forwarding `synth_tp_hash` would
/// re-enter `PyObject_Hash → py_hash_value(Foreign) → fwd_hash → the numpy
/// slot → object.tp_hash` and recurse until the stack overflows.
///
/// The rotate-right-by-4 of the object address matches both CPython's
/// `_Py_HashPointer` and WeavePy's VM-side [`weavepy_vm::object::identity_hash`]
/// for a foreign object (keyed on the same `PyObject*`), so a value hashed
/// through this C slot agrees bit-for-bit with the VM's identity hash of the
/// same object — dict/set keying stays consistent across the C↔VM boundary.
pub(crate) unsafe extern "C" fn object_generic_hash(o: *mut PyObject) -> crate::object::PyHashT {
    let u = o as usize as u64;
    let v = u.rotate_right(4) as crate::object::PyHashT;
    if v == -1 {
        -2
    } else {
        v
    }
}

/// `str.__hash__` — CPython's `unicode_hash`, which reads the string value
/// straight off the object and hashes it. Like [`object_generic_hash`] this
/// must be **self-contained** (no re-entry into generic VM hash dispatch): a
/// `str` *subtype* (numpy's `str_`) inherits this slot via `inherit_slots`,
/// and the VM resolves such an instance's `__hash__` back to this very slot —
/// forwarding to `PyObject_Hash` would ping-pong `VM → C → VM` forever.
/// Reads, in order: the native `Str`/`WStr` box, an instance's wrapped
/// native payload (a faithful C-built subtype body seeds it on first
/// crossing), and the faithful unicode body itself.
pub(crate) unsafe extern "C" fn unicode_value_hash(o: *mut PyObject) -> crate::object::PyHashT {
    let norm = |v: i64| {
        if v == -1 {
            -2isize as crate::object::PyHashT
        } else {
            v as crate::object::PyHashT
        }
    };
    match unsafe { crate::object::clone_object(o) } {
        Object::Str(s) => norm(weavepy_vm::object::py_str_hash(&s)),
        Object::WStr(cps) => norm(weavepy_vm::object::py_wstr_hash(&cps)),
        Object::Instance(inst) => match inst.native.get() {
            Some(Object::Str(s)) => norm(weavepy_vm::object::py_str_hash(s)),
            Some(Object::WStr(cps)) => norm(weavepy_vm::object::py_wstr_hash(cps)),
            _ => match unsafe { crate::mirror::read_unicode_value(o) } {
                Some(s) => norm(weavepy_vm::object::py_str_hash(&s)),
                None => {
                    crate::errors::set_type_error("unhashable type: expected str value");
                    -1
                }
            },
        },
        _ => match unsafe { crate::mirror::read_unicode_value(o) } {
            Some(s) => norm(weavepy_vm::object::py_str_hash(&s)),
            None => {
                crate::errors::set_type_error("descriptor '__hash__' requires a 'str' object");
                -1
            }
        },
    }
}

/// `bytes.__hash__` — CPython's `bytes_hash`; the `bytes` counterpart of
/// [`unicode_value_hash`], with the same self-containment requirement
/// (numpy's `bytes_` inherits it).
pub(crate) unsafe extern "C" fn bytes_value_hash(o: *mut PyObject) -> crate::object::PyHashT {
    let norm = |v: i64| {
        if v == -1 {
            -2isize as crate::object::PyHashT
        } else {
            v as crate::object::PyHashT
        }
    };
    match unsafe { crate::object::clone_object(o) } {
        Object::Bytes(b) => norm(weavepy_vm::object::py_bytes_hash(&b)),
        Object::Instance(inst) => match inst.native.get() {
            Some(Object::Bytes(b)) => norm(weavepy_vm::object::py_bytes_hash(b)),
            _ => match unsafe { crate::mirror::read_bytes_value(o) } {
                Some(b) => norm(weavepy_vm::object::py_bytes_hash(&b)),
                None => {
                    crate::errors::set_type_error("unhashable type: expected bytes value");
                    -1
                }
            },
        },
        _ => match unsafe { crate::mirror::read_bytes_value(o) } {
            Some(b) => norm(weavepy_vm::object::py_bytes_hash(&b)),
            None => {
                crate::errors::set_type_error("descriptor '__hash__' requires a 'bytes' object");
                -1
            }
        },
    }
}

/// Address of the VM-forwarding `tp_hash` bridge. `hash_via_slot` uses it to
/// short-circuit the shim for a *foreign* object: such an object's VM hash
/// (`py_hash_value` → `foreign::hash` → `fwd_hash` → `hash_via_slot`) would
/// otherwise re-enter this bridge (`synth_tp_hash` → `PyObject_Hash` →
/// `hash_public` → `py_hash_value`) and ping-pong `VM → C → VM` until the
/// stack overflows. The bridge adds nothing over the VM's own dispatch for a
/// foreign value, so it must be treated as "no native slot".
pub(crate) fn synth_tp_hash_addr() -> *mut c_void {
    synth_tp_hash as *mut c_void
}

/// Address of the VM-forwarding `tp_richcompare` bridge — the rich-compare
/// counterpart of [`synth_tp_hash_addr`]. `fwd_compare` (the VM→C compare
/// hook) must treat this slot as absent: the VM's `rich_compare_obj` routes
/// a foreign-operand comparison to the C slots, and if the *other* operand
/// is a VM class wearing this bridge (pandas `CategoricalDtype`, whose
/// Python `__eq__` installs it), invoking it re-enters `rich_compare_obj`
/// for the same pair — `fwd_compare → synth_tp_richcompare →
/// richcompare_via_vm → rich_compare_obj → fwd_compare` until the native
/// stack overflows (seen with `Series.astype("category")` comparing
/// `CategoricalDtype == numpy.dtypes.ObjectDType`).
pub(crate) fn synth_tp_richcompare_addr() -> *mut c_void {
    synth_tp_richcompare as *mut c_void
}
unsafe extern "C" fn synth_length(o: *mut PyObject) -> PySsizeT {
    unsafe { crate::abstract_::PyObject_Length(o) }
}
unsafe extern "C" fn synth_subscript(o: *mut PyObject, k: *mut PyObject) -> *mut PyObject {
    unsafe { crate::abstract_::PyObject_GetItem(o, k) }
}
unsafe extern "C" fn synth_ass_subscript(
    o: *mut PyObject,
    k: *mut PyObject,
    v: *mut PyObject,
) -> c_int {
    unsafe { crate::abstract_::PyObject_SetItem(o, k, v) }
}

/// `tp_descr_get` for WeavePy callables (plain functions, instance-binding
/// builtin methods, method descriptors) that cross into a C extension as a
/// type-dict entry.
///
/// CPython's special-method protocol — the one Cython emits for `with`,
/// `for`, operators (`__Pyx_PyObject_LookupSpecial`) — does
/// `res = _PyType_Lookup(tp, name); f = Py_TYPE(res)->tp_descr_get; res =
/// f(res, obj, tp);` to **bind** the found descriptor to the instance. With
/// no `tp_descr_get` wired on the function/method types the descriptor was
/// taken *unbound*, so a bound special method (e.g. a lock's `__exit__`) was
/// then called with `self` missing — surfacing as `AttributeError`/`TypeError`
/// deep inside an extension's module init. This mirrors CPython's
/// `func_descr_get` / `method_get`: bind to `obj` (yielding a `method`), or
/// return the descriptor unchanged for class access (`obj == NULL`/`None`) and
/// for a non-instance-binding builtin (a static/module function).
unsafe extern "C" fn callable_descr_get(
    descr: *mut PyObject,
    obj: *mut PyObject,
    _type: *mut PyObject,
) -> *mut PyObject {
    if std::env::var_os("WEAVEPY_TRACE_CTOR").is_some() {
        let dty = if descr.is_null() {
            ptr::null_mut()
        } else {
            unsafe { (*descr).ob_type }
        };
        eprintln!("[DESCRGET] descr={descr:p} descr.ob_type={dty:p} obj={obj:p} type={_type:p}");
    }
    let trace = std::env::var_os("WEAVEPY_TRACE_CTOR").is_some();
    if descr.is_null() {
        return ptr::null_mut();
    }
    // Class access (`Type.method`) yields the descriptor unchanged.
    if obj.is_null() {
        unsafe { crate::object::Py_IncRef(descr) };
        return descr;
    }
    if trace {
        eprintln!("[DESCRGET] step=clone_obj");
    }
    let receiver = unsafe { crate::object::clone_object(obj) };
    if trace {
        eprintln!(
            "[DESCRGET] step=clone_obj_done recv={}",
            receiver.type_name()
        );
    }
    if matches!(receiver, Object::None) {
        unsafe { crate::object::Py_IncRef(descr) };
        return descr;
    }
    if trace {
        eprintln!("[DESCRGET] step=clone_descr");
    }
    let d = unsafe { crate::object::clone_object(descr) };
    if trace {
        eprintln!("[DESCRGET] step=clone_descr_done d={}", d.type_name());
    }
    let bind = match &d {
        Object::Function(_) => true,
        Object::Builtin(b) => b.binds_instance,
        _ => false,
    };
    if !bind {
        unsafe { crate::object::Py_IncRef(descr) };
        return descr;
    }
    if trace {
        eprintln!("[DESCRGET] step=make_bound");
    }
    let bound = Object::BoundMethod(Rc::new(BoundMethod::new(receiver, d)));
    if trace {
        eprintln!("[DESCRGET] step=into_owned");
    }
    let r = crate::object::into_owned(bound);
    if trace {
        eprintln!("[DESCRGET] step=done r={r:p}");
    }
    r
}

/// `tp_descr_get` for the descriptor statics (`PyClassMethod_Type`,
/// `PyStaticMethod_Type`, `PyProperty_Type`) — CPython's `cm_descr_get`
/// / `sm_descr_get` / `property_descr_get`, expressed over the VM
/// payloads (RFC 0062 WS2). wrapt's C `FunctionWrapper` resolves a
/// wrapped descriptor via `Py_TYPE(wrapped)->tp_descr_get`; without
/// this slot the raw classmethod/staticmethod object crossed unbound.
unsafe extern "C" fn descriptor_descr_get(
    descr: *mut PyObject,
    obj: *mut PyObject,
    type_: *mut PyObject,
) -> *mut PyObject {
    if descr.is_null() {
        return ptr::null_mut();
    }
    let take_descr = || {
        unsafe { crate::object::Py_IncRef(descr) };
        descr
    };
    let d = unsafe { crate::object::clone_object(descr) };
    match &d {
        // `staticmethod.__get__` ignores the receiver entirely.
        Object::StaticMethod(w) => crate::object::into_owned(w.func()),
        // `classmethod.__get__` binds `__func__` to the owner *class*
        // (falling back to `type(obj)` when no owner was supplied).
        Object::ClassMethod(w) => {
            let owner = if !type_.is_null() {
                let o = unsafe { crate::object::clone_object(type_) };
                if matches!(o, Object::None) {
                    None
                } else {
                    Some(o)
                }
            } else {
                None
            };
            let owner = owner.or_else(|| {
                if obj.is_null() {
                    return None;
                }
                let t = unsafe { crate::abstract_::PyObject_Type(obj) };
                if t.is_null() {
                    return None;
                }
                let o = unsafe { crate::object::clone_object(t) };
                unsafe { crate::object::Py_DecRef(t) };
                Some(o)
            });
            match owner {
                Some(owner) => crate::object::into_owned(Object::BoundMethod(Rc::new(
                    BoundMethod::new(owner, w.func()),
                ))),
                None => take_descr(),
            }
        }
        // `property.__get__(None, type)` yields the property itself;
        // otherwise call the getter with the instance.
        Object::Property(p) => {
            if obj.is_null() {
                return take_descr();
            }
            let recv = unsafe { crate::object::clone_object(obj) };
            if matches!(recv, Object::None) {
                return take_descr();
            }
            let fget = p.fget();
            if matches!(fget, Object::None) {
                unsafe {
                    crate::errors::PyErr_SetString(
                        crate::errors::PyExc_AttributeError,
                        c"unreadable attribute".as_ptr(),
                    );
                }
                return ptr::null_mut();
            }
            let f = crate::object::into_owned(fget);
            let r = unsafe { crate::abstract_::PyObject_CallOneArg(f, obj) };
            unsafe { crate::object::Py_DecRef(f) };
            r
        }
        // RFC 0076 WS5: a *foreign* instance of a property subclass.
        // pybind11's `pybind11_static_property` chains its own
        // `tp_descr_get` (`pybind11_static_get`) to
        // `PyProperty_Type.tp_descr_get(self, cls, cls)` — this slot —
        // with the class as the receiver, expecting `fget` evaluation
        // (that is the whole point of a *static* property). The members
        // live on the C object; resolve `fget` through the attribute
        // protocol and call it. No `fget` → fall through to the raw
        // descriptor, the historical behaviour.
        Object::Foreign(_) | Object::Instance(_) => {
            if obj.is_null() {
                return take_descr();
            }
            let recv = unsafe { crate::object::clone_object(obj) };
            if matches!(recv, Object::None) {
                return take_descr();
            }
            let f = unsafe { crate::abstract_::PyObject_GetAttrString(descr, c"fget".as_ptr()) };
            if f.is_null() {
                crate::errors::clear_thread_local();
                return take_descr();
            }
            if matches!(unsafe { crate::object::clone_object(f) }, Object::None) {
                unsafe { crate::object::Py_DecRef(f) };
                return take_descr();
            }
            let r = unsafe { crate::abstract_::PyObject_CallOneArg(f, obj) };
            unsafe { crate::object::Py_DecRef(f) };
            r
        }
        _ => take_descr(),
    }
}

/// `PyProperty_Type.tp_descr_set` — CPython's `property_descr_set`:
/// call `fset(obj, value)` (`fdel(obj)` when `value` is NULL).
///
/// The slot's *presence* matters as much as its body: numpy's
/// `PyArray_View` decides between its `_set_dtype` and legacy in-place
/// paths by testing `Py_TYPE(sub_dtype)->tp_descr_set != NULL` on the
/// subclass's `dtype` attribute — with the slot NULL a subclass `dtype`
/// property setter was silently bypassed (Path 4) instead of invoked
/// with the 2.5 deprecation (Path 3) (RFC 0076 WS1,
/// test_view_dtype_property_setter). `PyObject_GenericSetAttr` also
/// consults it for the data-descriptor branch.
unsafe extern "C" fn property_descr_set(
    descr: *mut PyObject,
    obj: *mut PyObject,
    value: *mut PyObject,
) -> c_int {
    if descr.is_null() || obj.is_null() {
        crate::errors::set_type_error("__set__(None, None) is invalid");
        return -1;
    }
    let d = unsafe { crate::object::clone_object(descr) };
    let Object::Property(p) = &d else {
        crate::errors::set_type_error("descriptor __set__ requires a property");
        return -1;
    };
    let f = if value.is_null() { p.fdel() } else { p.fset() };
    if matches!(f, Object::None) {
        crate::errors::set_attribute_error(if value.is_null() {
            "property has no deleter"
        } else {
            "property has no setter"
        });
        return -1;
    }
    let fp = crate::object::into_owned(f);
    let r = if value.is_null() {
        unsafe { crate::abstract_::PyObject_CallOneArg(fp, obj) }
    } else {
        unsafe { crate::abstract_::PyObject_CallTwoArgs(fp, obj, value) }
    };
    unsafe { crate::object::Py_DecRef(fp) };
    if r.is_null() {
        return -1;
    }
    unsafe { crate::object::Py_DecRef(r) };
    0
}

/// `PyType_Type.tp_getattro` — CPython's `type_getattro` **default
/// body**, with no metaclass dispatch (RFC 0066 WS3).
///
/// pybind11's metaclass `tp_getattro` (`pybind11_meta_getattro`) handles
/// its instancemethod special case and then chains to
/// `PyType_Type.tp_getattro(cls, name)` read *directly off the struct*;
/// a NULL slot was a jump to address zero the first time a pybind11
/// module touched an attribute of one of its own classes (scipy's
/// `_highspy._core` registering `ObjSense`). Routing the chain through
/// full `PyObject_GetAttr` would dispatch the metaclass override again
/// and recurse — so this calls the VM's non-dispatching default.
unsafe extern "C" fn type_generic_getattro(o: *mut PyObject, name: *mut PyObject) -> *mut PyObject {
    if o.is_null() || name.is_null() {
        return ptr::null_mut();
    }
    let key = match unsafe { crate::object::clone_object(name) } {
        Object::Str(s) => s.to_string(),
        _ => {
            crate::errors::set_type_error("attribute name must be string");
            return ptr::null_mut();
        }
    };
    // This slot only ever runs on *type* instances, so a receiver that
    // does not already clone to `Object::Type` is a `PyTypeObject*` the
    // VM has not bridged yet (e.g. a Cython class instantiated before
    // anything imported it through the bridge) — ready + bridge it and
    // resolve through the same default protocol. Falling back to the
    // full `PyObject_GetAttr` here re-dispatches this very slot and
    // recurses without progress (measured: gevent `local()`, whose
    // Cython `__cinit__` walks the MRO fetching `__get__` off unbridged
    // C descriptor types, overflowed with RecursionError).
    let ty = match unsafe { crate::object::clone_object(o) } {
        Object::Type(t) => Some(t),
        _ => unsafe { bridge_or_ready(o.cast::<PyTypeObject>()) },
    };
    if let Some(ty) = ty {
        if let Some(res) = crate::interp::ensure_active(|| {
            crate::interp::with_interp_mut(|interp| interp.type_getattr_default(&ty, &key))
        }) {
            return match res {
                Ok(v) => crate::object::into_owned(v),
                Err(e) => {
                    crate::errors::set_pending_from_runtime(e);
                    ptr::null_mut()
                }
            };
        }
    }
    // No interpreter (or an unbridgeable pointer): resolve through the
    // generic instance protocol, which never re-enters this slot.
    unsafe { crate::genericalloc::PyObject_GenericGetAttr(o, name) }
}

/// `PyType_Type.tp_setattro` — CPython's `type_setattro` default body
/// (NULL `value` deletes), no metaclass dispatch. pybind11's
/// `pybind11_meta_setattro` chains here for every `class_::def`.
unsafe extern "C" fn type_generic_setattro(
    o: *mut PyObject,
    name: *mut PyObject,
    value: *mut PyObject,
) -> c_int {
    if o.is_null() || name.is_null() {
        return -1;
    }
    let obj = unsafe { crate::object::clone_object(o) };
    if let Object::Type(ty) = &obj {
        let key = match unsafe { crate::object::clone_object(name) } {
            Object::Str(s) => s.to_string(),
            _ => {
                crate::errors::set_type_error("attribute name must be string");
                return -1;
            }
        };
        let val = if value.is_null() {
            None
        } else {
            Some(unsafe { crate::object::clone_object(value) })
        };
        if let Some(res) = crate::interp::ensure_active(|| {
            crate::interp::with_interp_mut(|interp| match val.clone() {
                Some(v) => interp.type_setattr_default(ty, &key, v),
                None => interp.type_delattr_default(ty, &key),
            })
        }) {
            return match res {
                Ok(()) => 0,
                Err(e) => {
                    crate::errors::set_pending_from_runtime(e);
                    -1
                }
            };
        }
    }
    if value.is_null() {
        unsafe { crate::abstract_::PyObject_SetAttr(o, name, ptr::null_mut()) }
    } else {
        unsafe { crate::abstract_::PyObject_SetAttr(o, name, value) }
    }
}

/// Serialises synth-type creation so a class crossing concurrently mints
/// exactly one type.
static SYNTH_LOCK: Mutex<()> = Mutex::new(());

/// True when `cls` (or any base) defines `name` as a non-`None` attribute.
fn class_has_dunder(cls: &Rc<TypeObject>, name: &str) -> bool {
    !matches!(cls.lookup(name), None | Some(Object::None))
}

/// Populate a synthesised mirror's C-level protocol slots from `cls`'s
/// Python dunder methods. Macro-heavy extension code (Cython's
/// `__Pyx_PyObject_GetItem` → `Py_TYPE(o)->tp_as_mapping->mp_subscript`,
/// `__Pyx_PyObject_Call` → `tp_call`, the `for`/`with` slot reads) consults
/// these slots *directly* off `Py_TYPE(obj)`, bypassing the abstract API. A
/// mirror that leaves them NULL therefore looks e.g. "not subscriptable" /
/// "not callable" to an extension even though the VM implements the operation
/// (pandas' `lib.pyx` does `Literal[_NoDefault.no_default]` — a `__getitem__`
/// on the frozen `typing._SpecialForm` — during single-pass module exec).
/// Shared by [`synth_type_for_class`] and [`install_user_type`] so every
/// Python-class crossing exposes a faithful slot table regardless of which
/// mirror-minting path built it. Each `synth_*` bridge forwards back into the
/// VM's dispatch.
fn synth_protocol_slots(ty: &mut PyTypeObject, cls: &Rc<TypeObject>) {
    if class_has_dunder(cls, "__iter__") {
        ty.tp_iter = synth_tp_iter as *mut c_void;
    }
    if class_has_dunder(cls, "__next__") {
        ty.tp_iternext = synth_tp_iternext as *mut c_void;
        // CPython iterators answer `iter(it) is it`; advertise tp_iter too.
        if ty.tp_iter.is_null() {
            ty.tp_iter = synth_tp_iter as *mut c_void;
        }
    }
    if class_has_dunder(cls, "__call__") {
        ty.tp_call = synth_tp_call as *mut c_void;
    }
    if class_has_dunder(cls, "__repr__") {
        ty.tp_repr = synth_tp_repr as *mut c_void;
    }
    if class_has_dunder(cls, "__str__") {
        ty.tp_str = synth_tp_str as *mut c_void;
    }
    if class_has_dunder(cls, "__hash__") {
        ty.tp_hash = synth_tp_hash as *mut c_void;
    }
    // Rich comparison: when the class — or a VM ancestor below `object` —
    // defines any rich-compare dunder in its *own* class dict, mirror
    // CPython's `type_new`, which gives such a type `slot_tp_richcompare`.
    // The synthesised slot dispatches through the VM so the Python
    // override wins; without it, `inherit_slots` copies the readied
    // extension base's C `tp_richcompare` down and a Cython
    // `PyObject_RichCompareBool` call (pandas `_libs.ops.scalar_compare`
    // on an object array) runs the *base*'s comparison — pandas'
    // `PeriodDtype.__eq__("Period[D]")` (a Python override of the cdef
    // `PeriodDtypeBase.__eq__`) compared False through the C path while
    // the direct `==` compared True. The MRO walk is intentionally
    // *own-dict* based (unlike [`class_has_dunder`]'s MRO-wide lookup):
    // a class inheriting only `object`'s identity comparison keeps a NULL
    // slot exactly as CPython leaves `tp_richcompare` inherited.
    {
        const RICHCMP_DUNDERS: [&str; 6] =
            ["__eq__", "__ne__", "__lt__", "__le__", "__gt__", "__ge__"];
        let defines_richcmp = cls.mro.borrow().iter().any(|t| {
            if t.name == "object" {
                return false;
            }
            let d = t.dict.borrow();
            RICHCMP_DUNDERS
                .iter()
                .any(|n| d.contains_key(&DictKey(Object::from_static(n))))
        });
        if defines_richcmp {
            ty.tp_richcompare = synth_tp_richcompare as *mut c_void;
        }
    }
    let has_len = class_has_dunder(cls, "__len__");
    let has_getitem = class_has_dunder(cls, "__getitem__");
    let has_setitem = class_has_dunder(cls, "__setitem__") || class_has_dunder(cls, "__delitem__");
    if has_len || has_getitem || has_setitem {
        let mut mm: crate::layout::PyMappingMethods = unsafe { std::mem::zeroed() };
        if has_len {
            mm.mp_length = synth_length as *mut c_void;
        }
        if has_getitem {
            mm.mp_subscript = synth_subscript as *mut c_void;
        }
        if has_setitem {
            mm.mp_ass_subscript = synth_ass_subscript as *mut c_void;
        }
        ty.tp_as_mapping = Box::into_raw(Box::new(mm)) as *mut c_void;
        if has_len {
            let mut sm: crate::layout::PySequenceMethods = unsafe { std::mem::zeroed() };
            sm.sq_length = synth_length as *mut c_void;
            ty.tp_as_sequence = Box::into_raw(Box::new(sm)) as *mut c_void;
        }
    }
    // Number suite — CPython's `fixup_slot_dispatchers` wires class-dict
    // numeric dunders into `tp_as_number` `slot_nb_*` trampolines; without
    // them a slot-protocol dispatch (`binary_op1` with a foreign partner,
    // Cython's inlined `PyNumber_*` calls) never reaches the VM dunder
    // (`np.timedelta64 % pandas.Timedelta` inside Cython's
    // `__rmod__ → __rdivmod__` raised "unsupported operand type"). A
    // slotdef pairs the forward and reflected names on the *same* slot, so
    // either one present wires the shared trampoline (its `SLOT1BIN` body
    // sorts out direction at call time).
    {
        let mut nb: crate::layout::PyNumberMethods = unsafe { std::mem::zeroed() };
        let mut any = false;
        macro_rules! wire {
            ($field:ident, $tramp:ident, $($d:literal),+) => {
                if $(class_has_dunder(cls, $d))||+ {
                    nb.$field = $tramp as *mut c_void;
                    any = true;
                }
            };
        }
        wire!(nb_add, synth_nb_add, "__add__", "__radd__");
        wire!(nb_subtract, synth_nb_subtract, "__sub__", "__rsub__");
        wire!(nb_multiply, synth_nb_multiply, "__mul__", "__rmul__");
        wire!(nb_remainder, synth_nb_remainder, "__mod__", "__rmod__");
        wire!(nb_divmod, synth_nb_divmod, "__divmod__", "__rdivmod__");
        wire!(nb_power, synth_nb_power, "__pow__", "__rpow__");
        wire!(nb_lshift, synth_nb_lshift, "__lshift__", "__rlshift__");
        wire!(nb_rshift, synth_nb_rshift, "__rshift__", "__rrshift__");
        wire!(nb_and, synth_nb_and, "__and__", "__rand__");
        wire!(nb_xor, synth_nb_xor, "__xor__", "__rxor__");
        wire!(nb_or, synth_nb_or, "__or__", "__ror__");
        wire!(
            nb_floor_divide,
            synth_nb_floor_divide,
            "__floordiv__",
            "__rfloordiv__"
        );
        wire!(
            nb_true_divide,
            synth_nb_true_divide,
            "__truediv__",
            "__rtruediv__"
        );
        wire!(
            nb_matrix_multiply,
            synth_nb_matrix_multiply,
            "__matmul__",
            "__rmatmul__"
        );
        wire!(nb_inplace_add, synth_nb_inplace_add, "__iadd__");
        wire!(nb_inplace_subtract, synth_nb_inplace_subtract, "__isub__");
        wire!(nb_inplace_multiply, synth_nb_inplace_multiply, "__imul__");
        wire!(nb_inplace_remainder, synth_nb_inplace_remainder, "__imod__");
        wire!(nb_inplace_lshift, synth_nb_inplace_lshift, "__ilshift__");
        wire!(nb_inplace_rshift, synth_nb_inplace_rshift, "__irshift__");
        wire!(nb_inplace_and, synth_nb_inplace_and, "__iand__");
        wire!(nb_inplace_xor, synth_nb_inplace_xor, "__ixor__");
        wire!(nb_inplace_or, synth_nb_inplace_or, "__ior__");
        wire!(
            nb_inplace_floor_divide,
            synth_nb_inplace_floor_divide,
            "__ifloordiv__"
        );
        wire!(
            nb_inplace_true_divide,
            synth_nb_inplace_true_divide,
            "__itruediv__"
        );
        wire!(
            nb_inplace_matrix_multiply,
            synth_nb_inplace_matrix_multiply,
            "__imatmul__"
        );
        wire!(nb_negative, synth_nb_negative, "__neg__");
        wire!(nb_positive, synth_nb_positive, "__pos__");
        wire!(nb_absolute, synth_nb_absolute, "__abs__");
        wire!(nb_invert, synth_nb_invert, "__invert__");
        wire!(nb_int, synth_nb_int, "__int__");
        wire!(nb_float, synth_nb_float, "__float__");
        wire!(nb_index, synth_nb_index, "__index__");
        wire!(nb_bool, synth_nb_bool, "__bool__");
        if any {
            ty.tp_as_number = Box::into_raw(Box::new(nb)) as *mut c_void;
        }
    }
}

/// Mint (or return the cached) faithful C type for a Python class whose
/// instances drive a C-level protocol Cython reads off `Py_TYPE(obj)`:
/// iteration (`__iter__`/`__next__`) or the context-manager protocol
/// (`__enter__`/`__exit__`, looked up via `_PyType_Lookup` for `with`).
/// Returns `None` for every other class, leaving the historic
/// `PyBaseObject_Type` crossing in place to keep the blast radius small.
pub(crate) fn synth_type_for_class(cls: &Rc<TypeObject>) -> Option<*mut PyTypeObject> {
    let is_iter = class_has_dunder(cls, "__iter__") || class_has_dunder(cls, "__next__");
    let is_ctx = class_has_dunder(cls, "__enter__") || class_has_dunder(cls, "__exit__");
    // RFC 0076 WS1: `__index__` too — `PyIndex_Check` is a header *macro*
    // (`tp_as_number->nb_index != NULL`), compiled inline into extensions.
    // numpy's `PyArray_IntpConverter` gates every shape argument on it, so
    // a plain-`PyBaseObject_Type` crossing turned `np.zeros(IntLike())`
    // (and the dtype shape tuple of `test_dtype::test_shape_sequence`)
    // into "expected a sequence of integers or a single integer".
    let is_index = class_has_dunder(cls, "__index__");
    if !is_iter && !is_ctx && !is_index {
        return None;
    }
    let _guard = SYNTH_LOCK.lock().ok()?;
    // Another thread may have minted + registered it between our caller's
    // `find_type_ptr` miss and acquiring the lock.
    if let Some(p) = find_type_ptr(cls) {
        return Some(p);
    }

    let meta = metaclass_ptr(cls);
    // RFC 0045 (wave 5): a synthesised shell can itself subclass an inline C
    // type — numpy's `class MaskedArray(ndarray)` is iterable, so it reaches
    // *this* path (not `install_user_type`) yet must still get a faithful
    // `tp_basicsize`-wide body. Without inheriting the base's inline layout
    // its instances were plain 16-byte boxes; numpy's `PyArray_NewFromDescr`
    // then wrote the `PyArrayObject` fields over the Rust `obj` payload and a
    // later `clone_object` dereferenced the clobbered pointer (a SIGBUS in
    // `numpy.ma.core`'s `array_view → __array_finalize__`).
    let (inline_base_ptr, base_inline, mut basicsize) = inherit_inline_base_layout(cls, 16);
    if !base_inline {
        if let Some(sz) = faithful_purepy_basicsize(cls) {
            basicsize = basicsize.max(sz);
        }
    }
    let owned_name = format!("{}\0", cls.name).into_bytes();
    let mut ty = PyTypeObject::new_zeroed();
    ty.head.ob_refcnt = IMMORTAL_REFCNT;
    ty.head.ob_type = meta;
    ty.tp_name = owned_name.as_ptr() as *const c_char;
    ty.tp_basicsize = basicsize;
    ty.tp_dealloc = Some(crate::object::_PyWeavePy_Dealloc);
    // Mirror CPython's `PyType_Ready` `tp_alloc`/`tp_free` defaults so a
    // foreign C `tp_new` subclassing this synthesised type can allocate
    // through its `tp_alloc` slot (see `install_user_type`).
    {
        let alloc_fp: unsafe extern "C" fn(*mut PyTypeObject, PySsizeT) -> *mut PyObject =
            crate::genericalloc::PyType_GenericAlloc;
        let new_fp: unsafe extern "C" fn(
            *mut PyTypeObject,
            *mut PyObject,
            *mut PyObject,
        ) -> *mut PyObject = crate::genericalloc::PyType_GenericNew;
        let free_fp: unsafe extern "C" fn(*mut c_void) = crate::memory::PyObject_Free;
        ty.tp_alloc = alloc_fp as *mut c_void;
        // Inherit the solid (best_base) inline base's faithful `tp_new` so
        // its `cdef object` fields are initialised (see the matching note in
        // `install_user_type`). Non-inline shells keep the generic allocator.
        ty.tp_new = if base_inline {
            let inherited = inline_base_ptr
                .filter(|bp| !bp.is_null())
                .map(|bp| unsafe { (*bp).tp_new })
                .unwrap_or(ptr::null_mut());
            if inherited.is_null() {
                new_fp as *mut c_void
            } else {
                inherited
            }
        } else {
            new_fp as *mut c_void
        };
        ty.tp_free = free_fp as *mut c_void;
    }
    // RFC 0047 (wave 5): `HEAPTYPE` — a `class` statement mints a heap type
    // on CPython, and Cython's cpdef override dispatch gates on the bit
    // (see the matching note in [`install_user_type`]). The box below is a
    // genuine `PyTypeObjectBox`, so `slot_table_for`'s HEAPTYPE-guarded
    // embedded-table read stays sound.
    ty.tp_flags = crate::layout::tpflags::DEFAULT
        | crate::layout::tpflags::BASETYPE
        | crate::layout::tpflags::READY
        | crate::layout::tpflags::HEAPTYPE
        | fast_subclass_flags(cls);
    // Point `tp_base` at the faithful inline base (so `PyType_IsSubtype`
    // and numpy's `PyArray_Check` walk to `ndarray`); a non-inline shell
    // keeps the historic bare-`object` base to bound the blast radius.
    ty.tp_base = if base_inline {
        inline_base_ptr.unwrap_or_else(|| PyBaseObject_Type.as_ptr())
    } else {
        PyBaseObject_Type.as_ptr()
    };
    ty.bridge = Box::into_raw(Box::new(cls.clone()));

    synth_protocol_slots(&mut ty, cls);

    let bx = Box::new(PyTypeObjectBox {
        head: ty,
        owned_name,
        slot_table: SlotTable::empty(),
    });
    let leaked = Box::leak(bx);
    let p = &mut leaked.head as *mut PyTypeObject;
    register_heap_type(p);
    // RFC 0069 WS5: publish faithful `tp_bases` / `tp_mro` post-
    // registration (see the matching note in [`install_user_type`] —
    // numpy's `PyArray_DescrFromTypeObject` walks `tp_mro` directly).
    unsafe {
        let bases_for_c: Vec<Rc<TypeObject>> = cls.bases.borrow().clone();
        let mro_for_c: Vec<Rc<TypeObject>> = cls.mro.borrow().clone();
        let tp_bases_box = build_type_ptr_tuple(&bases_for_c);
        if !tp_bases_box.is_null() {
            (*p).tp_bases = tp_bases_box;
        }
        let tp_mro_box = build_type_ptr_tuple(&mro_for_c);
        if !tp_mro_box.is_null() {
            (*p).tp_mro = tp_mro_box;
        }
        // RFC 0076 WS5: publish `tp_dict` sharing the bridge's `DictData`
        // (see the matching note in [`install_user_type`] — torch's
        // `get_tensor_dict` reads `torch.Tensor`'s `tp_dict` off the
        // struct, and `Tensor` defines `__iter__`, so it mints here).
        (*p).tp_dict = crate::object::into_owned(Object::Dict(cls.dict.clone()));
    }
    // Mirror the inline base: instances need the same faithful inline body
    // (RFC 0045) so fixed-offset field reads/writes land on real
    // CPython-shaped memory rather than the Rust `obj` payload.
    if base_inline {
        maybe_register_inline_type(p);
    } else {
        maybe_register_container_body_type(p);
    }
    Some(p)
}

/// Static table used by [`find_type_ptr`]. Listed once so we don't
/// drift the macro-declared slots and the lookup table apart.
static STATIC_TYPE_TABLE: &[&StaticType] = &[
    &PyType_Type,
    &PyBaseObject_Type,
    &PyLong_Type,
    &PyFloat_Type,
    &PyBool_Type,
    &PyComplex_Type,
    &PyUnicode_Type,
    &PyBytes_Type,
    &PyByteArray_Type,
    &PyTuple_Type,
    &PyList_Type,
    &PyDict_Type,
    &PySet_Type,
    &PyFrozenSet_Type,
    &PyRange_Type,
    &PyModule_Type,
    &_PyNone_Type,
    &_PyNotImplemented_Type,
    &PyEllipsis_Type,
    &PyCapsule_Type,
    &PySlice_Type,
    &PyFunction_Type,
    &PyCFunction_Type,
    &PyMethod_Type,
    &PyGen_Type,
    &PyCoro_Type,
    &PyAsyncGen_Type,
    &PySeqIter_Type,
    // RFC 0055 WS5 (mypyc tail): membership makes `is_weavepy_owned_type`
    // accept these statics so `bridge_type` may read their bridge — mypyc's
    // `_init_subclass` *vectorcalls* `&PySuper_Type` (super(cls, cls)), which
    // otherwise proxies as a non-callable foreign 'object'.
    &PyDictKeys_Type,
    &PyDictValues_Type,
    &PyDictItems_Type,
    &PySuper_Type,
    // RFC 0062 WS2: descriptor types source-built extensions reference by
    // address (wrapt). Membership keeps identity + bridge lookups working.
    &PyClassMethod_Type,
    &PyStaticMethod_Type,
    &PyProperty_Type,
    &PyReversed_Type,
    // RFC 0066 WS3: membership resolves `type(im)` for the foreign
    // instancemethod proxies pybind11 mints.
    &PyInstanceMethod_Type,
    // RFC 0072 WS2: gevent's Cython caches `_memoryview = memoryview` as
    // `&PyMemoryView_Type` and *calls* it (`get_memory`); membership lets
    // `bridge_type` resolve the static to the real VM `memoryview` class so
    // `type_tp_call` constructs a working memoryview. `PyDictProxy_Type`
    // likewise round-trips (`type(cls.__dict__)` through the C surface).
    &PyMemoryView_Type,
    &PyDictProxy_Type,
];

/// Borrow the bridged native type from a [`PyTypeObject`].
///
/// SAFETY: `ty` must be either null or a valid pointer to a
/// statically- or heap-allocated type whose `bridge` has been
/// initialised.
pub unsafe fn bridge_type(ty: *mut PyTypeObject) -> Option<Rc<TypeObject>> {
    if ty.is_null() {
        return None;
    }
    // Readied stock types (RFC 0044) keep their bridge in a side
    // registry — their struct is only 416 bytes and has no `bridge`
    // field to read. Check that first.
    if let Some(rt) = readied_for(ty) {
        adopt_ob_type_drift(rt);
        return Some(rt.bridge.clone());
    }
    // RFC 0046 (wave 4): the private `bridge` field sits at offset 424 —
    // *past* the 416-byte stock `PyTypeObject`. A foreign extension type
    // (numpy's metatypes, an un-readied static type) is exactly that stock
    // size, so reading `.bridge` would be an out-of-bounds heap read (it
    // surfaced as a misaligned-pointer fault on a numpy type). Only our own
    // static/heap type boxes carry the field; decide by pointer identity.
    if !is_weavepy_owned_type(ty) {
        return None;
    }
    let bridge = unsafe { (*ty).bridge };
    if bridge.is_null() {
        return None;
    }
    Some(unsafe { (*bridge).clone() })
}

/// Adopt a raw `Py_SET_TYPE(&MyType, meta)` metaclass re-seat of a
/// readied stock type into its VM bridge (RFC 0076 WS5, see
/// [`ReadiedType::ob_type_seen`]). One relaxed load + pointer compare on
/// the common no-drift path.
fn adopt_ob_type_drift(rt: &ReadiedType) {
    let live = unsafe { (*rt.ext_ptr).head.ob_type } as usize;
    if live == 0 || live == rt.ob_type_seen.load(std::sync::atomic::Ordering::Relaxed) {
        return;
    }
    rt.ob_type_seen
        .store(live, std::sync::atomic::Ordering::Relaxed);
    if let Some(meta) = unsafe { bridge_type(live as *mut PyTypeObject) } {
        rt.bridge.set_metaclass(meta);
    }
}

/// [`TypeObject::metaclass_or_type`]'s drift probe (see
/// [`weavepy_vm::types::TypeObject::c_ext_ptr`]): re-check the readied
/// struct's live `ob_type` the moment Python asks for the class of the
/// class. `_bridge` is `rt.bridge` for a registered pointer; the lookup
/// keys on the pointer alone.
pub(crate) fn metaclass_drift_probe(ext: usize, _bridge: &TypeObject) {
    if let Some(rt) = readied_for(ext as *mut PyTypeObject) {
        adopt_ob_type_drift(rt);
    }
}

/// Resolve a `PyTypeObject*` to its bridged [`TypeObject`], readying it
/// on demand if it has not been bridged yet.
///
/// CPython's `PyType_Ready` finalises a type's **bases before the type
/// itself** (`type_ready` → `type_ready_mro`, which `PyType_Ready`s each
/// base). A stock extension that readies a subtype before its base —
/// numpy registers `Float16DType` before `PyType_Ready(&PyArrayDescr_Type)`
/// has run in some import orders — would otherwise lose the base entirely:
/// `bridge_type` returns `None`, the bridged type silently falls back to
/// `object`, and the subtype's MRO collapses to `[Self, object]`. That
/// dropped every getset the base declares (e.g. `numpy.dtype.type`).
///
/// SAFETY: `ty` must be null or a valid (own or stock) `PyTypeObject*`.
pub unsafe fn bridge_or_ready(ty: *mut PyTypeObject) -> Option<Rc<TypeObject>> {
    if ty.is_null() {
        return None;
    }
    if let Some(t) = unsafe { bridge_type(ty) } {
        return Some(t);
    }
    // Not yet bridged: ready it (idempotent) and retry. Foreign stock
    // types get harvested; our own types short-circuit inside PyType_Ready.
    unsafe { PyType_Ready(ty) };
    unsafe { bridge_type(ty) }
}

/// Mirror CPython's `inherit_special` fast-subclass bit assignment
/// (`Objects/typeobject.c`): a finalised type carries exactly one
/// `Py_TPFLAGS_*_SUBCLASS` bit, for the most-derived builtin in its
/// ancestry, so a stock extension's inlined `PyX_Check`
/// (`Py_TYPE(o)->tp_flags & Py_TPFLAGS_X_SUBCLASS`) classifies it without
/// an MRO walk. The else-if order matches CPython exactly. In particular
/// Cython's `__Pyx_ImportType` rejects `numpy.dtype` ("is not a type
/// object") unless its metaclass `numpy._DTypeMeta` — a `type` subclass —
/// carries `Py_TPFLAGS_TYPE_SUBCLASS`, and `__Pyx_Raise` rejects a
/// `cdef`-raised exception unless its class carries
/// `Py_TPFLAGS_BASE_EXC_SUBCLASS`.
fn fast_subclass_flags(t: &Rc<TypeObject>) -> u64 {
    use crate::layout::tpflags;
    let bt = weavepy_vm::builtin_types::builtin_types();
    if t.is_subclass_of(&bt.base_exception) {
        tpflags::BASE_EXC_SUBCLASS
    } else if t.is_subclass_of(&bt.type_) {
        tpflags::TYPE_SUBCLASS
    } else if t.is_subclass_of(&bt.int_) {
        tpflags::LONG_SUBCLASS
    } else if t.is_subclass_of(&bt.bytes_) {
        tpflags::BYTES_SUBCLASS
    } else if t.is_subclass_of(&bt.str_) {
        tpflags::UNICODE_SUBCLASS
    } else if t.is_subclass_of(&bt.tuple_) {
        tpflags::TUPLE_SUBCLASS
    } else if t.is_subclass_of(&bt.list_) {
        tpflags::LIST_SUBCLASS
    } else if t.is_subclass_of(&bt.dict_) {
        tpflags::DICT_SUBCLASS
    } else {
        0
    }
}

/// The canonical C `PyTypeObject*` for `t`'s **metaclass**, used as a
/// type mirror's `ob_type`.
///
/// CPython code (and Cython-generated code in particular) reads a class's
/// metaclass straight off `Py_TYPE(cls)`: `type(Enum)` must be `EnumType`,
/// `type(np.dtype)` must be `numpy._DTypeMeta`, and so on. Historically
/// every WeavePy type mirror hard-coded `ob_type = PyType_Type` (bare
/// `type`), so `__Pyx_CalculateMetaclass((Enum,))` resolved to `type`,
/// `type.__prepare__` returned a plain dict instead of `EnumType`'s
/// `_EnumDict`, and a Cython module defining a Python `class X(Enum)`
/// failed its multi-phase init with
/// `AttributeError: 'dict' object has no attribute '_member_names'`.
///
/// The metaclass mirror is minted on demand. Recursion bottoms out at the
/// static `PyType_Type`: `type`'s own metaclass is `type`, and every
/// well-formed metaclass chain terminates there.
fn metaclass_ptr(t: &Rc<TypeObject>) -> *mut PyTypeObject {
    let mc = t.metaclass_or_type();
    let bt = weavepy_vm::builtin_types::builtin_types();
    if Rc::ptr_eq(&mc, &bt.type_) || Rc::ptr_eq(&mc, t) {
        return PyType_Type.as_ptr();
    }
    if let Some(p) = find_type_ptr(&mc) {
        return p;
    }
    install_user_type(&mc)
}

/// Resolve `t`'s first base to its canonical C `PyTypeObject*` and decide
/// whether `t` inherits that base's **inline `tp_basicsize` storage**.
///
/// A pure-Python (VM) class can subclass an *inline* C extension type —
/// pandas' `class NaTType(_NaT)` (the `_NaT ← datetime` shell) or numpy's
/// `class MaskedArray(ndarray)`. CPython inherits `tp_basicsize`, so the
/// subclass instance carries the base's faithful C layout: a stock
/// `tp_new` packs fields at fixed offsets and the extension reads
/// `((BaseObject *)self)->field` directly. The mirror must therefore get a
/// faithful inline body, not a `PyObjectBox` (whose Rust payload sits
/// exactly where the extension expects `self->field`, so those writes
/// corrupt it — RFC 0045 / 0029).
///
/// Returns `(base_ptr, base_inline, basicsize)`. When the base is inline,
/// `basicsize` is the base's `tp_basicsize`; otherwise it is
/// `non_inline_default`. An unregistered pure-Python intermediate base
/// (pytz `UTC ← BaseTzInfo ← tzinfo`) is minted via `install_user_type`
/// so the `tp_base` chain reaches the faithful root; the `object` root
/// (no bases) yields `None`. Shared by [`install_user_type`] and
/// [`synth_type_for_class`] so a VM subclass of an inline C type gets a
/// faithful body regardless of which mirror-minting path it takes.
fn inherit_inline_base_layout(
    t: &Rc<TypeObject>,
    non_inline_default: PySsizeT,
) -> (Option<*mut PyTypeObject>, bool, PySsizeT) {
    // Resolve a direct base to its canonical C `PyTypeObject*`, minting a
    // mirror for a pure-Python intermediate base (one that itself has
    // bases) so the layout probe reaches the faithful root; the `object`
    // root (no bases) yields `None`.
    let resolve = |b: &Rc<TypeObject>| -> Option<*mut PyTypeObject> {
        type_ptr_for_class(b).or_else(|| {
            if b.bases.borrow().is_empty() {
                None
            } else {
                Some(install_user_type(b))
            }
        })
    };

    let bases = t.bases.borrow();
    let first_ptr = bases.first().and_then(&resolve);

    // CPython's `best_base()`: the "solid base" is the base with the widest
    // instance layout (`tp_basicsize`), scanned across *all* bases — not
    // just the first. A VM class that lists an inline C extension type
    // anywhere in its bases must inherit that faithful inline body. pandas'
    // `class Block(PandasObject, libinternals.Block)` puts its inline
    // Cython base *second* (the first base is the pure-Python
    // `PandasObject`); probing only `bases.first()` left `Block` — and its
    // subclasses `NumpyBlock`/`NumericBlock`/`ObjectBlock` — on a 16-byte
    // `PyObjectBox`, so Cython's fixed-offset field writes (`_mgr_locs`,
    // `values`, `refs`) clobbered the Rust `obj` payload and the later free
    // dereferenced the garbage (SIGBUS).
    let mut solid: Option<*mut PyTypeObject> = None;
    let mut solid_size: PySsizeT = 0;
    for b in bases.iter() {
        if let Some(bp) = resolve(b) {
            if std::env::var_os("WEAVEPY_TRACE_CTOR").is_some() {
                eprintln!(
                    "[CTOR] layout-probe class={} base={} bp={bp:p} inline={} basicsize={}",
                    t.name,
                    b.name,
                    is_inline_instance_type(bp),
                    unsafe { (*bp).tp_basicsize },
                );
            }
            if is_inline_instance_type(bp) {
                let sz = unsafe { (*bp).tp_basicsize };
                if solid.is_none() || sz > solid_size {
                    solid = Some(bp);
                    solid_size = sz;
                }
            }
        }
    }

    match solid {
        Some(sp) => (Some(sp), true, solid_size),
        None => (first_ptr, false, non_inline_default),
    }
}

/// Find the static [`PyTypeObject`] pointer that bridges to `t`,
/// installing one on demand for user-defined classes (e.g. heap
/// types created without `PyType_FromSpec` — usually never; this is
/// a fallback path).
/// Stock CPython 3.13 `tp_basicsize` for VM classes that stand in for
/// CPython *C* built-ins (WeavePy reimplements them in pure Python).
/// Cython's `__Pyx_ImportType` validates such a type at extension-import
/// time by comparing the live `tp_basicsize` against the `sizeof(...)`
/// its headers baked in, and errors when the live value is *smaller*
/// ("array.array size changed, may indicate binary incompatibility.
/// Expected 64 from C header, got 16 from PyObject" — scikit-learn's
/// `_svmlight_format_fast` cimports `cpython.array`; RFC 0075 WS9).
/// Reporting-only, exactly like the static-builtin `set_size` table:
/// these classes are never registered as inline-instance types, so the
/// value never diverts allocation.
fn faithful_purepy_basicsize(t: &Rc<TypeObject>) -> Option<PySsizeT> {
    let module = match t
        .dict
        .borrow()
        .get(&DictKey(Object::from_static("__module__")))
    {
        Some(Object::Str(s)) => s.to_string(),
        _ => return None,
    };
    match (module.as_str(), t.name.as_str()) {
        // `sizeof(arrayobject)`: VAR_HEAD(24) + ob_item(8) + allocated(8)
        // + ob_descr(8) + weakreflist(8) + ob_exports(8).
        ("array", "array") => Some(64),
        _ => None,
    }
}

pub fn install_user_type(t: &Rc<TypeObject>) -> *mut PyTypeObject {
    if let Some(p) = find_type_ptr(t) {
        return p;
    }
    // Resolve (minting if needed) the metaclass mirror *before* building
    // this type's box so `Py_TYPE(t)` reports the real metaclass.
    let meta = metaclass_ptr(t);
    let owned_name = format!("{}\0", t.name).into_bytes();
    // Stock extensions read `tp_flags` directly to classify a type. In
    // particular Cython's `__Pyx_Raise` gates `raise exc` on
    // `PyExceptionInstance_Check(x)` ≡ `Py_TYPE(x)->tp_flags &
    // Py_TPFLAGS_BASE_EXC_SUBCLASS`, so a WeavePy exception type published
    // here with `tp_flags == 0` makes every `raise RuntimeError(...)` from
    // a `cdef` method fail with "exception class must be a subclass of
    // BaseException". Mirror CPython: every readied type carries
    // DEFAULT | BASETYPE | READY, and an exception subclass also carries
    // the BASE_EXC_SUBCLASS fast-subclass bit.
    //
    // RFC 0047 (wave 5): also `Py_TPFLAGS_HEAPTYPE`. Every class a `class`
    // statement creates is a *heap type* on CPython (the VM's own
    // `type.__flags__` — `flags_bits` — already reports the bit), and
    // Cython's cpdef override dispatch gates on exactly this:
    //
    //   if (Py_TYPE(self)->tp_dictoffset != 0 ||
    //       PyType_HasFeature(Py_TYPE(self), IS_ABSTRACT | HEAPTYPE)) {
    //       meth = getattr(self, name); if not same-C-function: call meth
    //   }
    //   /* else: call the native cdef body directly */
    //
    // Without the bit a VM subclass of a `cdef class` (pandas'
    // `ExtensionBlock(EABackedBlock ← … ← libinternals.Block)`) never had
    // its Python override consulted: `BlockManager._slice_mgr_rows` called
    // the native `Block.slice_block_rows` (`values[..., slicer]`) instead of
    // `ExtensionBlock.slice_block_rows` (`values[slicer]`), handing 1-D
    // ExtensionArrays a 2-D `(Ellipsis, slice)` key
    // (`test_common.test_ellipsis_index`).
    use crate::layout::tpflags;
    let flags = tpflags::DEFAULT
        | tpflags::BASETYPE
        | tpflags::READY
        | tpflags::HEAPTYPE
        | fast_subclass_flags(t);
    if std::env::var_os("WEAVEPY_TRACE_TYPEPTR").is_some() {
        eprintln!(
            "[INSTALL_USER_TYPE] name={:?} flags={:#x} fast={:#x}",
            t.name,
            flags,
            fast_subclass_flags(t)
        );
    }
    // RFC 0029 / 0045 (wave 5): inherit an *inline* C base's `tp_basicsize`
    // and inline-storage status (see [`inherit_inline_base_layout`]) so a VM
    // subclass of e.g. the `datetime` shell (pandas `NaTType`) or
    // `numpy.ndarray` gets a faithful body, not a `PyObjectBox` the base's
    // fixed-offset field writes would corrupt. A non-inline base keeps the
    // identity-box size.
    let (base_ptr, base_inline, mut basicsize) = inherit_inline_base_layout(
        t,
        std::mem::size_of::<crate::object::PyObjectBox>() as PySsizeT,
    );
    if !base_inline {
        if let Some(sz) = faithful_purepy_basicsize(t) {
            basicsize = basicsize.max(sz);
        }
    }
    // RFC 0046 (wave 4/5): mirror CPython's `PyType_Ready` defaults for
    // `tp_alloc`/`tp_free` (inherited from `object`). A *foreign* C `tp_new`
    // that subclasses this VM type allocates through `subtype->tp_alloc(
    // subtype, 0)` directly — pandas' `class NAType(C_NAType)` runs the cdef
    // base's `C_NAType.__pyx_tp_new`, which calls `NAType->tp_alloc`. With a
    // NULL slot that is a jump through address 0 (SIGSEGV). `PyType_GenericAlloc`
    // mints a faithful instance body bound to this type's bridged class.
    let alloc_fp: unsafe extern "C" fn(*mut PyTypeObject, PySsizeT) -> *mut PyObject =
        crate::genericalloc::PyType_GenericAlloc;
    let new_fp: unsafe extern "C" fn(
        *mut PyTypeObject,
        *mut PyObject,
        *mut PyObject,
    ) -> *mut PyObject = crate::genericalloc::PyType_GenericNew;
    let free_fp: unsafe extern "C" fn(*mut c_void) = crate::memory::PyObject_Free;
    // RFC 0047 (wave 5): mirror CPython's `tp_new` inheritance. CPython's
    // `type_ready_inherit`/`inherit_special` copies `tp_new` down from
    // `tp_base` — which for a multiply-inheriting class is the *solid base*
    // (`best_base`), i.e. the base that owns the widest inline instance
    // layout, **not** the first base on the MRO. `inherit_inline_base_layout`
    // already resolved that solid base into `base_ptr`; adopt its faithful
    // `tp_new` so the C struct fields it declares are initialised
    // (Cython's `__pyx_tp_new` zeroes every `cdef object` field to `None`).
    //
    // This is the fix for pandas' `class MultiIndexUIntEngine(
    // BaseMultiIndexCodesEngine, UInt64Engine)`: the first MRO base
    // (`BaseMultiIndexCodesEngine`, no inline fields) has a `tp_new` that
    // leaves the inherited `IndexEngine` fields (`values`/`mask`/`mapping`)
    // NULL, so `IndexEngine.__init__`'s plain `__Pyx_DECREF(self->values)`
    // dereferenced NULL. The solid base (`UInt64Engine ← IndexEngine`) owns
    // those fields and its `tp_new` sets them to `None`. Only inline bases
    // carry a faithful C `tp_new` worth inheriting; a non-inline base keeps
    // the generic allocator (the shim still forwards to the base's captured
    // slot for those, unchanged).
    let tp_new_slot: *mut c_void = if base_inline {
        let inherited = base_ptr
            .filter(|bp| !bp.is_null())
            .map(|bp| unsafe { (*bp).tp_new })
            .unwrap_or(ptr::null_mut());
        if inherited.is_null() {
            new_fp as *mut c_void
        } else {
            inherited
        }
    } else {
        new_fp as *mut c_void
    };
    let bx = Box::new(PyTypeObjectBox {
        head: PyTypeObject {
            head: PyObject {
                ob_refcnt: IMMORTAL_REFCNT,
                ob_type: meta,
            },
            tp_name: owned_name.as_ptr() as *const c_char,
            tp_basicsize: basicsize,
            tp_base: base_ptr.unwrap_or(ptr::null_mut()),
            tp_dealloc: Some(crate::object::_PyWeavePy_Dealloc),
            tp_alloc: alloc_fp as *mut c_void,
            tp_new: tp_new_slot,
            tp_free: free_fp as *mut c_void,
            tp_flags: flags,
            bridge: Box::into_raw(Box::new(t.clone())),
            ..PyTypeObject::new_zeroed()
        },
        owned_name,
        slot_table: SlotTable::empty(),
    });
    let p = Box::leak(bx);
    // Derive the C-level protocol slots (`tp_as_mapping`/`mp_subscript`,
    // `tp_call`, `tp_iter`, …) from the class's dunders so an extension that
    // reads them straight off `Py_TYPE(obj)` (Cython's inlined subscript /
    // call / iteration helpers) sees a faithful table — not the NULL suite a
    // bare mirror would carry. Without this a frozen Python class crossing
    // here (e.g. `typing._SpecialForm`, which only defines `__getitem__` and
    // so misses the iter/ctx gate in `synth_type_for_class`) is "not
    // subscriptable" to a wheel's module-init code.
    synth_protocol_slots(&mut p.head, t);
    let ty_ptr = &mut p.head as *mut PyTypeObject;
    // RFC 0047 (wave 5): faithful `inherit_slots`, exactly as `PyType_Ready`
    // does. `synth_protocol_slots` above installs only the subtype's *own*
    // mapping/call/iter dunders; every function slot and method suite it
    // leaves NULL — most importantly the numeric suite `tp_as_number`
    // (`nb_add`/`nb_subtract`/…) and `tp_richcompare` — must be copied down
    // from the base so a Cython extension's *inlined*
    // `Py_TYPE(self)->tp_as_number->nb_add` read (with no MRO walk) resolves.
    // Without this, a VM subclass of a readied Cython `cdef class`
    // (pandas' `Timestamp(_Timestamp)`, `Timedelta(_Timedelta)`,
    // `Period(_Period)`) crossed into C with a NULL number suite: the C-API
    // `PyNumber_Add`/`PyNumber_Subtract` slot dispatch skipped the base's
    // `__add__`/`__sub__` and fell through to the *other* operand's slot
    // (numpy's `timedelta64`), which for nanosecond resolution coerces to a
    // Python `int` and trips pandas' `integer_op_not_supported` guard —
    // `Timestamp - np.timedelta64(n, "ns")` raised spuriously.
    let base_for_inherit = p.head.tp_base;
    unsafe { crate::inherit::inherit_slots(ty_ptr, &mut p.slot_table, base_for_inherit) };
    // Cache so subsequent calls with the same native `Rc` return the
    // same pointer instead of leaking a fresh box every time
    // (`PyExc_*` aliases — e.g. `SystemError` → `runtime_error` —
    // would otherwise install distinct slots for the same type).
    register_heap_type(ty_ptr);
    // RFC 0069 WS5: publish faithful C-level `tp_bases` / `tp_mro` (built
    // *after* registration so the type's own pointer resolves for the
    // `tp_mro[0]` self entry), exactly as the spec-built and
    // `PyType_Ready` paths do. numpy's `PyArray_DescrFromTypeObject`
    // walks `tp_mro` directly to map a scalar *subclass* back to its
    // dtype — a VM `class my_int16(np.int16)` crossed here with
    // `tp_mro == NULL`, so `np.int16(x)` / `x.item()` / `str(x)`
    // faulted (the `test_scalarinherit` census row).
    unsafe {
        let bases_for_c: Vec<Rc<TypeObject>> = t.bases.borrow().clone();
        let mro_for_c: Vec<Rc<TypeObject>> = t.mro.borrow().clone();
        let tp_bases_box = build_type_ptr_tuple(&bases_for_c);
        if !tp_bases_box.is_null() {
            (*ty_ptr).tp_bases = tp_bases_box;
        }
        let tp_mro_box = build_type_ptr_tuple(&mro_for_c);
        if !tp_mro_box.is_null() {
            (*ty_ptr).tp_mro = tp_mro_box;
        }
        // RFC 0076 WS5: publish `tp_dict` too, exactly as the
        // `PyType_Ready` path does — a dict box sharing the bridge's
        // `DictData`, so direct C reads and the VM observe the same
        // storage. torch's `get_tensor_dict` reads `tp_dict` straight
        // off the `torch.Tensor` (VM class) struct and hands it to
        // `PyDict_Merge` to copy the method table onto every legacy
        // `torch.FloatTensor` type; a NULL here failed `_initExtension`.
        (*ty_ptr).tp_dict = crate::object::into_owned(Object::Dict(t.dict.clone()));
    }
    // Mirror the inline base: instances of this subclass need the same
    // faithful inline body (RFC 0045) so fixed-offset field reads/writes
    // land on real CPython-shaped memory.
    if base_inline {
        maybe_register_inline_type(ty_ptr);
    } else {
        maybe_register_container_body_type(ty_ptr);
    }
    ty_ptr
}

// ----------------------------------------------------------------
// PyType_FromSpec — the heart of "extension defines a class".
// ----------------------------------------------------------------

pub const PY_TPFLAGS_HEAPTYPE: u32 = 1 << 9;
/// `Py_TPFLAGS_IS_ABSTRACT` — set on abstract base classes. Used
/// transiently by [`crate::instance`] to neutralise a Cython
/// `@cython.freelist` `tp_dealloc`: the freelist stash is guarded by
/// `!HasFeature(Py_TPFLAGS_IS_ABSTRACT)` in **both** Cython codegen
/// variants (classic and type-specs), so temporarily setting it forces
/// the release (`tp_free`) branch instead of the raw-pointer stash.
pub const PY_TPFLAGS_IS_ABSTRACT: u32 = 1 << 20;
pub const PY_TPFLAGS_BASETYPE: u32 = 1 << 10;
pub const PY_TPFLAGS_HAVE_GC: u32 = 1 << 14;
pub const PY_TPFLAGS_DEFAULT: u32 = 1 << 18;
pub const PY_TPFLAGS_HAVE_VECTORCALL: u32 = 1 << 11;
pub const PY_TPFLAGS_DISALLOW_INSTANTIATION: u32 = 1 << 7;
/// `Py_TPFLAGS_READY` — set on `tp_flags` once a type is finalised.
pub const PY_TPFLAGS_READY: u64 = 1 << 12;

/// Assemble a heap/readied type's `__dict__`: `__doc__` / `__module__`
/// / `__qualname__`, the method/getset/member descriptors, and the
/// synthesised dunder shims that forward to the C slots. Shared by
/// [`PyType_FromMetaclass`] and [`PyType_Ready`] (RFC 0044, WS2) so the
/// two type-definition styles converge on identical dispatch.
fn assemble_type_dict(
    qualified: &str,
    bare: &str,
    slot_table: &SlotTable,
    methods: &[crate::module::MethodEntry],
    getset_pairs: Vec<(String, Object)>,
    member_pairs: Vec<(String, Object)>,
    doc: Option<&str>,
    defining_class: &std::sync::Arc<std::sync::atomic::AtomicUsize>,
    new_null_raises: bool,
) -> DictData {
    let mut dict = DictData::default();
    if let Some(d) = doc {
        dict.insert(
            DictKey(Object::from_static("__doc__")),
            Object::from_str(d.to_owned()),
        );
    }
    dict.insert(
        DictKey(Object::from_static("__module__")),
        if let Some(idx) = qualified.rfind('.') {
            Object::from_str(qualified[..idx].to_owned())
        } else {
            Object::from_static("builtins")
        },
    );
    dict.insert(
        DictKey(Object::from_static("__qualname__")),
        Object::from_str(bare.to_owned()),
    );
    for entry in methods {
        dict.insert(
            DictKey(Object::from_str(entry.name.clone())),
            entry.bind_unbound(defining_class.clone()),
        );
    }
    for (name, obj) in getset_pairs {
        dict.insert(DictKey(Object::from_str(name)), obj);
    }
    for (name, obj) in member_pairs {
        dict.insert(DictKey(Object::from_str(name)), obj);
    }
    // CPython's `add_operators` (typeobject.c) skips a slot wrapper
    // whose name is already in `tp_dict` — a `tp_methods` entry wins
    // over the synthesized slot shim. numpy's ndarray defines
    // `__matmul__` in its method table (FASTCALL|KEYWORDS, with the
    // `out=` third argument) *and* fills `nb_matrix_multiply`;
    // overwriting the method with the 2-arg shim broke every
    // 3-arg `a.__matmul__(b, out)` call (scipy.linalg.interpolative's
    // pythran backend — RFC 0076 WS2). Only names present *before*
    // shim installation are protected: a later shim may still replace
    // an earlier one (the `mp_subscript` `__getitem__` supersedes the
    // `sq_item` one, matching CPython's slotdefs priority).
    #[allow(clippy::mutable_key_type)]
    let preexisting: std::collections::HashSet<DictKey> = dict.keys().cloned().collect();
    let dunder_pairs =
        crate::dunder_shim::install_dunder_shims(slot_table, qualified.to_owned(), new_null_raises);
    for (name, obj) in dunder_pairs {
        let key = DictKey(Object::from_str(name));
        if !preexisting.contains(&key) {
            dict.insert(key, obj);
        }
    }
    dict
}

// ----------------------------------------------------------------
// Readied stock types (RFC 0044, WS2).
//
// A stock extension defines a *static* `PyTypeObject` (exactly 416
// bytes — the CPython layout, with no room for WeavePy's private
// `bridge`/`slot_table` trailing fields) and calls `PyType_Ready`.
// We therefore cannot stash the bridge in the caller's struct; the
// bridge + decoded slot table live in this side registry, keyed by
// the extension's own type pointer (which is what flows through
// `PyModule_AddObject`, instance `ob_type`, `type(x)`, …).
//
// Entries are `Box::leak`'d (readied types live for the process
// lifetime), so the `&'static` borrows handed out by `bridge_type` /
// `slot_table_for` stay valid. The maps are **process-global** (RFC
// 0047, wave 5): a type readied during import on the main thread is
// used from every `threading.Thread` worker (pandas' multi-thread
// `read_csv` tests), so per-thread registries would make a worker
// mis-classify readied/inline types and route instance memory through
// the wrong free path. All access happens under the VM's GIL-or-cell
// locking discipline; the `Mutex` here guards the map structure itself.
// ----------------------------------------------------------------

/// WeavePy-owned data backing a readied stock type.
pub struct ReadiedType {
    /// The extension's own `&MyType` pointer (the canonical identity).
    pub ext_ptr: *mut PyTypeObject,
    /// Bridge to the native type.
    pub bridge: Rc<TypeObject>,
    /// Slots decoded from the faithful struct + method suites.
    pub slot_table: SlotTable,
    /// The struct's `ob_type` as last observed (RFC 0076 WS5). A C
    /// extension may re-seat a *static* type's metaclass with a raw
    /// `Py_SET_TYPE(&MyType, meta)` field write — torch's
    /// `_set_generator_metaclass` late-binds `OpaqueBaseMeta` onto
    /// `THPGeneratorType` this way — which no C-API call announces.
    /// [`bridge_type`] compares the live field against this snapshot on
    /// every crossing and adopts drift into the VM bridge's metaclass.
    pub ob_type_seen: std::sync::atomic::AtomicUsize,
}

unsafe impl Send for ReadiedType {}
unsafe impl Sync for ReadiedType {}

/// Map from an extension type pointer to its readied data.
static READIED_BY_PTR: Mutex<Option<std::collections::HashMap<usize, &'static ReadiedType>>> =
    Mutex::new(None);
/// Insertion-ordered list for the `Rc<TypeObject>` → pointer scan.
static READIED_TYPES: Mutex<Vec<&'static ReadiedType>> = Mutex::new(Vec::new());

/// Types whose instances get a faithful **inline `tp_basicsize`
/// body** (RFC 0045, wave 3): C-extension types finalised by
/// `PyType_FromSpec` / `PyType_Ready` that declare storage beyond the
/// object head. Membership is the opt-in gate that
/// [`crate::object::into_owned`] and
/// [`crate::genericalloc::PyType_GenericAlloc`] consult; a type absent
/// from this set keeps the wave-1/2 `PyObjectBox` instance shape, so
/// the change is purely additive (pure-Python classes and every
/// dict-backed fixture are unaffected). Process-global for the same
/// reason as [`READIED_BY_PTR`]: instances cross threads.
static INLINE_TYPES: Mutex<Option<std::collections::HashSet<usize>>> = Mutex::new(None);

/// Register `ty` as an inline-instance type iff it declares storage
/// beyond `PyObject_HEAD` (`tp_basicsize > sizeof(PyObject)`) — i.e. it
/// has real inline fields a stock reader pokes at fixed offsets (the
/// `PyArrayObject` shape). Called at `PyType_FromSpec` / `PyType_Ready`
/// finalisation. Types that keep all state in `__dict__`
/// (`tp_basicsize <= sizeof(PyObject)`, which is every current fixture)
/// are not registered and keep the legacy box (RFC 0045, WS1).
pub fn maybe_register_inline_type(ty: *mut PyTypeObject) {
    if ty.is_null() {
        return;
    }
    let basicsize = unsafe { (*ty).tp_basicsize } as usize;
    let registered = basicsize > std::mem::size_of::<PyObject>();
    if registered {
        if let Ok(mut g) = INLINE_TYPES.lock() {
            g.get_or_insert_with(std::collections::HashSet::new)
                .insert(ty as usize);
        }
    }
    if std::env::var_os("WEAVEPY_TRACE_CTOR").is_some() {
        eprintln!(
            "[CTOR] register_inline name={} ty={:p} basicsize={} sizeof_pyobj={} registered={}",
            ctor_trace_name(ty),
            ty,
            basicsize,
            std::mem::size_of::<PyObject>(),
            registered
        );
    }
}

/// Best-effort `tp_name` for constructor tracing (`WEAVEPY_TRACE_CTOR`).
pub fn ctor_trace_name(ty: *mut PyTypeObject) -> String {
    if ty.is_null() {
        return "<null>".to_owned();
    }
    let n = unsafe { (*ty).tp_name };
    if n.is_null() {
        return "<noname>".to_owned();
    }
    unsafe { CStr::from_ptr(n) }.to_string_lossy().into_owned()
}

/// True if instances of `ty` use a faithful inline `tp_basicsize` body
/// (RFC 0045, wave 3). O(1) hash lookup; false for every non-extension
/// type, so the wave-1/2 paths are unchanged for them.
pub fn is_inline_instance_type(ty: *mut PyTypeObject) -> bool {
    if ty.is_null() {
        return false;
    }
    INLINE_TYPES
        .lock()
        .ok()
        .and_then(|g| g.as_ref().map(|s| s.contains(&(ty as usize))))
        .unwrap_or(false)
}

/// Bridged VM types whose instances cross into C as faithful **container
/// bodies** (RFC 0047, wave 5): a pure-Python `class C(list)` /
/// `class C(tuple)` (pandas' `FrozenList`, every `namedtuple`). CPython
/// lays such an instance out as a real `PyListObject`/`PyTupleObject`
/// with the subclass in `ob_type`, and stock extensions classify with
/// `PyList_Check` (a `tp_flags` bit test) then poke the layout with the
/// `PyList_GET_ITEM`/`Py_SIZE` macros — no function call we could
/// interpose. A plain `PyObjectBox` (Rust payload where C expects
/// `ob_item`) read that way is garbage: pandas' ujson serializer walked
/// `FrozenList`'s payload bytes as a pointer array and crashed on
/// `to_json(orient="table")`.
static CONTAINER_BODY_TYPES: Mutex<Option<std::collections::HashSet<usize>>> = Mutex::new(None);
static CONTAINER_BODY_COUNT: std::sync::atomic::AtomicUsize =
    std::sync::atomic::AtomicUsize::new(0);

/// Register a bridged VM type whose instances need a faithful container
/// body iff it is a list/tuple subclass (decided by the fast-subclass
/// `tp_flags` bits already stamped on `ty`). Called at bridge time
/// ([`install_user_type`] / [`synth_type_for_class`]) for non-inline
/// types — an inline C base owns the layout instead.
pub(crate) fn maybe_register_container_body_type(ty: *mut PyTypeObject) {
    if ty.is_null() {
        return;
    }
    use crate::layout::tpflags;
    let flags = unsafe { (*ty).tp_flags };
    if flags & (tpflags::LIST_SUBCLASS | tpflags::TUPLE_SUBCLASS) == 0 {
        return;
    }
    if let Ok(mut g) = CONTAINER_BODY_TYPES.lock() {
        if g.get_or_insert_with(std::collections::HashSet::new)
            .insert(ty as usize)
        {
            CONTAINER_BODY_COUNT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        }
    }
}

/// True if instances of `ty` cross as faithful container bodies (list /
/// tuple subclass of a VM class). Gated on an atomic count so programs
/// that never bridge such a class pay one relaxed load.
pub fn is_container_body_type(ty: *mut PyTypeObject) -> bool {
    if ty.is_null() || CONTAINER_BODY_COUNT.load(std::sync::atomic::Ordering::Relaxed) == 0 {
        return false;
    }
    CONTAINER_BODY_TYPES
        .lock()
        .ok()
        .and_then(|g| g.as_ref().map(|s| s.contains(&(ty as usize))))
        .unwrap_or(false)
}

/// True iff the inline-instance type registry is still reachable (see
/// [`crate::containers::caches_alive`]). The registry is a process
/// `static` now (RFC 0047: cross-thread instances), so it never dies;
/// this only reports a poisoned mutex, which would mean a panic already
/// aborted a registry mutation mid-flight.
pub(crate) fn inline_types_alive() -> bool {
    INLINE_TYPES.lock().is_ok()
}

/// Look up the readied-type data for an extension type pointer.
fn readied_for(ty: *mut PyTypeObject) -> Option<&'static ReadiedType> {
    if ty.is_null() {
        return None;
    }
    READIED_BY_PTR
        .lock()
        .ok()
        .and_then(|g| g.as_ref().and_then(|m| m.get(&(ty as usize)).copied()))
}

/// The decoded slot table for a readied stock type, or `None` if `ty`
/// was not readied via [`PyType_Ready`]. Used by
/// [`crate::slottable::slot_table_for`] so readied static types (which
/// don't carry the `Py_TPFLAGS_HEAPTYPE` bit and have no embedded
/// `PyTypeObjectBox`) still expose their slots for direct dispatch
/// (buffer protocol, vectorcall, GC traverse, …).
pub fn readied_slot_table(ty: *mut PyTypeObject) -> Option<&'static SlotTable> {
    readied_for(ty).map(|rt| &rt.slot_table)
}

/// True if `ty` is a stock type finalised through [`PyType_Ready`]
/// (RFC 0044). Used by [`crate::genericalloc::PyType_GenericAlloc`] to
/// decide whether a freshly-allocated instance should carry a real
/// `Object::Instance` payload (so the extension's `tp_init` /
/// `PyObject_SetAttrString` operate on a genuine instance dict).
pub fn is_readied_type(ty: *mut PyTypeObject) -> bool {
    readied_for(ty).is_some()
}

/// The native bridge type for a readied stock type, if any.
pub fn readied_bridge(ty: *mut PyTypeObject) -> Option<Rc<TypeObject>> {
    readied_for(ty).map(|rt| rt.bridge.clone())
}

/// The live `PyTypeObject *` backing `cls`, if `cls` is bridged from a
/// C type — static, heap (`PyType_FromSpec`), or readied
/// (`PyType_Ready`). Public so the GC bridge (RFC 0044, WS4) can reach
/// an instance's `tp_traverse` / `tp_clear` slots; returns `None` for a
/// pure-Python class (no C `PyTypeObject` exists to consult).
pub fn type_ptr_for_class(cls: &Rc<TypeObject>) -> Option<*mut PyTypeObject> {
    find_type_ptr(cls)
}

/// The VM's `type.__doc__` / `type.__text_signature__` live-doc hook
/// (RFC 0075 WS8): the *current* `tp_doc` of the C type backing `cls`.
/// numpy's `add_newdoc` writes scalar-type docstrings into `tp_doc`
/// long after `PyType_Ready` — CPython's `type_get_doc` reads the
/// field on every access for static types, so we must too. Pure
/// lookup: `find_type_ptr` never mints a pointer, and a pure-Python
/// class (or a bridged type with a NULL `tp_doc`) reads as `None`,
/// letting the VM's normal resolution run.
/// The VM's `type.__flags__` hook (RFC 0075 WS8): the C `tp_flags` of
/// the type backing `cls`, used to correct the synthesized heap-type
/// bit for static extension types.
pub(crate) fn live_tp_flags(cls: &Rc<TypeObject>) -> Option<u64> {
    let p = find_type_ptr(cls)?;
    Some(unsafe { (*p).tp_flags } as u64)
}

pub(crate) fn live_tp_doc(cls: &Rc<TypeObject>) -> Option<String> {
    let p = find_type_ptr(cls)?;
    let doc = unsafe { (*p).tp_doc };
    if doc.is_null() {
        return None;
    }
    Some(
        unsafe { CStr::from_ptr(doc) }
            .to_string_lossy()
            .into_owned(),
    )
}

/// Build a faithful C-level tuple of the canonical `PyTypeObject*` for
/// each class in `types`. Used to publish `tp_bases` / `tp_mro` on a
/// readied / spec-built type so Cython-generated code can walk them via
/// the `PyTuple_GET_SIZE` / `PyTuple_GET_ITEM` macros (direct struct
/// reads, no function call). Each entry must already have a registered
/// canonical pointer (built after the type itself is registered so its
/// own `tp_mro[0]` slot resolves). Returns NULL on allocation failure.
unsafe fn build_type_ptr_tuple(types: &[Rc<TypeObject>]) -> *mut PyObject {
    let tup = unsafe { crate::containers::PyTuple_New(types.len() as PySsizeT) };
    if tup.is_null() {
        return ptr::null_mut();
    }
    for (i, cls) in types.iter().enumerate() {
        // `into_owned(Object::Type)` resolves to the canonical
        // `PyTypeObject*` (static / heap / readied) and hands back an
        // owned reference, which `PyTuple_SetItem` then steals.
        let p = crate::object::into_owned(Object::Type(cls.clone()));
        unsafe { crate::containers::PyTuple_SetItem(tup, i as PySsizeT, p) };
    }
    tup
}

/// Gate for [`publish_static_type_hierarchy`] (run-once).
static STATIC_HIERARCHY_PUBLISHED: Mutex<bool> = Mutex::new(false);

/// Publish faithful C-level `tp_bases` / `tp_mro` tuples on every static
/// builtin type (`object`, `int`, `str`, …).
///
/// This is deliberately *deferred* out of [`init_static_types`]: building
/// the tuples calls [`crate::containers::PyTuple_New`] / `into_owned`,
/// which need a live interpreter + allocator context. `init_static_types`
/// runs at the very first C-API touch (possibly before any `ActiveContext`
/// is established), so we publish at the first VM→C transition
/// ([`crate::interp::ensure_active`]) instead, where the context is
/// guaranteed. Idempotent and re-entrancy-safe (claims the flag before
/// building, so a nested build call is a no-op rather than a deadlock).
///
/// Without this, each static builtin crosses into C with `tp_mro == NULL`.
/// numpy's `_descr_from_subtype` resolves a 0-d array's scalar descr by
/// reading `Py_TYPE(sc)->tp_mro->ob_size` (`maybe_convert_objects` →
/// `PyArray_DescrFromScalar` on the `object` type) and dereferences the
/// NULL `tp_mro` (fault at `0x10`, the `PyTupleObject::ob_size` offset).
/// CPython walks a valid 1-element MRO and returns `dtype('O')`.
pub fn publish_static_type_hierarchy() {
    {
        let mut done = match STATIC_HIERARCHY_PUBLISHED.lock() {
            Ok(g) => g,
            Err(_) => return,
        };
        if *done {
            return;
        }
        // Claim before building and release the lock, so a re-entrant
        // `ensure_active` triggered while constructing the tuples sees the
        // flag set and returns immediately instead of deadlocking.
        *done = true;
    }
    unsafe {
        for slot in STATIC_TYPE_TABLE {
            let ty = &mut *slot.as_ptr();
            let bridge = ty.bridge;
            if bridge.is_null() {
                continue;
            }
            let rc: &Rc<TypeObject> = &*bridge;
            if ty.tp_mro.is_null() {
                let mro = rc.mro.borrow().clone();
                let tup = build_type_ptr_tuple(&mro);
                if !tup.is_null() {
                    ty.tp_mro = tup;
                }
            }
            if ty.tp_bases.is_null() {
                let bases = rc.bases.borrow().clone();
                let tup = build_type_ptr_tuple(&bases);
                if !tup.is_null() {
                    ty.tp_bases = tup;
                }
            }
        }
    }
}

#[no_mangle]
pub unsafe extern "C" fn PyType_FromSpec(spec: *mut PyType_Spec) -> *mut PyObject {
    unsafe { PyType_FromSpecWithBases(spec, ptr::null_mut()) }
}

#[no_mangle]
pub unsafe extern "C" fn PyType_FromSpecWithBases(
    spec: *mut PyType_Spec,
    bases: *mut PyObject,
) -> *mut PyObject {
    unsafe { PyType_FromMetaclass(ptr::null_mut(), ptr::null_mut(), spec, bases) }
}

#[no_mangle]
pub unsafe extern "C" fn PyType_FromMetaclass(
    _metaclass: *mut PyTypeObject,
    _module: *mut PyObject,
    spec: *mut PyType_Spec,
    bases: *mut PyObject,
) -> *mut PyObject {
    crate::interp::ensure_initialised();
    if spec.is_null() {
        crate::errors::set_runtime_error("PyType_FromSpec called with null spec");
        return ptr::null_mut();
    }
    let spec_ref = unsafe { &*spec };
    let raw_name = if spec_ref.name.is_null() {
        b"<anonymous>\0".as_ptr() as *const c_char
    } else {
        spec_ref.name
    };
    let name_cstr = unsafe { CStr::from_ptr(raw_name) };
    let qualified = name_cstr.to_string_lossy().into_owned();
    let bare = qualified
        .rsplit('.')
        .next()
        .unwrap_or(&qualified)
        .to_owned();

    // ----------------------------------------------------------------
    // Resolve the base type list. Default to `object` if `bases` is
    // null or empty. A `Py_tp_base` / `Py_tp_bases` slot in the spec
    // wins over the explicit argument (matches CPython).
    // ----------------------------------------------------------------
    let mut spec_base: Option<Rc<TypeObject>> = None;
    let mut spec_bases: Option<Vec<Rc<TypeObject>>> = None;
    let mut slot_ptr = spec_ref.slots;
    if !slot_ptr.is_null() {
        let mut p = slot_ptr;
        loop {
            let slot = unsafe { *p };
            if slot.slot == 0 {
                break;
            }
            match slot.slot {
                x if x == crate::slottable::Py_tp_base => {
                    if !slot.pfunc.is_null() {
                        let ty_ptr = slot.pfunc as *mut PyTypeObject;
                        if let Some(t) = unsafe { bridge_or_ready(ty_ptr) } {
                            spec_base = Some(t);
                        }
                    }
                }
                x if x == crate::slottable::Py_tp_bases => {
                    if !slot.pfunc.is_null() {
                        let bases_obj =
                            unsafe { crate::object::clone_object(slot.pfunc as *mut PyObject) };
                        if let Object::Tuple(items) = bases_obj {
                            spec_bases = Some(
                                items
                                    .iter()
                                    .filter_map(|item| match item {
                                        Object::Type(t) => Some(t.clone()),
                                        _ => None,
                                    })
                                    .collect(),
                            );
                        }
                    }
                }
                _ => {}
            }
            p = unsafe { p.add(1) };
        }
        slot_ptr = spec_ref.slots;
    }

    let arg_bases: Vec<Rc<TypeObject>> = if bases.is_null() {
        Vec::new()
    } else {
        let cloned = unsafe { crate::object::clone_object(bases) };
        match cloned {
            Object::Tuple(items) => items
                .iter()
                .filter_map(|item| match item {
                    Object::Type(t) => Some(t.clone()),
                    _ => None,
                })
                .collect(),
            Object::Type(t) => vec![t],
            _ => Vec::new(),
        }
    };

    let bases_resolved: Vec<Rc<TypeObject>> = if let Some(list) = spec_bases {
        list
    } else if !arg_bases.is_empty() {
        arg_bases
    } else if let Some(b) = spec_base {
        vec![b]
    } else {
        vec![weavepy_vm::builtin_types::builtin_types().object_.clone()]
    };
    let bases_resolved = if bases_resolved.is_empty() {
        vec![weavepy_vm::builtin_types::builtin_types().object_.clone()]
    } else {
        bases_resolved
    };

    // ----------------------------------------------------------------
    // First pass: scan the slot table, populate the SlotTable with
    // every recognised slot, and harvest doc / methods / getsets /
    // members for the dict.
    // ----------------------------------------------------------------
    let mut slot_table = SlotTable::empty();
    let mut methods: Vec<crate::module::MethodEntry> = Vec::new();
    let mut getset_pairs: Vec<(String, Object)> = Vec::new();
    let mut member_pairs: Vec<(String, Object)> = Vec::new();
    let mut doc: Option<String> = None;
    if !slot_ptr.is_null() {
        loop {
            let slot = unsafe { *slot_ptr };
            if slot.slot == 0 {
                break;
            }
            match slot.slot {
                x if x == crate::slottable::Py_tp_doc => {
                    if !slot.pfunc.is_null() {
                        let s = unsafe { CStr::from_ptr(slot.pfunc as *const c_char) };
                        doc = Some(s.to_string_lossy().into_owned());
                    }
                }
                x if x == crate::slottable::Py_tp_methods => {
                    if !slot.pfunc.is_null() {
                        methods.extend(unsafe {
                            crate::module::collect_methods(
                                slot.pfunc as *mut crate::module::PyMethodDef,
                            )
                        });
                    }
                }
                x if x == crate::slottable::Py_tp_getset => {
                    if !slot.pfunc.is_null() {
                        getset_pairs.extend(unsafe {
                            crate::getset::collect_getsets(
                                slot.pfunc as *mut crate::getset::PyGetSetDef,
                            )
                        });
                    }
                }
                x if x == crate::slottable::Py_tp_members => {
                    if !slot.pfunc.is_null() {
                        member_pairs.extend(unsafe {
                            crate::getset::collect_members(
                                slot.pfunc as *mut crate::getset::PyMemberDef,
                            )
                        });
                    }
                }
                x if x == crate::slottable::Py_tp_base || x == crate::slottable::Py_tp_bases => {
                    // Already consumed in the bases pass.
                }
                x if x == crate::slottable::Py_tp_token => {
                    // 3.14 (gh-124153): `Py_TP_USE_SPEC` (NULL) means the
                    // spec's own address is the token, so a module can
                    // recognise its heap types via `PyType_GetBaseByToken`
                    // without a static.
                    let token = if slot.pfunc.is_null() {
                        spec as *mut c_void
                    } else {
                        slot.pfunc
                    };
                    slot_table.install(slot.slot, token);
                }
                _ => {
                    slot_table.install(slot.slot, slot.pfunc);
                }
            }
            slot_ptr = unsafe { slot_ptr.add(1) };
        }
    }

    // ----------------------------------------------------------------
    // Build the type's dict: doc + module + methods + getset/member
    // descriptors + synthesised dunder shims. Shared with the
    // `PyType_Ready` path (RFC 0044, WS2) via [`assemble_type_dict`].
    // ----------------------------------------------------------------
    // Late-bound defining-class cell for METH_METHOD entries; stamped
    // with the heap type's pointer once the box exists (below).
    let defining_class = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(0));
    // CPython's `type_ready_set_new`: *heap* types always inherit `tp_new`
    // from the base — even from `object` — so a FromSpec type without a
    // `Py_tp_new` slot stays instantiable. Only an explicit
    // `Py_TPFLAGS_DISALLOW_INSTANTIATION` in the spec forbids creation.
    let new_null_raises = (spec_ref.flags & PY_TPFLAGS_DISALLOW_INSTANTIATION) != 0;
    let dict = assemble_type_dict(
        &qualified,
        &bare,
        &slot_table,
        &methods,
        getset_pairs,
        member_pairs,
        doc.as_deref(),
        &defining_class,
        new_null_raises,
    );

    let ty = match TypeObject::new_user(&bare, bases_resolved, dict) {
        Ok(ty) => ty,
        Err(e) => {
            crate::errors::set_pending_from_runtime(e);
            return ptr::null_mut();
        }
    };
    // CPython's `tp_name`-based error text prints the spec's full dotted
    // name; remember it on the bridge for `type_name_owned`.
    if qualified != bare {
        ty.c_tp_name
            .set(Some(Box::leak(qualified.clone().into_boxed_str())));
    }
    // RFC 0047 (wave 5): record a real C `sq_item` on the bridge so the
    // VM's `make_iter` can replicate `PyObject_GetIter`'s `PySeqIter`
    // fallback for a sequence type with no `tp_iter`.
    if !slot_table.get(crate::slottable::Py_sq_item).is_null() {
        ty.c_sq_item.set(true);
    }
    let owned_name = format!("{qualified}\0").into_bytes();
    // RFC 0047 (wave 5): publish the C-level `tp_dict` backed by the
    // bridge's shared `DictData` (see the `PyType_Ready` path for the full
    // rationale — Cython's `__Pyx_SetVtable`/`__Pyx_GetVtable` read and
    // write `type->tp_dict` directly).
    let tp_dict_box = crate::object::into_owned(Object::Dict(ty.dict.clone()));
    // Snapshot the MRO / bases before `ty` is moved into the box; the
    // faithful C-level `tp_bases` / `tp_mro` are built after the type is
    // registered (so its own pointer resolves for the `tp_mro[0]` slot).
    let mro_for_c: Vec<Rc<TypeObject>> = ty.mro.borrow().clone();
    let bases_for_c: Vec<Rc<TypeObject>> = ty.bases.borrow().clone();
    // RFC 0047 (wave 5): stamp the `inherit_special` fast-subclass bit (see
    // `fast_subclass_flags`) so a spec-built metaclass / builtin subclass is
    // classified correctly by an extension's inlined `tp_flags` reads.
    let subclass_flags = fast_subclass_flags(&ty);
    let bx = Box::new(PyTypeObjectBox {
        head: PyTypeObject {
            head: PyObject {
                ob_refcnt: IMMORTAL_REFCNT,
                ob_type: PyType_Type.as_ptr(),
            },
            tp_name: owned_name.as_ptr() as *const c_char,
            tp_basicsize: spec_ref.basicsize as PySsizeT,
            tp_itemsize: spec_ref.itemsize as PySsizeT,
            tp_flags: (spec_ref.flags | PY_TPFLAGS_HEAPTYPE) as u64 | subclass_flags,
            tp_dealloc: Some(crate::object::_PyWeavePy_Dealloc),
            tp_slots: spec_ref.slots,
            tp_dict: tp_dict_box,
            bridge: Box::into_raw(Box::new(ty)),
            ..PyTypeObject::new_zeroed()
        },
        owned_name,
        slot_table,
    });
    let leaked = Box::leak(bx);
    let ty_ptr = &mut leaked.head as *mut PyTypeObject;
    defining_class.store(ty_ptr as usize, std::sync::atomic::Ordering::Relaxed);
    register_heap_type(ty_ptr);
    // RFC 0045 (wave 3): a heap type that declares inline fields beyond
    // the object head gets faithful `tp_basicsize` instance storage.
    maybe_register_inline_type(ty_ptr);
    // RFC 0047 (wave 5): publish faithful C-level `tp_base` / `tp_bases` /
    // `tp_mro` (CPython's `PyType_FromMetaclass` sets all three). Cython
    // and other extensions read them directly off the struct.
    unsafe {
        if let Some(bp) = bases_for_c.first().and_then(type_ptr_for_class) {
            (*ty_ptr).tp_base = bp;
        }
        let tp_bases_box = build_type_ptr_tuple(&bases_for_c);
        if !tp_bases_box.is_null() {
            (*ty_ptr).tp_bases = tp_bases_box;
        }
        let tp_mro_box = build_type_ptr_tuple(&mro_for_c);
        if !tp_mro_box.is_null() {
            (*ty_ptr).tp_mro = tp_mro_box;
        }
        // Mirror CPython's `type_ready` lifecycle-slot fill for spec-built
        // heap types: the spec's slots landed in the side `SlotTable`, but a
        // stock extension reads `tp_new` / `tp_alloc` / `tp_free` straight
        // off the struct. Cython 3.1's shared `_cyutility` builds its
        // memoryview `Enum` via type specs and its `tp_new` calls
        // `t->tp_alloc(t, 0)` directly — a NULL there is a jump to address
        // zero (pandas ≥2.3 wheels link every `_libs` module against
        // `_cyutility`). Spec slot wins; then the base struct's slot
        // (CPython `inherit_slots`); then the `object` defaults.
        let spec_new = leaked.slot_table.get(crate::slottable::Py_tp_new);
        let spec_alloc = leaked.slot_table.get(crate::slottable::Py_tp_alloc);
        let spec_free = leaked.slot_table.get(crate::slottable::Py_tp_free);
        let base_ptr = (*ty_ptr).tp_base;
        if !spec_new.is_null() {
            (*ty_ptr).tp_new = spec_new.as_void();
        } else if !base_ptr.is_null() && !(*base_ptr).tp_new.is_null() {
            (*ty_ptr).tp_new = (*base_ptr).tp_new;
        } else {
            let new_fp: unsafe extern "C" fn(
                *mut PyTypeObject,
                *mut PyObject,
                *mut PyObject,
            ) -> *mut PyObject = crate::genericalloc::PyType_GenericNew;
            (*ty_ptr).tp_new = new_fp as *mut c_void;
        }
        if !spec_alloc.is_null() {
            (*ty_ptr).tp_alloc = spec_alloc.as_void();
        } else {
            let alloc_fp: unsafe extern "C" fn(*mut PyTypeObject, PySsizeT) -> *mut PyObject =
                crate::genericalloc::PyType_GenericAlloc;
            (*ty_ptr).tp_alloc = alloc_fp as *mut c_void;
        }
        if !spec_free.is_null() {
            (*ty_ptr).tp_free = spec_free.as_void();
        } else {
            let free_fp: unsafe extern "C" fn(*mut c_void) = crate::memory::PyObject_Free;
            (*ty_ptr).tp_free = free_fp as *mut c_void;
        }
        // RFC 0066 WS3: publish every remaining protocol slot onto the
        // faithful struct — stock extensions read them directly.
        publish_spec_struct_slots(ty_ptr, &leaked.slot_table);
    }
    ty_ptr as *mut PyObject
}

/// Write a spec-built type's protocol slots from the side [`SlotTable`]
/// onto the faithful `PyTypeObject` struct — the direct `tp_*` function
/// pointers plus heap-allocated `tp_as_*` method suites.
///
/// CPython's `PyType_FromMetaclass` stores every `Py_tp_*` spec slot in
/// the heap type's struct (with embedded suites), and stock extension
/// code reads them back *directly* off `Py_TYPE(x)`. Cython's
/// `__Pyx_PyObject_LookupSpecial` — the `with`/`for`/operator
/// special-method protocol — binds a method found via `_PyType_Lookup`
/// through `Py_TYPE(res)->tp_descr_get`: lxml's `XSLT.__init__` looks up
/// `_ErrorLog.__exit__` (a CyFunction, whose spec-built type carries
/// `Py_tp_descr_get`) this way. With the struct slot left NULL the
/// CyFunction crossed *unbound*, `__exit__` was called with the exception
/// triple only, and `self` arrived as `None` — crashing in
/// `_ErrorLog_disconnect`. The side table remains the canonical source
/// for the VM's dunder synthesis; this is purely the C-visible view.
///
/// Lifecycle slots (`tp_new`/`tp_alloc`/`tp_free`/`tp_dealloc`) are
/// managed by the caller and skipped here.
unsafe fn publish_spec_struct_slots(ty: *mut PyTypeObject, t: &SlotTable) {
    use crate::slottable as ids;
    unsafe fn set(dst: *mut *mut c_void, t: &SlotTable, id: c_int) {
        let p = t.get(id).as_void();
        if !p.is_null() && unsafe { (*dst).is_null() } {
            unsafe { *dst = p };
        }
    }
    unsafe {
        let tr = &mut *ty;
        set(&mut tr.tp_call, t, ids::Py_tp_call);
        set(&mut tr.tp_init, t, ids::Py_tp_init);
        set(&mut tr.tp_iter, t, ids::Py_tp_iter);
        set(&mut tr.tp_iternext, t, ids::Py_tp_iternext);
        set(&mut tr.tp_richcompare, t, ids::Py_tp_richcompare);
        set(&mut tr.tp_getattro, t, ids::Py_tp_getattro);
        set(&mut tr.tp_setattro, t, ids::Py_tp_setattro);
        set(&mut tr.tp_descr_get, t, ids::Py_tp_descr_get);
        set(&mut tr.tp_descr_set, t, ids::Py_tp_descr_set);
        set(&mut tr.tp_hash, t, ids::Py_tp_hash);
        set(&mut tr.tp_repr, t, ids::Py_tp_repr);
        set(&mut tr.tp_str, t, ids::Py_tp_str);
        set(&mut tr.tp_traverse, t, ids::Py_tp_traverse);
        set(&mut tr.tp_clear, t, ids::Py_tp_clear);
        set(&mut tr.tp_getattr, t, ids::Py_tp_getattr);
        set(&mut tr.tp_setattr, t, ids::Py_tp_setattr);

        // Number suite.
        let nb_ids = [
            ids::Py_nb_add,
            ids::Py_nb_subtract,
            ids::Py_nb_multiply,
            ids::Py_nb_remainder,
            ids::Py_nb_divmod,
            ids::Py_nb_power,
            ids::Py_nb_negative,
            ids::Py_nb_positive,
            ids::Py_nb_absolute,
            ids::Py_nb_bool,
            ids::Py_nb_invert,
            ids::Py_nb_lshift,
            ids::Py_nb_rshift,
            ids::Py_nb_and,
            ids::Py_nb_xor,
            ids::Py_nb_or,
            ids::Py_nb_int,
            ids::Py_nb_float,
            ids::Py_nb_inplace_add,
            ids::Py_nb_inplace_subtract,
            ids::Py_nb_inplace_multiply,
            ids::Py_nb_inplace_remainder,
            ids::Py_nb_inplace_power,
            ids::Py_nb_inplace_lshift,
            ids::Py_nb_inplace_rshift,
            ids::Py_nb_inplace_and,
            ids::Py_nb_inplace_xor,
            ids::Py_nb_inplace_or,
            ids::Py_nb_floor_divide,
            ids::Py_nb_true_divide,
            ids::Py_nb_inplace_floor_divide,
            ids::Py_nb_inplace_true_divide,
            ids::Py_nb_index,
            ids::Py_nb_matrix_multiply,
            ids::Py_nb_inplace_matrix_multiply,
        ];
        if tr.tp_as_number.is_null() && nb_ids.iter().any(|&id| !t.get(id).is_null()) {
            let mut n: crate::layout::PyNumberMethods = std::mem::zeroed();
            n.nb_add = t.get(ids::Py_nb_add).as_void();
            n.nb_subtract = t.get(ids::Py_nb_subtract).as_void();
            n.nb_multiply = t.get(ids::Py_nb_multiply).as_void();
            n.nb_remainder = t.get(ids::Py_nb_remainder).as_void();
            n.nb_divmod = t.get(ids::Py_nb_divmod).as_void();
            n.nb_power = t.get(ids::Py_nb_power).as_void();
            n.nb_negative = t.get(ids::Py_nb_negative).as_void();
            n.nb_positive = t.get(ids::Py_nb_positive).as_void();
            n.nb_absolute = t.get(ids::Py_nb_absolute).as_void();
            n.nb_bool = t.get(ids::Py_nb_bool).as_void();
            n.nb_invert = t.get(ids::Py_nb_invert).as_void();
            n.nb_lshift = t.get(ids::Py_nb_lshift).as_void();
            n.nb_rshift = t.get(ids::Py_nb_rshift).as_void();
            n.nb_and = t.get(ids::Py_nb_and).as_void();
            n.nb_xor = t.get(ids::Py_nb_xor).as_void();
            n.nb_or = t.get(ids::Py_nb_or).as_void();
            n.nb_int = t.get(ids::Py_nb_int).as_void();
            n.nb_float = t.get(ids::Py_nb_float).as_void();
            n.nb_inplace_add = t.get(ids::Py_nb_inplace_add).as_void();
            n.nb_inplace_subtract = t.get(ids::Py_nb_inplace_subtract).as_void();
            n.nb_inplace_multiply = t.get(ids::Py_nb_inplace_multiply).as_void();
            n.nb_inplace_remainder = t.get(ids::Py_nb_inplace_remainder).as_void();
            n.nb_inplace_power = t.get(ids::Py_nb_inplace_power).as_void();
            n.nb_inplace_lshift = t.get(ids::Py_nb_inplace_lshift).as_void();
            n.nb_inplace_rshift = t.get(ids::Py_nb_inplace_rshift).as_void();
            n.nb_inplace_and = t.get(ids::Py_nb_inplace_and).as_void();
            n.nb_inplace_xor = t.get(ids::Py_nb_inplace_xor).as_void();
            n.nb_inplace_or = t.get(ids::Py_nb_inplace_or).as_void();
            n.nb_floor_divide = t.get(ids::Py_nb_floor_divide).as_void();
            n.nb_true_divide = t.get(ids::Py_nb_true_divide).as_void();
            n.nb_inplace_floor_divide = t.get(ids::Py_nb_inplace_floor_divide).as_void();
            n.nb_inplace_true_divide = t.get(ids::Py_nb_inplace_true_divide).as_void();
            n.nb_index = t.get(ids::Py_nb_index).as_void();
            n.nb_matrix_multiply = t.get(ids::Py_nb_matrix_multiply).as_void();
            n.nb_inplace_matrix_multiply = t.get(ids::Py_nb_inplace_matrix_multiply).as_void();
            tr.tp_as_number = Box::into_raw(Box::new(n)) as *mut c_void;
        }

        // Sequence suite.
        let sq_ids = [
            ids::Py_sq_length,
            ids::Py_sq_concat,
            ids::Py_sq_repeat,
            ids::Py_sq_item,
            ids::Py_sq_ass_item,
            ids::Py_sq_contains,
            ids::Py_sq_inplace_concat,
            ids::Py_sq_inplace_repeat,
        ];
        if tr.tp_as_sequence.is_null() && sq_ids.iter().any(|&id| !t.get(id).is_null()) {
            let mut s: crate::layout::PySequenceMethods = std::mem::zeroed();
            s.sq_length = t.get(ids::Py_sq_length).as_void();
            s.sq_concat = t.get(ids::Py_sq_concat).as_void();
            s.sq_repeat = t.get(ids::Py_sq_repeat).as_void();
            s.sq_item = t.get(ids::Py_sq_item).as_void();
            s.sq_ass_item = t.get(ids::Py_sq_ass_item).as_void();
            s.sq_contains = t.get(ids::Py_sq_contains).as_void();
            s.sq_inplace_concat = t.get(ids::Py_sq_inplace_concat).as_void();
            s.sq_inplace_repeat = t.get(ids::Py_sq_inplace_repeat).as_void();
            tr.tp_as_sequence = Box::into_raw(Box::new(s)) as *mut c_void;
        }

        // Mapping suite.
        let mp_ids = [
            ids::Py_mp_length,
            ids::Py_mp_subscript,
            ids::Py_mp_ass_subscript,
        ];
        if tr.tp_as_mapping.is_null() && mp_ids.iter().any(|&id| !t.get(id).is_null()) {
            let mut m: crate::layout::PyMappingMethods = std::mem::zeroed();
            m.mp_length = t.get(ids::Py_mp_length).as_void();
            m.mp_subscript = t.get(ids::Py_mp_subscript).as_void();
            m.mp_ass_subscript = t.get(ids::Py_mp_ass_subscript).as_void();
            tr.tp_as_mapping = Box::into_raw(Box::new(m)) as *mut c_void;
        }

        // Async suite.
        let am_ids = [
            ids::Py_am_await,
            ids::Py_am_aiter,
            ids::Py_am_anext,
            ids::Py_am_send,
        ];
        if tr.tp_as_async.is_null() && am_ids.iter().any(|&id| !t.get(id).is_null()) {
            let mut a: crate::layout::PyAsyncMethods = std::mem::zeroed();
            a.am_await = t.get(ids::Py_am_await).as_void();
            a.am_aiter = t.get(ids::Py_am_aiter).as_void();
            a.am_anext = t.get(ids::Py_am_anext).as_void();
            a.am_send = t.get(ids::Py_am_send).as_void();
            tr.tp_as_async = Box::into_raw(Box::new(a)) as *mut c_void;
        }

        // Buffer suite.
        let bf_ids = [ids::Py_bf_getbuffer, ids::Py_bf_releasebuffer];
        if tr.tp_as_buffer.is_null() && bf_ids.iter().any(|&id| !t.get(id).is_null()) {
            let mut b: crate::layout::PyBufferProcs = std::mem::zeroed();
            b.bf_getbuffer = t.get(ids::Py_bf_getbuffer).as_void();
            b.bf_releasebuffer = t.get(ids::Py_bf_releasebuffer).as_void();
            tr.tp_as_buffer = Box::into_raw(Box::new(b)) as *mut c_void;
        }
    }
}

/// `PyType_GetSlot(ty, slot)` — fetch a slot pointer from `ty`'s
/// SlotTable.
#[no_mangle]
pub unsafe extern "C" fn PyType_GetSlot(ty: *mut PyTypeObject, slot: c_int) -> *mut c_void {
    if ty.is_null() {
        return ptr::null_mut();
    }
    if let Some(table) = unsafe { crate::slottable::slot_table_for(ty) } {
        let p = table.get(slot).as_void();
        if !p.is_null() {
            return p;
        }
    }
    // Lifecycle slots live on the faithful struct even when the decoded
    // table has no entry — static built-in mirrors and `install_user_type`
    // boxes fill `tp_new`/`tp_alloc`/`tp_free` in the struct only. PyO3's
    // subclass creation resolves its base's `tp_new` through this call
    // (pydantic-core: "base type without tp_new" when it comes back NULL).
    unsafe {
        match slot {
            crate::slottable::Py_tp_new => (*ty).tp_new,
            crate::slottable::Py_tp_alloc => (*ty).tp_alloc,
            crate::slottable::Py_tp_free => (*ty).tp_free,
            crate::slottable::Py_tp_dealloc => match (*ty).tp_dealloc {
                Some(f) => f as *mut c_void,
                None => ptr::null_mut(),
            },
            _ => ptr::null_mut(),
        }
    }
}

/// `PyType_HasFeature(type, flag)` — check a `Py_TPFLAGS_*` bit.
#[no_mangle]
pub unsafe extern "C" fn PyType_HasFeature(ty: *mut PyTypeObject, flag: u32) -> c_int {
    if ty.is_null() {
        return 0;
    }
    let f = unsafe { (*ty).tp_flags };
    let flag = flag as u64;
    if (f & flag) == flag {
        1
    } else {
        0
    }
}

/// `PyType_GetFlags(type)` — return the type's `tp_flags` field.
/// CPython returns `unsigned long` (`c_ulong`, 64-bit on LP64).
#[no_mangle]
pub unsafe extern "C" fn PyType_GetFlags(ty: *mut PyTypeObject) -> std::os::raw::c_ulong {
    if ty.is_null() {
        return 0;
    }
    unsafe { (*ty).tp_flags as std::os::raw::c_ulong }
}

/// `PyType_GetQualName(type)` — return the type's qualified name as
/// a fresh `str` object.
#[no_mangle]
pub unsafe extern "C" fn PyType_GetQualName(ty: *mut PyTypeObject) -> *mut PyObject {
    if ty.is_null() {
        return ptr::null_mut();
    }
    let n = unsafe { (*ty).tp_name };
    if n.is_null() {
        return crate::object::into_owned(Object::from_static(""));
    }
    let s = unsafe { CStr::from_ptr(n) }.to_string_lossy().into_owned();
    let bare = s.rsplit('.').next().unwrap_or(&s).to_owned();
    crate::object::into_owned(Object::from_str(bare))
}

#[no_mangle]
pub unsafe extern "C" fn PyType_FromModuleAndSpec(
    module: *mut PyObject,
    spec: *mut PyType_Spec,
    bases: *mut PyObject,
) -> *mut PyObject {
    let ty = unsafe { PyType_FromSpecWithBases(spec, bases) };
    // Remember the owning module so `PyType_GetModuleByDef` (multidict's
    // per-module state lookup) can resolve it later.
    crate::abi313::register_type_module(ty, module);
    ty
}

/// True if `ty` is a WeavePy-owned type object (a static built-in or a
/// `PyType_FromSpec` heap type) — i.e. its struct carries the private
/// `bridge`/`slot_table` trailing fields and is already "ready". Decided
/// purely by pointer identity so we never read past a 416-byte stock
/// struct.
pub(crate) fn is_weavepy_owned_type(ty: *mut PyTypeObject) -> bool {
    for slot in STATIC_TYPE_TABLE {
        if slot.as_ptr() == ty {
            return true;
        }
    }
    HEAP_TYPE_SET
        .lock()
        .map(|g| g.as_ref().is_some_and(|set| set.contains(&(ty as usize))))
        .unwrap_or(false)
}

/// Decode a faithfully-laid-out `PyTypeObject` (a stock extension's
/// statically-initialised type + its method suites) into a
/// [`SlotTable`] plus the dict ingredients (RFC 0044, WS2).
struct Harvested {
    slot_table: SlotTable,
    methods: Vec<crate::module::MethodEntry>,
    getset_pairs: Vec<(String, Object)>,
    member_pairs: Vec<(String, Object)>,
    doc: Option<String>,
    base: Option<Rc<TypeObject>>,
}

/// Read every populated slot of a faithful `PyTypeObject` into a
/// [`SlotTable`]. The direct `tp_*` function pointers map to their
/// `Py_tp_*` ids; each non-null method suite (`tp_as_number`, …) is
/// decomposed into its `Py_nb_*` / `Py_sq_*` / `Py_mp_*` / `Py_am_*` /
/// `Py_bf_*` ids at the faithful offsets pinned in [`crate::layout`].
///
/// # Safety
/// `ty` must point at a readable, faithfully-laid-out `PyTypeObject`
/// (at least the 416-byte CPython prefix).
unsafe fn harvest_faithful(ty: *mut PyTypeObject) -> Harvested {
    use crate::slottable as ids;
    let mut t = SlotTable::empty();

    unsafe fn put(t: &mut SlotTable, id: c_int, p: *mut c_void) {
        if !p.is_null() {
            t.install(id, p);
        }
    }

    let tref = unsafe { &*ty };

    // Direct type-level slots.
    unsafe {
        put(&mut t, ids::Py_tp_call, tref.tp_call);
        put(&mut t, ids::Py_tp_init, tref.tp_init);
        put(&mut t, ids::Py_tp_new, tref.tp_new);
        put(&mut t, ids::Py_tp_iter, tref.tp_iter);
        put(&mut t, ids::Py_tp_iternext, tref.tp_iternext);
        put(&mut t, ids::Py_tp_richcompare, tref.tp_richcompare);
        put(&mut t, ids::Py_tp_getattro, tref.tp_getattro);
        put(&mut t, ids::Py_tp_setattro, tref.tp_setattro);
        put(&mut t, ids::Py_tp_descr_get, tref.tp_descr_get);
        put(&mut t, ids::Py_tp_descr_set, tref.tp_descr_set);
        put(&mut t, ids::Py_tp_hash, tref.tp_hash);
        put(&mut t, ids::Py_tp_repr, tref.tp_repr);
        put(&mut t, ids::Py_tp_str, tref.tp_str);
        put(&mut t, ids::Py_tp_traverse, tref.tp_traverse);
        put(&mut t, ids::Py_tp_clear, tref.tp_clear);
        put(&mut t, ids::Py_tp_alloc, tref.tp_alloc);
        put(&mut t, ids::Py_tp_free, tref.tp_free);
        put(&mut t, ids::Py_tp_getattr, tref.tp_getattr);
        put(&mut t, ids::Py_tp_setattr, tref.tp_setattr);
    }

    // Number suite.
    if !tref.tp_as_number.is_null() {
        let n = unsafe { &*(tref.tp_as_number as *const crate::layout::PyNumberMethods) };
        unsafe {
            put(&mut t, ids::Py_nb_add, n.nb_add);
            put(&mut t, ids::Py_nb_subtract, n.nb_subtract);
            put(&mut t, ids::Py_nb_multiply, n.nb_multiply);
            put(&mut t, ids::Py_nb_remainder, n.nb_remainder);
            put(&mut t, ids::Py_nb_divmod, n.nb_divmod);
            put(&mut t, ids::Py_nb_power, n.nb_power);
            put(&mut t, ids::Py_nb_negative, n.nb_negative);
            put(&mut t, ids::Py_nb_positive, n.nb_positive);
            put(&mut t, ids::Py_nb_absolute, n.nb_absolute);
            put(&mut t, ids::Py_nb_bool, n.nb_bool);
            put(&mut t, ids::Py_nb_invert, n.nb_invert);
            put(&mut t, ids::Py_nb_lshift, n.nb_lshift);
            put(&mut t, ids::Py_nb_rshift, n.nb_rshift);
            put(&mut t, ids::Py_nb_and, n.nb_and);
            put(&mut t, ids::Py_nb_xor, n.nb_xor);
            put(&mut t, ids::Py_nb_or, n.nb_or);
            put(&mut t, ids::Py_nb_int, n.nb_int);
            put(&mut t, ids::Py_nb_float, n.nb_float);
            put(&mut t, ids::Py_nb_inplace_add, n.nb_inplace_add);
            put(&mut t, ids::Py_nb_inplace_subtract, n.nb_inplace_subtract);
            put(&mut t, ids::Py_nb_inplace_multiply, n.nb_inplace_multiply);
            put(&mut t, ids::Py_nb_inplace_remainder, n.nb_inplace_remainder);
            put(&mut t, ids::Py_nb_inplace_power, n.nb_inplace_power);
            put(&mut t, ids::Py_nb_inplace_lshift, n.nb_inplace_lshift);
            put(&mut t, ids::Py_nb_inplace_rshift, n.nb_inplace_rshift);
            put(&mut t, ids::Py_nb_inplace_and, n.nb_inplace_and);
            put(&mut t, ids::Py_nb_inplace_xor, n.nb_inplace_xor);
            put(&mut t, ids::Py_nb_inplace_or, n.nb_inplace_or);
            put(&mut t, ids::Py_nb_floor_divide, n.nb_floor_divide);
            put(&mut t, ids::Py_nb_true_divide, n.nb_true_divide);
            put(
                &mut t,
                ids::Py_nb_inplace_floor_divide,
                n.nb_inplace_floor_divide,
            );
            put(
                &mut t,
                ids::Py_nb_inplace_true_divide,
                n.nb_inplace_true_divide,
            );
            put(&mut t, ids::Py_nb_index, n.nb_index);
            put(&mut t, ids::Py_nb_matrix_multiply, n.nb_matrix_multiply);
            put(
                &mut t,
                ids::Py_nb_inplace_matrix_multiply,
                n.nb_inplace_matrix_multiply,
            );
        }
    }

    // Sequence suite.
    if !tref.tp_as_sequence.is_null() {
        let s = unsafe { &*(tref.tp_as_sequence as *const crate::layout::PySequenceMethods) };
        unsafe {
            put(&mut t, ids::Py_sq_length, s.sq_length);
            put(&mut t, ids::Py_sq_concat, s.sq_concat);
            put(&mut t, ids::Py_sq_repeat, s.sq_repeat);
            put(&mut t, ids::Py_sq_item, s.sq_item);
            put(&mut t, ids::Py_sq_ass_item, s.sq_ass_item);
            put(&mut t, ids::Py_sq_contains, s.sq_contains);
            put(&mut t, ids::Py_sq_inplace_concat, s.sq_inplace_concat);
            put(&mut t, ids::Py_sq_inplace_repeat, s.sq_inplace_repeat);
        }
    }

    // Mapping suite.
    if !tref.tp_as_mapping.is_null() {
        let m = unsafe { &*(tref.tp_as_mapping as *const crate::layout::PyMappingMethods) };
        unsafe {
            put(&mut t, ids::Py_mp_length, m.mp_length);
            put(&mut t, ids::Py_mp_subscript, m.mp_subscript);
            put(&mut t, ids::Py_mp_ass_subscript, m.mp_ass_subscript);
        }
    }

    // Async suite.
    if !tref.tp_as_async.is_null() {
        let a = unsafe { &*(tref.tp_as_async as *const crate::layout::PyAsyncMethods) };
        unsafe {
            put(&mut t, ids::Py_am_await, a.am_await);
            put(&mut t, ids::Py_am_aiter, a.am_aiter);
            put(&mut t, ids::Py_am_anext, a.am_anext);
            put(&mut t, ids::Py_am_send, a.am_send);
        }
    }

    // Buffer suite.
    if !tref.tp_as_buffer.is_null() {
        let b = unsafe { &*(tref.tp_as_buffer as *const crate::layout::PyBufferProcs) };
        unsafe {
            put(&mut t, ids::Py_bf_getbuffer, b.bf_getbuffer);
            put(&mut t, ids::Py_bf_releasebuffer, b.bf_releasebuffer);
        }
    }

    // Descriptor tables + doc + base for the dict / linearisation.
    let methods = if tref.tp_methods.is_null() {
        Vec::new()
    } else {
        unsafe {
            crate::module::collect_methods(tref.tp_methods as *mut crate::module::PyMethodDef)
        }
    };
    let getset_pairs = if tref.tp_getset.is_null() {
        Vec::new()
    } else {
        unsafe { crate::getset::collect_getsets(tref.tp_getset as *mut crate::getset::PyGetSetDef) }
    };
    let member_pairs = if tref.tp_members.is_null() {
        Vec::new()
    } else {
        unsafe {
            crate::getset::collect_members(tref.tp_members as *mut crate::getset::PyMemberDef)
        }
    };
    let doc = if tref.tp_doc.is_null() {
        None
    } else {
        Some(
            unsafe { CStr::from_ptr(tref.tp_doc) }
                .to_string_lossy()
                .into_owned(),
        )
    };
    let base = if tref.tp_base.is_null() {
        None
    } else {
        unsafe { bridge_or_ready(tref.tp_base) }
    };

    Harvested {
        slot_table: t,
        methods,
        getset_pairs,
        member_pairs,
        doc,
        base,
    }
}

/// Resolve a stock type's full `tp_bases` tuple into bridged VM types.
///
/// CPython's `PyType_Ready` linearises the MRO from **all** of a type's
/// bases, not just `tp_base`. NumPy's numeric scalars use *dual
/// inheritance* (`Objects/typeobject.c`-style `tp_bases`): e.g.
/// `numpy.float64.tp_base == numpy.floating` but
/// `numpy.float64.tp_bases == (numpy.floating, float)`, and likewise
/// `complex128 → (complexfloating, complex)`, `str_ → (str, character)`.
/// Following only `tp_base` truncates the MRO and — critically — drops the
/// Python parent, so `isinstance(np.float64(x), float)` and CPython's
/// `round()` (which requires a `float` subclass) both fail.
///
/// Returns the resolved bases in `tp_bases` order (each readied on
/// demand), or an empty vec when `tp_bases` is absent/unreadable so the
/// caller falls back to the single-`tp_base` path.
unsafe fn harvest_bases(ty: *mut PyTypeObject) -> Vec<Rc<TypeObject>> {
    let tp_bases = unsafe { (*ty).tp_bases };
    if tp_bases.is_null() {
        return Vec::new();
    }
    let n = unsafe { crate::containers::PyTuple_Size(tp_bases) };
    if n <= 0 {
        return Vec::new();
    }
    let mut out = Vec::with_capacity(n as usize);
    for i in 0..n {
        let item = unsafe { crate::containers::PyTuple_GetItem(tp_bases, i) };
        if item.is_null() {
            continue;
        }
        if let Some(cls) = unsafe { bridge_or_ready(item as *mut PyTypeObject) } {
            out.push(cls);
        }
    }
    out
}

/// `PyType_Ready(t)` — finalise a type object.
///
/// For WeavePy's own types (static built-ins, `PyType_FromSpec` heap
/// types) this is a no-op: they are ready the moment their bridge is
/// installed. For a **stock extension's statically-initialised
/// `PyTypeObject`** (RFC 0044, WS2) it harvests the faithful struct +
/// method suites into a [`SlotTable`], builds the bridged native type
/// with synthesised dunder shims, and registers it in the readied-type
/// side table — then writes `ob_type` and the `Py_TPFLAGS_READY` bit
/// back into the caller's struct (both at offsets inside the faithful
/// 416-byte region, so a stock struct is never overrun).
#[no_mangle]
pub unsafe extern "C" fn PyType_Ready(t: *mut PyTypeObject) -> c_int {
    if t.is_null() {
        return 0;
    }
    crate::interp::ensure_initialised();
    // Idempotent: already readied, or one of our own ready types.
    if readied_for(t).is_some() || is_weavepy_owned_type(t) {
        return 0;
    }

    let mut h = unsafe { harvest_faithful(t) };

    // Resolve name (qualified + bare) from tp_name.
    let raw_name = unsafe { (*t).tp_name };
    let qualified = if raw_name.is_null() {
        "<readied>".to_owned()
    } else {
        unsafe { CStr::from_ptr(raw_name) }
            .to_string_lossy()
            .into_owned()
    };
    let bare = qualified
        .rsplit('.')
        .next()
        .unwrap_or(&qualified)
        .to_owned();

    // MRO bases: prefer the full `tp_bases` when the type declares more
    // than one (numpy's dual-inherited scalars — `float64`, `complex128`,
    // `str_`, `bytes_`), so the Python parent lands in the linearised MRO
    // (`isinstance(np.float64(x), float)`, `round(...)`, …). Single-base
    // types keep the historical `tp_base`-only path.
    let multi_bases = unsafe { harvest_bases(t) };
    let single_base = h
        .base
        .clone()
        .unwrap_or_else(|| weavepy_vm::builtin_types::builtin_types().object_.clone());

    // `PyType_Ready` path: the caller's static struct *is* the type
    // pointer, so METH_METHOD's defining class is known up front.
    let defining_class = std::sync::Arc::new(std::sync::atomic::AtomicUsize::new(t as usize));
    // CPython's `type_ready_set_new`: a *static* type whose `tp_new` is
    // NULL and whose base is `object` gets `Py_TPFLAGS_DISALLOW_INSTANTIATION`
    // ("a precaution so that old extension types don't suddenly become
    // callable"); any other base donates its `tp_new`. Pillow's readied
    // `CmsProfile` / `CmsTransform` land in the raising arm.
    let new_null_raises = h
        .base
        .as_ref()
        .is_none_or(|b| Rc::ptr_eq(b, &weavepy_vm::builtin_types::builtin_types().object_))
        || (unsafe { (*t).tp_flags } & PY_TPFLAGS_DISALLOW_INSTANTIATION as u64) != 0;
    let getset_names: Vec<String> = h.getset_pairs.iter().map(|(n, _)| n.clone()).collect();
    let member_names: Vec<String> = h.member_pairs.iter().map(|(n, _)| n.clone()).collect();
    let mut dict = assemble_type_dict(
        &qualified,
        &bare,
        &h.slot_table,
        &h.methods,
        h.getset_pairs,
        h.member_pairs,
        h.doc.as_deref(),
        &defining_class,
        new_null_raises,
    );
    // A *static* type's tp_dict carries no `__module__` in CPython —
    // the class-level value comes from the `type.__module__` getset
    // parsing tp_name, and **instances have no `__module__` at all**.
    // pickle depends on the miss: `_ufunc_reduce` returns a bare name
    // and `whichmodule` must scan `sys.modules` for the module that
    // really holds the ufunc (numpy test_pickle pickles
    // `_rational_tests.test_add`, which a planted class-dict
    // `__module__ == "numpy"` misroutes to "numpy.test_add").
    // RFC 0075 WS8; the VM's class-attr synthetic re-derives the
    // dotted prefix from `c_tp_name` below. Heap/FromSpec types keep
    // their dict entry (CPython plants one there too).
    dict.shift_remove(&DictKey(Object::from_static("__module__")));

    let ty = if multi_bases.len() >= 2 {
        // Retry with only the primary `tp_base` if the full dual-inheritance
        // set has no consistent C3 linearisation — never worse than the
        // historical single-base MRO. `dict` is cloned for the retry.
        match TypeObject::new_user(&bare, multi_bases, dict.clone()) {
            Ok(ty) => ty,
            Err(_) => match TypeObject::new_user(&bare, vec![single_base], dict) {
                Ok(ty) => ty,
                Err(e) => {
                    crate::errors::set_pending_from_runtime(e);
                    return -1;
                }
            },
        }
    } else {
        match TypeObject::new_user(&bare, vec![single_base], dict) {
            Ok(ty) => ty,
            Err(e) => {
                crate::errors::set_pending_from_runtime(e);
                return -1;
            }
        }
    };
    // CPython's `tp_name`-based error text prints the full dotted name
    // (`'numpy.ndarray'`) even though `__name__` is bare; remember it on
    // the bridge for `type_name_owned`.
    if qualified != bare {
        ty.c_tp_name
            .set(Some(Box::leak(qualified.clone().into_boxed_str())));
    }

    // RFC 0076 WS5: tag every harvested `tp_getset` property in the
    // descriptor registry with its owning class, so the crossing back
    // into C mints the byte-faithful `getset_descriptor` box (see
    // `object::GetSetDescrBox`) instead of a generic `property` box —
    // torch's `add_docstr(torch.Generator.device, …)` classifies by
    // `tp_name` and writes `d_getset->doc` into the struct.
    for name in &getset_names {
        let entry = ty
            .dict
            .borrow()
            .get(&weavepy_vm::object::StrKey(name))
            .cloned();
        if let Some(prop @ Object::Property(_)) = entry {
            weavepy_vm::descr_registry::register(
                &prop,
                weavepy_vm::descr_registry::DescrKind::GetSet,
                ty.clone(),
                name,
                None,
            );
        }
    }
    // Same for harvested `tp_members`: CPython types them
    // `member_descriptor`, and numpy's `_needs_add_docstring` keys off
    // `isinstance(obj, property)` — an unregistered member surfaced as a
    // plain `property` and every `add_newdoc('…', 'dtype', ('alignment',
    // …))` warned "used on a pure-python object" (the warning text also
    // pollutes subprocess stdout asserted by test_nditer's
    // test_buffered_cast_error_paths_unraisable — RFC 0076 WS1).
    for name in &member_names {
        let entry = ty
            .dict
            .borrow()
            .get(&weavepy_vm::object::StrKey(name))
            .cloned();
        if let Some(prop @ Object::Property(_)) = entry {
            weavepy_vm::descr_registry::register(
                &prop,
                weavepy_vm::descr_registry::DescrKind::Member,
                ty.clone(),
                name,
                None,
            );
        }
    }

    // RFC 0047 (wave 5): publish the C-level `tp_dict`. Cython-generated
    // module init writes into `type->tp_dict` *directly*
    // (`__Pyx_SetVtable` does `PyDict_SetItem(type->tp_dict,
    // "__pyx_vtable__", capsule)`) and reads it back through
    // `__Pyx_GetVtable` for cpdef dispatch. We back it with a dict box
    // sharing the bridge's `DictData`, so a direct `tp_dict` mutation and
    // the VM's MRO lookup observe the same storage. The type is immortal,
    // so the box (refcount 1) lives for the process, matching CPython
    // where the type owns its `tp_dict`.
    let tp_dict_box = crate::object::into_owned(Object::Dict(ty.dict.clone()));

    // RFC 0047 (wave 5): faithful `inherit_slots`. The type dict above
    // carries only the subtype's *own* dunders (inherited behaviour is
    // reached through the MRO, exactly as CPython). But a Cython-generated
    // extension reads `Py_TYPE(self)->tp_*` and `…->tp_as_number->nb_add`
    // **directly off the C struct**, with no MRO walk, so the inherited
    // slots must be baked into both the decoded table (for direct-table
    // dispatch) and the faithful struct (for inlined reads). The base was
    // already readied + flattened during harvest, so one level of copy
    // carries the whole ancestor chain.
    let base_ptr = unsafe { (*t).tp_base };
    unsafe { crate::inherit::inherit_slots(t, &mut h.slot_table, base_ptr) };

    // RFC 0047 (wave 5): record a real C `sq_item` on the bridge (after
    // `inherit_slots`, so an inherited sequence protocol counts too) so the
    // VM's `make_iter` can replicate `PyObject_GetIter`'s `PySeqIter`
    // fallback for a sequence type with no `tp_iter` (numpy's
    // `_array_converter`).
    if !h.slot_table.get(crate::slottable::Py_sq_item).is_null() {
        ty.c_sq_item.set(true);
    }

    ty.c_ext_ptr.set(t as usize);
    let readied: &'static ReadiedType = Box::leak(Box::new(ReadiedType {
        ext_ptr: t,
        bridge: ty,
        slot_table: h.slot_table,
        ob_type_seen: std::sync::atomic::AtomicUsize::new(unsafe { (*t).head.ob_type } as usize),
    }));
    if std::env::var_os("WEAVEPY_TRACE_TYPEPTR").is_some() {
        eprintln!(
            "[READY] name={:?} ext_ptr={:p} bridge={:p}",
            bare,
            t,
            Rc::as_ptr(&readied.bridge)
        );
    }
    if let Ok(mut g) = READIED_BY_PTR.lock() {
        g.get_or_insert_with(std::collections::HashMap::new)
            .insert(t as usize, readied);
    }
    if let Ok(mut g) = READIED_TYPES.lock() {
        g.push(readied);
    }
    bump_type_registry_gen();
    // RFC 0045 (wave 3): a readied static type that declares inline
    // fields beyond the object head gets faithful `tp_basicsize`
    // instance storage (the `PyArrayObject` shape).
    maybe_register_inline_type(t);

    // RFC 0047 (wave 5): publish faithful C-level `tp_base` / `tp_bases` /
    // `tp_mro`. Cython's `__Pyx_MergeVtables` reads `type->tp_base` and
    // indexes `type->tp_bases` through the `PyTuple_GET_SIZE` /
    // `PyTuple_GET_ITEM` macros (direct struct access), and
    // `__Pyx_setup_reduce` walks `tp_mro` — leaving any of them NULL
    // segfaults. Built *after* the type is registered so its own pointer
    // resolves for the `tp_mro[0]` self entry.
    let base_for_c: Option<*mut PyTypeObject> = readied
        .bridge
        .bases
        .borrow()
        .first()
        .and_then(type_ptr_for_class);
    let bases_for_c: Vec<Rc<TypeObject>> = readied.bridge.bases.borrow().clone();
    let mro_for_c: Vec<Rc<TypeObject>> = readied.bridge.mro.borrow().clone();
    let tp_bases_box = unsafe { build_type_ptr_tuple(&bases_for_c) };
    let tp_mro_box = unsafe { build_type_ptr_tuple(&mro_for_c) };

    // Write-back into the caller's struct — both offsets live inside
    // the faithful 416-byte CPython prefix, so a stock static type is
    // never overrun.
    //
    // RFC 0046 (wave 4): only *fill* a missing metaclass. CPython's
    // `PyType_Ready` sets `ob_type` to `Py_TYPE(tp_base)` (defaulting to
    // `&PyType_Type`) only when it is NULL; it must never clobber a
    // metaclass the extension pre-installed. numpy mallocs each DType
    // class with `ob_type = &PyArrayDTypeMeta_Type` (its metaclass) and
    // relies on the stock inlined `PyObject_TypeCheck(dt,
    // &PyArrayDTypeMeta_Type)` — a direct `ob_type` pointer compare — so
    // overwriting it with `&PyType_Type` made every DType fail
    // validation ("provided object … is not a DType").
    //
    // RFC 0066 WS5: the fill must be `Py_TYPE(tp_base)`, not a bare
    // `&PyType_Type`. numpy's `_ScaledFloatTestDType` is a *static*
    // DType class declared `PyVarObject_HEAD_INIT(NULL, 0)` with
    // `tp_base = &PyArrayDescr_Type` — it inherits its metaclass
    // (`PyArrayDTypeMeta_Type`, PyArrayDescr_Type's own `ob_type`)
    // through the ready, exactly CPython's `type_ready_set_type`.
    // Filling `&PyType_Type` failed the cast-spec validation
    // ("ArrayMethod provided object … is not a DType").
    unsafe {
        if (*t).head.ob_type.is_null() {
            let declared_base = (*t).tp_base;
            let base = if declared_base.is_null() {
                base_for_c.unwrap_or(std::ptr::null_mut())
            } else {
                declared_base
            };
            let mut meta = if base.is_null() {
                std::ptr::null_mut()
            } else {
                (*base).head.ob_type
            };
            if meta.is_null() {
                meta = PyType_Type.as_ptr();
            }
            (*t).head.ob_type = meta;
        }
        (*t).head.ob_refcnt = IMMORTAL_REFCNT;
        (*t).tp_flags |= PY_TPFLAGS_READY;
        // RFC 0047 (wave 5): mirror CPython's `inherit_special` and stamp
        // the fast-subclass bit for the most-derived builtin in this type's
        // ancestry. A stock extension reads these directly off `tp_flags`
        // (`PyType_Check`, `PyExceptionInstance_Check`, …); without them
        // numpy.random's Cython rejects `numpy.dtype` whose metaclass
        // `_DTypeMeta` is a `type` subclass that here would carry no
        // `Py_TPFLAGS_TYPE_SUBCLASS`.
        (*t).tp_flags |= fast_subclass_flags(&readied.bridge);
        if (*t).tp_dict.is_null() {
            (*t).tp_dict = tp_dict_box;
        } else {
            // A *pre-seeded* tp_dict: CPython's `PyType_Ready` keeps the
            // existing dict and readies *into* it — numpy builds
            // `PyUFunc_Type.tp_dict = {"__signature__": descriptor}`
            // before calling ready (multiarraymodule.c), and every ufunc
            // instance's `inspect.signature` support hangs off that
            // entry (RFC 0075 WS8). Fold the seeded entries into the
            // bridge dict (they win over harvested names, matching
            // CPython where `add_methods` skips existing keys), then
            // swap in the shared box so later direct `tp_dict`
            // mutations stay visible to the VM's MRO lookups.
            if let Object::Dict(pre) = crate::object::clone_object((*t).tp_dict) {
                for (k, v) in pre.borrow().iter() {
                    readied
                        .bridge
                        .dict
                        .borrow_mut()
                        .insert(k.clone(), v.clone());
                }
            }
            crate::object::Py_DecRef((*t).tp_dict);
            (*t).tp_dict = tp_dict_box;
        }
        if (*t).tp_base.is_null() {
            if let Some(bp) = base_for_c {
                (*t).tp_base = bp;
            }
        }
        // RFC 0076 WS5: CPython's `inherit_special` copies the base's
        // `tp_basicsize`/`tp_itemsize` **into the caller's struct** when
        // the subtype declares none. pybind11's `make_default_metaclass`
        // relies on exactly that: it allocates a metaclass off
        // `PyType_Type.tp_alloc`, sets *no* sizes, readies it, and later
        // calls `metaclass->tp_alloc(metaclass, 0)` to mint each class as
        // a full `PyHeapTypeObject`. Without the write-back the metaclass
        // reads `tp_basicsize = 0`, the class block comes back 16 bytes
        // wide, and pybind11's writes to `ht_type.tp_*`/`as_number`/…
        // shred the heap (torch's `initModule` crashed inside
        // `PyType_Ready` on a neighbour allocation's bytes).
        if !(*t).tp_base.is_null() {
            let b = (*t).tp_base;
            if (*t).tp_basicsize == 0 {
                (*t).tp_basicsize = (*b).tp_basicsize;
            }
            if (*t).tp_itemsize == 0 {
                (*t).tp_itemsize = (*b).tp_itemsize;
            }
        }
        if (*t).tp_bases.is_null() {
            (*t).tp_bases = tp_bases_box;
        } else if !tp_bases_box.is_null() {
            crate::object::Py_DecRef(tp_bases_box);
        }
        if (*t).tp_mro.is_null() {
            (*t).tp_mro = tp_mro_box;
        } else if !tp_mro_box.is_null() {
            crate::object::Py_DecRef(tp_mro_box);
        }
        if (*t).tp_dealloc.is_none() {
            (*t).tp_dealloc = Some(crate::object::_PyWeavePy_Dealloc);
        }
        // RFC 0046 (wave 4): CPython's `PyType_Ready` installs a default
        // `tp_free` (`PyObject_Free`) when the type provides none. An
        // extension `tp_dealloc` that ends with `Py_TYPE(self)->tp_free(self)`
        // — numpy's `boundarraymethod_dealloc` does — would otherwise call
        // through a NULL slot. Our `PyObject_Free` absorbs the free of a
        // faithful instance body (its block is owned by the native
        // instance) and `PyMem_Free`s a plain block.
        if (*t).tp_free.is_null() {
            let free_fp: unsafe extern "C" fn(*mut c_void) = crate::memory::PyObject_Free;
            (*t).tp_free = free_fp as *mut c_void;
        }
        // RFC 0046 (wave 4): likewise default `tp_alloc` to
        // `PyType_GenericAlloc`. CPython inherits it from `object`; an
        // extension that calls `subtype->tp_alloc(subtype, 0)` directly —
        // numpy's `arraydescr_new` does, to mint a fresh DType instance —
        // would otherwise jump through a NULL slot.
        if (*t).tp_alloc.is_null() {
            let alloc_fp: unsafe extern "C" fn(*mut PyTypeObject, PySsizeT) -> *mut PyObject =
                crate::genericalloc::PyType_GenericAlloc;
            (*t).tp_alloc = alloc_fp as *mut c_void;
        }
    }

    // RFC 0046 (wave 4): reflect a *foreign* metaclass onto the bridged
    // type so metatype-level descriptors resolve through the VM's
    // `load_attr_type` (CPython's `type_getattro` searches `Py_TYPE(type)`
    // first). numpy mallocs each DType class (`Float64DType`, …) with
    // `ob_type = &PyArrayDTypeMeta_Type`, whose `_DTypeMeta` exposes
    // `_legacy` / `_abstract` / the `type` property as getsets; a dtype's
    // `arraydescr_repr` / `.name` read `type(dtype)._legacy`. Without the
    // metaclass link `metaclass_or_type()` collapses to `type`, those reads
    // raise `AttributeError`, and dtype `repr`/`str`/`.name` degrade to the
    // foreign placeholder. Adopt any metatype other than our own
    // `PyType_Type` (and never the type itself), readied on demand so its
    // getsets are harvested. RFC 0076 WS5: a WeavePy-*owned* metatype box
    // counts too — pybind11's `py::metaclass(OpaqueBaseMeta)` hands a VM
    // class's C mirror as `ob_type` (torch's `ProcessGroup`), and the
    // bridged class must report it so `isinstance(cls, OpaqueBaseMeta)`
    // holds.
    unsafe {
        let meta_ptr = (*t).head.ob_type;
        if !meta_ptr.is_null() && meta_ptr != t && meta_ptr != PyType_Type.as_ptr() {
            if let Some(meta_t) = bridge_or_ready(meta_ptr) {
                if !Rc::ptr_eq(&meta_t, &weavepy_vm::builtin_types::builtin_types().type_) {
                    readied.bridge.set_metaclass(meta_t);
                }
            }
        }
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn PyType_IsSubtype(a: *mut PyTypeObject, b: *mut PyTypeObject) -> c_int {
    if a.is_null() || b.is_null() {
        return 0;
    }
    // CPython walks `a->tp_mro` FIRST — the only walk that sees *multiple*
    // inheritance. numpy's `complex128` reaches `complex` solely through its
    // MRO (`tp_bases == (complexfloating, complex)`, but `tp_base` points at
    // `complexfloating` only), and pandas' `is_complex_object` — the inline
    // `PyComplex_Check` → `PyType_IsSubtype` — depends on it: a base-chain
    // walk misses `complex` and `maybe_convert_objects` then coerces the
    // scalar through the float path, silently dropping the imaginary part.
    let mro = unsafe { (*(a as *mut crate::layout::PyTypeObjectFull)).tp_mro };
    if !mro.is_null() {
        let n = unsafe { crate::containers::PyTuple_Size(mro) };
        for i in 0..n {
            let item = unsafe { crate::containers::PyTuple_GetItem(mro, i) };
            if std::ptr::eq(item as *mut PyTypeObject, b) {
                return 1;
            }
        }
        // CPython returns 0 here — the MRO is authoritative. We keep
        // falling through instead: a WeavePy-bridged type's C `tp_mro`
        // mirror may be stale or partial (only faithful mirrors publish
        // one), so the bridged comparison below stays the source of truth
        // for VM-minted types.
    }
    // `a` not completely initialized (no MRO yet): `b` is a subtype if it
    // is reachable through the `tp_base` chain. A pure pointer walk —
    // correct no matter which interpreter minted either type, and never an
    // out-of-bounds read (every `PyTypeObject`, stock or ours, carries
    // `tp_base` at the standard offset). This is what makes the
    // process-global datetime shells (RFC 0029) answer
    // `PyDate_Check(datetime_instance)` correctly via their
    // `datetime → date → object` chain, where a bridge-identity
    // comparison would fail across the test harness's per-case
    // interpreters.
    if unsafe { c_base_chain_contains(a, b) } {
        return 1;
    }
    // Fall back to the bridged-MRO comparison for types whose faithful C
    // base chain is not populated (the common WeavePy bridged type).
    let (Some(a), Some(b)) = (unsafe { bridge_type(a) }, unsafe { bridge_type(b) }) else {
        return 0;
    };
    c_int::from(a.is_subclass_of(&b))
}

/// Walk `a`'s `tp_base` ancestry looking for `b` — the pointer-only core
/// of CPython's `PyType_IsSubtype`. Returns `false` (not "unknown") when
/// the chain runs out, so callers fall back to the bridged comparison.
///
/// # Safety
/// `a` must be null or a valid `PyTypeObject*`; the chain is acyclic and
/// terminates at a type whose `tp_base` is null (`object`).
unsafe fn c_base_chain_contains(a: *mut PyTypeObject, b: *mut PyTypeObject) -> bool {
    let mut cur = a;
    while !cur.is_null() {
        if std::ptr::eq(cur, b) {
            return true;
        }
        cur = unsafe { (*cur).tp_base };
    }
    false
}

#[no_mangle]
pub unsafe extern "C" fn PyObject_TypeCheck(o: *mut PyObject, ty: *mut PyTypeObject) -> c_int {
    if o.is_null() || ty.is_null() {
        return 0;
    }
    let head = unsafe { &*o };
    if std::ptr::eq(head.ob_type, ty) {
        return 1;
    }
    // Same subtype semantics as the inline CPython header
    // (`Py_IS_TYPE || PyType_IsSubtype`), including the C `tp_mro` walk
    // that multiple-inheritance extension types (numpy's scalar lattice)
    // need.
    unsafe { PyType_IsSubtype(head.ob_type, ty) }
}

/// `PyType_GetName(type)` — the type's `__name__` as a **str object**
/// (new reference), *not* the raw `tp_name` C string. PyO3's
/// `PyType::name()` (abi3 ≥ 3.11) wraps the result as a `PyString` and,
/// via `AddTypeToModule`, appends it to a module's `__all__` — handing it
/// a `char*` made it dereference string bytes as an object header
/// (cryptography's `x509.verification.VerificationError` export).
/// CPython semantics: heap types read `ht_name`; static types get the
/// tail of `tp_name` after the last dot.
#[no_mangle]
pub unsafe extern "C" fn PyType_GetName(ty: *mut PyTypeObject) -> *mut PyObject {
    if ty.is_null() {
        return ptr::null_mut();
    }
    if let Some(cls) = unsafe { bridge_type(ty) } {
        return crate::object::into_owned(Object::from_str(cls.name.clone()));
    }
    let np = unsafe { (*ty).tp_name };
    if np.is_null() {
        return ptr::null_mut();
    }
    let full = unsafe { std::ffi::CStr::from_ptr(np) }.to_string_lossy();
    let bare = full.rsplit('.').next().unwrap_or(&full);
    crate::object::into_owned(Object::from_str(bare))
}

# Compact canonical-string intern pools

The outlined native-entry experiment finished and was archived in 263 selected
files, 4,561,708 bytes, with every indexed SHA verified. No timing jobs remain.
The two-file intern-pool draft was applied by exact before/after source hashes.
The new regression test passed CPython and unchanged 5b299d93 in JIT, interpreter,
and gil=0 correctness modes. 99506 CLOSED 0: all nine new benchmark controls
also passed exact before/after-warmup values on those four variants. These are
baseline checks, not candidate validation or measured performance gains.

The existing per-thread sys pool and separate global stable-name pool now use
HashSet<Rc<str>> instead of duplicate String-keyed maps. Canonical objects remain
strongly owned and stable; pointer-sensitive marshal intern status is preserved.
UTF-8/single-character construction and existing WStr behavior remain intact.
No new dependency, unsafe code, cache, object field, or pool lifetime change.
The current runtime also includes outlined post-binding native entry and its
known fallback regressions. This memory change is independently compared with
5b299d93; focused measurements also retain 539c as an additional reference.

Formatted sources and 17 methods are frozen before build. Next gates: VM/static
checks, targeted release checks, standard compatibility, extra sys/marshal/
inspection/pathlib/copy suites, then the declared isolated focused/full timing.
No candidate binary, timing result, allocation count, or RSS gain exists yet.

342 VM tests PASS (37.11s observed test time); formatting, Clippy, and no-default-feature check pass. Release build is running. Separate post-processing summary method frozen before any timing; the original 17 active methods remain unchanged. No candidate performance claim yet.

43362 CLOSED 0: release built successfully. Candidate a1e87c1a97c941d0e92d5c82db2892719d1a1a18284b530438ce2d72d634fae4 is 44,289,520 bytes, 1,280 fewer than immediate 5b299d93. All 146 prebuild source hashes, 17 method hashes, source-snapshot hashes, and executable identity verified. The 66 targeted release checks and six extra CPython suites are running. No timing has started.

89281 CLOSED 0: all 66 targeted release checks and instrumented binding regression passed. 5312 CLOSED 0: all six extra CPython sys/marshal/inspection/pathlib/copy/copyreg suites passed without baseline fallback. Full standard compatibility is running. A separate untimed datetime path inspection is starting as input to future work; it does not edit active sources or establish a performance result.

66206 CLOSED 0: separate startup-region diagnostic completed with CPython/reference/candidate checksum agreement, successful vmmap capture, and unchanged caches after the seed. RSS snapshots are 15,122,432 / 29,638,656 / 29,229,056 bytes. Reference/candidate malloc-zone allocated bytes are reported as 6344K/6176K, allocation counts 55096/53148, and fragmentation 2680K/2416K. Candidate RSS snapshot is 409,600 bytes lower, but this is not a peak-RSS census or timing claim. All owned diagnostic children were terminated after inspection as designed. Untimed datetime path inspection also completed with exact CPython values; it motivates a separate unapplied three-file assertion-exit draft. That draft and a new Python semantic preflight are not part of this candidate.

50640 CLOSED 0: all 275 standard compatibility checks passed. Sources and all frozen methods remain exact. No owned build/test/profile jobs remain. Focused nine-control measurements are launching under the fresh strict host-load gate.

56049 CLOSED 0: all nine focused controls, exact CPython values before/after warmup, seven paired samples per variant, and isolated stable caches passed. Qualified gate; 53.4 seconds total observed. JIT intern-hit medians improve about 5.9-6.4 percent against immediate 5b299d93; marshal pooled/plain improve 4.0/2.9 percent. Long-string pool growth time improves 6.0 percent and peak RSS falls 24.7 percent; Unicode growth time improves 2.4 percent and RSS falls 13.3 percent. Short-string growth JIT workload time regresses 1.38 percent; type-name hits regress 0.13 percent. Both-mode values, CPU/wall/RSS, every sample/range/regression and reference comparisons are retained. No CPython wins are claimed for these controls. Full suite is next under a fresh strict gate.

13080 CLOSED 0: all 24 full-suite fixtures and nine startup/import controls completed, gate launch observation 2, total 338.175 seconds, end load 3.754/2.953/2.799. JIT 23-workload time is 1.006189527 of immediate predecessor and 3.401745728 of CPython, six time wins. Interpreter workload time is 1.013708831 of predecessor. All-24 JIT process wall/CPU/RSS ratios are 1.010565651/1.009625979/0.992675430; interpreter RSS is 0.984699574. JIT RSS is 2.059444270 of CPython, zero wins. Historical 21 JIT paired mean is 2.102276701 (ratio-of-medians 2.103794196). Thus focused intern/marshal wins and memory reductions coexist with small broad timing regressions. Preserve all results; do not claim overall/universal performance superiority or dismiss regressions as noise. All 146 runtime/test source hashes and all frozen methods remain exact after timing. The complete experiment is being archived before applying any next runtime change.

#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/early-bound-entry-checks/frozen"
binary=target/release/weavepy-runtime-early-bound-entry
test "$(cat target/early-bound-entry-build-stage.txt)" = done
test ! -e target/early-bound-entry-checks
mkdir target/early-bound-entry-checks
printf 'targeted binding, native calls, and observability\n' > target/early-bound-entry-check-stage.txt
for test in test_bound_native_entry test_default_suffix test_extcall_kwonly_messages test_jit_calls test_jit_dyn_calls test_jit_unboxed_calls test_jit_scalar_leaf_calls test_jit_object_lanes test_jit_raise_exits test_native_call_scratch test_native_pin_retirement test_native_pin_pressure test_frame_recycling test_recursion_guard test_cross_thread_heap test_native_generator_pin_retirement test_jit_cells test_small_slot_storage test_pickle_callables test_weakref_basic; do
    WEAVEPY_JIT=1 "$binary" "tests/regrtest/$test.py" > "target/early-bound-entry-checks/$test-jit.txt" 2>&1
    WEAVEPY_JIT=0 "$binary" "tests/regrtest/$test.py" > "target/early-bound-entry-checks/$test-interp.txt" 2>&1
    WEAVEPY_JIT=1 "$binary" -X gil=0 "tests/regrtest/$test.py" > "target/early-bound-entry-checks/$test-gil0.txt" 2>&1
done
WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_bound_native_entry.py > target/early-bound-entry-checks/native-coverage.stdout.txt 2> target/early-bound-entry-checks/native-coverage.stderr.txt
printf 'done\n' > target/early-bound-entry-check-stage.txt

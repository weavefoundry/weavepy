
def keep(a, b, c):
    return (a, b, c)
text = 'kept-' + '🧶' * 13
data = bytes(range(256))
items = tuple(range(17))
def bench(n):
    total = 0
    for i in range(n):
        a, b, c = keep(text, data, items)
        total += len(a) + len(b) + len(c)
    return total

import os
import _pydatetime as pure
def bench(n):
    total = 0
    for i in range(n):
        try:
            pure._format_time(3, 4, 5, 1999, 'invalid')
        except ValueError:
            total += 1
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

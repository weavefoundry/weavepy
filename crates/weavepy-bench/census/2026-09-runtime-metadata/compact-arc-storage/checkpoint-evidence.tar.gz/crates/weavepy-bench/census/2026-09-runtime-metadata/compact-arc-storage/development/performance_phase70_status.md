# Compact metadata beside shared pointers

Phase69 bf2 is fully measured. No timing gates or tool sessions remain active.
Its 23-workload JIT mean is 0.9974017678376587 of ed99 and 3.3573026034797753
of CPython (six wins). All-24 wall/CPU/RSS ratios to ed99 are
1.0061028891895925 / 1.0048193344398841 / 0.9766110416736018. RSS is
2.0103514564758425 of CPython, with zero wins. All full-suite RSS medians
improve, but 12 workload-time medians regress. All samples remain.

Focused bf2: shared dictionary RSS -9.5%, eight-element tuple population
-21.2%; shared population times improve 7-13%. Every unique ASCII/bytes
construction control is 2.8-5.8% slower (all seven pairs). Nine-byte strings
and bytes each use about 3.9% more RSS (all seven pairs). Warm shared calls
are 1.48% slower in all seven pairs. This isn't a universal improvement.
Need archive bf2 before replacing its source. Active runtime remains bf2.

Next independent prototype: a packed strong Arc owner with a pointer and
seven little-endian metadata bytes on 64-bit targets. A nonowning layout/ABI
model (packed_value_layout_preflight.rs) measures WideValue 24, ThinValue 16,
PackedValue 16, PackedOwner 15/alignment 1. LLVM merged the modeled thin and
packed roundtrip functions into the same aggregate ABI. This isn't an actual
VM layout, ownership, safety, or performance result. Logs/IR are retained.

Design to investigate: ordinary str/[T]/TupleStorage Arc allocations, without
the new per-allocation length header. Sealed metadata trait reconstructs the
original DST pointer from data and inline length. TupleStorage can return to
its original hash-only header, with its length in the packed strong handle.
Use ordinary full Weak<T> metadata, retaining exact liveness semantics.

Reserve all-ones inline length as an escape, not an allocation-size cap. For
larger lengths, own a Box<Arc<T>> through the pointer word. Each escaped strong
handle owns its own Box and one true Arc reference; cloning clones that Arc
into a fresh Box, preserving standard strong/weak counts and pointer identity.
Weak upgrades recover a normal Arc and repack or box it. No shared Box count
may substitute for Arc payload counts. A legitimate huge zero-sized [()] Arc
can test this path without enormous memory or iteration. Force-boxed ordinary
values can additionally exercise transitions back to inline metadata.

On 32-bit targets keep all four metadata bytes, avoiding a 16-MB allocation
threshold; the escape is usize::MAX. Copy packed pointer fields by value, never
create misaligned references. Decode the seven metadata bytes without an
eight-byte overread. Preserve pointer provenance, normal Arc alignment/drop,
UTF-8, borrowed hash lookup, tuple hash/reuse, and all existing weak/C API
contracts. This design could remove the custom slice allocation conversion
and support arbitrary element types via standard Arc<[T]> constructors.

No packed owning implementation exists yet. Validate ordinary/escaped owners,
weak upgrades, unique mutation, destructors, ZST/extreme lengths, alignments,
threads, and str hashes under Miri on ARM64 and i686 before VM integration.
Then compare actual VM layouts and unchanged focused/full inputs against both
bf2 and ed99. Keep every regression. The goal remains unachieved; no new
commit or push has been made in this continuation.

## Integration update

bf2 archive was exported and reverified (518 indexed files plus index.json).
Prototype ordinary tests and strict-provenance Miri passed all eight tests on
ARM64 and i686; prototype clippy passed. Applied compact owners to the VM after
preserving 238 current Rust sources in compact-arc-storage-preimages. Restored
the tuple hash-only allocation header and retained all old storage tests, plus
eight new compact-metadata tests. cargo check --all-targets CLI/C API passed.
No timing gate is active. Actual layout and integrated validation are next.

## Validation and disk recovery

The first integrated VM run passed 355 tests. Exact-module strict-provenance
Miri passed 16 tests each on ARM64 and i686. The first C API build failed at
linking with ENOSPC, before its tests ran. The complete linker failure remains
in compact-arc-storage-capi-tests-01.txt. After checking no compiler or runtime
was active, removed only target/debug (30,442 disposable Cargo output files,
20,977,963,461 logical bytes); cleanup manifest is retained. Source snapshots,
benchmark data, scripts, frozen caches, and release references remain. C API
validation is rebuilding offline in compact-arc-storage-capi-tests-02.txt.
No candidate release build or timing has started.

## Release build in progress

C API retry passed 156 tests across 17 completed test/doc-test groups; optional
extensions may be skipped inside passing tests. Strict clippy passed without
source edits, and the no-JIT check passed. Actual VM layout: Object,
Option<Object>, and DictKey are 16 bytes, with Object alignment 8. Compact
strong owners are 15 bytes; tuple payloads are 8 + 16*n bytes, excluding Arc
reference counts. These are layout observations only.

The source/method freeze contains 339 sources and 77 methods/inputs. Active
release build is build_compact_arc_storage.sh (session 25482). After it succeeds,
run check_compact_arc_storage.sh, then validate_compact_arc_storage.sh outside
the sandbox (local socket fixtures), plus check_compact_arc_storage_extra.py.
No timing gate may start until every owned build/test has finished and
verify_compact_arc_storage_ready.py passes.

Planned sequential timing stages, each via run_performance_under_load_gate.py:
1. focused against bf2, output compact-arc-storage-focused-thin;
2. full against bf2, output compact-arc-storage-full-thin;
3. focused against ed99, output compact-arc-storage-focused-wide;
4. full against ed99, output compact-arc-storage-full-wide.
Use matching *-load.json files and preserve every attempt/sample. Focused
launcher takes BASE OUTPUT. Full launcher takes FOCUSED OUTPUT BASE. Both
reference executables remain under target/release with their original names.

## Release identity and Python validation

Release build completed in an observed 4m04s (not a controlled build-time
comparison). Binary weavepy-runtime-compact-arc-storage is 44,317,296 bytes,
SHA-256 65ff081f8d85851c247cee8cc9e64bd3ebb1f80d49b617cbd6115ab44141c883.
Snapshot captured 165 sources plus measurement inputs. All 339 prebuild source
and 77 method hashes were verified unchanged. All 87 targeted Python checks
passed (29 tests x three modes), plus a native-coverage trace. Extra bytes,
codecs, and four nested C API suites passed. Marshal matches the same four
exactly graded baseline divergences on both new and ed99; not a clean pass.
Main outside-sandbox compatibility validation is active in session 63037.
No build remains active, and no performance gate has started.

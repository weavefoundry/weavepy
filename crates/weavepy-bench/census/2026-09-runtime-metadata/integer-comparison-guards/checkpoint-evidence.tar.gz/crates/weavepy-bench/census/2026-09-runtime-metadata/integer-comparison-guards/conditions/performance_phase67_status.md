# Guarded opaque integer comparisons

The assertion experiment finished and was archived in 231 selected files,
1,068,986 bytes, with all stored/uncompressed hashes verified. Its broad JIT
work mean improves 0.24 percent, but peak RSS increases 0.17 percent and nested
loops regress 13.4 percent across all five pairs. Those remain in the evidence;
the overall goal is unachieved. ed99 is this experiment's immediate baseline.

93322 CLOSED 0: all 19 benchmark controls agree before/after warmup on CPython
and unchanged ed99 in JIT, interpreter, and GIL-disabled modes. The semantic v2
preflight also passed all four variants, including uniquely named functions and
loop callback exception locals/traceback. Original v1 evidence remains separate.

The two-file draft was applied after exact baseline/draft hashes were verified.
It reuses the existing exact-Int guard at COMPARE_OP after producing calls,
with both original operands retained for misses. No call fusion, new runtime
helper, object field, cache, unsafe code, or execution policy is added. Two
opaque values and opaque/float pairs retain their previous analysis. Candidate
correctness and performance have not yet been established. Formatting and
prebuild freezing precede full JIT/VM/static tests and the correct CLI build.

13775 CLOSED 101 before VM/static/release stages: the new analyzer fixture failed TypeUnknown because it passed n only to an opaque producer but never supplied n's parameter lane. The existing Cfg defaults unprobed arguments to unknown. Corrected only the fixture with typed_params slot 1 Int, matching runtime seeded parameter probing; all six operators and both operand orders retain guard-PC/IntCmp assertions. Runtime draft is unchanged. The original failing JIT output, method, and 148-source manifest remain preserved; the v2 continuation uses distinct logs and a corrected source manifest. No candidate executable or timing exists yet.

All 59 corrected JIT tests and all 342 VM tests pass (36.69s observed VM test duration); format, Clippy, and no-default-feature checks pass. Release is running. An untimed nested-loop diagnostic preserves CPython-equivalent values and identical a1e/ed99 stats, including zero deopts; it does not explain or erase the five-pair timing regression. The old pin-memo draft has been rebased into a separate v2 draft that preserves the current outlined entry helper, but is unapplied and unvalidated. A broader single-allocation thin-owner design note is also unapplied and makes no safety/performance claim.

59050 CLOSED 0: corrected build and complete JIT/VM/static tests pass. Candidate e709418a7c2ff7282cf45cf7ee8b00783fbd50e1ce574c440ff2c23c54fc6ede is 44289536 bytes. Corrected 148 source/test and original 19/corrected 20 method hashes verified; release/default binary identities agree. Candidate targeted checks, positive-discovery extra suites, and actual 19-function compile/rebuild coverage are next. No timing yet.

52316 and 14737 CLOSED 0: all 72 targeted release checks pass, and all 19 named comparison functions actually compile and rebuild with exact CPython results. 75388 CLOSED 0: all six extra suites select nonempty tests and pass, including comparison, rich comparison, long integers, calls, extended calls, and unittest. Full 275-case compatibility is running in 41247. The separate untimed datetime diagnostic method was frozen before execution. No timing yet.

Untimed datetime values agree with CPython. Compiled functions rise from 26 to 28 (__lt__ and __gt__), but native-call deopts rise from 0 to 64 in this driver. _ymd2ord still rejects MixedArithTypes; field validators now advance to FORMAT_VALUE operand-lane rejection. Neither compilation counts nor rejection changes establish a speedup. The diagnostic is preserved separately; full compatibility remains running.

A separate, unapplied thin-slice prototype now retains standard Arc refcounts and wide Weak handles while storing length in the allocation. Two ordinary tests pass (all lengths 0..1024 for u8/u32 and concurrent weak upgrades/last-strong drops). These are not a memory-safety or performance proof. An isolated nightly Miri toolchain was installed (84939 CLOSED 0) without changing the default; strict-provenance checks are starting. No benchmark gate may launch while this owned setup/check job can run. The active WeavePy runtime remains unchanged.

41247 CLOSED 0: all 275 standard compatibility checks passed. The candidate has completed correctness gates. Focused measurement remains pending until the unrelated, owned Miri prototype check completes; no timing gate is armed yet. All later timing will use the existing frozen methods and source hashes.

40553 CLOSED 0: both standalone thin-slice prototype tests pass under Miri strict provenance on aarch64-apple-darwin. This is evidence for those prototype cases, not proof of a sound/full VM migration or a performance result. No owned build/test/profile/install jobs remain. The comparison candidate's 148 corrected source/test and 19/20 method hashes still match. Its 19-control focused measurement is next under the strict gate; all runtime and active methods stay frozen. A separate two-file borrowing-defaults proposal is only a draft and has not been applied or tested.

Source audit correction: TupleStorage defaults to unsized [Object], making Object::Tuple another wide Arc. The earlier thin-layout lead understated the scope: strings/bytes alone cannot shrink Object. Both design notes now explicitly preserve this correction. The isolated u8/u32 prototype is unchanged and establishes no tuple or Object-layout result. The borrowing-defaults draft changes one runtime source file, not two; it remains unapplied.

2230 CLOSED 0: focused strict gate qualified and finished; all 19 controls, seven pairs, values, and frozen caches verified. Left/right integer comparisons take .786771/.791926 of ed99 time; integer-returning branch takes .364454. Complex callback with no rich misses regresses to 1.125484 warm and 1.150999 cold; 1/100 rich misses regress 1.031766 warm and 1.096722 cold. These are not universal wins. Several RSS medians rise, including warm rich_every_2 at 1.008108. All pairs and interpreter/control losses remain. Full census/startup timing is running in 61120; runtime and active methods remain unchanged.

61120 CLOSED 0: full strict gate qualified and completed in 336.96s; end load 2.6387/2.6357/2.6602. All 148 corrected source/test and 19/20 method hashes verified. JIT 23-workload new/ed99 1.002726534, new/CPython 3.387763140, 6 wins. Historical 21 paired 2.091439073, ratio of medians 2.091853640. All-24 process wall/CPU/RSS new/base 1.008229779/1.006882514/1.001823041; RSS/CPython 2.062056488, zero wins. This is an under-refinement tradeoff, not a completed overall optimization. All individual time/RSS regressions remain in raw data and summaries. A separate post-timing five-control callback trace agrees with CPython. An unapplied three-file call-fusion draft reuses the existing exact-integer result path; v2 corrects constant opcode spellings before any compilation or source application. Original draft remains preserved.

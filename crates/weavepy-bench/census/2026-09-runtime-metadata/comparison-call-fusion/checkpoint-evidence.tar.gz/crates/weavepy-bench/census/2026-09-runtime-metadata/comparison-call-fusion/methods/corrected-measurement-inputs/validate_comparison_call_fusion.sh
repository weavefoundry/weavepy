#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/comparison-call-fusion-validation/frozen"
binary=target/release/weavepy-runtime-comparison-call-fusion
output=target/comparison-call-fusion-validation
test "$(cat target/comparison-call-fusion-check-stage.txt)" = done
test ! -e "$output"
mkdir "$output"
printf 'full compatibility\n' > target/comparison-call-fusion-validation-stage.txt
python3.14 crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py --binary "$binary" --out "$output/validation.json" > "$output/validation.txt" 2>&1
printf 'done\n' > target/comparison-call-fusion-validation-stage.txt

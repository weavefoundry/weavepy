"""Run the exact new regression source before changing the runtime."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path('target/bound-native-entry-baseline-preflight');root.mkdir()
source=Path('target/test_bound_native_entry_draft.py')
copy=root/source.name;copy.write_bytes(source.read_bytes())
report={'source_sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'runs':{}}
variants=[('cpython',shutil.which('python3.14'),None,[]),
          ('baseline_jit','target/release/weavepy-runtime-pickle-special-lookup','1',[]),
          ('baseline_interp','target/release/weavepy-runtime-pickle-special-lookup','0',[]),
          ('baseline_gil0','target/release/weavepy-runtime-pickle-special-lookup','1',['-X','gil=0'])]
for label,binary,jit,flags in variants:
    env=dict(os.environ)
    for key in ['WEAVEPY_JIT','WEAVEPY_JIT_TRACE','WEAVEPY_VM_STATS','WEAVEPY_JIT_THRESHOLD']:
        env.pop(key,None)
    digest=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    if jit is not None:
        env.update(WEAVEPY_JIT=jit,WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
                   WEAVEPY_FROZEN_CACHE=str((root/'frozen'/digest).resolve()))
    command=[binary,*flags,str(copy)]
    result=subprocess.run(command,env=env,text=True,capture_output=True,timeout=120)
    report['runs'][label]={'command':command,'binary_sha256':digest,'returncode':result.returncode,
                            'stdout':result.stdout,'stderr':result.stderr}
    (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(label,result.returncode,result.stdout,result.stderr[-2500:],flush=True)
raise SystemExit(0 if all(r['returncode']==0 and r['stdout']=='bound native entry: ok\n' for r in report['runs'].values()) else 1)

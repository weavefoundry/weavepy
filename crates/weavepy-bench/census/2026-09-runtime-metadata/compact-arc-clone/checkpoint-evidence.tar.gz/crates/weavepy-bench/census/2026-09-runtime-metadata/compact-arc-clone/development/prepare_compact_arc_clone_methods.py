"""Fresh one-change trial against 65ff and retained bf2; preserve prior methods."""
from pathlib import Path

def fresh(name, text):
    path = Path('target') / name
    assert not path.exists(), path
    path.write_text(text)

for name in ['build_compact_arc_storage.sh', 'check_compact_arc_storage.sh',
             'validate_compact_arc_storage.sh', 'check_compact_arc_storage_extra.py',
             'measure_compact_arc_storage_focused.sh', 'measure_compact_arc_storage_full.sh',
             'summarize_compact_arc_storage.py', 'verify_compact_arc_storage_ready.py',
             'freeze_compact_arc_storage_sources.py']:
    s = (Path('target') / name).read_text()
    s = s.replace('compact-arc-storage', 'compact-arc-clone').replace('compact_arc_storage', 'compact_arc_clone')
    if name.startswith('build_'):
        s = s.replace('base=target/release/weavepy-runtime-thin-value-storage', 'base=target/release/weavepy-runtime-compact-arc-storage')
    if name.startswith('check_') and name.endswith('.py'):
        s = s.replace('weavepy-runtime-jit-assertion-exits', 'weavepy-runtime-compact-arc-storage')
    if name.startswith('verify_'):
        s = s.replace('capi-tests-02.txt', 'capi-tests-01.txt')
        s = s.replace('weavepy-runtime-jit-assertion-exits', 'weavepy-runtime-thin-value-storage')
        s = s.replace('ed99cdbaf8e403eb7de9e3cbac86687748481596443b0e5055a77057c57a0a29', 'bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4')
    if name.startswith('freeze_'):
        s = s.replace("paths = set(json.loads(Path('target/thin-value-storage-prebuild.json').read_text())['sources'])", "paths = set(json.loads(Path('target/compact-arc-storage-prebuild.json').read_text())['sources'])")
        s = s.replace("paths.update(json.loads(Path('target/compact-arc-clone-preimages/index.json').read_text())['sources'])\n", '')
    fresh(name.replace('compact_arc_storage', 'compact_arc_clone'), s)
print('Prepared fresh clone-trial methods against 65ff and bf2.')

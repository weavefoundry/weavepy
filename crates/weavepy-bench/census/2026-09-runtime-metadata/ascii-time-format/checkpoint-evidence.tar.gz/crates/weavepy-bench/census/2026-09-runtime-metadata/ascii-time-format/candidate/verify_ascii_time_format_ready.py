"""Require complete formatter validation and unchanged measured identities."""
from pathlib import Path
import hashlib
import json
import re

def read(path):
    return json.loads(Path(path).read_text())
for group in read('target/ascii-time-format-prebuild.json').values():
    for path, digest in group.items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest() == digest, path
env = read('target/ascii-time-format-source-snapshot/environment.json')
for label in ['new', 'previous']:
    item = env['binaries'][label]
    assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest() == item['sha256'], label
assert env['binaries']['previous']['sha256'] == 'bc88bf2b02abaaf0ad6a3d7427a17cab11f864a400a8161fc2effe5f396dd695'
assert hashlib.sha256(Path('target/release/weavepy-runtime-thin-value-storage').read_bytes()).hexdigest() == 'bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'
assert 'test result: ok. 351 passed' in Path('target/ascii-time-format-vm-tests-01.txt').read_text()
text = Path('target/ascii-time-format-capi-tests-01.txt').read_text()
assert 'test result: FAILED' not in text
assert sum(map(int, re.findall(r'test result: ok\. (\d+) passed', text))) == 156
for label in ['clippy-01', 'nojit-check']:
    assert 'Finished' in Path(f'target/ascii-time-format-{label}.txt').read_text()
expected = 'time formatting semantics: ok\n'
for label in ['cpython', 'baseline-jit', 'baseline-interp', 'baseline-gil0']:
    assert Path(f'target/ascii-time-format-oracle-{label}.txt').read_text() == expected
assert Path('target/ascii-time-format-check-stage.txt').read_text().strip() == 'done'
checks = Path('target/ascii-time-format-checks')
for mode in ['jit', 'interp', 'gil0']:
    assert len(list(checks.glob(f'*-{mode}.txt'))) == 32
    assert (checks / f'test_time_format_fastpath-{mode}.txt').read_text() == expected
validation = read('target/ascii-time-format-validation/validation.json')
assert len(validation) == 275 and all(r['passed'] for r in validation)
assert Path('target/ascii-time-format-checks/native-format-coverage.txt').read_text() == 'native formatter active\n'
print('All source/method identities, native checks, 96 targeted checks, and 275 compatibility checks verified.')

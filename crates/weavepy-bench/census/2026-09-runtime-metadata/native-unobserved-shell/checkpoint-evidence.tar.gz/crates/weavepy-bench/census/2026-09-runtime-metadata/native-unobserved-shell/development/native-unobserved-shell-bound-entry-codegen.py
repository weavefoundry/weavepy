"""Supplement the frozen symbol probe with the actual bound-entry symbol name."""
from pathlib import Path
import hashlib,json,subprocess
root=Path('target/native-unobserved-shell-codegen')
report={'purpose':__doc__,'method_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'variants':{}}
name='try_call_native_bound'
for label,binary in [('previous','target/release/weavepy-runtime-ascii-time-format'),('new','target/release/weavepy-runtime-native-unobserved-shell')]:
    symbols=(root/(label+'-symbols.txt')).read_text()
    matches=[line.split()[-1] for line in symbols.splitlines() if line.split() and line.split()[-1].endswith('5tier2'+str(len(name))+name)]
    assert len(matches)==1,(label,matches)
    symbol=matches[0]
    result=subprocess.run(['xcrun','llvm-objdump','--macho','--disassemble','--dis-symname',symbol,binary],text=True,capture_output=True,check=True)
    path=root/(label+'-bound-entry.txt');assert not path.exists();path.write_text(result.stdout)
    lines=result.stdout.splitlines();start=lines.index(symbol+':')
    report['variants'][label]={'binary_sha256':hashlib.sha256(Path(binary).read_bytes()).hexdigest(),'symbol':symbol,'assembly':str(path),'assembly_sha256':hashlib.sha256(result.stdout.encode()).hexdigest(),'prologue':lines[start+1:start+15]}
    print(label,'\n'+'\n'.join(lines[start+1:start+10]))
p=root/'bound-entry-report.json';assert not p.exists();p.write_text(json.dumps(report,indent=2)+'\n')

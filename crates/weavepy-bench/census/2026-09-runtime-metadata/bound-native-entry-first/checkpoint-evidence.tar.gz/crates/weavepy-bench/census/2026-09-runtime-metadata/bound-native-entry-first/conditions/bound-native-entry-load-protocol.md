# Host conditions for post-binding native entry

After all candidate correctness and coverage checks pass, attempt a strict
focused gate: one- and five-minute load at most four on this eight-CPU host,
three consecutive observations ten seconds apart, and a maximum 600-second
wait. Record its complete result. Once measurement starts, keep all samples
regardless of later load. Do not repeat or select benchmark samples.

Only if that gate expires with no child and no focused measurement output,
run the separately declared focused diagnostic with no quiet-host requirement.
The conditional launcher checks those facts before starting. Use fresh output
paths and retain all load, value, cache, wall, CPU, and RSS observations. Label
this as a busy-host diagnostic and keep the preceding qualified headline.

The full startup/standard comparison takes the completed focused directory and
a fresh output directory as explicit arguments. If focused timing qualified,
attempt the same strict precondition for the full run. If the focused run was
a diagnostic, use a separately recorded full diagnostic without a quiet-host
claim. A failed full strict gate may likewise be followed only by a separately
declared diagnostic when no samples or child were started. Retain the failed
gate and all subsequent samples. All nine startup cases and all 24 standard
fixtures remain required, with their declared paired sample counts and explicit
historical/full/process cohorts.

No runtime or active harness edits, competing builds, tests, or profiles while
a gate can launch or a benchmark is active. These observations cannot establish
universal, energy, controlled build, portability, or free-threaded improvements.

"""Force sparse keyword binding after both complete and suffix-default calls bypassed it."""
import hashlib,json
from pathlib import Path
old=Path('target/binder-flag-inputs-v2');root=Path('target/binder-flag-inputs-v3');root.mkdir()
prepared=json.loads((old/'preparation.json').read_text());rows={}
for name,row in prepared['rows'].items():
    source=Path(row['path']).read_text();assert hashlib.sha256(source.encode()).hexdigest()==row['source_sha256']
    if name=='many_body_locals':
        assert 'def leaf(a, b=2, c=3):' in source
        source=source.replace('def leaf(a, b=2, c=3):','def leaf(a, b=2, c=3, d=4):').replace('return body0 + body129 + b + c','return body0 + body129 + b + c + d').replace('leaf(b=3, a=i)','leaf(d=5, a=i)')
    p=root/(name+'.py');p.write_text(source)
    d=root/(name+'-verify.py');d.write_text(Path(row['driver']).read_text().replace(str(old)+'/',str(root)+'/'))
    rows[name]={'path':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'driver':str(d),'driver_sha256':hashlib.sha256(d.read_bytes()).hexdigest()}
    if name!='many_body_locals':assert rows[name]['source_sha256']==row['source_sha256']
(root/'preparation.json').write_text(json.dumps({'work':prepared['work'],'rows':rows,'supersedes_before_timing':str(old),'reason':'V2 also bypassed the binder through optimized trailing defaults. V3 supplies a and d while omitting b and c. Other nine source hashes remain identical.'},indent=2)+'\n')
(root/'protocol.md').write_text((old/'protocol.md').read_text()+'''\nV3 correction before any timing: v2 also produced 850 native-to-native calls
and only three generic dynamic calls, failing the >=500 generic coverage check.
Preserve that failure. V3 uses the known sparse layout leaf(d=5, a=i) with b/c
omitted in the middle. Only this changed case needs another path inspection;
the other nine source hashes match their already inspected versions.
''')
p=Path('target/inspect_binder_signature_paths_v3.py');assert not p.exists()
s=Path('target/inspect_binder_signature_paths_v2.py').read_text().replace('binder-flag-inputs-v2','binder-flag-inputs-v3').replace('binder-flags-signature-paths-v2','binder-flags-signature-paths-v3')
line="prepared = json.loads(Path('target/binder-flag-inputs-v3/preparation.json').read_text())"
assert line in s;s=s.replace(line,line+"\nprepared['rows'] = {'many_body_locals': prepared['rows']['many_body_locals']}")
s=s.replace('All ten signature-control values match CPython; actual native/fallback paths recorded.','The corrected many-body-local value matches CPython and has verified generic binding calls.')
p.write_text(s)
p=Path('target/measure_binder_flags_focused_v3.sh');assert not p.exists();p.write_text(Path('target/measure_binder_flags_focused_v2.sh').read_text().replace('binder-flag-inputs-v2','binder-flag-inputs-v3').replace('binder-flags-signature-paths-v2','binder-flags-signature-paths-v3'))
root=Path('target/binder-flags-v3-measurement-inputs');root.mkdir()
paths=list(json.loads(Path('target/binder-flags-v2-measurement-inputs/index.json').read_text()))+['target/prepare_binder_flag_inputs_v3.py','target/inspect_binder_signature_paths_v3.py','target/measure_binder_flags_focused_v3.sh']
records={}
for name in paths:
 p=Path(name);b=p.read_bytes();(root/p.name).write_bytes(b);records[name]=hashlib.sha256(b).hexdigest()
(root/'index.json').write_text(json.dumps(records,indent=2)+'\n')
print('Preserved the v2 coverage failure; froze v3 controls and',len(records),'method files before timing.')

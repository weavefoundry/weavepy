"""Freeze comparison success, guard misses, recovery, and datetime controls."""
import hashlib
import json
from pathlib import Path

root = Path('target/integer-comparison-inputs')
root.mkdir()
warm = {}
for name, expression in [('left_int', 'f(i) < 2500'), ('right_int', '2500 > f(i)'), ('branch_int', 'f(i) >= 2500')]:
    body = '        total += compare(exact, i)\n'
    compare = '    return ' + expression + '\n'
    if name == 'branch_int':
        compare = '    if ' + expression + ':\n        return 7\n    return 9\n'
    warm[name] = 'def exact(i):\n    return i\ndef compare(f, i):\n' + compare + 'def bench(n):\n    total = 0\n    for i in range(n):\n' + body + '    return total\n'
for name, result in [('bool_miss', 'bool(i & 1)'), ('float_miss', 'i + 0.5'), ('bigint_miss', '(1 << 80) + i')]:
    warm[name] = f'''def produce(i):
    return {result}
def compare(f, i):
    return f(i) < 2500
def bench(n):
    total = 0
    for i in range(n):
        total += compare(produce, i)
    return total
'''
rich = '''class Rich:
    def __lt__(self, other):
        return False
RICH = Rich()
def produce(i):
    return RICH if PERIOD and i % max(PERIOD, 1) == 0 else i
def compare(f, i):
    return f(i) < 2500
def bench(n):
    total = 0
    for i in range(n):
        total += compare(produce, i)
    return total
'''
for period in (0, 100, 2, 1):
    warm['rich_every_' + str(period)] = 'PERIOD = ' + str(period) + '\n' + rich
warm['miss_burst_recovery'] = '''class Rich:
    def __lt__(self, other):
        return False
RICH = Rich()
def produce(i):
    return RICH if i < 0 else i
def compare(f, i):
    return f(i) < 2500
def bench(n):
    total = 0
    for i in range(100):
        total += compare(produce, -1)
    for i in range(n):
        total += compare(produce, i)
    return total
'''
for name in ('date_toordinal', 'date_weekday', 'datetime_add', 'datetime_subtract'):
    warm[name] = Path('target/assertion-exit-inputs/warm/' + name + '.py').read_text()
cold = {name: warm[name] for name in ('rich_every_0', 'rich_every_100', 'rich_every_2', 'rich_every_1')}
for group, cases in [('warm', warm), ('cold', cold)]:
    directory = root / group
    directory.mkdir()
    rows = {}
    for name, source in cases.items():
        if group == 'cold':
            source += '''
if __name__ == "__main__":
    import os
    import time
    n = int(os.environ["WEAVEPY_BENCH_WORK"])
    start = time.perf_counter_ns()
    result = bench(n)
    elapsed = time.perf_counter_ns() - start
    print("WEAVEPY_BENCH_NS=%d" % elapsed)
'''
        p = directory / (name + '.py')
        p.write_text(source)
        driver = directory / (name + '-verify.py')
        driver.write_text(f'''import importlib.util
import json
spec = importlib.util.spec_from_file_location("comparison_control", {str(p.resolve())!r})
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(5000)
for _ in range(6):
    module.bench(5000)
last = module.bench(5000)
print(json.dumps(first))
print(json.dumps(last))
''')
        rows[name] = {'path': str(p), 'source_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                      'driver': str(driver), 'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest()}
    (directory / 'preparation.json').write_text(json.dumps({'work': 5000, 'rows': rows}, indent=2) + '\n')
print('Prepared', len(warm), 'warm and', len(cold), 'cold comparison controls.')

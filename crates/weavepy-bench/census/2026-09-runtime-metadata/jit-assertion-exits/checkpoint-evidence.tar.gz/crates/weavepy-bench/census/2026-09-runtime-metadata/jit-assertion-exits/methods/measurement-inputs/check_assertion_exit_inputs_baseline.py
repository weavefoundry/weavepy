"""Verify new assertion controls on the unchanged baseline and CPython."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

out = Path("target/assertion-exit-inputs-baseline")
out.mkdir()
previous = "target/release/weavepy-runtime-compact-intern-pools"
variants = [("cpython", shutil.which("python3.14"), None, []),
            ("jit", previous, "1", []), ("interp", previous, "0", []),
            ("gil0", previous, "1", ["-X", "gil=0"])]
report = {"binaries": {}, "rows": {}, "timed_samples": 0}
for label, binary, _, _ in variants:
    report["binaries"][label] = {"path": binary, "sha256": hashlib.sha256(Path(binary).read_bytes()).hexdigest()}
for group in ("warm", "cold"):
    prepared = json.loads(Path("target/assertion-exit-inputs/" + group + "/preparation.json").read_text())
    for name, case in prepared["rows"].items():
        row = report["rows"][group + "/" + name] = {"case": case, "runs": {}}
        for key in ("path", "driver"):
            assert hashlib.sha256(Path(case[key]).read_bytes()).hexdigest() == case["source_sha256" if key == "path" else "driver_sha256"]
        for label, binary, jit, flags in variants:
            env = dict(os.environ)
            for key in ("WEAVEPY_JIT", "WEAVEPY_GIL", "WEAVEPY_JIT_TRACE", "WEAVEPY_VM_STATS", "WEAVEPY_JIT_THRESHOLD"):
                env.pop(key, None)
            if jit is not None:
                env.update(WEAVEPY_JIT=jit, WEAVEPY_STDLIB_CACHE=str(Path("target/performance-stdlib-cache").resolve()),
                           WEAVEPY_FROZEN_CACHE=str((out / "frozen" / report["binaries"][label]["sha256"]).resolve()))
            result = subprocess.run([binary, *flags, case["driver"]], env=env, text=True, capture_output=True, timeout=180)
            row["runs"][label] = {"returncode": result.returncode, "stdout": result.stdout, "stderr": result.stderr}
            (out / "report.json").write_text(json.dumps(report, indent=2) + "\n")
            assert result.returncode == 0, (name, label, result.stderr)
            values = [json.loads(line) for line in result.stdout.splitlines()]
            assert len(values) == 2 and values[0] == values[1], (name, label, values)
        assert all(r["stdout"] == row["runs"]["cpython"]["stdout"] for r in row["runs"].values()), name
        print(group, name, "four variants passed", flush=True)
report["status"] = "passed"
(out / "report.json").write_text(json.dumps(report, indent=2) + "\n")

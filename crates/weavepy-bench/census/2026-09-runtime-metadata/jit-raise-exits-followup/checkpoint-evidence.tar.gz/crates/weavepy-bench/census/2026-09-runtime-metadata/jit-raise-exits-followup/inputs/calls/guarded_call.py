def guarded_call(n):
    if n < 0:
        raise ValueError("negative")
    return n * 3 + 1

def bench(n):
    total = 0
    for i in range(n):
        total += guarded_call(i)
    return total

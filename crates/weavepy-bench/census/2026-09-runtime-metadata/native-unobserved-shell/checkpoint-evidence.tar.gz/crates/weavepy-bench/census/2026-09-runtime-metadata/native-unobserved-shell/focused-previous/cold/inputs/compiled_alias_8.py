import os
def leaf(x0, x1, x2, x3, x4, x5, x6, x7):
    return x0 + x1 + x2 + x3 + x4 + x5 + x6 + x7

def bench(n):
    f = leaf
    total = 0
    for i in range(n):
        total += f(i, 1, 2, 3, 4, 5, 6, 7)
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

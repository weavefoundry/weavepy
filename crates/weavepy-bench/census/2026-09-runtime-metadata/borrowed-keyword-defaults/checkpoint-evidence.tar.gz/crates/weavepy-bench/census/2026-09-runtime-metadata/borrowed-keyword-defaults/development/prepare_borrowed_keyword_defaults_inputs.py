"""Retain positional controls and add keyword-only default-binding controls."""
from pathlib import Path
import hashlib
import json

root = Path('target/borrowed-keyword-defaults-inputs')
assert not root.exists()
for group in ['cold', 'warm']:
    folder = root / group
    folder.mkdir(parents=True)
    previous = json.loads(Path(f'target/borrowed-defaults-inputs/{group}/preparation.json').read_text())
    texts = {name: Path(row['path']).read_text() for name, row in previous['rows'].items()}
    for width in [1, 4, 16, 64]:
        for mode in ['omitted', 'partial_keyword']:
            texts[f'kw_override_{width}_{mode}'] = None
    for width in [4, 64]:
        texts[f'kw_override_{width}_all_supplied'] = None
        texts[f'kw_compiled_{width}_omitted'] = None
    prepared = {'purpose': __doc__, 'work': 20000, 'rows': {}}
    for name, text in texts.items():
        if text is None:
            _, kind, width, *mode = name.split('_')
            width = int(width)
            mode = '_'.join(mode)
            override = kind == 'override'
            params = ', '.join(f'a{i}' + ('' if override else f'=values[{i}]') for i in range(width))
            argument = {'omitted': '', 'partial_keyword': f'a{width-1}=provided',
                        'all_supplied': ', '.join(f'a{i}=provided' for i in range(width))}[mode]
            text = f'''import os
values = tuple("default-%d-" % i + "shared-text" * 3 for i in range({width}))
provided = "provided-" + "string" * 3
def target(*, {params}):
    return a{width-1}
'''
            if override:
                text += f'target.__kwdefaults__ = {{"a%d" % i: values[i] for i in range({width})}}\n'
            text += f'''def bench(n):
    total = 0
    for _ in range(n):
        total += len(target({argument}))
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))
'''
        path = folder / (name + '.py')
        path.write_text(text)
        driver = folder / (name + '-verify.py')
        driver.write_text(f'''import importlib.util, json
spec = importlib.util.spec_from_file_location('default_control', {str(path.resolve())!r})
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(20000)
for _ in range(6):
    module.bench(64)
last = module.bench(20000)
print(json.dumps(first))
print(json.dumps(last))
''')
        prepared['rows'][name] = {'path': str(path), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                 'driver': str(driver), 'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest()}
    (folder / 'preparation.json').write_text(json.dumps(prepared, indent=2) + '\n')
print('Prepared 24 cold and 24 warm binding controls, including unchanged positional sources.')

	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	__RINvNtCs82bWklYMk3w_3std2rt10lang_startuECs62ZXp5Ablwp_29niche_string_layout_preflight
	.globl	__RINvNtCs82bWklYMk3w_3std2rt10lang_startuECs62ZXp5Ablwp_29niche_string_layout_preflight
	.p2align	2
__RINvNtCs82bWklYMk3w_3std2rt10lang_startuECs62ZXp5Ablwp_29niche_string_layout_preflight:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x4, x3
	mov	x3, x2
	mov	x2, x1
	str	x0, [sp, #8]
Lloh0:
	adrp	x1, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.0@PAGE
Lloh1:
	add	x1, x1, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.0@PAGEOFF
	add	x0, sp, #8
	bl	__RNvNtCs82bWklYMk3w_3std2rt19lang_start_internal
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.p2align	2
__RINvNtNtCs82bWklYMk3w_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs62ZXp5Ablwp_29niche_string_layout_preflight:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	blr	x0
	; InlineAsm Start
	; InlineAsm End
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0Cs62ZXp5Ablwp_29niche_string_layout_preflight:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCs82bWklYMk3w_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs62ZXp5Ablwp_29niche_string_layout_preflight
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNSNvYNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0INtNtNtCs8Mbv00yxnRz_4core3ops8function6FnOnceuE9call_once6vtableCs62ZXp5Ablwp_29niche_string_layout_preflight:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCs82bWklYMk3w_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs62ZXp5Ablwp_29niche_string_layout_preflight
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.private_extern	__RNvCs62ZXp5Ablwp_29niche_string_layout_preflight4main
	.globl	__RNvCs62ZXp5Ablwp_29niche_string_layout_preflight4main
	.p2align	2
__RNvCs62ZXp5Ablwp_29niche_string_layout_preflight4main:
	.cfi_startproc
	sub	sp, sp, #160
	.cfi_def_cfa_offset 160
	stp	x29, x30, [sp, #144]
	add	x29, sp, #144
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Lloh2:
	adrp	x8, __RNvXsi_NtNtNtCs8Mbv00yxnRz_4core3fmt3num3impjNtB9_7Display3fmt@GOTPAGE
Lloh3:
	ldr	x8, [x8, __RNvXsi_NtNtNtCs8Mbv00yxnRz_4core3fmt3num3impjNtB9_7Display3fmt@GOTPAGEOFF]
Lloh4:
	adrp	x9, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.1@PAGE
Lloh5:
	add	x9, x9, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.1@PAGEOFF
	stp	x9, x8, [sp]
Lloh6:
	adrp	x10, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.2@PAGE
Lloh7:
	add	x10, x10, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.2@PAGEOFF
	stp	x10, x8, [sp, #16]
	stp	x10, x8, [sp, #32]
	stp	x10, x8, [sp, #48]
Lloh8:
	adrp	x11, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.3@PAGE
Lloh9:
	add	x11, x11, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.3@PAGEOFF
	stp	x11, x8, [sp, #64]
	stp	x9, x8, [sp, #80]
	stp	x9, x8, [sp, #96]
	stp	x9, x8, [sp, #112]
	stp	x10, x8, [sp, #128]
Lloh10:
	adrp	x0, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.4@PAGE
Lloh11:
	add	x0, x0, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.4@PAGEOFF
	mov	x1, sp
	bl	__RNvNtNtCs82bWklYMk3w_3std2io5stdio6__print
	.cfi_def_cfa wsp, 160
	ldp	x29, x30, [sp, #144]
	add	sp, sp, #160
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh10, Lloh11
	.loh AdrpAdd	Lloh8, Lloh9
	.loh AdrpAdd	Lloh6, Lloh7
	.loh AdrpAdd	Lloh4, Lloh5
	.loh AdrpLdrGot	Lloh2, Lloh3
	.cfi_endproc

	.globl	_string_length
	.p2align	2
_string_length:
	.cfi_startproc
	ldr	x0, [x0, #8]
	ret
	.cfi_endproc

	.globl	_main
	.p2align	2
_main:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x3, x1
	sxtw	x2, w0
Lloh12:
	adrp	x8, __RNvCs62ZXp5Ablwp_29niche_string_layout_preflight4main@PAGE
Lloh13:
	add	x8, x8, __RNvCs62ZXp5Ablwp_29niche_string_layout_preflight4main@PAGEOFF
	str	x8, [sp, #8]
Lloh14:
	adrp	x1, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.0@PAGE
Lloh15:
	add	x1, x1, l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.0@PAGEOFF
	add	x0, sp, #8
	mov	w4, #0
	bl	__RNvNtCs82bWklYMk3w_3std2rt19lang_start_internal
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh14, Lloh15
	.loh AdrpAdd	Lloh12, Lloh13
	.cfi_endproc

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNSNvYNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0INtNtNtCs8Mbv00yxnRz_4core3ops8function6FnOnceuE9call_once6vtableCs62ZXp5Ablwp_29niche_string_layout_preflight
	.quad	__RNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0Cs62ZXp5Ablwp_29niche_string_layout_preflight
	.quad	__RNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0Cs62ZXp5Ablwp_29niche_string_layout_preflight

	.section	__TEXT,__literal8,8byte_literals
	.p2align	3, 0x0
l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.1:
	.asciz	"\020\000\000\000\000\000\000"

	.p2align	3, 0x0
l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.2:
	.asciz	"\b\000\000\000\000\000\000"

	.p2align	3, 0x0
l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.3:
	.asciz	"\007\000\000\000\000\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_anon.65e49aab4a798c6dd5caf9a2dd1841ac.4:
	.asciz	"\017{\"StringOwner\":\300\023,\"owner_alignment\":\300\023,\"metadata_offset\":\300\022,\"metadata_bytes\":\300\035,\"marker_offset_in_metadata\":\300\020,\"CurrentValue\":\300\017,\"PackedValue\":\300\016,\"NicheValue\":\300\030,\"NicheValue_alignment\":\300\002}\n"

.subsections_via_symbols

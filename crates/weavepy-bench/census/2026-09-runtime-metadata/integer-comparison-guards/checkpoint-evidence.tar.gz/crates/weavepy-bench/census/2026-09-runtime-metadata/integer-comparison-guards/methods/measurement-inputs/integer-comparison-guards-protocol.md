# Guard opaque integer comparisons at the comparison instruction

The preceding assertion experiment must finish and its evidence must be
archived before this change is applied. The new analyzer uses its existing
integer_operand_guard and UnboxInt for one opaque operand beside an integral
peer. It guards at COMPARE_OP after producer calls, retaining the original
operands for misses. Two opaque operands and opaque/float pairs stay unchanged.
No call fusion, helper, object field, cache, unsafe code, or execution policy
is added. Frequent misses could regress and must remain in the evidence.

Before applying, require baseline CPython and unchanged ed99 results for the
semantic regression and all 19 focused controls. The test exercises all six
comparisons in both orders, branch truth conversion, integer boundaries, bool,
float and huge integer surprises, subclasses, rich and reflected comparisons,
arbitrary comparison results, callback order and exceptions, loop locals and
exact traceback lines, tracing, and recovery. Native coverage must establish
actual compilation and exit reconstruction for all 19 named functions.

Require JIT and VM tests, formatting, Clippy, no-default-feature check, the
correct release CLI build, 72 targeted release runs, standard compatibility,
and six extra comparison/integer/call/unittest suites with a positive selected
count and all selected modules passing. Preserve baseline failures separately.
GIL-disabled execution is a correctness control; it disables JIT here.

Focused timing uses 15 warm and four first-invocation controls at work 5000,
seven pairs of candidate JIT/interpreter, immediate ed99 JIT/interpreter,
retained 539c JIT/interpreter, and CPython. Four datetime inputs retain the
assertion experiment's exact source bytes. Guard misses include bool, float,
huge integers, four rich-comparison frequencies, and a miss-burst recovery.
All values and frozen-cache checks must pass. The four cold controls include
process CPU but no separate workload CPU timer. Full timing retains the 24
unchanged fixtures at five pairs and nine startup/import cases at 31 pairs.
The full baseline is ed99, isolating this change; startup helper disables JIT.

Each timing run requires three ten-second observations with both one- and
five-minute load averages at most 4, up to 600 seconds. Preserve no-child gate
expirations before any separately declared diagnostic. Keep every sample,
regression, wall/CPU/RSS measurement, VM/swap/load observation, and source,
method, binary, and cache hash. No runtime or active method changes, builds,
tests, profiles, or other owned heavy work while a timing gate can launch.
Keep historical 21-, workload 23-, and process 24-fixture cohorts separate.
Only same-run paired comparisons support attribution. The overall performance
goal remains unachieved. No universal, energy, controlled build-time,
portability, or native parallel performance superiority is established.

"""Restore the existing cold timer entry points without repeating completed cases."""
import ast
import hashlib
import json
from pathlib import Path

root = Path('target/bound-native-entry-inputs')
method = Path('target/prepare_bound_native_entry_inputs.py')
definition = next(node for node in ast.parse(method.read_text()).body
                  if isinstance(node, ast.FunctionDef) and node.name == 'save_group')
namespace = dict(root=root, Path=Path, hashlib=hashlib, json=json)
exec(compile(ast.Module(body=[definition], type_ignores=[]), str(method), 'exec'), namespace)
prior = Path('target/jit-raise-call-spans-inputs/cold-exceptions')
prepared = json.loads((prior / 'preparation.json').read_text())
cases = {}
for name, case in prepared['rows'].items():
    source = Path(case['path'])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == case['source_sha256']
    assert "if __name__ == '__main__':" in source.read_text()
    cases[name] = source.read_text()
namespace['save_group']('cold-exceptions', prepared['work'], cases)
print('Copied all four original cold controls, including their standalone timers.')

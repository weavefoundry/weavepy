	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvMs4_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArcShE14clone_indirectB7_
	.p2align	2
__RNvMs4_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArcShE14clone_indirectB7_:
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception0
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x22, x21, [sp, #16]
	stp	x20, x19, [sp, #32]
	stp	x29, x30, [sp, #48]
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_remember_state
	mov	x19, x8
	ldrb	w8, [x0, #14]
	ldrh	w9, [x0, #12]
	orr	w8, w9, w8, lsl #16
	ldr	w9, [x0, #8]
	orr	x20, x9, x8, lsl #32
	ldr	x8, [x0]
	mov	x9, #72057594037927935
	cmp	x20, x9
	b.ne	LBB0_2
	ldp	x9, x20, [x8]
	add	x8, x9, #16
LBB0_2:
	sub	x21, x8, #16
	mov	w9, #1
	ldadd	x9, x9, [x21]
	tbnz	x9, #63, LBB0_9
	lsr	x9, x20, #56
	cmp	x9, #0
	mov	x9, #72057594037927935
	bic	x9, x9, x20
	ccmp	x9, #0, #4, eq
	b.ne	LBB0_6
	stp	x21, x20, [sp]
	bl	__RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w0, #16
	mov	w1, #8
	bl	__RNvCs1njKG4L9aB3_7___rustc12___rust_alloc
	cbz	x0, LBB0_8
	stp	x21, x20, [x0]
	str	x0, [x19]
	mov	w8, #-1
	str	w8, [x19, #8]
	stur	w8, [x19, #11]
	.cfi_def_cfa wsp, 64
	b	LBB0_7
LBB0_6:
	.cfi_restore_state
	.cfi_remember_state
	str	x8, [x19]
	str	w20, [x19, #8]
	lsr	x8, x20, #48
	strb	w8, [x19, #14]
	lsr	x8, x20, #32
	strh	w8, [x19, #12]
	.cfi_def_cfa wsp, 64
LBB0_7:
	ldp	x29, x30, [sp, #48]
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	ret
LBB0_8:
	.cfi_restore_state
Ltmp0:
	mov	w0, #8
	mov	w1, #16
	bl	__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error
Ltmp1:
LBB0_9:
	brk	#0x1
LBB0_10:
Ltmp2:
	mov	x8, #-1
	ldaddl	x8, x8, [x21]
	cmp	x8, #1
	b.ne	LBB0_12
	dmb	ishld
	mov	x19, x0
	mov	x0, sp
	bl	__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcShE9drop_slowCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen
	mov	x0, x19
LBB0_12:
	bl	__Unwind_Resume
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table0:
Lexception0:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Ltmp0-Lfunc_begin0
	.uleb128 Ltmp1-Ltmp0
	.uleb128 Ltmp2-Lfunc_begin0
	.byte	0
	.uleb128 Ltmp1-Lfunc_begin0
	.uleb128 Lfunc_end0-Ltmp1
	.byte	0
	.byte	0
Lcst_end0:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcShE9drop_slowCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen
	.p2align	2
__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcShE9drop_slowCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen:
	.cfi_startproc
	mov	x8, x0
	ldr	x0, [x0]
	cmn	x0, #1
	b.eq	LBB1_4
	ldr	x8, [x8, #8]
	add	x9, x0, #8
	mov	x10, #-1
	ldaddl	x10, x9, [x9]
	cmp	x9, #1
	b.ne	LBB1_4
	dmb	ishld
	add	x8, x8, #23
	ands	x1, x8, #0xfffffffffffffff8
	b.eq	LBB1_4
	mov	w2, #8
	b	__RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc
LBB1_4:
	ret
	.cfi_endproc

	.globl	__RNvXsj_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core6borrow6BorroweE6borrow
	.p2align	2
__RNvXsj_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core6borrow6BorroweE6borrow:
	.cfi_startproc
	ldrb	w8, [x0, #14]
	ldrh	w9, [x0, #12]
	orr	w8, w9, w8, lsl #16
	ldr	w9, [x0, #8]
	orr	x1, x9, x8, lsl #32
	ldr	x0, [x0]
	mov	x8, #72057594037927935
	cmp	x1, x8
	b.eq	LBB2_2
	ret
LBB2_2:
	ldp	x8, x1, [x0]
	add	x0, x8, #16
	ret
	.cfi_endproc

	.globl	__RNvXso_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core7convert4FromReE4from
	.p2align	2
__RNvXso_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core7convert4FromReE4from:
Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception1
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x20, x1
	mov	x22, x0
	mov	x19, x8
	mov	w0, #1
	bl	__RNvNtCshxvaOLs88l5_5alloc4sync32arcinner_layout_for_value_layout
	mov	x24, x0
	mov	x23, x1
	cbz	x1, LBB3_8
	bl	__RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x23
	mov	x1, x24
	bl	__RNvCs1njKG4L9aB3_7___rustc12___rust_alloc
	mov	x21, x0
	cbz	x0, LBB3_9
LBB3_2:
	mov	w8, #1
	dup.2d	v0, x8
	mov	x23, x21
	str	q0, [x23], #16
	mov	x0, x23
	mov	x1, x22
	mov	x2, x20
	bl	_memcpy
	lsr	x8, x20, #56
	cbnz	x8, LBB3_5
	mov	x8, #72057594037927935
	bics	xzr, x8, x20
	b.eq	LBB3_5
	str	x23, [x19]
	str	w20, [x19, #8]
	lsr	x8, x20, #48
	strb	w8, [x19, #14]
	lsr	x8, x20, #32
	strh	w8, [x19, #12]
	.cfi_def_cfa wsp, 80
	b	LBB3_7
LBB3_5:
	.cfi_restore_state
	.cfi_remember_state
	stp	x21, x20, [sp]
	bl	__RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w0, #16
	mov	w1, #8
	bl	__RNvCs1njKG4L9aB3_7___rustc12___rust_alloc
	cbz	x0, LBB3_10
	stp	x21, x20, [x0]
	str	x0, [x19]
	mov	w8, #-1
	str	w8, [x19, #8]
	stur	w8, [x19, #11]
	.cfi_def_cfa wsp, 80
LBB3_7:
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB3_8:
	.cfi_restore_state
	mov	x21, x24
	cbnz	x24, LBB3_2
LBB3_9:
	mov	x0, x24
	mov	x1, x23
	bl	__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error
LBB3_10:
Ltmp3:
	mov	w0, #8
	mov	w1, #16
	bl	__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error
Ltmp4:
	brk	#0x1
LBB3_12:
Ltmp5:
	mov	x8, #-1
	ldaddl	x8, x8, [x21]
	cmp	x8, #1
	b.ne	LBB3_14
	dmb	ishld
	mov	x19, x0
	mov	x0, sp
	bl	__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcShE9drop_slowCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen
	mov	x0, x19
LBB3_14:
	bl	__Unwind_Resume
Lfunc_end1:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table3:
Lexception1:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end1-Lcst_begin1
Lcst_begin1:
	.uleb128 Lfunc_begin1-Lfunc_begin1
	.uleb128 Ltmp3-Lfunc_begin1
	.byte	0
	.byte	0
	.uleb128 Ltmp3-Lfunc_begin1
	.uleb128 Ltmp4-Ltmp3
	.uleb128 Ltmp5-Lfunc_begin1
	.byte	0
	.uleb128 Ltmp4-Lfunc_begin1
	.uleb128 Lfunc_end1-Ltmp4
	.byte	0
	.byte	0
Lcst_end1:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvXsp_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core7convert4FromNtNtCshxvaOLs88l5_5alloc6string6StringE4from
	.p2align	2
__RNvXsp_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core7convert4FromNtNtCshxvaOLs88l5_5alloc6string6StringE4from:
Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception2
	sub	sp, sp, #96
	.cfi_def_cfa_offset 96
	stp	x26, x25, [sp, #16]
	stp	x24, x23, [sp, #32]
	stp	x22, x21, [sp, #48]
	stp	x20, x19, [sp, #64]
	stp	x29, x30, [sp, #80]
	add	x29, sp, #80
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_remember_state
	mov	x23, x0
	mov	x19, x8
	ldp	x22, x20, [x0, #8]
Ltmp6:
	mov	w0, #1
	mov	x1, x20
	bl	__RNvNtCshxvaOLs88l5_5alloc4sync32arcinner_layout_for_value_layout
Ltmp7:
	mov	x25, x0
	mov	x24, x1
	cbz	x1, LBB4_11
	bl	__RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x24
	mov	x1, x25
	bl	__RNvCs1njKG4L9aB3_7___rustc12___rust_alloc
	mov	x21, x0
	cbz	x0, LBB4_12
LBB4_3:
	mov	w8, #1
	dup.2d	v0, x8
	mov	x24, x21
	str	q0, [x24], #16
	mov	x0, x24
	mov	x1, x22
	mov	x2, x20
	bl	_memcpy
	ldr	x1, [x23]
	cbz	x1, LBB4_5
	mov	x0, x22
	mov	w2, #1
	bl	__RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc
LBB4_5:
	lsr	x8, x20, #56
	cbnz	x8, LBB4_8
	mov	x8, #72057594037927935
	bics	xzr, x8, x20
	b.eq	LBB4_8
	str	x24, [x19]
	str	w20, [x19, #8]
	lsr	x8, x20, #48
	strb	w8, [x19, #14]
	lsr	x8, x20, #32
	strh	w8, [x19, #12]
	.cfi_def_cfa wsp, 96
	b	LBB4_10
LBB4_8:
	.cfi_restore_state
	.cfi_remember_state
	stp	x21, x20, [sp]
	bl	__RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w0, #16
	mov	w1, #8
	bl	__RNvCs1njKG4L9aB3_7___rustc12___rust_alloc
	cbz	x0, LBB4_13
	stp	x21, x20, [x0]
	str	x0, [x19]
	mov	w8, #-1
	str	w8, [x19, #8]
	stur	w8, [x19, #11]
	.cfi_def_cfa wsp, 96
LBB4_10:
	ldp	x29, x30, [sp, #80]
	ldp	x20, x19, [sp, #64]
	ldp	x22, x21, [sp, #48]
	ldp	x24, x23, [sp, #32]
	ldp	x26, x25, [sp, #16]
	add	sp, sp, #96
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	ret
LBB4_11:
	.cfi_restore_state
	mov	x21, x25
	cbnz	x25, LBB4_3
LBB4_12:
Ltmp11:
	mov	x0, x25
	mov	x1, x24
	bl	__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error
Ltmp12:
	b	LBB4_14
LBB4_13:
Ltmp8:
	mov	w0, #8
	mov	w1, #16
	bl	__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error
Ltmp9:
LBB4_14:
	brk	#0x1
LBB4_15:
Ltmp10:
	mov	x8, #-1
	ldaddl	x8, x8, [x21]
	cmp	x8, #1
	b.ne	LBB4_20
	dmb	ishld
	mov	x19, x0
	mov	x0, sp
	bl	__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcShE9drop_slowCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen
	b	LBB4_19
LBB4_17:
Ltmp13:
	ldr	x1, [x23]
	cbz	x1, LBB4_20
	mov	x19, x0
	mov	x0, x22
	mov	w2, #1
	bl	__RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc
LBB4_19:
	mov	x0, x19
LBB4_20:
	bl	__Unwind_Resume
Lfunc_end2:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table4:
Lexception2:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end2-Lcst_begin2
Lcst_begin2:
	.uleb128 Ltmp6-Lfunc_begin2
	.uleb128 Ltmp7-Ltmp6
	.uleb128 Ltmp13-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp7-Lfunc_begin2
	.uleb128 Ltmp11-Ltmp7
	.byte	0
	.byte	0
	.uleb128 Ltmp11-Lfunc_begin2
	.uleb128 Ltmp12-Ltmp11
	.uleb128 Ltmp13-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp8-Lfunc_begin2
	.uleb128 Ltmp9-Ltmp8
	.uleb128 Ltmp10-Lfunc_begin2
	.byte	0
	.uleb128 Ltmp9-Lfunc_begin2
	.uleb128 Lfunc_end2-Ltmp9
	.byte	0
	.byte	0
Lcst_end2:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvXsq_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core7convert4FromRNtNtCshxvaOLs88l5_5alloc6string6StringE4from
	.p2align	2
__RNvXsq_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core7convert4FromRNtNtCshxvaOLs88l5_5alloc6string6StringE4from:
	.cfi_startproc
	ldp	x9, x1, [x0, #8]
	mov	x0, x9
	b	__RNvXso_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core7convert4FromReE4from
	.cfi_endproc

	.globl	__RNvXsr_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core7convert4FromINtNtCshxvaOLs88l5_5alloc5boxed3BoxeEE4from
	.p2align	2
__RNvXsr_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceEINtNtCs8Mbv00yxnRz_4core7convert4FromINtNtCshxvaOLs88l5_5alloc5boxed3BoxeEE4from:
Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, _rust_eh_personality
	.cfi_lsda 16, Lexception3
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x24, x23, [sp, #16]
	stp	x22, x21, [sp, #32]
	stp	x20, x19, [sp, #48]
	stp	x29, x30, [sp, #64]
	add	x29, sp, #64
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_remember_state
	mov	x19, x1
	mov	x22, x0
	mov	x20, x8
Ltmp14:
	mov	w0, #1
	bl	__RNvNtCshxvaOLs88l5_5alloc4sync32arcinner_layout_for_value_layout
Ltmp15:
	mov	x24, x0
	mov	x23, x1
	cbz	x1, LBB6_11
	bl	__RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	x0, x23
	mov	x1, x24
	bl	__RNvCs1njKG4L9aB3_7___rustc12___rust_alloc
	mov	x21, x0
	cbz	x0, LBB6_12
LBB6_3:
	mov	w8, #1
	dup.2d	v0, x8
	mov	x23, x21
	str	q0, [x23], #16
	mov	x0, x23
	mov	x1, x22
	mov	x2, x19
	bl	_memcpy
	cbz	x19, LBB6_5
	mov	x0, x22
	mov	x1, x19
	mov	w2, #1
	bl	__RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc
LBB6_5:
	lsr	x8, x19, #56
	cbnz	x8, LBB6_8
	mov	x8, #72057594037927935
	bics	xzr, x8, x19
	b.eq	LBB6_8
	str	x23, [x20]
	str	w19, [x20, #8]
	lsr	x8, x19, #48
	strb	w8, [x20, #14]
	lsr	x8, x19, #32
	strh	w8, [x20, #12]
	.cfi_def_cfa wsp, 80
	b	LBB6_10
LBB6_8:
	.cfi_restore_state
	.cfi_remember_state
	stp	x21, x19, [sp]
	bl	__RNvCs1njKG4L9aB3_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w0, #16
	mov	w1, #8
	bl	__RNvCs1njKG4L9aB3_7___rustc12___rust_alloc
	cbz	x0, LBB6_13
	stp	x21, x19, [x0]
	str	x0, [x20]
	mov	w8, #-1
	str	w8, [x20, #8]
	stur	w8, [x20, #11]
	.cfi_def_cfa wsp, 80
LBB6_10:
	ldp	x29, x30, [sp, #64]
	ldp	x20, x19, [sp, #48]
	ldp	x22, x21, [sp, #32]
	ldp	x24, x23, [sp, #16]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	ret
LBB6_11:
	.cfi_restore_state
	mov	x21, x24
	cbnz	x24, LBB6_3
LBB6_12:
Ltmp19:
	mov	x0, x24
	mov	x1, x23
	bl	__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error
Ltmp20:
	b	LBB6_14
LBB6_13:
Ltmp16:
	mov	w0, #8
	mov	w1, #16
	bl	__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error
Ltmp17:
LBB6_14:
	brk	#0x1
LBB6_15:
Ltmp18:
	mov	x8, #-1
	ldaddl	x8, x8, [x21]
	cmp	x8, #1
	b.ne	LBB6_18
	dmb	ishld
	mov	x19, x0
	mov	x0, sp
	bl	__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcShE9drop_slowCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen
	mov	x0, x19
	bl	__Unwind_Resume
LBB6_17:
Ltmp21:
	cbnz	x19, LBB6_19
LBB6_18:
	bl	__Unwind_Resume
LBB6_19:
	mov	x20, x0
	mov	x0, x22
	mov	x1, x19
	mov	w2, #1
	bl	__RNvCs1njKG4L9aB3_7___rustc14___rust_dealloc
	mov	x0, x20
	bl	__Unwind_Resume
Lfunc_end3:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table6:
Lexception3:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 Lcst_end3-Lcst_begin3
Lcst_begin3:
	.uleb128 Ltmp14-Lfunc_begin3
	.uleb128 Ltmp15-Ltmp14
	.uleb128 Ltmp21-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp15-Lfunc_begin3
	.uleb128 Ltmp19-Ltmp15
	.byte	0
	.byte	0
	.uleb128 Ltmp19-Lfunc_begin3
	.uleb128 Ltmp20-Ltmp19
	.uleb128 Ltmp21-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp16-Lfunc_begin3
	.uleb128 Ltmp17-Ltmp16
	.uleb128 Ltmp18-Lfunc_begin3
	.byte	0
	.uleb128 Ltmp17-Lfunc_begin3
	.uleb128 Lfunc_end3-Ltmp17
	.byte	0
	.byte	0
Lcst_end3:
	.p2align	2, 0x0

	.section	__TEXT,__text,regular,pure_instructions
	.globl	__RNvXss_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceENtNtCs8Mbv00yxnRz_4core3fmt7Display3fmt
	.p2align	2
__RNvXss_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceENtNtCs8Mbv00yxnRz_4core3fmt7Display3fmt:
	.cfi_startproc
	mov	x2, x1
	ldrb	w8, [x0, #14]
	ldrh	w9, [x0, #12]
	orr	w8, w9, w8, lsl #16
	ldr	w9, [x0, #8]
	orr	x1, x9, x8, lsl #32
	ldr	x0, [x0]
	mov	x8, #72057594037927935
	cmp	x1, x8
	b.eq	LBB7_2
	b	__RNvXsi_NtCs8Mbv00yxnRz_4core3fmteNtB5_7Display3fmt
LBB7_2:
	ldp	x8, x1, [x0]
	add	x0, x8, #16
	b	__RNvXsi_NtCs8Mbv00yxnRz_4core3fmteNtB5_7Display3fmt
	.cfi_endproc

	.globl	_clone_shared_bytes
	.p2align	2
_clone_shared_bytes:
	.cfi_startproc
	mov	x9, x0
	ldr	w10, [x9, #8]!
	ldrb	w11, [x9, #6]
	ldrh	w12, [x9, #4]
	orr	w11, w12, w11, lsl #16
	orr	x10, x10, x11, lsl #32
	mov	x11, #72057594037927935
	cmp	x10, x11
	b.eq	LBB8_3
	ldr	x10, [x0]
	sub	x11, x10, #16
	mov	w12, #1
	ldadd	x12, x11, [x11]
	tbnz	x11, #63, LBB8_4
	ldr	w11, [x9]
	str	w11, [x8, #8]
	ldur	w9, [x9, #3]
	stur	w9, [x8, #11]
	str	x10, [x8]
	ret
LBB8_3:
	b	__RNvMs4_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArcShE14clone_indirectB7_
LBB8_4:
	brk	#0x1
	.cfi_endproc

	.globl	__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArceE9drop_slowCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen
__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArceE9drop_slowCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen = __RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcShE9drop_slowCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen
	.globl	__RNvMs4_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceE14clone_indirectB7_
__RNvMs4_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArceE14clone_indirectB7_ = __RNvMs4_NtCsaaQN9VRpplU_34compact_arc_clone_after_v2_codegen5ownerINtB5_10CompactArcShE14clone_indirectB7_
	.globl	_clone_shared_string
_clone_shared_string = _clone_shared_bytes
.subsections_via_symbols

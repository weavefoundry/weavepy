//! The runtime object model.
//!
//! Every Python value at runtime is an [`Object`]. The enum is a
//! tagged union over the immortal singletons (None, bool, small int)
//! and `Rc<…>` handles for the rest. Cloning an [`Object`] copies
//! the small inline payload or bumps an `Rc`; it never deep-copies.
//!
//! This is a placeholder representation. Identity (`is`) is computed
//! by [`Object::is_same`] using `Rc::ptr_eq` for the heap variants
//! and value equality for the value-type variants. RFC 0002 will
//! replace this with a proper type-slot-based object model.

pub use crate::tuple_storage::{SharedTuple, TupleStorage};

use crate::shared_value::{SharedSlice, SharedStr, ThinArc};
use crate::sync::Rc;
use crate::sync::Weak;
use crate::sync::{Cell, RefCell};
use std::cmp::Ordering;
use std::fmt;
use std::hash::{Hash, Hasher};
use std::io::{Read, Write};

use num_bigint::BigInt;
use num_traits::{Signed, ToPrimitive, Zero};
use weavepy_compiler::CodeObject;

use crate::error::{os_error, runtime_error, type_error, value_error, RuntimeError};
use crate::types::{PyInstance, TypeObject};

/// RFC 0025 compile-time gate: every `Object` variant — and therefore
/// the heap closure can cross OS thread boundaries via
/// `_thread.start_new_thread`. The proof is that the Rust compiler
/// successfully derives `Object: Send + Sync` from this assertion;
/// if any future variant introduces a non-`Send` payload (a raw
/// pointer, a `Box<dyn Fn>` without the bounds, a `std::cell::Cell`,
/// etc.), this assertion fails to compile.
const _: () = {
    const fn assert_send<T: Send>() {}
    const fn assert_sync<T: Sync>() {}
    assert_send::<Object>();
    assert_sync::<Object>();
};

/// Number of slots in the per-thread code-point-length cache.
const STR_LEN_CACHE_CAP: usize = 1024;

thread_local! {
    /// Direct-mapped cache of `SharedStr` heap identity -> code-point length.
    ///
    /// WeavePy stores `str` as UTF-8, so counting code points — needed by
    /// `len(s)`, index/slice bounds, and `re` span clamping — is O(n).
    /// Scanners and tokenisers touch the *same* large string repeatedly, so
    /// without memoisation an otherwise-linear pass degrades to O(n^2) (the
    /// cause of `test_json`'s deep-recursion cases hanging). Each slot holds
    /// the source `Rc` so a freed allocation cannot be reused at the same
    /// address and alias a stale length; collisions simply recompute and
    /// overwrite, so the cache is always correct and bounded to CAP entries.
    static STR_LEN_CACHE: std::cell::RefCell<Vec<Option<(usize, SharedStr, usize)>>> =
        std::cell::RefCell::new(vec![None; STR_LEN_CACHE_CAP]);
}

/// Code-point length of a UTF-8 `str`, memoised by heap identity. O(1) on a
/// cache hit; O(n) (and caches the result) on a miss. Strings of 0 or 1
/// bytes are counted directly — they are necessarily 0 or 1 code points, so
/// caching them would only evict useful entries.
pub(crate) fn str_char_len(s: &SharedStr) -> usize {
    let bytes = s.len();
    if bytes <= 1 {
        return bytes;
    }
    let ptr = SharedStr::as_ptr(s).cast::<u8>() as usize;
    let slot = (ptr / 8) % STR_LEN_CACHE_CAP;
    STR_LEN_CACHE.with(|c| {
        let mut cache = c.borrow_mut();
        if let Some((p, _, n)) = &cache[slot] {
            if *p == ptr {
                return *n;
            }
        }
        let n = s.chars().count();
        cache[slot] = Some((ptr, s.clone(), n));
        n
    })
}

/// A Python value as seen by the interpreter.
#[derive(Clone)]
pub enum Object {
    None,
    /// The "no value" marker for local-variable slots — CPython's NULL
    /// fast-local. Never a Python-visible value: `LOAD_FAST` raises
    /// `UnboundLocalError` on it, and the `f_locals` provider skips it
    /// (which is what lets a local explicitly bound to `None` remain
    /// visible — the two states must be distinguishable).
    Unbound,
    Bool(bool),
    Int(i64),
    /// Arbitrary-precision integer (RFC 0019). Created on i64 overflow,
    /// large literals, or explicit `int.from_bytes(...)` /
    /// `int(...)` parsing of large strings. `Object::int_from_bigint`
    /// auto-demotes to `Int(i64)` when the value fits.
    Long(Rc<BigInt>),
    Float(f64),
    /// Complex number with rectangular components (RFC 0019).
    Complex(Rc<PyComplex>),
    Str(SharedStr),
    /// A `str` containing at least one lone surrogate (U+D800..U+DFFF), which
    /// Rust's `str`/UTF-8 cannot represent. Stored as a sequence of code
    /// points — each a Unicode scalar value *or* a lone surrogate. Produced by
    /// `chr(surrogate)`, `'\udxxx'` escapes, and `surrogateescape`/
    /// `surrogatepass` decoding; consumed by the surrogate-aware encoders,
    /// `os.fsencode`, and `repr`. The invariant ">= 1 lone surrogate" keeps it
    /// disjoint from [`Object::Str`]: the two never compare equal, and any
    /// operation whose result is pure UTF-8 canonicalises back to `Str` (see
    /// [`Object::str_from_codepoints`]). This is WeavePy's WTF-8 string arc
    /// (RFC 0040) — CPython stores lone surrogates natively, so PEP 383
    /// `surrogateescape` filenames, `surrogatepass`, and `chr(0xD800)` all
    /// round-trip.
    WStr(SharedSlice<u32>),
    Tuple(crate::object::SharedTuple),
    List(Rc<RefCell<Vec<Object>>>),
    Dict(Rc<RefCell<DictData>>),
    Range(Rc<Range>),
    Function(Rc<PyFunction>),
    Builtin(Rc<BuiltinFn>),
    BoundMethod(Rc<BoundMethod>),
    Code(Rc<CodeObject>),
    Cell(Rc<RefCell<Object>>),
    Iter(Rc<RefCell<PyIterator>>),
    Slice(Rc<PySlice>),
    Type(Rc<TypeObject>),
    Instance(Rc<PyInstance>),
    /// A loaded module (`Object::Module(Rc<PyModule>)`). Attribute
    /// access goes through `module.dict`. Introduced in RFC 0012.
    Module(Rc<PyModule>),
    /// A live generator object (RFC 0006). Holds a suspended frame
    /// shared via `Rc<RefCell<…>>` so it can be resumed by `next()`,
    /// `.send(v)`, `.throw(e)`, and `.close()`.
    Generator(Rc<PyGenerator>),
    /// A live coroutine object (PEP 492, RFC 0016) — the value
    /// returned from calling an `async def`. Reuses [`PyGenerator`]'s
    /// suspended-frame machinery; the variant tag distinguishes it
    /// for the awaitable protocol and `isinstance` checks.
    Coroutine(Rc<PyGenerator>),
    /// A live async-generator object (PEP 525, RFC 0016) — the value
    /// returned from calling an `async def` that contains `yield`.
    /// Consumable via `async for`.
    AsyncGenerator(Rc<PyGenerator>),
    /// Deferred awaitable produced by `agen.asend()` / `.athrow()` /
    /// `.aclose()` (PEP 525). Awaiting it applies the operation to the
    /// underlying async generator. See [`AsyncGenAwait`].
    AsyncGenAwait(Rc<AsyncGenAwait>),
    /// Immutable byte string `b"..."`.
    Bytes(SharedSlice<u8>),
    /// Mutable byte string `bytearray(...)`.
    ByteArray(Rc<RefCell<Vec<u8>>>),
    /// Mutable set `{1, 2, 3}` / `set(...)`. Backed by an
    /// `IndexSet<DictKey>` so iteration order is insertion order
    /// (CPython 3.7+ semantics).
    Set(Rc<RefCell<SetData>>),
    /// Immutable set `frozenset(...)`. Wrapped in [`FrozenSetObj`] so the
    /// CPython `so_hash` cache (frozensets are immutable, so their hash is
    /// computed once) rides along with the element storage.
    FrozenSet(Rc<FrozenSetObj>),
    /// File-like object — opened by `open()`, returned by
    /// `io.StringIO`/`io.BytesIO`, and the values behind
    /// `sys.stdin`/`stdout`/`stderr`.
    File(Rc<PyFile>),
    /// `@property` descriptor (RFC 0015). Resolves through the
    /// data-descriptor path on attribute access.
    Property(Rc<PyProperty>),
    /// `@staticmethod` descriptor (RFC 0015). Returns the wrapped
    /// callable unchanged when accessed via instance or class.
    StaticMethod(Rc<MethodWrapper>),
    /// `@classmethod` descriptor (RFC 0015). Returns a method bound
    /// to the class (not the instance) on access.
    ClassMethod(Rc<MethodWrapper>),
    /// Slot descriptor created by `__slots__` (RFC 0015). Stores a
    /// per-instance value under the slot's name in `__dict__`,
    /// enforcing the slot-list at the class level.
    SlotDescriptor(Rc<SlotDescriptor>),
    /// Python-visible frame object (RFC 0018). Created on demand by
    /// `sys._getframe`, the `traceback` module, and the unwind
    /// machinery. Holds the locals snapshot, globals reference, and
    /// the chain of outer frames.
    Frame(Rc<PyFrame>),
    /// Python-visible traceback object (RFC 0018). Built as
    /// exceptions propagate so user code can walk `tb_next` /
    /// `tb_frame` / `tb_lineno` like CPython.
    Traceback(Rc<PyTraceback>),
    /// Memory view over a bytes-like object (RFC 0023). Supports the
    /// buffer protocol minimum: indexing, slicing, `len`, `cast`,
    /// `tobytes`, `tolist`, `release`, `nbytes`, `format`, `itemsize`,
    /// `ndim`, `shape`, `strides`, `readonly`, `c_contiguous`,
    /// `f_contiguous`, `contiguous`.
    MemoryView(Rc<PyMemoryView>),
    /// A read-only mapping view (RFC 0023). Used by `cls.__dict__`,
    /// `module.__dict__` reads through `vars()`, and dataclass
    /// `__match_args__` exposure. Backed by a shared `DictData`
    /// reference; mutations through this view raise `TypeError`.
    MappingProxy(Rc<RefCell<DictData>>),
    /// An *object-backed* `mappingproxy` (RFC 0068 WS5). CPython's
    /// `types.MappingProxyType(mapping)` accepts any mapping object and
    /// delegates every operation to it — overridden methods on a dict
    /// subclass (`__missing__`, custom `keys`, …) show through the view
    /// (test_types.MappingProxyTests). Plain-`dict` proxies stay on the
    /// [`Object::MappingProxy`] fast path; this variant carries the
    /// wrapped mapping for everything else, and all protocol dispatch
    /// routes through the interpreter.
    MappingProxyObj(Rc<Object>),
    /// A view over `dict.keys() / .values() / .items()` (RFC 0023).
    /// Keeps a reference to the source dict so the view stays live
    /// across mutations, matching CPython's dict view semantics.
    DictView(Rc<PyDictView>),
    /// `types.SimpleNamespace` instance (RFC 0023). Used by
    /// `sys.implementation`, `argparse.Namespace`-shaped fixtures, and
    /// the conformance harness.
    SimpleNamespace(Rc<RefCell<DictData>>),
    /// Native lazy iterator adapter (RFC 0037) — an `itertools` object
    /// CPython implements in C. Wraps an arbitrary VM iterable, so it
    /// is stepped by the *interpreter* (`Interpreter::iter_next`),
    /// never by `PyIterator::next_value`: advancing the source may
    /// resume a generator or call a user-defined `__next__`. Being
    /// native matters beyond speed — stepping adds no Python frame,
    /// which `traceback.walk_stack`'s hardcoded `f_back` hop count
    /// relies on.
    LazyIter(Rc<PyLazyIter>),
    /// A C-API `PyCapsule` (RFC 0029 / RFC 0045, wave 3).
    ///
    /// A capsule is a *cpyext* concept — pure-Python code never mints one —
    /// but it routinely lives in a place the VM owns: a module dict
    /// (`module._API`, the numpy `import_array()` idiom) or an attribute
    /// (`obj.__array_struct__`). The VM therefore must hold *some* value
    /// for it. This is that value: an opaque, identity-stable token whose
    /// payload the VM never interprets. The binary-ABI layer
    /// (`weavepy-capi`) owns the capsule's C storage and registers a free
    /// callback (via [`register_capsule_free`]) that runs when the last
    /// reference here drops. See [`PyCapsuleSoul`].
    Capsule(Rc<PyCapsuleSoul>),
    /// A "foreign" `PyObject` minted by a C extension itself (a numpy
    /// builtin function, a static `PyArray_Descr`, a module-defined type
    /// object, …) rather than by WeavePy's binary-ABI allocator. The VM
    /// holds it as an opaque, identity-stable proxy and routes every
    /// operation back through the cpyext bridge (RFC 0046, wave 4). See
    /// [`crate::foreign::PyForeignSoul`].
    Foreign(Rc<crate::foreign::PyForeignSoul>),
}

/// VM-side soul of a C-API `PyCapsule` (see [`Object::Capsule`]).
///
/// The capsule's real state (the wrapped `void*`, its name, context, and
/// destructor) lives in `weavepy-capi`'s heap-allocated capsule box. This
/// struct is only the VM's *handle* onto it, so a capsule can round-trip
/// `C -> VM (module dict / attribute) -> C` as the **same** pointer: the
/// cpyext layer retains the box while a soul is alive and hands the very
/// same pointer back out on each crossing.
///
/// `handle` is stored as a `usize` (not a pointer) on purpose: it keeps
/// `Object: Send + Sync` (the compile-time assertion above), matching the
/// faithful-instance-body hook. The VM never dereferences it.
#[derive(Debug)]
pub struct PyCapsuleSoul {
    /// Capsule name (e.g. `"_stockarray._ARRAY_API"`), used only for
    /// `repr`. A capsule may be unnamed, hence `Option`.
    pub name: Option<SharedStr>,
    /// Opaque handle owned by the cpyext layer (the retained capsule
    /// `PyObject*`, as an integer). Never dereferenced by the VM.
    pub handle: usize,
}

impl Drop for PyCapsuleSoul {
    fn drop(&mut self) {
        if let Some(free) = CAPSULE_FREE.get() {
            free(self.handle);
        }
    }
}

/// Free hook for a capsule's cpyext-side storage, registered by
/// `weavepy-capi` during interpreter init (the same additive-hook pattern
/// as [`crate::types::register_instance_body_free`]). Inert in a pure-VM
/// build, where no capsule is ever created.
static CAPSULE_FREE: std::sync::OnceLock<fn(usize)> = std::sync::OnceLock::new();

/// Register the capsule free hook (RFC 0045, wave 3). Idempotent — a
/// second registration is ignored.
pub fn register_capsule_free(f: fn(usize)) {
    let _ = CAPSULE_FREE.set(f);
}

impl fmt::Debug for Object {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Object::None => write!(f, "None"),
            Object::Unbound => write!(f, "<unbound>"),
            Object::Bool(b) => write!(f, "{}", if *b { "True" } else { "False" }),
            Object::Int(i) => write!(f, "{i}"),
            Object::Long(b) => write!(f, "{b}"),
            Object::Complex(c) => write!(f, "complex({}, {})", c.real, c.imag),
            Object::Float(x) => write!(f, "{x}"),
            Object::Str(s) => write!(f, "{s:?}"),
            Object::WStr(cps) => write!(f, "WStr({} code points)", cps.len()),
            Object::Tuple(items) => f.debug_list().entries(items.iter()).finish(),
            Object::List(items) => f.debug_list().entries(items.borrow().iter()).finish(),
            Object::Dict(d) => {
                let d = d.borrow();
                let mut m = f.debug_map();
                for (k, v) in d.iter() {
                    m.entry(&k.0, v);
                }
                m.finish()
            }
            Object::Range(r) => write!(f, "range({}, {}, {})", r.start, r.stop, r.step),
            Object::Function(func) => write!(f, "<function {}>", func.name),
            Object::Builtin(b) => write!(f, "<built-in function {}>", b.name),
            Object::BoundMethod(bm) => write!(f, "<bound method {:?}>", bm.function),
            Object::Code(c) => write!(f, "<code object {}>", c.name),
            Object::Cell(c) => f.debug_tuple("Cell").field(&c.borrow()).finish(),
            Object::Iter(_) => write!(f, "<iterator>"),
            Object::Slice(s) => write!(f, "slice({:?}, {:?}, {:?})", s.start, s.stop, s.step),
            Object::Type(t) => write!(f, "<class '{}'>", t.name),
            Object::Instance(i) => write!(f, "<{} object>", i.cls().name),
            Object::Module(m) => write!(f, "<module {:?}>", m.name),
            Object::Generator(g) => write!(f, "<generator object {}>", g.name.borrow().to_str()),
            Object::Coroutine(g) => write!(f, "<coroutine object {}>", g.name.borrow().to_str()),
            Object::AsyncGenerator(g) => {
                write!(f, "<async_generator object {}>", g.name.borrow().to_str())
            }
            Object::AsyncGenAwait(a) => write!(f, "<{} object>", a.kind.type_name()),
            Object::Bytes(b) => write!(f, "Bytes({})", b.len()),
            Object::ByteArray(b) => write!(f, "ByteArray({})", b.borrow().len()),
            Object::Set(s) => f.debug_set().entries(s.borrow().iter()).finish(),
            Object::FrozenSet(s) => f.debug_set().entries(s.iter()).finish(),
            Object::File(file) => write!(f, "<file {:?}>", file.name),
            Object::Property(_) => write!(f, "<property>"),
            Object::StaticMethod(inner) => write!(f, "<staticmethod {:?}>", inner.func()),
            Object::ClassMethod(inner) => write!(f, "<classmethod {:?}>", inner.func()),
            Object::SlotDescriptor(sd) => write!(f, "<slot {:?} of {:?}>", sd.name, sd.class_name),
            Object::Frame(fr) => write!(f, "<frame at 0x{:x}>", Rc::as_ptr(fr) as usize),
            Object::Traceback(tb) => {
                write!(f, "<traceback object at 0x{:x}>", Rc::as_ptr(tb) as usize)
            }
            Object::MemoryView(mv) => {
                let state = if mv.released.get() {
                    "released memory"
                } else {
                    "memory"
                };
                write!(f, "<{state} at 0x{:x}>", Rc::as_ptr(mv) as usize)
            }
            Object::MappingProxy(d) => {
                let d = d.borrow();
                let mut m = f.debug_map();
                for (k, v) in d.iter() {
                    m.entry(&k.0, v);
                }
                m.finish()
            }
            Object::MappingProxyObj(inner) => {
                write!(f, "mappingproxy({:?})", inner.as_ref())
            }
            Object::DictView(v) => write!(f, "<{} {:?}>", v.kind.type_name(), v),
            Object::SimpleNamespace(d) => {
                let d = d.borrow();
                let mut m = f.debug_struct("namespace");
                for (k, v) in d.iter() {
                    m.field(&k.0.to_str(), v);
                }
                m.finish()
            }
            Object::LazyIter(l) => write!(f, "<{} object>", l.type_name()),
            Object::Capsule(c) => match &c.name {
                Some(n) => write!(f, "<capsule object \"{n}\" at 0x{:x}>", c.handle),
                None => write!(f, "<capsule object NULL at 0x{:x}>", c.handle),
            },
            Object::Foreign(s) => write!(f, "<foreign {} at 0x{:x}>", s.type_name, s.ptr),
        }
    }
}

/// Internal payload for [`Object::Frame`]. Captures the live state
/// of a frame at the point the snapshot is materialised — the VM
/// updates [`PyFrame::lasti`] before any opcode that may inspect
/// frames so `frame.f_lineno` reads correctly.
pub struct PyFrame {
    pub code: Rc<CodeObject>,
    pub globals: Rc<RefCell<DictData>>,
    pub builtins: Rc<RefCell<DictData>>,
    /// Index of the current instruction inside [`Self::code`]. Updated
    /// per-instruction by the dispatch loop while this frame is the
    /// active one.
    pub lasti: Cell<u32>,
    /// The enclosing frame (the next-outer in the call stack), `None`
    /// for the module frame.
    pub back: RefCell<Option<Rc<PyFrame>>>,
    /// Lazy snapshot of the locals dict. Built on first access to
    /// `frame.f_locals`. Subsequent accesses see the cached dict;
    /// CPython does the same. The cached dict is *not* a live view —
    /// writes to it don't propagate back to the frame's `locals`
    /// array.
    pub locals_cache: RefCell<Option<Object>>,
    /// Cell storage shared with the executing frame (cellvars first,
    /// then freevars) — read by [`Self::compute_locals`] so
    /// `f_locals` honours cell variables. RFC 0058 replaced the
    /// per-call provider *closure* with these plain fields: the
    /// closure was a separate allocation capturing seven `Rc` clones
    /// on every Python call.
    pub cells: Rc<Vec<Rc<RefCell<Object>>>>,
    /// Class-body namespace (see `Frame::class_namespace`): when set,
    /// `f_locals` is this dict rather than a fast-locals snapshot.
    pub class_namespace: Option<Rc<RefCell<DictData>>>,
    /// PEP 3115 custom class-body mapping; takes precedence over
    /// [`Self::class_namespace`] for `f_locals`.
    pub class_namespace_obj: Option<Object>,
    /// Module/exec scope: `f_locals is f_globals`.
    pub is_module_scope: bool,
    /// Shared, mutable mirror of the running frame's `locals` array.
    /// The VM updates this between steps so `f_locals` reflects live
    /// state. `None` once the frame has returned.
    pub locals_mirror: RefCell<Option<Rc<RefCell<Vec<Object>>>>>,
    /// Per-frame trace function. Returned by `sys.settrace`'s hook
    /// (or by a previous per-frame trace), this callable receives
    /// subsequent `'line'` / `'return'` / `'exception'` events on
    /// the frame. `Object::None` disables tracing for the frame.
    pub trace: RefCell<Object>,
    /// Backlink to the generator/coroutine that owns this frame
    /// (weak — the frame must not keep its generator alive). Set by
    /// the VM when the snapshot is cached on a generator frame; lets
    /// `frame.clear()` tear down the suspended generator like
    /// CPython's `frame_clear`.
    pub gen_owner: RefCell<Option<crate::sync::Weak<PyGenerator>>>,
    /// Per-frame `f_lineno` override. Set alongside a validated
    /// [`Self::pending_jump`] so reads report the jump target until
    /// the dispatch loop applies it (RFC 0050); cleared on apply.
    pub override_lineno: crate::sync::RefCell<Option<u32>>,
    /// The trace event this frame is currently dispatching. CPython's
    /// `frame_setlineno` gates `f_lineno` assignment on the event kind
    /// (`'line'` and yield events allow jumps; `'call'`/`'return'`/
    /// `'exception'`/`'opcode'` refuse). Set/cleared by the
    /// `fire_*_event` dispatchers (RFC 0050).
    pub trace_event: Cell<crate::linejump::TraceEvent>,
    /// A validated pending line-jump: the `f_lineno` setter runs the
    /// legality analysis (`linejump::compute_jump`) and parks the plan
    /// here; the dispatch loop applies it to the live frame right
    /// after the trace callback returns (RFC 0050).
    pub pending_jump: crate::sync::RefCell<Option<crate::linejump::PendingJump>>,
    /// Most recently observed source line on this frame, used by
    /// the dispatcher to know when to fire a `'line'` event. `None`
    /// means "no line event has fired on this frame yet" — the
    /// next `step` will fire one.
    pub last_line: crate::sync::RefCell<Option<u32>>,
    /// Mirrors CPython's `frame.f_trace_lines`. When `true` (the
    /// default) the dispatcher fires `'line'` events; debuggers set it
    /// `false` to suppress them.
    pub trace_lines: Cell<bool>,
    /// Mirrors CPython's `frame.f_trace_opcodes`. When `true` the
    /// dispatcher fires an `'opcode'` event before every instruction
    /// (used by `bdb`/`pdb` instruction stepping). Defaults to `false`.
    pub trace_opcodes: Cell<bool>,
    /// Count of live activations of this frame across *all*
    /// interpreter call stacks. Incremented on push, decremented on
    /// pop. `frame.clear()` consults it so a frame executing on a
    /// different OS thread (its `Rc` handed across via a traceback,
    /// `sys._current_frames()`, …) is refused like CPython's
    /// "cannot clear an executing frame" — the caller's own
    /// `frame_stack` can't see other threads' activations.
    pub on_stack: Cell<u32>,
    /// PEP 667 `f_extra_locals`: keys stored *through* the
    /// `FrameLocalsProxy` that don't name a fast local (including
    /// non-string keys). Created lazily on first such store —
    /// `test_frame.test_delete` distinguishes "before f_extra_locals
    /// is created". RFC 0060.
    pub extra_locals: RefCell<Option<Rc<RefCell<DictData>>>>,
    /// Set by `frame.clear()`: the frame's references are gone, so
    /// `f_locals` must present an empty mapping even though the cell
    /// vector (shared with closures) still holds values. Mirrors
    /// CPython clearing the cell slots out of `f_localsplus` while
    /// the cell objects live on in the closures that captured them.
    pub cleared: Cell<bool>,
}

impl fmt::Debug for PyFrame {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "<frame code={:?} lineno={}>",
            self.code.name,
            self.current_lineno()
        )
    }
}

impl Drop for PyFrame {
    fn drop(&mut self) {
        // Iteratively tear down the `back` chain. A plain recursive drop
        // would drop this frame's `back` Arc, whose own drop drops the
        // *next* frame's `back`, and so on — one native stack frame per
        // link. A deep traceback that pins the whole call chain (e.g. a
        // `RecursionError` raised ~1000 frames down) then overflows the
        // native stack and `abort()`s the process the moment the
        // exception is finally released. Walking the list here keeps
        // teardown O(depth) in heap but O(1) in native stack: each frame
        // we unwrap has its own `back` detached *before* it falls out of
        // scope, so its Drop sees an empty chain and never recurses.
        let mut link = self.back.borrow_mut().take();
        while let Some(frame) = link {
            match Rc::try_unwrap(frame) {
                Ok(inner) => link = inner.back.borrow_mut().take(),
                // Still referenced elsewhere (an alive generator frame, a
                // retained `f_back`): that owner keeps the tail alive.
                Err(_) => break,
            }
        }
    }
}

impl PyFrame {
    pub fn current_lineno(&self) -> u32 {
        if let Some(v) = self.override_lineno.get() {
            return v;
        }
        let pc = self.lasti.get() as usize;
        self.code.linetable.get(pc).copied().unwrap_or(0)
    }

    /// Compute a fresh locals mapping from the live frame state —
    /// the class/module namespace itself for those scopes, or a
    /// fast-locals snapshot dict for function scopes. This replaces
    /// the RFC 0047 per-call provider closure (RFC 0058): same
    /// logic, but reading plain fields instead of captured clones.
    /// Returns `None` when the live mirror has been severed (the
    /// frame returned and ownership was not taken).
    pub fn compute_locals(&self) -> Option<Object> {
        // For module / class bodies the user-visible locals are the
        // corresponding namespace dict (class_ns when set, otherwise
        // globals). PEP 3115 custom class namespaces hand back the
        // live mapping object itself, exactly as CPython does.
        if let Some(ns_obj) = self.class_namespace_obj.as_ref() {
            return Some(ns_obj.clone());
        }
        if let Some(ns) = self.class_namespace.as_ref() {
            return Some(Object::Dict(ns.clone()));
        }
        if self.is_module_scope {
            return Some(Object::Dict(self.globals.clone()));
        }
        // A cleared frame holds no references: report an empty mapping
        // even though the (closure-shared) cells still carry values.
        if self.cleared.get() {
            return Some(Object::new_dict());
        }
        let mirror = self.locals_mirror.borrow().clone()?;
        let snapshot = mirror.borrow();
        let varnames = &self.code.varnames;
        let cell_names: Vec<&String> = self
            .code
            .cellvars
            .iter()
            .chain(self.code.freevars.iter())
            .collect();
        // Function frames: copy the locals array into a dict so user
        // code can read by name. Cell variables live in the cell, not
        // the local slot.
        let mut d = DictData::default();
        for (name, value) in varnames.iter().zip(snapshot.iter()) {
            // Compiler-synthesized temporaries (`.retval0`,
            // `.eg_remaining0`, …) are implementation detail —
            // CPython keeps its equivalents on the value stack, so
            // they never appear in `f_locals`.
            if name.starts_with('.') {
                continue;
            }
            if matches!(value, Object::Unbound) {
                if let Some(idx) = cell_names.iter().position(|c| *c == name) {
                    if let Some(cell) = self.cells.get(idx) {
                        let v = cell.borrow().clone();
                        if !matches!(v, Object::Unbound) {
                            d.insert(DictKey(Object::from_str(name.clone())), v);
                        }
                        continue;
                    }
                }
            }
            // Unbound slots (never assigned, or `del`eted) are absent
            // from `f_locals`; a local that *is* bound to `None`
            // stays visible (NameError suggestions rely on this).
            if !matches!(value, Object::Unbound) {
                d.insert(DictKey(Object::from_str(name.clone())), value.clone());
            }
        }
        // Cellvars not present in varnames (e.g. `__class__`).
        for (i, name) in cell_names.iter().enumerate() {
            if varnames.iter().any(|v| v == *name) {
                continue;
            }
            if let Some(cell) = self.cells.get(i) {
                let v = cell.borrow().clone();
                if !matches!(v, Object::Unbound) {
                    d.insert(DictKey(Object::from_str((*name).clone())), v);
                }
            }
        }
        // PEP 667: keys stored through the FrameLocalsProxy that don't
        // name a fast local land in `f_extra_locals` and are part of
        // every snapshot (`locals()`, `PyEval_GetFrameLocals`).
        if let Some(extra) = self.extra_locals.borrow().as_ref() {
            for (k, v) in extra.borrow().iter() {
                d.insert(k.clone(), v.clone());
            }
        }
        Some(Object::Dict(Rc::new(RefCell::new(d))))
    }

    /// All user-visible fast-local names for this frame, in CPython's
    /// `co_localsplusnames` order (varnames, then cellvars, then
    /// freevars) without duplicates or compiler temporaries
    /// (`.retval0`-style dot names). RFC 0060 — enumeration base for
    /// the PEP 667 `FrameLocalsProxy`.
    pub fn fast_names(&self) -> Vec<String> {
        let mut out: Vec<String> = Vec::new();
        for name in self
            .code
            .varnames
            .iter()
            .chain(self.code.cellvars.iter())
            .chain(self.code.freevars.iter())
        {
            if name.starts_with('.') || out.iter().any(|n| n == name) {
                continue;
            }
            out.push(name.clone());
        }
        out
    }

    /// Whether `name` names a fast local (bound or not) of this frame.
    /// Dot-names (a genexpr's `.0` argument, compiler temporaries) are
    /// included: CPython's `FrameLocalsProxy` reads/writes them by key
    /// even though they never appear in the enumeration
    /// (`test_generators.test_modify_f_locals` replaces `.0`).
    pub fn has_fast(&self, name: &str) -> bool {
        self.code.varnames.iter().any(|n| n == name)
            || self.code.cellvars.iter().any(|n| n == name)
            || self.code.freevars.iter().any(|n| n == name)
    }

    /// Read a fast local by name, cell-aware. `None` when the name is
    /// not a fast local of this frame or the slot is unbound (never
    /// assigned, `del`eted, or wiped by `frame.clear()`).
    pub fn fast_get(&self, name: &str) -> Option<Object> {
        if self.cleared.get() {
            return None;
        }
        // Cell variables (cellvars + freevars) live in the cell; the
        // fast slot for a captured argument is Unbound after entry.
        if let Some(idx) = self
            .code
            .cellvars
            .iter()
            .chain(self.code.freevars.iter())
            .position(|n| n == name)
        {
            let v = self.cells.get(idx)?.borrow().clone();
            return match v {
                Object::Unbound => None,
                other => Some(other),
            };
        }
        let slot = self.code.varnames.iter().position(|n| n == name)?;
        if let Some(mirror) = self.locals_mirror.borrow().as_ref() {
            return match mirror.borrow().get(slot) {
                Some(Object::Unbound) | None => None,
                Some(other) => Some(other.clone()),
            };
        }
        // Mirror severed (the frame returned and `take_ownership`
        // froze a snapshot): serve reads from that snapshot.
        if let Some(Object::Dict(d)) = self.locals_cache.borrow().as_ref() {
            return d.borrow().get(&StrKey(name)).cloned();
        }
        None
    }

    /// Write a fast local by name, cell-aware. Returns `false` when
    /// `name` is not a writable fast local of this frame (the caller
    /// stores it in `f_extra_locals` instead).
    pub fn fast_set(&self, name: &str, value: Object) -> bool {
        if self.cleared.get() {
            return false;
        }
        if let Some(idx) = self
            .code
            .cellvars
            .iter()
            .chain(self.code.freevars.iter())
            .position(|n| n == name)
        {
            if let Some(cell) = self.cells.get(idx) {
                *cell.borrow_mut() = value;
                return true;
            }
            return false;
        }
        let Some(slot) = self.code.varnames.iter().position(|n| n == name) else {
            return false;
        };
        if let Some(mirror) = self.locals_mirror.borrow().as_ref() {
            let mut m = mirror.borrow_mut();
            if slot < m.len() {
                m[slot] = value;
                return true;
            }
            return false;
        }
        if let Some(Object::Dict(d)) = self.locals_cache.borrow().as_ref() {
            d.borrow_mut()
                .insert(DictKey(Object::from_str(name)), value);
            return true;
        }
        false
    }

    /// The `f_extra_locals` dict, creating it when `create` is set.
    pub fn extra_locals_dict(&self, create: bool) -> Option<Rc<RefCell<DictData>>> {
        if let Some(d) = self.extra_locals.borrow().as_ref() {
            return Some(d.clone());
        }
        if !create {
            return None;
        }
        let d = Rc::new(RefCell::new(DictData::default()));
        *self.extra_locals.borrow_mut() = Some(d.clone());
        Some(d)
    }

    /// Materialise the locals dict, caching the result. Subsequent
    /// calls return the same dict object so `id(frame.f_locals)` is
    /// stable.
    pub fn locals(&self) -> Object {
        if self.locals_cache.borrow().is_some() {
            self.refresh_locals();
            if let Some(v) = self.locals_cache.borrow().as_ref() {
                return v.clone();
            }
        }
        let dict = self.compute_locals().unwrap_or_else(Object::new_dict);
        *self.locals_cache.borrow_mut() = Some(dict.clone());
        dict
    }

    /// Is this a non-optimized (module / class / exec) scope, i.e. one
    /// whose names live in a namespace mapping instead of fast slots?
    pub fn is_unoptimized_scope(&self) -> bool {
        self.is_module_scope || self.class_namespace.is_some() || self.class_namespace_obj.is_some()
    }

    /// PEP 709: a *non-optimized* frame currently holding a bound fast
    /// local. Only inlined comprehensions give module/exec frames fast
    /// slots (their iteration variables — CPython's "hidden" fast
    /// locals), and only while the loop runs (LOAD_FAST_AND_CLEAR
    /// unbinds them on exit). While true, `locals()` / `f_locals` must
    /// expose the hidden names (test_listcomps scope='module').
    pub fn has_live_hidden_locals(&self) -> bool {
        if !self.is_unoptimized_scope() || self.cleared.get() {
            return false;
        }
        let mirror = self.locals_mirror.borrow().clone();
        let Some(mirror) = mirror else {
            return false;
        };
        let m = mirror.borrow();
        self.code
            .varnames
            .iter()
            .zip(m.iter())
            .any(|(n, v)| !n.starts_with('.') && !matches!(v, Object::Unbound))
    }

    /// The dict backing this non-optimized frame's namespace (module
    /// globals or a plain-dict class/exec namespace); `None` for
    /// optimized frames and custom mapping namespaces.
    fn namespace_dict(&self) -> Option<Rc<RefCell<DictData>>> {
        if self.class_namespace_obj.is_some() {
            return None;
        }
        if let Some(ns) = self.class_namespace.as_ref() {
            return Some(ns.clone());
        }
        if self.is_module_scope {
            return Some(self.globals.clone());
        }
        None
    }

    /// The `locals()` builtin, PEP 667 split: function (optimized)
    /// scopes return an *independent snapshot* per call — mutating it
    /// never affects the frame, and later calls return new dicts
    /// (test_patma_204: `out = locals(); del out["w"]`). Module, class,
    /// and exec scopes return the live namespace itself — except while
    /// an inlined comprehension's hidden fast locals are live, when
    /// CPython's `_PyEval_GetFrameLocals` dict-ifies the frame's
    /// `FrameLocalsProxy`: a fresh snapshot of the namespace with the
    /// bound hidden names merged over it (test_listcomps
    /// `locals()["x"]` at module scope). The identity-stable
    /// [`Self::locals`] cache stays reserved for `frame.f_locals`.
    pub fn locals_snapshot(&self) -> Object {
        if self.has_live_hidden_locals() {
            if let Some(ns) = self.namespace_dict() {
                let mut d = ns.borrow().clone();
                if let Some(mirror) = self.locals_mirror.borrow().as_ref() {
                    for (name, value) in self.code.varnames.iter().zip(mirror.borrow().iter()) {
                        if !name.starts_with('.') && !matches!(value, Object::Unbound) {
                            d.insert(DictKey(Object::from_str(name.clone())), value.clone());
                        }
                    }
                }
                return Object::Dict(Rc::new(RefCell::new(d)));
            }
        }
        match self.compute_locals() {
            Some(dict) => dict,
            None => self.locals(),
        }
    }

    /// Refresh the materialised `f_locals` dict *in place*, keeping
    /// its identity stable (PEP 667: a handle obtained earlier
    /// observes later execution of the frame). Frame names are
    /// rewritten from the live state; user-added extra keys are
    /// preserved.
    pub fn refresh_locals(&self) {
        let cached = self.locals_cache.borrow().clone();
        let Some(Object::Dict(cached_rc)) = cached else {
            return;
        };
        let Some(Object::Dict(fresh_rc)) = self.compute_locals() else {
            return;
        };
        // Module/class scopes hand back the namespace dict itself —
        // already live, nothing to merge.
        if Rc::ptr_eq(&cached_rc, &fresh_rc) {
            return;
        }
        let mut out = fresh_rc.borrow().clone();
        {
            let old = cached_rc.borrow();
            for (k, v) in old.iter() {
                let is_frame_name = match &k.0 {
                    Object::Str(s) => {
                        let name = s.as_ref();
                        self.code.varnames.iter().any(|n| n == name)
                            || self.code.cellvars.iter().any(|n| n == name)
                            || self.code.freevars.iter().any(|n| n == name)
                    }
                    _ => false,
                };
                if !is_frame_name && !out.contains_key(k) {
                    out.insert(k.clone(), v.clone());
                }
            }
        }
        *cached_rc.borrow_mut() = out;
    }

    /// Bring the materialised snapshot (if any) up to date with the
    /// frame's live state. Used by the VM after the frame has executed
    /// enough to make the cached contents stale (function entry,
    /// generator resume). The dict's identity is preserved.
    pub fn invalidate_locals(&self) {
        self.refresh_locals();
    }

    /// CPython `take_ownership`: when a frame returns but its frame object
    /// outlives the activation (a live traceback or an explicit
    /// `sys._getframe`/`gi_frame` handle still references it), the
    /// running fast-locals are *moved into* the frame object so
    /// `frame.f_locals` stays readable for as long as that reference
    /// lives (`traceback.TracebackException(..., capture_locals=True)`).
    ///
    /// We materialise the current live mirror into the `f_locals` cache,
    /// then sever the live mirror/provider so the cache is the
    /// authoritative, stable snapshot. The cache pins only what the frame
    /// genuinely captured and dies together with the frame object — so a
    /// frame referenced only by the (about-to-be-dropped) call stack, or
    /// by garbage, is *not* given ownership (the caller keeps clearing the
    /// mirror there) and prompt refcount finalization is preserved.
    pub fn take_ownership_of_locals(&self) {
        let Some(dict) = self.compute_locals() else {
            // Already detached: nothing to own.
            return;
        };
        *self.locals_cache.borrow_mut() = Some(dict);
        // Sever the live link: future reads return the frozen snapshot
        // (`refresh_locals` early-returns once the mirror is `None`),
        // and dropping the mirror releases the frame's share of the
        // locals storage.
        *self.locals_mirror.borrow_mut() = None;
    }
}

/// RFC 0058 (WS2) — one entry of the interpreter's Python-visible
/// call-stack spine.
///
/// Pushing a call used to construct a full [`PyFrame`] (17 fields, a
/// provider closure, and an eagerly linked `back` chain) for every
/// activation, though almost no call is ever introspected. A shell
/// carries just the cheap `Rc` handles needed to *materialise* the
/// real `PyFrame` on demand — `sys._getframe`, tracing, traceback
/// capture, `gi_frame` — plus a relaxed-atomic `lasti` mirror the
/// dispatch loop keeps current.
///
/// Invariants:
///
/// - `materialized` frames obtained through [`materialize_stack_at`]
///   have their `back` chain linked for everything below them at the
///   moment of the call. Callers cannot change while a frame is on
///   the stack, so the chain stays correct for the frame's lifetime.
/// - A shell pushed with a pre-materialised frame (generator resume)
///   may carry a stale/None `back` until the next walk refreshes it;
///   direct `f_back` reads on the current thread route through the
///   walk (see the `f_back` attribute handler).
#[derive(Debug)]
pub struct FrameShell {
    pub code: FrameSlot<Rc<CodeObject>>,
    pub locals: FrameSlot<Rc<RefCell<Vec<Object>>>>,
    pub cells: FrameSlot<Rc<Vec<Rc<RefCell<Object>>>>>,
    pub globals: FrameSlot<Rc<RefCell<DictData>>>,
    pub builtins: FrameSlot<Rc<RefCell<DictData>>>,
    /// Mapping-object `__builtins__` (see `Frame::builtins_obj`) — a
    /// sandboxed exec/eval frame resolves builtin names by item access
    /// on this object; `_PyEval_GetBuiltin`-style helpers (e.g.
    /// `iterator.__reduce__`) must consult it too.
    pub builtins_obj: Option<Object>,
    pub class_namespace: Option<Rc<RefCell<DictData>>>,
    pub class_namespace_obj: Option<Object>,
    /// Generator/coroutine/async-generator frame?
    pub is_gen: bool,
    /// Backlink to the owning generator, when this activation is a
    /// generator resume (lets `gi_frame` find the executing frame).
    pub gen_owner: RefCell<Option<crate::sync::Weak<PyGenerator>>>,
    /// Live mirror of the executing frame's `pc`, stored relaxed by
    /// the dispatch loop each instruction so materialisation at any
    /// point reports the correct `f_lineno`.
    pub lasti: std::sync::atomic::AtomicU32,
    /// Fast gate for [`Self::materialized`]: one relaxed load tells
    /// the dispatch loop whether it must also sync the materialised
    /// frame's `lasti` cell each instruction.
    pub has_materialized: std::sync::atomic::AtomicBool,
    /// The real Python frame object, once someone asked for it.
    pub materialized: RefCell<Option<Rc<PyFrame>>>,
}

/// Owned metadata in a live frame shell. Recycled shells leave these slots
/// empty so recycling doesn't clone and later drop shared placeholders.
/// Only a live shell may be read; the pool is private to the interpreter.
#[derive(Debug)]
pub struct FrameSlot<T>(Option<T>);

impl<T> FrameSlot<T> {
    pub(crate) fn new(value: T) -> Self {
        Self(Some(value))
    }

    pub(crate) fn clear(&mut self) {
        self.0 = None;
    }
}

impl<T> std::ops::Deref for FrameSlot<T> {
    type Target = T;

    fn deref(&self) -> &T {
        self.0.as_ref().expect("live frame shell metadata")
    }
}

impl FrameShell {
    /// Wrap an already-materialised frame (generator resume, event
    /// dispatch around throw/unwind) in a shell for the spine.
    pub fn from_py_frame(py: &Rc<PyFrame>) -> Self {
        FrameShell {
            code: FrameSlot::new(py.code.clone()),
            locals: FrameSlot::new(
                py.locals_mirror
                    .borrow()
                    .clone()
                    .unwrap_or_else(|| Rc::new(RefCell::new(Vec::new()))),
            ),
            cells: FrameSlot::new(py.cells.clone()),
            globals: FrameSlot::new(py.globals.clone()),
            builtins: FrameSlot::new(py.builtins.clone()),
            builtins_obj: None,
            class_namespace: py.class_namespace.clone(),
            class_namespace_obj: py.class_namespace_obj.clone(),
            is_gen: py.code.is_generator || py.code.is_coroutine || py.code.is_async_generator,
            gen_owner: RefCell::new(py.gen_owner.borrow().clone()),
            lasti: std::sync::atomic::AtomicU32::new(py.lasti.get()),
            has_materialized: std::sync::atomic::AtomicBool::new(true),
            materialized: RefCell::new(Some(py.clone())),
        }
    }

    /// Build the real [`PyFrame`] for this shell with the given
    /// `back` pointer, caching it. Bumps `on_stack` exactly once per
    /// materialisation — the pop path decrements it for shells whose
    /// `materialized` is set.
    pub fn materialize(&self, back: Option<Rc<PyFrame>>) -> Rc<PyFrame> {
        if let Some(existing) = self.materialized.borrow().as_ref() {
            return existing.clone();
        }
        let py = Rc::new(PyFrame {
            code: self.code.clone(),
            globals: self.globals.clone(),
            builtins: self.builtins.clone(),
            lasti: Cell::new(self.lasti.load(std::sync::atomic::Ordering::Relaxed)),
            back: RefCell::new(back),
            locals_cache: RefCell::new(None),
            cells: self.cells.clone(),
            class_namespace: self.class_namespace.clone(),
            class_namespace_obj: self.class_namespace_obj.clone(),
            is_module_scope: self.code.name == "<module>",
            locals_mirror: RefCell::new(Some(self.locals.clone())),
            trace: RefCell::new(Object::None),
            gen_owner: RefCell::new(self.gen_owner.borrow().clone()),
            override_lineno: crate::sync::RefCell::new(None),
            trace_event: Cell::new(crate::linejump::TraceEvent::None),
            pending_jump: crate::sync::RefCell::new(None),
            last_line: crate::sync::RefCell::new(None),
            trace_lines: Cell::new(true),
            trace_opcodes: Cell::new(false),
            on_stack: Cell::new(1),
            extra_locals: RefCell::new(None),
            cleared: Cell::new(false),
        });
        *self.materialized.borrow_mut() = Some(py.clone());
        self.has_materialized
            .store(true, std::sync::atomic::Ordering::Release);
        // RFC 0065 (WS1): a freshly materialized frame must kick its
        // dispatch loop off the quiet path so the per-instruction
        // `lasti`-cell sync resumes.
        crate::hot_gates::bump_loop_gen();
        py
    }

    /// The current instruction index, preferring the shell's live
    /// mirror (kept current by the dispatch loop).
    pub fn current_lasti(&self) -> u32 {
        self.lasti.load(std::sync::atomic::Ordering::Relaxed)
    }

    /// The source line currently executing, honouring a materialised
    /// frame's `f_lineno` override when one exists. Cheap enough for
    /// consumers that only need file/line (warnings' `stacklevel`
    /// walk, faulthandler dumps) to skip materialisation entirely.
    pub fn current_lineno(&self) -> u32 {
        // `try_borrow`: faulthandler calls this from crash context,
        // where a panic on a live mutable borrow would be fatal.
        if let Ok(m) = self.materialized.try_borrow() {
            if let Some(py) = m.as_ref() {
                return py.current_lineno();
            }
        }
        let pc = self.current_lasti() as usize;
        self.code.linetable.get(pc).copied().unwrap_or(0)
    }
}

/// The interpreter call-stack spine: one shell per live activation.
pub type FrameStack = Rc<RefCell<Vec<Rc<FrameShell>>>>;

/// The shared, immutable empty cell vector — cell-free calls (the
/// overwhelming majority) share one allocation instead of building a
/// fresh `Rc<Vec>` each.
pub fn empty_cells() -> Rc<Vec<Rc<RefCell<Object>>>> {
    static EMPTY: std::sync::OnceLock<Rc<Vec<Rc<RefCell<Object>>>>> = std::sync::OnceLock::new();
    EMPTY.get_or_init(|| Rc::new(Vec::new())).clone()
}

/// Materialise the frame at `idx` (0 = outermost) together with
/// everything below it, linking `back` pointers bottom-up, and return
/// it. Refreshes `back` on already-materialised entries too, so a
/// generator frame re-pushed with a stale link is corrected.
pub fn materialize_stack_at(stack: &FrameStack, idx: usize) -> Option<Rc<PyFrame>> {
    let shells: Vec<Rc<FrameShell>> = {
        let s = stack.borrow();
        if idx >= s.len() {
            return None;
        }
        s[..=idx].to_vec()
    };
    let mut back: Option<Rc<PyFrame>> = None;
    for shell in &shells {
        let existing = shell.materialized.borrow().clone();
        let py = match existing {
            Some(py) => {
                *py.back.borrow_mut() = back;
                py
            }
            None => {
                let py = shell.materialize(back);
                // Materialised while live on the stack: count the
                // activation so `frame.clear()` refuses it.
                py
            }
        };
        back = Some(py);
    }
    back
}

/// Materialise and return the top frame of a stack, or `None` when
/// the stack is empty.
pub fn materialize_stack_top(stack: &FrameStack) -> Option<Rc<PyFrame>> {
    let len = stack.borrow().len();
    if len == 0 {
        return None;
    }
    materialize_stack_at(stack, len - 1)
}

/// Internal payload for [`Object::Traceback`]. Built lazily by the
/// unwind machinery and chained outward through [`Self::next`].
#[derive(Debug)]
pub struct PyTraceback {
    pub frame: Rc<PyFrame>,
    pub lineno: u32,
    pub lasti: u32,
    /// `types.TracebackType(…)` stores the caller-supplied `tb_lasti`
    /// verbatim; interpreter-raised tracebacks leave this `None` and map
    /// the instruction index through `cpython_lasti` on read.
    pub raw_lasti: Option<i64>,
    pub next: RefCell<Option<Rc<PyTraceback>>>,
}

impl Drop for PyTraceback {
    fn drop(&mut self) {
        // Same unbounded-recursion hazard as `PyFrame::drop`: a traceback
        // is a `tb_next` linked list one node per stack level, so a
        // ~1000-deep traceback (a `RecursionError`) would drop recursively
        // and overflow the native stack. Tear the chain down iteratively.
        let mut link = self.next.borrow_mut().take();
        while let Some(tb) = link {
            match Rc::try_unwrap(tb) {
                Ok(inner) => link = inner.next.borrow_mut().take(),
                Err(_) => break,
            }
        }
    }
}

// ---- bytearray buffer-export accounting ----
//
// CPython forbids resizing a `bytearray` while its buffer is exported
// (`ob_exports > 0`): a live `memoryview`, or a native method holding
// the buffer across a re-entrant callback (gh-142560). We track live
// exports per backing buffer in a side table. The hot-path cost for
// non-exporting programs is a single relaxed atomic load.

static BYTEARRAY_EXPORT_TOTAL: std::sync::atomic::AtomicUsize =
    std::sync::atomic::AtomicUsize::new(0);

type ExportMap = std::collections::HashMap<usize, (crate::sync::Weak<RefCell<Vec<u8>>>, usize)>;

fn bytearray_export_map() -> &'static std::sync::Mutex<ExportMap> {
    static MAP: std::sync::OnceLock<std::sync::Mutex<ExportMap>> = std::sync::OnceLock::new();
    MAP.get_or_init(|| std::sync::Mutex::new(ExportMap::new()))
}

/// Register a live export of `buf`. Pair with
/// [`bytearray_export_release`] (or use [`ByteArrayExportGuard`]).
pub fn bytearray_export_acquire(buf: &Rc<RefCell<Vec<u8>>>) {
    let key = Rc::as_ptr(buf) as usize;
    let mut map = bytearray_export_map().lock().unwrap();
    let entry = map.entry(key);
    match entry {
        std::collections::hash_map::Entry::Occupied(mut o) => {
            // A recycled allocation address must not inherit the stale
            // count from a dead buffer.
            let stale = o
                .get()
                .0
                .upgrade()
                .is_none_or(|live| !Rc::ptr_eq(&live, buf));
            if stale {
                let removed = o.get().1;
                BYTEARRAY_EXPORT_TOTAL.fetch_sub(removed, std::sync::atomic::Ordering::AcqRel);
                *o.get_mut() = (Rc::downgrade(buf), 1);
            } else {
                o.get_mut().1 += 1;
            }
        }
        std::collections::hash_map::Entry::Vacant(v) => {
            v.insert((Rc::downgrade(buf), 1));
        }
    }
    BYTEARRAY_EXPORT_TOTAL.fetch_add(1, std::sync::atomic::Ordering::AcqRel);
}

/// Drop one live export of `buf`.
pub fn bytearray_export_release(buf: &Rc<RefCell<Vec<u8>>>) {
    let key = Rc::as_ptr(buf) as usize;
    let mut map = bytearray_export_map().lock().unwrap();
    if let Some((weak, count)) = map.get_mut(&key) {
        let live = weak.upgrade().is_some_and(|live| Rc::ptr_eq(&live, buf));
        if live {
            *count -= 1;
            BYTEARRAY_EXPORT_TOTAL.fetch_sub(1, std::sync::atomic::Ordering::AcqRel);
            if *count == 0 {
                map.remove(&key);
            }
        }
    }
}

/// Does `buf` have any live exports?
pub fn bytearray_is_exported(buf: &Rc<RefCell<Vec<u8>>>) -> bool {
    if BYTEARRAY_EXPORT_TOTAL.load(std::sync::atomic::Ordering::Acquire) == 0 {
        return false;
    }
    let key = Rc::as_ptr(buf) as usize;
    let map = bytearray_export_map().lock().unwrap();
    map.get(&key).is_some_and(|(weak, count)| {
        *count > 0 && weak.upgrade().is_some_and(|live| Rc::ptr_eq(&live, buf))
    })
}

/// Gate for length-changing `bytearray` operations — CPython's
/// `_canresize`. Same-length writes are always fine; the callers only
/// invoke this when the operation would change `len`.
pub fn bytearray_check_resizable(buf: &Rc<RefCell<Vec<u8>>>) -> Result<(), RuntimeError> {
    if bytearray_is_exported(buf) {
        return Err(RuntimeError::PyException(
            crate::error::PyException::from_builtin(
                "BufferError",
                "Existing exports of data: object cannot be re-sized",
            ),
        ));
    }
    Ok(())
}

/// RAII export of a bytearray buffer — what a CPython C method holds
/// (via `PyObject_GetBuffer` on `self`) while it converts arguments
/// that may call back into Python.
#[derive(Debug)]
pub struct ByteArrayExportGuard {
    buf: Rc<RefCell<Vec<u8>>>,
}

impl ByteArrayExportGuard {
    pub fn new(buf: Rc<RefCell<Vec<u8>>>) -> Self {
        bytearray_export_acquire(&buf);
        Self { buf }
    }
}

impl Drop for ByteArrayExportGuard {
    fn drop(&mut self) {
        bytearray_export_release(&self.buf);
    }
}

/// A raw, externally-owned memory region a [`PyMemoryView`] can window
/// over — an `mmap.mmap` mapping or a `multiprocessing.shared_memory`
/// block. The region is kept alive by the `Arc` held in
/// [`MemoryViewBuffer::Shared`]; access is by raw pointer because the
/// memory is genuinely aliased (shared across OS threads, and across
/// processes for a file/anon shared mapping), exactly like CPython's
/// mmap/shared-memory buffer export. Writes through the view land in the
/// shared region. Serialisation of concurrent access is the caller's job
/// (the GIL plus, for `multiprocessing`, the heap/semaphore locks).
pub trait SharedMemBuffer: std::fmt::Debug + Send + Sync {
    /// Region length in bytes.
    fn byte_len(&self) -> usize;
    /// Pointer to the first byte of the region (stable for the region's
    /// lifetime — `mmap`/shared memory never moves).
    fn data_ptr(&self) -> *mut u8;
    /// Whether the region is read-only (an `ACCESS_READ` mapping).
    fn is_readonly(&self) -> bool;
    /// Called when a memoryview over the region is explicitly `release()`d,
    /// with the region's current strong count (`holders`). A C-buffer
    /// region counts these and forwards to `PyBuffer_Release` once every
    /// remaining holder is a released view (CPython releases the
    /// `_PyManagedBuffer` as soon as its export count hits zero, without
    /// waiting for GC — `_testbuffer.ndarray.pop()` depends on it). Plain
    /// mmap/shared-memory regions don't care.
    fn on_view_release(&self, holders: usize) {
        let _ = holders;
    }
}

/// Backing buffer for a [`PyMemoryView`].
#[derive(Debug)]
pub enum MemoryViewBuffer {
    /// Immutable bytes; the view exposes them read-only.
    Bytes(SharedSlice<u8>),
    /// Mutable bytearray; the view participates in `bytearray`'s
    /// shared-state semantics so writes through the view land in
    /// the underlying buffer.
    ByteArray(Rc<RefCell<Vec<u8>>>),
    /// A raw shared-memory region (`mmap`, `shared_memory`). Writes land
    /// in the region so other threads/processes mapping it observe them.
    Shared(Rc<dyn SharedMemBuffer>),
}

impl MemoryViewBuffer {
    /// A read-only slice over the *entire* backing region. For `Shared`
    /// this aliases the live mapping; for `Bytes`/`ByteArray` it borrows
    /// the owned buffer. The returned slice is valid for `'a` because the
    /// backing is kept alive by `self`.
    ///
    /// # Safety / aliasing
    /// For `Shared`, the region is intentionally aliased shared memory; do
    /// not hold the returned slice across a write through the same view.
    pub fn with_read<R>(&self, f: impl FnOnce(&[u8]) -> R) -> R {
        match self {
            MemoryViewBuffer::Bytes(b) => f(b),
            MemoryViewBuffer::ByteArray(b) => f(&b.borrow()),
            MemoryViewBuffer::Shared(s) => {
                let slice = unsafe { std::slice::from_raw_parts(s.data_ptr(), s.byte_len()) };
                f(slice)
            }
        }
    }

    /// A mutable slice over the entire backing region, or `None` for a
    /// read-only backing (`Bytes`, or an `ACCESS_READ` `Shared`).
    pub fn with_write<R>(&self, f: impl FnOnce(&mut [u8]) -> R) -> Option<R> {
        match self {
            MemoryViewBuffer::Bytes(_) => None,
            MemoryViewBuffer::ByteArray(b) => Some(f(&mut b.borrow_mut())),
            MemoryViewBuffer::Shared(s) => {
                if s.is_readonly() {
                    return None;
                }
                let slice = unsafe { std::slice::from_raw_parts_mut(s.data_ptr(), s.byte_len()) };
                Some(f(slice))
            }
        }
    }
}

/// `memoryview(obj)` — a thin window into another bytes-like object.
/// We only implement the byte-format minimum CPython itself ships
/// (`format='B'`, `itemsize=1`, `ndim=1`). NumPy-style N-dimensional
/// views are RFC 0023 future work; the surface is enough for
/// `pickle.PickleBuffer`, `socket.recv_into`, and the standard
/// `memoryview(b'hello').tobytes()` patterns.
#[derive(Debug)]
pub struct PyMemoryView {
    pub buffer: MemoryViewBuffer,
    /// Inclusive start offset into the buffer (in bytes).
    pub start: Cell<usize>,
    /// Logical size of the view, in bytes (`nbytes` == `product(shape) *
    /// itemsize`). For a contiguous view this is also the width of the
    /// `[start..start+len]` window; for a strided view it is the number of
    /// bytes `tobytes()` materialises, not the span of the buffer it walks.
    pub len: Cell<usize>,
    pub readonly: Cell<bool>,
    pub released: Cell<bool>,
    pub format: RefCell<String>,
    pub itemsize: Cell<usize>,
    /// Logical dimensions, in *elements*. Empty means "derive a 1-D
    /// `[len / itemsize]` shape", which keeps every simple constructor a
    /// plain literal — only `cast(shape=…)` and strided slicing store an
    /// explicit shape.
    pub shape: RefCell<Vec<usize>>,
    /// Per-dimension stride, in *bytes*. Empty means "derive the
    /// C-contiguous strides for `shape`". A negative stride (from a
    /// `seq[::-1]`-style slice) marks the view non-contiguous.
    pub strides: RefCell<Vec<isize>>,
    /// PEP 3118 suboffsets, in bytes. Empty means "no indirection"
    /// (CPython's all-`-1` case). An entry `>= 0` marks a PIL-style
    /// indirect dimension: after adding `index * stride`, the pointer at
    /// that address is dereferenced and `suboffsets[dim]` added. Only a
    /// [`MemoryViewBuffer::Shared`] backing (a live C exporter's memory)
    /// can carry suboffsets — element access chases raw pointers, which
    /// may land outside the root allocation.
    pub suboffsets: RefCell<Vec<isize>>,
    /// The object the buffer was exported from — CPython's `mv.obj`
    /// (`view->obj`). `None` when unknown; the attribute getter then
    /// reconstructs a bytes-like from the backing buffer.
    pub exporter: RefCell<Option<Object>>,
    /// True for a 0-dimensional (scalar) view — PEP 3118 `ndim == 0`, as
    /// exported by ctypes scalars. Distinguished from an empty stored
    /// `shape`, which means "derive the 1-D layout".
    pub zero_dim: Cell<bool>,
    /// Cached content hash (CPython `mv->hash`), `-1` when not yet computed.
    /// Once set, `hash(mv)` keeps answering it even after `release()` —
    /// "releasing the memoryview keeps the stored hash value (as with
    /// weakrefs)" (test_memoryview.test_hash).
    pub hash: Cell<i64>,
    /// Re-entrancy guard for `memory_hash` (CPython `mv->exports`, gh-142664):
    /// while the exporter's `__hash__` runs, `release()` must fail with
    /// BufferError instead of freeing the buffer out from under the hash.
    pub exports: Cell<u32>,
    /// PEP 688: the memoryview object a Python-level `__buffer__` returned
    /// when this view was constructed (`memoryview(obj)` over a class with
    /// `def __buffer__`). Kept so releasing this view can hand the *same
    /// object* to the exporter's `__release_buffer__`
    /// (test_buffer.test_same_buffer_returned asserts identity). `None`
    /// for views over native buffers.
    pub release_inner: RefCell<Option<Object>>,
    /// CPython's `_Py_MEMORYVIEW_RESTRICTED` (PEP 688): set on the view
    /// passed to `__release_buffer__` — further exports (`memoryview(mv)`,
    /// `cast`, `toreadonly`, slicing, `__buffer__`) raise ValueError,
    /// while reads (`tobytes`) and `release` stay legal.
    pub restricted: Cell<bool>,
}

impl PyMemoryView {
    pub fn from_bytes(b: SharedSlice<u8>) -> Self {
        let len = b.len();
        Self {
            buffer: MemoryViewBuffer::Bytes(b),
            start: Cell::new(0),
            len: Cell::new(len),
            readonly: Cell::new(true),
            released: Cell::new(false),
            format: RefCell::new("B".to_owned()),
            itemsize: Cell::new(1),
            shape: RefCell::new(Vec::new()),
            strides: RefCell::new(Vec::new()),
            suboffsets: RefCell::new(Vec::new()),
            exporter: RefCell::new(None),
            zero_dim: Cell::new(false),
            hash: Cell::new(-1),
            exports: Cell::new(0),
            release_inner: RefCell::new(None),
            restricted: Cell::new(false),
        }
    }

    /// `memoryview(mmap_or_shm)` — a window over a raw shared-memory
    /// region. Writable unless the region is `ACCESS_READ`.
    pub fn from_shared(buf: Rc<dyn SharedMemBuffer>) -> Self {
        let len = buf.byte_len();
        let readonly = buf.is_readonly();
        Self {
            buffer: MemoryViewBuffer::Shared(buf),
            start: Cell::new(0),
            len: Cell::new(len),
            readonly: Cell::new(readonly),
            released: Cell::new(false),
            format: RefCell::new("B".to_owned()),
            itemsize: Cell::new(1),
            shape: RefCell::new(Vec::new()),
            strides: RefCell::new(Vec::new()),
            suboffsets: RefCell::new(Vec::new()),
            exporter: RefCell::new(None),
            zero_dim: Cell::new(false),
            hash: Cell::new(-1),
            exports: Cell::new(0),
            release_inner: RefCell::new(None),
            restricted: Cell::new(false),
        }
    }

    pub fn from_bytearray(b: Rc<RefCell<Vec<u8>>>) -> Self {
        let len = b.borrow().len();
        // The view is a live buffer export: the bytearray cannot be
        // resized until this view is released/dropped (CPython
        // `ob_exports`).
        bytearray_export_acquire(&b);
        Self {
            buffer: MemoryViewBuffer::ByteArray(b),
            start: Cell::new(0),
            len: Cell::new(len),
            readonly: Cell::new(false),
            released: Cell::new(false),
            format: RefCell::new("B".to_owned()),
            itemsize: Cell::new(1),
            shape: RefCell::new(Vec::new()),
            strides: RefCell::new(Vec::new()),
            suboffsets: RefCell::new(Vec::new()),
            exporter: RefCell::new(None),
            zero_dim: Cell::new(false),
            hash: Cell::new(-1),
            exports: Cell::new(0),
            release_inner: RefCell::new(None),
            restricted: Cell::new(false),
        }
    }

    /// 1-D contiguous view over an already-materialised buffer. Used by the
    /// C-API `PyMemoryView_*` constructors, which copy the exporter's bytes
    /// into a fresh, flat buffer (so there is no external bytearray export to
    /// account for). `shape`/`strides` are left empty to derive the 1-D
    /// layout from `len`/`itemsize`.
    pub fn contiguous_1d(
        buffer: MemoryViewBuffer,
        len: usize,
        readonly: bool,
        format: String,
        itemsize: usize,
    ) -> Self {
        Self {
            buffer,
            start: Cell::new(0),
            len: Cell::new(len),
            readonly: Cell::new(readonly),
            released: Cell::new(false),
            format: RefCell::new(format),
            itemsize: Cell::new(itemsize),
            shape: RefCell::new(Vec::new()),
            strides: RefCell::new(Vec::new()),
            suboffsets: RefCell::new(Vec::new()),
            exporter: RefCell::new(None),
            zero_dim: Cell::new(false),
            hash: Cell::new(-1),
            exports: Cell::new(0),
            release_inner: RefCell::new(None),
            restricted: Cell::new(false),
        }
    }

    /// Same backing buffer, same window — `memoryview(mv)`. Takes its
    /// own buffer export, like CPython.
    pub fn shallow_clone(&self) -> Self {
        let buffer = match &self.buffer {
            MemoryViewBuffer::Bytes(b) => MemoryViewBuffer::Bytes(b.clone()),
            MemoryViewBuffer::ByteArray(b) => {
                if !self.released.get() {
                    bytearray_export_acquire(b);
                }
                MemoryViewBuffer::ByteArray(b.clone())
            }
            MemoryViewBuffer::Shared(s) => MemoryViewBuffer::Shared(s.clone()),
        };
        Self {
            buffer,
            start: Cell::new(self.start.get()),
            len: Cell::new(self.len.get()),
            readonly: Cell::new(self.readonly.get()),
            released: Cell::new(self.released.get()),
            format: RefCell::new(self.format.borrow().clone()),
            itemsize: Cell::new(self.itemsize.get()),
            shape: RefCell::new(self.shape.borrow().clone()),
            strides: RefCell::new(self.strides.borrow().clone()),
            suboffsets: RefCell::new(self.suboffsets.borrow().clone()),
            exporter: RefCell::new(self.exporter.borrow().clone()),
            zero_dim: Cell::new(self.zero_dim.get()),
            // A fresh object: the hash cache and re-entrancy guard are
            // per-view state, not shared with the source.
            hash: Cell::new(-1),
            exports: Cell::new(0),
            release_inner: RefCell::new(None),
            restricted: Cell::new(false),
        }
    }

    /// Whether two views window the same backing buffer (identity, not
    /// content) — `bytearray.__release_buffer__` validation.
    pub fn shares_buffer(&self, other: &PyMemoryView) -> bool {
        match (&self.buffer, &other.buffer) {
            (MemoryViewBuffer::Bytes(a), MemoryViewBuffer::Bytes(b)) => ThinArc::ptr_eq(a, b),
            (MemoryViewBuffer::ByteArray(a), MemoryViewBuffer::ByteArray(b)) => Rc::ptr_eq(a, b),
            (MemoryViewBuffer::Shared(a), MemoryViewBuffer::Shared(b)) => {
                std::ptr::addr_eq(Rc::as_ptr(a), Rc::as_ptr(b))
            }
            _ => false,
        }
    }

    /// `memoryview.release()` — drop the buffer export and mark the
    /// view unusable. Idempotent.
    pub fn release(&self) {
        if !self.released.replace(true) {
            // Drop the exporter reference now: CPython's `memory_release`
            // decrefs `view.obj` immediately, and test_buffer's chained
            // release test relies on the exporter deallocating (and thus
            // releasing *its* consumed buffers) before outer views exit.
            *self.exporter.borrow_mut() = None;
            match &self.buffer {
                MemoryViewBuffer::ByteArray(b) => bytearray_export_release(b),
                // Notify the shared region so it can release its underlying
                // export as soon as no *unreleased* view remains
                // (`_testbuffer.ndarray` counts exports and refuses
                // `push`/`pop` until they drop).
                MemoryViewBuffer::Shared(r) => {
                    r.on_view_release(Rc::strong_count(r));
                }
                MemoryViewBuffer::Bytes(_) => {}
            }
        }
    }

    /// Logical dimensions in elements. An empty stored `shape` derives the
    /// 1-D `[nbytes / itemsize]` layout that every plain constructor uses.
    pub fn shape_dims(&self) -> Vec<usize> {
        if self.zero_dim.get() {
            return Vec::new();
        }
        let stored = self.shape.borrow();
        if !stored.is_empty() {
            return stored.clone();
        }
        let itemsize = self.itemsize.get().max(1);
        vec![self.len.get() / itemsize]
    }

    /// Per-dimension stride in bytes. An empty stored `strides` derives the
    /// C-contiguous layout for the current `shape`.
    pub fn stride_bytes(&self) -> Vec<isize> {
        let stored = self.strides.borrow();
        if !stored.is_empty() {
            return stored.clone();
        }
        c_contiguous_strides(&self.shape_dims(), self.itemsize.get().max(1))
    }

    pub fn ndim(&self) -> usize {
        self.shape_dims().len()
    }

    /// True when any dimension carries a PEP 3118 suboffset (a PIL-style
    /// indirect view over a C exporter) — element access must chase
    /// pointers instead of computing a linear byte offset.
    pub fn has_suboffsets(&self) -> bool {
        self.suboffsets.borrow().iter().any(|&s| s >= 0)
    }

    /// True when the elements sit back-to-back in C (row-major) order, so a
    /// plain `[start..start+nbytes]` slice yields them. Anything with a
    /// negative or gapped stride (e.g. `mv[::-1]`, `mv[::2]`) or with
    /// suboffsets is not.
    pub fn is_c_contiguous(&self) -> bool {
        if self.has_suboffsets() {
            return false;
        }
        let stored = self.strides.borrow();
        if stored.is_empty() {
            return true; // derived strides are C-contiguous by construction
        }
        drop(stored);
        // CPython `_IsCContiguous`: zero-length buffers are trivially
        // contiguous; axes of length 0/1 impose no stride constraint.
        let shape = self.shape_dims();
        if shape.iter().product::<usize>() == 0 {
            return true;
        }
        let strides = self.stride_bytes();
        let mut sd = self.itemsize.get().max(1) as isize;
        for d in (0..shape.len()).rev() {
            let dim = shape[d];
            if dim > 1 && strides[d] != sd {
                return false;
            }
            sd *= dim as isize;
        }
        true
    }

    /// Fortran (column-major) contiguity, per CPython's
    /// `_IsFortranContiguous`: the *first* axis has stride
    /// `itemsize`, each later axis multiplies up. Axes of length 0/1
    /// impose no constraint.
    pub fn is_f_contiguous(&self) -> bool {
        if self.has_suboffsets() {
            return false;
        }
        let shape = self.shape_dims();
        if shape.iter().product::<usize>() == 0 {
            return true;
        }
        let strides = self.stride_bytes();
        let mut sd = self.itemsize.get().max(1) as isize;
        for (d, &dim) in shape.iter().enumerate() {
            if dim > 1 && strides[d] != sd {
                return false;
            }
            sd *= dim as isize;
        }
        true
    }

    /// Linear byte offset (into the backing buffer) of the element at the
    /// already-normalized multi-index `idxs`. Only meaningful when the
    /// view has no suboffsets.
    fn element_linear_offset(&self, idxs: &[usize]) -> usize {
        let strides = self.stride_bytes();
        let mut off = self.start.get() as isize;
        for (d, &i) in idxs.iter().enumerate() {
            off += i as isize * strides[d];
        }
        off.max(0) as usize
    }

    /// PEP 3118 `PyBuffer_GetPointer` for an indirect (suboffsets) view:
    /// walk each dimension adding `index * stride`, dereferencing through
    /// the stored pointer (plus `suboffsets[dim]`) whenever the dimension
    /// is indirect. Requires a `Shared` backing — the pointers reference
    /// live C exporter memory outside the linear window model.
    fn element_indirect_ptr(&self, idxs: &[usize]) -> Option<*mut u8> {
        let MemoryViewBuffer::Shared(s) = &self.buffer else {
            return None;
        };
        let strides = self.stride_bytes();
        let subs = self.suboffsets.borrow();
        let mut ptr = unsafe { s.data_ptr().add(self.start.get()) };
        for (d, &i) in idxs.iter().enumerate() {
            ptr = unsafe { ptr.offset(i as isize * strides[d]) };
            if subs.get(d).copied().unwrap_or(-1) >= 0 {
                // The exporter stores a pointer at this element address; the
                // address is only guaranteed byte-aligned, so read unaligned.
                let deref = unsafe { ptr.cast::<*mut u8>().read_unaligned() };
                if deref.is_null() {
                    return None;
                }
                ptr = unsafe { deref.offset(subs[d]) };
            }
        }
        Some(ptr)
    }

    /// Pass the `itemsize` bytes of the element at (normalized)
    /// multi-index `idxs` to `f`. Handles both linear (strided) and
    /// indirect (suboffsets) views. `None` means the address could not be
    /// resolved (out-of-window offset or a NULL indirect pointer) — an
    /// exporter-side inconsistency, not a user error.
    pub fn read_element<R>(&self, idxs: &[usize], f: impl FnOnce(&[u8]) -> R) -> Option<R> {
        let itemsize = self.itemsize.get().max(1);
        if self.has_suboffsets() {
            let ptr = self.element_indirect_ptr(idxs)?;
            let slice = unsafe { std::slice::from_raw_parts(ptr, itemsize) };
            return Some(f(slice));
        }
        let off = self.element_linear_offset(idxs);
        self.buffer.with_read(|all| {
            if off + itemsize <= all.len() {
                Some(f(&all[off..off + itemsize]))
            } else {
                None
            }
        })
    }

    /// Write `data` (exactly `itemsize` bytes) over the element at
    /// (normalized) multi-index `idxs`. `None` means the backing is
    /// read-only or the address could not be resolved.
    pub fn write_element(&self, idxs: &[usize], data: &[u8]) -> Option<()> {
        if self.has_suboffsets() {
            if let MemoryViewBuffer::Shared(s) = &self.buffer {
                if s.is_readonly() {
                    return None;
                }
            }
            let ptr = self.element_indirect_ptr(idxs)?;
            unsafe { std::ptr::copy_nonoverlapping(data.as_ptr(), ptr, data.len()) };
            return Some(());
        }
        let off = self.element_linear_offset(idxs);
        self.buffer
            .with_write(|all| {
                if off + data.len() <= all.len() {
                    all[off..off + data.len()].copy_from_slice(data);
                    true
                } else {
                    false
                }
            })
            .and_then(|ok| ok.then_some(()))
    }

    /// Materialise the view's elements in C order. Contiguous views take the
    /// fast `[start..start+nbytes]` path; strided/reversed views are gathered
    /// element-by-element following `strides`, exactly like CPython's
    /// `memoryview.tobytes()`.
    pub fn to_bytes(&self) -> Vec<u8> {
        let itemsize = self.itemsize.get().max(1);
        if self.is_c_contiguous() {
            let start = self.start.get();
            let end = start + self.len.get();
            return self.buffer.with_read(|all| all[start..end].to_vec());
        }
        let shape = self.shape_dims();
        let total: usize = shape.iter().product();
        let mut out = Vec::with_capacity(total * itemsize);
        let mut index = vec![0usize; shape.len()];
        for _ in 0..total {
            // `read_element` handles both linear (strided) and indirect
            // (suboffsets) addressing; unresolvable elements are skipped,
            // matching the old out-of-window behaviour.
            self.read_element(&index, |b| out.extend_from_slice(b));
            // Increment the multi-index (last axis fastest = C order).
            for d in (0..shape.len()).rev() {
                index[d] += 1;
                if index[d] < shape[d] {
                    break;
                }
                index[d] = 0;
            }
        }
        out
    }

    /// Format string with a leading native-order `@` stripped, matching
    /// CPython's `cmp_structure` (which compares `format+1` when the first
    /// byte is `@`). `memoryview(b'x')` is `"B"`; `bytes`/`bytearray` buffers
    /// are also `"B"`.
    fn norm_format(&self) -> String {
        let f = self.format.borrow();
        f.strip_prefix('@').unwrap_or(&f).to_owned()
    }

    /// `memoryview == memoryview` per CPython's `memory_richcompare`:
    /// equal when ndim and shape match and each element's *unpacked
    /// value* compares equal. Formats may differ (`'<i'` vs `'>h'` with
    /// the same values are equal); multi-member struct formats compare
    /// as tuples; float comparison is by value, so NaN elements are
    /// never equal (CPython `unpack_cmp` / `struct_get_unpacker`).
    /// (Released views are handled by the caller as identity
    /// comparison.)
    pub fn buffer_eq(&self, other: &PyMemoryView) -> bool {
        if self.released.get() || other.released.get() {
            return false;
        }
        let shape = self.shape_dims();
        if shape != other.shape_dims() || self.zero_dim.get() != other.zero_dim.get() {
            return false;
        }
        let fmt_a = self.norm_format();
        let fmt_b = other.norm_format();
        // Byte fast path: identical unsigned-byte views compare by raw
        // content (the only format whose value order equals byte order
        // regardless of layout).
        if fmt_a == "B" && fmt_b == "B" {
            return self.to_bytes() == other.to_bytes();
        }
        let total: usize = shape.iter().product();
        let mut index = vec![0usize; shape.len()];
        for _ in 0..total {
            let va = self.read_element(&index, |b| {
                crate::stdlib::struct_mod::unpack_element(&fmt_a, b)
            });
            let vb = other.read_element(&index, |b| {
                crate::stdlib::struct_mod::unpack_element(&fmt_b, b)
            });
            let (Some(Ok(va)), Some(Ok(vb))) = (va, vb) else {
                // Unresolvable address or a format the struct module
                // can't unpack — CPython returns NotImplemented, which
                // grades as "not equal" here.
                return false;
            };
            if va.len() != vb.len() {
                return false;
            }
            if !va
                .iter()
                .zip(&vb)
                .all(|(x, y)| x.is_same(y) || x.eq_value(y))
            {
                return false;
            }
            for d in (0..shape.len()).rev() {
                index[d] += 1;
                if index[d] < shape[d] {
                    break;
                }
                index[d] = 0;
            }
        }
        true
    }

    /// `memoryview == bytes`/`bytearray`. A bytes-like exposes a 1-D `"B"`,
    /// itemsize-1 buffer, so the view is only equal when it has that same
    /// shape and its bytes match.
    pub fn eq_byte_slice(&self, bytes: &[u8]) -> bool {
        if self.released.get() {
            return false;
        }
        self.norm_format() == "B" && self.itemsize.get() == 1 && self.ndim() == 1 && {
            self.to_bytes() == bytes
        }
    }
}

/// Byte offset of character index `ci` in `s`. Positions past the end
/// extrapolate one byte per character: the StringIO overseek gap is filled
/// with 1-byte `'\0'`s on the next write, so the mapping stays exact.
pub(crate) fn memtext_byte_of_char(s: &str, ci: usize) -> usize {
    let mut count = 0usize;
    for (b, _) in s.char_indices() {
        if count == ci {
            return b;
        }
        count += 1;
    }
    s.len() + (ci - count)
}

/// Character index of byte offset `b` in `s` (must sit on a char boundary
/// when within the string); see [`memtext_byte_of_char`] for the
/// past-the-end extrapolation.
fn memtext_char_of_byte(s: &str, b: usize) -> usize {
    if b >= s.len() {
        return s.chars().count() + (b - s.len());
    }
    s.char_indices().take_while(|(i, _)| *i < b).count()
}

/// C-contiguous (row-major) byte strides for `shape` at the given itemsize:
/// the last axis has stride `itemsize`, each earlier axis multiplies up.
pub fn c_contiguous_strides(shape: &[usize], itemsize: usize) -> Vec<isize> {
    let mut strides = vec![itemsize as isize; shape.len()];
    let mut acc = itemsize as isize;
    for d in (0..shape.len()).rev() {
        strides[d] = acc;
        acc *= shape[d] as isize;
    }
    strides
}

impl Drop for PyMemoryView {
    fn drop(&mut self) {
        self.release();
    }
}

/// Discriminator carried on [`Object::DictView`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DictViewKind {
    Keys,
    Values,
    Items,
}

impl DictViewKind {
    pub fn type_name(self) -> &'static str {
        match self {
            DictViewKind::Keys => "dict_keys",
            DictViewKind::Values => "dict_values",
            DictViewKind::Items => "dict_items",
        }
    }
}

/// Live view over a backing `dict`. Iteration order mirrors the
/// underlying `IndexMap`. Mutations to the dict propagate through
/// the view (CPython invariant).
#[derive(Debug)]
pub struct PyDictView {
    pub dict: Rc<RefCell<DictData>>,
    pub kind: DictViewKind,
    /// Keepalive for a dict-*subclass* receiver: the view holds only the
    /// native `DictData` payload, so without this the subclass instance
    /// (and its `__del__`) would fire as soon as `A(dict)().keys()`
    /// returns (test_dict test_free_after_iterating).
    pub owner: Option<Object>,
}

/// Set-like equality for `dict_keys` / `dict_items` views (CPython
/// `dictview_richcompare`). A `dict_keys` view equals another keys view
/// when they hold the same *set* of keys (order-independent); a
/// `dict_items` view equals another items view when they hold the same set
/// of `(key, value)` pairs — i.e. dict equality. `dict_values` views are
/// **not** set-like and only ever compare equal by identity, so they fall
/// through to the caller's identity tail.
fn dict_view_set_eq(a: &PyDictView, b: &PyDictView) -> bool {
    if a.kind != b.kind {
        return false;
    }
    match a.kind {
        DictViewKind::Values => false,
        DictViewKind::Keys => {
            let da = a.dict.borrow();
            let db = b.dict.borrow();
            da.len() == db.len() && da.iter().all(|(k, _)| db.contains_key(k))
        }
        DictViewKind::Items => {
            let da = a.dict.borrow();
            let db = b.dict.borrow();
            da.len() == db.len()
                && da.iter().all(|(k, v)| match db.get(k) {
                    Some(v2) => v.is_same(v2) || v.eq_value(v2),
                    None => false,
                })
        }
    }
}

/// Internal payload for [`Object::StaticMethod`] / [`Object::ClassMethod`].
///
/// Besides the wrapped callable, CPython's `classmethod` and
/// `staticmethod` objects carry a real instance `__dict__` which the
/// constructor seeds with the functools-wrapper attributes copied from
/// the wrapped function (bpo-43682). Arbitrary attributes can be set on
/// the wrapper afterwards (`cm.x = 42`).
#[derive(Debug)]
pub struct MethodWrapper {
    /// The wrapped callable. Interior-mutable because CPython's
    /// `classmethod`/`staticmethod` set `sm_callable`/`cm_callable` in
    /// `__init__` (not `__new__`), so a subclass that overrides
    /// `__init__` without chaining leaves `__func__` as `None`
    /// (test_descr `test_classmethod_new` / `test_staticmethod_new`).
    func: RefCell<Object>,
    pub dict: Rc<RefCell<DictData>>,
}

impl MethodWrapper {
    pub fn new(func: Object) -> Rc<Self> {
        let dict = Self::wrapper_dict_for(&func);
        Rc::new(Self {
            func: RefCell::new(func),
            dict: Rc::new(RefCell::new(dict)),
        })
    }

    /// CPython's `functools.WRAPPER_ASSIGNMENTS` copy that `cm_init` /
    /// `sm_init` perform: seed the wrapper's instance dict from the
    /// wrapped callable.
    fn wrapper_dict_for(func: &Object) -> DictData {
        match func {
            // Copy `functools.WRAPPER_ASSIGNMENTS` from a plain function
            // (CPython skips attributes the callable doesn't have, and
            // only functions are guaranteed to carry all five).
            Object::Function(f) => {
                let code = f.code();
                // Computed lazily, then pinned to the function's slots so
                // `wrapper.__name__ is func.__name__` style identity
                // checks hold (CPython stores one object per attribute).
                let pinned = |name: &'static str, compute: &dyn Fn() -> Object| {
                    f.slot(name).unwrap_or_else(|| {
                        let v = compute();
                        f.set_slot(name, v.clone());
                        v
                    })
                };
                let name = pinned("__name__", &|| Object::from_str(f.name.clone()));
                let qualname = pinned("__qualname__", &|| Object::from_str(code.qualname.clone()));
                let module = pinned("__module__", &|| {
                    f.globals
                        .borrow()
                        .get(&DictKey(Object::from_static("__name__")))
                        .cloned()
                        .unwrap_or(Object::None)
                });
                let doc = pinned("__doc__", &|| {
                    crate::builtins::code_docstring(&code).unwrap_or(Object::None)
                });
                // 3.14 (PEP 749, gh-125017): `__annotations__` and
                // `__annotate__` are no longer copied eagerly; they are
                // getsets that lazily pull from the wrapped callable and
                // cache the result in the wrapper's dict (see `load_attr`).
                [
                    ("__module__", module),
                    ("__name__", name),
                    ("__qualname__", qualname),
                    ("__doc__", doc),
                ]
                .into_iter()
                .map(|(k, v)| (DictKey(Object::from_static(k)), v))
                .collect()
            }
            // Builtin callables: no seeding. (Also load-bearing: these
            // wrappers are built *during* `builtin_types()` init, so
            // this arm must not call back into the type registry.)
            Object::Builtin(_) => DictData::default(),
            // Non-function callables only carry the attributes they
            // actually have; for builtin singletons/values that is just
            // the type docstring (`staticmethod(None).__dict__` ==
            // `{'__doc__': None.__doc__}`).
            other => {
                let cls = crate::builtins::class_of(other);
                match crate::builtin_type_doc(&cls.name) {
                    Some(doc) if cls.flags.is_builtin => [(
                        DictKey(Object::from_static("__doc__")),
                        Object::from_static(doc),
                    )]
                    .into_iter()
                    .collect(),
                    _ => DictData::default(),
                }
            }
        }
    }

    /// The wrapped callable (a clone of the current value).
    pub fn func(&self) -> Object {
        self.func.borrow().clone()
    }

    /// Replace the wrapped callable and re-seed the wrapper dict from it,
    /// matching CPython's `cm_init`/`sm_init` (which set the callable and
    /// run the functools-wraps copy). A subclass that overrides
    /// `__init__` without chaining never reaches here, so its `__func__`
    /// stays `None`.
    pub fn set_func(&self, func: Object) {
        *self.dict.borrow_mut() = Self::wrapper_dict_for(&func);
        *self.func.borrow_mut() = func;
    }
}

/// Internal payload for [`Object::Property`].
///
/// All four members are interior-mutable: CPython's `property.__doc__`
/// is a writable member (`namedtuple` field docs are patched in place:
/// `Point.x.__doc__ = …`), and `property_init` *re-initialises the
/// existing object* — a `property` subclass whose `__init__` chains
/// `super().__init__(fget, doc=doc)` (werkzeug's `cached_property`)
/// mutates the descriptor that `type.__call__` already allocated.
#[derive(Debug)]
pub struct PyProperty {
    pub fget: RefCell<Object>,
    pub fset: RefCell<Object>,
    pub fdel: RefCell<Object>,
    pub doc: RefCell<Object>,
    /// CPython 3.13 `prop_name` (gh-98963): recorded by `__set_name__`
    /// during class creation and surfaced as `prop.__name__` and in the
    /// "property 'x' of 'C' object has no getter" error family. `None`
    /// means *unset* (distinct from an explicit `p.__name__ = None`,
    /// which stores `Some(Object::None)`).
    pub name: RefCell<Option<Object>>,
    /// CPython `getter_doc`: whether `doc` was harvested from the
    /// getter's `__doc__` (as opposed to passed explicitly). Drives
    /// `property_copy`: a getter-derived doc is *not* carried over to
    /// the copy, so the new getter's own docstring wins.
    pub getter_doc: Cell<bool>,
}

impl Drop for PyProperty {
    fn drop(&mut self) {
        // See `BuiltinFn::drop`.
        crate::descr_registry::forget(std::ptr::from_ref(self).cast::<()>() as usize);
    }
}

impl PyProperty {
    pub fn new(fget: Object, fset: Object, fdel: Object, doc: Object) -> Self {
        Self {
            fget: RefCell::new(fget),
            fset: RefCell::new(fset),
            fdel: RefCell::new(fdel),
            doc: RefCell::new(doc),
            name: RefCell::new(None),
            getter_doc: Cell::new(false),
        }
    }

    /// Current getter.
    pub fn fget(&self) -> Object {
        self.fget.borrow().clone()
    }

    /// Current setter.
    pub fn fset(&self) -> Object {
        self.fset.borrow().clone()
    }

    /// Current deleter.
    pub fn fdel(&self) -> Object {
        self.fdel.borrow().clone()
    }

    /// Current `__doc__` value.
    pub fn doc(&self) -> Object {
        self.doc.borrow().clone()
    }

    /// CPython `property_init`: replace all four members in place and
    /// forget any `__set_name__`-recorded name (re-initialisation makes
    /// the descriptor anonymous again).
    pub fn reinit(&self, fget: Object, fset: Object, fdel: Object, doc: Object) {
        *self.fget.borrow_mut() = fget;
        *self.fset.borrow_mut() = fset;
        *self.fdel.borrow_mut() = fdel;
        *self.doc.borrow_mut() = doc;
        *self.name.borrow_mut() = None;
        self.getter_doc.set(false);
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PropertyAttr {
    Get,
    Set,
    Del,
}

/// Internal payload for [`Object::SlotDescriptor`].
#[derive(Debug)]
pub struct SlotDescriptor {
    /// The attribute name this slot guards. Used both for storage in
    /// the instance dict and for error messages.
    pub name: String,
    /// The class that declared this slot, kept by name for nicer
    /// error messages (we do not need a hard reference back to the
    /// type for correctness).
    pub class_name: String,
    /// Value reported when the slot is unset. `__slots__` members have
    /// none (an unset slot raises `AttributeError`); the exception
    /// pseudo-slots (`BaseException.args`/`__context__`/`errno`/…)
    /// mirror CPython's getset/member defaults — `()`, `None`, `False`
    /// — so a freshly constructed, never-raised instance still answers.
    pub default: Option<Object>,
    /// CPython `Py_READONLY` members (`BaseExceptionGroup.message` /
    /// `.exceptions`): attribute assignment and deletion raise
    /// `AttributeError("readonly attribute")`; only internal
    /// `slot_set` writes land.
    pub readonly: bool,
    /// Docstring surfaced as `__doc__` — the `__dict__`/`__weakref__`
    /// getsets carry CPython's fixed text ("dictionary for instance
    /// variables", …); plain `__slots__` members have none. pydoc
    /// renders it under the descriptor's summary line.
    pub doc: Option<&'static str>,
    /// The declaring type, for `__objclass__`. Weak: the type's dict
    /// owns the descriptor, so a strong ref would be a guaranteed
    /// cycle. `None` for descriptors built before their type exists
    /// (exception pseudo-slots), which resolve by `class_name` instead.
    pub objclass: RefCell<Option<crate::sync::Weak<crate::types::TypeObject>>>,
}

/// Ordered set backing for [`Object::Set`] and [`Object::FrozenSet`].
/// Fast-hashed for the same reason as [`DictData`].
pub type SetData = indexmap::IndexSet<DictKey, crate::fasthash::FxBuildHasher>;

/// Backing object for [`Object::FrozenSet`]: the element storage plus a
/// lazily-computed hash cache.
///
/// CPython caches `frozenset_hash` in the object's `so_hash` field
/// (`Objects/setobject.c`) because a frozenset is immutable, so its hash
/// never changes. Without that cache, `hash()` re-walks the whole
/// structure every call — and for *nested* frozensets (e.g. the von
/// Neumann ordinals built by `test_set`'s `test_hash_effectiveness`) the
/// recursion is exponential, turning a sub-second test into minutes.
///
/// [`Deref`](std::ops::Deref)s to [`SetData`] so the many read sites that
/// call `.iter()`/`.len()`/`.contains()` keep working unchanged.
pub struct FrozenSetObj {
    data: SetData,
    /// `None` until the first `hash()`; then the bit-exact CPython hash.
    hash: crate::sync::CachedHash,
}

impl FrozenSetObj {
    pub fn new(data: SetData) -> Self {
        Self {
            data,
            hash: crate::sync::CachedHash::new(None),
        }
    }

    /// The cached hash, if it has already been computed.
    pub fn cached_hash(&self) -> Option<i64> {
        self.hash.get()
    }

    /// Memoise the computed hash for subsequent `hash()` calls.
    pub fn store_hash(&self, value: i64) {
        self.hash.store(value);
    }
}

impl std::ops::Deref for FrozenSetObj {
    type Target = SetData;
    fn deref(&self) -> &SetData {
        &self.data
    }
}

impl std::fmt::Debug for FrozenSetObj {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_set().entries(self.data.iter()).finish()
    }
}

// ---------- supporting types ----------

/// Rectangular-form complex number (RFC 0019). CPython's
/// `complex` is also stored as `(double real, double imag)`; we
/// match the layout for compatibility.
#[derive(Debug, Clone, Copy)]
pub struct PyComplex {
    pub real: f64,
    pub imag: f64,
}

impl PyComplex {
    pub fn new(real: f64, imag: f64) -> Self {
        Self { real, imag }
    }

    /// Construct from a `(real, imag)` tuple. Convenience for the
    /// many call sites that build one inline.
    pub fn from_tuple(t: (f64, f64)) -> Self {
        Self {
            real: t.0,
            imag: t.1,
        }
    }
}

/// `range(...)` bounds. `i128` so ranges straddling the `i64` boundary
/// (`range(sys.maxsize - 5, sys.maxsize + 5)`) still work; elements that
/// don't fit `i64` materialise as `Object::Long`. CPython supports
/// arbitrary ints here; bounds past `i128` (test_range's `2**200` /
/// `sys.maxsize**10` cases) spill into `big`, keeping the in-range
/// iteration fast path allocation-free for every realistic range.
#[derive(Debug, Clone)]
pub struct Range {
    pub start: i128,
    pub stop: i128,
    pub step: i128,
    /// Arbitrary-precision `(start, stop, step)` when any bound exceeds
    /// `i128`. The `i128` mirrors then hold *saturated* values (clamped
    /// to the `i128` limits) so direction/emptiness checks that only
    /// compare signs stay truthful; every value-producing operation must
    /// consult this triple first (via [`Range::bounds`] and friends).
    pub big: Option<Box<(BigInt, BigInt, BigInt)>>,
}

impl Range {
    pub fn new(start: i128, stop: i128, step: i128) -> Self {
        Self {
            start,
            stop,
            step,
            big: None,
        }
    }

    pub fn from_bigints(start: BigInt, stop: BigInt, step: BigInt) -> Self {
        use num_traits::ToPrimitive;
        match (start.to_i128(), stop.to_i128(), step.to_i128()) {
            (Some(a), Some(b), Some(c)) => Self::new(a, b, c),
            _ => {
                let clamp = |b: &BigInt| -> i128 {
                    b.to_i128()
                        .unwrap_or(if b.sign() == num_bigint::Sign::Minus {
                            i128::MIN
                        } else {
                            i128::MAX
                        })
                };
                Self {
                    start: clamp(&start),
                    stop: clamp(&stop),
                    step: clamp(&step),
                    big: Some(Box::new((start, stop, step))),
                }
            }
        }
    }

    /// The `(start, stop, step)` triple at full precision.
    pub fn bounds(&self) -> (BigInt, BigInt, BigInt) {
        match &self.big {
            Some(b) => (b.0.clone(), b.1.clone(), b.2.clone()),
            None => (
                BigInt::from(self.start),
                BigInt::from(self.stop),
                BigInt::from(self.step),
            ),
        }
    }

    pub fn start_obj(&self) -> Object {
        match &self.big {
            Some(b) => Object::int_from_bigint(b.0.clone()),
            None => int_from_i128(self.start),
        }
    }

    pub fn stop_obj(&self) -> Object {
        match &self.big {
            Some(b) => Object::int_from_bigint(b.1.clone()),
            None => int_from_i128(self.stop),
        }
    }

    pub fn step_obj(&self) -> Object {
        match &self.big {
            Some(b) => Object::int_from_bigint(b.2.clone()),
            None => int_from_i128(self.step),
        }
    }
}

/// Collect an exact range whose bounds fit the inline integer lane.
/// Wider bounds and iterator objects keep their existing collection paths.
pub(crate) fn collect_small_int_range(value: &Object) -> Option<Result<Vec<Object>, RuntimeError>> {
    let Object::Range(range) = value else {
        return None;
    };
    if range.big.is_some() || range.step == 0 {
        return None;
    }
    let start = i128::from(i64::try_from(range.start).ok()?);
    let stop = i128::from(i64::try_from(range.stop).ok()?);
    let step = i128::from(i64::try_from(range.step).ok()?);
    // The widened arithmetic also handles opposite i64 endpoints and
    // i64::MIN steps without overflowing the span or its absolute step.
    let len = if step > 0 && start < stop {
        (stop - start - 1) / step + 1
    } else if step < 0 && start > stop {
        (start - stop - 1) / -step + 1
    } else {
        0
    };
    let Ok(len) = isize::try_from(len) else {
        return Some(Err(crate::error::overflow_error(
            "Python int too large to convert to C ssize_t",
        )));
    };
    let len = len as usize;
    let mut items = Vec::new();
    if items.try_reserve_exact(len).is_err() {
        return Some(Err(crate::error::memory_error(String::new())));
    }
    let mut current = start;
    for _ in 0..len {
        // Every yielded value lies between the checked i64 bounds.
        // The final advance may cross an endpoint, so keep it in i128.
        items.push(Object::Int(current as i64));
        current += step;
    }
    Some(Ok(items))
}

/// Full-precision element count of `r` (CPython `compute_range_length`
/// without the `Py_ssize_t` clamp). The `big`-aware sibling of
/// [`range_len_i128`]; used wherever a big-bounded range can reach.
pub(crate) fn range_len_bigint(r: &Range) -> BigInt {
    let (start, stop, step) = r.bounds();
    let zero = BigInt::from(0);
    let span = if step > zero {
        (stop - &start).max(zero.clone())
    } else if step < zero {
        (start - &stop).max(zero.clone())
    } else {
        return zero;
    };
    if span == zero {
        return zero;
    }
    let step_abs = step.magnitude().clone();
    let step_abs = BigInt::from(step_abs);
    (span + &step_abs - 1) / step_abs
}

/// An int object from an `i128`: machine `Int` when it fits, `Long`
/// otherwise.
pub fn int_from_i128(v: i128) -> Object {
    match i64::try_from(v) {
        Ok(x) => Object::Int(x),
        Err(_) => Object::Long(Rc::new(num_bigint::BigInt::from(v))),
    }
}

/// Number of elements a `range` yields, as an `i128` (never negative;
/// `0` for an empty or zero-step range). Mirrors CPython's
/// `compute_range_length` and is shared by `range` equality *and*
/// hashing so the two always agree (`hash` must match `==`).
pub(crate) fn range_len_i128(r: &Range) -> i128 {
    let span = if r.step > 0 {
        (r.stop - r.start).max(0)
    } else if r.step < 0 {
        (r.start - r.stop).max(0)
    } else {
        return 0;
    };
    if span == 0 {
        return 0;
    }
    let step = r.step.unsigned_abs() as i128;
    (span + step - 1) / step
}

/// Run any tripped Python signal handler on the main thread, mirroring
/// `os::service_pending_signals`. Used by the buffered-write flush so an
/// `EINTR` from a blocking `write(2)` runs the handler before retrying
/// (PEP 475). A handler that raises (e.g. a `SIGALRM` doing `1/0`) returns
/// that error here, so the flush abandons the write instead of looping.
#[cfg(unix)]
fn service_pending_signals_io() -> Result<(), RuntimeError> {
    if !crate::gil::is_main_thread() || !crate::stdlib::signal_mod::signals_pending() {
        return Ok(());
    }
    if let Some(ptr) = crate::vm_singletons::current_interpreter_ptr() {
        // SAFETY: published by the active builtin call on this (main) thread;
        // the interpreter outlives this synchronous re-entrant call, matching
        // the `os`/`select`/`_thread` blocking-signal pattern.
        let interp = unsafe { &mut *ptr };
        interp.run_pending_signals_public()?;
    }
    Ok(())
}

/// Acquire a [`PyFile::fd_syscall_lock`], immune to poisoning (a panicking
/// holder can't corrupt a `()` payload). Must only be called with the GIL
/// released: a holder may be blocked in a syscall (pipe read/full-pipe write)
/// indefinitely, and waiting for it while holding the GIL would stall every
/// thread. This is CPython's `ENTER_BUFFERED` (grab the buffered object's
/// lock under `Py_BEGIN_ALLOW_THREADS`).
#[cfg(unix)]
fn fd_lock(lock: &std::sync::Mutex<()>) -> std::sync::MutexGuard<'_, ()> {
    lock.lock().unwrap_or_else(|e| e.into_inner())
}

/// Blocking `read(2)` from a raw descriptor honouring PEP 475: release the
/// GIL across the (possibly blocking) syscall, and on `EINTR` run any tripped
/// Python signal handler and retry instead of surfacing `InterruptedError`
/// (test_io `check_interrupted_read_retry`: a `SIGALRM` handler feeds the
/// pipe and the interrupted read must resume and deliver those bytes). A
/// handler that raises propagates and abandons the read. `n = None` reads to
/// EOF. The borrow on the file's backend is *not* held here, so a handler
/// touching the same stream can't trip a `BorrowMutError`. The `read(2)`
/// itself runs under the stream's [`PyFile::fd_syscall_lock`] so it can never
/// interleave with a concurrent `write(2)`/`lseek(2)` on the same file
/// description (see the field's doc for the offset race this prevents).
#[cfg(unix)]
fn read_fd_intr(
    fd: std::os::unix::io::RawFd,
    n: Option<usize>,
    lock: &std::sync::Mutex<()>,
) -> Result<Vec<u8>, RuntimeError> {
    let read_once = |buf: &mut [u8]| -> Result<usize, RuntimeError> {
        loop {
            let r = crate::gil::allow_threads_then(|| {
                let _serialized = fd_lock(lock);
                unsafe { libc::read(fd, buf.as_mut_ptr().cast(), buf.len()) }
            });
            if r >= 0 {
                return Ok(r as usize);
            }
            let err = std::io::Error::last_os_error();
            if err.raw_os_error() == Some(libc::EINTR) {
                service_pending_signals_io()?;
                continue;
            }
            // Carry the errno so a stale descriptor surfaces as
            // `OSError(EBADF)` (test_fileio `testErrnoOnClosedRead`).
            return Err(crate::error::io_error_to_py(&err));
        }
    };
    match n {
        Some(0) => Ok(Vec::new()),
        Some(n) => {
            let mut buf = vec![0u8; n];
            let k = read_once(&mut buf)?;
            buf.truncate(k);
            Ok(buf)
        }
        None => {
            let mut out = Vec::new();
            let mut chunk = vec![0u8; 64 * 1024];
            loop {
                let k = read_once(&mut chunk)?;
                if k == 0 {
                    return Ok(out);
                }
                out.extend_from_slice(&chunk[..k]);
            }
        }
    }
}

/// Drain `pending` to a raw descriptor, removing the written prefix in place,
/// and honouring PEP 475: release the GIL across each (possibly blocking)
/// `write(2)` so peers run, and on `EINTR` run any tripped Python signal
/// handler before retrying. A `SIGALRM` handler that raises then abandons a
/// write blocked on a full pipe instead of looping forever — exactly what
/// `test_io`'s `SignalsTest.test_interrupted_write_buffered` exercises (a
/// buffered flush is one big `write` to a saturated pipe).
///
/// On a non-blocking would-block (`EAGAIN`/`EWOULDBLOCK`) it stops, leaves the
/// unwritten remainder in `pending`, and returns the canonical
/// `BlockingIOError(EAGAIN, …, 0)`; the caller restores the remainder and
/// reports `characters_written` (`_pyio.BufferedWriter._flush_unlocked` →
/// `BufferedWriter.write`, `test_io.test_nonblock_pipe_write_*`). The written
/// prefix is always drained from `pending` first — including when a signal
/// handler raises mid-flush — so the remainder is never double-written. The
/// descriptor is borrowed, not owned, so the backing `File` must outlive it.
/// Each `write(2)` runs under the stream's [`PyFile::fd_syscall_lock`] so it
/// can never interleave with a concurrent `read(2)`/`lseek(2)` on the same
/// file description (see the field's doc for the offset race this prevents).
#[cfg(unix)]
fn write_drain_fd_intr(
    fd: std::os::unix::io::RawFd,
    pending: &mut Vec<u8>,
    lock: &std::sync::Mutex<()>,
) -> Result<(), RuntimeError> {
    let mut off = 0usize;
    let res = loop {
        if off >= pending.len() {
            break Ok(());
        }
        let chunk = &pending[off..];
        let r = crate::gil::allow_threads_then(|| {
            let _serialized = fd_lock(lock);
            unsafe { libc::write(fd, chunk.as_ptr().cast(), chunk.len()) }
        });
        if r < 0 {
            let err = std::io::Error::last_os_error();
            let code = err.raw_os_error();
            if code == Some(libc::EINTR) {
                if let Err(e) = service_pending_signals_io() {
                    break Err(e);
                }
                continue;
            }
            if code == Some(libc::EAGAIN) || code == Some(libc::EWOULDBLOCK) {
                break Err(crate::error::blocking_io_error_written(
                    libc::EAGAIN,
                    "write could not complete without blocking",
                    0,
                ));
            }
            break Err(crate::error::io_error_to_py(&err));
        }
        // A 0-length `write` only happens for an empty `chunk`, which the loop
        // guard already excludes; treat a defensive 0 as completion.
        if r == 0 {
            break Ok(());
        }
        off += r as usize;
        // Run pending Python signal handlers after *every* partial write, not
        // just on `EINTR`. When a reader frees one byte of a saturated pipe,
        // the blocked `write` returns a successful *partial* result rather
        // than `EINTR` (see `test_io` `check_interrupted_write`); the buffered
        // layer must still check signals so a `SIGALRM` handler that raises
        // (`1/0`) surfaces here instead of re-blocking on the full pipe
        // forever. A handler that raises returns its error and abandons the
        // remaining write, exactly like CPython's buffered-writer flush.
        if let Err(e) = service_pending_signals_io() {
            break Err(e);
        }
    };
    pending.drain(..off.min(pending.len()));
    res
}

/// EAGAIN value to default to when a `BlockingIOError` lacks an explicit
/// `errno` (it never should — the flush always sets it — but be defensive).
#[cfg(unix)]
const EAGAIN_FALLBACK: i32 = libc::EAGAIN;
#[cfg(not(unix))]
const EAGAIN_FALLBACK: i32 = 11;

/// True when `err` is a `BlockingIOError` instance (so the buffered-writer
/// `write` can mirror `_pyio.BufferedWriter.write`'s `except BlockingIOError`
/// partial-write accounting).
fn runtime_err_is_blocking(err: &RuntimeError) -> bool {
    if let RuntimeError::PyException(pe) = err {
        if let Object::Instance(inst) = &pe.instance {
            return inst
                .cls()
                .is_subclass_of(&crate::builtin_types::builtin_types().blocking_io_error);
        }
    }
    false
}

/// Read `e.errno` / `e.strerror` off a `BlockingIOError` so a re-raised
/// 3-arg `BlockingIOError(errno, strerror, characters_written)` preserves them.
fn runtime_err_eagain_info(err: &RuntimeError) -> (i32, String) {
    if let RuntimeError::PyException(pe) = err {
        if let Object::Instance(inst) = &pe.instance {
            let errno = crate::builtin_types::exc_attr(inst, "errno")
                .as_ref()
                .and_then(Object::as_i64)
                .unwrap_or(i64::from(EAGAIN_FALLBACK)) as i32;
            let strerror = match crate::builtin_types::exc_attr(inst, "strerror") {
                Some(Object::Str(s)) => s.to_string(),
                _ => "write could not complete without blocking".to_owned(),
            };
            return (errno, strerror);
        }
    }
    (
        EAGAIN_FALLBACK,
        "write could not complete without blocking".to_owned(),
    )
}

/// Whether a descriptor is in non-blocking mode (`O_NONBLOCK`). Used to keep
/// the common blocking-file read path untouched: only a non-blocking fd needs
/// the would-block → `None` handling below.
#[cfg(unix)]
fn fd_is_nonblocking(fd: std::os::unix::io::RawFd) -> bool {
    let flags = unsafe { libc::fcntl(fd, libc::F_GETFL) };
    flags >= 0 && (flags & libc::O_NONBLOCK) != 0
}

/// Read from a *non-blocking* descriptor, mapping a would-block
/// (`EAGAIN`/`EWOULDBLOCK`) to CPython's raw-`read` semantics: `Ok(None)` when
/// nothing could be read yet, `Ok(Some(data))` for a (possibly partial) read,
/// and `Ok(Some(b""))` at EOF. PEP 475: a tripped signal handler runs on
/// `EINTR` / after each chunk and may abandon the read by raising.
/// (`test_io.test_nonblock_pipe_write_*` reads a saturated pipe to drain it,
/// then relies on `iter(rf.read, None)` terminating on the would-block `None`.)
#[cfg(unix)]
fn read_fd_nonblock(
    fd: std::os::unix::io::RawFd,
    n: Option<usize>,
    lock: &std::sync::Mutex<()>,
) -> Result<Option<Vec<u8>>, RuntimeError> {
    match n {
        Some(want) => {
            if want == 0 {
                return Ok(Some(Vec::new()));
            }
            let mut buf = vec![0u8; want];
            loop {
                let r = crate::gil::allow_threads_then(|| {
                    let _serialized = fd_lock(lock);
                    unsafe { libc::read(fd, buf.as_mut_ptr().cast(), want) }
                });
                if r < 0 {
                    let err = std::io::Error::last_os_error();
                    let code = err.raw_os_error();
                    if code == Some(libc::EINTR) {
                        service_pending_signals_io()?;
                        continue;
                    }
                    if code == Some(libc::EAGAIN) || code == Some(libc::EWOULDBLOCK) {
                        return Ok(None);
                    }
                    return Err(os_error(format!("read: {err}")));
                }
                buf.truncate(r as usize);
                return Ok(Some(buf));
            }
        }
        None => {
            // read-all: drain until EOF or would-block, returning the bytes
            // gathered so far (or `None` if the very first read would block).
            let mut out = Vec::new();
            let mut chunk = [0u8; 8192];
            loop {
                let r = crate::gil::allow_threads_then(|| {
                    let _serialized = fd_lock(lock);
                    unsafe { libc::read(fd, chunk.as_mut_ptr().cast(), chunk.len()) }
                });
                if r < 0 {
                    let err = std::io::Error::last_os_error();
                    let code = err.raw_os_error();
                    if code == Some(libc::EINTR) {
                        service_pending_signals_io()?;
                        continue;
                    }
                    if code == Some(libc::EAGAIN) || code == Some(libc::EWOULDBLOCK) {
                        return Ok(if out.is_empty() { None } else { Some(out) });
                    }
                    return Err(os_error(format!("read: {err}")));
                }
                if r == 0 {
                    return Ok(Some(out));
                }
                out.extend_from_slice(&chunk[..r as usize]);
                service_pending_signals_io()?;
            }
        }
    }
}

/// A loaded Python module: a name, an optional source filename, and
/// a dict that doubles as `module.__dict__` and the globals namespace
/// of code that runs *inside* the module.
///
/// Built-in modules (`sys`, `math`, …) have `filename = None`; modules
/// loaded from a `.py` file carry the path used to find them. Modules
/// are cheap-to-clone via the wrapping `Rc`, and identity (`is`)
/// reduces to pointer equality on that `Rc`.
pub struct PyModule {
    pub name: String,
    pub filename: Option<String>,
    pub dict: Rc<RefCell<DictData>>,
}

impl fmt::Debug for PyModule {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "<module {:?}>", self.name)
    }
}

/// `module.__class__ = ModuleSubclass` support (RFC 0076 WS5). CPython's
/// `object_set_class` waives the layout guard when both classes are
/// `ModuleType` subtypes, and torch's config system leans on it:
/// `install_config_module` re-points every `torch.*.config` module at a
/// `ConfigModule` subclass whose `__getattr__`/`__setattr__` serve the
/// config entries. `PyModule` has no class field (modules predate the
/// feature and are built in ~100 places), so the assigned class lives in
/// this side registry keyed by `Rc` identity. Process-global: modules
/// cross threads through the import cache, and a worker thread's
/// `torch._dynamo` import must observe the class the main thread set.
/// Modules are effectively immortal (the import cache pins them), so
/// stale-key reuse is not a practical concern.
static MODULE_CLASS: std::sync::LazyLock<
    parking_lot::RwLock<std::collections::HashMap<usize, Object>>,
> = std::sync::LazyLock::new(|| parking_lot::RwLock::new(std::collections::HashMap::new()));

/// Record `m.__class__ = cls`. The caller validates that `cls` is a
/// `ModuleType` subclass.
pub fn set_module_class(m: &Rc<PyModule>, cls: Object) {
    MODULE_CLASS.write().insert(Rc::as_ptr(m) as usize, cls);
}

/// The class assigned via [`set_module_class`], if any. `None` means the
/// stock `types.ModuleType`.
pub fn module_class(m: &Rc<PyModule>) -> Option<Rc<crate::types::TypeObject>> {
    match MODULE_CLASS.read().get(&(Rc::as_ptr(m) as usize)) {
        Some(Object::Type(t)) => Some(t.clone()),
        _ => None,
    }
}

/// Dictionary key: a hashable [`Object`] wrapped to satisfy the
/// `Hash + Eq` requirements imposed by `HashMap` / `IndexMap`.
#[derive(Clone, Debug)]
pub struct DictKey(pub Object);

/// Zero-allocation probe key for `str`-keyed [`DictData`] lookups.
///
/// `map.get(&StrKey(name))` replaces the historic
/// `map.get(&crate::object::StrKey(name))`, which heap-allocated a
/// fresh `SharedStr` *per probe* — measurable on every attribute/global
/// lookup. Hash must mirror [`DictKey`]'s exactly for `Object::Str`
/// (the canonical Python hash fed to the table hasher), so a probe
/// lands in the same bucket as the stored key.
///
/// Equality is *faithful* to [`DictKey`]'s: the overwhelmingly common
/// stored plain `Object::Str` compares natively (pure, never re-enters
/// Python), and only a hash-colliding exotic stored key (a `str`
/// subclass instance, a hash-mimicking object) falls back to the full
/// `DictKey` comparison — allocating the temporary `Object::Str` and
/// possibly dispatching Python `__eq__`, exactly as the old probe did.
/// Callers holding sensitive borrows across a probe can consult
/// [`exotic_str_keys_possible`] to know whether the re-entrant branch
/// is reachable for class dicts.
#[derive(Debug, Clone, Copy)]
pub struct StrKey<'a>(pub &'a str);

impl Hash for StrKey<'_> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        // Bit-for-bit the `DictKey` hash of `Object::Str(self.0)`.
        py_str_hash(self.0).hash(state);
    }
}

impl indexmap::Equivalent<DictKey> for StrKey<'_> {
    #[inline]
    fn equivalent(&self, key: &DictKey) -> bool {
        match &key.0 {
            Object::Str(s) => &**s == self.0,
            // A `WStr` always carries a lone surrogate (module invariant),
            // so it can never equal a valid `&str`.
            Object::WStr(_) => false,
            // Exotic stored key sharing the bucket: defer to the full
            // `DictKey` comparison (identity, native value, Python
            // `__eq__`). Rare enough that the temporary allocation is
            // irrelevant.
            _ => DictKey(Object::from_str(self.0)) == *key,
        }
    }
}

/// [`StrKey`] with its Python hash precomputed (RFC 0077 WS4). The
/// interpreter's attribute-name probes hash the same `co_names` entry on
/// every execution of a site — a siphash per probe — so the VM memoises
/// `py_str_hash` per code object (see `code_name_key` in the eval loop)
/// and probes with this key instead. Hash and equality are bit-for-bit
/// those of `StrKey`; the caller is responsible for `hash ==
/// py_str_hash(s)`.
#[derive(Debug, Clone, Copy)]
pub struct StrKeyHashed<'a> {
    pub s: &'a str,
    pub hash: i64,
}

impl Hash for StrKeyHashed<'_> {
    #[inline]
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.hash.hash(state);
    }
}

impl indexmap::Equivalent<DictKey> for StrKeyHashed<'_> {
    #[inline]
    fn equivalent(&self, key: &DictKey) -> bool {
        indexmap::Equivalent::equivalent(&StrKey(self.s), key)
    }
}

/// Count of "exotic" keys ever inserted into a *class* dict: any key
/// that is not a plain `Object::Str`. While zero (every real-world
/// program), `TypeObject::lookup`'s native [`StrKey`] walk is
/// authoritative and the Python-`__eq__` fallback probe is skipped
/// entirely. Bumped by the class-creation seams that can accept an
/// arbitrary mapping namespace (`type(name, bases, ns)`, class bodies
/// with computed keys); monotone, never reset.
static EXOTIC_CLASS_KEYS: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Record that `key` is entering a class dict; bumps the global exotic
/// counter when it is not a plain interned-string key.
#[inline]
pub fn note_class_dict_key(key: &DictKey) {
    if !matches!(key.0, Object::Str(_)) {
        EXOTIC_CLASS_KEYS.fetch_add(1, std::sync::atomic::Ordering::AcqRel);
    }
}

/// True once any class dict anywhere has held a non-`str` key, i.e.
/// the moment `StrKey`-only MRO walks stop being authoritative for
/// misses.
#[inline]
pub fn exotic_str_keys_possible() -> bool {
    EXOTIC_CLASS_KEYS.load(std::sync::atomic::Ordering::Acquire) != 0
}

/// Reach for the running interpreter to compute a user instance's Python
/// `__hash__`. `DictKey`'s `Hash`/`Eq` impls have no interpreter handle, so
/// they borrow the thread's published interpreter pointer — the same bridge
/// `_imp`/`_thread`/the C-API iterator use. Returns `None` when no
/// interpreter is active (e.g. a dict built from pure-Rust setup), so the
/// caller falls back to the native structural behaviour.
fn current_interp_hash(obj: &Object) -> Option<i64> {
    let ptr = crate::vm_singletons::current_interpreter_ptr()?;
    // SAFETY: the pointer is published by the bytecode dispatch loop for the
    // running thread and used only to re-enter the interpreter synchronously,
    // mirroring the established reentrant-callback pattern in `_imp`/`_thread`.
    let interp = unsafe { &mut *ptr };
    // RFC 0039 (WS5): this re-entrant `__hash__` may run while a `set`/`dict`
    // holds its `GilCell` mutex (we were called from `DictKey::hash` during an
    // insert/lookup). Suppress the cooperative GIL hand-off for its duration so
    // another thread can't take the GIL and then deadlock on that same mutex.
    let _no_yield = crate::gil::no_gil_handoff();
    interp.reentrant_py_hash(obj)
}

/// Companion to [`current_interp_hash`] for `a == b` via Python `__eq__`.
fn current_interp_eq(a: &Object, b: &Object) -> Option<bool> {
    let ptr = crate::vm_singletons::current_interpreter_ptr()?;
    // SAFETY: see `current_interp_hash`.
    let interp = unsafe { &mut *ptr };
    // RFC 0039 (WS5): same GIL ↔ cell-mutex hazard as `current_interp_hash` —
    // this `__eq__` can run while a container holds its borrow during a
    // collision check, so hold off the cooperative hand-off until it returns.
    let _no_yield = crate::gil::no_gil_handoff();
    interp.reentrant_py_eq(a, b)
}

/// True when `obj` is a user instance whose class supplies a *callable*
/// `name` dunder (a real Python `def`, not the inherited identity default).
/// Used to gate the reentrant `__eq__` dispatch so plain instances keep the
/// native identity fast path.
pub(crate) fn instance_has_custom_dunder(obj: &Object, name: &str) -> bool {
    let Object::Instance(inst) = obj else {
        return false;
    };
    match inst.cls().lookup_with_owner(name) {
        Some((Object::Function(_) | Object::BoundMethod(_), _)) => true,
        Some((Object::None, _)) | None => false,
        // A non-function dunder. A user class supplying it (e.g.
        // `unittest.mock` installs `Mock` instances as `__hash__` /
        // `__eq__` on per-instance subclasses) needs Python dispatch.
        Some((_, owner)) if !owner.flags.is_builtin => true,
        // A built-in type that *overrides* the dunder in its own dict
        // rather than inheriting `object`'s identity default needs Python
        // dispatch too: `weakref` compares/hashes by referent, so its
        // `ref` objects can't be keyed by the native identity path
        // (`test_weakref`/`test_weakset` rely on `ref(a) == ref(a)` and
        // matching hashes finding the same set slot). `object`'s own
        // `__eq__`/`__hash__` — where every *plain* instance resolves —
        // stay native so ordinary objects keep identity semantics, and
        // value-wrapping subclasses (`class C(int)`, struct sequences)
        // keep their native structural comparison via `native`.
        Some((_, owner)) => {
            inst.native.get().is_none()
                && !Rc::ptr_eq(&owner, &crate::builtin_types::builtin_types().object_)
        }
    }
}

/// True when a `set`/`dict` key needs Python-level `__eq__` dispatch rather
/// than the native [`Object::eq_value`] fast path: a foreign extension
/// scalar (numpy `int64`/`float64`/…), a user instance with a custom
/// `__eq__`, or a *hashable container* (`tuple`/`frozenset`) that
/// transitively holds one. `eq_value` compares only native pairs, so it
/// returns `false` for two distinct foreign scalars even when numpy's
/// `tp_richcompare` deems them equal; a `tuple` such as
/// `(np.int64(0), np.int64(1))` therefore never matched an equal stored key
/// (its hash *does* match — see [`DictKey::hash`]). That silently broke
/// `pd.IntervalIndex` uniqueness/dedup: `is_unique` keys `(left, right)`
/// numpy-scalar pairs in a `set`, and `intersection`/`_is_strictly_
/// monotonic_increasing` build on it. Recursion is bounded because only
/// immutable, bottom-up-built containers are hashable enough to be keys.
pub(crate) fn key_needs_interp_eq(obj: &Object) -> bool {
    match obj {
        Object::Foreign(_) => true,
        Object::Tuple(items) => items.iter().any(key_needs_interp_eq),
        Object::FrozenSet(s) => s.iter().any(|k| key_needs_interp_eq(&k.0)),
        // A PEP 604 union compares as a *set* of members (CPython
        // `union_richcompare`), including against typing's
        // `_UnionGenericAlias` — structural namespace equality can't
        // express either (RFC 0076 WS5).
        Object::SimpleNamespace(_) => crate::is_pep604_union(obj).is_some(),
        _ => instance_has_custom_dunder(obj, "__eq__"),
    }
}

/// `a == b` with CPython's `PyObject_RichCompareBool(a, b, Py_EQ)`
/// semantics, for sequence membership / `count` / `index`:
///
/// 1. identity first — `x is y` ⇒ equal (so `nan in [nan]` for the same
///    nan is `True`), then
/// 2. when either operand carries a user `__eq__`, dispatch the *full*
///    Python comparison (both directions, reflected `__eq__`), and
///    **propagate** any exception it raises (CPython's `list.count` /
///    `.index` let a `__eq__` exception escape), otherwise
/// 3. fall back to native structural equality.
///
/// The interpreter is reached through the published per-thread pointer —
/// the same bridge `DictKey`/`_thread`/the C-API use — so a plain
/// `fn(&[Object])` builtin can honour Python comparisons. With no active
/// interpreter (pure-Rust setup) it degrades to `eq_value`.
pub(crate) fn member_eq(a: &Object, b: &Object) -> Result<bool, RuntimeError> {
    if a.is_same(b) {
        return Ok(true);
    }
    // Dispatch the full Python comparison whenever an operand can carry
    // custom `__eq__` semantics: a pure-Python instance with a user dunder,
    // OR a foreign (C-extension) object whose `tp_richcompare` the native
    // `eq_value` fast path cannot see. Without the foreign case, `dtype in
    // (a, b)` / `[dtype].count(other)` compare a numpy dtype/scalar against a
    // primitive via `eq_value` (always unequal) even though `dtype == "int8"`
    // is `True` through the reflected richcompare. A matching *container*
    // pair can carry such an element at any depth (`[(1, Timestamp), …]
    // .index((1, Timestamp))` in pandas' `test_factorize`), so a
    // container-vs-container pair dispatches too — `deep_equal_collection`
    // recurses per element through the interpreter.
    fn deep_dispatch(o: &Object) -> bool {
        matches!(
            o,
            Object::Tuple(_) | Object::List(_) | Object::Dict(_) | Object::Slice(_)
        )
    }
    if instance_has_custom_dunder(a, "__eq__")
        || instance_has_custom_dunder(b, "__eq__")
        || matches!(a, Object::Foreign(_))
        || matches!(b, Object::Foreign(_))
        || (deep_dispatch(a) && deep_dispatch(b))
    {
        if let Some(ptr) = crate::vm_singletons::current_interpreter_ptr() {
            // SAFETY: see `current_interp_eq`.
            let interp = unsafe { &mut *ptr };
            let _no_yield = crate::gil::no_gil_handoff();
            return interp.reentrant_py_eq_bool(a, b);
        }
    }
    Ok(a.eq_value(b))
}

// ---- recursive-`repr` guard (CPython `Py_ReprEnter`/`Py_ReprLeave`) ----

struct ReprGuardState {
    /// Ids of containers whose `repr` is currently being rendered on this
    /// thread, so a self-referential container yields `[...]`/`{...}` rather
    /// than recursing forever.
    stack: Vec<usize>,
    /// Set when nesting reached `sys.getrecursionlimit()`; the outermost
    /// `repr`/`str` boundary turns it into a `RecursionError`.
    overflow: bool,
}

thread_local! {
    static REPR_GUARD: RefCell<ReprGuardState> =
        const { RefCell::new(ReprGuardState { stack: Vec::new(), overflow: false }) };
}

/// Begin rendering container `id`. Returns `false` when `id` is already being
/// rendered (a reference cycle — the caller emits its `…` marker) or when the
/// nesting depth has hit `sys.getrecursionlimit()` (sets the overflow flag, so
/// the boundary raises `RecursionError` instead of blowing the native stack).
fn repr_enter(id: usize) -> bool {
    // `try_with`: a leaked stream can drop during thread-local *destruction*
    // (its `Drop` renders a repr for the unclosed-file ResourceWarning); the
    // guard TLS may already be gone, and `with` would abort the process.
    // No guard means no cycle in flight — admit.
    REPR_GUARD
        .try_with(|g| {
            let mut b = g.borrow_mut();
            if b.stack.contains(&id) {
                return false;
            }
            if b.stack.len() >= crate::recursion::recursion_limit() {
                b.overflow = true;
                return false;
            }
            b.stack.push(id);
            true
        })
        .unwrap_or(true)
}

/// Finish rendering the container most recently admitted by [`repr_enter`].
fn repr_leave() {
    let _ = REPR_GUARD.try_with(|g| {
        g.borrow_mut().stack.pop();
    });
}

/// Render `f` at a Python-visible `repr()`/`str()` boundary, mapping a
/// recursion-limit overflow to `Err(())` (the caller raises `RecursionError`).
/// Only the *outermost* boundary clears/inspects the overflow flag, so a
/// user `__repr__` that itself calls `repr()` still shares one cycle stack.
pub(crate) fn repr_guarded<F: FnOnce() -> String>(f: F) -> Result<String, ()> {
    let outer = REPR_GUARD.with(|g| g.borrow().stack.is_empty());
    if outer {
        REPR_GUARD.with(|g| g.borrow_mut().overflow = false);
    }
    let s = f();
    let overflowed = outer && REPR_GUARD.with(|g| std::mem::take(&mut g.borrow_mut().overflow));
    if overflowed {
        Err(())
    } else {
        Ok(s)
    }
}

thread_local! {
    /// First exception raised by a user `__repr__` invoked from the
    /// *infallible* native renderer ([`Object::repr`] — container reprs,
    /// `%`-formatting, the `Debug` impl). Rust's `repr()` returns a plain
    /// `String`, so the error can't propagate the way CPython's
    /// `PyObject_Repr` does (returning NULL); it is parked here and the
    /// fallible boundary (`Vm::repr_of`, `str()`) re-raises it
    /// (test_dict `test_repr`: `repr({1: BadRepr()})` must surface `Exc`).
    static REPR_ERROR: RefCell<Option<RuntimeError>> = const { RefCell::new(None) };
}

/// Park `err` as the pending repr error (first one wins, matching CPython
/// aborting the whole repr on the first failing element).
pub(crate) fn stash_repr_error(err: RuntimeError) {
    REPR_ERROR.with(|slot| {
        let mut slot = slot.borrow_mut();
        if slot.is_none() {
            *slot = Some(err);
        }
    });
}

/// Take the pending repr error, if any. Called at fallible repr/str
/// boundaries; also used to *clear* stale state before rendering.
pub(crate) fn take_repr_error() -> Option<RuntimeError> {
    REPR_ERROR.with(|slot| slot.borrow_mut().take())
}

impl PartialEq for DictKey {
    fn eq(&self, other: &Self) -> bool {
        // CPython compares dict/set keys with `a is b or a == b`; the identity
        // half makes a stored `nan` findable by itself (`{nan}` contains its
        // own nan even though `nan != nan`).
        if self.0.is_same(&other.0) {
            return true;
        }
        // Native fast path also covers instance *identity* (`Rc::ptr_eq`),
        // which is the `a is b` half of CPython's dict-key comparison.
        if self.0.eq_value(&other.0) {
            return true;
        }
        // Distinct user instances with a custom `__eq__` compare through it
        // so a class defining `__eq__`/`__hash__` works as a `set`/`dict`
        // key. Plain instances (no custom `__eq__`) keep identity semantics,
        // already decided by the `eq_value` fast path above.
        //
        // A foreign extension scalar (numpy `int64`/…) compares to the equal
        // Python scalar only through its `tp_richcompare` — `eq_value` above
        // knows only native pairs — so route it through the interpreter too.
        // With the shared `tp_hash` (see `py_hash_value`) this is what lets
        // `d[np.int64(0)]` find the `0` key (numpy's `np.roll` shifts dict).
        // The same holds for a `tuple`/`frozenset` *containing* such a scalar
        // (`key_needs_interp_eq` recurses): a native element-wise `eq_value`
        // can't equate two distinct numpy scalars, so the whole container is
        // compared via Python `==` (`pd.IntervalIndex` dedup keys `(left,
        // right)` numpy pairs in a `set`).
        if key_needs_interp_eq(&self.0) || key_needs_interp_eq(&other.0) {
            // Deferred-dispatch probe: report the need for a Python
            // comparison instead of running it under the table's borrow
            // (gh-140551: that user code may mutate the very dict being
            // walked); the caller retries on the borrow-free path.
            if key_eq_defer_active() {
                KEY_COMPARISON.with(|state| state.deferred.set(true));
                return false;
            }
            // CPython dispatches `__eq__` only between keys in the *same
            // hash bucket*; unequal hashes mean "not equal" without any
            // user code. indexmap's small-table linear scan compares every
            // entry through this `eq` with no hash check at all, so enforce
            // the bucket precondition here — sqlalchemy's
            // `constraints.discard(ColumnSet())` probes a 1-element set
            // with a key whose `__eq__` returns a SQL clause that *raises*
            // on truthiness, and CPython never invokes it (hashes differ).
            //
            // Consult the recorded hash first (the value the table stored
            // when the key was hashed — CPython's `ep->me_hash`), so the
            // check never re-dispatches a stored key's `__hash__`:
            // `test_setdefault_atomic` counts exactly one call per key.
            let h_self = recorded_key_hash(&self.0).unwrap_or_else(|| {
                py_hash_value(&self.0).unwrap_or_else(|| identity_hash(&self.0))
            });
            let h_other = recorded_key_hash(&other.0).unwrap_or_else(|| {
                py_hash_value(&other.0).unwrap_or_else(|| identity_hash(&other.0))
            });
            if h_self != h_other {
                return false;
            }
            if let Some(eq) = current_interp_eq(&self.0, &other.0) {
                return eq;
            }
        }
        false
    }
}

impl Eq for DictKey {}

struct KeyComparisonState {
    /// First exception raised by a Python `__hash__`/`__eq__` invoked from
    /// `DictKey`'s `Hash`/`Eq` while a `set`/`dict` probed the hash table.
    /// Those Rust traits are infallible, so they can't return the error the
    /// way CPython's `PyObject_Hash`/`PyObject_RichCompareBool` do (returning
    /// -1 to abort the operation). Instead the error is parked here and the
    /// surrounding set/dict operation re-raises it via [`key_cmp_scope`]
    /// (`test_set` `test_badcmp` / `test_8420_set_merge`).
    error: std::cell::RefCell<Option<RuntimeError>>,
    /// Depth of active `with_key_eq_deferred` scopes.
    defer_depth: std::cell::Cell<usize>,
    /// A stored key needs a Python comparison outside the table borrow.
    deferred: std::cell::Cell<bool>,
}

thread_local! {
    // Only this thread accesses the bookkeeping, and no borrow survives
    // a Python callback. Keep related fields together so each scope needs
    // one TLS lookup and no cross-thread lock.
    static KEY_COMPARISON: KeyComparisonState = const { KeyComparisonState {
        error: std::cell::RefCell::new(None),
        defer_depth: std::cell::Cell::new(0),
        deferred: std::cell::Cell::new(false),
    } };
}

/// Park `err` as the pending key-comparison error (first one wins, matching
/// CPython aborting on the first failed compare). Called from the reentrant
/// `__hash__`/`__eq__` bridges when the callback raises.
/// `indexmap` skips hashing when probing a table of 0 or 1 entries (it
/// compares the lone entry directly). CPython always calls `__hash__`
/// first, so a raising `__hash__` must still surface for `x in {'a'}`
/// (test_set.test_unhashable_element's `HashError`). Only a user
/// instance with a Python `__hash__` is affected; the call runs inside a
/// `key_cmp_scope`, so a raised exception is stashed and re-raised there.
#[inline]
pub(crate) fn force_hash_for_tiny_table(len: usize, key: &Object) {
    if len <= 1 && dict_key_is_reentrant(key) {
        let _ = py_hash_value(key);
    }
}

pub(crate) fn stash_key_cmp_error(err: RuntimeError) {
    KEY_COMPARISON.with(|state| {
        let mut slot = state.error.borrow_mut();
        if slot.is_none() {
            *slot = Some(err);
        }
    });
}

#[inline]
fn key_cmp_error_pending() -> bool {
    KEY_COMPARISON.with(|state| state.error.borrow().is_some())
}

/// Run `f` — a closure that performs `IndexSet`/`IndexMap` probes which may
/// re-enter a Python `__hash__`/`__eq__` — and surface any exception those
/// callbacks raised. The pending error of an *outer* scope is saved across
/// the call and restored afterwards, so a re-entrant set/dict mutation from
/// inside a comparison (`bad_eq.__eq__` calling `set2.clear()`) neither loses
/// nor steals the outer operation's error.
pub(crate) fn key_cmp_scope<T>(f: impl FnOnce() -> T) -> Result<T, RuntimeError> {
    KEY_COMPARISON.with(|state| {
        let saved = state.error.borrow_mut().take();
        let out = f();
        let mine = state.error.replace(saved);
        match mine {
            Some(err) => Err(err),
            None => Ok(out),
        }
    })
}

/// Run a native dict-table probe with Python `__eq__` dispatch *deferred*:
/// inside `f`, `DictKey::eq` never re-enters the interpreter — it reports
/// "not equal" and raises a flag instead. Returns `(result, deferred)`;
/// a `true` flag means the probe was inconclusive (some stored key needed a
/// Python comparison) and the caller must retry on the borrow-free
/// [`dict_reentrant_find`] path. This is what protects the *stored*-key
/// side of gh-140551/bpo-40489: a plain `'test' in d` probe can hit a
/// stored `str` subclass whose `__eq__` clears the dict mid-walk.
pub(crate) fn with_key_eq_deferred<T>(f: impl FnOnce() -> T) -> (T, bool) {
    KEY_COMPARISON.with(|state| {
        state.defer_depth.set(state.defer_depth.get() + 1);
        let saved = state.deferred.replace(false);
        let out = f();
        let deferred = state.deferred.replace(saved);
        state.defer_depth.set(state.defer_depth.get() - 1);
        (out, deferred)
    })
}

fn key_eq_defer_active() -> bool {
    KEY_COMPARISON.with(|state| state.defer_depth.get() > 0)
}

/// True when a dict operation keyed by `key` can run *user Python* during
/// the hash-table walk — its class (or a tuple element's class) supplies a
/// non-builtin `__eq__` or `__hash__`. Such operations must take the
/// borrow-free two-phase path ([`dict_reentrant_find`] + pinned mutation)
/// because that user code may raise, or re-enter the interpreter and mutate
/// the same dict (gh-140551), and because CPython invokes `__hash__`
/// exactly once per operation (`test_setdefault_atomic`). Builtin-owned
/// overrides (`weakref` comparing by referent) stay on the fast path: they
/// cannot re-enter user code.
pub(crate) fn dict_key_is_reentrant(key: &Object) -> bool {
    match key {
        Object::Instance(inst) => {
            let py_dunder = |name: &str| match inst.cls().lookup_with_owner(name) {
                Some((Object::None, _)) | None => false,
                Some((_, owner)) => !owner.flags.is_builtin,
            };
            py_dunder("__eq__") || py_dunder("__hash__")
        }
        Object::Tuple(items) => items.iter().any(dict_key_is_reentrant),
        _ => false,
    }
}

/// The table-level (Fx-mixed) hash for a Python hash value, matching what
/// `DictKey::hash` feeds the [`DictData`] hasher.
fn dict_table_hash(py_hash: i64) -> u64 {
    use std::hash::BuildHasher;
    crate::fasthash::FxBuildHasher.hash_one(py_hash)
}

/// Probe result of [`dict_reentrant_probe`]: the key's table-level hash
/// plus the equal *stored* key, if any.
pub(crate) struct ReentrantProbe {
    table_hash: u64,
    stored: Option<Object>,
}

/// Borrow-free dict lookup for a key whose `__hash__`/`__eq__` can run user
/// Python.
///
/// The Python hash is computed exactly once, up front, with no borrow held
/// (CPython's `PyObject_Hash` runs before the table walk — a raising
/// `__hash__` surfaces here, and `test_setdefault_atomic` counts one call
/// per operation). Python `__eq__` likewise only ever runs with no borrow
/// held on `d`; if it re-enters and mutates the dict, the walk restarts
/// against a fresh same-hash snapshot with prior comparison results
/// memoised — the restart CPython's `lookdict` performs when it detects a
/// mutated table (gh-140551, dict `test_clear_at_lookup`).
pub(crate) fn dict_reentrant_probe(
    d: &RefCell<DictData>,
    key: &Object,
) -> Result<ReentrantProbe, RuntimeError> {
    use indexmap::map::raw_entry_v1::RawEntryApiV1;
    let kh = key_cmp_scope(|| py_hash_value(key))?.unwrap_or_else(|| identity_hash(key));
    let table_hash = dict_table_hash(kh);
    let mut memo: Vec<(Object, bool)> = Vec::new();
    loop {
        // Same-hash candidates, collected under a short borrow with a
        // never-matching predicate (no user code runs inside it).
        let mut cands: Vec<Object> = Vec::new();
        {
            let m = d.borrow();
            let _ = m.raw_entry_v1().from_hash(table_hash, |k| {
                cands.push(k.0.clone());
                false
            });
        }
        let mut fresh_call = false;
        let mut found = None;
        for stored in &cands {
            // Identity and native-value equality never run user code.
            if stored.is_same(key) || stored.eq_value(key) {
                found = Some(stored.clone());
                break;
            }
            if !(key_needs_interp_eq(key) || key_needs_interp_eq(stored)) {
                continue;
            }
            // Memo first: a restarted snapshot walk must not re-run *any*
            // user code (hash or eq) for a candidate it already settled.
            if let Some((_, eq)) = memo.iter().find(|(o, _)| o.is_same(stored)) {
                if *eq {
                    found = Some(stored.clone());
                    break;
                }
                continue;
            }
            // Same-bucket precondition: indexmap's small-table linear scan
            // hands `from_hash` every entry regardless of hash, but CPython
            // only ever dispatches `__eq__` between keys whose hashes match.
            // The stored key's hash comes from its record (CPython reads the
            // entry's `me_hash`); only a record-less key pays a dispatch.
            let sh = match recorded_key_hash(stored) {
                Some(h) => h,
                None => key_cmp_scope(|| py_hash_value(stored))?
                    .unwrap_or_else(|| identity_hash(stored)),
            };
            if sh != kh {
                continue;
            }
            // Python `__eq__` (stored first, CPython's argument order) with
            // no borrow held; it may mutate `d` re-entrantly.
            let eq = key_cmp_scope(|| current_interp_eq(stored, key))?.unwrap_or(false);
            memo.push((stored.clone(), eq));
            fresh_call = true;
            break; // restart against a fresh snapshot
        }
        if found.is_some() || !fresh_call {
            return Ok(ReentrantProbe {
                table_hash,
                stored: found,
            });
        }
    }
}

/// [`dict_reentrant_probe`], reduced to the stored key (membership tests).
pub(crate) fn dict_reentrant_find(
    d: &RefCell<DictData>,
    key: &Object,
) -> Result<Option<Object>, RuntimeError> {
    Ok(dict_reentrant_probe(d, key)?.stored)
}

/// Reentrant-safe `d[key] = value`. Returns the replaced value, if any.
///
/// The mutation itself is performed through the raw-entry API with an
/// identity-only predicate and the pre-computed hash, so no user
/// `__hash__`/`__eq__` ever runs while the table holds its borrow.
pub(crate) fn dict_reentrant_insert(
    d: &RefCell<DictData>,
    key: Object,
    value: Object,
) -> Result<Option<Object>, RuntimeError> {
    use indexmap::map::raw_entry_v1::{RawEntryApiV1, RawEntryMut};
    let probe = dict_reentrant_probe(d, &key)?;
    let target = probe.stored.as_ref().unwrap_or(&key);
    let mut m = d.borrow_mut();
    match m
        .raw_entry_mut_v1()
        .from_hash(probe.table_hash, |k| k.0.is_same(target))
    {
        RawEntryMut::Occupied(mut e) => {
            let same = e.get().is_same(&value);
            let old = e.insert(value);
            drop(m);
            if !same {
                dict_mutation_event(d);
            }
            Ok(Some(old))
        }
        RawEntryMut::Vacant(e) => {
            e.insert_hashed_nocheck(probe.table_hash, DictKey(key), value);
            drop(m);
            dict_watch_bump(d);
            dict_mutation_event(d);
            Ok(None)
        }
    }
}

/// Reentrant-safe `d.setdefault(key, default)`: one probe, one `__hash__`
/// call (`test_setdefault_atomic` counts them). Returns the stored value
/// (existing, or the freshly inserted default).
pub(crate) fn dict_reentrant_setdefault(
    d: &RefCell<DictData>,
    key: Object,
    default: Object,
) -> Result<Object, RuntimeError> {
    use indexmap::map::raw_entry_v1::{RawEntryApiV1, RawEntryMut};
    let probe = dict_reentrant_probe(d, &key)?;
    let target = probe.stored.as_ref().unwrap_or(&key);
    let mut m = d.borrow_mut();
    match m
        .raw_entry_mut_v1()
        .from_hash(probe.table_hash, |k| k.0.is_same(target))
    {
        RawEntryMut::Occupied(e) => Ok(e.get().clone()),
        RawEntryMut::Vacant(e) => {
            e.insert_hashed_nocheck(probe.table_hash, DictKey(key), default.clone());
            drop(m);
            dict_watch_bump(d);
            dict_mutation_event(d);
            Ok(default)
        }
    }
}

/// Reentrant-safe `d[key]` read. Returns the stored value, if any.
pub(crate) fn dict_reentrant_get(
    d: &RefCell<DictData>,
    key: &Object,
) -> Result<Option<Object>, RuntimeError> {
    use indexmap::map::raw_entry_v1::RawEntryApiV1;
    let probe = dict_reentrant_probe(d, key)?;
    match probe.stored {
        Some(stored) => Ok(d
            .borrow()
            .raw_entry_v1()
            .from_hash(probe.table_hash, |k| k.0.is_same(&stored))
            .map(|(_, v)| v.clone())),
        None => Ok(None),
    }
}

/// Reentrant-safe `del d[key]` / `d.pop(key)`. Returns the evicted entry.
pub(crate) fn dict_reentrant_remove(
    d: &RefCell<DictData>,
    key: &Object,
) -> Result<Option<(Object, Object)>, RuntimeError> {
    use indexmap::map::raw_entry_v1::{RawEntryApiV1, RawEntryMut};
    let probe = dict_reentrant_probe(d, key)?;
    match probe.stored {
        Some(stored) => {
            let mut m = d.borrow_mut();
            match m
                .raw_entry_mut_v1()
                .from_hash(probe.table_hash, |k| k.0.is_same(&stored))
            {
                RawEntryMut::Occupied(e) => {
                    let (k, v) = e.shift_remove_entry();
                    drop(m);
                    dict_watch_bump(d);
                    dict_mutation_event(d);
                    Ok(Some((k.0, v)))
                }
                RawEntryMut::Vacant(_) => Ok(None),
            }
        }
        None => Ok(None),
    }
}

// ---------------------------------------------------------------------------
// Dict structural-version watches (mutation-during-iteration detection).
//
// CPython's compact dict detects `del d[k]; d[k] = v` during iteration —
// same `ma_used`, so the size trip-wire stays silent — because the delete
// leaves a tombstone and the reinsert *appends*: the iterator then finds an
// entry beyond the `di->len` elements it expected and raises `RuntimeError:
// dictionary keys changed during iteration`. Our `IndexMap` has no
// tombstones (`shift_remove` compacts in place), so the layout carries no
// trace of the churn. Instead, dict iterators register a *watch* on their
// source dict; the centralized structural mutators (`dict_insert` on a new
// key, `dict_remove`, `clear`, `popitem`) bump the watched dict's version,
// and the iterator's checked `__next__` raises on a version change.
//
// The registry is keyed by the dict's heap address and only ever holds
// dicts with a live watcher (the watcher holds the dict's `Rc`, so the
// address cannot be recycled while the entry exists). `DICT_WATCH_COUNT`
// gates the mutator-side lookup: with no active iterator it's a single
// thread-local read, keeping `d[k] = v` hot paths unaffected.
// ---------------------------------------------------------------------------

thread_local! {
    /// dict address -> (shared structural version, live watcher count).
    static DICT_WATCHES: std::cell::RefCell<
        std::collections::HashMap<usize, (Rc<Cell<u64>>, usize), crate::fasthash::FxBuildHasher>,
    > = std::cell::RefCell::new(std::collections::HashMap::default());
    /// Number of entries in `DICT_WATCHES` (fast gate for mutators).
    static DICT_WATCH_COUNT: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

/// A live subscription to one dict's structural version. Created by a dict
/// iterator's first user-visible `__next__`; dropped with the iterator.
#[derive(Debug)]
pub struct DictWatch {
    ptr: usize,
    version: Rc<Cell<u64>>,
    start: u64,
}

impl DictWatch {
    pub(crate) fn new(d: &Rc<RefCell<DictData>>) -> DictWatch {
        let ptr = std::ptr::from_ref::<RefCell<DictData>>(&**d) as usize;
        let version = DICT_WATCHES.with(|w| {
            let mut w = w.borrow_mut();
            let entry = w.entry(ptr).or_insert_with(|| (Rc::new(Cell::new(0)), 0));
            entry.1 += 1;
            entry.0.clone()
        });
        DICT_WATCH_COUNT.with(|c| c.set(DICT_WATCHES.with(|w| w.borrow().len())));
        let start = version.get();
        DictWatch {
            ptr,
            version,
            start,
        }
    }

    /// True when the watched dict changed structurally (a key added or
    /// removed) since this watch was created.
    pub(crate) fn changed(&self) -> bool {
        self.version.get() != self.start
    }
}

impl Clone for DictWatch {
    fn clone(&self) -> DictWatch {
        // Re-register so the entry's watcher count matches the number of
        // live handles (a cloned iterator — `__reduce__`, copy — must keep
        // the watch alive after the original drops).
        DICT_WATCHES.with(|w| {
            let mut w = w.borrow_mut();
            let entry = w
                .entry(self.ptr)
                .or_insert_with(|| (self.version.clone(), 0));
            entry.1 += 1;
        });
        DICT_WATCH_COUNT.with(|c| c.set(DICT_WATCHES.with(|w| w.borrow().len())));
        DictWatch {
            ptr: self.ptr,
            version: self.version.clone(),
            start: self.start,
        }
    }
}

impl Drop for DictWatch {
    fn drop(&mut self) {
        DICT_WATCHES.with(|w| {
            let mut w = w.borrow_mut();
            if let Some(entry) = w.get_mut(&self.ptr) {
                entry.1 = entry.1.saturating_sub(1);
                if entry.1 == 0 {
                    w.remove(&self.ptr);
                }
            }
        });
        DICT_WATCH_COUNT.with(|c| c.set(DICT_WATCHES.with(|w| w.borrow().len())));
    }
}

/// Record a structural change (key added/removed) to `d`. O(1) no-op unless
/// some iterator is watching a dict on this thread.
pub(crate) fn dict_watch_bump(d: &RefCell<DictData>) {
    if DICT_WATCH_COUNT.with(std::cell::Cell::get) == 0 {
        return;
    }
    let ptr = std::ptr::from_ref::<RefCell<DictData>>(d) as usize;
    DICT_WATCHES.with(|w| {
        if let Some((version, _)) = w.borrow().get(&ptr) {
            version.set(version.get() + 1);
        }
    });
}

// ---------------------------------------------------------------------------
// PEP 509 dict version tags (RFC 0060).
//
// CPython stamps every dict with `ma_version_tag`, drawn from one global
// monotonically increasing counter: fresh dicts get a unique tag and every
// *effective* mutation (key added/removed, or a value replaced by a
// different object — identity, not equality) draws a new one.
// `_testcapi.dict_get_version` exposes it and `test_dict_version` asserts
// the full semantics.
//
// WeavePy's `DictData` is a bare `IndexMap` with no room for a per-dict
// field, so versions live in a side registry keyed by the dict's heap
// address and assigned lazily: the first `dict_version_get` on a dict
// registers it with a fresh tag; the centralized mutators
// (`dict_insert`/`dict_remove`/`clear`/`popitem`/`setdefault` and the
// reentrant variants) then advance registered dicts through
// [`dict_version_bump`]. Unregistered dicts skip all bookkeeping — an
// unobserved dict's next `dict_version_get` draws a fresh (hence changed
// and unique) tag anyway, which is indistinguishable from eager stamping.
//
// The registry stores a `Weak` per entry: the weak count keeps the
// allocation's address from being recycled while the entry exists, so a
// present key always denotes the same dict. `PEP509_ACTIVE` gates the
// mutator-side hook to a single relaxed load until the first
// `dict_get_version` call (only test code ever calls it).
// ---------------------------------------------------------------------------

static PEP509_ACTIVE: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
/// The global version source. Starts at 1 so no dict ever reports tag 0
/// (CPython reserves 0 for "never assigned").
static PEP509_COUNTER: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1);
#[allow(clippy::type_complexity)]
static PEP509_VERSIONS: std::sync::LazyLock<
    parking_lot::Mutex<std::collections::HashMap<usize, (Weak<RefCell<DictData>>, u64)>>,
> = std::sync::LazyLock::new(|| parking_lot::Mutex::new(std::collections::HashMap::new()));

fn pep509_next() -> u64 {
    PEP509_COUNTER.fetch_add(1, std::sync::atomic::Ordering::Relaxed)
}

/// `_testcapi.dict_get_version(d)` — the dict's current PEP 509 tag,
/// registering the dict for mutation tracking on first sight.
pub fn dict_version_get(d: &Rc<RefCell<DictData>>) -> u64 {
    PEP509_ACTIVE.store(true, std::sync::atomic::Ordering::Relaxed);
    let ptr = Rc::as_ptr(d) as usize;
    let mut reg = PEP509_VERSIONS.lock();
    if let Some((_, v)) = reg.get(&ptr) {
        return *v;
    }
    // Bound the registry: entries whose dict died keep their address
    // reserved (via the Weak) but serve no further purpose.
    if reg.len() >= 4096 {
        reg.retain(|_, (w, _)| w.strong_count() > 0);
    }
    let v = pep509_next();
    reg.insert(ptr, (Rc::downgrade(d), v));
    v
}

/// Advance a registered dict's PEP 509 tag after an effective mutation.
/// One relaxed load when no `dict_get_version` call has ever happened.
#[inline]
pub(crate) fn dict_version_bump(d: &RefCell<DictData>) {
    if !PEP509_ACTIVE.load(std::sync::atomic::Ordering::Relaxed) {
        return;
    }
    let ptr = std::ptr::from_ref::<RefCell<DictData>>(d) as usize;
    let mut reg = PEP509_VERSIONS.lock();
    if let Some(entry) = reg.get_mut(&ptr) {
        entry.1 = pep509_next();
    }
}

/// The shared post-mutation hook for the centralized dict mutators: feeds
/// both the PEP 509 registry and the `builtin_dict` rare-event counter.
/// Call only for *effective* changes (a key added or removed, or a value
/// replaced by a non-identical object).
#[inline]
pub(crate) fn dict_mutation_event(d: &RefCell<DictData>) {
    crate::rare_events::note_dict_mutation(d);
    dict_version_bump(d);
}

impl Hash for DictKey {
    fn hash<H: Hasher>(&self, state: &mut H) {
        // Bucket every key by its single canonical Python hash value, so any
        // two keys Python deems equal-and-hashable collide here regardless of
        // their Rust representation: equal numeric types (`1 == 1.0 == True`),
        // an `int`/`str`/… subclass and its wrapped value, and — crucially —
        // a custom `__hash__` that returns a built-in value (e.g.
        // `hash('halibut')`) and the string itself. `DictKey::eq` then decides
        // actual equality within the bucket. Identity-hashable objects
        // (functions, types, plain instances, …) fold in their allocation
        // identity; truly unhashable keys share a constant bucket and the
        // runtime raises lazily when used.
        let h = py_hash_value(&self.0).unwrap_or_else(|| identity_hash(&self.0));
        h.hash(state);
    }
}

/// Backing store of every Python dict / instance `__dict__` / class dict.
///
/// Keyed by the *Python* hash ([`DictKey`]'s `Hash` feeds the canonical
/// `py_hash_value` into the table hasher), so the table hasher itself only
/// ever sees one pre-mixed 64-bit word — [`crate::fasthash::FxBuildHasher`]
/// (one multiply) instead of SipHash, which profiled as a top-ten CPU
/// consumer under pandas. Not attacker-relevant: collision resistance
/// comes from the Python-level hash, exactly as in CPython's own tables.
pub type DictData = indexmap::IndexMap<DictKey, Object, crate::fasthash::FxBuildHasher>;

#[derive(Clone)]
pub struct PyFunction {
    pub name: String,
    /// The code object executed on call. Interior-mutable because
    /// `f.__code__ = other.__code__` rebinds it at runtime (CPython's
    /// `func_set_code`); every call reads the *current* value.
    pub code: RefCell<Rc<CodeObject>>,
    /// Module-level globals shared with the defining module.
    pub globals: Rc<RefCell<DictData>>,
    /// CPython `func_builtins`: the builtins mapping this function's
    /// frames resolve names against. Resolved from
    /// `globals['__builtins__']` once, at function creation, and never
    /// re-read — rebinding `globals()['__builtins__']` between calls
    /// must not change resolution (test_dynamic's
    /// `test_cannot_replace_builtins_dict_between_calls`).
    pub builtins: Rc<RefCell<DictData>>,
    pub defaults: Vec<Object>,
    pub kw_defaults: Vec<(String, Object)>,
    /// Closure cells matching `code.freevars` in order.
    pub closure: Vec<Object>,
    /// `__dict__` for arbitrary attribute assignment on the
    /// function — e.g. `@functools.wraps`, `@abstractmethod`'s
    /// `__isabstractmethod__`, or any decorator that stashes
    /// per-callable metadata. The outer `RefCell` exists because
    /// CPython's `func_set_dict` *aliases* the assigned dict
    /// (`f.__dict__ = d; f.__dict__ is d` — test_funcattrs), so the
    /// whole payload must be swappable, not just its contents.
    pub attrs: RefCell<Rc<RefCell<DictData>>>,
    /// CPython function *getset/member slots* (`__name__`,
    /// `__qualname__`, `__doc__`, `__module__`, `__annotations__`,
    /// `__type_params__`, …). These live outside `__dict__`: they're
    /// data descriptors on the `function` type, so `f.__name__ = x`
    /// must never appear in `f.__dict__` (functools.update_wrapper
    /// copies `__dict__` and asserts the wrapper's annotations are
    /// untouched by the wrapped function's slots).
    pub slots: RefCell<DictData>,
}

/// Attribute names backed by function slots rather than `__dict__`.
/// `__code__` is *not* here: it rebinds `PyFunction::code` directly so
/// calls observe the swap (see the function setattr path).
pub fn is_function_slot(name: &str) -> bool {
    matches!(
        name,
        "__name__"
            | "__qualname__"
            | "__doc__"
            | "__module__"
            | "__annotations__"
            | "__annotate__"
            | "__type_params__"
            | "__defaults__"
            | "__kwdefaults__"
    )
}

impl PyFunction {
    /// The current code object (honours `f.__code__ = …` rebinding).
    pub fn code(&self) -> Rc<CodeObject> {
        self.code.borrow().clone()
    }

    /// The live `__dict__` payload (honours `f.__dict__ = d` swapping).
    pub fn attrs(&self) -> Rc<RefCell<DictData>> {
        self.attrs.borrow().clone()
    }

    /// Read a slot value if one has been stored (explicitly assigned or
    /// stamped at definition time). Computed fallbacks live at the
    /// attribute-access sites.
    pub fn slot(&self, name: &str) -> Option<Object> {
        self.slots
            .borrow()
            .get(&crate::object::StrKey(name))
            .cloned()
    }

    pub fn set_slot(&self, name: &str, value: Object) {
        self.slots
            .borrow_mut()
            .insert(DictKey(Object::from_str(name)), value);
    }
}

impl fmt::Debug for PyFunction {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "<function {}>", self.name)
    }
}

#[derive(Clone)]
pub struct BoundMethod {
    pub receiver: Object,
    pub function: Object,
    /// When `true`, this is *not* a fully-bound CPython `method` but a
    /// *deferred special-method dispatch* (`instance_method` /
    /// `metaclass_method`): if `function` turns out to be a descriptor
    /// instance (a class attribute with `__get__`, e.g.
    /// `class X: __iter__ = SomeDescriptor()`), its `__get__(receiver,
    /// type(receiver))` is invoked at call time and the result is
    /// called — mirroring CPython's `_PyObject_LookupSpecial`.
    ///
    /// When `false` (the default for a real bound method), calling
    /// prepends `receiver` and calls `function` directly, with **no**
    /// further descriptor resolution. This is what `classmethod.__get__`
    /// / `function.__get__` produce: CPython 3.13 removed chained
    /// `classmethod` descriptors, so `classmethod(partial)` must call the
    /// wrapped `partial` with the class prepended rather than re-invoking
    /// `partial.__get__`.
    pub redispatch_descriptor: bool,
    /// A genuine CPython `PyMethod_Type` object over a *builtin*
    /// callable: `classmethod(repr).__get__(None, C)`,
    /// `types.MethodType(len, obj)`. Attribute lookup on a builtin
    /// type's method (`[].append`, `object().__repr__`) instead yields a
    /// C-level bound object (`builtin_function_or_method` /
    /// `method-wrapper`), which CPython's instrumentation never expands
    /// (`_MAYBE_EXPAND_METHOD` checks `PyMethod_Type`). Irrelevant when
    /// `function` is a Python function (always `method`).
    pub py_method: bool,
}

impl BoundMethod {
    /// A fully-bound method (CPython `method`): calling it prepends
    /// `receiver` and calls `function` directly.
    pub fn new(receiver: Object, function: Object) -> Self {
        BoundMethod {
            receiver,
            function,
            redispatch_descriptor: false,
            py_method: false,
        }
    }

    /// A `PyMethod_Type` object built by `classmethod.__get__` /
    /// `types.MethodType`, so a builtin `function` still reports as
    /// `method` and expands under instrumentation (see [`Self::py_method`]).
    pub fn py_method(receiver: Object, function: Object) -> Self {
        BoundMethod {
            receiver,
            function,
            redispatch_descriptor: false,
            py_method: true,
        }
    }

    /// Would CPython represent this as a `PyMethod_Type` object? Always
    /// for a Python function; for a builtin only when built by
    /// `classmethod.__get__` / `types.MethodType` over a *non-native*
    /// callable (a C `classmethod_descriptor` such as `int.from_bytes`
    /// binds to a `builtin_function_or_method`).
    pub fn is_pymethod_type(&self) -> bool {
        match &self.function {
            Object::Builtin(_) => {
                self.py_method && crate::descr_registry::lookup(&self.function).is_none()
            }
            _ => true,
        }
    }

    /// A *deferred* special-method dispatch: if `function` is itself a
    /// descriptor instance, its `__get__` is honoured at call time. Only
    /// the implicit special-method lookup helpers (`instance_method` /
    /// `metaclass_method`) build these.
    pub fn dispatch(receiver: Object, function: Object) -> Self {
        BoundMethod {
            receiver,
            function,
            redispatch_descriptor: true,
            py_method: false,
        }
    }
}

impl fmt::Debug for BoundMethod {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "<bound method>")
    }
}

/// A Rust function exposed to Python code.
///
/// The `Send + Sync` bound on the closure is what makes `Object` itself
/// `Send + Sync` (RFC 0025). Every stdlib factory that builds a
/// `BuiltinFn` captures only `Send + Sync` state — a property the
/// audit checks at construction time.
pub struct BuiltinFn {
    pub name: &'static str,
    /// CPython's type split: type-dict *method descriptors* (and slot
    /// wrappers) bind `self` on instance attribute access; module-level
    /// `builtin_function_or_method`s are **not** descriptors and are
    /// returned as-is (`class C: f = len` leaves `c.f` unbound).
    pub binds_instance: bool,
    pub call: Box<dyn Fn(&[Object]) -> Result<Object, RuntimeError> + Send + Sync>,
    /// Kwargs-aware entry point. When `Some`, the VM dispatch loop
    /// calls this with both positional and keyword arguments instead
    /// of falling through the legacy positional-only path. Builtins
    /// that don't accept kwargs leave this as `None`; the dispatcher
    /// then errors on any kwargs the caller passes.
    pub call_kw: Option<
        Box<dyn Fn(&[Object], &[(String, Object)]) -> Result<Object, RuntimeError> + Send + Sync>,
    >,
}

impl Drop for BuiltinFn {
    fn drop(&mut self) {
        // The descriptor side tables key on this allocation's address;
        // a reused address must not inherit its tags.
        crate::descr_registry::forget(std::ptr::from_ref(self).cast::<()>() as usize);
    }
}

impl BuiltinFn {
    /// Build a positional-only builtin (the common case).
    pub fn new<F>(name: &'static str, body: F) -> Self
    where
        F: Fn(&[Object]) -> Result<Object, RuntimeError> + Send + Sync + 'static,
    {
        Self {
            name,
            binds_instance: false,
            call: Box::new(body),
            call_kw: None,
        }
    }

    /// Build a kwargs-aware builtin. The positional-only `call` field
    /// stays wired (using a body that ignores kwargs) so dispatchers
    /// that don't bother to check `call_kw` still work.
    pub fn with_kwargs<F>(name: &'static str, body: F) -> Self
    where
        F: Fn(&[Object], &[(String, Object)]) -> Result<Object, RuntimeError>
            + Send
            + Sync
            + Clone
            + 'static,
    {
        let body_pos = body.clone();
        Self {
            name,
            binds_instance: false,
            call: Box::new(move |args| body_pos(args, &[])),
            call_kw: Some(Box::new(move |args, kwargs| body(args, kwargs))),
        }
    }
}

impl fmt::Debug for BuiltinFn {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "<built-in function {}>", self.name)
    }
}

#[derive(Debug, Clone)]
pub struct PySlice {
    pub start: Object,
    pub stop: Object,
    pub step: Object,
}

/// A live Python generator (RFC 0006). Each generator wraps a frame
/// that the interpreter resumes from the last `YIELD_VALUE`. The frame
/// itself is opaque to outside code — it's owned by the VM module via
/// `state` and only legal to inspect via interpreter methods.
pub struct PyGenerator {
    /// `gi_name`. Seeded from the function's `__name__` at call time;
    /// user code may reassign it (`gen.__name__ = ...`). Held as the
    /// *string object* so repeated reads return the identical object —
    /// CPython stores `gi_name` as a `PyObject*` and
    /// `gen.__name__ is gen.__name__` holds (test_types
    /// CoroutineTests.test_gen reads it through two paths and
    /// asserts `is`).
    pub name: RefCell<Object>,
    /// `gi_qualname` (PEP 3155). Seeded from the function's
    /// `__qualname__` at call time; reassignable like `name`.
    pub qualname: RefCell<Object>,
    /// Whether this is a plain generator, a coroutine, or an async
    /// generator. Needed so the shared send/throw machinery can apply
    /// PEP 479 (a `StopIteration` escaping the *body* becomes a
    /// `RuntimeError`) with the right wording per flavour.
    pub kind: CoroutineKind,
    /// `gi_code` — held on the generator itself (CPython keeps a
    /// strong reference) so it stays readable after the generator
    /// finishes and the frame is dropped.
    pub code: Object,
    pub state: RefCell<GeneratorState>,
    /// `cr_origin` — for coroutines created while
    /// `sys.set_coroutine_origin_tracking_depth(n)` is active: a tuple
    /// of `(filename, lineno, funcname)` triples for the creation call
    /// stack (most recent first). `None` when tracking is off.
    pub origin: RefCell<Object>,
    /// PEP 525 `sys.set_asyncgen_hooks` bookkeeping (async generators
    /// only). `hooks_inited` flips on the first `__anext__`/`asend`/
    /// `athrow`/`aclose`, at which point the thread's *finalizer* hook
    /// is captured here so finalization can route through the event
    /// loop that first iterated the generator.
    pub hooks_inited: crate::sync::Cell<bool>,
    pub finalizer: RefCell<Object>,
    /// CPython's "tp_finalize already ran" GC bit: `invoke_finalizer`
    /// sets it before finalizing so a generator left suspended by its
    /// finalizer (e.g. a PEP 525 hook that declined to close it) is
    /// not resurrected and re-finalized forever on the next drop.
    pub finalize_ran: crate::sync::Cell<bool>,
}

impl PyGenerator {
    pub fn new(
        name: impl Into<String>,
        qualname: impl Into<String>,
        kind: CoroutineKind,
        code: Object,
        frame: Box<dyn std::any::Any + Send + Sync>,
    ) -> Self {
        Self {
            name: RefCell::new(Object::from_str(name.into())),
            qualname: RefCell::new(Object::from_str(qualname.into())),
            kind,
            code,
            state: RefCell::new(GeneratorState::Created(frame)),
            origin: RefCell::new(Object::None),
            hooks_inited: crate::sync::Cell::new(false),
            finalizer: RefCell::new(Object::None),
            finalize_ran: crate::sync::Cell::new(false),
        }
    }

    pub fn is_finished(&self) -> bool {
        matches!(&*self.state.borrow(), GeneratorState::Finished)
    }
}

impl fmt::Debug for PyGenerator {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "<generator {}>", self.name.borrow().to_str())
    }
}

impl Drop for PyGenerator {
    fn drop(&mut self) {
        // CPython finalizes a generator the moment its refcount dies:
        // a *suspended* frame gets `GeneratorExit` thrown in so
        // `finally:`/`with` cleanup runs. We can't run Python from
        // `Drop`, so resurrect the live frame into the VM's
        // pending-finalizer queue; `gc.collect()` and the module-exit
        // path drain it. Created-but-never-started frames have run no
        // user code, so (like CPython's `gen_close`) they are simply
        // marked completed.
        let Ok(mut state) = self.state.try_borrow_mut() else {
            return;
        };
        let prev = std::mem::replace(&mut *state, GeneratorState::Finished);
        drop(state);
        match prev {
            GeneratorState::Suspended(frame) => {
                // Finalized once already (CPython's `_PyGC_FINALIZED` bit):
                // drop the frame for real instead of looping forever
                // through resurrection → finalize → drop.
                if self.finalize_ran.get() {
                    defer_generator_state_drop(GeneratorState::Suspended(frame));
                    return;
                }
                let resurrected = Rc::new(PyGenerator {
                    name: RefCell::new(self.name.borrow().clone()),
                    qualname: RefCell::new(self.qualname.borrow().clone()),
                    kind: self.kind,
                    code: self.code.clone(),
                    state: RefCell::new(GeneratorState::Suspended(frame)),
                    origin: RefCell::new(self.origin.borrow().clone()),
                    hooks_inited: crate::sync::Cell::new(self.hooks_inited.get()),
                    finalizer: RefCell::new(self.finalizer.borrow().clone()),
                    finalize_ran: crate::sync::Cell::new(self.finalize_ran.get()),
                });
                let obj = match self.kind {
                    CoroutineKind::Generator => Object::Generator(resurrected),
                    CoroutineKind::Coroutine => Object::Coroutine(resurrected),
                    CoroutineKind::AsyncGenerator => Object::AsyncGenerator(resurrected),
                };
                crate::vm_singletons::try_push_pending_finalizer(obj);
            }
            // A never-started frame still owns locals that can hold the
            // *next* generator of a pipeline (`chain(chain(chain(…)))`).
            // Dropping it inline recurses one native stack frame per
            // link and overflows on long chains, so route it through
            // the iterative trampoline below.
            state @ GeneratorState::Created(_) => defer_generator_state_drop(state),
            GeneratorState::Finished | GeneratorState::Running => {}
        }
    }
}

/// Flavour of a `PyGenerator`. Stored alongside the suspended frame
/// so the same suspension machinery serves all three async-shaped
/// objects.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CoroutineKind {
    Generator,
    Coroutine,
    AsyncGenerator,
}

impl CoroutineKind {
    /// The flavour word CPython uses in error messages
    /// ("generator already executing", "coroutine ignored
    /// GeneratorExit", "async generator ...").
    pub fn word(self) -> &'static str {
        match self {
            Self::Generator => "generator",
            Self::Coroutine => "coroutine",
            Self::AsyncGenerator => "async generator",
        }
    }
}

/// State machine for an active or exhausted generator. The frame is
/// stored as `Box<dyn Any>` because `PyGenerator` lives in the
/// `object` module but `Frame` lives in `vm::lib`.
pub enum GeneratorState {
    /// Created but not yet started — body hasn't executed past the
    /// initial `RETURN_GENERATOR`.
    Created(Box<dyn std::any::Any + Send + Sync>),
    /// Paused at a `YIELD_VALUE`.
    Suspended(Box<dyn std::any::Any + Send + Sync>),
    /// Body returned (cleanly or via exception). Subsequent
    /// `next`/`send` raise `StopIteration`.
    Finished,
    /// Currently executing — re-entry would be illegal.
    Running,
}

thread_local! {
    /// Worklist for [`defer_generator_state_drop`].
    static GEN_DROP_QUEUE: std::cell::RefCell<Vec<GeneratorState>> =
        const { std::cell::RefCell::new(Vec::new()) };
    /// True while the outermost deferred drop is draining the queue.
    static GEN_DROP_DRAINING: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

/// Drop a generator's frame payload *iteratively*. A generator pipeline
/// (`a = gen(); b = wrap(a); c = wrap(b); …`) dies as a linked chain:
/// dropping the head frame drops the next `Arc<PyGenerator>`, whose
/// `Drop` would drop *its* frame, one native stack frame per link —
/// thousands of links overflow the stack. Instead every generator drop
/// pushes its frame here and only the outermost call drains, so chain
/// teardown runs in constant stack space.
fn defer_generator_state_drop(state: GeneratorState) {
    // `try_with`: during thread teardown our own TLS may already be
    // destroyed; fall back to the inline (recursive) drop then — by
    // that point GcState::drop has already flattened tracked chains.
    let queued = GEN_DROP_QUEUE.try_with(|q| q.borrow_mut().push(state));
    let Ok(()) = queued else {
        return;
    };
    let _ = GEN_DROP_DRAINING.try_with(|flag| {
        if flag.get() {
            // An outer drop is draining; it will pick up our entry.
            return;
        }
        flag.set(true);
        loop {
            let next = GEN_DROP_QUEUE.with(|q| q.borrow_mut().pop());
            match next {
                Some(s) => drop(s),
                None => break,
            }
        }
        flag.set(false);
    });
}

impl fmt::Debug for GeneratorState {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Created(_) => write!(f, "Created"),
            Self::Suspended(_) => write!(f, "Suspended"),
            Self::Finished => write!(f, "Finished"),
            Self::Running => write!(f, "Running"),
        }
    }
}

/// The deferred operation carried by an [`AsyncGenAwait`].
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AgenAwaitKind {
    /// `agen.asend(value)` — resume the agen, sending `value` in.
    Send,
    /// `agen.athrow(exc[, val[, tb]])` — throw into the agen.
    Throw,
    /// `agen.aclose()` — throw `GeneratorExit` into the agen.
    Close,
}

impl AgenAwaitKind {
    /// CPython type name of the awaitable this op produces: `asend`
    /// yields `async_generator_asend`; `athrow`/`aclose` both yield
    /// `async_generator_athrow`.
    pub fn type_name(self) -> &'static str {
        match self {
            AgenAwaitKind::Send => "async_generator_asend",
            AgenAwaitKind::Throw | AgenAwaitKind::Close => "async_generator_athrow",
        }
    }
}

/// Deferred awaitable returned by `agen.asend(v)` / `agen.athrow(e)` /
/// `agen.aclose()` (PEP 525). Mirrors CPython's `async_generator_asend`
/// and `async_generator_athrow`: the operation on the underlying async
/// generator is *deferred* until the awaitable is driven (`await`ed),
/// rather than running eagerly at call time. WeavePy's cooperative async
/// model has no real suspension inside the agen body, so a single drive
/// applies the op and completes the await — but routing through an
/// awaitable (instead of executing inside `asend`/`athrow`/`aclose`) is
/// exactly what makes `await agen.aclose()` legal rather than the bug it
/// replaces (`await None`).
pub struct AsyncGenAwait {
    /// The `Object::AsyncGenerator` this operation targets.
    pub agen: Object,
    pub kind: AgenAwaitKind,
    /// Operation payload: `asend` -> `[value]`, `athrow` -> the throw
    /// args (`[exc, val?, tb?]`), `aclose` -> empty.
    pub args: Vec<Object>,
    /// Set once the awaitable has been driven, so a second pull behaves
    /// like an exhausted iterator (`StopIteration`) instead of replaying
    /// the operation.
    pub consumed: Cell<bool>,
    /// Set on the first drive. The first drive applies the operation payload
    /// (`args`); later drives — reached only when the agen suspended on an
    /// inner `await` and we passed its value through — forward the caller's
    /// sent value to resume that inner await.
    pub started: Cell<bool>,
}

impl fmt::Debug for AsyncGenAwait {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "<{} object>", self.kind.type_name())
    }
}

/// File-like object exposed to Python. Wraps a [`FileBackend`] so
/// the same wrapper can talk to a real file, an in-memory buffer
/// (`io.StringIO`/`io.BytesIO`), or the interpreter's stdout/stderr
/// sinks.
/// Default Python-level buffer size for a buffered file stream
/// (`io.DEFAULT_BUFFER_SIZE`): 128 KiB since CPython 3.14 (gh-117151).
pub const DEFAULT_BUFFER_SIZE: usize = 128 * 1024;

/// `TextIOWrapper._CHUNK_SIZE`, which stayed at 8 KiB when
/// `DEFAULT_BUFFER_SIZE` grew in 3.14.
pub const TEXT_CHUNK_SIZE: usize = 8192;

/// The CPython io-stack layer a [`PyFile`] presents to Python: its
/// `type()` identity and which `io` ABC it answers `isinstance` for.
/// WeavePy backs every file with one monolithic `PyFile`, but reports the
/// faithful layered class (`FileIO`/`BufferedReader`/…/`TextIOWrapper`,
/// `BytesIO`/`StringIO`) so `type(open(p,'rb')) is io.BufferedReader` and
/// `isinstance(io.FileIO(fd), io.RawIOBase)` hold like CPython.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum IoKind {
    /// Unbuffered raw binary file — `io.FileIO` (a `RawIOBase`).
    Raw,
    /// Buffered binary reader — `io.BufferedReader`.
    BufferedReader,
    /// Buffered binary writer — `io.BufferedWriter`.
    BufferedWriter,
    /// Buffered binary read+write — `io.BufferedRandom`.
    BufferedRandom,
    /// Text stream — `io.TextIOWrapper`.
    Text,
    /// In-memory bytes — `io.BytesIO`.
    BytesIO,
    /// In-memory text — `io.StringIO`.
    StringIO,
}

impl IoKind {
    /// Derive the default layer for a freshly opened file from its mode
    /// string (CPython's `open()` buffering rules: text → `TextIOWrapper`,
    /// binary read → `BufferedReader`, binary write/append →
    /// `BufferedWriter`, binary update (`+`) → `BufferedRandom`).
    pub fn from_mode(mode: &str) -> Self {
        if mode.contains('b') {
            if mode.contains('+') {
                IoKind::BufferedRandom
            } else if mode.contains('w') || mode.contains('a') || mode.contains('x') {
                IoKind::BufferedWriter
            } else {
                IoKind::BufferedReader
            }
        } else {
            IoKind::Text
        }
    }
}

/// Faithful incremental text-decode state for a text stream whose codec
/// demands CPython's `TextIOWrapper` incremental machinery (its one-shot
/// `decode` is `None` — a custom incremental-only codec, e.g. test_io's
/// `test_decoder`). The common stateless codecs (utf-8/ascii/latin-1/
/// euc_jp/…) keep the fast one-shot path and never allocate this.
///
/// Mirrors the `_decoder`/`_decoded_chars`/`_snapshot`/`_b2cratio`
/// ADT in `_pyio.TextIOWrapper`: the decoder is driven a chunk at a
/// time, decoded characters are buffered here until the client consumes
/// them, and `_snapshot = (dec_flags, next_input)` records a point where
/// the decoder's input buffer was empty so `tell()`/`seek()` can pack and
/// replay an opaque cookie.
#[derive(Debug)]
pub struct TextIncr {
    /// The (newline-wrapped) Python `IncrementalDecoder` instance.
    pub decoder: Object,
    /// Decoded characters buffered from the last chunk (`_decoded_chars`),
    /// held as a `char` vector so the `_get_decoded_chars(n)` ADT can slice
    /// by *character* count exactly like CPython.
    pub decoded: Vec<char>,
    /// How many of [`TextIncr::decoded`] characters have been handed to the
    /// client (`_decoded_chars_used`).
    pub decoded_used: usize,
    /// `(_snapshot)` — the decoder flags and the not-yet-decoded input
    /// bytes at the last empty-buffer snapshot point. `None` until the
    /// first chunk is read.
    pub snapshot: Option<(Object, Vec<u8>)>,
    /// Running bytes-to-chars ratio used to seed the `tell()` decoder walk
    /// (`_b2cratio`).
    pub b2cratio: f64,
}

// --- Reentrant interpreter bridge for the incremental text-decode path -----
//
// The incremental `TextIOWrapper` machinery drives a *Python* decoder object
// (its `decode`/`getstate`/`setstate`/`reset` methods) and reaches for the
// frozen `codecs`/`_io` modules. Like the rest of `object.rs`'s reentrant
// callbacks (`current_interp_hash`, the `__repr__` bridge), these borrow the
// thread's published interpreter pointer.

fn pf_with_interp<T>(
    f: impl FnOnce(&mut crate::Interpreter) -> Result<T, RuntimeError>,
) -> Result<T, RuntimeError> {
    let ptr = crate::vm_singletons::current_interpreter_ptr()
        .ok_or_else(|| value_error("no running interpreter for text decode"))?;
    // SAFETY: published by the enclosing VM frame on this thread; the GIL keeps
    // the reentrant access exclusive (same contract as `current_interp_hash`).
    let interp = unsafe { &mut *ptr };
    f(interp)
}

/// Call `<module>.<func>(*args)` through the running interpreter.
fn pf_mod_call(module: &str, func: &str, args: &[Object]) -> Result<Object, RuntimeError> {
    pf_with_interp(|interp| {
        let m = interp.import_path(module)?;
        let f = interp.load_attr_public(&m, func)?;
        interp.call_object(f, args, &[])
    })
}

/// Call a plain callable `callable(*args)`.
fn pf_call_value(callable: &Object, args: &[Object]) -> Result<Object, RuntimeError> {
    pf_with_interp(|interp| interp.call_object(callable.clone(), args, &[]))
}

/// Call `obj.<name>(*args)` (a bound method) through the running interpreter.
fn pf_call_method(obj: &Object, name: &str, args: &[Object]) -> Result<Object, RuntimeError> {
    pf_with_interp(|interp| {
        let m = interp.load_attr_public(obj, name)?;
        interp.call_object(m, args, &[])
    })
}

/// Split a decoder `getstate()` result `(bytes, flags)` into its parts.
fn decoder_state_parts(state: &Object) -> Result<(Vec<u8>, Object), RuntimeError> {
    if let Object::Tuple(items) = state {
        if items.len() == 2 {
            let buf = match &items[0] {
                Object::Bytes(b) => b.to_vec(),
                Object::ByteArray(b) => b.borrow().clone(),
                _ => Vec::new(),
            };
            return Ok((buf, items[1].clone()));
        }
    }
    Err(type_error("illegal decoder state"))
}

/// Coerce an int-like `Object` to a `BigInt` (decoder flags / cookie input).
fn obj_to_bigint(o: &Object) -> BigInt {
    match o {
        Object::Int(i) => BigInt::from(*i),
        Object::Long(b) => (**b).clone(),
        Object::Bool(b) => BigInt::from(i64::from(*b)),
        _ => BigInt::from(0),
    }
}

/// Build the `(b'', dec_flags)` tuple a decoder `setstate` expects.
fn make_state_tuple(dec_flags: &BigInt) -> Object {
    Object::new_tuple_array([
        Object::new_bytes(Vec::new()),
        Object::int_from_bigint(dec_flags.clone()),
    ])
}

/// Pack a `TextIOWrapper` cookie, matching CPython's bit layout exactly:
/// `position | (dec_flags<<64) | (bytes_to_feed<<128) | (chars_to_skip<<192)
/// | (need_eof<<256)`.
fn pack_text_cookie(
    position: u64,
    dec_flags: &BigInt,
    bytes_to_feed: u64,
    need_eof: bool,
    chars_to_skip: u64,
) -> Object {
    let mut c = BigInt::from(position);
    c |= dec_flags.clone() << 64usize;
    c |= BigInt::from(bytes_to_feed) << 128usize;
    c |= BigInt::from(chars_to_skip) << 192usize;
    if need_eof {
        c |= BigInt::from(1u64) << 256usize;
    }
    Object::int_from_bigint(c)
}

/// Inverse of [`pack_text_cookie`].
fn unpack_text_cookie(cookie: &BigInt) -> (u64, BigInt, u64, bool, u64) {
    let mask: BigInt = (BigInt::from(1u64) << 64usize) - 1;
    let position = (cookie & &mask).to_u64().unwrap_or(0);
    let rest = cookie >> 64usize;
    let dec_flags = &rest & &mask;
    let rest = rest >> 64usize;
    let bytes_to_feed = (&rest & &mask).to_u64().unwrap_or(0);
    let rest = rest >> 64usize;
    let chars_to_skip = (&rest & &mask).to_u64().unwrap_or(0);
    let rest = rest >> 64usize;
    let need_eof = !(&rest & &mask).is_zero();
    (position, dec_flags, bytes_to_feed, need_eof, chars_to_skip)
}

pub struct PyFile {
    pub name: String,
    pub mode: String,
    pub binary: bool,
    /// The faithful CPython io layer this stream presents (`type()` and
    /// `isinstance` identity); see [`IoKind`].
    pub io_kind: crate::sync::Cell<IoKind>,
    pub backend: RefCell<FileBackend>,
    pub closed: RefCell<bool>,
    /// Text-mode codec (`open(..., encoding=...)`); `None` means the
    /// UTF-8 default.
    pub encoding: RefCell<Option<String>>,
    /// The *verbatim* `encoding=` spelling for `.encoding` reporting.
    /// CPython echoes the caller's string back exactly (`open(...,
    /// encoding='utf-8').encoding == 'utf-8'`, test_tempfile
    /// SpooledTemporaryFile), while [`Self::encoding`] collapses UTF-8
    /// spellings to `None` for the codec fast path. `None` here means no
    /// explicit encoding — report the locale codeset.
    pub encoding_name: RefCell<Option<String>>,
    /// Text-mode error handler (`open(..., errors=...)`); `None` → "strict".
    pub errors: RefCell<Option<String>>,
    /// Text-mode newline policy (`open(..., newline=...)`). A `None` field
    /// value selects CPython's universal-newline default: `\r\n`/`\r`→`\n`
    /// on read and `\n`→`os.linesep` on write. `Some("")` disables all
    /// translation; `Some("\n"|"\r"|"\r\n")` pins an explicit line ending
    /// (`\n`→that ending on write; no input translation).
    pub newline: RefCell<Option<String>>,
    /// Python-visible `name` override. Files opened from a descriptor
    /// start out named by their fd integer; `tempfile` (and user code)
    /// reassign `f.name` to the real path — or, for an anonymous temp file,
    /// back to the integer fd. Stored as an arbitrary object so the override
    /// faithfully round-trips `str`, `bytes`, and `int` (CPython's `FileIO`
    /// exposes a plain writable `name`). The Rust-internal `name` (used for
    /// error messages, etc.) stays put.
    pub name_override: RefCell<Option<Object>>,
    /// The file was opened with a `bytes`/`bytearray` filename, so the
    /// Python-visible `f.name` must read back as `bytes` (CPython keeps the
    /// original object type).
    pub name_is_bytes: crate::sync::Cell<bool>,
    /// The file was opened directly from an integer file descriptor
    /// (`open(fd)`), so — absent a later override — `f.name` must read back as
    /// that `int`, exactly like CPython's `FileIO` (`test_int_name_attribute`).
    pub name_is_fd: crate::sync::Cell<bool>,
    /// The stream has no filesystem name (`io.BytesIO`/`io.StringIO`): reading
    /// `f.name` raises `AttributeError`, like CPython's in-memory streams.
    pub no_name: crate::sync::Cell<bool>,
    /// An in-memory text buffer (`io.StringIO`) received *bridged* lone
    /// surrogates (PUA window, see `builtins::BRIDGE_BASE`) via `write()`
    /// or its initial value. Read paths un-bridge only when set, so a
    /// genuine plane-16 PUA character (U+10F800..U+10FFFF) written to a
    /// surrogate-free buffer round-trips verbatim
    /// (test_capi.test_file `test_pyfile_writestring`).
    pub mem_bridged: crate::sync::Cell<bool>,
    /// CPython `FileIO(fd, closefd=...)`: when `false`, closing the stream
    /// must *not* close the wrapped OS descriptor (the caller still owns it —
    /// e.g. wrapping `sys.stdin`'s fd). Defaults to `true`.
    pub closefd: crate::sync::Cell<bool>,
    /// Per-instance attribute store (CPython's file objects carry a
    /// `__dict__`). Lets user code monkeypatch methods/attributes on a live
    /// stream — e.g. `bio.seekable = lambda: False` (test_bz2 `testSeekable`).
    /// Empty by default (no allocation); checked after the fixed data
    /// attributes but before native methods, so it shadows methods like
    /// CPython's non-data-descriptor instance-dict rule.
    pub extra_attrs: RefCell<Vec<(String, Object)>>,
    /// Memoised binary underlayer for a *text* standard stream (`f.buffer`).
    /// CPython exposes a single, stable `sys.stdin.buffer` object: repeated
    /// accesses return the *same* `BufferedReader`, so identity/`==` holds
    /// (argparse's `FileType('-')` round-trips it). Minted lazily on first
    /// `.buffer` access; `None` until then and for streams that are their own
    /// buffer.
    pub binary_buffer_cache: RefCell<Option<Object>>,
    /// Observed line endings, as CPython's `IncrementalNewlineDecoder` tracks
    /// them for the text-mode `.newlines` attribute. Bit flags: `1`=`\r`,
    /// `2`=`\n`, `4`=`\r\n`. Updated on every text-mode read (regardless of the
    /// `newline=` translation policy); `0` reads back as `None`.
    pub seennl: crate::sync::Cell<u8>,
    /// Pending bytes for a binary [`IoKind::BufferedWriter`] over a real
    /// descriptor: CPython's `BufferedWriter` holds writes in a Python-level
    /// buffer until it fills, an explicit `flush()`, or `close()` — *not*
    /// `fileno()`. This is what lets `os.close(f.fileno())` discard unflushed
    /// data (`test_subprocess.test_bufsize_equal_one_binary_mode`) and a
    /// large buffered write surface its `BrokenPipeError` only at flush
    /// (`test_broken_pipe_cleanup`). Empty for every other stream kind.
    pub write_buf: RefCell<Vec<u8>>,
    /// The buffer-full threshold for [`PyFile::write_buf`] (`open(...,
    /// buffering=N)`; `DEFAULT_BUFFER_SIZE` otherwise).
    pub buf_size: crate::sync::Cell<usize>,
    /// BOM-once bookkeeping for a text stream using a BOM-prefixing codec
    /// (`utf-16`/`utf-32`/`utf-8-sig`): `true` while the encoder is at the
    /// start of the stream and the next write must emit the BOM. Cleared by the
    /// first write (and re-set by `seek(0)`), so the BOM is written exactly once
    /// — CPython's `encoding_start_of_stream` (`test_io` BOM/seek cases).
    pub text_start_of_stream: crate::sync::Cell<bool>,
    /// CPython `TextIOWrapper`'s `telling` flag. `next(f)` / `for line in f`
    /// drives `__next__`, which disables `tell()` (it would otherwise have to
    /// unwind the readahead snapshot): `tell()` raises
    /// `OSError("telling position disabled by next() call")` until the iterator
    /// is exhausted or an explicit `seek()` re-enables it. Text streams only —
    /// a binary stream's `tell()` stays live during iteration
    /// (`test_io.test_telling`). Defaults to `true`.
    pub telling: crate::sync::Cell<bool>,
    /// Tri-state gate for the faithful incremental text-decode path:
    /// `None` = undecided (compute on first text read), `Some(false)` =
    /// the codec has a one-shot `decode` so the fast path is used,
    /// `Some(true)` = the codec is incremental-only and reads/seeks route
    /// through [`PyFile::text_incr`]. Decided once and cached so the hot
    /// read path never re-probes `codecs.lookup`.
    pub text_incr_gate: crate::sync::Cell<Option<bool>>,
    /// Lazily-built incremental decoder + cookie state (see [`TextIncr`]).
    /// `None` until the incremental path activates.
    pub text_incr: RefCell<Option<TextIncr>>,
    /// CPython `FileIO._blksize`: the filesystem's preferred block size,
    /// captured from `fstat` at open time (falling back to
    /// `io.DEFAULT_BUFFER_SIZE` when the stat has no useful `st_blksize`).
    /// `open()` seeds it; other constructors keep the default.
    pub blksize: crate::sync::Cell<i64>,
    /// The class name to render in `repr()` for a `FileIO` *subclass*
    /// instance (CPython's `fileio_repr` prints `Py_TYPE(self)->tp_name`, so
    /// `<TestSubclass name=...>`). `None` renders the base `_io.FileIO`.
    pub repr_class: RefCell<Option<String>>,
    /// Serializes the raw descriptor syscalls (`read`/`write`/`lseek`) this
    /// stream issues with the GIL released. CPython's buffered objects
    /// (`BufferedReader`/`Writer`/`Random`, which `TextIOWrapper` stacks on)
    /// guard every raw op with a per-object lock acquired GIL-free
    /// (`ENTER_BUFFERED`), so two threads never have a `read(2)` and a
    /// `write(2)` in flight on the same file description at once. Without
    /// that, the kernel's read path can observe the shared offset *before* a
    /// concurrent write publishes its offset advance, letting an iterating
    /// reader steal a just-written byte and desync the offset from EOF
    /// (test_io.test_write_readline_races). `Arc` so the dup-ed `.buffer`
    /// sibling — which shares the OS file description and offset — shares the
    /// lock too.
    pub fd_syscall_lock: std::sync::Arc<std::sync::Mutex<()>>,
    /// Bytes read ahead of the logical stream position, served back before the
    /// backend on the next read. Universal-newline `readline` on a
    /// *non-seekable* stream must read one byte past a `\r` to distinguish a
    /// lone `\r` from the front half of `\r\n` (CPython's incremental newline
    /// decoder holds the `\r` back); when that byte starts the next line it
    /// cannot be `lseek`-ed back, so it parks here
    /// (test_file_eintr.test_readlines: SIGINT splits the pipe read between
    /// `\r` and `\n`).
    pub read_pushback: RefCell<Vec<u8>>,
}

impl PyFile {
    pub fn new(name: impl Into<String>, mode: impl Into<String>, backend: FileBackend) -> Self {
        let mode_s = mode.into();
        let binary = mode_s.contains('b');
        let io_kind = IoKind::from_mode(&mode_s);
        Self {
            name: name.into(),
            mode: mode_s,
            binary,
            io_kind: crate::sync::Cell::new(io_kind),
            backend: RefCell::new(backend),
            closed: RefCell::new(false),
            encoding: RefCell::new(None),
            encoding_name: RefCell::new(None),
            errors: RefCell::new(None),
            newline: RefCell::new(None),
            name_override: RefCell::new(None),
            name_is_bytes: crate::sync::Cell::new(false),
            name_is_fd: crate::sync::Cell::new(false),
            no_name: crate::sync::Cell::new(false),
            mem_bridged: crate::sync::Cell::new(false),
            closefd: crate::sync::Cell::new(true),
            extra_attrs: RefCell::new(Vec::new()),
            binary_buffer_cache: RefCell::new(None),
            seennl: crate::sync::Cell::new(0),
            write_buf: RefCell::new(Vec::new()),
            buf_size: crate::sync::Cell::new(DEFAULT_BUFFER_SIZE),
            text_start_of_stream: crate::sync::Cell::new(true),
            telling: crate::sync::Cell::new(true),
            text_incr_gate: crate::sync::Cell::new(None),
            text_incr: RefCell::new(None),
            blksize: crate::sync::Cell::new(DEFAULT_BUFFER_SIZE as i64),
            repr_class: RefCell::new(None),
            fd_syscall_lock: std::sync::Arc::new(std::sync::Mutex::new(())),
            read_pushback: RefCell::new(Vec::new()),
        }
    }

    /// Whether writes are held in [`PyFile::write_buf`] rather than going
    /// straight to the OS: a binary `BufferedWriter` backed by a real
    /// descriptor. Append/random and text streams write through (unchanged
    /// behaviour); in-memory streams are their own buffer.
    pub fn is_write_buffered(&self) -> bool {
        self.io_kind.get() == IoKind::BufferedWriter
            && matches!(&*self.backend.borrow(), FileBackend::Disk(_))
    }

    /// Flush the pending [`PyFile::write_buf`] to the backing descriptor.
    /// Drains the buffer first so a failed write (e.g. `EPIPE` to a child
    /// that already exited) leaves nothing to re-flush, then surfaces the
    /// error like CPython's `BufferedWriter._flush_unlocked`.
    pub fn flush_write_buf(&self) -> Result<(), RuntimeError> {
        // `pending` is mutated only on the Unix drain path below; off Unix it is
        // write-only-once, so suppress the spurious `unused_mut` there.
        #[cfg_attr(not(unix), allow(unused_mut))]
        let mut pending = {
            let mut wb = self.write_buf.borrow_mut();
            if wb.is_empty() {
                return Ok(());
            }
            std::mem::take(&mut *wb)
        };
        // On Unix, drain to the descriptor through the PEP 475-aware loop:
        // snapshot the raw fd under a *short* borrow, release it, then do the
        // (possibly blocking, GIL-released) write. Holding `backend` across the
        // write would deadlock a signal handler that touches the same file, and
        // `write_all` would silently retry `EINTR` — never letting a `SIGALRM`
        // handler raise — which is the `test_interrupted_write_buffered` hang.
        #[cfg(unix)]
        {
            use std::os::unix::io::AsRawFd;
            let raw_fd = match &*self.backend.borrow() {
                FileBackend::Disk(f) => Some(f.as_raw_fd()),
                _ => None,
            };
            if let Some(fd) = raw_fd {
                let res = write_drain_fd_intr(fd, &mut pending, &self.fd_syscall_lock);
                // A partial / would-block flush (or a signal-handler raise)
                // leaves the unwritten remainder in `pending`; put it back into
                // `write_buf` so it isn't lost and a later flush can finish it.
                // Re-prepend it ahead of any bytes a reentrant `write()` staged
                // while the GIL was released during the drain.
                if !pending.is_empty() {
                    let mut wb = self.write_buf.borrow_mut();
                    if wb.is_empty() {
                        *wb = pending;
                    } else {
                        pending.extend_from_slice(&wb);
                        *wb = pending;
                    }
                }
                return res;
            }
        }
        let mut backend = self.backend.borrow_mut();
        if let FileBackend::Disk(f) = &mut *backend {
            use std::io::Write;
            f.write_all(&pending)
                .map_err(|e| crate::error::io_error_to_py(&e))?;
        }
        Ok(())
    }

    /// `close()` that first flushes the write buffer, mirroring `_pyio`'s
    /// `try: self.flush() finally: self.raw.close()`: the descriptor is
    /// always released, but a flush error (a broken pipe) still propagates.
    pub fn close_with_flush(&self) -> Result<(), RuntimeError> {
        if *self.closed.borrow() {
            return Ok(());
        }
        let flush_res = self.flush_write_buf();
        // `close(2)` can itself fail — CPython's `FileIO.close` raises
        // `OSError(EBADF)` when the descriptor was already closed out from
        // under the object (`os.close(f.fileno())`; test_fileio
        // `testErrnoOnClose`). The object still transitions to closed.
        let close_res = self.close_report();
        flush_res?;
        close_res.map_err(|e| crate::error::io_error_to_py(&e))
    }

    /// Read a monkeypatched per-instance attribute, if set.
    pub fn get_extra_attr(&self, name: &str) -> Option<Object> {
        self.extra_attrs
            .borrow()
            .iter()
            .find(|(k, _)| k == name)
            .map(|(_, v)| v.clone())
    }

    /// Set a per-instance attribute (insert or overwrite).
    pub fn set_extra_attr(&self, name: &str, value: Object) {
        let mut attrs = self.extra_attrs.borrow_mut();
        if let Some(slot) = attrs.iter_mut().find(|(k, _)| k == name) {
            slot.1 = value;
        } else {
            attrs.push((name.to_owned(), value));
        }
    }

    /// Delete a per-instance attribute (`del f.attr`); returns whether the
    /// name was present. CPython's file objects carry a `__dict__`, so an
    /// attribute set via `setattr` is removable again — `test.support.swap_attr`
    /// relies on `delattr` succeeding (or raising `AttributeError`, never
    /// `TypeError`) when restoring a monkeypatched method/`name`.
    pub fn delete_extra_attr(&self, name: &str) -> bool {
        let mut attrs = self.extra_attrs.borrow_mut();
        if let Some(pos) = attrs.iter().position(|(k, _)| k == name) {
            attrs.remove(pos);
            true
        } else {
            false
        }
    }

    /// Remove a user-assigned `f.name` override (`del f.name`); returns whether
    /// an override was present. Only the *user* override is cleared — a real
    /// `FileIO`'s intrinsic path/fd name is not user-deletable (CPython's
    /// `FileIO.name` getset has no deleter), so this leaves intrinsic names in
    /// place and the caller raises `AttributeError`.
    pub fn clear_name_override(&self) -> bool {
        let had = self.name_override.borrow().is_some();
        *self.name_override.borrow_mut() = None;
        had
    }

    /// Reassign the Python-visible `name` (`f.name = ...`). Accepts any
    /// object so an fd integer round-trips faithfully (CPython's `tempfile`
    /// rewrites `raw.name` to the fd for anonymous temp files).
    pub fn set_name(&self, name: Object) {
        *self.name_override.borrow_mut() = Some(name);
    }

    /// Override the presented io layer (`io.FileIO(fd)` → `Raw`,
    /// `io.BytesIO()` → `BytesIO`, `open(..., buffering=0)` → `Raw`).
    pub fn set_io_kind(&self, kind: IoKind) {
        self.io_kind.set(kind);
    }

    /// The Python-visible `name` *object*: `str` normally, `bytes` when the
    /// file was opened with a bytes filename, or `None` for in-memory streams
    /// (where the caller raises `AttributeError`). A user-set override always
    /// wins and is returned as `str`.
    pub fn name_obj(&self) -> Option<Object> {
        if let Some(n) = self.name_override.borrow().clone() {
            return Some(n);
        }
        if self.no_name.get() {
            return None;
        }
        if self.name_is_fd.get() {
            // Opened from a bare fd: `name` is the integer descriptor.
            if let Ok(fd) = self.name.parse::<i64>() {
                return Some(Object::Int(fd));
            }
        }
        if self.name_is_bytes.get() {
            Some(Object::new_bytes(self.name.clone().into_bytes()))
        } else {
            Some(Object::from_str(self.name.clone()))
        }
    }

    /// The binary underlayer exposed as `f.buffer` / `f.raw`. CPython's
    /// `sys.stdin` is a text `TextIOWrapper` whose `.buffer` is a *distinct*
    /// binary `BufferedReader`; collapsing them onto one text-mode object made
    /// `sys.stdin.buffer.read()` hand back `str`. For a text-mode standard
    /// input we therefore mint a binary view over the same backend (stdin is a
    /// process-global resource, so sharing the fd is correct). Every other
    /// stream already round-trips raw bytes through `read`/`write`, so it can
    /// serve as its own buffer — signalled here by returning `None`.
    pub fn binary_buffer(&self) -> Option<Object> {
        if self.binary {
            return None;
        }
        // A stable, memoised object: CPython's `sys.stdin.buffer` is the same
        // `BufferedReader` every access (so `buf is sys.stdin.buffer` and
        // argparse's `FileType('rb')('-')` round-trip hold). Mint once, cache.
        if let Some(buf) = self.binary_buffer_cache.borrow().as_ref() {
            return Some(buf.clone());
        }
        // `sys.stdin/stdout/stderr.buffer` is the underlying *binary* stream
        // sharing the same OS sink/source, so `print` (text) and
        // `sys.stdout.buffer.write(b"...")` (raw bytes, e.g. `python -m
        // base64`/`gzip`) both reach the same descriptor.
        let backend = self.backend.borrow();
        let buf = match &*backend {
            FileBackend::Stdin => Some(Object::File(Rc::new(PyFile::new(
                "<stdin>",
                "rb",
                FileBackend::Stdin,
            )))),
            FileBackend::Stdout(w) => Some(Object::File(Rc::new(PyFile::new(
                "<stdout>",
                "wb",
                FileBackend::Stdout(w.clone()),
            )))),
            FileBackend::Stderr(w) => Some(Object::File(Rc::new(PyFile::new(
                "<stderr>",
                "wb",
                FileBackend::Stderr(w.clone()),
            )))),
            // A *text* disk file (CPython's `TextIOWrapper`) exposes its binary
            // underlayer (`BufferedRandom`). We collapse the buffer/raw layers
            // into one `PyFile`, so mint a binary sibling over a `dup`-ed
            // descriptor: a duplicated fd shares the OS file *description*, so
            // the two stay in lock-step on the seek offset (which is what
            // `SpooledTemporaryFile.rollover`'s `buffer.write` + `seek` relies
            // on). `try_clone` failing simply means no `.buffer`.
            FileBackend::Disk(file) => file.try_clone().ok().map(|dup| {
                let mut binmode = self.mode.replace('t', "");
                if !binmode.contains('b') {
                    binmode.push('b');
                }
                let mut bf = PyFile::new(self.name.clone(), binmode, FileBackend::Disk(dup));
                // The dup-ed descriptor shares the OS file *description* —
                // and thus the seek offset — with this stream, so raw
                // syscalls on either object must serialize on one lock.
                bf.fd_syscall_lock = self.fd_syscall_lock.clone();
                if let Some(n) = self.name_override.borrow().as_ref() {
                    *bf.name_override.borrow_mut() = Some(n.clone());
                }
                bf.name_is_bytes.set(self.name_is_bytes.get());
                // `f.buffer.raw.closefd` must report the same ownership flag as
                // the text wrapper it came from (`test_io.test_closefd_attr`):
                // a stream opened `open(fd, ..., closefd=False)` does not own
                // its descriptor.
                bf.closefd.set(self.closefd.get());
                bf.name_is_fd.set(self.name_is_fd.get());
                Object::File(Rc::new(bf))
            }),
            _ => None,
        };
        if let Some(b) = &buf {
            *self.binary_buffer_cache.borrow_mut() = Some(b.clone());
        }
        buf
    }

    /// The stream's `mode` attribute as CPython reports it. A binary stream
    /// (CPython `FileIO`/`Buffered*`) normalises to canonical form, so
    /// `open(p, 'w+b').mode == 'rb+'` and `open(p, 'wb').mode == 'wb'`. A text
    /// stream (`TextIOWrapper`) reports the mode string it was opened with.
    pub fn reported_mode(&self) -> String {
        if !self.binary {
            return self.mode.clone();
        }
        let m = &self.mode;
        let created = m.contains('x');
        let appending = m.contains('a');
        let plus = m.contains('+');
        let readable = m.contains('r') || plus;
        let writable = m.contains('w') || appending || created || plus;
        if created {
            if readable {
                "xb+"
            } else {
                "xb"
            }
        } else if appending {
            if readable {
                "ab+"
            } else {
                "ab"
            }
        } else if readable {
            if writable {
                "rb+"
            } else {
                "rb"
            }
        } else {
            "wb"
        }
        .to_string()
    }

    /// The CPython `tp_repr` string for this stream — the `<_io.… >` form keyed
    /// on the presented io layer ([`IoKind`]). Shared by [`Object::repr`] and
    /// the unclosed-file `ResourceWarning` emitted from [`Drop`], so the two
    /// render byte-identically (`test_io.test_warn_on_dealloc` checks that the
    /// pre-drop `repr(f)` is a substring of the warning message). `self_addr`
    /// supplies the object address for the in-memory (`BytesIO`/`StringIO`)
    /// variants that render `at 0x…`; OS-backed streams ignore it.
    pub fn repr_with_addr(&self, self_addr: usize) -> String {
        match self.io_kind.get() {
            IoKind::BytesIO => format!("<_io.BytesIO object at 0x{self_addr:x}>"),
            IoKind::StringIO => format!("<_io.StringIO object at 0x{self_addr:x}>"),
            kind => {
                // A `FileIO` subclass instance renders its own class name
                // (CPython prints `Py_TYPE(self)->tp_name`).
                let cls: String = self
                    .repr_class
                    .borrow()
                    .clone()
                    .unwrap_or_else(|| "_io.FileIO".to_owned());
                // CPython's `fileio_repr`: a closed raw file (fd < 0) prints
                // no name/mode at all (test_fileio `testRepr`).
                if kind == IoKind::Raw && self.is_closed() {
                    return format!("<{cls} [closed]>");
                }
                // CPython's `fileio_repr`/`textiowrapper_repr` guard the
                // `name` render with `Py_ReprEnter`: a `name` that leads back
                // to this stream raises RuntimeError instead of recursing
                // (test_fileio `testRecursiveRepr`). Infallible context, so
                // the error is parked for the fallible repr boundary.
                if !repr_enter(self_addr) {
                    stash_repr_error(crate::error::runtime_error(
                        "reentrant call inside _io stream __repr__".to_owned(),
                    ));
                    return "<...>".to_owned();
                }
                // A raw file whose `name` was deleted (`del f.name`) falls
                // back to `fd=N` (CPython keeps `name` in the instance dict;
                // `fileio_repr` catches the AttributeError and prints the fd).
                let deleted_name = kind == IoKind::Raw && self.name_obj().is_none();
                let name = self
                    .name_obj()
                    .map(|o| o.repr())
                    .unwrap_or_else(|| format!("'{}'", self.name));
                repr_leave();
                match kind {
                    IoKind::Raw if deleted_name => format!(
                        "<{} fd={} mode='{}' closefd={}>",
                        cls,
                        self.fileno().unwrap_or(-1),
                        self.reported_mode(),
                        if self.closefd.get() { "True" } else { "False" }
                    ),
                    IoKind::Raw => format!(
                        "<{} name={} mode='{}' closefd={}>",
                        cls,
                        name,
                        self.reported_mode(),
                        if self.closefd.get() { "True" } else { "False" }
                    ),
                    IoKind::BufferedReader => format!("<_io.BufferedReader name={name}>"),
                    IoKind::BufferedWriter => format!("<_io.BufferedWriter name={name}>"),
                    IoKind::BufferedRandom => format!("<_io.BufferedRandom name={name}>"),
                    _ => {
                        // Echo the caller's exact `encoding=` spelling, as
                        // CPython's TextIOWrapper repr does.
                        let enc = self
                            .encoding_name
                            .borrow()
                            .clone()
                            .unwrap_or_else(|| "utf-8".to_owned());
                        format!(
                            "<_io.TextIOWrapper name={} mode='{}' encoding='{}'>",
                            name, self.mode, enc
                        )
                    }
                }
            }
        }
    }

    /// Whether this stream is an in-memory `BytesIO`/`StringIO` buffer rather
    /// than a real disk file or standard stream. CPython's in-memory streams
    /// do not carry the `mode`/`name` attributes that OS-backed file objects
    /// do, so callers gate those attributes on this.
    pub fn is_memory(&self) -> bool {
        matches!(
            &*self.backend.borrow(),
            FileBackend::MemBytes { .. } | FileBackend::MemText { .. }
        )
    }

    /// Whether the stream is attached to a terminal (`f.isatty()`). The
    /// standard streams defer to the real process handles (so a piped or
    /// redirected `sys.stdin` reports `False`); in-memory `BytesIO`/
    /// `StringIO` buffers are never ttys.
    pub fn isatty(&self) -> bool {
        use std::io::IsTerminal;
        match &*self.backend.borrow() {
            FileBackend::Disk(f) => f.is_terminal(),
            FileBackend::Stdin => std::io::stdin().is_terminal(),
            FileBackend::Stdout(_) => std::io::stdout().is_terminal(),
            FileBackend::Stderr(_) => std::io::stderr().is_terminal(),
            FileBackend::MemBytes { .. } | FileBackend::MemText { .. } => false,
        }
    }

    /// `f.fileno()` — the underlying OS file descriptor. Disk files expose
    /// their real fd; the standard streams report 0/1/2; in-memory
    /// `BytesIO`/`StringIO` have no descriptor and return `None` (the caller
    /// raises `io.UnsupportedOperation`). Mirrors `io.IOBase.fileno`.
    pub fn fileno(&self) -> Option<i64> {
        match &*self.backend.borrow() {
            #[cfg(unix)]
            FileBackend::Disk(f) => {
                use std::os::unix::io::AsRawFd;
                Some(i64::from(f.as_raw_fd()))
            }
            #[cfg(windows)]
            FileBackend::Disk(f) => {
                // RFC 0063: the CRT fd model. Python-visible descriptors on
                // Windows are CRT fds (CPython opens through `_wopen` and
                // exposes the fd), never raw HANDLEs — `msvcrt.get_osfhandle
                // (f.fileno())`, `os.fstat(f.fileno())`, and `mmap(f.fileno())`
                // all consume the CRT domain. The registry mints one fd per
                // handle on first use and transfers handle ownership to it;
                // the close path (below) releases through the fd.
                crate::stdlib::nt_support::fileno_for_disk_file(f)
                    .ok()
                    .map(i64::from)
            }
            #[cfg(not(any(unix, windows)))]
            FileBackend::Disk(_) => None,
            FileBackend::Stdin => Some(0),
            FileBackend::Stdout(_) => Some(1),
            FileBackend::Stderr(_) => Some(2),
            FileBackend::MemBytes { .. } | FileBackend::MemText { .. } => None,
        }
    }

    /// `f.readable()` — whether reads are permitted. Disk files derive it
    /// from the mode (`r`/`+`); the std streams and in-memory buffers
    /// report their fixed capability. Mirrors `io.IOBase.readable`.
    pub fn readable(&self) -> bool {
        match &*self.backend.borrow() {
            FileBackend::Stdin => true,
            FileBackend::Stdout(_) | FileBackend::Stderr(_) => false,
            FileBackend::MemBytes { .. } | FileBackend::MemText { .. } => true,
            FileBackend::Disk(_) => self.mode.contains('r') || self.mode.contains('+'),
        }
    }

    /// `f.writable()` — whether writes are permitted.
    pub fn writable(&self) -> bool {
        match &*self.backend.borrow() {
            FileBackend::Stdin => false,
            FileBackend::Stdout(_) | FileBackend::Stderr(_) => true,
            FileBackend::MemBytes { .. } | FileBackend::MemText { .. } => true,
            FileBackend::Disk(_) => {
                self.mode.contains('w')
                    || self.mode.contains('a')
                    || self.mode.contains('x')
                    || self.mode.contains('+')
            }
        }
    }

    /// `f.seekable()` — in-memory buffers always support random access; a
    /// disk-backed stream is seekable only if the underlying descriptor is
    /// (a regular file is, a pipe/FIFO/socket is not). CPython's `FileIO`
    /// probes this with `lseek(fd, 0, SEEK_CUR)` and treats `ESPIPE` as
    /// "not seekable" (`test_io.test_optional_abilities` over `os.pipe()`).
    pub fn seekable(&self) -> bool {
        match &*self.backend.borrow() {
            FileBackend::MemBytes { .. } | FileBackend::MemText { .. } => true,
            FileBackend::Disk(f) => {
                #[cfg(unix)]
                {
                    use std::os::unix::io::AsRawFd;
                    let fd = f.as_raw_fd();
                    // SEEK_CUR with a zero offset reports the position without
                    // moving it, so this is a side-effect-free probe.
                    unsafe { libc::lseek(fd, 0, libc::SEEK_CUR) >= 0 }
                }
                #[cfg(not(unix))]
                {
                    let _ = f;
                    true
                }
            }
            _ => false,
        }
    }

    /// Set the text-mode codec. UTF-8 spellings collapse to the
    /// `None` fast path.
    pub fn set_encoding(&self, enc: &str) {
        let norm = enc.to_ascii_lowercase().replace(['-', '_'], "");
        *self.encoding_name.borrow_mut() = Some(enc.to_owned());
        *self.encoding.borrow_mut() = if norm == "utf8" {
            None
        } else {
            Some(enc.to_owned())
        };
    }

    /// Set the text-mode error handler (`open(..., errors=...)`). A
    /// `"strict"` handler keeps the `None` fast path.
    pub fn set_errors(&self, errors: &str) {
        *self.errors.borrow_mut() = if errors == "strict" {
            None
        } else {
            Some(errors.to_owned())
        };
    }

    /// Set the text-mode newline policy (`open(..., newline=...)`). The
    /// Python value `None` leaves the field unset (universal newlines).
    pub fn set_newline(&self, newline: Option<&str>) {
        *self.newline.borrow_mut() = newline.map(str::to_owned);
    }

    /// The error-handler name to feed the codec layer (`"strict"` default).
    pub(crate) fn errors_name(&self) -> String {
        self.errors
            .borrow()
            .clone()
            .unwrap_or_else(|| "strict".to_owned())
    }

    /// CPython newline translation applied to text-mode *output*: `\n` is
    /// rewritten to the configured line ending. Universal mode maps `\n`→
    /// `os.linesep` (a no-op on WeavePy's Unix targets); `''`/`'\n'` are
    /// pass-through.
    fn translate_newlines_write(&self, s: &str) -> String {
        match self.newline.borrow().as_deref() {
            Some("\r") => s.replace('\n', "\r"),
            Some("\r\n") => s.replace('\n', "\r\n"),
            // `StringIO(newline=None)` translates *on write* (CPython's
            // `_io.StringIO.write` drives the incremental newline decoder over
            // the incoming text), so the buffer — and thus `getvalue()` —
            // holds the collapsed form. Byte-backed text files translate on
            // *read* instead (`translate_newlines_read`). Because the raw
            // `\r`/`\r\n` endings are gone once collapsed, the `.newlines`
            // tally must be taken *here*, pre-translation
            // (test_memoryio.test_newlines_property).
            None if self.io_kind.get() == IoKind::StringIO => {
                self.record_seen_newlines(s);
                if s.as_bytes().contains(&b'\r') {
                    s.replace("\r\n", "\n").replace('\r', "\n")
                } else {
                    s.to_owned()
                }
            }
            _ => s.to_owned(),
        }
    }

    /// CPython newline translation applied to text-mode *input*: only the
    /// universal mode (`newline=None`) collapses `\r\n` and lone `\r` to
    /// `\n`. Any explicit `newline=` (including `''`) leaves input untouched.
    fn translate_newlines_read(&self, s: String) -> String {
        // CPython's `IncrementalNewlineDecoder` records observed line endings
        // on every read for the `.newlines` attribute, *independent* of whether
        // translation is enabled — so update the tally before translating.
        self.record_seen_newlines(&s);
        if self.newline.borrow().is_none() && s.as_bytes().contains(&b'\r') {
            s.replace("\r\n", "\n").replace('\r', "\n")
        } else {
            s
        }
    }

    /// Fold the line endings present in a freshly decoded chunk into `seennl`.
    fn record_seen_newlines(&self, s: &str) {
        if !s.as_bytes().iter().any(|&b| b == b'\r' || b == b'\n') {
            return;
        }
        let crlf = s.matches("\r\n").count();
        let cr = s.as_bytes().iter().filter(|&&b| b == b'\r').count() - crlf;
        let lf = s.as_bytes().iter().filter(|&&b| b == b'\n').count() - crlf;
        let mut flags = self.seennl.get();
        if cr > 0 {
            flags |= 1;
        }
        if lf > 0 {
            flags |= 2;
        }
        if crlf > 0 {
            flags |= 4;
        }
        self.seennl.set(flags);
    }

    /// The Python-visible text-mode `.newlines`: `None` when nothing has been
    /// read yet, a single string when one kind of ending was seen, or a tuple
    /// of all kinds seen — matching CPython's `IncrementalNewlineDecoder`.
    pub fn newlines_obj(&self) -> Object {
        let tup = |parts: &[&'static str]| {
            Object::new_tuple(parts.iter().map(|p| Object::from_static(p)).collect())
        };
        match self.seennl.get() {
            1 => Object::from_static("\r"),
            2 => Object::from_static("\n"),
            3 => tup(&["\r", "\n"]),
            4 => Object::from_static("\r\n"),
            5 => tup(&["\r", "\r\n"]),
            6 => tup(&["\n", "\r\n"]),
            7 => tup(&["\r", "\n", "\r\n"]),
            _ => Object::None,
        }
    }

    /// Encode a text-mode write through the file's codec, honouring the
    /// configured `errors=` handler and `newline=` translation.
    pub fn encode_text(&self, s: &str) -> Result<Vec<u8>, RuntimeError> {
        let translated = self.translate_newlines_write(s);
        let errors = self.errors_name();
        let enc = match &*self.encoding.borrow() {
            Some(enc) => enc.clone(),
            None if errors == "strict" => return Ok(translated.into_bytes()),
            None => "utf-8".to_owned(),
        };
        // BOM-once: a BOM-prefixing codec emits the BOM only on the first write
        // to a stream positioned at its start; subsequent writes (and any write
        // to a stream seeked off byte 0, e.g. append mode) use the BOM-less
        // continuation codec (CPython `encoding_start_of_stream`).
        let effective = match crate::stdlib::codecs_mod::bom_continuation(&enc) {
            Some(cont) if !self.text_start_of_stream.get() => cont.to_owned(),
            _ => enc.clone(),
        };
        // Text-model codec check happened at wrapper construction; per-write
        // codec calls must not repeat it (`test_io.test_illegal_encoder`).
        let _exempt = crate::stdlib::codecs_mod::io_text_exempt_guard();
        let out = crate::stdlib::codecs_mod::encode_str(&translated, &effective, &errors)?;
        self.text_start_of_stream.set(false);
        Ok(out)
    }

    /// Encode a surrogate-bearing `str` (code points, possibly containing lone
    /// surrogates) for a text-mode write, honouring the file's codec and
    /// `errors=` handler. Mirrors [`Self::encode_text`] for the `WStr` case:
    /// a strict UTF-8 stream raises `UnicodeEncodeError` on a lone surrogate,
    /// while `surrogateescape`/`surrogatepass` round-trip it. Newline
    /// translation is skipped — `\n`/`\r` are scalar values unaffected by the
    /// surrogate payload, and a `WStr` only exists because of the surrogates.
    pub fn encode_text_codepoints(&self, cps: &[u32]) -> Result<Vec<u8>, RuntimeError> {
        let errors = self.errors_name();
        let enc = match &*self.encoding.borrow() {
            Some(enc) => enc.clone(),
            None => "utf-8".to_owned(),
        };
        crate::stdlib::codecs_mod::encode_codepoints(cps, &enc, &errors)
    }

    /// Decode a text-mode read through the file's codec, honouring the
    /// configured `errors=` handler and universal-newline translation.
    pub fn decode_text(&self, bytes: Vec<u8>) -> Result<String, RuntimeError> {
        // `surrogateescape`/`surrogatepass` can decode to *lone surrogates*,
        // which a Rust `String` cannot hold — route those through the
        // Object-producing decoder and bridge surrogates into the PUA window
        // (the same scheme `StringIO` uses); `stream_text_object` un-bridges
        // on the way out.
        fn decode_or_bridge(bytes: &[u8], enc: &str, errors: &str) -> Result<String, RuntimeError> {
            if matches!(errors, "surrogateescape" | "surrogatepass") {
                let obj = crate::stdlib::codecs_mod::decode_bytes_obj(bytes, enc, errors)?;
                return crate::builtins::bridge_str_of(&obj)
                    .ok_or_else(|| value_error("codec did not return a str"));
            }
            crate::stdlib::codecs_mod::decode_bytes(bytes, enc, errors)
        }
        let errors = self.errors_name();
        // Text-model codec check happened at wrapper construction; per-read
        // codec calls must not repeat it (`test_io.test_illegal_decoder`).
        let _exempt = crate::stdlib::codecs_mod::io_text_exempt_guard();
        let decoded = match &*self.encoding.borrow() {
            Some(enc) => decode_or_bridge(&bytes, enc, &errors)?,
            None if errors == "strict" => {
                // Fast, zero-copy path for the overwhelmingly common valid-UTF-8
                // case; on malformed input fall back to the codec so the failure
                // surfaces as a CPython-faithful `UnicodeDecodeError` ("'utf-8'
                // codec can't decode byte …") rather than a Rust `Utf8Error`
                // string wrapped in a bare `ValueError` — pandas' `read_csv`/
                // `read_json` (GH39450) match on the former.
                match String::from_utf8(bytes) {
                    Ok(s) => s,
                    Err(e) => {
                        crate::stdlib::codecs_mod::decode_bytes(&e.into_bytes(), "utf-8", &errors)?
                    }
                }
            }
            None => decode_or_bridge(&bytes, "utf-8", &errors)?,
        };
        Ok(self.translate_newlines_read(decoded))
    }

    /// Read up to `n` Unicode *characters* from a text-mode stream (CPython
    /// `TextIOWrapper.read(size)` / `StringIO.read(size)` count code points,
    /// not bytes). In-memory text is already code-point addressed, so a single
    /// sized `read_bytes` returns exactly `n` chars' worth of bytes; a byte
    /// descriptor (`open(p)` over disk, stdin) is decoded one code point at a
    /// time so a multibyte character is never split across the `n`-char
    /// boundary — `open(p, encoding="utf-8").read(2)` over "héllo" yields "hé",
    /// not a half-decoded 2-byte slice that raises a UTF-8 error.
    pub fn read_text_n(&self, n: usize) -> Result<String, RuntimeError> {
        let mem_text_bytes = {
            if let FileBackend::MemText { data, pos } = &mut *self.backend.borrow_mut() {
                // `pos` is a byte offset into valid UTF-8; advance it by `n`
                // whole characters so a multibyte char is never split
                // (`StringIO("h\u00e9llo").read(2)` == "h\u00e9"). The raw
                // `read_bytes` path deliberately counts *bytes*, not chars.
                // A position seeked past the end reads as EOF.
                let s = data.get(*pos..).unwrap_or("");
                let end_rel = s.char_indices().nth(n).map(|(i, _)| i).unwrap_or(s.len());
                let out = s.as_bytes()[..end_rel].to_vec();
                *pos += end_rel;
                Some(out)
            } else {
                None
            }
        };
        if let Some(bytes) = mem_text_bytes {
            return self.decode_text(bytes);
        }
        let mut bytes: Vec<u8> = Vec::new();
        let mut chars = 0usize;
        while chars < n {
            let lead = self.read_bytes(Some(1))?;
            let Some(&b0) = lead.first() else {
                break; // EOF
            };
            // UTF-8 lead byte → number of trailing continuation bytes. A stray
            // continuation/invalid lead is taken as a lone byte; `decode_text`
            // then applies the stream's configured error handler.
            let extra = match b0 {
                0x00..=0x7F => 0,
                0xC0..=0xDF => 1,
                0xE0..=0xEF => 2,
                0xF0..=0xF7 => 3,
                _ => 0,
            };
            bytes.extend_from_slice(&lead);
            if extra > 0 {
                let cont = self.read_bytes(Some(extra))?;
                bytes.extend_from_slice(&cont);
            }
            chars += 1;
        }
        self.decode_text(bytes)
    }

    // -- Faithful incremental text-decode path (CPython `TextIOWrapper`) -----
    //
    // WeavePy's fast text read path one-shot-decodes the common stateless
    // codecs. CPython's `TextIOWrapper`, by contrast, *always* drives an
    // `IncrementalDecoder` and exposes opaque `tell()`/`seek()` cookies that
    // snapshot the decoder's state. The two behave identically for stateless
    // codecs (a cookie is just a byte offset), so the fast path stays. But a
    // custom incremental-only codec — one whose one-shot `decode` is `None`,
    // e.g. test_io's `test_decoder`/`StatefulIncrementalDecoder` — can only be
    // read through the incremental machinery. These methods port
    // `_pyio.TextIOWrapper`'s `_read_chunk`/`read`/`tell`/`seek` ADT, driving
    // the Python decoder object, and activate only when the gate below trips.

    /// `_CHUNK_SIZE` for the incremental reader — honours a user-set
    /// `f._CHUNK_SIZE` (test_io pokes it directly) and otherwise uses the
    /// default buffer size.
    fn text_chunk_size(&self) -> usize {
        for (k, v) in self.extra_attrs.borrow().iter() {
            if k == "_CHUNK_SIZE" {
                if let Object::Int(n) = v {
                    if *n > 0 {
                        return *n as usize;
                    }
                }
            }
        }
        TEXT_CHUNK_SIZE
    }

    /// Decide — once, lazily, and cached — whether this text stream must use
    /// the incremental decoder path. True iff the configured codec's one-shot
    /// `decode` is `None` (a custom incremental-only codec). For every normal
    /// codec this is `false` and the fast one-shot path is taken.
    pub fn text_incr_active_gate(&self) -> bool {
        if self.binary {
            return false;
        }
        if matches!(&*self.backend.borrow(), FileBackend::MemText { .. }) {
            // In-memory `StringIO` is already code-point addressed; the
            // incremental machinery is only for byte-backed text streams.
            return false;
        }
        if let Some(decided) = self.text_incr_gate.get() {
            return decided;
        }
        // The overwhelmingly common case — a stream opened without an explicit
        // `encoding=` (the UTF-8 default) — always has a one-shot decoder, so
        // skip the `codecs.lookup` probe entirely and pin the fast path.
        let decided = match &*self.encoding.borrow() {
            None => false,
            Some(enc) => {
                // Two reasons a byte-backed text stream must use the incremental
                // decoder: (1) a custom incremental-only codec whose one-shot
                // `decode` is `None`, and (2) a "newline-unsafe" codec
                // (UTF-16/32) where the encoded newline spans multiple bytes, so
                // line boundaries can only be found in *decoded* text — CPython's
                // `TextIOWrapper` always drives the incremental decoder for these.
                crate::stdlib::codecs_mod::codec_one_shot_decode_is_none(enc)
                    || crate::stdlib::codecs_mod::codec_is_newline_unsafe(enc)
            }
        };
        self.text_incr_gate.set(Some(decided));
        decided
    }

    /// Lazily build the (newline-wrapped) Python `IncrementalDecoder` and the
    /// [`TextIncr`] state. Mirrors `_pyio.TextIOWrapper._get_decoder`.
    fn ensure_text_decoder(&self) -> Result<(), RuntimeError> {
        if self.text_incr.borrow().is_some() {
            return Ok(());
        }
        let enc = self
            .encoding
            .borrow()
            .clone()
            .unwrap_or_else(|| "utf-8".to_owned());
        let errors = self.errors_name();
        let factory = pf_mod_call("codecs", "getincrementaldecoder", &[Object::from_str(&enc)])?;
        let raw = pf_call_value(&factory, &[Object::from_str(&errors)])?;
        // Universal-newline wrapping, exactly like `_get_decoder`:
        // `newline=None` → recognise + translate; `newline=''` → recognise
        // only; an explicit ending → no wrapping.
        let newline = self.newline.borrow().clone();
        let readuniversal = matches!(newline.as_deref(), None | Some(""));
        let translate = newline.is_none();
        let decoder = if readuniversal {
            pf_mod_call(
                "_io",
                "IncrementalNewlineDecoder",
                &[raw, Object::Bool(translate)],
            )?
        } else {
            raw
        };
        *self.text_incr.borrow_mut() = Some(TextIncr {
            decoder,
            decoded: Vec::new(),
            decoded_used: 0,
            snapshot: None,
            b2cratio: 0.0,
        });
        Ok(())
    }

    /// Clone the live decoder handle (cheap — it's an `Rc`-backed `Object`).
    fn text_decoder(&self) -> Result<Object, RuntimeError> {
        self.text_incr
            .borrow()
            .as_ref()
            .map(|t| t.decoder.clone())
            .ok_or_else(|| value_error("no decoder"))
    }

    /// `_get_decoded_chars(n)` — advance into the decoded-char buffer.
    fn text_get_decoded_chars(&self, n: Option<usize>) -> String {
        let mut guard = self.text_incr.borrow_mut();
        let Some(t) = guard.as_mut() else {
            return String::new();
        };
        let offset = t.decoded_used.min(t.decoded.len());
        let end = match n {
            None => t.decoded.len(),
            Some(n) => offset.saturating_add(n).min(t.decoded.len()),
        };
        let chars: String = t.decoded[offset..end].iter().collect();
        t.decoded_used = end;
        chars
    }

    /// `_rewind_decoded_chars(n)` — push `n` already-handed-out characters back
    /// into the decoded buffer (used by `readline` to un-consume the tail past
    /// the line ending). Saturates rather than panicking on an out-of-range `n`.
    fn text_rewind_decoded_chars(&self, n: usize) {
        if let Some(t) = self.text_incr.borrow_mut().as_mut() {
            t.decoded_used = t.decoded_used.saturating_sub(n);
        }
    }

    /// Whether the current decoded-char buffer is empty (mirrors CPython's
    /// `if self._decoded_chars:` truthiness test on the whole buffer).
    fn text_decoded_is_empty(&self) -> bool {
        self.text_incr
            .borrow()
            .as_ref()
            .map(|t| t.decoded.is_empty())
            .unwrap_or(true)
    }

    /// `_set_decoded_chars('')` + `_snapshot = None` — the EOF reset performed
    /// by `read`/`readline` when the stream is exhausted.
    fn text_set_decoded_empty(&self) {
        if let Some(t) = self.text_incr.borrow_mut().as_mut() {
            t.decoded.clear();
            t.decoded_used = 0;
            t.snapshot = None;
        }
    }

    /// `_read_chunk` — read and decode the next raw chunk, replacing the
    /// decoded-char buffer and (when telling) recording a snapshot point.
    /// Returns `false` at EOF.
    fn text_read_chunk(&self) -> Result<bool, RuntimeError> {
        let decoder = self.text_decoder()?;
        let telling = self.telling.get();

        // Snapshot prep: a point where the decoder's input buffer is empty.
        let (dec_buffer, dec_flags) = if telling {
            let st = pf_call_method(&decoder, "getstate", &[])?;
            let (b, f) = decoder_state_parts(&st)?;
            (b, f)
        } else {
            (Vec::new(), Object::None)
        };

        let chunk_size = self.text_chunk_size();
        let input_chunk = self.read_bytes(Some(chunk_size))?;
        let eof = input_chunk.is_empty();
        let decoded_obj = pf_call_method(
            &decoder,
            "decode",
            &[Object::new_bytes(input_chunk.clone()), Object::Bool(eof)],
        )?;
        let decoded: Vec<char> = decoded_obj.to_str().chars().collect();
        let b2cratio = if decoded.is_empty() {
            0.0
        } else {
            input_chunk.len() as f64 / decoded.len() as f64
        };

        let mut guard = self.text_incr.borrow_mut();
        let t = guard.as_mut().ok_or_else(|| value_error("no decoder"))?;
        t.decoded = decoded;
        t.decoded_used = 0;
        t.b2cratio = b2cratio;
        if telling {
            let mut next_input = dec_buffer;
            next_input.extend_from_slice(&input_chunk);
            t.snapshot = Some((dec_flags, next_input));
        }
        Ok(!eof)
    }

    /// `TextIOWrapper.read(size)` over the incremental decoder. `None` size
    /// reads to EOF.
    pub fn read_text_incr(&self, size: Option<usize>) -> Result<String, RuntimeError> {
        self.ensure_text_decoder()?;
        match size {
            None => {
                // Read everything: drain the buffer then decode the rest
                // with `final=True`.
                let decoder = self.text_decoder()?;
                let mut result = self.text_get_decoded_chars(None);
                let rest = self.read_bytes(None)?;
                let tail = pf_call_method(
                    &decoder,
                    "decode",
                    &[Object::new_bytes(rest), Object::Bool(true)],
                )?;
                result.push_str(&tail.to_str());
                let mut guard = self.text_incr.borrow_mut();
                if let Some(t) = guard.as_mut() {
                    if t.snapshot.is_some() {
                        t.decoded.clear();
                        t.decoded_used = 0;
                        t.snapshot = None;
                    }
                }
                Ok(result)
            }
            Some(size) => {
                let mut result = self.text_get_decoded_chars(Some(size));
                let mut eof = false;
                while result.chars().count() < size && !eof {
                    eof = !self.text_read_chunk()?;
                    let need = size - result.chars().count();
                    result.push_str(&self.text_get_decoded_chars(Some(need)));
                }
                Ok(result)
            }
        }
    }

    /// `TextIOWrapper.readline(size)` over the incremental decoder — a faithful
    /// port of `_pyio.TextIOWrapper.readline`. The crucial difference from the
    /// fast [`read_line_bytes`](Self::read_line_bytes) path is that the line
    /// boundary is located in the *decoded* character buffer, never in raw
    /// bytes, so it is correct for the newline-unsafe UTF-16/UTF-32 codecs
    /// whose encoded newline occupies several bytes (and where a `0x0A`/`0x0D`
    /// byte can appear inside an unrelated code unit). `size` is `None` for
    /// "no cap", `Some(n)` to stop after `n` characters.
    pub fn readline_text_incr(&self, size: Option<usize>) -> Result<String, RuntimeError> {
        self.ensure_text_decoder()?;
        // Newline policy, mirroring `_pyio`'s `_readtranslate`/`_readuniversal`/
        // `_readnl` derived from the `newline=` argument.
        let newline = self.newline.borrow().clone();
        let readtranslate = newline.is_none();
        let readuniversal = matches!(newline.as_deref(), None | Some(""));
        let readnl: Vec<char> = newline.as_deref().unwrap_or("").chars().collect();

        // Grab all currently-decoded text (any extra past the line end is
        // rewound below).
        let mut line: Vec<char> = self.text_get_decoded_chars(None).chars().collect();
        let mut start = 0usize;
        let endpos: usize;
        loop {
            let mut found: Option<usize> = None;
            if readtranslate {
                // Newlines already translated to `\n` by the newline decoder.
                if let Some(rel) = line[start..].iter().position(|&c| c == '\n') {
                    found = Some(start + rel + 1);
                } else {
                    start = line.len();
                }
            } else if readuniversal {
                // Search for any of `\r`, `\r\n`, `\n`; the newline decoder
                // guarantees a `\r\n` pair is never split across chunks.
                let nlpos = line[start..]
                    .iter()
                    .position(|&c| c == '\n')
                    .map(|p| start + p);
                let crpos = line[start..]
                    .iter()
                    .position(|&c| c == '\r')
                    .map(|p| start + p);
                match (crpos, nlpos) {
                    (None, None) => start = line.len(),
                    (None, Some(nl)) => found = Some(nl + 1),
                    (Some(cr), None) => found = Some(cr + 1),
                    (Some(cr), Some(nl)) if nl < cr => found = Some(nl + 1),
                    (Some(cr), Some(nl)) if nl == cr + 1 => found = Some(cr + 2),
                    (Some(cr), Some(_)) => found = Some(cr + 1),
                }
            } else if !readnl.is_empty() {
                // Non-universal: an exact line-terminator string.
                if let Some(pos) = line
                    .windows(readnl.len())
                    .position(|w| w == readnl.as_slice())
                {
                    found = Some(pos + readnl.len());
                }
            }
            if let Some(e) = found {
                endpos = e;
                break;
            }
            if let Some(sz) = size {
                if line.len() >= sz {
                    endpos = sz;
                    break;
                }
            }
            // No line ending seen yet — pull the next decoded chunk(s).
            let mut have = false;
            while self.text_read_chunk()? {
                if !self.text_decoded_is_empty() {
                    have = true;
                    break;
                }
            }
            if !have {
                // A final-flush chunk at EOF can still yield decoded chars.
                have = !self.text_decoded_is_empty();
            }
            if have {
                let more = self.text_get_decoded_chars(None);
                line.extend(more.chars());
            } else {
                // End of file.
                self.text_set_decoded_empty();
                return Ok(line.into_iter().collect());
            }
        }
        let mut endpos = endpos;
        if let Some(sz) = size {
            if endpos > sz {
                endpos = sz;
            }
        }
        // Rewind the decoded buffer to just past the line ending we returned.
        self.text_rewind_decoded_chars(line.len() - endpos);
        Ok(line[..endpos].iter().collect())
    }

    /// `TextIOWrapper.tell()` over the incremental decoder — packs the opaque
    /// cookie (a direct port of `_pyio.TextIOWrapper.tell`). The cookie's only
    /// contract is that `seek(tell())` round-trips, but we match CPython's bit
    /// layout exactly so it is indistinguishable from the reference.
    pub fn tell_text_incr(&self) -> Result<Object, RuntimeError> {
        self.flush()?;
        let mut position = self.tell()? as u64;

        // No snapshot yet → the decoder hasn't consumed anything; the cookie
        // is just the byte position.
        let (dec_flags, next_input, chars_to_skip) = {
            let guard = self.text_incr.borrow();
            match guard.as_ref().and_then(|t| {
                t.snapshot
                    .as_ref()
                    .map(|(f, n)| (f.clone(), n.clone(), t.decoded_used))
            }) {
                Some(v) => v,
                None => return Ok(Object::int_from_i128(i128::from(position))),
            }
        };
        let decoder = self.text_decoder()?;

        // Skip back to the snapshot point.
        position -= next_input.len() as u64;
        let dec_flags_bi = obj_to_bigint(&dec_flags);
        let mut chars_to_skip = chars_to_skip;
        if chars_to_skip == 0 {
            return Ok(pack_text_cookie(position, &dec_flags_bi, 0, false, 0));
        }

        // Walk the decoder forward from the snapshot to the current location,
        // tracking the nearest safe (empty-buffer) start point.
        let saved_state = pf_call_method(&decoder, "getstate", &[])?;
        let result = (|| -> Result<Object, RuntimeError> {
            let mut dec_flags_bi = dec_flags_bi.clone();
            // Fast search: seed `skip_bytes` from the running byte/char ratio.
            let b2cratio = self
                .text_incr
                .borrow()
                .as_ref()
                .map(|t| t.b2cratio)
                .unwrap_or(0.0);
            let mut skip_bytes = (b2cratio * chars_to_skip as f64) as i64;
            let mut skip_back = 1i64;
            if skip_bytes > next_input.len() as i64 {
                // Defensive clamp (CPython asserts this holds).
                skip_bytes = next_input.len() as i64;
            }
            let mut broke = false;
            while skip_bytes > 0 {
                pf_call_method(&decoder, "setstate", &[make_state_tuple(&dec_flags_bi)])?;
                let upto = &next_input[..skip_bytes as usize];
                let dec = pf_call_method(&decoder, "decode", &[Object::new_bytes(upto.to_vec())])?;
                let n = dec.to_str().chars().count();
                if n <= chars_to_skip {
                    let st = pf_call_method(&decoder, "getstate", &[])?;
                    let (b, d) = decoder_state_parts(&st)?;
                    if b.is_empty() {
                        dec_flags_bi = obj_to_bigint(&d);
                        chars_to_skip -= n;
                        broke = true;
                        break;
                    }
                    skip_bytes -= b.len() as i64;
                    skip_back = 1;
                } else {
                    skip_bytes -= skip_back;
                    skip_back *= 2;
                }
            }
            if !broke {
                skip_bytes = 0;
                pf_call_method(&decoder, "setstate", &[make_state_tuple(&dec_flags_bi)])?;
            }

            let mut start_pos = position + skip_bytes as u64;
            let mut start_flags = dec_flags_bi.clone();
            if chars_to_skip == 0 {
                return Ok(pack_text_cookie(start_pos, &start_flags, 0, false, 0));
            }

            // Feed one byte at a time, noting safe restart points.
            let mut bytes_fed = 0u64;
            let mut need_eof = false;
            let mut chars_decoded = 0usize;
            let mut reached = false;
            for i in (skip_bytes as usize)..next_input.len() {
                bytes_fed += 1;
                let dec = pf_call_method(
                    &decoder,
                    "decode",
                    &[Object::new_bytes(next_input[i..=i].to_vec())],
                )?;
                chars_decoded += dec.to_str().chars().count();
                let st = pf_call_method(&decoder, "getstate", &[])?;
                let (b, d) = decoder_state_parts(&st)?;
                if b.is_empty() && chars_decoded <= chars_to_skip {
                    start_pos += bytes_fed;
                    chars_to_skip -= chars_decoded;
                    start_flags = obj_to_bigint(&d);
                    bytes_fed = 0;
                    chars_decoded = 0;
                }
                if chars_decoded >= chars_to_skip {
                    reached = true;
                    break;
                }
            }
            if !reached {
                // Need EOF to surface the remaining characters.
                let dec = pf_call_method(
                    &decoder,
                    "decode",
                    &[Object::new_bytes(Vec::new()), Object::Bool(true)],
                )?;
                chars_decoded += dec.to_str().chars().count();
                need_eof = true;
                if chars_decoded < chars_to_skip {
                    return Err(os_error("can't reconstruct logical file position"));
                }
            }
            Ok(pack_text_cookie(
                start_pos,
                &start_flags,
                bytes_fed,
                need_eof,
                chars_to_skip as u64,
            ))
        })();
        // Always restore the decoder's live state.
        pf_call_method(&decoder, "setstate", &[saved_state])?;
        result
    }

    /// `TextIOWrapper.seek(cookie)` over the incremental decoder — unpacks the
    /// cookie and replays `read(chars_to_skip)` from the safe start point
    /// (a direct port of `_pyio.TextIOWrapper.seek`, absolute `whence=0`).
    pub fn seek_text_incr(&self, cookie: &Object) -> Result<Object, RuntimeError> {
        let cookie_bi = obj_to_bigint(cookie);
        if cookie_bi.is_negative() {
            return Err(value_error("negative seek position"));
        }
        self.flush()?;
        let (start_pos, dec_flags, bytes_to_feed, need_eof, chars_to_skip) =
            unpack_text_cookie(&cookie_bi);

        // Seek the underlying buffer to the safe start point and reset state.
        self.seek(start_pos as isize, 0)?;
        {
            let mut guard = self.text_incr.borrow_mut();
            if let Some(t) = guard.as_mut() {
                t.decoded.clear();
                t.decoded_used = 0;
                t.snapshot = None;
            }
        }

        let zero = num_bigint::BigInt::from(0u32);
        let has_incr = self.text_incr.borrow().is_some();
        if cookie_bi == zero {
            self.ensure_text_decoder()?;
            let decoder = self.text_decoder()?;
            pf_call_method(&decoder, "reset", &[])?;
        } else if has_incr || dec_flags != zero || chars_to_skip != 0 {
            self.ensure_text_decoder()?;
            let decoder = self.text_decoder()?;
            pf_call_method(&decoder, "setstate", &[make_state_tuple(&dec_flags)])?;
            if let Some(t) = self.text_incr.borrow_mut().as_mut() {
                t.snapshot = Some((Object::int_from_bigint(dec_flags.clone()), Vec::new()));
            }
        }

        if chars_to_skip != 0 {
            let decoder = self.text_decoder()?;
            let input_chunk = self.read_bytes(Some(bytes_to_feed as usize))?;
            let decoded_obj = pf_call_method(
                &decoder,
                "decode",
                &[
                    Object::new_bytes(input_chunk.clone()),
                    Object::Bool(need_eof),
                ],
            )?;
            let decoded: Vec<char> = decoded_obj.to_str().chars().collect();
            if decoded.len() < chars_to_skip as usize {
                return Err(os_error("can't restore logical file position"));
            }
            if let Some(t) = self.text_incr.borrow_mut().as_mut() {
                t.decoded = decoded;
                t.decoded_used = chars_to_skip as usize;
                t.snapshot = Some((Object::int_from_bigint(dec_flags.clone()), input_chunk));
            }
        }
        Ok(cookie.clone())
    }

    /// `TextIOWrapper.seek(cookie, whence)` over the incremental decoder,
    /// dispatching the three whence modes exactly like CPython: absolute
    /// (cookie replay), current (only `0` → re-sync to `tell()`), and end
    /// (only `0` → reset to EOF).
    pub fn seek_text(&self, cookie: &Object, whence: i32) -> Result<Object, RuntimeError> {
        match whence {
            0 => self.seek_text_incr(cookie),
            1 => {
                if !obj_to_bigint(cookie).is_zero() {
                    return Err(crate::stdlib::io::unsupported_op(
                        "can't do nonzero cur-relative seeks",
                    ));
                }
                let cur = self.tell_text_incr()?;
                self.seek_text_incr(&cur)
            }
            2 => {
                if !obj_to_bigint(cookie).is_zero() {
                    return Err(crate::stdlib::io::unsupported_op(
                        "can't do nonzero end-relative seeks",
                    ));
                }
                self.flush()?;
                let pos = self.seek(0, 2)?;
                {
                    let mut guard = self.text_incr.borrow_mut();
                    if let Some(t) = guard.as_mut() {
                        t.decoded.clear();
                        t.decoded_used = 0;
                        t.snapshot = None;
                    }
                }
                if self.text_incr.borrow().is_some() {
                    let decoder = self.text_decoder()?;
                    pf_call_method(&decoder, "reset", &[])?;
                }
                Ok(Object::int_from_i128(pos as i128))
            }
            _ => Err(value_error("invalid whence")),
        }
    }

    pub fn is_closed(&self) -> bool {
        *self.closed.borrow()
    }

    pub fn check_open(&self) -> Result<(), RuntimeError> {
        if self.is_closed() {
            Err(value_error("I/O operation on closed file."))
        } else {
            Ok(())
        }
    }

    pub fn close(&self) {
        let _ = self.close_report();
    }

    /// [`PyFile::close`] that reports the `close(2)` result instead of
    /// swallowing it. The stream always transitions to closed and the backend
    /// is always released; only the syscall's verdict is returned (a stale
    /// descriptor yields `EBADF`). Drop paths and internal callers ignore it;
    /// the Python-level `close()` raises it as `OSError`.
    pub fn close_report(&self) -> std::io::Result<()> {
        *self.closed.borrow_mut() = true;
        // CPython's `TextIOWrapper.close()` closes its underlying buffer
        // layer. The collapsed `PyFile` mints `.buffer` as a memoised
        // *sibling* stream over a dup-ed descriptor (see
        // [`PyFile::binary_buffer`]); without closing it in lock-step, the
        // sibling stays "open" after the text stream closes and its
        // finalizer later emits `ResourceWarning("unclosed file
        // <_io.BufferedRandom ...>")` — surfacing inside whatever
        // unrelated `check_warnings` block runs the next collection
        // (test_tempfile.test_warnings_on_cleanup). The sibling's close
        // verdict is secondary (the text layer's own close below is the
        // reported one), so errors are swallowed like other drop paths.
        let sibling = self.binary_buffer_cache.borrow().clone();
        if let Some(Object::File(buf)) = sibling {
            if !*buf.closed.borrow() {
                let _ = buf.flush_write_buf();
                let _ = buf.close_report();
            }
        }
        // Release OS-backed resources promptly. Dropping a real fd (a disk
        // file, or a subprocess pipe re-wrapped as a `Disk` backend) closes
        // the descriptor — and closing the write end of a child's `stdin`
        // pipe is exactly what signals EOF so the child can finish reading.
        // In-memory buffers are left intact so a post-close `getvalue()` still
        // works, matching our existing `BytesIO`/`StringIO` semantics.
        let mut backend = self.backend.borrow_mut();
        if matches!(&*backend, FileBackend::Disk(_)) {
            let old = std::mem::replace(
                &mut *backend,
                FileBackend::MemBytes {
                    data: Rc::new(RefCell::new(Vec::new())),
                    pos: 0,
                },
            );
            if let FileBackend::Disk(f) = old {
                #[cfg(unix)]
                {
                    // Always detach the fd from Rust's `File` (an `OwnedFd`)
                    // before closing. User code can legitimately close the
                    // descriptor out from under us — e.g.
                    // `os.close(f.fileno())` in CPython's
                    // `test_subprocess` — and letting `File`'s checked drop
                    // run `close(2)` on an already-closed fd aborts the whole
                    // process ("IO Safety violation: owned file descriptor
                    // already closed"). CPython models fds as plain ints, so a
                    // double close is merely `EBADF`; we mirror that by
                    // closing the raw fd ourselves and swallowing the error.
                    //
                    // `closefd=False` (`FileIO(fd, closefd=False)`): the caller
                    // keeps ownership, so we detach without closing.
                    use std::os::unix::io::IntoRawFd;
                    let fd = f.into_raw_fd();
                    if self.closefd.get() && unsafe { libc::close(fd) } != 0 {
                        return Err(std::io::Error::last_os_error());
                    }
                }
                #[cfg(windows)]
                {
                    // RFC 0063: mirror the Unix detach-then-close discipline
                    // in the CRT fd model. `close_disk_file` defuses the
                    // `File`'s checked drop (`into_raw_handle`) and releases
                    // through the adopted CRT fd when `fileno()` minted one
                    // (the fd owns the handle), else `CloseHandle` directly.
                    // A stale handle/fd reports like Unix's `EBADF` instead
                    // of double closing.
                    use std::os::windows::io::IntoRawHandle;
                    if self.closefd.get() {
                        crate::stdlib::nt_support::close_disk_file(f)?;
                    } else {
                        // `closefd=False`: the caller keeps ownership; detach
                        // without closing (the registry entry, if any, stays
                        // keyed to the still-live handle).
                        let _ = f.into_raw_handle();
                    }
                }
                #[cfg(not(any(unix, windows)))]
                {
                    // No portable raw-fd detach here; closing is unavoidable.
                    drop(f);
                }
            }
        }
        Ok(())
    }

    /// Re-initialise a `FileIO` in place over a new descriptor. CPython's
    /// `FileIO.__init__` may be called again on a live object to re-point it
    /// at another fd (`test_io.test_fileio_closefd`). We first release the
    /// current descriptor honouring the *current* `closefd` (so a
    /// `closefd=False` stream never closes a borrowed fd), then adopt
    /// `new_backend` under the supplied `closefd`. `mode`/`binary` are fixed
    /// at construction, so a re-init that changes the access mode keeps the
    /// original mode string (FileIO is always binary, so this only matters for
    /// the rare read↔write re-init, which CPython itself rejects mid-stream).
    pub fn reinit_fileio(&self, new_backend: FileBackend, closefd: bool) {
        self.close();
        *self.backend.borrow_mut() = new_backend;
        self.closefd.set(closefd);
        *self.closed.borrow_mut() = false;
        self.write_buf.borrow_mut().clear();
        self.text_start_of_stream.set(true);
        *self.binary_buffer_cache.borrow_mut() = None;
    }

    /// Read up to `n` bytes from the backend; `None` reads everything.
    /// Returns bytes regardless of mode — the caller decides whether
    /// to wrap them as `str` (text mode) or `bytes` (binary mode).
    /// Non-blocking-aware variant of [`PyFile::read_bytes`] for the file
    /// `read()` method: a would-block on a non-blocking descriptor returns
    /// `Ok(None)` (so `BufferedReader.read()` yields `None` instead of raising
    /// `OSError(EAGAIN)`), while blocking descriptors and in-memory streams
    /// keep the exact `read_bytes` behaviour. Only descriptor-backed streams in
    /// `O_NONBLOCK` mode take the special path.
    pub fn read_bytes_opt(&self, n: Option<usize>) -> Result<Option<Vec<u8>>, RuntimeError> {
        #[cfg(unix)]
        {
            use std::os::unix::io::AsRawFd;
            self.check_open()?;
            self.flush_write_buf()?;
            if let Some(parked) = self.take_pushback(n) {
                return Ok(Some(parked));
            }
            let raw_fd = match &*self.backend.borrow() {
                FileBackend::Disk(f) => Some(f.as_raw_fd()),
                _ => None,
            };
            if let Some(fd) = raw_fd {
                if fd_is_nonblocking(fd) {
                    return read_fd_nonblock(fd, n, &self.fd_syscall_lock);
                }
            }
        }
        self.read_bytes(n).map(Some)
    }

    /// Serve read-ahead bytes parked by [`PyFile::read_line_bytes`]'s
    /// non-seekable `\r`-lookahead. `Some(bytes)` is a complete short read
    /// (never mixed with a backend read — a pipe read returning fewer bytes
    /// than asked is always legal); `None` means nothing is parked. A `None`
    /// size request drains the whole pushback, then the caller's read-to-EOF
    /// logic would miss it, so that case appends the backend's remainder here.
    fn take_pushback(&self, n: Option<usize>) -> Option<Vec<u8>> {
        let mut pb = self.read_pushback.borrow_mut();
        if pb.is_empty() {
            return None;
        }
        match n {
            Some(k) => {
                let take = k.min(pb.len());
                Some(pb.drain(..take).collect())
            }
            None => Some(std::mem::take(&mut *pb)),
        }
    }

    pub fn read_bytes(&self, n: Option<usize>) -> Result<Vec<u8>, RuntimeError> {
        self.check_open()?;
        // Any staged writes must reach the descriptor before a read observes
        // the stream position (defensive; a pure `BufferedWriter` is not
        // readable, but keeps read-after-write coherent).
        self.flush_write_buf()?;
        if let Some(mut parked) = self.take_pushback(n) {
            // A read-to-EOF must not stop at the parked byte.
            if n.is_none() {
                parked.extend(self.read_bytes(None)?);
            }
            return Ok(parked);
        }
        // Unix disk/pipe descriptors go through the PEP 475-aware raw read:
        // snapshot the fd under a short borrow, then read with the backend
        // released so a signal handler can run (and even touch this stream)
        // mid-call.
        #[cfg(unix)]
        {
            use std::os::unix::io::AsRawFd;
            let raw_fd = match &*self.backend.borrow() {
                FileBackend::Disk(f) => Some(f.as_raw_fd()),
                _ => None,
            };
            if let Some(fd) = raw_fd {
                return read_fd_intr(fd, n, &self.fd_syscall_lock);
            }
        }
        let mut backend = self.backend.borrow_mut();
        let mut buf = Vec::new();
        match (&mut *backend, n) {
            (FileBackend::Disk(f), Some(n)) => {
                buf.resize(n, 0);
                let read = f
                    .read(&mut buf)
                    .map_err(|e| crate::error::io_error_to_py(&e))?;
                buf.truncate(read);
            }
            (FileBackend::Disk(f), None) => {
                f.read_to_end(&mut buf)
                    .map_err(|e| crate::error::io_error_to_py(&e))?;
            }
            (FileBackend::MemBytes { data, pos }, None) => {
                let d = data.borrow();
                // The position can sit *past* the end after a seek beyond
                // EOF (legal for BytesIO); reading there yields b'' and
                // leaves the position untouched — never slice out of range.
                if *pos < d.len() {
                    buf.extend_from_slice(&d[*pos..]);
                    *pos = d.len();
                }
            }
            (FileBackend::MemBytes { data, pos }, Some(n)) => {
                let d = data.borrow();
                if *pos < d.len() {
                    let end = (*pos + n).min(d.len());
                    buf.extend_from_slice(&d[*pos..end]);
                    *pos = end;
                }
            }
            (FileBackend::MemText { data, pos }, None) => {
                let bytes = data.as_bytes();
                if *pos < bytes.len() {
                    buf.extend_from_slice(&bytes[*pos..]);
                    *pos = bytes.len();
                }
            }
            (FileBackend::MemText { data, pos }, Some(n)) => {
                // Raw *byte* semantics — callers that need character counts
                // (`read_text_n`) handle MemText themselves. Line iteration
                // (`read_line_bytes`) probes one byte at a time and would
                // drop trailing bytes of a multibyte char if this grouped by
                // character.
                let bytes = data.as_bytes();
                if *pos < bytes.len() {
                    let end = (*pos + n).min(bytes.len());
                    buf.extend_from_slice(&bytes[*pos..end]);
                    *pos = end;
                }
            }
            (FileBackend::Stdout(_) | FileBackend::Stderr(_), _) => {
                return Err(os_error("not readable"));
            }
            (FileBackend::Stdin, None) => {
                // RFC 0064 WS4 — a real console reads through the
                // UTF-16 bridge (`ReadConsoleW` + Ctrl-Z EOF), so
                // interactive input carries the full Unicode range
                // regardless of the console codepage.
                #[cfg(windows)]
                if let Some(result) = crate::stdlib::win_console::stdin_console_read(None) {
                    return result;
                }
                // Raw bytes (not `read_to_string`, which would reject non-UTF-8
                // binary data piped to `sys.stdin.buffer`). Text-mode callers
                // decode the result via `decode_text`.
                std::io::stdin()
                    .read_to_end(&mut buf)
                    .map_err(|e| os_error(format!("read: {e}")))?;
            }
            (FileBackend::Stdin, Some(n)) => {
                #[cfg(windows)]
                if let Some(result) = crate::stdlib::win_console::stdin_console_read(Some(n)) {
                    return result;
                }
                // Read up to `n` bytes, looping past short reads (pipes deliver
                // data in fragments) until we have `n` or hit EOF — matching
                // `BufferedReader.read(n)`. Honouring `n` (instead of draining
                // all of stdin) is what makes `sys.stdin.buffer.read(size)`
                // usable, e.g. `python -m gzip -d` over a pipe.
                let stdin = std::io::stdin();
                let mut handle = stdin.lock();
                buf.resize(n, 0);
                let mut filled = 0;
                while filled < n {
                    let got = handle
                        .read(&mut buf[filled..])
                        .map_err(|e| os_error(format!("read: {e}")))?;
                    if got == 0 {
                        break;
                    }
                    filled += got;
                }
                buf.truncate(filled);
            }
        }
        Ok(buf)
    }

    /// Read until the next ``\n`` (inclusive) or EOF and return the
    /// resulting string. Used by iteration over text-mode files and
    /// ``StringIO`` instances; binary-mode files refuse the call to
    /// avoid silently decoding non-UTF-8 bytes.
    pub fn readline_unbounded(&self) -> Result<String, RuntimeError> {
        let mut out: Vec<u8> = Vec::new();
        loop {
            let b = self.read_bytes(Some(1))?;
            if b.is_empty() {
                break;
            }
            out.extend_from_slice(&b);
            if b[0] == b'\n' {
                break;
            }
        }
        if self.binary {
            // Binary mode: caller should iterate by ``readline``
            // explicitly; the iterator protocol implicitly decodes
            // to str, which would be wrong for bytes.
            let _ = out;
            return Err(type_error(
                "binary mode files are not iterable in text mode".to_owned(),
            ));
        }
        self.decode_text(out)
    }

    /// Read one line and return it as a `bytes` object (binary mode) or a
    /// `str` (text mode), or `None` at EOF. Backs lazy file iteration
    /// (`for line in f`) for *both* modes — CPython's file object is its
    /// own iterator and a binary file yields `bytes` lines.
    /// Read one raw, *untranslated* line's bytes, honoring the stream's
    /// `newline` policy for where a line ends — newline *translation* is
    /// applied later by [`decode_text`](Self::decode_text). An optional
    /// `limit` caps the bytes read (CPython `readline(size)`); a returned
    /// empty `Vec` means end-of-stream.
    ///
    /// Binary streams (and text pinned to `\n`) split on `\n` only; an
    /// explicit `\r`/`\r\n` newline pins that terminator; universal mode
    /// (`newline=None`) and the no-translation mode (`newline=""`) both split
    /// on `\r`, `\n`, *and* `\r\n` (CPython's `IncrementalNewlineDecoder`).
    /// `\r`/`\n` are ASCII and never occur as UTF-8 continuation bytes, so
    /// byte-level scanning never splits mid-character.
    pub fn read_line_bytes(&self, limit: Option<usize>) -> Result<Vec<u8>, RuntimeError> {
        enum Nl {
            Lf,
            Cr,
            CrLf,
            Universal,
        }
        let nl = if self.binary {
            Nl::Lf
        } else {
            match self.newline.borrow().as_deref() {
                Some("\n") => Nl::Lf,
                Some("\r") => Nl::Cr,
                Some("\r\n") => Nl::CrLf,
                _ => Nl::Universal,
            }
        };
        let mut out: Vec<u8> = Vec::new();
        loop {
            if let Some(lim) = limit {
                if out.len() >= lim {
                    break;
                }
            }
            let b = self.read_bytes(Some(1))?;
            if b.is_empty() {
                break;
            }
            let ch = b[0];
            out.push(ch);
            match nl {
                Nl::Lf => {
                    if ch == b'\n' {
                        break;
                    }
                }
                Nl::Cr => {
                    if ch == b'\r' {
                        break;
                    }
                }
                Nl::CrLf => {
                    if ch == b'\n' && out.len() >= 2 && out[out.len() - 2] == b'\r' {
                        break;
                    }
                }
                Nl::Universal => {
                    if ch == b'\n' {
                        break;
                    }
                    if ch == b'\r' {
                        // A lone `\r` ends the line, but `\r\n` is a single
                        // terminator — read one byte to tell them apart
                        // (CPython's incremental newline decoder holds the
                        // `\r` back until the next byte settles it, even
                        // across an EINTR-split pipe read —
                        // test_file_eintr.test_readlines). When the byte
                        // belongs to the next line, un-read it: seek back on
                        // a seekable stream, park it in `read_pushback`
                        // otherwise.
                        let nb = self.read_bytes(Some(1))?;
                        if nb.is_empty() {
                            break;
                        }
                        if nb[0] == b'\n' {
                            out.push(b'\n');
                        } else if self.seekable() {
                            self.seek(-1, 1)?;
                        } else {
                            self.read_pushback.borrow_mut().insert(0, nb[0]);
                        }
                        break;
                    }
                }
            }
        }
        Ok(out)
    }

    pub fn readline_obj(&self) -> Result<Option<Object>, RuntimeError> {
        // Native file iteration (`for line in f`) must honour the same
        // incremental-decoder gate as explicit `readline()`, or a UTF-16/32
        // stream would be byte-scanned for newlines and mis-decoded (this is
        // the path the CSV parser and `readlines()` iterate through).
        if !self.binary && self.text_incr_active_gate() {
            let line = self.readline_text_incr(None)?;
            return Ok(if line.is_empty() {
                None
            } else {
                Some(Object::from_str(line))
            });
        }
        let out = self.read_line_bytes(None)?;
        if out.is_empty() {
            return Ok(None);
        }
        if self.binary {
            Ok(Some(Object::new_bytes(out)))
        } else {
            // Un-bridge PUA-window code points back to lone surrogates
            // (StringIO buffers that received surrogates, and
            // surrogate-producing error handlers). Gated so a genuine
            // plane-16 PUA character in a surrogate-free stream is not
            // misread as a bridged surrogate.
            let text = self.decode_text(out)?;
            if self.unbridge_on_read() {
                Ok(Some(crate::builtins::bridge_to_object(&text)))
            } else {
                Ok(Some(Object::from_str(text)))
            }
        }
    }

    /// Whether read paths must un-bridge PUA-window code points back to
    /// lone surrogates: an in-memory buffer that actually *received*
    /// bridged surrogates, or a decode error handler that can produce
    /// them. See [`Self::mem_bridged`].
    pub fn unbridge_on_read(&self) -> bool {
        if matches!(&*self.backend.borrow(), FileBackend::MemText { .. }) {
            return self.mem_bridged.get();
        }
        matches!(
            self.errors_name().as_str(),
            "surrogateescape" | "surrogatepass"
        )
    }

    /// Write **all** of `data`, blocking as needed — the text-layer commit
    /// path. CPython's `TextIOWrapper.write` reports the full character count
    /// and pushes every encoded byte through the buffered layer, retrying
    /// partial writes and `EINTR` (running tripped signal handlers between
    /// attempts — test_io `check_interrupted_write_retry`). A raw single
    /// `write(2)` that a signal cuts short must therefore be resumed here,
    /// not surfaced as a short write.
    pub fn write_text_all(&self, data: &[u8]) -> Result<(), RuntimeError> {
        if self.is_write_buffered() {
            self.write_bytes(data)?;
            return Ok(());
        }
        #[cfg(unix)]
        {
            use std::os::unix::io::AsRawFd;
            self.check_open()?;
            let raw_fd = match &*self.backend.borrow() {
                FileBackend::Disk(f) => Some(f.as_raw_fd()),
                _ => None,
            };
            if let Some(fd) = raw_fd {
                let mut pending = data.to_vec();
                return write_drain_fd_intr(fd, &mut pending, &self.fd_syscall_lock);
            }
        }
        let mut off = 0;
        while off < data.len() {
            let k = self.write_bytes(&data[off..])?;
            if k == 0 {
                break;
            }
            off += k;
        }
        Ok(())
    }

    pub fn write_bytes(&self, data: &[u8]) -> Result<usize, RuntimeError> {
        self.check_open()?;
        // Binary `BufferedWriter`: stage the write in the Python-level buffer
        // and only push to the descriptor once it fills (CPython
        // `BufferedWriter.write`). The bytes are *not* on the fd yet, so
        // `os.close(fileno())` discards them and a flush to a broken pipe
        // raises only here / at close.
        if self.is_write_buffered() {
            let bufsize = self.buf_size.get();
            // Pre-flush if the buffer is already over size (a prior partial
            // non-blocking flush left it full). A `BlockingIOError` here means
            // none of `data` has been accepted yet, so it re-raises with
            // `characters_written == 0` (`_pyio.BufferedWriter.write`).
            if self.write_buf.borrow().len() > bufsize {
                if let Err(e) = self.flush_write_buf() {
                    if runtime_err_is_blocking(&e) {
                        let (errno, strerror) = runtime_err_eagain_info(&e);
                        return Err(crate::error::blocking_io_error_written(errno, &strerror, 0));
                    }
                    return Err(e);
                }
            }
            let before = self.write_buf.borrow().len();
            {
                let mut wb = self.write_buf.borrow_mut();
                wb.extend_from_slice(data);
            }
            let mut written = (self.write_buf.borrow().len() - before) as i64;
            if self.write_buf.borrow().len() >= bufsize {
                if let Err(e) = self.flush_write_buf() {
                    if runtime_err_is_blocking(&e) {
                        // Partial non-blocking write. If the (partially drained)
                        // buffer still exceeds the buffer size, accept what fits,
                        // discard the overage, and report `characters_written`;
                        // otherwise everything in `data` is committed and will be
                        // flushed later, so swallow the error and report the full
                        // write (`_pyio.BufferedWriter.write`,
                        // `test_io.test_nonblock_pipe_write_*`).
                        let cur = self.write_buf.borrow().len();
                        if cur > bufsize {
                            let overage = (cur - bufsize) as i64;
                            written -= overage;
                            self.write_buf.borrow_mut().truncate(bufsize);
                            let (errno, strerror) = runtime_err_eagain_info(&e);
                            return Err(crate::error::blocking_io_error_written(
                                errno, &strerror, written,
                            ));
                        }
                    } else {
                        return Err(e);
                    }
                }
            }
            return Ok(written.max(0) as usize);
        }
        let mut backend = self.backend.borrow_mut();
        let n = match &mut *backend {
            FileBackend::Disk(f) => f
                .write(data)
                .map_err(|e| crate::error::io_error_to_py(&e))?,
            FileBackend::MemBytes { data: buf, pos } => {
                // CPython's `bytesio.c` `write` runs `check_exports` first: a
                // `BytesIO` with a live `getbuffer()` export refuses *any*
                // write (it might re-size the shared buffer).
                bytearray_check_resizable(buf)?;
                // Writing nothing is a no-op — in particular it must not
                // zero-fill an overseek gap (test_memoryio.test_overseek:
                // `write(b'')` past EOF leaves getvalue() unchanged).
                if data.is_empty() {
                    return Ok(0);
                }
                let mut b = buf.borrow_mut();
                if *pos > b.len() {
                    // Seeked past EOF: writing zero-fills the gap (CPython
                    // `BytesIO`/`FileIO` sparse-write semantics).
                    b.resize(*pos, 0);
                }
                if *pos == b.len() {
                    b.extend_from_slice(data);
                } else {
                    let end = (*pos + data.len()).min(b.len());
                    b[*pos..end].copy_from_slice(&data[..end - *pos]);
                    if data.len() > end - *pos {
                        b.extend_from_slice(&data[end - *pos..]);
                    }
                }
                *pos += data.len();
                data.len()
            }
            FileBackend::MemText { data: buf, pos } => {
                let s = std::str::from_utf8(data)
                    .map_err(|_| value_error("StringIO requires utf-8 bytes"))?;
                // CPython `StringIO.write` overwrites *in place*, keeping any
                // tail beyond the written region ('h' over "Hello world"
                // yields "hello world", test_memoryio.write_ops), and pads a
                // past-the-end position with '\0' (test_overseek). Writing
                // nothing must not pad. The return value counts *bytes*
                // consumed — `write_text_all` loops on it; the char count
                // CPython reports is computed by the `file_write` surface.
                if s.is_empty() {
                    return Ok(0);
                }
                let n_chars = s.chars().count();
                if *pos > buf.len() {
                    let gap = *pos - buf.len();
                    buf.extend(std::iter::repeat_n('\0', gap));
                }
                let start = *pos;
                let tail = &buf[start..];
                let end_rel = tail
                    .char_indices()
                    .nth(n_chars)
                    .map(|(i, _)| i)
                    .unwrap_or(tail.len());
                buf.replace_range(start..start + end_rel, s);
                *pos = start + s.len();
                s.len()
            }
            FileBackend::Stdout(sink) => {
                // RFC 0064 WS4 — a real console gets the UTF-16 bridge
                // (`WriteConsoleW`), so the full Unicode range renders
                // regardless of the console codepage; redirected fds
                // keep the byte sink below.
                #[cfg(windows)]
                if let Some(result) = crate::stdlib::win_console::console_write(1, data) {
                    return result;
                }
                let mut s = sink.borrow_mut();
                let n = s
                    .write(data)
                    .map_err(|e| crate::error::io_error_to_py(&e))?;
                // `-u` / `PYTHONUNBUFFERED`: every write reaches the fd
                // immediately (Rust's stdout is otherwise line-buffered,
                // which would lose bytes on `os._exit`).
                if crate::vm_singletons::stdio_unbuffered() {
                    s.flush().map_err(|e| crate::error::io_error_to_py(&e))?;
                } else {
                    crate::vm_singletons::note_stdout_write(&data[..n]);
                }
                n
            }
            FileBackend::Stderr(sink) => {
                #[cfg(windows)]
                if let Some(result) = crate::stdlib::win_console::console_write(2, data) {
                    return result;
                }
                let mut s = sink.borrow_mut();
                let n = s
                    .write(data)
                    .map_err(|e| crate::error::io_error_to_py(&e))?;
                if crate::vm_singletons::stdio_unbuffered() {
                    s.flush().map_err(|e| crate::error::io_error_to_py(&e))?;
                }
                n
            }
            FileBackend::Stdin => return Err(os_error("not writable")),
        };
        Ok(n)
    }

    pub fn flush(&self) -> Result<(), RuntimeError> {
        self.check_open()?;
        // Drain the staged `BufferedWriter` bytes to the descriptor first.
        self.flush_write_buf()?;
        let mut backend = self.backend.borrow_mut();
        match &mut *backend {
            FileBackend::Disk(f) => f.flush().map_err(|e| crate::error::io_error_to_py(&e))?,
            FileBackend::Stdout(sink) => {
                sink.borrow_mut()
                    .flush()
                    .map_err(|e| crate::error::io_error_to_py(&e))?;
                // Rust's stdout swallows `EBADF` (std's `handle_ebadf`), so
                // a "successful" flush to a closed fd 1 silently dropped
                // any buffered tail. Surface it as the `OSError` CPython
                // raises (shutdown then reports "Exception ignored on
                // flushing sys.stdout" and exits 120).
                #[cfg(unix)]
                if crate::vm_singletons::take_stdout_pending()
                    && unsafe { libc::fcntl(1, libc::F_GETFD) } == -1
                {
                    let e = std::io::Error::from_raw_os_error(libc::EBADF);
                    return Err(crate::error::io_error_to_py(&e));
                }
            }
            FileBackend::Stderr(sink) => sink
                .borrow_mut()
                .flush()
                .map_err(|e| crate::error::io_error_to_py(&e))?,
            _ => {}
        }
        Ok(())
    }

    /// Read every byte remaining and decode as UTF-8. Convenience for
    /// stdlib helpers (e.g. `json.load`) that want text regardless of
    /// the file's nominal mode.
    pub fn read_text_all(&self) -> Result<String, RuntimeError> {
        let bytes = self.read_bytes(None)?;
        String::from_utf8(bytes).map_err(|_| value_error("invalid UTF-8 in input"))
    }

    /// Write a UTF-8 string as bytes. Mirrors `read_text_all` and is
    /// safe to call on any mode supporting writes.
    pub fn write_text(&self, s: &str) -> Result<usize, RuntimeError> {
        self.write_bytes(s.as_bytes())
    }

    /// Current position. Works for both in-memory buffers and disk files.
    ///
    /// `StringIO` positions are *character* counts at the Python surface
    /// (CPython addresses the UCS payload directly); the `MemText` backend
    /// stores a byte offset into its UTF-8 buffer, translated at this
    /// boundary by [`memtext_char_of_byte`]/[`memtext_byte_of_char`].
    pub fn position(&self) -> usize {
        // Staged `BufferedWriter` bytes sit logically after the descriptor
        // offset, so `tell()` counts them (CPython's `BufferedWriter.tell`
        // returns `raw.tell() + len(buffer)`).
        let pending = self.write_buf.borrow().len();
        match &mut *self.backend.borrow_mut() {
            FileBackend::MemBytes { pos, .. } => *pos,
            // Public StringIO positions count characters, not bytes.
            FileBackend::MemText { data, pos } => memtext_char_of_byte(data, *pos),
            FileBackend::Disk(f) => {
                use std::io::Seek;
                f.stream_position().map(|n| n as usize).unwrap_or(0) + pending
            }
            _ => 0,
        }
    }

    /// `f.tell()` — like [`position`](Self::position) but surfaces the OS error
    /// instead of swallowing it. CPython's `FileIO.tell` does an `lseek` and a
    /// pipe/FIFO descriptor raises `OSError(ESPIPE)`, which
    /// `test_io.test_optional_abilities` asserts for a non-seekable stream.
    pub fn tell(&self) -> Result<usize, RuntimeError> {
        let pending = self.write_buf.borrow().len();
        match &mut *self.backend.borrow_mut() {
            FileBackend::MemBytes { pos, .. } => Ok(*pos),
            FileBackend::MemText { data, pos } => Ok(memtext_char_of_byte(data, *pos)),
            FileBackend::Disk(f) => {
                use std::io::Seek;
                let p = f
                    .stream_position()
                    .map_err(|e| crate::error::io_error_to_py(&e))?;
                Ok(p as usize + pending)
            }
            _ => Ok(0),
        }
    }

    /// Seek to absolute position. Returns the new position.
    pub fn seek(&self, offset: isize, whence: i32) -> Result<usize, RuntimeError> {
        self.check_open()?;
        // CPython's `BufferedWriter.seek` flushes the write buffer first so the
        // descriptor offset the seek is relative to is current.
        self.flush_write_buf()?;
        // Unix disk descriptors: serialize the offset move against this
        // file's in-flight GIL-released raw reads/writes (see
        // `fd_syscall_lock`) — an `lseek` interleaving with a concurrent
        // `write(2)`'s deposit/offset-advance window would desync the offset
        // from EOF just like the read/write race. The fd is snapshotted
        // under a short borrow (dropped before the GIL release, so a thread
        // we yield to can touch this stream without tripping the `RefCell`),
        // and the lock is only taken with the GIL released — its holder may
        // be blocked in a syscall indefinitely.
        #[cfg(unix)]
        let disk_fd = {
            use std::os::unix::io::AsRawFd;
            match &*self.backend.borrow() {
                FileBackend::Disk(f) => Some(f.as_raw_fd()),
                _ => None,
            }
        };
        #[cfg(unix)]
        if let Some(fd) = disk_fd {
            let lseek_whence = match whence {
                0 => libc::SEEK_SET,
                1 => libc::SEEK_CUR,
                2 => libc::SEEK_END,
                _ => return Err(value_error("invalid whence")),
            };
            let target = if whence == 0 {
                offset.max(0) as libc::off_t
            } else {
                offset as libc::off_t
            };
            let lock = &self.fd_syscall_lock;
            let r = crate::gil::allow_threads_then(|| {
                let _serialized = fd_lock(lock);
                unsafe { libc::lseek(fd, target, lseek_whence) }
            });
            if r < 0 {
                return Err(crate::error::io_error_to_py(
                    &std::io::Error::last_os_error(),
                ));
            }
            let result = r as usize;
            if !self.binary {
                self.text_start_of_stream.set(result == 0);
            }
            return Ok(result);
        }
        let result = {
            let mut backend = self.backend.borrow_mut();
            match &mut *backend {
                FileBackend::MemBytes { data, pos } => {
                    let dlen = data.borrow().len();
                    let new_pos = match whence {
                        // An absolute negative position is an error
                        // (`bytesio.c`); relative seeks clamp to 0 instead
                        // (test_memoryio.test_seek).
                        0 if offset < 0 => {
                            return Err(value_error(format!("negative seek value {offset}")))
                        }
                        0 => offset as usize,
                        1 => (*pos as isize + offset).max(0) as usize,
                        2 => (dlen as isize + offset).max(0) as usize,
                        _ => {
                            return Err(value_error(format!(
                                "invalid whence ({whence}, should be 0, 1 or 2)"
                            )))
                        }
                    };
                    // CPython's in-memory streams allow seeking *past* the end
                    // (the next write zero-fills the gap); don't clamp to `dlen`.
                    *pos = new_pos;
                    *pos
                }
                FileBackend::MemText { data, pos } => {
                    // Public positions are in *characters* (CPython
                    // `StringIO`); the stored `pos` stays a byte offset —
                    // see `memtext_byte_of_char`. Seeking past the end is
                    // legal (the next write pads with '\0', one byte per
                    // padded char, so the mapping stays consistent).
                    let clen = data.chars().count();
                    let new_char = match whence {
                        0 if offset < 0 => {
                            return Err(value_error(format!("Negative seek position {offset}")))
                        }
                        0 => offset as usize,
                        1 => (memtext_char_of_byte(data, *pos) as isize + offset).max(0) as usize,
                        2 => (clen as isize + offset).max(0) as usize,
                        _ => {
                            return Err(value_error(format!(
                                "Invalid whence ({whence}, should be 0, 1 or 2)"
                            )))
                        }
                    };
                    *pos = memtext_byte_of_char(data, new_char);
                    new_char
                }
                // Unix disk descriptors take the lock-serialized `lseek`
                // early-exit above; this arm serves the other platforms.
                FileBackend::Disk(f) => {
                    use std::io::Seek;
                    let whence_pos = match whence {
                        0 => std::io::SeekFrom::Start(offset.max(0) as u64),
                        1 => std::io::SeekFrom::Current(offset as i64),
                        2 => std::io::SeekFrom::End(offset as i64),
                        _ => return Err(value_error("invalid whence")),
                    };
                    f.seek(whence_pos)
                        .map_err(|e| crate::error::io_error_to_py(&e))? as usize
                }
                _ => return Err(os_error("stream is not seekable")),
            }
        };
        // BOM-once: seeking back to byte 0 returns a BOM-prefixing text encoder
        // to the start of the stream (so the next write re-emits the BOM); any
        // other position suppresses it (CPython's seek `encoding_start_of_stream`).
        if !self.binary {
            self.text_start_of_stream.set(result == 0);
        }
        Ok(result)
    }

    /// `truncate(size=None)` — resize the stream to `size` bytes (or the
    /// current position when `None`), returning the new size. The stream
    /// position is left unchanged, matching CPython's `IOBase.truncate`.
    /// Growing only extends an in-memory buffer; on disk it delegates to
    /// `ftruncate(2)` via `File::set_len`.
    pub fn truncate(&self, size: Option<u64>) -> Result<u64, RuntimeError> {
        self.check_open()?;
        self.flush()?;
        let mut backend = self.backend.borrow_mut();
        match &mut *backend {
            FileBackend::MemBytes { data, pos } => {
                // `truncate` re-sizes; refused while a `getbuffer()` view is
                // live (CPython `bytesio.c` `check_exports`).
                bytearray_check_resizable(data)?;
                let n = size.unwrap_or(*pos as u64) as usize;
                let mut d = data.borrow_mut();
                // `bytesio.c` only ever *shrinks*: a size beyond the end
                // leaves the buffer untouched, and the requested size is
                // returned either way (test_memoryio.test_truncate).
                if n < d.len() {
                    d.truncate(n);
                }
                Ok(n as u64)
            }
            FileBackend::MemText { data, pos } => {
                // `size` counts characters (StringIO); shrink-only and
                // return the requested size, like the bytes form.
                let n = size.unwrap_or_else(|| memtext_char_of_byte(data, *pos) as u64) as usize;
                let cut = memtext_byte_of_char(data, n);
                if cut < data.len() {
                    data.truncate(cut);
                }
                Ok(n as u64)
            }
            FileBackend::Disk(f) => {
                use std::io::Seek;
                let n = match size {
                    Some(s) => s,
                    None => f
                        .stream_position()
                        .map_err(|e| crate::error::io_error_to_py(&e))?,
                };
                f.set_len(n).map_err(|e| crate::error::io_error_to_py(&e))?;
                Ok(n)
            }
            _ => Err(os_error("File or stream is not seekable")),
        }
    }

    /// Extract the entire buffer of an in-memory StringIO/BytesIO.
    /// Used by `StringIO.getvalue()` / `BytesIO.getvalue()`.
    pub fn getvalue(&self) -> Option<Object> {
        match &*self.backend.borrow() {
            FileBackend::MemBytes { data, .. } => {
                Some(Object::Bytes(SharedSlice::from(data.borrow().as_slice())))
            }
            // The buffer stores lone surrogates as bridged PUA code points
            // (so a Rust `String` can hold them); map them back to a `str`/
            // `WStr` here — but only when surrogates were actually written
            // (`mem_bridged`), so a genuine plane-16 PUA character
            // round-trips verbatim.
            FileBackend::MemText { data, .. } => Some(if self.mem_bridged.get() {
                crate::builtins::bridge_to_object(data)
            } else {
                Object::from_str(data.as_str())
            }),
            _ => None,
        }
    }

    /// `BytesIO.getbuffer()` — a *writable* `memoryview` aliasing the
    /// in-memory buffer (CPython's `bytesio_getbuffer`). Sharing the
    /// `Rc<RefCell<Vec<u8>>>` means writes through the view land in the
    /// stream, and the export keeps the buffer pinned (a subsequent
    /// `write`/`truncate` raises `BufferError`) until the view is released.
    pub fn getbuffer(&self) -> Result<Object, RuntimeError> {
        match &*self.backend.borrow() {
            FileBackend::MemBytes { data, .. } => Ok(Object::MemoryView(Rc::new(
                PyMemoryView::from_bytearray(data.clone()),
            ))),
            _ => Err(type_error("getbuffer() requires a BytesIO")),
        }
    }
}

impl fmt::Debug for PyFile {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "<file {:?} mode={:?}>", self.name, self.mode)
    }
}

impl Drop for PyFile {
    fn drop(&mut self) {
        // CPython's fileio/buffered/textio deallocators emit a
        // `ResourceWarning("unclosed file %R")` when an *open*, fd-backed
        // stream is reclaimed without an explicit `close()`/`with`
        // (`test_io.test_warn_on_dealloc{,_fd}`). Mirror it here, since a
        // leaked `PyFile`'s last `Rc` drop *is* its deallocation. Gates:
        //   * not finalizing — the interpreter-shutdown sweep tears down the
        //     `warnings` machinery and would otherwise re-enter a half-dead VM;
        //   * `!closed` — an explicit `close()` latches `closed=true` (and
        //     swaps the backend to an in-memory buffer), so a properly closed
        //     stream stays silent;
        //   * `closefd` — a borrowed descriptor (`FileIO(fd, closefd=False)`)
        //     is not ours to warn about;
        //   * a live `Disk` backend — in-memory `BytesIO`/`StringIO` and the
        //     std streams never carry an OS fd to leak.
        // The `closed`/backend gates also make this idempotent against the
        // fd close below and any re-entrant drop. The message is *enqueued*,
        // not emitted in place: a destructor runs at an arbitrary point (an
        // `Rc` can hit zero mid-instruction while a container is borrowed), so
        // synthesising the Python warning here would re-enter `warnings.warn`
        // and panic with `BorrowMutError`. The eval loop drains the queue at
        // its between-bytecodes safe point, matching CPython's dealloc timing;
        // during shutdown the module sweep in `run_shutdown_finalizers` drains
        // one last time (CPython's late "<sys>:0: ResourceWarning").
        if !*self.closed.borrow()
            && self.closefd.get()
            && matches!(&*self.backend.borrow(), FileBackend::Disk(_))
        {
            let addr = std::ptr::from_ref(self) as usize;
            let repr = self.repr_with_addr(addr);
            crate::vm_singletons::push_pending_resource_warning_with_source(
                format!("unclosed file {repr}"),
                addr,
            );
        }
        // Close any still-open OS descriptor *ourselves* rather than letting
        // Rust's `File` (an `OwnedFd`) run its checked drop. User code can
        // close the fd out from under us (`os.close(f.fileno())`), and Rust's
        // checked close aborts the whole process on a double close ("IO Safety
        // violation"). CPython models fds as plain ints where that is just
        // `EBADF`, so we close the raw fd and swallow the error. If `close()`
        // already ran the backend is an in-memory buffer (no-op here);
        // `closefd=False` detaches without closing.
        // Best-effort flush of any staged `BufferedWriter` bytes before the
        // descriptor is dropped, so data written but never explicitly flushed
        // still reaches disk (CPython relies on the buffer's deallocator).
        let _ = self.flush_write_buf();
        #[cfg(unix)]
        {
            let Ok(mut backend) = self.backend.try_borrow_mut() else {
                return;
            };
            if matches!(&*backend, FileBackend::Disk(_)) {
                let old = std::mem::replace(
                    &mut *backend,
                    FileBackend::MemBytes {
                        data: Rc::new(RefCell::new(Vec::new())),
                        pos: 0,
                    },
                );
                if let FileBackend::Disk(f) = old {
                    use std::os::unix::io::IntoRawFd;
                    let fd = f.into_raw_fd();
                    if self.closefd.get() {
                        unsafe {
                            libc::close(fd);
                        }
                    }
                }
            }
        }
        #[cfg(windows)]
        {
            // RFC 0063: the Windows twin of the Unix drop path above —
            // detach the handle from the `File`, then release through the
            // adopted CRT fd (when `fileno()` minted one) or `CloseHandle`,
            // swallowing stale-descriptor errors like CPython's plain-int
            // fd model does.
            let Ok(mut backend) = self.backend.try_borrow_mut() else {
                return;
            };
            if matches!(&*backend, FileBackend::Disk(_)) {
                let old = std::mem::replace(
                    &mut *backend,
                    FileBackend::MemBytes {
                        data: Rc::new(RefCell::new(Vec::new())),
                        pos: 0,
                    },
                );
                if let FileBackend::Disk(f) = old {
                    if self.closefd.get() {
                        let _ = crate::stdlib::nt_support::close_disk_file(f);
                    } else {
                        use std::os::windows::io::IntoRawHandle;
                        let _ = f.into_raw_handle();
                    }
                }
            }
        }
    }
}

/// Concrete backing store for a [`PyFile`].
pub enum FileBackend {
    /// A real file on disk.
    Disk(std::fs::File),
    /// In-memory byte buffer (`io.BytesIO`). The data lives behind a shared
    /// `Rc<RefCell<Vec<u8>>>` (the same store a `bytearray`/`memoryview`
    /// uses) so `BytesIO.getbuffer()` can hand out a *writable* view that
    /// aliases the buffer — and the export-tracking machinery
    /// (`bytearray_is_exported`) makes resize-while-exported raise
    /// `BufferError`, matching CPython's `bytesio.c` `check_exports`.
    MemBytes {
        data: Rc<RefCell<Vec<u8>>>,
        pos: usize,
    },
    /// In-memory UTF-8 buffer (`io.StringIO`).
    MemText { data: String, pos: usize },
    /// The interpreter's process stdout sink.
    Stdout(Rc<RefCell<dyn Write + Send + Sync>>),
    /// The interpreter's process stderr sink.
    Stderr(Rc<RefCell<dyn Write + Send + Sync>>),
    /// Process stdin (read-only).
    Stdin,
}

impl fmt::Debug for FileBackend {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Disk(_) => write!(f, "Disk"),
            Self::MemBytes { .. } => write!(f, "MemBytes"),
            Self::MemText { .. } => write!(f, "MemText"),
            Self::Stdout(_) => write!(f, "Stdout"),
            Self::Stderr(_) => write!(f, "Stderr"),
            Self::Stdin => write!(f, "Stdin"),
        }
    }
}

/// State of an [`Object::LazyIter`]. A separate struct (rather than
/// `PyIterator` variants) because stepping needs the interpreter, and
/// `PyIterator::next_value`'s 30+ call sites step without one — a lazy
/// adapter reaching them would silently read as exhausted.
#[derive(Debug)]
pub struct PyLazyIter {
    pub state: RefCell<LazyIterKind>,
}

impl PyLazyIter {
    /// Python-visible type name (`type(islice(...)).__name__`).
    pub fn type_name(&self) -> &'static str {
        match &*self.state.borrow() {
            LazyIterKind::Islice { .. } => "islice",
            LazyIterKind::Repeat { .. } => "repeat",
            LazyIterKind::TeeBranch { .. } => "_tee",
            LazyIterKind::Count { .. } => "count",
            LazyIterKind::Cycle { .. } => "cycle",
            LazyIterKind::Chain { .. } => "chain",
            LazyIterKind::Compress { .. } => "compress",
            LazyIterKind::DropWhile { .. } => "dropwhile",
            LazyIterKind::TakeWhile { .. } => "takewhile",
            LazyIterKind::FilterFalse { .. } => "filterfalse",
            LazyIterKind::StarMap { .. } => "starmap",
            LazyIterKind::Pairwise { .. } => "pairwise",
            LazyIterKind::ZipLongest { .. } => "zip_longest",
            LazyIterKind::Accumulate { .. } => "accumulate",
            LazyIterKind::Product { .. } => "product",
            LazyIterKind::Permutations { .. } => "permutations",
            LazyIterKind::Combinations { .. } => "combinations",
            LazyIterKind::Cwr { .. } => "combinations_with_replacement",
            LazyIterKind::Batched { .. } => "batched",
        }
    }
}

/// Buffer shared by the branches of one `tee()` call. `buffer` aliases
/// the storage of the Python-level `_tee_dataobject.buffer` list, so
/// items appended natively stay visible to `__reduce__` on the Python
/// side. Dropping a multi-million-cell buffer is a plain `Vec` drop —
/// iterative, never recursing down a linked chain.
#[derive(Debug)]
pub struct TeeShared {
    /// `None` once the source is exhausted.
    pub source: Option<Object>,
    pub buffer: Rc<RefCell<Vec<Object>>>,
    /// Guards the source pull: CPython's tee raises RuntimeError when
    /// one branch re-enters the shared source while another branch is
    /// already inside it.
    pub busy: bool,
}

#[derive(Debug)]
pub enum LazyIterKind {
    /// `itertools.islice(source, start, stop, step)` mid-iteration.
    /// `next_idx` is the source index of the next element to emit and
    /// `pos` the source index the underlying iterator will yield next;
    /// the gap between them is skipped on demand (CPython consumes
    /// skipped elements lazily, not at construction).
    Islice {
        source: Object,
        next_idx: u64,
        pos: u64,
        stop: Option<u64>,
        step: u64,
        done: bool,
    },
    /// Core of `itertools.repeat`: yield `obj` forever (`times` None)
    /// or `times` more times.
    Repeat { obj: Object, times: Option<i64> },
    /// One branch of `itertools.tee`. `data` is the Python
    /// `_tee_dataobject` the branch reports through `lazy_state` (for
    /// pickling); the hot path reads `shared` directly.
    TeeBranch {
        shared: Rc<RefCell<TeeShared>>,
        data: Object,
        index: usize,
    },
    /// `itertools.count(current, step)` — values can be any numeric
    /// type (float, Decimal, Fraction), stepping goes through the
    /// interpreter's `+`.
    Count { current: Object, step: Object },
    /// `itertools.cycle`. `saved` aliases the Python wrapper's saved
    /// list storage; `firstpass` set means elements are already saved
    /// (don't re-append while draining `source`).
    Cycle {
        source: Option<Object>,
        saved: Rc<RefCell<Vec<Object>>>,
        index: usize,
        firstpass: bool,
    },
    /// `itertools.chain`: `source` iterates the iterables, `active`
    /// the current one. `source` None means fully exhausted.
    Chain {
        source: Option<Object>,
        active: Option<Object>,
    },
    /// `itertools.compress(data, selectors)`.
    Compress { data: Object, selectors: Object },
    /// `itertools.dropwhile(func, source)`; `started` once the
    /// predicate has failed.
    DropWhile {
        func: Object,
        source: Object,
        started: bool,
    },
    /// `itertools.takewhile(func, source)`.
    TakeWhile {
        func: Object,
        source: Object,
        stopped: bool,
    },
    /// `itertools.filterfalse(func_or_None, source)`.
    FilterFalse { func: Object, source: Object },
    /// `itertools.starmap(func, source)`.
    StarMap { func: Object, source: Object },
    /// `itertools.pairwise(source)`.
    Pairwise {
        source: Option<Object>,
        old: Option<Object>,
    },
    /// `itertools.zip_longest(*iters, fillvalue=...)`; exhausted slots
    /// become `None`.
    ZipLongest {
        iters: Vec<Option<Object>>,
        fillvalue: Object,
        numactive: usize,
    },
    /// `itertools.accumulate(source, func, initial=...)`.
    Accumulate {
        source: Object,
        func: Option<Object>,
        total: Option<Object>,
        initial: Option<Object>,
    },
    /// `itertools.product` over materialised pools.
    Product {
        pools: Vec<crate::object::SharedTuple>,
        indices: Vec<usize>,
        started: bool,
        stopped: bool,
    },
    /// `itertools.permutations(pool, r)` (Sedgewick's cycles algorithm,
    /// like CPython).
    Permutations {
        pool: crate::object::SharedTuple,
        r: usize,
        indices: Vec<usize>,
        cycles: Vec<usize>,
        started: bool,
        stopped: bool,
    },
    /// `itertools.combinations(pool, r)`.
    Combinations {
        pool: crate::object::SharedTuple,
        r: usize,
        indices: Vec<usize>,
        started: bool,
        stopped: bool,
    },
    /// `itertools.combinations_with_replacement(pool, r)`.
    Cwr {
        pool: crate::object::SharedTuple,
        r: usize,
        indices: Vec<usize>,
        started: bool,
        stopped: bool,
    },
    /// `itertools.batched(source, n, strict)`.
    Batched {
        source: Option<Object>,
        n: usize,
        strict: bool,
    },
}

/// State of an active iterator. Slim by design — every iterable
/// type implements its own iteration here (no Python-level iterator
/// protocol yet).
#[derive(Debug, Clone)]
pub enum PyIterator {
    List {
        items: Rc<RefCell<Vec<Object>>>,
        index: usize,
        /// Keepalive for a list-*subclass* source: `items` is only the
        /// native payload, so the subclass instance (and its `__del__`)
        /// is pinned here while the iterator lives (test_list
        /// test_free_after_iterating). Boxed to keep the variant small.
        owner: Option<Box<Object>>,
    },
    Tuple {
        items: crate::object::SharedTuple,
        index: usize,
    },
    Str {
        s: SharedStr,
        index: usize,
    },
    Range {
        current: i64,
        stop: i64,
        step: i64,
    },
    /// Range whose bounds don't all fit `i64` — the slow sibling of
    /// `Range` (which stays `i64` so the FOR_ITER inline cache pushes
    /// machine ints without conversion checks).
    RangeHuge {
        current: i128,
        stop: i128,
        step: i128,
    },
    /// Range with bounds past `i128` (CPython's `longrange_iterator`,
    /// e.g. `iter(range(1 << 1000))` — test_range). Boxed to keep the
    /// `PyIterator` enum small for the common variants.
    RangeBig {
        current: Box<BigInt>,
        stop: Box<BigInt>,
        step: Box<BigInt>,
    },
    /// Live iterator over a dict (CPython's `dictiterobject`): walks the
    /// `IndexMap` by entry index rather than snapshotting, so it pins no
    /// key/value `Rc`s of its own — an overwritten value is freed promptly
    /// even mid-loop (`test_oob_indexing_dictiter_iternextitem` relies on
    /// `d[k] = None` firing the old value's `__del__` during iteration),
    /// and the cycle GC can trace `iter -> dict -> elements`
    /// (`test_container_iterator`).
    DictKeys {
        /// What each step yields: the key, the value, or a `(key, value)`
        /// tuple — one iterator shape backs `iter(d)`, `iter(d.keys())`,
        /// `iter(d.values())` and `iter(d.items())` so all of them share
        /// the mutation trip-wires below.
        kind: DictViewKind,
        index: usize,
        /// The live source dict. Detached (set to `None`) on exhaustion,
        /// like CPython clearing `di_dict` on the first StopIteration, so
        /// a later mutation can't resurrect the iterator or trip its
        /// guards.
        dict: Option<Rc<RefCell<DictData>>>,
        /// `len()` of `dict` at iterator creation; a later mismatch trips
        /// the "changed size during iteration" error (CPython's
        /// `di_used != ma_used` guard).
        len: usize,
        /// Structural-version subscription, established lazily by the
        /// first checked `__next__` (internal drains that use the
        /// unchecked path never pay for it). A version change with the
        /// *same* size — `del d[k]; d[k] = v` mid-loop — raises
        /// `RuntimeError: dictionary keys changed during iteration`,
        /// matching CPython's tombstone-based detection.
        watch: Option<DictWatch>,
        /// Keepalive for a dict-*subclass* source: `dict` above is only
        /// the native payload, so the subclass instance (and its
        /// `__del__`) must be pinned here for the iterator's lifetime
        /// (test_dict test_free_after_iterating).
        owner: Option<Object>,
        /// `reversed(d)` / `reversed(d.items())` …: `index` then counts
        /// *down* (it holds the number of entries still to yield). The
        /// watch is taken eagerly so a `clear()` + refill before the
        /// first step exhausts the cursor silently, like CPython's
        /// `di_pos >= dk_nentries` bail-out
        /// (test_dict.test_reversed_dict_after_clear_and_restore).
        reverse: bool,
    },
    Bytes {
        data: SharedSlice<u8>,
        index: usize,
    },
    /// Live view over a bytearray (CPython's `bytearray_iterator`
    /// tracks the buffer, so clearing the bytearray exhausts a
    /// half-consumed iterator — issue 27443).
    ByteArray {
        data: Rc<RefCell<Vec<u8>>>,
        index: usize,
    },
    /// Lazy `enumerate(...)`. Holds a *shared* handle to the wrapped
    /// iterator so consuming the enumerate also advances the original
    /// (CPython: `enumerate(it)` yields from the same `it`, leaving it
    /// positioned right after the last item produced).
    Enumerate {
        inner: Rc<RefCell<PyIterator>>,
        count: i64,
        /// Engaged when the counter can't ride in an `i64` — a big
        /// `start` (`enumerate(x, sys.maxsize + 1)`) or an overflowing
        /// increment. `count` is ignored while this is `Some`.
        count_big: Option<Box<BigInt>>,
    },
    /// `reversed(seq)` — yields `items[index]`, `items[index-1]`, … down
    /// to `items[0]`. `items` is held in *forward* order (matching
    /// CPython's `list_reverseiterator`, whose `__reduce__` is
    /// `(reversed, (forward_seq,), index)`); `index` counts down and the
    /// backing vector is detached on exhaustion.
    Reversed {
        items: Rc<RefCell<Vec<Object>>>,
        index: i64,
        /// Keepalive for a list-*subclass* source (see [`Self::List`]).
        owner: Option<Box<Object>>,
    },
    /// Shared handle onto an existing `Object::Iter`'s cursor: `iter(it)
    /// is it` in Python, so any consumer draining the handle must advance
    /// the original object too (`heapq.nlargest` zips a prefix off `it`
    /// and then scans the tail with `for elem in it`). Cloning the cursor
    /// instead would silently fork the position.
    Shared(Rc<RefCell<PyIterator>>),
    /// Generic subclass keepalive: `inner` iterates a builtin-container
    /// *subclass*'s native payload, and `owner` pins the subclass
    /// instance so its `__del__` can't fire while the iterator is live;
    /// the pin drops on exhaustion, running the finalizer at CPython's
    /// timing (support.check_free_after_iterating — tuple / str / bytes
    /// / bytearray / set subclasses; `List`/`Reversed`/`DictKeys` carry
    /// dedicated `owner` slots instead).
    KeepAlive {
        inner: Rc<RefCell<PyIterator>>,
        owner: Option<Object>,
    },
    /// Live iterator over a mutable `set` (CPython's `setiterobject`).
    /// Unlike the snapshot iterators above it keeps the *set object*
    /// alive and walks it by slot index, so (a) the cycle GC can trace
    /// `iter -> set -> elements` (`test_container_iterator`) and (b) a
    /// size change between `__next__` calls is detected against the
    /// `len` snapshot and raises `RuntimeError: Set changed size during
    /// iteration` (`test_changingSizeWhileIterating`), exactly like
    /// `setiter_iternext` comparing `si_used` to `so->used`.
    Set {
        set: Rc<RefCell<SetData>>,
        index: usize,
        /// `so->used` at iterator creation; a later mismatch is the
        /// "changed size during iteration" trip-wire.
        len: usize,
    },
    /// Lazy line iterator over an open file object. In CPython a file *is*
    /// its own iterator and reads exactly one line per `__next__`, so we
    /// hold the `PyFile` and stream line-by-line rather than draining the
    /// whole stream up front. This is required for (a) pipes / growing
    /// files / `sys.stdin` where eager draining would block until EOF, and
    /// (b) binary-mode files, which must yield `bytes` lines (CPython makes
    /// binary files iterable too — `multiprocessing.resource_tracker.main`
    /// does `for line in open(fd, 'rb')`).
    File {
        file: Rc<PyFile>,
    },
}

impl PyIterator {
    /// Pull the next value out of the iterator, or `None` if exhausted.
    pub fn next_value(&mut self) -> Option<Object> {
        match self {
            PyIterator::List {
                items,
                index,
                owner,
            } => {
                let next = items.borrow().get(*index).cloned();
                match next {
                    Some(v) => {
                        *index += 1;
                        Some(v)
                    }
                    None => {
                        // Exhausted. Detach from the backing list so a
                        // later `append`/`extend` can't resurrect the
                        // iterator — CPython clears `it_seq` on the first
                        // StopIteration and the iterator stays empty. The
                        // subclass keepalive drops with it, running its
                        // `__del__` here like CPython freeing the list
                        // (test_free_after_iterating).
                        *items = Rc::new(RefCell::new(Vec::new()));
                        *owner = None;
                        None
                    }
                }
            }
            PyIterator::Tuple { items, index } => {
                let v = items.get(*index).cloned()?;
                *index += 1;
                Some(v)
            }
            PyIterator::Str { s, index } => {
                let bytes = s.as_bytes();
                if *index >= bytes.len() {
                    return None;
                }
                // Advance by one UTF-8 code point.
                let rest = &s[*index..];
                let ch = rest.chars().next()?;
                let len = ch.len_utf8();
                *index += len;
                Some(Object::Str(SharedStr::from(ch.to_string().as_str())))
            }
            PyIterator::Range {
                current,
                stop,
                step,
            } => {
                let exhausted = if *step > 0 {
                    *current >= *stop
                } else if *step < 0 {
                    *current <= *stop
                } else {
                    true
                };
                if exhausted {
                    return None;
                }
                let v = *current;
                *current += *step;
                Some(Object::Int(v))
            }
            PyIterator::RangeHuge {
                current,
                stop,
                step,
            } => {
                let exhausted = if *step > 0 {
                    *current >= *stop
                } else if *step < 0 {
                    *current <= *stop
                } else {
                    true
                };
                if exhausted {
                    return None;
                }
                let v = *current;
                // Advancing past the final value can cross i128's boundary
                // even though every yielded value and the stop are valid.
                // Such an advance is necessarily beyond the stop, so exhaust.
                *current = current.checked_add(*step).unwrap_or(*stop);
                Some(int_from_i128(v))
            }
            PyIterator::RangeBig {
                current,
                stop,
                step,
            } => {
                let zero = BigInt::from(0);
                let exhausted = if **step > zero {
                    **current >= **stop
                } else if **step < zero {
                    **current <= **stop
                } else {
                    true
                };
                if exhausted {
                    return None;
                }
                let v = (**current).clone();
                **current += &**step;
                Some(Object::int_from_bigint(v))
            }
            PyIterator::DictKeys {
                kind,
                index,
                dict,
                owner,
                reverse,
                ..
            } => {
                let d = dict.as_ref()?;
                let entry = if *reverse {
                    if *index == 0 {
                        None
                    } else {
                        d.borrow()
                            .get_index(*index - 1)
                            .map(|(k, v)| (k.0.clone(), v.clone()))
                    }
                } else {
                    d.borrow()
                        .get_index(*index)
                        .map(|(k, v)| (k.0.clone(), v.clone()))
                };
                match entry {
                    Some((k, v)) => {
                        if *reverse {
                            *index -= 1;
                        } else {
                            *index += 1;
                        }
                        Some(match kind {
                            DictViewKind::Keys => k,
                            DictViewKind::Values => v,
                            DictViewKind::Items => Object::new_tuple_array([k, v]),
                        })
                    }
                    None => {
                        // Exhausted: detach from the dict (CPython clears
                        // `di_dict` on the first StopIteration) so a later
                        // mutation can't resurrect the cursor or trip the
                        // mutation guards. The subclass keepalive drops
                        // with it — CPython frees the dict object here,
                        // running its `__del__` (test_free_after_iterating
                        // expects that ordering).
                        *dict = None;
                        *owner = None;
                        None
                    }
                }
            }
            PyIterator::Bytes { data, index } => {
                let v = data.get(*index).copied()?;
                *index += 1;
                Some(Object::Int(i64::from(v)))
            }
            PyIterator::ByteArray { data, index } => {
                let v = data.borrow().get(*index).copied();
                match v {
                    Some(v) => {
                        *index += 1;
                        Some(Object::Int(i64::from(v)))
                    }
                    None => {
                        // Exhausted. Detach from the buffer so a later
                        // `append` can't resurrect the iterator —
                        // CPython clears `it_seq` on first StopIteration.
                        // `usize::MAX` marks the detached state so
                        // `__reduce__` emits the exhausted form.
                        *data = Rc::new(RefCell::new(Vec::new()));
                        *index = usize::MAX;
                        None
                    }
                }
            }
            PyIterator::Enumerate {
                inner,
                count,
                count_big,
            } => {
                let v = inner.borrow_mut().next_value()?;
                let idx = if let Some(b) = count_big {
                    let cur = (**b).clone();
                    **b += 1;
                    Object::Long(Rc::new(cur))
                } else {
                    let i = *count;
                    match count.checked_add(1) {
                        Some(n) => *count = n,
                        None => *count_big = Some(Box::new(BigInt::from(i) + 1)),
                    }
                    Object::Int(i)
                };
                Some(Object::new_tuple_array([idx, v]))
            }
            PyIterator::Shared(inner) => inner.borrow_mut().next_value(),
            PyIterator::KeepAlive { inner, owner } => {
                let v = inner.borrow_mut().next_value();
                if v.is_none() {
                    // Exhausted: drop the subclass pin so its `__del__`
                    // runs now, like CPython freeing the container on
                    // the iterator's first StopIteration.
                    *owner = None;
                }
                v
            }
            // Lazy file line. The error channel is `next_value_checked`
            // (used by FOR_ITER / `next()`); the rare internal drain that
            // calls `next_value` treats a read error as end-of-stream.
            PyIterator::File { file } => {
                let is_text = !file.binary;
                if is_text {
                    file.telling.set(false);
                }
                let line = file.readline_obj().ok().flatten();
                if is_text && line.is_none() {
                    file.telling.set(file.seekable());
                }
                line
            }
            PyIterator::Set { set, index, .. } => {
                let v = set.borrow().get_index(*index).map(|k| k.0.clone());
                match v {
                    Some(v) => {
                        *index += 1;
                        Some(v)
                    }
                    None => None,
                }
            }
            PyIterator::Reversed {
                items,
                index,
                owner,
            } => {
                if *index < 0 {
                    *items = Rc::new(RefCell::new(Vec::new()));
                    *owner = None;
                    return None;
                }
                let v = items.borrow().get(*index as usize).cloned();
                match v {
                    Some(val) => {
                        *index -= 1;
                        Some(val)
                    }
                    None => {
                        // Index out of range (list shrank): exhaust + detach.
                        *items = Rc::new(RefCell::new(Vec::new()));
                        *index = -1;
                        *owner = None;
                        None
                    }
                }
            }
        }
    }

    /// Whether this iterator can participate in a reference cycle and so
    /// should be enrolled with the cycle GC when created (CPython tracks
    /// these `*_iterator` objects). Scalar iterators (`range`, `str`,
    /// `bytes`, `bytearray`) buffer no `Object`s and can never close a
    /// cycle, so they stay off the GC's books — keeping the hot
    /// `for i in range(...)` path allocation-light.
    pub fn can_cycle(&self) -> bool {
        matches!(
            self,
            PyIterator::List { .. }
                | PyIterator::Tuple { .. }
                | PyIterator::DictKeys { .. }
                | PyIterator::Set { .. }
                | PyIterator::Reversed { .. }
                | PyIterator::Enumerate { .. }
                | PyIterator::Shared(_)
                | PyIterator::KeepAlive { .. }
        )
    }

    /// Visit every [`Object`] this iterator keeps alive, for the cycle
    /// GC's `tp_traverse`. CPython implements `*_iterator.tp_traverse`
    /// for exactly this reason (bug #3680 — a set iterator stored on an
    /// element of the set it iterates is an uncollectable cycle without
    /// it). The snapshot iterators expose their buffered items; the live
    /// `Set` iterator exposes the set's current elements.
    pub fn gc_referents(&self, visit: &mut dyn FnMut(&Object)) {
        match self {
            PyIterator::List { items, owner, .. } | PyIterator::Reversed { items, owner, .. } => {
                // A list-subclass keepalive is a real edge — the
                // free-after-iterating cycle (`iter -> instance -> class
                // -> __del__ cell -> iter`) must be traceable.
                if let Some(o) = owner {
                    visit(o);
                }
                // `iter(list)` shares the *live* list's backing buffer (the
                // same `Rc<RefCell<Vec>>`), so the referent edge to subtract is
                // `iter -> list`, not `iter -> elements`: the list object is a
                // GC candidate in its own right and accounts `list -> elements`
                // via `traverse_object`. Visiting the elements here instead
                // would leave the list's internal refcount unsubtracted,
                // stranding it as a false root (and pinning the cycle).
                // Snapshot iterators (`frozenset`/`dict.values()`/file) hold a
                // *private* buffer that no tracked list shares; the collector's
                // transient-promotion step treats that buffer as a temporary
                // candidate so its `-> elements` edges are still accounted.
                visit(&Object::List(items.clone()));
            }
            PyIterator::Tuple { items, .. } => {
                for v in items.iter() {
                    visit(v);
                }
            }
            PyIterator::DictKeys { dict, owner, .. } => {
                // A live cursor: the iterator holds only the *dict* (a
                // shared `Rc`), so the cycle edge to subtract is
                // `iter -> dict`; the dict's own `tp_traverse` accounts
                // `dict -> items` (bug #3680's dict-iterator analogue).
                if let Some(d) = dict {
                    visit(&Object::Dict(d.clone()));
                }
                // A dict-subclass keepalive is a real edge too — the
                // free-after-iterating cycle (`iter -> instance -> class
                // -> __del__ cell -> iter`) must be traceable.
                if let Some(o) = owner {
                    visit(o);
                }
            }
            PyIterator::Set { set, .. } => {
                // The iterator holds the *set* (a shared `Rc`), and the set
                // holds the element `Rc`s — so the cycle edge to subtract is
                // `iter -> set`, with the set's own `tp_traverse` accounting
                // `set -> elements`. Visiting the elements directly here would
                // leave the set's internal refcount unsubtracted, stranding it
                // (and everything it reaches) as a false root.
                visit(&Object::Set(set.clone()));
            }
            PyIterator::Enumerate { inner, .. } | PyIterator::Shared(inner) => {
                if let Ok(inner) = inner.try_borrow() {
                    inner.gc_referents(visit);
                }
            }
            PyIterator::KeepAlive { inner, owner } => {
                // The subclass pin is a real edge — the
                // free-after-iterating cycle (`iter -> instance -> class
                // -> __del__ cell -> iter`) must be traceable.
                if let Some(o) = owner {
                    visit(o);
                }
                if let Ok(inner) = inner.try_borrow() {
                    inner.gc_referents(visit);
                }
            }
            // No `Object` referents: the payload is plain bytes / scalars,
            // or (for `File`) an OS handle that buffers no Python objects.
            PyIterator::Str { .. }
            | PyIterator::Bytes { .. }
            | PyIterator::ByteArray { .. }
            | PyIterator::Range { .. }
            | PyIterator::RangeHuge { .. }
            | PyIterator::RangeBig { .. }
            | PyIterator::File { .. } => {}
        }
    }

    /// Like [`next_value`], but enforces CPython's "container changed
    /// size during iteration" invariant before yielding. Used on the
    /// *user-visible* `__next__` boundaries (`FOR_ITER`, the `next()`
    /// builtin, `iter.__next__()`); the many internal consumers that
    /// drain a freshly-built iterator without mutating its source can
    /// keep calling the cheaper [`next_value`].
    pub fn next_value_checked(&mut self) -> Result<Option<Object>, RuntimeError> {
        if let PyIterator::Set { set, len, index } = self {
            // `setiter_iternext`: a size change since creation is fatal,
            // even on the step that would otherwise raise StopIteration.
            if set.borrow().len() != *len {
                // Sticky, like CPython's `si_used = -1`: every further
                // `next()` keeps raising, and `__length_hint__` reports 0
                // (test_iterlen.test_immutable_during_iteration).
                *len = usize::MAX;
                *index = usize::MAX;
                return Err(runtime_error("Set changed size during iteration"));
            }
        }
        if let PyIterator::DictKeys {
            dict: Some(d),
            len,
            watch,
            index,
            reverse,
            ..
        } = self
        {
            // `dictiter_iternext`: a size change since creation is fatal,
            // mirroring CPython's `di_used != ma_used` guard. Triggers even
            // on the step that would otherwise raise StopIteration.
            if d.borrow().len() != *len {
                // Sticky (`di_used = -1`): further `next()` calls keep
                // raising and `__length_hint__` reports 0.
                *len = usize::MAX;
                *index = if *reverse { 0 } else { usize::MAX };
                return Err(runtime_error("dictionary changed size during iteration"));
            }
            // Same size but keys churned (`del d[k]; d[k] = v` between
            // steps): CPython's iterator walks past the delete's tombstone
            // into the appended entry and raises. We detect the same churn
            // through the structural-version watch (value overwrites don't
            // bump it, so `d[k] = new` over an existing key stays legal).
            match watch {
                Some(w) if w.changed() => {
                    if *reverse {
                        // `dictreviter_iter_lock_held`: a rebuilt entry
                        // array leaves `di_pos` past `dk_nentries`, which
                        // is a silent StopIteration, not an error.
                        *index = 0;
                        return Ok(None);
                    }
                    return Err(runtime_error("dictionary keys changed during iteration"));
                }
                None => *watch = Some(DictWatch::new(d)),
                _ => {}
            }
        }
        if let PyIterator::File { file } = self {
            // Surface read errors (OSError, decode errors) at the
            // user-visible `__next__` boundary instead of swallowing them.
            // CPython's `TextIOWrapper.__next__` disables `tell()` for the
            // duration of the iteration and restores it (to `seekable`) at
            // EOF (`test_io.test_telling`); binary streams keep `tell()` live.
            let is_text = !file.binary;
            if is_text {
                file.telling.set(false);
            }
            let line = file.readline_obj()?;
            if is_text && line.is_none() {
                file.telling.set(file.seekable());
            }
            return Ok(line);
        }
        if let PyIterator::KeepAlive { inner, owner } = self {
            // Delegate so the inner cursor's mutation guards (set/dict
            // size checks above) still fire through the wrapper.
            let r = inner.borrow_mut().next_value_checked();
            if matches!(r, Ok(None)) {
                // Exhausted: drop the subclass pin (see `next_value`).
                *owner = None;
            }
            return r;
        }
        Ok(self.next_value())
    }

    /// Number of items remaining, when cheaply known. Backs the
    /// `__length_hint__` slot CPython's built-in iterators expose
    /// (`operator.length_hint`, list pre-sizing, …). Returns `None`
    /// for sources whose remaining length isn't known in O(1).
    pub fn remaining(&self) -> Option<usize> {
        match self {
            PyIterator::List { items, index, .. } => {
                Some(items.borrow().len().saturating_sub(*index))
            }
            PyIterator::Tuple { items, index } => Some(items.len().saturating_sub(*index)),
            PyIterator::Str { s, index } => Some(s[(*index).min(s.len())..].chars().count()),
            PyIterator::DictKeys {
                dict,
                index,
                reverse,
                ..
            } => Some(dict.as_ref().map_or(0, |d| {
                if *reverse {
                    (*index).min(d.borrow().len())
                } else {
                    d.borrow().len().saturating_sub(*index)
                }
            })),
            PyIterator::Bytes { data, index } => Some(data.len().saturating_sub(*index)),
            PyIterator::ByteArray { data, index } => {
                Some(data.borrow().len().saturating_sub(*index))
            }
            PyIterator::Enumerate { inner, .. } => inner.borrow().remaining(),
            PyIterator::Shared(inner) => inner.borrow().remaining(),
            PyIterator::KeepAlive { inner, .. } => inner.borrow().remaining(),
            PyIterator::Set { set, index, .. } => Some(set.borrow().len().saturating_sub(*index)),
            // CPython `listreviter_len`: `index + 1`, but 0 when the live
            // list shrank below the cursor (test_iterlen
            // TestListReversed.test_mutation).
            PyIterator::Reversed { items, index, .. } => {
                let len = (*index + 1).max(0) as usize;
                if items.borrow().len() < len {
                    Some(0)
                } else {
                    Some(len)
                }
            }
            PyIterator::Range {
                current,
                stop,
                step,
            } => {
                if *step > 0 && *current < *stop {
                    Some(
                        ((i128::from(*stop) - i128::from(*current) + i128::from(*step) - 1)
                            / i128::from(*step)) as usize,
                    )
                } else if *step < 0 && *current > *stop {
                    Some(
                        ((i128::from(*current) - i128::from(*stop) - i128::from(*step) - 1)
                            / -i128::from(*step)) as usize,
                    )
                } else {
                    Some(0)
                }
            }
            PyIterator::RangeHuge {
                current,
                stop,
                step,
            } => range_len_bigint(&Range::new(*current, *stop, *step)).to_usize(),
            PyIterator::RangeBig {
                current,
                stop,
                step,
            } => {
                use num_traits::ToPrimitive;
                let zero = BigInt::from(0);
                let one = BigInt::from(1);
                if **step > zero && **current < **stop {
                    ((&**stop - &**current + &**step - &one) / &**step).to_usize()
                } else if **step < zero && **current > **stop {
                    ((&**current - &**stop - &**step - &one) / (-&**step)).to_usize()
                } else {
                    Some(0)
                }
            }
            // A stream's remaining length isn't known without reading it.
            PyIterator::File { .. } => None,
        }
    }

    /// Snapshot the items the iterator would still yield, *without*
    /// consuming it. Backs the built-in iterator's `__reduce__`
    /// (pickling): CPython reduces e.g. a list-iterator to
    /// `(iter, (remaining_list,))`, so a freshly-unpickled iterator
    /// replays exactly the not-yet-seen elements. A shared
    /// (`Enumerate`) inner is read through its `RefCell` borrow, never
    /// advanced.
    pub fn remaining_items(&self) -> Vec<Object> {
        match self {
            PyIterator::List { items, index, .. } => items
                .borrow()
                .get(*index..)
                .map(<[_]>::to_vec)
                .unwrap_or_default(),
            PyIterator::Tuple { items, index } => {
                items.get(*index..).map(<[_]>::to_vec).unwrap_or_default()
            }
            PyIterator::Str { s, index } => {
                let start = (*index).min(s.len());
                s[start..]
                    .chars()
                    .map(|c| Object::Str(SharedStr::from(c.to_string().as_str())))
                    .collect()
            }
            PyIterator::DictKeys {
                kind,
                index,
                dict,
                reverse,
                ..
            } => match dict {
                Some(d) => {
                    let d = d.borrow();
                    let range: Box<dyn Iterator<Item = usize>> = if *reverse {
                        Box::new((0..(*index).min(d.len())).rev())
                    } else {
                        Box::new((*index).min(d.len())..d.len())
                    };
                    range
                        .filter_map(|i| d.get_index(i))
                        .map(|(k, v)| match kind {
                            DictViewKind::Keys => k.0.clone(),
                            DictViewKind::Values => v.clone(),
                            DictViewKind::Items => {
                                Object::new_tuple_array([k.0.clone(), v.clone()])
                            }
                        })
                        .collect()
                }
                None => Vec::new(),
            },
            PyIterator::Bytes { data, index } => data
                .get(*index..)
                .map(|rest| rest.iter().map(|b| Object::Int(i64::from(*b))).collect())
                .unwrap_or_default(),
            PyIterator::ByteArray { data, index } => data
                .borrow()
                .get(*index..)
                .map(|rest| rest.iter().map(|b| Object::Int(i64::from(*b))).collect())
                .unwrap_or_default(),
            PyIterator::Range {
                current,
                stop,
                step,
            } => {
                let mut out = Vec::new();
                let (mut c, st, sp) = (*current, *stop, *step);
                if sp > 0 {
                    while c < st {
                        out.push(Object::Int(c));
                        c += sp;
                    }
                } else if sp < 0 {
                    while c > st {
                        out.push(Object::Int(c));
                        c += sp;
                    }
                }
                out
            }
            PyIterator::RangeHuge {
                current,
                stop,
                step,
            } => {
                let mut out = Vec::new();
                let (mut c, st, sp) = (*current, *stop, *step);
                if sp > 0 {
                    while c < st {
                        out.push(int_from_i128(c));
                        let Some(next) = c.checked_add(sp) else {
                            break;
                        };
                        c = next;
                    }
                } else if sp < 0 {
                    while c > st {
                        out.push(int_from_i128(c));
                        let Some(next) = c.checked_add(sp) else {
                            break;
                        };
                        c = next;
                    }
                }
                out
            }
            PyIterator::RangeBig {
                current,
                stop,
                step,
            } => {
                // Materialisable only when the remaining count fits memory
                // anyway; an astronomically long iterator snapshots empty
                // (pickling it is impossible in CPython too — MemoryError).
                let mut out = Vec::new();
                if self.remaining().is_some() {
                    let (mut c, st, sp) = ((**current).clone(), &**stop, &**step);
                    let zero = BigInt::from(0);
                    if *sp > zero {
                        while c < *st {
                            out.push(Object::int_from_bigint(c.clone()));
                            c += sp;
                        }
                    } else if *sp < zero {
                        while c > *st {
                            out.push(Object::int_from_bigint(c.clone()));
                            c += sp;
                        }
                    }
                }
                out
            }
            PyIterator::Enumerate {
                inner,
                count,
                count_big,
            } => {
                let rest = inner.borrow().remaining_items();
                let mut out = Vec::with_capacity(rest.len());
                match count_big {
                    Some(b) => {
                        let mut i = (**b).clone();
                        for v in rest {
                            out.push(Object::new_tuple_array([
                                Object::Long(Rc::new(i.clone())),
                                v,
                            ]));
                            i += 1;
                        }
                    }
                    None => {
                        for (i, v) in (*count..).zip(rest) {
                            out.push(Object::new_tuple_array([Object::Int(i), v]));
                        }
                    }
                }
                out
            }
            PyIterator::Shared(inner) => inner.borrow().remaining_items(),
            PyIterator::KeepAlive { inner, .. } => inner.borrow().remaining_items(),
            PyIterator::Set { set, index, .. } => set
                .borrow()
                .iter()
                .skip(*index)
                .map(|k| k.0.clone())
                .collect(),
            PyIterator::Reversed { items, index, .. } => {
                // Not-yet-yielded values, in yield order: items[index]..items[0].
                let items = items.borrow();
                let mut out = Vec::new();
                let mut i = *index;
                while i >= 0 {
                    if let Some(v) = items.get(i as usize) {
                        out.push(v.clone());
                    }
                    i -= 1;
                }
                out
            }
            // A file iterator can't be snapshotted without consuming the
            // stream; file objects aren't picklable, so `__reduce__` never
            // reaches here in practice. Empty keeps it side-effect-free.
            PyIterator::File { .. } => Vec::new(),
        }
    }

    /// The forward slice a `reversed`-iterator reduces with: re-applying
    /// `reversed` to it reproduces the not-yet-yielded values in order.
    /// Empty when exhausted, giving CPython's `(reversed, ([],))`.
    pub fn reversed_reduce_arg(&self) -> Option<Object> {
        match self {
            PyIterator::Reversed { items, index, .. } => {
                let items = items.borrow();
                let end = ((*index).max(-1) + 1) as usize;
                let slice = items.get(..end.min(items.len())).unwrap_or(&[]);
                Some(Object::new_list(slice.to_vec()))
            }
            _ => None,
        }
    }

    /// The remaining items packaged in the *native container type*
    /// CPython uses for that iterator's `__reduce__` argument, so the
    /// reduction tuple compares equal to CPython's: a string-iterator
    /// reduces with a `str`, a tuple-iterator with a `tuple`, a
    /// list-iterator with a `list`. (Bytes and the generic seqiter use a
    /// `tuple`, so an exhausted one reduces to `(iter, ((),))`.)
    /// Re-applying `iter` to this value replays exactly the not-yet-seen
    /// elements.
    pub fn reduce_remaining(&self) -> Object {
        match self {
            PyIterator::Tuple { .. } | PyIterator::Bytes { .. } | PyIterator::ByteArray { .. } => {
                Object::new_tuple(self.remaining_items())
            }
            PyIterator::Str { s, index } => {
                let start = (*index).min(s.len());
                Object::from_str(&s[start..])
            }
            // list / dict / range / enumerate reduce through a plain list
            // (dict iterators explicitly unpickle as list iterators).
            _ => Object::new_list(self.remaining_items()),
        }
    }
}

// ---------- behavior ----------

impl Object {
    /// Python truthiness.
    pub fn is_truthy(&self) -> bool {
        match self {
            Object::None => false,
            Object::Unbound => false,
            Object::Bool(b) => *b,
            Object::Int(i) => *i != 0,
            Object::Long(b) => !b.is_zero(),
            Object::Complex(c) => c.real != 0.0 || c.imag != 0.0,
            // IEEE 754: NaN != 0.0, so NaN is truthy (CPython agrees).
            Object::Float(f) => *f != 0.0,
            Object::Str(s) => !s.is_empty(),
            // A `WStr` always holds >= 1 code point (the surrogate), so it is
            // never the empty string and is always truthy.
            Object::WStr(_) => true,
            Object::Tuple(items) => !items.is_empty(),
            Object::List(items) => !items.borrow().is_empty(),
            Object::Dict(d) => !d.borrow().is_empty(),
            Object::Range(r) => {
                if let Some(b) = &r.big {
                    // Both saturated mirrors can clamp to the same extreme
                    // (`range(2**200, 2**201)`), so compare at full width.
                    let zero = BigInt::from(0);
                    if b.2 > zero {
                        b.0 < b.1
                    } else if b.2 < zero {
                        b.0 > b.1
                    } else {
                        false
                    }
                } else if r.step > 0 {
                    r.start < r.stop
                } else if r.step < 0 {
                    r.start > r.stop
                } else {
                    false
                }
            }
            Object::Function(_)
            | Object::Builtin(_)
            | Object::BoundMethod(_)
            | Object::Code(_)
            | Object::Iter(_)
            | Object::Slice(_)
            | Object::Type(_)
            | Object::Module(_)
            | Object::Generator(_)
            | Object::Coroutine(_)
            | Object::AsyncGenerator(_)
            | Object::AsyncGenAwait(_)
            | Object::File(_)
            | Object::Property(_)
            | Object::StaticMethod(_)
            | Object::ClassMethod(_)
            | Object::SlotDescriptor(_)
            | Object::Frame(_)
            | Object::Traceback(_)
            | Object::Capsule(_) => true,
            // Foreign proxies route truthiness through the extension's
            // `nb_bool`/`sq_length` (numpy: a 0-d/1-elem array's truth).
            Object::Foreign(s) => crate::foreign::is_true(s),
            Object::MemoryView(mv) => mv.len.get() > 0,
            Object::MappingProxy(d) => !d.borrow().is_empty(),
            // Static fallback; the VM's truthiness path delegates to the
            // wrapped mapping's `__len__` before reaching here.
            Object::MappingProxyObj(inner) => inner.is_truthy(),
            Object::DictView(v) => !v.dict.borrow().is_empty(),
            Object::SimpleNamespace(_) => true,
            Object::LazyIter(_) => true,
            Object::Bytes(b) => !b.is_empty(),
            Object::ByteArray(b) => !b.borrow().is_empty(),
            Object::Set(s) => !s.borrow().is_empty(),
            Object::FrozenSet(s) => !s.is_empty(),
            Object::Cell(inner) => inner.borrow().is_truthy(),
            Object::Instance(inst) => {
                // int/str/… subclass instances are truthy per their
                // wrapped value unless the class overrides __bool__/__len__.
                if inst.cls().lookup("__bool__").is_none() && inst.cls().lookup("__len__").is_none()
                {
                    if let Some(native) = inst.native.get() {
                        return native.is_truthy();
                    }
                }
                // Honour __bool__ then __len__ before defaulting to True.
                if let Some(m) = inst.cls().lookup("__bool__") {
                    // Caller dispatches; we cannot run Python here.
                    // Default to True; the dispatch site handles the
                    // dunder dispatch when it has interpreter access.
                    let _ = m;
                    true
                } else if let Some(m) = inst.cls().lookup("__len__") {
                    let _ = m;
                    true
                } else {
                    true
                }
            }
        }
    }

    /// `is` operator semantics.
    pub fn is_same(&self, other: &Self) -> bool {
        match (self, other) {
            (Object::None, Object::None) => true,
            (Object::Bool(a), Object::Bool(b)) => a == b,
            (Object::Int(a), Object::Int(b)) => a == b,
            (Object::Long(a), Object::Long(b)) => Rc::ptr_eq(a, b) || **a == **b,
            // Cross-type identity: Int and Long with the same value
            // are *equal* but not the *same* object — `is` checks
            // identity, not value. Mirror CPython by reporting only
            // structural identity, never cross-representation
            // identity. A future RFC may intern the small-int range
            // explicitly.
            (Object::Complex(a), Object::Complex(b)) => {
                // Bit-equality as an identity proxy is safe only for non-NaN
                // parts: a NaN-bearing complex is observable through the
                // `a is b or a == b` container rule (`==` is False), so two
                // distinct allocations must stay distinct — Rc identity only,
                // exactly like CPython's pointer identity.
                Rc::ptr_eq(a, b)
                    || (!a.real.is_nan()
                        && !a.imag.is_nan()
                        && a.real.to_bits() == b.real.to_bits()
                        && a.imag.to_bits() == b.imag.to_bits())
            }
            (Object::Float(a), Object::Float(b)) => a.to_bits() == b.to_bits(),
            (Object::Str(a), Object::Str(b)) => SharedStr::ptr_eq(a, b),
            (Object::WStr(a), Object::WStr(b)) => SharedSlice::ptr_eq(a, b),
            (Object::Tuple(a), Object::Tuple(b)) => ThinArc::ptr_eq(a, b),
            (Object::List(a), Object::List(b)) => Rc::ptr_eq(a, b),
            (Object::Dict(a), Object::Dict(b)) => Rc::ptr_eq(a, b),
            (Object::Range(a), Object::Range(b)) => Rc::ptr_eq(a, b),
            (Object::Function(a), Object::Function(b)) => Rc::ptr_eq(a, b),
            (Object::Builtin(a), Object::Builtin(b)) => Rc::ptr_eq(a, b),
            (Object::BoundMethod(a), Object::BoundMethod(b)) => Rc::ptr_eq(a, b),
            (Object::Code(a), Object::Code(b)) => Rc::ptr_eq(a, b),
            (Object::Iter(a), Object::Iter(b)) => Rc::ptr_eq(a, b),
            (Object::Slice(a), Object::Slice(b)) => Rc::ptr_eq(a, b),
            (Object::Cell(a), Object::Cell(b)) => Rc::ptr_eq(a, b),
            (Object::Type(a), Object::Type(b)) => Rc::ptr_eq(a, b),
            (Object::Instance(a), Object::Instance(b)) => Rc::ptr_eq(a, b),
            (Object::Module(a), Object::Module(b)) => Rc::ptr_eq(a, b),
            (Object::Generator(a), Object::Generator(b)) => Rc::ptr_eq(a, b),
            (Object::Coroutine(a), Object::Coroutine(b)) => Rc::ptr_eq(a, b),
            (Object::AsyncGenerator(a), Object::AsyncGenerator(b)) => Rc::ptr_eq(a, b),
            (Object::AsyncGenAwait(a), Object::AsyncGenAwait(b)) => Rc::ptr_eq(a, b),
            (Object::Bytes(a), Object::Bytes(b)) => SharedSlice::ptr_eq(a, b),
            (Object::ByteArray(a), Object::ByteArray(b)) => Rc::ptr_eq(a, b),
            (Object::Set(a), Object::Set(b)) => Rc::ptr_eq(a, b),
            (Object::FrozenSet(a), Object::FrozenSet(b)) => Rc::ptr_eq(a, b),
            (Object::File(a), Object::File(b)) => Rc::ptr_eq(a, b),
            (Object::Property(a), Object::Property(b)) => Rc::ptr_eq(a, b),
            (Object::StaticMethod(a), Object::StaticMethod(b)) => Rc::ptr_eq(a, b),
            (Object::ClassMethod(a), Object::ClassMethod(b)) => Rc::ptr_eq(a, b),
            (Object::SlotDescriptor(a), Object::SlotDescriptor(b)) => Rc::ptr_eq(a, b),
            (Object::Frame(a), Object::Frame(b)) => Rc::ptr_eq(a, b),
            (Object::Traceback(a), Object::Traceback(b)) => Rc::ptr_eq(a, b),
            (Object::MemoryView(a), Object::MemoryView(b)) => Rc::ptr_eq(a, b),
            (Object::MappingProxy(a), Object::MappingProxy(b)) => Rc::ptr_eq(a, b),
            (Object::MappingProxyObj(a), Object::MappingProxyObj(b)) => Rc::ptr_eq(a, b),
            (Object::DictView(a), Object::DictView(b)) => Rc::ptr_eq(a, b),
            (Object::SimpleNamespace(a), Object::SimpleNamespace(b)) => Rc::ptr_eq(a, b),
            (Object::LazyIter(a), Object::LazyIter(b)) => Rc::ptr_eq(a, b),
            (Object::Capsule(a), Object::Capsule(b)) => Rc::ptr_eq(a, b),
            // Two foreign proxies are the *same* object iff they wrap the
            // same `PyObject*` (cpyext identity), even across distinct souls.
            (Object::Foreign(a), Object::Foreign(b)) => a.ptr == b.ptr,
            (Object::Unbound, Object::Unbound) => true,
            _ => false,
        }
    }

    /// `==` operator semantics — recursive value equality.
    pub fn eq_value(&self, other: &Self) -> bool {
        // Subclasses of immutable built-ins (`class C(int)`,
        // `enum.IntEnum`, `_NamedIntConstant`, …) compare by the value
        // they wrap, so `C(5) == 5` and two distinct instances with the
        // same value are equal — exactly like CPython.
        let lhs_native = self.native_value();
        let rhs_native = other.native_value();
        if lhs_native.is_some() || rhs_native.is_some() {
            let l = lhs_native.as_ref().unwrap_or(self);
            let r = rhs_native.as_ref().unwrap_or(other);
            return l.eq_value(r);
        }
        match (self, other) {
            (Object::None, Object::None) => true,
            (Object::Bool(a), Object::Bool(b)) => a == b,
            (Object::Int(a), Object::Int(b)) => a == b,
            (Object::Long(a), Object::Long(b)) => **a == **b,
            (Object::Int(a), Object::Long(b)) | (Object::Long(b), Object::Int(a)) => {
                **b == BigInt::from(*a)
            }
            (Object::Bool(a), Object::Int(b)) | (Object::Int(b), Object::Bool(a)) => {
                i64::from(*a) == *b
            }
            (Object::Bool(a), Object::Long(b)) | (Object::Long(b), Object::Bool(a)) => {
                **b == BigInt::from(i64::from(*a))
            }
            (Object::Float(a), Object::Float(b)) => a == b,
            (Object::Int(a), Object::Float(b)) | (Object::Float(b), Object::Int(a)) => {
                i64_eq_f64(*a, *b)
            }
            (Object::Long(a), Object::Float(b)) | (Object::Float(b), Object::Long(a)) => {
                bigint_eq_f64(a, *b)
            }
            (Object::Bool(a), Object::Float(b)) | (Object::Float(b), Object::Bool(a)) => {
                f64::from(i64::from(*a) as i32) == *b
            }
            (Object::Complex(a), Object::Complex(b)) => a.real == b.real && a.imag == b.imag,
            (Object::Complex(c), Object::Int(i)) | (Object::Int(i), Object::Complex(c)) => {
                c.imag == 0.0 && i64_eq_f64(*i, c.real)
            }
            (Object::Complex(c), Object::Float(f)) | (Object::Float(f), Object::Complex(c)) => {
                c.imag == 0.0 && c.real == *f
            }
            (Object::Complex(c), Object::Long(b)) | (Object::Long(b), Object::Complex(c)) => {
                c.imag == 0.0 && bigint_eq_f64(b, c.real)
            }
            // `complex_richcompare` folds bools through the numeric tower:
            // `0j == False` and `1+0j == True` (test_bool `test_complex`).
            (Object::Complex(c), Object::Bool(b)) | (Object::Bool(b), Object::Complex(c)) => {
                c.imag == 0.0 && c.real == f64::from(u8::from(*b))
            }
            (Object::Str(a), Object::Str(b)) => a == b,
            // Two surrogate-bearing strings compare code-point-wise. A `WStr`
            // never equals a plain `Str`: the invariant guarantees a `WStr`
            // holds >= 1 lone surrogate that no UTF-8 `Str` can contain, so the
            // mixed pair correctly falls through to the `_ => false` tail.
            (Object::WStr(a), Object::WStr(b)) => a == b,
            // Sequence comparison is element-wise `PyObject_RichCompareBool`,
            // which is identity-first — so `[nan] == [nan]` (same nan) is true.
            (Object::Tuple(a), Object::Tuple(b)) => {
                a.len() == b.len()
                    && a.iter()
                        .zip(b.iter())
                        .all(|(x, y)| x.is_same(y) || x.eq_value(y))
            }
            (Object::List(a), Object::List(b)) => {
                let a = a.borrow();
                let b = b.borrow();
                a.len() == b.len()
                    && a.iter()
                        .zip(b.iter())
                        .all(|(x, y)| x.is_same(y) || x.eq_value(y))
            }
            (Object::Dict(a), Object::Dict(b)) => {
                let a = a.borrow();
                let b = b.borrow();
                if a.len() != b.len() {
                    return false;
                }
                for (k, v) in a.iter() {
                    match b.get(k) {
                        Some(v2) if v.eq_value(v2) => {}
                        _ => return false,
                    }
                }
                true
            }
            (Object::Bytes(a), Object::Bytes(b)) => a[..] == b[..],
            (Object::ByteArray(a), Object::ByteArray(b)) => *a.borrow() == *b.borrow(),
            (Object::Bytes(a), Object::ByteArray(b)) | (Object::ByteArray(b), Object::Bytes(a)) => {
                a[..] == *b.borrow()
            }
            // Snapshot mutable `set` operands before comparing: the element
            // `__eq__` invoked during the membership probe can re-enter and
            // clear the operand (bpo-46615), and holding a live `borrow()`
            // across that callback would panic with `BorrowMutError`.
            (Object::Set(a), Object::Set(b)) => {
                let (a, b) = (a.borrow().clone(), b.borrow().clone());
                sets_equal(&a, &b)
            }
            (Object::FrozenSet(a), Object::FrozenSet(b)) => sets_equal(a, b),
            (Object::Set(a), Object::FrozenSet(b)) | (Object::FrozenSet(b), Object::Set(a)) => {
                let a = a.borrow().clone();
                sets_equal(&a, b)
            }
            // `memoryview` compares by buffer contents (CPython
            // `memory_richcompare`): structural match on format/itemsize/
            // shape plus byte-identical elements. A released view falls back
            // to object identity, exactly like CPython's `BASE_INACCESSIBLE`.
            (Object::MemoryView(a), Object::MemoryView(b)) => {
                if a.released.get() || b.released.get() {
                    Rc::ptr_eq(a, b)
                } else {
                    a.buffer_eq(b)
                }
            }
            // A released view compares unequal to any buffer (CPython
            // `BASE_INACCESSIBLE` short-circuits to NotEqual).
            (Object::MemoryView(a), Object::Bytes(b))
            | (Object::Bytes(b), Object::MemoryView(a)) => !a.released.get() && a.eq_byte_slice(b),
            (Object::MemoryView(a), Object::ByteArray(b))
            | (Object::ByteArray(b), Object::MemoryView(a)) => {
                !a.released.get() && a.eq_byte_slice(&b.borrow())
            }
            // Any other buffer exporter (`array.array`, a PEP 688
            // `__buffer__` class) compares structurally through its exported
            // view — format/shape plus contents, like CPython's
            // `memory_richcompare` (test_memoryview.test_compare with
            // `array('i', …)`).
            (Object::MemoryView(a), other @ Object::Instance(_))
            | (other @ Object::Instance(_), Object::MemoryView(a)) => {
                if a.released.get() {
                    return false;
                }
                if let Some(b) =
                    crate::builtins::buffer_exported_view(other, crate::builtins::PYBUF_FULL_RO)
                {
                    return a.buffer_eq(&b);
                }
                // A C-extension exporter (`_testbuffer.ndarray`, numpy)
                // crosses as an `Instance` wearing its C class and exports
                // through `bf_getbuffer`, not a PEP 688 `__buffer__` — take
                // its buffer via the C-API bridge and compare values.
                match crate::foreign::get_buffer_obj(other) {
                    Ok(Object::MemoryView(b)) => a.buffer_eq(&b),
                    _ => false,
                }
            }
            // A C-extension exporter (`_testbuffer.ndarray`, numpy):
            // CPython's `memory_richcompare` takes the other operand's
            // buffer and compares element values, so `memoryview == nd`
            // works for any exporter (test_buffer's compare matrix).
            (Object::MemoryView(a), Object::Foreign(soul))
            | (Object::Foreign(soul), Object::MemoryView(a)) => {
                if a.released.get() {
                    return false;
                }
                match crate::foreign::get_buffer(soul) {
                    Ok(Object::MemoryView(b)) => a.buffer_eq(&b),
                    _ => false,
                }
            }
            // `slice` objects compare as the `(start, stop, step)` triple
            // (CPython's `slice_richcompare`), identity-first per field so
            // `slice(None)` fields (NaN-free here, but consistent) match.
            (Object::Slice(a), Object::Slice(b)) => {
                (a.start.is_same(&b.start) || a.start.eq_value(&b.start))
                    && (a.stop.is_same(&b.stop) || a.stop.eq_value(&b.stop))
                    && (a.step.is_same(&b.step) || a.step.eq_value(&b.step))
            }
            // Namespace-shaped values: `types.SimpleNamespace` compares
            // `vars(a) == vars(b)`, and PEP 585 generic aliases (also
            // carried in this representation, keyed by `__origin__` /
            // `__args__` / `__parameters__`) compare those fields — both
            // reduce to dict-content equality (`list[int] == list[int]`).
            (Object::SimpleNamespace(a), Object::SimpleNamespace(b)) => {
                Rc::ptr_eq(a, b) || {
                    let (a, b) = (a.borrow(), b.borrow());
                    a.len() == b.len()
                        && a.iter()
                            .all(|(k, v)| b.get(k).is_some_and(|w| v.is_same(w) || v.eq_value(w)))
                }
            }
            // Reference-identity equality for class / module / function
            // / builtin / method values. CPython falls back to identity
            // here, and our `in` / dict-key checks rely on it.
            (Object::Type(a), Object::Type(b)) => Rc::ptr_eq(a, b),
            (Object::Module(a), Object::Module(b)) => Rc::ptr_eq(a, b),
            (Object::Function(a), Object::Function(b)) => Rc::ptr_eq(a, b),
            (Object::Builtin(a), Object::Builtin(b)) => Rc::ptr_eq(a, b),
            (Object::Instance(a), Object::Instance(b)) => Rc::ptr_eq(a, b),
            // Bound methods compare like CPython's `method_richcompare`:
            // `__func__` by equality, `__self__` by identity. Two freshly
            // bound references to the same method on the same object are
            // therefore equal even though they're distinct allocations.
            (Object::BoundMethod(a), Object::BoundMethod(b)) => {
                let func_eq = match (&a.function, &b.function) {
                    // Built-in methods are materialized fresh on each
                    // attribute access; CPython's `meth_richcompare`
                    // compares the C method def — same receiver + same
                    // name resolves to the same def here.
                    (Object::Builtin(x), Object::Builtin(y)) => {
                        Rc::ptr_eq(x, y) || x.name == y.name
                    }
                    _ => a.function.eq_value(&b.function),
                };
                func_eq && a.receiver.is_same(&b.receiver)
            }
            // `dict_keys` / `dict_items` views are set-like (CPython
            // `dictview_richcompare`): equal when they hold the same set of
            // keys / `(key, value)` pairs, regardless of insertion order or
            // which backing dict they came from.
            (Object::DictView(a), Object::DictView(b)) => {
                Rc::ptr_eq(a, b) || dict_view_set_eq(a, b)
            }
            // `range` compares by the *sequence it generates*, not the raw
            // `(start, stop, step)` triple (CPython `range_equals`): equal
            // iff the lengths match, and — when non-empty — the starts match,
            // and — when length > 1 — the steps match. So `range(0, 3, 2) ==
            // range(0, 4, 2)` (both yield `[0, 2]`) and every empty range
            // compares equal (`range(0) == range(5, 5)`), while `range(3) !=
            // range(4)`. `pandas.RangeIndex.equals` (and thus `DataFrame`
            // round-trip equality) rides on this. Kept bit-for-bit consistent
            // with the `range` hash in `py_hash_value`.
            (Object::Range(a), Object::Range(b)) => {
                if Rc::ptr_eq(a, b) {
                    return true;
                }
                if a.big.is_some() || b.big.is_some() {
                    // Full-width comparison (test_range's `2**200` bounds).
                    let la = range_len_bigint(a);
                    let zero = BigInt::from(0);
                    if la != range_len_bigint(b) {
                        return false;
                    }
                    if la == zero {
                        return true;
                    }
                    let (sa, _, ta) = a.bounds();
                    let (sb, _, tb) = b.bounds();
                    if sa != sb {
                        return false;
                    }
                    return la == BigInt::from(1) || ta == tb;
                }
                let la = range_len_i128(a);
                if la != range_len_i128(b) {
                    false
                } else if la == 0 {
                    true
                } else if a.start != b.start {
                    false
                } else {
                    la == 1 || a.step == b.step
                }
            }
            // Code objects compare *by value* in CPython (`code_richcompare`
            // walks name/bytecode/consts/names/…): `compile(s) ==
            // compile(s)` is True (test_codeop compares `compile_command`
            // output against a fresh `compile`).
            (Object::Code(a), Object::Code(b)) => Rc::ptr_eq(a, b) || code_value_eq(a, b),
            // CPython's default `tp_richcompare` (no user `__eq__`) falls
            // back to *identity*: `x == x` is True and `x == y` is False
            // for distinct objects. This covers reference types without
            // value semantics — frames, generators, tracebacks, cells,
            // … — where `bdb`/`pdb` rely on `frame ==
            // self.returnframe`. Returning a flat `false` here would make
            // even `frame == frame` False.
            _ => self.is_same(other),
        }
    }

    /// Total-order comparison for the (small) set of orderable
    /// types: ints, floats, strings, tuples, lists. Other
    /// combinations return [`Err`] mapping to Python's `TypeError`.
    pub fn cmp(&self, other: &Self) -> Result<Ordering, RuntimeError> {
        use Object as O;
        // Order `int`/`str`/… subclass instances by the value they wrap.
        let lhs_native = self.native_value();
        let rhs_native = other.native_value();
        if lhs_native.is_some() || rhs_native.is_some() {
            let l = lhs_native.as_ref().unwrap_or(self);
            let r = rhs_native.as_ref().unwrap_or(other);
            return l.cmp(r);
        }
        match (self, other) {
            (O::Int(a), O::Int(b)) => Ok(a.cmp(b)),
            (O::Long(a), O::Long(b)) => Ok((**a).cmp(b)),
            (O::Int(a), O::Long(b)) => Ok(BigInt::from(*a).cmp(b)),
            (O::Long(a), O::Int(b)) => Ok((**a).cmp(&BigInt::from(*b))),
            // NaN is unordered: CPython's sort/min/max only ever ask `a < b`,
            // which is False both ways for NaN — observationally `Equal`
            // (stable sort keeps original order, test_sort
            // test_unsafe_tuple_compare).
            (O::Float(a), O::Float(b)) => Ok(a.partial_cmp(b).unwrap_or(Ordering::Equal)),
            (O::Int(a), O::Float(b)) => i64_cmp_f64(*a, *b),
            (O::Float(a), O::Int(b)) => Ok(i64_cmp_f64(*b, *a)?.reverse()),
            (O::Long(a), O::Float(b)) => Ok(bigint_cmp_f64(a, *b)?),
            (O::Float(a), O::Long(b)) => Ok(bigint_cmp_f64(b, *a)?.reverse()),
            (O::Bool(a), O::Bool(b)) => Ok(a.cmp(b)),
            (O::Bool(a), O::Int(b)) => Ok(i64::from(*a).cmp(b)),
            (O::Int(a), O::Bool(b)) => Ok(a.cmp(&i64::from(*b))),
            (O::Bool(a), O::Long(b)) => Ok(BigInt::from(i64::from(*a)).cmp(b)),
            (O::Long(a), O::Bool(b)) => Ok((**a).cmp(&BigInt::from(i64::from(*b)))),
            (O::Bool(a), O::Float(b)) => Ok((i64::from(*a) as f64)
                .partial_cmp(b)
                .unwrap_or(Ordering::Equal)),
            (O::Float(a), O::Bool(b)) => Ok(a
                .partial_cmp(&(i64::from(*b) as f64))
                .unwrap_or(Ordering::Equal)),
            (O::Str(a), O::Str(b)) => Ok(a.cmp(b)),
            // Any comparison involving a surrogate-bearing string orders by
            // code point (CPython compares `str` by code point; UTF-8 byte
            // order already matches that for the pure-`Str` fast path above).
            // A lone surrogate (U+D800..U+DFFF) thus sorts between U+D7FF and
            // U+E000, exactly as in CPython.
            (O::Str(_), O::WStr(_)) | (O::WStr(_), O::Str(_)) | (O::WStr(_), O::WStr(_)) => {
                let a = self.str_codepoints().unwrap();
                let b = other.str_codepoints().unwrap();
                Ok(a.cmp(&b))
            }
            // bytes/bytearray order lexicographically by byte value;
            // the four mixed combinations all compare (CPython's
            // shared `bytes_richcompare` buffer path).
            (O::Bytes(a), O::Bytes(b)) => Ok(a.as_ref().cmp(b.as_ref())),
            (O::Bytes(a), O::ByteArray(b)) => Ok(a.as_ref()[..].cmp(&b.borrow()[..])),
            (O::ByteArray(a), O::Bytes(b)) => Ok(a.borrow()[..].cmp(b.as_ref())),
            (O::ByteArray(a), O::ByteArray(b)) => {
                let bv = b.borrow().clone();
                Ok(a.borrow()[..].cmp(&bv[..]))
            }
            (O::Tuple(a), O::Tuple(b)) => seq_cmp(a, b),
            (O::List(a), O::List(b)) => {
                let a = a.borrow();
                let b = b.borrow();
                seq_cmp(&a, &b)
            }
            _ => {
                if crate::hot_gates::env_flags::cmp_bt() {
                    eprintln!(
                        "[CMP_BT vm-lt] '{}' vs '{}'\n{:?}",
                        self.type_name_owned(),
                        other.type_name_owned(),
                        std::backtrace::Backtrace::force_capture()
                    );
                }
                Err(type_error(format!(
                    "'<' not supported between instances of '{}' and '{}'",
                    self.type_name_owned(),
                    other.type_name_owned()
                )))
            }
        }
    }

    /// Membership: `x in container`.
    pub fn contains(&self, item: &Self) -> Result<bool, RuntimeError> {
        match self {
            // CPython's `PyObject_RichCompareBool` short-circuits on identity
            // before `==` (so `nan in [nan]` for the same nan is `True`) and
            // otherwise dispatches Python `__eq__` (both directions),
            // propagating any exception it raises.
            Object::Tuple(items) => {
                for x in items.iter() {
                    if member_eq(x, item)? {
                        return Ok(true);
                    }
                }
                Ok(false)
            }
            Object::List(items) => {
                // Snapshot strong refs: a user `__eq__` may mutate this list
                // mid-scan (CPython re-checks bounds each step), so we must
                // not hold the borrow across the comparison.
                let snapshot = items.borrow().clone();
                for x in &snapshot {
                    if member_eq(x, item)? {
                        return Ok(true);
                    }
                }
                Ok(false)
            }
            Object::Str(haystack) => match item {
                Object::Str(needle) => Ok(haystack.contains(&**needle)),
                // `"..." in wstr`: a surrogate-bearing needle can never be a
                // substring of a pure-UTF-8 haystack, so this is always false.
                Object::WStr(_) => Ok(false),
                _ => Err(type_error(
                    "'in <string>' requires string as left operand".to_owned(),
                )),
            },
            // Substring search over a surrogate-bearing haystack works on code
            // points so a lone surrogate matches itself.
            Object::WStr(_) => match item {
                Object::Str(_) | Object::WStr(_) => {
                    let hay = self.str_codepoints().unwrap();
                    let needle = item.str_codepoints().unwrap();
                    Ok(codepoint_subslice_contains(&hay, &needle))
                }
                _ => Err(type_error(
                    "'in <string>' requires string as left operand".to_owned(),
                )),
            },
            Object::Dict(d) => {
                // `unhashable in {…}` raises TypeError, exactly like a
                // direct `d[unhashable]` lookup (CPython `PyDict_Contains`).
                crate::builtins::ensure_dict_key(item)?;
                if dict_key_is_reentrant(item) {
                    // A key with user `__eq__` compares through Python (which
                    // may raise, or mutate `d` mid-probe — gh-140551).
                    return Ok(dict_reentrant_find(d, item)?.is_some());
                }
                let (hit, deferred) = with_key_eq_deferred(|| {
                    key_cmp_scope(|| d.borrow().contains_key(&DictKey(item.clone())))
                });
                let hit = hit?;
                if hit {
                    return Ok(true);
                }
                if deferred {
                    // A *stored* key needed a Python comparison (bpo-40489:
                    // `'test' in d` hitting a `str` subclass whose `__eq__`
                    // clears `d`); retry borrow-free.
                    return Ok(dict_reentrant_find(d, item)?.is_some());
                }
                Ok(false)
            }
            // Set membership retries an unhashable `set` operand as a
            // frozenset (CPython `set_lookkey`); a `list`/etc. still raises.
            Object::Set(s) => {
                let key = crate::builtins::set_membership_key(item)?;
                // A custom `__eq__` raising during a hash collision aborts the
                // lookup in CPython (test_badcmp `s.__contains__(BadCmp())`).
                key_cmp_scope(|| {
                    force_hash_for_tiny_table(s.borrow().len(), &key.0);
                    s.borrow().contains(&key)
                })
            }
            Object::FrozenSet(s) => {
                let key = crate::builtins::set_membership_key(item)?;
                key_cmp_scope(|| {
                    force_hash_for_tiny_table(s.len(), &key.0);
                    s.contains(&key)
                })
            }
            Object::Bytes(haystack) => bytes_membership(haystack, item),
            Object::ByteArray(haystack) => {
                // Hold a buffer export: converting `item` can reenter
                // Python (a user `__index__`/`__buffer__`) that tries to
                // resize this bytearray; the resize then raises
                // BufferError at the mutation site (gh-142560).
                let _guard = ByteArrayExportGuard::new(haystack.clone());
                let hay: Vec<u8> = haystack.borrow().clone();
                bytes_membership(&hay, item)
            }
            Object::Range(r) => {
                use num_traits::ToPrimitive;
                let big_item: Option<BigInt> = match item {
                    Object::Bool(b) => Some(BigInt::from(i64::from(*b))),
                    Object::Int(i) => Some(BigInt::from(*i)),
                    Object::Long(b) => Some((**b).clone()),
                    _ => None,
                };
                if r.big.is_some() {
                    if let Some(i) = big_item.clone() {
                        let (start, stop, step) = r.bounds();
                        let zero = BigInt::from(0);
                        return if step > zero {
                            Ok(i >= start && i < stop && (i - start) % step == zero)
                        } else if step < zero {
                            Ok(i <= start && i > stop && (start - i) % (-step) == zero)
                        } else {
                            Ok(false)
                        };
                    }
                }
                let i: Option<i128> = match item {
                    Object::Bool(b) => Some(i128::from(*b)),
                    Object::Int(i) => Some(i128::from(*i)),
                    Object::Long(b) => b.to_i128(),
                    _ => None,
                };
                // A `Long` outside i128 can't be a member of a non-big
                // range... unless the fallthrough below finds it via `==`
                // scan — but a pure-int probe is exactly CPython's
                // arithmetic fast path, so answer directly.
                if big_item.is_some() && i.is_none() && r.big.is_none() {
                    return Ok(false);
                }
                if let Some(i) = i {
                    if r.step > 0 {
                        Ok(i >= r.start && i < r.stop && (i - r.start) % r.step == 0)
                    } else if r.step < 0 {
                        Ok(i <= r.start && i > r.stop && (r.start - i) % (-r.step) == 0)
                    } else {
                        Ok(false)
                    }
                } else {
                    // CPython's `range_contains` fast-paths only exact
                    // ints/bools; every other type falls back to
                    // `_PySequence_IterSearch`, so `5.0 in range(10)` and an
                    // always-equal object are found through per-element `==`
                    // (test_range.test_contains / test_types).
                    let mut cur = r.start;
                    while (r.step > 0 && cur < r.stop) || (r.step < 0 && cur > r.stop) {
                        if member_eq(&int_from_i128(cur), item)? {
                            return Ok(true);
                        }
                        cur += r.step;
                    }
                    Ok(false)
                }
            }
            Object::MappingProxy(d) => Ok(d.borrow().contains_key(&DictKey(item.clone()))),
            // Static fallback; the VM's `in` dispatch delegates to the
            // wrapped mapping's own `__contains__` first.
            Object::MappingProxyObj(inner) => inner.contains(item),
            // View membership matches the dict's own: user `__hash__`/
            // `__eq__` dispatch through Python and their exceptions
            // propagate (test_dictviews.test_compare_error).
            Object::DictView(v) => match v.kind {
                DictViewKind::Keys => Object::Dict(v.dict.clone()).contains(item),
                DictViewKind::Values => {
                    let snapshot: Vec<Object> = v.dict.borrow().values().cloned().collect();
                    for x in &snapshot {
                        if member_eq(x, item)? {
                            return Ok(true);
                        }
                    }
                    Ok(false)
                }
                DictViewKind::Items => {
                    if let Object::Tuple(t) = item {
                        if t.len() == 2 {
                            if let Some(stored) = crate::builtins::dict_lookup(&v.dict, &t[0])? {
                                return member_eq(&stored, &t[1]);
                            }
                            return Ok(false);
                        }
                    }
                    Ok(false)
                }
            },
            // CPython has no `sq_contains` for memoryview, so `x in m` walks
            // the sequence protocol: released views raise ValueError, 0-dim
            // TypeError, deeper views NotImplementedError, and a 1-D view
            // compares its unpacked elements by value (`1.0 in m` works for
            // a float view — test_buffer.test_memoryview_sequence).
            Object::MemoryView(mv) => {
                if mv.released.get() {
                    return Err(crate::value_error(
                        "operation forbidden on released memoryview object",
                    ));
                }
                let elems = crate::mv_element_objects(mv)?;
                for x in &elems {
                    if member_eq(x, item)? {
                        return Ok(true);
                    }
                }
                Ok(false)
            }
            // A built-in-subclass instance (`class C(dict)`, …) contains
            // through its wrapped native payload — the receiver-side
            // analogue of CPython dispatching `sq_contains` on the base.
            Object::Instance(inst) => match inst.native.get() {
                Some(native) => native.contains(item),
                None => Err(type_error(format!(
                    "argument of type '{}' is not a container or iterable",
                    self.type_name()
                ))),
            },
            _ => Err(type_error(format!(
                "argument of type '{}' is not a container or iterable",
                self.type_name()
            ))),
        }
    }

    /// Make an iterator over `self`. The returned [`PyIterator`]
    /// drains the source on each `next_value` call.
    pub fn make_iter(&self) -> Result<PyIterator, RuntimeError> {
        match self {
            Object::List(items) => Ok(PyIterator::List {
                items: items.clone(),
                index: 0,
                owner: None,
            }),
            Object::Tuple(items) => Ok(PyIterator::Tuple {
                items: items.clone(),
                index: 0,
            }),
            Object::Str(s) => Ok(PyIterator::Str {
                s: s.clone(),
                index: 0,
            }),
            // Iterating a surrogate-bearing string yields one length-1 string
            // per code point (a lone surrogate becomes a length-1 `WStr`).
            Object::WStr(cps) => Ok(PyIterator::List {
                items: Rc::new(RefCell::new(
                    cps.iter()
                        .map(|&c| Object::str_from_codepoints(vec![c]))
                        .collect(),
                )),
                index: 0,
                owner: None,
            }),
            Object::Range(r) => Ok({
                if let Some(b) = &r.big {
                    // CPython's `longrange_iterator`: bounds past i128.
                    PyIterator::RangeBig {
                        current: Box::new(b.0.clone()),
                        stop: Box::new(b.1.clone()),
                        step: Box::new(b.2.clone()),
                    }
                } else {
                    match (
                        i64::try_from(r.start),
                        i64::try_from(r.stop),
                        i64::try_from(r.step),
                    ) {
                        // `current += step` must not overflow after the last
                        // yielded element (current peaks at stop-1+step for
                        // positive step, bottoms at stop+1+step for negative),
                        // so boundary-hugging ranges take the i128 variant too.
                        (Ok(current), Ok(stop), Ok(step)) if stop.checked_add(step).is_some() => {
                            PyIterator::Range {
                                current,
                                stop,
                                step,
                            }
                        }
                        _ => PyIterator::RangeHuge {
                            current: r.start,
                            stop: r.stop,
                            step: r.step,
                        },
                    }
                }
            }),
            Object::Dict(d) => {
                let len = d.borrow().len();
                Ok(PyIterator::DictKeys {
                    kind: DictViewKind::Keys,
                    index: 0,
                    dict: Some(d.clone()),
                    len,
                    watch: None,
                    reverse: false,
                    owner: None,
                })
            }
            Object::Set(s) => {
                // A *live* iterator (not a snapshot): keep the set alive for
                // the cycle GC to trace and detect size changes mid-iteration.
                Ok(PyIterator::Set {
                    set: s.clone(),
                    index: 0,
                    len: s.borrow().len(),
                })
            }
            Object::FrozenSet(s) => {
                let items: Vec<Object> = s.iter().map(|k| k.0.clone()).collect();
                Ok(PyIterator::List {
                    items: Rc::new(RefCell::new(items)),
                    index: 0,
                    owner: None,
                })
            }
            Object::Bytes(b) => Ok(PyIterator::Bytes {
                data: b.clone(),
                index: 0,
            }),
            Object::ByteArray(b) => Ok(PyIterator::ByteArray {
                data: b.clone(),
                index: 0,
            }),
            Object::MemoryView(mv) => {
                if mv.released.get() {
                    return Err(value_error("memoryview: released"));
                }
                // CPython's `memoryiter` yields *format-unpacked elements*
                // (an `int64` exporter iterates as Python ints, `'d'` as
                // floats), not raw bytes — pandas' `Index(memoryview(arr))`
                // takes `list(data)` and depends on it. Multi-dimensional
                // iteration would yield sub-views; CPython raises
                // NotImplementedError there and so do we.
                let shape = mv.shape_dims();
                if shape.len() > 1 {
                    return Err(crate::error::not_implemented_error(
                        "multi-dimensional sub-views are not implemented",
                    ));
                }
                let items = crate::mv_element_objects(mv)?;
                Ok(PyIterator::List {
                    items: Rc::new(RefCell::new(items)),
                    index: 0,
                    owner: None,
                })
            }
            Object::DictView(v) => {
                // All three view kinds iterate through the same guarded
                // live cursor so a mid-loop structural mutation of the
                // source dict raises RuntimeError from any of them
                // (CPython's `dictiter_iternextvalue`/`iternextitem`
                // share the key-iterator's trip-wires).
                let len = v.dict.borrow().len();
                Ok(PyIterator::DictKeys {
                    kind: v.kind,
                    index: 0,
                    dict: Some(v.dict.clone()),
                    len,
                    watch: None,
                    reverse: false,
                    owner: v.owner.clone(),
                })
            }
            Object::MappingProxy(d) => {
                let len = d.borrow().len();
                Ok(PyIterator::DictKeys {
                    kind: DictViewKind::Keys,
                    index: 0,
                    dict: Some(d.clone()),
                    len,
                    watch: None,
                    reverse: false,
                    owner: None,
                })
            }
            // Static fallback; the VM's iteration dispatch delegates to
            // the wrapped mapping's own `__iter__` first.
            Object::MappingProxyObj(inner) => inner.make_iter(),
            Object::File(file) => {
                // CPython's file object is its own iterator: each step calls
                // ``readline`` and yields the line, raising StopIteration at
                // EOF. We stream lazily (one line per `next`) rather than
                // draining up front — eager draining would block on pipes /
                // `sys.stdin` until EOF and breaks binary-mode files, which
                // must yield ``bytes`` lines.
                Ok(PyIterator::File { file: file.clone() })
            }
            // A native iterator is its own iterable: `iter(it) is it` in
            // Python, and passing one to a plain builtin (`zip`,
            // `dict.fromkeys`, `set`, …) must drain *the same cursor* —
            // partial consumption (`zip(range(n), it)`) must leave `it`
            // positioned at the first unconsumed element.
            Object::Iter(it) => Ok(PyIterator::Shared(it.clone())),
            // Iterables the object-level factory can't build a `PyIterator`
            // for on its own — they need the running interpreter to drive
            // their `__iter__`/`__next__` (or `tp_iter`/`tp_iternext`):
            //   * `Instance`  — a user/extension class (incl. a bridged
            //     Cython generator or generator-expression, which crosses
            //     into the VM as an `Instance` of its bridged type).
            //   * `Foreign`   — an opaque C object (numpy array iterator,
            //     any C `tp_iter` type).
            //   * `Generator` / `Coroutine` — VM generators driven by
            //     `send`.
            // A builtin invoked from C reaches here (Cython compiles
            // `sum(stop - start for start, stop in slices)` in pandas'
            // `get_blkno_indexers`, reached by `merge`/`reindex`/`drop`, to
            // a C `sum()` over a generator object). Drive it through the
            // active interpreter's iterator protocol and materialise the
            // elements — every builtin routed here (`sum`/`min`/`max`/
            // `sorted`/`list`/`tuple`/`any`/`all`/…) consumes the iterable
            // in full, so eager collection matches their semantics.
            Object::Instance(_)
            | Object::Foreign(_)
            | Object::Generator(_)
            | Object::Coroutine(_) => {
                let ptr = crate::vm_singletons::current_interpreter_ptr().ok_or_else(|| {
                    type_error(format!(
                        "'{}' object is not iterable",
                        self.type_name_owned()
                    ))
                })?;
                // SAFETY: published by the enclosing VM frame still live on
                // this thread; the GIL keeps the access exclusive. Same
                // reentrant-callback pattern as `current_interp_eq` above.
                let interp = unsafe { &mut *ptr };
                let iter = interp.iter_object(self.clone())?;
                let mut items = Vec::new();
                while let Some(v) = interp.iter_next_object(iter.clone())? {
                    items.push(v);
                }
                Ok(PyIterator::List {
                    items: Rc::new(RefCell::new(items)),
                    index: 0,
                    owner: None,
                })
            }
            _ => Err(type_error(format!(
                "'{}' object is not iterable",
                self.type_name_owned()
            ))),
        }
    }

    pub fn type_name(&self) -> &'static str {
        match self {
            Object::None => "NoneType",
            Object::Unbound => "NoneType",
            Object::Bool(_) => "bool",
            Object::Int(_) => "int",
            Object::Long(_) => "int",
            Object::Complex(_) => "complex",
            Object::Float(_) => "float",
            Object::Str(_) => "str",
            // A surrogate-bearing string is still a `str` to Python.
            Object::WStr(_) => "str",
            Object::Tuple(_) => "tuple",
            Object::List(_) => "list",
            Object::Dict(_) => "dict",
            Object::Range(_) => "range",
            Object::Function(_) => "function",
            Object::Builtin(_) => "builtin_function_or_method",
            Object::BoundMethod(_) => "method",
            Object::Code(_) => "code",
            // `enumerate` / `reversed` objects are instances of their own
            // real types in CPython; anything else reports the generic
            // iterator name (`try_borrow` in case the cursor is mid-step).
            Object::Iter(it) => match it.try_borrow().as_deref() {
                Ok(PyIterator::Enumerate { .. }) => "enumerate",
                Ok(PyIterator::Reversed { .. }) => "reversed",
                _ => "iterator",
            },
            Object::Slice(_) => "slice",
            Object::Cell(_) => "cell",
            Object::Type(_) => "type",
            // For Instance we'd ideally return the class name, but
            // type_name returns &'static; callers that need the real
            // name use Object::type_name_owned below.
            Object::Instance(_) => "object",
            Object::Module(_) => "module",
            Object::Generator(_) => "generator",
            Object::Coroutine(_) => "coroutine",
            Object::AsyncGenerator(_) => "async_generator",
            Object::AsyncGenAwait(a) => a.kind.type_name(),
            Object::Bytes(_) => "bytes",
            Object::ByteArray(_) => "bytearray",
            Object::Set(_) => "set",
            Object::FrozenSet(_) => "frozenset",
            Object::File(_) => "file",
            Object::Property(_) => "property",
            Object::StaticMethod(_) => "staticmethod",
            Object::ClassMethod(_) => "classmethod",
            Object::SlotDescriptor(_) => "member_descriptor",
            Object::Frame(_) => "frame",
            Object::Traceback(_) => "traceback",
            Object::MemoryView(_) => "memoryview",
            Object::MappingProxy(_) | Object::MappingProxyObj(_) => "mappingproxy",
            Object::DictView(v) => v.kind.type_name(),
            Object::SimpleNamespace(_) => "SimpleNamespace",
            Object::LazyIter(l) => l.type_name(),
            Object::Capsule(_) => "PyCapsule",
            // The real (dynamic) `tp_name` is only available via
            // type_name_owned; this static placeholder mirrors Instance.
            Object::Foreign(_) => "object",
        }
    }

    /// Like [`type_name`], but returns the user-class name for
    /// `Object::Instance` instead of the static placeholder.
    /// CPython's `%T` format unit: `type(obj).__module__.__qualname__`
    /// with the `builtins` prefix dropped (`test.test_str.PseudoFloat`,
    /// `float`). Built-in and bridged types fall back to
    /// [`Self::type_name_owned`].
    pub fn type_name_fq(&self) -> String {
        if let Object::Instance(inst) = self {
            let cls = inst.cls();
            if cls.c_tp_name.get().is_none() {
                return cls.qualified_display_name();
            }
        }
        self.type_name_owned()
    }

    pub fn type_name_owned(&self) -> String {
        match self {
            // A bridged extension class renders its C `tp_name`
            // (`'numpy.ndarray'`), exactly as CPython's `tp_name`-based
            // `TypeError` text does; pure-Python classes keep the bare name.
            Object::Instance(inst) => {
                let cls = inst.cls();
                match cls.c_tp_name.get() {
                    Some(full) => full.to_owned(),
                    None => cls.name.clone(),
                }
            }
            // `type_name_owned` is `type(obj).__name__`. For a *class* object
            // that is its metaclass (`type` for a plain class, `ABCMeta`/an
            // `EnumMeta`, … otherwise) — never a `type[<name>]` alias. CPython's
            // error text ("'<' not supported between instances of 'type' and
            // 'type'", which pandas' groupby idxmax/idxmin over an object column
            // matches on) depends on this being the bare metaclass name.
            Object::Type(t) => t
                .metaclass
                .try_borrow()
                .ok()
                .and_then(|m| m.as_ref().map(|mc| mc.name.clone()))
                .unwrap_or_else(|| "type".to_string()),
            // `type_name_owned` feeds CPython-style `TypeError` text, which
            // uses the raw `tp_name` (`'numpy.float64'`,
            // `'pandas._libs.tslibs.offsets.Nano'`) — not the bare `__name__`.
            Object::Foreign(s) => s.tp_name.to_string(),
            other => other.type_name().to_owned(),
        }
    }

    /// Python `repr()` — produces a string that, when fed back, would
    /// round-trip to the same value for the basic types we support.
    pub fn repr(&self) -> String {
        match self {
            Object::None => "None".to_owned(),
            Object::Unbound => "<unbound>".to_owned(),
            Object::Bool(b) => if *b { "True" } else { "False" }.to_owned(),
            Object::Int(i) => i.to_string(),
            Object::Long(b) => b.to_string(),
            Object::Complex(c) => complex_repr(c.real, c.imag),
            Object::Float(f) => float_repr(*f),
            Object::Str(s) => {
                // CPython quote selection (Objects/unicodeobject.c
                // `unicode_repr`): use '\'' unless the string contains a
                // single quote and no double quote, in which case use '"'
                // so the single quotes need not be escaped.
                let has_single = s.contains('\'');
                let has_double = s.contains('"');
                let quote = if has_single && !has_double { '"' } else { '\'' };
                let mut out = String::with_capacity(s.len() + 2);
                out.push(quote);
                for c in s.chars() {
                    match c {
                        '\\' => out.push_str("\\\\"),
                        '\n' => out.push_str("\\n"),
                        '\r' => out.push_str("\\r"),
                        '\t' => out.push_str("\\t"),
                        c if c == quote => {
                            out.push('\\');
                            out.push(quote);
                        }
                        c if char_is_printable(c) => out.push(c),
                        // Non-printable code points are escaped the way
                        // CPython's `unicode_repr` does: \xNN, \uNNNN or
                        // \UNNNNNNNN depending on the code-point width.
                        c => {
                            let n = c as u32;
                            if n <= 0xff {
                                out.push_str(&format!("\\x{n:02x}"));
                            } else if n <= 0xffff {
                                out.push_str(&format!("\\u{n:04x}"));
                            } else {
                                out.push_str(&format!("\\U{n:08x}"));
                            }
                        }
                    }
                }
                out.push(quote);
                out
            }
            Object::WStr(cps) => {
                // Same algorithm as the `Str` arm, but over raw code points so
                // lone surrogates (which cannot be a Rust `char`) round-trip as
                // `\udXXX`. CPython's `unicode_repr` shows lone surrogates with
                // the same `\uXXXX` escape used for any non-printable BMP point.
                let has_single = cps.contains(&0x27);
                let has_double = cps.contains(&0x22);
                let quote: char = if has_single && !has_double { '"' } else { '\'' };
                let quote_cp = quote as u32;
                let mut out = String::with_capacity(cps.len() + 2);
                out.push(quote);
                for &n in cps.iter() {
                    match char::from_u32(n) {
                        Some('\\') => out.push_str("\\\\"),
                        Some('\n') => out.push_str("\\n"),
                        Some('\r') => out.push_str("\\r"),
                        Some('\t') => out.push_str("\\t"),
                        _ if n == quote_cp => {
                            out.push('\\');
                            out.push(quote);
                        }
                        Some(c) if char_is_printable(c) => out.push(c),
                        // Both lone surrogates (`from_u32` == None) and
                        // non-printable scalars escape by code-point width.
                        _ => {
                            if n <= 0xff {
                                out.push_str(&format!("\\x{n:02x}"));
                            } else if n <= 0xffff {
                                out.push_str(&format!("\\u{n:04x}"));
                            } else {
                                out.push_str(&format!("\\U{n:08x}"));
                            }
                        }
                    }
                }
                out.push(quote);
                out
            }
            Object::Tuple(items) => {
                let id = ThinArc::as_ptr(items).cast::<()>() as usize;
                if !repr_enter(id) {
                    return "(...)".to_owned();
                }
                let mut s = String::from("(");
                for (i, x) in items.iter().enumerate() {
                    if i > 0 {
                        s.push_str(", ");
                    }
                    s.push_str(&x.repr());
                }
                if items.len() == 1 {
                    s.push(',');
                }
                s.push(')');
                repr_leave();
                s
            }
            Object::List(items) => {
                let id = Rc::as_ptr(items).cast::<()>() as usize;
                if !repr_enter(id) {
                    return "[...]".to_owned();
                }
                // Index with a fresh length check each step, cloning the
                // element and releasing the borrow *before* rendering it:
                // an element's `__repr__` may mutate this very list
                // (test_list.test_repr_mutate pops it), which CPython's
                // index-based `list_repr` tolerates — holding the borrow
                // across the call would instead panic the cell.
                let mut s = String::from("[");
                let mut i = 0usize;
                loop {
                    let x = {
                        let borrowed = items.borrow();
                        if i >= borrowed.len() {
                            break;
                        }
                        borrowed[i].clone()
                    };
                    if i > 0 {
                        s.push_str(", ");
                    }
                    s.push_str(&x.repr());
                    i += 1;
                }
                s.push(']');
                repr_leave();
                s
            }
            Object::Dict(d) => {
                let id = Rc::as_ptr(d).cast::<()>() as usize;
                if !repr_enter(id) {
                    return "{...}".to_owned();
                }
                // Snapshot the entries so a key/value `__repr__` that mutates
                // this dict can't panic the borrowed cell mid-render.
                let pairs: Vec<(Object, Object)> = {
                    let borrowed = d.borrow();
                    borrowed
                        .iter()
                        .map(|(k, v)| (k.0.clone(), v.clone()))
                        .collect()
                };
                let mut s = String::from("{");
                for (i, (k, v)) in pairs.iter().enumerate() {
                    if i > 0 {
                        s.push_str(", ");
                    }
                    s.push_str(&k.repr());
                    s.push_str(": ");
                    s.push_str(&v.repr());
                }
                s.push('}');
                repr_leave();
                s
            }
            Object::Range(r) => {
                let (start, stop, step) = r.bounds();
                if step == BigInt::from(1) {
                    format!("range({start}, {stop})")
                } else {
                    format!("range({start}, {stop}, {step})")
                }
            }
            Object::Function(f) => {
                // CPython shows the *qualname* (with any user override
                // via `f.__qualname__ = …` taking priority).
                let qual = f
                    .slot("__qualname__")
                    .as_ref()
                    .map(Object::to_str)
                    .unwrap_or_else(|| f.code().qualname.clone());
                format!("<function {} at 0x{:x}>", qual, Rc::as_ptr(f) as usize)
            }
            Object::Builtin(b) => {
                // A registered descriptor reprs per its CPython kind
                // (test_reprlib.test_descriptors): `dict.items` is
                // `<method 'items' of 'dict' objects>`, `int.__add__` a
                // slot wrapper, and so on. Untagged builtins (and
                // staticmethod-wrapped C functions, whose type stays
                // `builtin_function_or_method`) keep the plain form.
                use crate::descr_registry::DescrKind;
                match crate::descr_registry::lookup(self) {
                    Some(meta) => match meta.kind {
                        DescrKind::Method => format!(
                            "<method '{}' of '{}' objects>",
                            meta.name, meta.objclass.name
                        ),
                        DescrKind::Wrapper => format!(
                            "<slot wrapper '{}' of '{}' objects>",
                            meta.name, meta.objclass.name
                        ),
                        DescrKind::GetSet => format!(
                            "<attribute '{}' of '{}' objects>",
                            meta.name, meta.objclass.name
                        ),
                        DescrKind::Member => format!(
                            "<member '{}' of '{}' objects>",
                            meta.name, meta.objclass.name
                        ),
                        DescrKind::StaticBuiltin => {
                            format!("<built-in function {}>", b.name)
                        }
                    },
                    None => format!("<built-in function {}>", b.name),
                }
            }
            // CPython `method_repr`: `<bound method qualname of repr(self)>`.
            // The name is `func.__qualname__` then `func.__name__`, and
            // finally `?` when the wrapped callable carries neither — e.g.
            // a `types.MethodType` bound over an arbitrary callable object.
            Object::BoundMethod(bm) => {
                let qual = match &bm.function {
                    Object::Function(f) => f
                        .slot("__qualname__")
                        .as_ref()
                        .map(Object::to_str)
                        .unwrap_or_else(|| f.code().qualname.clone()),
                    // A C function bound to its receiver is CPython's
                    // `builtin_function_or_method`, whose repr is
                    // `<built-in method split of str object at 0x…>`
                    // (test_reprlib.test_builtin_function).
                    Object::Builtin(b) => {
                        return format!(
                            "<built-in method {} of {} object at 0x{:x}>",
                            b.name,
                            bm.receiver.type_name(),
                            crate::builtins::object_identity(&bm.receiver)
                        )
                    }
                    Object::Instance(i) => {
                        let pick = |key: &str| -> Option<String> {
                            if let Some(Object::Str(s)) =
                                i.dict.borrow().get(&crate::object::StrKey(key))
                            {
                                return Some(s.to_string());
                            }
                            match i.cls().lookup(key) {
                                Some(Object::Str(s)) => Some(s.to_string()),
                                _ => None,
                            }
                        };
                        pick("__qualname__")
                            .or_else(|| pick("__name__"))
                            .unwrap_or_else(|| "?".to_owned())
                    }
                    other => other.repr(),
                };
                format!("<bound method {} of {}>", qual, bm.receiver.repr())
            }
            // CPython `code_repr`: name, heap address, filename, and the
            // first line (test_dis normalizes the address but asserts the
            // file/line tail verbatim).
            Object::Code(c) => {
                let firstlineno = if c.name == "<module>" {
                    1
                } else {
                    c.linetable.iter().copied().find(|l| *l > 0).unwrap_or(1)
                };
                format!(
                    "<code object {} at 0x{:012x}, file \"{}\", line {}>",
                    c.name,
                    Rc::as_ptr(c) as usize,
                    c.filename,
                    firstlineno
                )
            }
            Object::Iter(_) => "<iterator>".to_owned(),
            Object::Slice(s) => format!(
                "slice({}, {}, {})",
                s.start.repr(),
                s.stop.repr(),
                s.step.repr()
            ),
            // CPython `cell_repr`: address of the cell plus the type and
            // address of its referent (or "empty" for an unbound cell).
            Object::Cell(inner) => {
                let addr = crate::sync::Rc::as_ptr(inner) as usize;
                let v = inner.borrow();
                match &*v {
                    Object::Unbound => format!("<cell at 0x{addr:x}: empty>"),
                    other => format!(
                        "<cell at 0x{:x}: {} object at 0x{:x}>",
                        addr,
                        other.type_name(),
                        crate::builtins::object_identity(other)
                    ),
                }
            }
            Object::Type(t) => format!("<class '{}'>", t.qualified_display_name()),
            Object::Module(m) => match &m.filename {
                // A module whose only identity is the `<frozen name>`
                // pseudo-filename reprs as CPython's FrozenImporter
                // modules do (`_module_repr_from_spec` with
                // origin='frozen' and no location): `<module 'x'
                // (frozen)>`, not `from '<frozen x>'`.
                Some(path) if *path == format!("<frozen {}>", m.name) => {
                    format!("<module '{}' (frozen)>", m.name)
                }
                Some(path) => format!("<module '{}' from '{}'>", m.name, path),
                None => format!("<module '{}' (built-in)>", m.name),
            },
            // CPython's repr shows the qualified name (PEP 3155).
            Object::Generator(g) => format!(
                "<generator object {} at 0x{:x}>",
                g.qualname.borrow().to_str(),
                Rc::as_ptr(g) as usize
            ),
            Object::Coroutine(g) => format!(
                "<coroutine object {} at 0x{:x}>",
                g.qualname.borrow().to_str(),
                Rc::as_ptr(g) as usize
            ),
            Object::AsyncGenerator(g) => format!(
                "<async_generator object {} at 0x{:x}>",
                g.qualname.borrow().to_str(),
                Rc::as_ptr(g) as usize
            ),
            Object::AsyncGenAwait(a) => format!(
                "<{} object at 0x{:x}>",
                a.kind.type_name(),
                Rc::as_ptr(a) as usize
            ),
            Object::Bytes(b) => bytes_repr(b),
            Object::ByteArray(b) => {
                format!("bytearray({})", bytes_repr_inner(&b.borrow(), false))
            }
            Object::Set(s) => set_repr(
                &set_items(&s.borrow()),
                "set",
                Rc::as_ptr(s).cast::<()>() as usize,
            ),
            Object::FrozenSet(s) => set_repr(
                &set_items(s),
                "frozenset",
                Rc::as_ptr(s).cast::<()>() as usize,
            ),
            Object::File(file) => {
                // Faithful CPython `tp_repr` per io layer (`IoKind`):
                //   BytesIO/StringIO  -> `<_io.BytesIO object at 0x..>` (no name)
                //   FileIO            -> `<_io.FileIO name=.. mode='rb' closefd=True>`
                //   Buffered*         -> `<_io.BufferedReader name=..>`
                //   TextIOWrapper     -> `<_io.TextIOWrapper name=.. mode='r' encoding='..'>`
                // The name is formatted with `repr` (`%R`): an fd is an
                // unquoted int (`name=6`), a path a quoted str (`name='f'`).
                // Shared with the `Drop` unclosed-file `ResourceWarning`.
                file.repr_with_addr(Rc::as_ptr(file) as usize)
            }
            Object::Instance(inst) => {
                // The `Ellipsis` / `NotImplemented` singletons render as
                // fixed text — CPython's `ellipsis`/`NotImplementedType`
                // `tp_repr`. We supply it here, keyed on the registry type
                // identity, rather than via a `__repr__` dict entry that
                // would otherwise leak into `dir()` (test_descr test_dir
                // requires `dir(Ellipsis) == dir(object())`).
                {
                    let cls = inst.cls();
                    if cls.name == "ellipsis" || cls.name == "NotImplementedType" {
                        let bt = crate::builtin_types::builtin_types();
                        if Rc::ptr_eq(&cls, &bt.ellipsis_) {
                            return "Ellipsis".to_owned();
                        }
                        if Rc::ptr_eq(&cls, &bt.not_implemented_type_) {
                            return "NotImplemented".to_owned();
                        }
                    }
                }
                // A subclass of `set`/`frozenset` that doesn't override
                // `__repr__` renders with its *own* type name —
                // `set2({7})`, not `{7}` — exactly like CPython's
                // `set_repr` (`Py_TYPE(so) != &PySet_Type`). The native
                // payload carries the elements; the class name comes from
                // the instance's type.
                if let Some(native_set @ (Object::Set(_) | Object::FrozenSet(_))) =
                    inst.native.get()
                {
                    let repr_key = DictKey(Object::from_static("__repr__"));
                    let bt = crate::builtin_types::builtin_types();
                    // CPython's `set_repr` keys off `Py_TYPE(so) != &PySet_Type`,
                    // so a bare subclass renders as `set2({7})`. A *user* override
                    // anywhere below the builtin `set`/`frozenset` (object's
                    // inherited slot doesn't count) takes precedence and is run
                    // through the normal re-dispatch path below.
                    let has_user_repr = inst.cls().mro.borrow().iter().any(|t| {
                        !Rc::ptr_eq(t, &bt.set_)
                            && !Rc::ptr_eq(t, &bt.frozenset_)
                            && !Rc::ptr_eq(t, &bt.object_)
                            && t.dict.borrow().contains_key(&repr_key)
                    });
                    if !has_user_repr {
                        let name = inst.cls().name.clone();
                        let short = name.rsplit('.').next().unwrap_or(&name);
                        return match native_set {
                            Object::Set(s) => set_repr(
                                &set_items(&s.borrow()),
                                short,
                                Rc::as_ptr(s).cast::<()>() as usize,
                            ),
                            Object::FrozenSet(s) => {
                                set_repr(&set_items(s), short, Rc::as_ptr(s).cast::<()>() as usize)
                            }
                            _ => unreachable!(),
                        };
                    }
                }
                // Defer to __repr__ on the class when present. This path
                // is reached from *native* rendering (container reprs,
                // error messages, the Debug impl), so the user `__repr__`
                // must be run by re-entering the live interpreter — the
                // same reentry the dunder coercions use. Without it,
                // `repr([Color.RED])` would render the elements as
                // `<Color object>` instead of `<Color.RED: 1>`.
                let key = DictKey(Object::from_static("__repr__"));
                let has_user_repr = inst.cls().mro.borrow().iter().any(|t| {
                    t.dict.borrow().get(&key).is_some_and(|v| {
                        // Introspection-only mirrors in builtin dicts (the
                        // docs surface pass puts `object.__repr__` in
                        // `vars(object)`, RFC 0056 WS4) are not user reprs —
                        // the default `<module.qualname object at 0x…>`
                        // rendering below must keep winning.
                        !(t.flags.is_builtin && crate::descr_registry::is_surface_only(v))
                    })
                });
                if has_user_repr {
                    if let Some(ptr) = crate::vm_singletons::current_interpreter_ptr() {
                        // SAFETY: published by an enclosing VM frame still
                        // live on this thread; the GIL keeps it exclusive.
                        let interp = unsafe { &mut *ptr };
                        if let Some(method) = crate::instance_method(self, "__repr__") {
                            let globals = interp.builtins_dict();
                            match interp.call_object_with_globals(&method, &[], &[], &globals) {
                                Ok(r) => return r.to_str(),
                                // Park the error for the fallible boundary
                                // (`repr(d)` on a dict whose element's
                                // `__repr__` raises must surface the
                                // exception, not render a placeholder).
                                Err(e) => stash_repr_error(e),
                            }
                        }
                    }
                    format!("<{} object>", inst.cls().name)
                } else {
                    // CPython's `object.__repr__`: `<module.qualname object
                    // at 0x…>` (module omitted for builtins).
                    format!(
                        "<{} object at 0x{:x}>",
                        inst.cls().qualified_display_name(),
                        Rc::as_ptr(inst) as usize
                    )
                }
            }
            Object::Property(_) => "<property object>".to_owned(),
            // CPython 3.10+: `<staticmethod(<function f at 0x..>)>` — the
            // wrapped callable's repr is embedded so the address matches
            // `'{!r}'.format(func)`.
            Object::StaticMethod(inner) => format!("<staticmethod({})>", inner.func().repr()),
            Object::ClassMethod(inner) => format!("<classmethod({})>", inner.func().repr()),
            Object::SlotDescriptor(sd) => {
                format!("<member '{}' of '{}' objects>", sd.name, sd.class_name)
            }
            // CPython `frame_repr`: address, file, current line, code name.
            Object::Frame(fr) => format!(
                "<frame at 0x{:x}, file {}, line {}, code {}>",
                Rc::as_ptr(fr) as usize,
                Object::from_str(fr.code.filename.clone()).repr(),
                fr.current_lineno(),
                fr.code.name
            ),
            Object::Traceback(tb) => {
                format!("<traceback object at 0x{:x}>", Rc::as_ptr(tb) as usize)
            }
            Object::MemoryView(mv) => {
                // A released view reprs distinctly (CPython `memory_repr`);
                // str()/repr() must keep working after release.
                let state = if mv.released.get() {
                    "released memory"
                } else {
                    "memory"
                };
                format!("<{state} at 0x{:x}>", Rc::as_ptr(mv) as usize)
            }
            Object::MappingProxy(d) => {
                let body = Object::Dict(d.clone()).repr();
                format!("mappingproxy({body})")
            }
            // Static fallback; the VM's `repr_of` delegates to the wrapped
            // mapping's own `__repr__` first.
            Object::MappingProxyObj(inner) => {
                format!("mappingproxy({})", inner.repr())
            }
            Object::DictView(v) => {
                // CPython `dictview_repr` guards with `Py_ReprEnter`: a view
                // over a dict that contains the view renders `...` instead of
                // recursing (test_dictviews `test_recursive_repr`).
                let id = Rc::as_ptr(v).cast::<()>() as usize;
                if !repr_enter(id) {
                    return "...".to_owned();
                }
                let d = v.dict.borrow();
                let body: Vec<String> = match v.kind {
                    DictViewKind::Keys => d.keys().map(|k| k.0.repr()).collect(),
                    DictViewKind::Values => d.values().map(|v| v.repr()).collect(),
                    DictViewKind::Items => d
                        .iter()
                        .map(|(k, v)| format!("({}, {})", k.0.repr(), v.repr()))
                        .collect(),
                };
                repr_leave();
                format!("{}([{}])", v.kind.type_name(), body.join(", "))
            }
            Object::LazyIter(l) => {
                format!(
                    "<itertools.{} object at {:#x}>",
                    l.type_name(),
                    Rc::as_ptr(l) as usize
                )
            }
            Object::Capsule(c) => match &c.name {
                Some(n) => format!("<capsule object \"{n}\" at 0x{:x}>", c.handle),
                None => format!("<capsule object NULL at 0x{:x}>", c.handle),
            },
            // Infallible fallback; the VM's `repr_of` routes a foreign
            // proxy through the extension's `tp_repr` (numpy array repr).
            Object::Foreign(s) => crate::foreign::repr(s)
                .unwrap_or_else(|_| format!("<{} object at 0x{:x}>", s.type_name, s.ptr)),
            Object::SimpleNamespace(d) => {
                let dict = d.borrow();
                // PEP 585/604 runtime forms repr as type expressions
                // (CPython: `repr(list[int])` is "list[int]", `repr(int |
                // str)` is "int | str"), not as namespace literals.
                let is_ellipsis = |o: &Object| {
                    matches!(o, Object::Instance(inst)
                        if Rc::ptr_eq(&inst.cls(), &crate::builtin_types::builtin_types().ellipsis_))
                };
                fn type_param_repr(o: &Object) -> String {
                    let is_ellipsis = |o: &Object| {
                        matches!(o, Object::Instance(inst)
                            if Rc::ptr_eq(&inst.cls(), &crate::builtin_types::builtin_types().ellipsis_))
                    };
                    match o {
                        Object::Type(t) => t.qualified_display_name(),
                        Object::None => "None".to_owned(),
                        // CPython `ga_repr` renders an Ellipsis argument as
                        // the literal `...` (`repr(tuple[int, ...])`).
                        _ if is_ellipsis(o) => "...".to_owned(),
                        // A list argument (a ParamSpec parameter list,
                        // `Alias[int, [float, object]]`) reprs each element
                        // with the same type-expression rule (CPython
                        // `ga_repr`'s PyList special case). Indexed access
                        // without holding the borrow: an element's user
                        // `__repr__` may mutate the list, which CPython
                        // surfaces as IndexError (gh-143823,
                        // test_genericalias.test_evil_repr3).
                        Object::List(items) => {
                            let len = items.borrow().len();
                            let mut parts: Vec<String> = Vec::with_capacity(len);
                            for idx in 0..len {
                                let item = items.borrow().get(idx).cloned();
                                match item {
                                    Some(it) => parts.push(type_param_repr(&it)),
                                    None => {
                                        stash_repr_error(crate::error::index_error(
                                            "list index out of range".to_owned(),
                                        ));
                                        break;
                                    }
                                }
                            }
                            format!("[{}]", parts.join(", "))
                        }
                        // CPython `_Py_typing_type_repr`: anything with a
                        // `__qualname__` and a `__module__` renders as
                        // `module.qualname` (bare `qualname` for builtins),
                        // so `repr(Union[fun, int])` is
                        // `"__main__.fun | int"` (test_typing
                        // test_function_repr_union), and `list[len]` is
                        // `"list[len]"`.
                        Object::Function(f) => {
                            let qual = f
                                .slot("__qualname__")
                                .as_ref()
                                .map(Object::to_str)
                                .unwrap_or_else(|| f.code().qualname.clone());
                            let module = f
                                .slot("__module__")
                                .or_else(|| {
                                    f.globals
                                        .borrow()
                                        .get(&DictKey(Object::from_static("__name__")))
                                        .cloned()
                                })
                                .unwrap_or(Object::None);
                            match module {
                                Object::None => o.repr(),
                                m => {
                                    let m = m.to_str();
                                    if m == "builtins" {
                                        qual
                                    } else {
                                        format!("{m}.{qual}")
                                    }
                                }
                            }
                        }
                        Object::Builtin(b) => {
                            let qual = crate::builtin_display_name(b.name);
                            match crate::descr_registry::module_of(o) {
                                Some(m) if m != "builtins" => format!("{m}.{qual}"),
                                _ => qual.to_owned(),
                            }
                        }
                        other => other.repr(),
                    }
                }
                let args = dict.get(&DictKey(Object::from_static("__args__"))).cloned();
                if dict
                    .get(&DictKey(Object::from_static("__is_pep604_union__")))
                    .is_some()
                {
                    if let Some(Object::Tuple(items)) = &args {
                        // CPython's `union_repr` prints `NoneType` as
                        // `None` (`repr(int | None)` == "int | None");
                        // `GenericAlias` repr does not.
                        let parts: Vec<String> = items
                            .iter()
                            .map(|o| match o {
                                Object::Type(t) if t.name == "NoneType" => "None".to_owned(),
                                other => type_param_repr(other),
                            })
                            .collect();
                        return parts.join(" | ");
                    }
                }
                if let (Some(origin), Some(Object::Tuple(items))) =
                    (dict.get(&DictKey(Object::from_static("__origin__"))), &args)
                {
                    // The PEP 646 starred form (`__unpacked__ = True`, what
                    // `iter(tuple[str])` yields) reprs with a `*` prefix
                    // (CPython `ga_repr`: `*tuple[str]`).
                    let star = if matches!(
                        dict.get(&DictKey(Object::from_static("__unpacked__"))),
                        Some(Object::Bool(true))
                    ) {
                        "*"
                    } else {
                        ""
                    };
                    // `collections.abc.Callable[...]` stores its args
                    // *flattened* `(arg1, .., argN, ret)`; the repr restores
                    // the CPython `_CallableGenericAlias` bracket form
                    // `Callable[[arg1, .., argN], ret]` unless the parameter
                    // slot is `...`/a ParamSpec (which reprs bare).
                    let is_param_expr = |o: &Object| {
                        is_ellipsis(o)
                            || matches!(o, Object::Instance(inst)
                            if inst.cls().mro.borrow().iter().any(|t| matches!(
                                t.name.as_str(),
                                "ParamSpec" | "_ConcatenateGenericAlias"
                            )))
                    };
                    if matches!(origin, Object::Type(t) if t.name == "Callable")
                        && !items.is_empty()
                        && !(items.len() == 2 && is_param_expr(&items[0]))
                    {
                        let (ret, params) = items.split_last().expect("non-empty args");
                        let parts: Vec<String> = params.iter().map(type_param_repr).collect();
                        return format!(
                            "{}{}[[{}], {}]",
                            star,
                            type_param_repr(origin),
                            parts.join(", "),
                            type_param_repr(ret)
                        );
                    }
                    // CPython `ga_repr` writes a literal `()` for an
                    // empty args tuple (`repr(list[()])` == "list[()]").
                    if items.is_empty() {
                        return format!("{}{}[()]", star, type_param_repr(origin));
                    }
                    let parts: Vec<String> = items.iter().map(type_param_repr).collect();
                    return format!("{}{}[{}]", star, type_param_repr(origin), parts.join(", "));
                }
                // CPython's `namespace_repr` is `Py_ReprEnter`-guarded:
                // a self-referencing namespace renders as `namespace(...)`
                // (test_types.test_recursive_repr).
                thread_local! {
                    static IN_REPR: RefCell<std::collections::HashSet<usize>> =
                        RefCell::new(std::collections::HashSet::new());
                }
                let key = Rc::as_ptr(d) as usize;
                if !IN_REPR.with(|s| s.borrow_mut().insert(key)) {
                    return "namespace(...)".to_owned();
                }
                let parts: Vec<String> = dict
                    .iter()
                    .map(|(k, v)| format!("{}={}", k.0.to_str(), v.repr()))
                    .collect();
                IN_REPR.with(|s| {
                    s.borrow_mut().remove(&key);
                });
                format!("namespace({})", parts.join(", "))
            }
        }
    }

    /// Python `str()` — like [`repr`] but strings render without
    /// surrounding quotes.
    pub fn to_str(&self) -> String {
        match self {
            Object::Str(s) => s.to_string(),
            // A `String` cannot hold lone surrogates, so this lossy view maps
            // them to U+FFFD. Fidelity-critical consumers (encoders,
            // `os.fsencode`, `repr`) take [`Object::str_codepoints`] instead;
            // `to_str` is for display/diagnostic text where loss is acceptable.
            Object::WStr(cps) => cps
                .iter()
                .map(|&c| char::from_u32(c).unwrap_or('\u{FFFD}'))
                .collect(),
            _ => self.repr(),
        }
    }

    /// Length, where defined. Returns `Err(TypeError)` otherwise.
    pub fn len(&self) -> Result<usize, RuntimeError> {
        match self {
            Object::Str(s) => Ok(str_char_len(s)),
            // Length in code points: a lone surrogate counts as one, matching
            // CPython where `len(chr(0xD800)) == 1`.
            Object::WStr(cps) => Ok(cps.len()),
            Object::Tuple(items) => Ok(items.len()),
            Object::List(items) => Ok(items.borrow().len()),
            Object::Dict(d) => Ok(d.borrow().len()),
            Object::Range(r) => {
                if r.big.is_some() {
                    use num_traits::ToPrimitive;
                    let len = range_len_bigint(r);
                    return match len.to_i64() {
                        Some(n) if n >= 0 => Ok(n as usize),
                        _ => Err(crate::error::overflow_error(
                            "Python int too large to convert to C ssize_t",
                        )),
                    };
                }
                let span = if r.step > 0 {
                    (r.stop - r.start).max(0)
                } else if r.step < 0 {
                    (r.start - r.stop).max(0)
                } else {
                    return Err(value_error("range step cannot be zero"));
                };
                let step = r.step.unsigned_abs() as i128;
                let len = ((span + step - 1) / step).max(0);
                // CPython's `range_length` computes a `Py_ssize_t`; a range
                // longer than that (`range(-maxsize, maxsize)`) raises
                // OverflowError from `len()` (test_range.test_large_range).
                if len > i128::from(i64::MAX) {
                    return Err(crate::error::overflow_error(
                        "Python int too large to convert to C ssize_t",
                    ));
                }
                Ok(len as usize)
            }
            Object::Bytes(b) => Ok(b.len()),
            Object::ByteArray(b) => Ok(b.borrow().len()),
            Object::Set(s) => Ok(s.borrow().len()),
            Object::FrozenSet(s) => Ok(s.len()),
            // `len(mv)` is the first-dimension element count, not the byte
            // size — they differ once `cast` sets `itemsize > 1` or adds
            // dimensions (`len(memoryview(b'1234').cast('I')) == 1`).
            Object::MemoryView(mv) => {
                // A released view refuses (CPython `memory_length`,
                // test_memoryview._check_released).
                if mv.released.get() {
                    return Err(value_error(
                        "operation forbidden on released memoryview object",
                    ));
                }
                if mv.zero_dim.get() {
                    return Err(crate::error::type_error(
                        "0-dim memory has no length".to_owned(),
                    ));
                }
                Ok(mv.shape_dims().first().copied().unwrap_or(0))
            }
            Object::MappingProxy(d) => Ok(d.borrow().len()),
            // Static fallback; the VM's `len()` delegates to the wrapped
            // mapping's own `__len__` first.
            Object::MappingProxyObj(inner) => inner.len(),
            Object::DictView(v) => Ok(v.dict.borrow().len()),
            // A subclass of a built-in container (`class C(list)`, …)
            // measures the length of the native payload it wraps.
            Object::Instance(inst) => match inst.native.get() {
                Some(native) => native.len(),
                None => {
                    if crate::hot_gates::env_flags::len_dbg() {
                        eprintln!(
                            "[LEN_DBG] Instance cls={} c_body={:#x} native=None",
                            inst.cls().name,
                            inst.c_body.get()
                        );
                    }
                    Err(type_error(format!(
                        "object of type '{}' has no len()",
                        self.type_name()
                    )))
                }
            },
            // A foreign extension object (an ndarray slice handed to the
            // *builtin* `len` by Cython's `roll_apply`) carries its length
            // in its C `sq_length`/`mp_length` slot — consult the bridge,
            // exactly as CPython's `PyObject_Size` slot dispatch would.
            // The bridge propagates the C-side error (including its
            // faithful "object of type '…' has no len()" TypeError).
            Object::Foreign(s) => Ok(crate::foreign::length(s)?.max(0) as usize),
            _ => Err(type_error(format!(
                "object of type '{}' has no len()",
                self.type_name()
            ))),
        }
    }
}

fn sets_equal(a: &SetData, b: &SetData) -> bool {
    a.len() == b.len() && a.iter().all(|k| b.contains(k))
}

/// CPython `code_richcompare`: two code objects are equal when their
/// semantic surface matches — name, arities, flags-ish shape, bytecode,
/// constants (recursively, code constants use this same comparison),
/// and the name tables. Deliberately *excludes* line/column tables,
/// filename, and the interior-mutable inline-cache table (CPython
/// ignores `co_linetable` too, and warmed caches must not make an
/// executed code object unequal to a fresh compile of the same source).
/// `co_firstlineno` as the attribute surface reports it (first tracked
/// line; module bodies always report 1).
fn code_firstlineno(c: &CodeObject) -> u32 {
    if c.name == "<module>" {
        1
    } else {
        c.linetable.iter().copied().find(|l| *l > 0).unwrap_or(1)
    }
}

/// The location table as `co_linetable` reports it: a pinned raw
/// override wins, otherwise the encoded wire form.
fn code_effective_linetable(c: &CodeObject) -> Vec<u8> {
    if let Some(b) = c.wire.as_ref().and_then(|w| w.co_linetable.as_ref()) {
        return b.clone();
    }
    c.to_cpython().co_linetable.clone()
}

/// The bytecode as `co_code` reports it: a pinned raw override wins,
/// otherwise the encoded wire form.
fn code_effective_code(c: &CodeObject) -> Vec<u8> {
    if let Some(b) = c.wire.as_ref().and_then(|w| w.co_code.as_ref()) {
        return b.clone();
    }
    c.to_cpython().co_code.clone()
}

/// The exception table as `co_exceptiontable` reports it.
fn code_effective_exceptiontable(c: &CodeObject) -> Vec<u8> {
    if let Some(b) = c.wire.as_ref().and_then(|w| w.co_exceptiontable.as_ref()) {
        return b.clone();
    }
    c.to_cpython().co_exceptiontable.clone()
}

/// Value hash for code objects, consistent with `code_value_eq` (equal
/// codes must land in the same set/dict bucket — CPython `code_hash`;
/// test_marshal round-trips sets of code objects).
pub(crate) fn code_value_hash(c: &CodeObject) -> i64 {
    let mut lanes: Vec<i64> = vec![
        py_str_hash(&c.name),
        py_str_hash(&c.qualname),
        i64::from(c.arg_count),
        i64::from(c.posonly_count),
        i64::from(c.kwonly_count),
        i64::from(c.has_varargs)
            | (i64::from(c.has_varkeywords) << 1)
            | (i64::from(c.is_generator) << 2),
        py_hash_bytes_slice(&code_effective_code(c)),
        i64::from(code_firstlineno(c)),
        py_hash_bytes_slice(&code_effective_linetable(c)),
        py_hash_bytes_slice(&code_effective_exceptiontable(c)),
    ];
    for group in [&c.names, &c.varnames, &c.freevars, &c.cellvars] {
        for n in group.iter() {
            lanes.push(py_str_hash(n));
        }
    }
    for k in c.constants.iter() {
        // Consts hash through their runtime objects so numeric aliasing
        // (0.0 vs -0.0) and nested code objects stay consistent with
        // `const_eq`.
        let o = crate::constant_to_object_public(k.clone());
        lanes.push(py_hash_value(&o).unwrap_or_else(|| identity_hash(&o)));
    }
    let v = combine_tuple_hash(&lanes);
    if v == -1 {
        -2
    } else {
        v
    }
}

fn code_value_eq(a: &CodeObject, b: &CodeObject) -> bool {
    use weavepy_compiler::Constant;
    fn const_eq(x: &Constant, y: &Constant) -> bool {
        match (x, y) {
            (Constant::Code(cx), Constant::Code(cy)) => code_value_eq(cx, cy),
            _ => x == y,
        }
    }
    a.name == b.name
        && a.qualname == b.qualname
        && a.arg_count == b.arg_count
        && a.posonly_count == b.posonly_count
        && a.kwonly_count == b.kwonly_count
        && a.has_varargs == b.has_varargs
        && a.has_varkeywords == b.has_varkeywords
        && a.is_generator == b.is_generator
        // Bytecode is compared through the encoded CPython wire form, not
        // the internal instruction vectors: the compiler and the marshal
        // decoder can pick different (equivalent) internal encodings for
        // the same program, and CPython's code_richcompare works on the
        // normalized wire stream anyway.
        && code_effective_code(a) == code_effective_code(b)
        && a.names == b.names
        && a.varnames == b.varnames
        && a.freevars == b.freevars
        && a.cellvars == b.cellvars
        // CPython's code_richcompare covers location and exception info
        // too: replacing co_linetable/co_exceptiontable produces an
        // *unequal* code object, and two otherwise-identical lambdas on
        // different source lines differ (test_code.test_code_equality /
        // test_code_hash_uses_firstlineno). Compared through the *encoded*
        // wire tables (plus co_firstlineno, which the relative line deltas
        // don't capture) so a marshal round-trip — whose per-instruction
        // vectors are representationally different but semantically
        // identical — still compares equal (test_marshal.testModule).
        && code_firstlineno(a) == code_firstlineno(b)
        && code_effective_linetable(a) == code_effective_linetable(b)
        && code_effective_exceptiontable(a) == code_effective_exceptiontable(b)
        && a.wire == b.wire
        && a.constants.len() == b.constants.len()
        && a.constants
            .iter()
            .zip(b.constants.iter())
            .all(|(x, y)| const_eq(x, y))
}

/// Substring test over code-point sequences (the WTF-8 analogue of
/// `str::contains`). The empty needle matches anywhere (`"" in s` is `True`).
pub(crate) fn codepoint_subslice_contains(haystack: &[u32], needle: &[u32]) -> bool {
    if needle.is_empty() {
        return true;
    }
    if needle.len() > haystack.len() {
        return false;
    }
    haystack.windows(needle.len()).any(|w| w == needle)
}

/// Compare a BigInt against a float.  Mirrors CPython: `inf` always
/// compares greater than any int, `-inf` always less, NaN is
/// uncomparable.
pub(crate) fn bigint_cmp_f64(a: &BigInt, b: f64) -> Result<Ordering, RuntimeError> {
    if b.is_nan() {
        // Unordered (`<` is False both ways); see `Object::cmp`'s float arm.
        return Ok(Ordering::Equal);
    }
    if b == f64::INFINITY {
        return Ok(Ordering::Less);
    }
    if b == f64::NEG_INFINITY {
        return Ok(Ordering::Greater);
    }
    // Compare integer parts first by comparing the BigInt to floor(b)
    // converted to BigInt; tie-break on fractional part.
    let trunc = b.trunc();
    let bi_trunc = bigint_from_f64_trunc(trunc);
    match a.cmp(&bi_trunc) {
        Ordering::Equal => {
            let frac = b - trunc;
            if frac == 0.0 {
                Ok(Ordering::Equal)
            } else if frac > 0.0 {
                Ok(Ordering::Less)
            } else {
                Ok(Ordering::Greater)
            }
        }
        other => Ok(other),
    }
}

pub(crate) fn bigint_eq_f64(a: &BigInt, b: f64) -> bool {
    if !b.is_finite() {
        return false;
    }
    if b.fract() != 0.0 {
        return false;
    }
    let bi = bigint_from_f64_trunc(b);
    *a == bi
}

/// Smallest power of two that is *not* exactly representable beyond the
/// f64 integer-precision boundary; `2f64.powi(63)` as a literal so the
/// i64-range checks below stay branch-cheap.
const TWO_POW_63: f64 = 9_223_372_036_854_775_808.0;

/// Exact `i64 == f64`. A plain `a as f64 == b` loses precision for
/// `|a| > 2**53`, making e.g. `float(2**53 + 1) == 2**53 + 1` wrongly
/// `True`. CPython compares an int and a float *exactly*; this mirrors
/// that without allocating a `BigInt` for the common in-range case.
pub(crate) fn i64_eq_f64(a: i64, b: f64) -> bool {
    if !b.is_finite() || b.fract() != 0.0 {
        return false;
    }
    // `b` is integral; it can equal an `i64` only inside `[-2**63, 2**63)`.
    if (-TWO_POW_63..TWO_POW_63).contains(&b) {
        (b as i64) == a
    } else {
        false
    }
}

/// Exact `i64` vs `f64` ordering (see [`i64_eq_f64`]).
pub(crate) fn i64_cmp_f64(a: i64, b: f64) -> Result<Ordering, RuntimeError> {
    if b.is_nan() {
        // Unordered (`<` is False both ways); see `Object::cmp`'s float arm.
        return Ok(Ordering::Equal);
    }
    if b == f64::INFINITY {
        return Ok(Ordering::Less);
    }
    if b == f64::NEG_INFINITY {
        return Ok(Ordering::Greater);
    }
    let trunc = b.trunc();
    if (-TWO_POW_63..TWO_POW_63).contains(&trunc) {
        let ti = trunc as i64;
        match a.cmp(&ti) {
            Ordering::Equal => {
                let frac = b - trunc;
                if frac == 0.0 {
                    Ok(Ordering::Equal)
                } else if frac > 0.0 {
                    Ok(Ordering::Less)
                } else {
                    Ok(Ordering::Greater)
                }
            }
            other => Ok(other),
        }
    } else if trunc > 0.0 {
        // |b| ≥ 2**63 is larger in magnitude than any i64.
        Ok(Ordering::Less)
    } else {
        Ok(Ordering::Greater)
    }
}

// ---------------------------------------------------------------------------
// NaN identity tags
// ---------------------------------------------------------------------------
//
// CPython heap-allocates every `float`, so two separately created NaNs are
// distinct *objects*: `float('nan') is float('nan')` is False, `hash(nan)`
// is pointer-derived per object (3.10+, gh-43475), and a `set`/`dict` keeps
// separately created NaNs apart (the `a is b or a == b` key rule finds only
// the *same* NaN). WeavePy's `Object::Float` is an unboxed `f64`, where all
// canonical NaNs are bit-identical — collapsing that distinction (pandas'
// `IntervalIndex._intersection_non_unique` deliberately exploits it to keep
// one NaN row; CPython's own float tests pin `hash(nan)` to the object).
//
// Identity is restored by *tagging*: every seam where CPython would allocate
// a fresh float object for a NaN (literal parse, `PyFloat_FromDouble`,
// arithmetic producing NaN) stamps a unique counter into the mantissa.
// Bit 51 (quiet) stays set, bit 50 marks "WeavePy tag", bits 29..50 carry
// the counter, bits 0..29 hold a fixed magic (see `NAN_TAG_MAGIC`), and
// the sign bit is preserved. `is_same` (bit
// comparison) then separates distinct NaNs exactly like CPython pointer
// identity, and `py_hash_double` hashes the bits — stable per object,
// different across objects.
//
// The tag must never leak where CPython would expose *canonical* NaN bits:
// `struct.pack`, `PyFloat_AsDouble` (numpy ingests array elements through
// it; `pandas.util.hash_pandas_object` hashes the raw buffer), pickle /
// marshal payloads, and mirror float bodies (`ob_fval` is read by the
// `PyFloat_AS_DOUBLE` macro). Those seams call [`untag_nan`], which strips
// only marker-and-magic-bearing tags and leaves genuine payloads — e.g.
// from `struct.unpack` of exotic bytes — untouched, so byte-level
// round-trips stay faithful.

/// Marker bit distinguishing WeavePy identity tags from genuine NaN
/// payloads that entered through byte-level APIs.
const NAN_TAG_MARKER: u64 = 1 << 50;
/// The tag's low field is a fixed magic, not counter bits. A NaN widened
/// from a 2- or 4-byte encoding (`PyFloat_Unpack2/4`, `struct.unpack('e'
/// / 'f')`) carries its payload in the top of the mantissa and has bits
/// 0..29 clear, so requiring this nonzero magic there means no such
/// payload can ever be mistaken for a tag and canonicalized on the way
/// back out (test_capi.test_float's random-payload round trips at every
/// size). An 8-byte payload collides only with probability 2^-29.
const NAN_TAG_MAGIC_MASK: u64 = (1 << 29) - 1;
const NAN_TAG_MAGIC: u64 = 0x0A5C_3D71;
/// The identity counter lives in bits 29..50.
const NAN_TAG_COUNTER_SHIFT: u32 = 29;
const NAN_TAG_COUNTER_MASK: u64 = (1 << (50 - NAN_TAG_COUNTER_SHIFT)) - 1;

/// Whether `v` carries a WeavePy identity tag (as opposed to a genuine
/// payload that entered through a byte-level API).
#[inline]
fn is_tagged_nan(v: f64) -> bool {
    let bits = v.to_bits();
    v.is_nan() && bits & NAN_TAG_MARKER != 0 && bits & NAN_TAG_MAGIC_MASK == NAN_TAG_MAGIC
}

/// Stamp a fresh identity tag into a NaN, preserving its sign. Non-NaN
/// values pass through unchanged. Each call yields a distinct bit pattern,
/// mirroring CPython allocating a distinct object.
#[inline]
pub fn tag_nan(v: f64) -> f64 {
    if !v.is_nan() {
        return v;
    }
    fresh_nan_bits(v)
}

#[cold]
fn fresh_nan_bits(v: f64) -> f64 {
    use std::sync::atomic::{AtomicU64, Ordering};
    static NEXT_NAN_TAG: AtomicU64 = AtomicU64::new(1);
    let counter = NEXT_NAN_TAG.fetch_add(1, Ordering::Relaxed) & NAN_TAG_COUNTER_MASK;
    let sign = v.to_bits() & (1u64 << 63);
    // Exponent all-ones + quiet bit keeps it a quiet NaN on every platform.
    f64::from_bits(
        sign | 0x7ff8_0000_0000_0000
            | NAN_TAG_MARKER
            | (counter << NAN_TAG_COUNTER_SHIFT)
            | NAN_TAG_MAGIC,
    )
}

/// Construct an `Object::Float`, giving a NaN result a fresh identity —
/// used at every seam where CPython would allocate a new float object.
#[inline]
pub fn fresh_float(v: f64) -> Object {
    Object::Float(tag_nan(v))
}

/// Strip a WeavePy identity tag, restoring the canonical quiet NaN (sign
/// preserved) CPython would expose. Genuine payloads (marker bit clear) and
/// non-NaN values pass through unchanged.
#[inline]
pub fn untag_nan(v: f64) -> f64 {
    if is_tagged_nan(v) {
        let sign = v.to_bits() & (1u64 << 63);
        return f64::from_bits(sign | 0x7ff8_0000_0000_0000);
    }
    v
}

/// Re-tag a NaN read back from a byte-level API (`struct.unpack`, pickle,
/// marshal). A *canonical* payload gets a fresh identity — CPython builds a
/// new object whose canonical bits round-trip anyway — while an exotic
/// payload is preserved verbatim so `pack(unpack(bytes)) == bytes` holds
/// bit-for-bit (identity fidelity yields to byte fidelity there).
#[inline]
pub fn tag_unpacked_nan(v: f64) -> f64 {
    if v.is_nan() && v.to_bits() & !(1u64 << 63) == 0x7ff8_0000_0000_0000 {
        return fresh_nan_bits(v);
    }
    v
}

/// Width of the Python numeric hash reduction: `_PyHASH_BITS` (61 on
/// 64-bit, so the modulus is the Mersenne prime `2**61 - 1`).
const PY_HASH_BITS: u32 = 61;
/// `sys.hash_info.inf` — the hash of `±inf` (CPython `_PyHASH_INF`).
pub(crate) const PY_HASH_INF: i64 = 314_159;
/// `sys.hash_info.imag` — the multiplier for a complex's imaginary part.
const PY_HASH_IMAG: u64 = 1_000_003;

/// C `frexp`: split `x` into `(m, e)` with `x == m * 2**e` and
/// `0.5 <= |m| < 1` (or `m == 0`). Handles subnormals; callers guard
/// against non-finite inputs.
fn py_frexp(x: f64) -> (f64, i32) {
    if x == 0.0 || !x.is_finite() {
        return (x, 0);
    }
    let bits = x.to_bits();
    let raw_exp = ((bits >> 52) & 0x7ff) as i32;
    if raw_exp == 0 {
        // Subnormal: scale into the normal range (× 2**54), then correct.
        let (m, e) = py_frexp(x * 18_014_398_509_481_984.0_f64);
        return (m, e - 54);
    }
    // Normal value = ±(1.frac) * 2**(raw_exp-1023). Forcing the stored
    // exponent field to 1022 (factor 2**-1) yields a mantissa in [0.5, 1);
    // the true binary exponent is then `raw_exp - 1022`.
    let e = raw_exp - 1022;
    let m = f64::from_bits((bits & 0x800f_ffff_ffff_ffff) | (1022u64 << 52));
    (m, e)
}

/// CPython `_Py_HashDouble`: the canonical hash of a finite double via
/// reduction modulo `2**61 - 1`, so an integer-valued float hashes equal
/// to the corresponding `int` and a `Fraction`/`Decimal` of equal value.
pub(crate) fn py_hash_double(v: f64) -> i64 {
    const MOD: u64 = (1u64 << PY_HASH_BITS) - 1;
    if !v.is_finite() {
        if v.is_infinite() {
            return if v > 0.0 { PY_HASH_INF } else { -PY_HASH_INF };
        }
        // NaN. CPython 3.10+ (gh-43475) derives the hash from the object's
        // *identity* so distinct NaNs land in different buckets. WeavePy's
        // identity for a NaN float is its (tagged) bit pattern — see
        // [`tag_nan`] — so hash the bits: stable for the same object, unique
        // per creation, exactly the property `object.__hash__` gives CPython.
        let v = (v.to_bits().rotate_right(4) as i64).wrapping_mul(0x9E37_79B9_7F4A_7C15u64 as i64);
        return if v == -1 { -2 } else { v };
    }
    let (mut m, mut e) = py_frexp(v);
    let sign: i64 = if m < 0.0 {
        m = -m;
        -1
    } else {
        1
    };
    // Accumulate 28 bits of mantissa at a time, rotating left within the
    // 61-bit field (mirrors the C loop exactly).
    let mut x: u64 = 0;
    while m != 0.0 {
        x = ((x << 28) & MOD) | (x >> (PY_HASH_BITS - 28));
        m *= 268_435_456.0; // 2**28
        e -= 28;
        let y = m as u64;
        m -= y as f64;
        x += y;
        if x >= MOD {
            x -= MOD;
        }
    }
    // Fold in the leftover power of two via a 61-bit rotate.
    let mut e = e % (PY_HASH_BITS as i32);
    if e < 0 {
        e += PY_HASH_BITS as i32;
    }
    let e = e as u32;
    x = ((x << e) & MOD) | (x >> (PY_HASH_BITS - e));
    let mut res = (x as i64) * sign;
    if res == -1 {
        res = -2;
    }
    res
}

/// CPython `long_hash` for a machine int: `sign * (|n| mod (2**61-1))`,
/// with the reserved `-1` remapped to `-2`.
pub(crate) fn py_hash_long_i64(n: i64) -> i64 {
    const MOD: u128 = (1u128 << PY_HASH_BITS) - 1;
    let mut x = (i128::from(n).unsigned_abs() % MOD) as i64;
    if n < 0 {
        x = -x;
    }
    if x == -1 {
        x = -2;
    }
    x
}

/// CPython `long_hash` for a big int. `BigInt %` is truncating, so it
/// already carries the dividend's sign with magnitude `|n| mod P`.
pub(crate) fn py_hash_long_bigint(value: &BigInt) -> i64 {
    let modulus = BigInt::from((1u64 << PY_HASH_BITS) - 1);
    let rem = value % &modulus;
    let mut x = rem.to_i64().unwrap_or(0);
    if x == -1 {
        x = -2;
    }
    x
}

/// CPython `complex_hash`: `hash(real) + _PyHASH_IMAG * hash(imag)` in
/// wrapping (mod 2**64) arithmetic, with `-1` remapped to `-2`. A
/// zero-imaginary complex therefore hashes equal to the bare float.
pub(crate) fn py_hash_complex(re: f64, im: f64) -> i64 {
    let hr = py_hash_double(re) as u64;
    let hi = py_hash_double(im) as u64;
    let combined = hr.wrapping_add(PY_HASH_IMAG.wrapping_mul(hi));
    let res = combined as i64;
    if res == -1 {
        -2
    } else {
        res
    }
}

/// Exact CPython `hash()` for the built-in numeric types, so that equal
/// values across `bool`/`int`/`float`/`complex` (and the pure-Python
/// `Fraction`/`Decimal`, which implement the same reduction) all agree.
/// Returns `None` for non-numeric objects.
pub(crate) fn numeric_hash(obj: &Object) -> Option<i64> {
    match obj {
        Object::Bool(b) => Some(py_hash_long_i64(i64::from(*b))),
        Object::Int(i) => Some(py_hash_long_i64(*i)),
        Object::Long(b) => Some(py_hash_long_bigint(b)),
        Object::Float(f) => Some(py_hash_double(*f)),
        Object::Complex(c) => {
            // CPython 3.10+ `complex_hash` runs `_Py_HashDouble((PyObject*)v,
            // part)`, so a NaN part contributes the *object's* pointer hash —
            // distinct complex allocations with NaN parts hash apart. Our
            // `Object::Complex` carries Rc identity; fold that in for the NaN
            // case (both parts see the same identity, as in CPython).
            if c.real.is_nan() || c.imag.is_nan() {
                let ident = (Rc::as_ptr(c) as usize as u64).rotate_right(4) as i64;
                let re_h = if c.real.is_nan() {
                    ident
                } else {
                    py_hash_double(c.real)
                };
                let im_h = if c.imag.is_nan() {
                    ident
                } else {
                    py_hash_double(c.imag)
                };
                let combined =
                    (re_h as u64).wrapping_add(PY_HASH_IMAG.wrapping_mul(im_h as u64)) as i64;
                return Some(if combined == -1 { -2 } else { combined });
            }
            Some(py_hash_complex(c.real, c.imag))
        }
        _ => None,
    }
}

/// `hash(None)` — CPython 3.12 returns this fixed constant rather than a
/// pointer-derived value.
const PY_HASH_NONE: i64 = 0xFCA8_6420;

/// Per-process `str`/`bytes`/`memoryview` hash algorithm (PEP 456).
///
/// Randomized (default) hashing carries no cross-process stability contract,
/// so it uses the internal Fx fold: this function sits under *every*
/// string-keyed dict probe (attribute lookups, globals, keyword matching),
/// where profiling showed SipHash itself as a top-ten CPU consumer. When
/// `PYTHONHASHSEED` is pinned, though, the *values* are the contract —
/// test_hash spawns children with a fixed seed and compares `hash('abc')`
/// bit-for-bit — so the pinned mode is CPython's exact SipHash-1-3 keyed by
/// the LCG-expanded seed. Both modes agree that `hash("") == hash(b"") == 0`
/// and remap the reserved `-1` to `-2`.
enum HashAlgo {
    /// Randomized default: Fx fold salted with per-process OS entropy,
    /// finished with a murmur3 avalanche so the low bits distribute
    /// (dict-slot quality; test_hash's `hash(prefix + chr(c)) & 0xf`).
    Fx { salt: u64 },
    /// `PYTHONHASHSEED=n` pinned: CPython-exact SipHash-1-3.
    Sip { k0: u64, k1: u64 },
}

static HASH_ALGO: std::sync::OnceLock<HashAlgo> = std::sync::OnceLock::new();

/// Pin the hash secret from `PYTHONHASHSEED`. Must run before the first
/// `str`/`bytes` hash of the process (the CLI calls it first thing);
/// a later call is a no-op, matching CPython where the seed is fixed
/// at startup.
pub fn set_hash_seed(seed: u32) {
    let (k0, k1) = if seed == 0 {
        // `PYTHONHASHSEED=0` zeroes `_Py_HashSecret` outright.
        (0, 0)
    } else {
        // CPython `lcg_urandom` (bootstrap_hash.c): an MSVC-style LCG
        // expands the 32-bit seed byte-by-byte into `_Py_HashSecret`;
        // the first 16 bytes are SipHash's k0/k1, little-endian.
        let mut buf = [0u8; 16];
        let mut x: u32 = seed;
        for b in &mut buf {
            x = x.wrapping_mul(214_013).wrapping_add(2_531_011);
            *b = (x >> 16) as u8;
        }
        (
            u64::from_le_bytes(buf[..8].try_into().unwrap()),
            u64::from_le_bytes(buf[8..].try_into().unwrap()),
        )
    };
    let _ = HASH_ALGO.set(HashAlgo::Sip { k0, k1 });
}

fn hash_algo() -> &'static HashAlgo {
    HASH_ALGO.get_or_init(|| {
        use std::hash::{BuildHasher, Hasher};
        // `RandomState` is seeded from OS entropy once per process.
        HashAlgo::Fx {
            salt: std::collections::hash_map::RandomState::new()
                .build_hasher()
                .finish(),
        }
    })
}

/// CPython's SipHash-1-3 (`pysiphash` in Python/pyhash.c): one compression
/// round per 8-byte word, three finalization rounds, keyed by the two
/// 64-bit halves of `_Py_HashSecret`.
fn siphash13(k0: u64, k1: u64, data: &[u8]) -> u64 {
    #[inline(always)]
    fn round(v0: &mut u64, v1: &mut u64, v2: &mut u64, v3: &mut u64) {
        *v0 = v0.wrapping_add(*v1);
        *v2 = v2.wrapping_add(*v3);
        *v1 = v1.rotate_left(13) ^ *v0;
        *v3 = v3.rotate_left(16) ^ *v2;
        *v0 = v0.rotate_left(32);
        *v2 = v2.wrapping_add(*v1);
        *v0 = v0.wrapping_add(*v3);
        *v1 = v1.rotate_left(17) ^ *v2;
        *v3 = v3.rotate_left(21) ^ *v0;
        *v2 = v2.rotate_left(32);
    }
    let mut v0 = k0 ^ 0x736f_6d65_7073_6575;
    let mut v1 = k1 ^ 0x646f_7261_6e64_6f6d;
    let mut v2 = k0 ^ 0x6c79_6765_6e65_7261;
    let mut v3 = k1 ^ 0x7465_6462_7974_6573;
    let (chunks, rem) = data.as_chunks::<8>();
    for chunk in chunks {
        let mi = u64::from_le_bytes(*chunk);
        v3 ^= mi;
        round(&mut v0, &mut v1, &mut v2, &mut v3);
        v0 ^= mi;
    }
    // Little-endian assemble of the 0..7 tail bytes with fixed-width
    // loads: byte `i` of the tail lands at bits `8*i`, exactly as
    // `u64::from_le_bytes` of a zero-padded buffer would place it, but
    // without the variable-length `copy_from_slice` (a `memcpy` call that
    // the RFC 0077 census showed under every short-string hash).
    let mut tail: u64 = 0;
    let mut rest = rem;
    let mut shift = 0u32;
    if rest.len() >= 4 {
        tail |= u64::from(u32::from_le_bytes([rest[0], rest[1], rest[2], rest[3]]));
        rest = &rest[4..];
        shift = 32;
    }
    if rest.len() >= 2 {
        tail |= u64::from(u16::from_le_bytes([rest[0], rest[1]])) << shift;
        rest = &rest[2..];
        shift += 16;
    }
    if let Some(&byte) = rest.first() {
        tail |= u64::from(byte) << shift;
    }
    let b = ((data.len() as u64) << 56) | tail;
    v3 ^= b;
    round(&mut v0, &mut v1, &mut v2, &mut v3);
    v0 ^= b;
    v2 ^= 0xff;
    round(&mut v0, &mut v1, &mut v2, &mut v3);
    round(&mut v0, &mut v1, &mut v2, &mut v3);
    round(&mut v0, &mut v1, &mut v2, &mut v3);
    (v0 ^ v1) ^ (v2 ^ v3)
}

fn py_hash_bytes_slice(bytes: &[u8]) -> i64 {
    if bytes.is_empty() {
        return 0;
    }
    let v = match hash_algo() {
        HashAlgo::Sip { k0, k1 } => siphash13(*k0, *k1, bytes) as i64,
        HashAlgo::Fx { salt } => {
            use std::hash::Hasher;
            let mut h = crate::fasthash::FxHasher::default();
            h.write_u64(*salt);
            h.write(bytes);
            h.write_usize(bytes.len());
            // murmur3 fmix64: the Fx fold alone avalanches poorly into the
            // low bits, which is where dict slots (and test_hash's
            // distribution check) look.
            let mut x = h.finish();
            x ^= x >> 33;
            x = x.wrapping_mul(0xff51_afd7_ed55_8ccd);
            x ^= x >> 33;
            x = x.wrapping_mul(0xc4ce_b9fe_1a85_ec53);
            x ^= x >> 33;
            x as i64
        }
    };
    if v == -1 {
        -2
    } else {
        v
    }
}

/// Interpreter-independent hash of a `str` — the exact value `hash(s)`
/// yields (the same one [`py_hash_value`] computes for `Object::Str`).
///
/// The C-API layer mirrors this into a faithful `str`'s `hash` field so
/// that macro-heavy Cython, which reads `((PyASCIIObject*)s)->hash`
/// *directly* off the struct to match keyword arguments
/// (`__Pyx_MatchKeywordArg_str`), sees the same value WeavePy would
/// compute — without it every Cython call with a keyword argument fails
/// with a spurious "unexpected keyword argument".
pub fn py_str_hash(s: &str) -> i64 {
    if s.is_ascii() || matches!(hash_algo(), HashAlgo::Fx { .. }) {
        return py_hash_bytes_slice(s.as_bytes());
    }
    // Pinned seed: CPython hashes the *compact-unicode payload* — one byte
    // per char through U+00FF, two through U+FFFF, four beyond, in native
    // endianness (test_hash pins the UCS2 values per endianness) — so the
    // unit buffer must be rebuilt from the UTF-8 storage.
    let max = s.chars().map(u32::from).max().unwrap_or(0);
    let buf: Vec<u8> = if max <= 0xff {
        s.chars().map(|c| c as u32 as u8).collect()
    } else if max <= 0xffff {
        s.chars()
            .flat_map(|c| (c as u32 as u16).to_ne_bytes())
            .collect()
    } else {
        s.chars().flat_map(|c| (c as u32).to_ne_bytes()).collect()
    };
    py_hash_bytes_slice(&buf)
}

/// Interpreter-independent hash of a `bytes` value — the exact value
/// `hash(b)` yields (the same one [`py_hash_value`] computes for
/// `Object::Bytes`). Used by the C-API's faithful `PyBytes_Type.tp_hash`.
pub fn py_bytes_hash(b: &[u8]) -> i64 {
    py_hash_bytes_slice(b)
}

/// Interpreter-independent hash of a surrogate-bearing `WStr` — the exact
/// value [`py_hash_value`] computes for `Object::WStr`. Used by the
/// C-API's faithful `PyUnicode_Type.tp_hash`.
pub fn py_wstr_hash(cps: &[u32]) -> i64 {
    if matches!(hash_algo(), HashAlgo::Fx { .. }) {
        let mut bytes = Vec::with_capacity(cps.len() * 4);
        for &c in cps {
            bytes.extend_from_slice(&c.to_le_bytes());
        }
        return py_hash_bytes_slice(&bytes);
    }
    // Pinned seed: same compact-payload layout as [`py_str_hash`]. Lone
    // surrogates are ordinary BMP code points here, so a surrogate-bearing
    // string hashes over 2-byte units exactly as CPython's UCS2 kind does.
    let max = cps.iter().copied().max().unwrap_or(0);
    let buf: Vec<u8> = if max <= 0xff {
        cps.iter().map(|&c| c as u8).collect()
    } else if max <= 0xffff {
        cps.iter().flat_map(|&c| (c as u16).to_ne_bytes()).collect()
    } else {
        cps.iter().flat_map(|&c| c.to_ne_bytes()).collect()
    };
    py_hash_bytes_slice(&buf)
}

/// Identity-based hash for objects that hash by allocation identity in
/// CPython (functions, types, modules, plain instances without a custom
/// `__hash__`, …). Mirrors CPython's pointer hash: rotate so the low
/// alignment zero-bits don't waste bucket entropy, remapping `-1` to `-2`.
pub(crate) fn identity_hash(obj: &Object) -> i64 {
    fn rot(p: *const ()) -> i64 {
        let u = p as usize as u64;
        let v = u.rotate_right(4) as i64;
        if v == -1 {
            -2
        } else {
            v
        }
    }
    match obj {
        Object::Function(r) => rot(Rc::as_ptr(r).cast()),
        Object::Builtin(r) => rot(Rc::as_ptr(r).cast()),
        // CPython `method_hash`: combine `hash(__self__)` with
        // `hash(__func__)` so two bindings of the same method on the
        // same object hash (and compare) equal. Built-in functions are
        // materialized fresh per access; hash their *name* so the hash
        // agrees with `eq_value`.
        Object::BoundMethod(r) => {
            let self_h = py_hash_value(&r.receiver).unwrap_or_else(|| identity_hash(&r.receiver));
            let func_h = match &r.function {
                Object::Builtin(b) => py_hash_bytes_slice(b.name.as_bytes()),
                f => py_hash_value(f).unwrap_or_else(|| identity_hash(f)),
            };
            let v = self_h ^ func_h.rotate_left(13);
            if v == -1 {
                -2
            } else {
                v
            }
        }
        Object::Code(r) => rot(Rc::as_ptr(r).cast()),
        Object::Cell(r) => rot(Rc::as_ptr(r).cast()),
        Object::Iter(r) => rot(Rc::as_ptr(r).cast()),
        Object::Slice(r) => rot(Rc::as_ptr(r).cast()),
        Object::Type(r) => rot(Rc::as_ptr(r).cast()),
        // A float-subclass instance wrapping a NaN payload hashes like the
        // payload (`hash(F('nan')) == object.__hash__(F('nan'))`,
        // test_float test_hash_nan): WeavePy's NaN identity is the tagged
        // bit pattern (see `tag_nan`), not the wrapper allocation.
        Object::Instance(r) => match r.native.get() {
            Some(f @ Object::Float(v)) if v.is_nan() => identity_hash(f),
            _ => rot(Rc::as_ptr(r).cast()),
        },
        Object::Module(r) => rot(Rc::as_ptr(r).cast()),
        Object::Generator(r) | Object::Coroutine(r) | Object::AsyncGenerator(r) => {
            rot(Rc::as_ptr(r).cast())
        }
        Object::AsyncGenAwait(r) => rot(Rc::as_ptr(r).cast()),
        Object::File(r) => rot(Rc::as_ptr(r).cast()),
        Object::Property(r) => rot(Rc::as_ptr(r).cast()),
        Object::StaticMethod(r) => rot(Rc::as_ptr(r).cast()),
        Object::ClassMethod(r) => rot(Rc::as_ptr(r).cast()),
        Object::SlotDescriptor(r) => rot(Rc::as_ptr(r).cast()),
        Object::Frame(r) => rot(Rc::as_ptr(r).cast()),
        Object::Traceback(r) => rot(Rc::as_ptr(r).cast()),
        Object::MemoryView(r) => rot(Rc::as_ptr(r).cast()),
        // A PEP 585 generic alias hashes by *value* (CPython `ga_hash`:
        // `hash(__origin__) ^ hash(__args__)`), keeping hash consistent
        // with `eq_value`'s content comparison so `{Callable[[int], int],
        // Callable[[int], int]}` dedups. Plain namespaces keep identity.
        Object::SimpleNamespace(r) => {
            let d = r.borrow();
            let is_union = d
                .get(&DictKey(Object::from_static("__is_pep604_union__")))
                .is_some();
            let origin = d.get(&DictKey(Object::from_static("__origin__")));
            let args = d.get(&DictKey(Object::from_static("__args__")));
            if is_union {
                // CPython `union_hash`: hash of the frozenset of args, so
                // `int | str` and `str | int` collide as required by `==`.
                let mut acc: i64 = 0;
                if let Some(Object::Tuple(items)) = args {
                    for it in items.iter() {
                        acc ^= py_hash_value(it).unwrap_or_else(|| identity_hash(it));
                    }
                }
                if acc == -1 {
                    -2
                } else {
                    acc
                }
            } else if let (Some(origin), Some(args)) = (origin, args) {
                let h1 = py_hash_value(origin).unwrap_or_else(|| identity_hash(origin));
                let h2 = py_hash_value(args).unwrap_or_else(|| identity_hash(args));
                let v = h1 ^ h2;
                if v == -1 {
                    -2
                } else {
                    v
                }
            } else {
                rot(Rc::as_ptr(r).cast())
            }
        }
        Object::LazyIter(r) => rot(Rc::as_ptr(r).cast()),
        Object::Capsule(r) => rot(Rc::as_ptr(r).cast()),
        // Identity hash keyed on the foreign `PyObject*` (matches the
        // `is`-identity used by `eq`/`id`). A value-hashable foreign
        // object (numpy scalar) is handled earlier via the hash hook.
        Object::Foreign(s) => rot((s.ptr as *const u8).cast()),
        // A float's "identity" is its (NaN-tagged) bit pattern — the same
        // derivation `py_hash_double` uses for NaN, so
        // `object.__hash__(nan) == hash(nan)` (test_float test_hash_nan,
        // CPython gh-43475 hashes NaN by object identity).
        Object::Float(v) => {
            let h =
                (v.to_bits().rotate_right(4) as i64).wrapping_mul(0x9E37_79B9_7F4A_7C15u64 as i64);
            if h == -1 {
                -2
            } else {
                h
            }
        }
        // Value-hashable variants never reach here (handled by
        // `py_hash_value`); anything else gets a stable constant.
        _ => 0,
    }
}

/// Whether an instance's wrapped `native` value (the primitive an
/// `int`/`str`/… subclass *is*) is one of the **immutable** builtins, so a
/// custom `__hash__` derived from it is constant and safe to memoise on the
/// instance. Mutable wrappers (`list`/`dict`/`set`/`bytearray`) and the
/// `None`/absent case are excluded — see [`PyInstance::hash_cache`].
fn native_is_immutable(native: Option<&Object>) -> bool {
    matches!(
        native,
        Some(
            Object::Int(_)
                | Object::Long(_)
                | Object::Bool(_)
                | Object::Float(_)
                | Object::Complex(_)
                | Object::Str(_)
                | Object::Bytes(_)
                | Object::Tuple(_)
                | Object::FrozenSet(_)
        )
    )
}

/// Canonical Python `hash(obj)` value, shared by the `hash()` builtin and
/// the [`DictKey`] hasher. Bucketing every key by this single value (rather
/// than a type-tagged structural hash) is what lets objects Python considers
/// equal-and-hashable collide regardless of Rust representation — e.g. a
/// custom `__hash__` returning `hash('halibut')` buckets with the actual
/// string, so a `set`/`dict` can dedup them via [`DictKey::eq`].
///
/// Returns `None` for objects with no *value* hash (identity-hashable or
/// unhashable); callers fall back to [`identity_hash`].
/// CPython 3.13 `tuplehash` (Objects/tupleobject.c), bit-exact: an
/// xxHash-derived mix over the element hashes. `test_tuple`'s
/// `test_hash_exact` pins specific 64-bit results, so the constants and the
/// rotate/multiply order must match CPython exactly. Shared by the value
/// hasher below and the interpreter's `hash()` (which dispatches each lane's
/// `__hash__` so element errors propagate).
pub(crate) struct TupleHasher {
    acc: u64,
}

impl TupleHasher {
    const PRIME_1: u64 = 11_400_714_785_074_694_791;
    const PRIME_2: u64 = 14_029_467_366_897_019_727;
    const PRIME_5: u64 = 2_870_177_450_012_600_261;

    pub(crate) fn new() -> Self {
        Self { acc: Self::PRIME_5 }
    }

    pub(crate) fn push(&mut self, lane: i64) {
        self.acc = self
            .acc
            .wrapping_add((lane as u64).wrapping_mul(Self::PRIME_2));
        self.acc = self.acc.rotate_left(31).wrapping_mul(Self::PRIME_1);
    }

    pub(crate) fn finish(self, len: usize) -> i64 {
        let value = self
            .acc
            .wrapping_add((len as u64) ^ (Self::PRIME_5 ^ 3_527_539)) as i64;
        if value == -1 {
            1_546_275_796
        } else {
            value
        }
    }
}

pub(crate) fn combine_tuple_hash(lanes: &[i64]) -> i64 {
    let mut hash = TupleHasher::new();
    for &lane in lanes {
        hash.push(lane);
    }
    hash.finish(lanes.len())
}

/// The hash previously *recorded* for `obj` when it was hashed for a keyed
/// table — the WeavePy stand-in for CPython's per-entry `ep->me_hash`. Only
/// instances carry a record (the `hash_cache` cell, written by every
/// [`py_hash_value`] dispatch of a custom `__hash__`); everything else
/// hashes purely, so `None` just means "compute it".
///
/// Used by the same-bucket preconditions in [`DictKey::eq`] and
/// [`dict_reentrant_probe`]: CPython compares the probe hash against the
/// *stored entry's* hash and never re-invokes a stored key's `__hash__`
/// (`test_dict.test_setdefault_atomic` counts the dispatches).
pub(crate) fn recorded_key_hash(obj: &Object) -> Option<i64> {
    match obj {
        Object::Instance(inst) => inst.hash_cache.get(),
        _ => None,
    }
}

/// CPython's `frozenset_hash` mixing (Objects/setobject.c) over
/// pre-computed element hashes. Shared by the frozenset arm of
/// [`py_hash_value`] and the PEP 604 union arm (`union_hash` is defined
/// as `hash(frozenset(args))`).
fn frozenset_style_hash<I: Iterator<Item = i64>>(lanes: I) -> i64 {
    let mut acc: u64 = 0;
    let mut n: u64 = 0;
    for eh in lanes {
        let eh = eh as u64;
        acc ^= (eh ^ (eh << 16) ^ 89_869_747).wrapping_mul(3_644_798_167);
        n += 1;
    }
    acc ^= n.wrapping_add(1).wrapping_mul(1_927_868_237);
    acc ^= (acc >> 11) ^ (acc >> 25);
    acc = acc.wrapping_mul(69_069).wrapping_add(907_133_923);
    let v = acc as i64;
    if v == -1 {
        590_923_713
    } else {
        v
    }
}

pub(crate) fn py_hash_value(obj: &Object) -> Option<i64> {
    if let Some(h) = numeric_hash(obj) {
        return Some(h);
    }
    match obj {
        Object::None => Some(PY_HASH_NONE),
        Object::Str(s) => Some(py_str_hash(s)),
        // Code objects compare by value (`code_value_eq`), so they must
        // also hash by value or value-equal codes land in different
        // set/dict buckets (CPython `code_hash`).
        Object::Code(c) => Some(code_value_hash(c)),
        // Surrogate-bearing string: hash the code-point sequence. Need only be
        // deterministic and self-consistent — a `WStr` never equals a `Str`
        // (disjoint by invariant), so cross-representation hash agreement is
        // unnecessary; collisions only cost a probe, never correctness.
        Object::WStr(cps) => Some(py_wstr_hash(cps)),
        Object::Bytes(b) => Some(py_hash_bytes_slice(b)),
        // A read-only byte-format view hashes as its contents — equal to the
        // hash of `tobytes()` regardless of alignment or strides (CPython
        // `memory_hash`; test_hash.test_unaligned_buffers). The value is
        // computed once and cached, so a released view keeps answering it.
        // The error cases (released / writable / non-byte format) are
        // rejected up front by `ensure_hashable`; a view that reaches here
        // unvetted falls back to identity below.
        Object::MemoryView(mv) if mv.hash.get() != -1 => Some(mv.hash.get()),
        Object::MemoryView(mv)
            if !mv.released.get()
                && mv.readonly.get()
                && matches!(mv.format.borrow().as_str(), "B" | "b" | "c") =>
        {
            let h = py_hash_bytes_slice(&mv.to_bytes());
            mv.hash.set(h);
            Some(h)
        }
        Object::Tuple(items) => {
            if let Some(hash) = items.cached_hash() {
                return Some(hash);
            }
            // Hash table callbacks communicate errors through the ambient
            // scope. Isolate this walk so a failed lane is never cached,
            // and stop before invoking any later element's hash method.
            match key_cmp_scope(|| {
                let mut hash = TupleHasher::new();
                for item in items.iter() {
                    if let Err(error) = crate::builtins::ensure_hashable(item) {
                        stash_key_cmp_error(error);
                        return None;
                    }
                    let lane = py_hash_value(item).unwrap_or_else(|| identity_hash(item));
                    if key_cmp_error_pending() {
                        return None;
                    }
                    hash.push(lane);
                }
                Some(hash.finish(items.len()))
            }) {
                Ok(hash) => {
                    if let Some(hash) = hash {
                        // Rust bootstrap code can build keyed tables before
                        // an interpreter exists. A custom hash then falls
                        // back to identity; don't memoize that placeholder.
                        if crate::vm_singletons::current_interpreter_ptr().is_some()
                            || items.iter().all(|item| {
                                matches!(
                                    item,
                                    Object::Int(_)
                                        | Object::Long(_)
                                        | Object::Float(_)
                                        | Object::Complex(_)
                                        | Object::Bool(_)
                                        | Object::None
                                        | Object::Str(_)
                                        | Object::WStr(_)
                                        | Object::Bytes(_)
                                        | Object::Range(_)
                                )
                            })
                        {
                            items.store_hash(hash);
                        }
                    }
                    hash
                }
                Err(error) => {
                    stash_key_cmp_error(error);
                    None
                }
            }
        }
        // Slices hash since 3.12 (gh-101335): CPython `slicehash` builds
        // the `(start, stop, step)` tuple and hashes that. Unhashable
        // members are rejected earlier by `ensure_hashable`.
        Object::Slice(s) => {
            let lanes: Vec<i64> = [&s.start, &s.stop, &s.step]
                .into_iter()
                .map(|x| py_hash_value(x).unwrap_or_else(|| identity_hash(x)))
                .collect();
            Some(combine_tuple_hash(&lanes))
        }
        Object::FrozenSet(s) => {
            // A frozenset is immutable, so its hash is computed once and
            // cached (CPython's `so_hash`). This is not just an optimisation:
            // nested frozensets would otherwise re-hash their whole
            // sub-structure on every call (exponential for von Neumann
            // ordinals — see `FrozenSetObj`).
            if let Some(h) = s.cached_hash() {
                return Some(h);
            }
            // CPython's `frozenset_hash` (Objects/setobject.c), bit-exact:
            // `collections.abc.Set._hash` reimplements the same algorithm
            // in Python and the two must agree (`hash(fs) == Set._hash(fs)`).
            let v = frozenset_style_hash(
                s.iter()
                    .map(|k| py_hash_value(&k.0).unwrap_or_else(|| identity_hash(&k.0))),
            );
            s.store_hash(v);
            Some(v)
        }
        // A PEP 604 union hashes as `hash(frozenset(__args__))` (CPython
        // `union_hash`) — the same value typing's `_UnionGenericAlias.
        // __hash__` computes, so `d[typing.Optional[T]]` is findable with
        // the `T | None` spelling (RFC 0076 WS5: torch's `infer_schema`
        // keys `SUPPORTED_PARAM_TYPES` by the typing forms and probes
        // with the annotation as written). Without this arm the union
        // fell to `identity_hash` and the probe landed in the wrong
        // bucket even though `==` and builtin `hash()` both agreed.
        Object::SimpleNamespace(_) => {
            let members = crate::is_pep604_union(obj)?;
            Some(frozenset_style_hash(members.iter().map(|m| {
                py_hash_value(m).unwrap_or_else(|| identity_hash(m))
            })))
        }
        Object::Instance(inst) => {
            // A `weakref.ref` hashes as its referent (CPython `weakref_hash`),
            // computed natively and memoised so the hot `DictKey` path never
            // pays a reentrant `__hash__` dispatch — see `weakref_native_hash`.
            if let Some(h) = crate::stdlib::weakref_real::weakref_native_hash(obj) {
                return Some(h);
            }
            // A user-defined `__hash__` outranks the wrapped value's hash —
            // e.g. functools' `_HashedSeq(list)` caches its hash precisely so
            // the (unhashable) list payload is never consulted.
            if instance_has_custom_dunder(obj, "__hash__") {
                // When the instance wraps an *immutable* builtin value (an
                // `int`/`str`/`tuple`/… subclass), the value can't change, so
                // a custom `__hash__` is genuinely constant and may be
                // memoised. This is what makes CPython's hash-table reuse
                // (`set(dict)`, `dict.fromkeys(set)`, `s.difference(d)`, …)
                // observe exactly **one** `__hash__` call per element
                // (`test_set`/`test_dict::test_do_not_rehash_dict_keys`).
                //
                // A plain `object` subclass with a side-effecting or
                // conditionally-raising `__hash__` (test_dict's `BadHash`)
                // wraps no native value, so it is *never* cached and is
                // re-invoked on every probe exactly like CPython.
                if native_is_immutable(inst.native.get()) {
                    if let Some(h) = inst.hash_cache.get() {
                        return Some(h);
                    }
                    let h = current_interp_hash(obj);
                    if let Some(h) = h {
                        inst.hash_cache.store(h);
                    }
                    return h;
                }
                // Mutable wrapper (or plain object subclass): dispatch on
                // every call, but *record* the result. The record is never
                // read back here — it stands in for CPython's entry-stored
                // hash (`ep->me_hash`): when a table probe needs the hash of
                // an already-*stored* key for the same-bucket precondition
                // (`DictKey::eq` / `dict_reentrant_probe`), CPython reads the
                // entry, never re-invoking `__hash__` — `test_dict`'s
                // `test_setdefault_atomic` counts exactly one call per key.
                let h = current_interp_hash(obj);
                if let Some(hv) = h {
                    inst.hash_cache.store(hv);
                }
                return h;
            }
            if let Some(native) = inst.native.get() {
                // int/str/… subclass instance hashes as the wrapped value.
                return py_hash_value(native);
            }
            // Custom `__hash__` via the interpreter; `None` (no active
            // interpreter or only the inherited identity hash) falls through
            // to `identity_hash` at the call site.
            current_interp_hash(obj)
        }
        // A foreign extension scalar (numpy `int64`/`float64`/`bool_`, …)
        // hashes through its own `tp_hash` slot so it collides with the equal
        // Python scalar in a dict/set — CPython guarantees
        // `hash(np.int64(0)) == hash(0)`. numpy's `np.roll` keys its `shifts`
        // dict by axis with numpy ints, then looks it up with the Python-int
        // axis; without the shared hash the lookup raises `KeyError`. The
        // `no_gil_handoff` guard mirrors `current_interp_hash`: this may run
        // while a container holds its cell mutex during a probe.
        Object::Foreign(s) => {
            let _no_yield = crate::gil::no_gil_handoff();
            match crate::foreign::hash(s) {
                Ok(hash) => Some(hash),
                Err(error) => {
                    stash_key_cmp_error(error);
                    None
                }
            }
        }
        // `range` hashes as CPython's `range_hash`: the hash of the
        // `(length, start | None, step | None)` triple. Collapsing start/step
        // to `None` for empty / length-1 ranges keeps the hash in lock-step
        // with `eq_value` above — equal ranges (same generated sequence) share
        // a hash and can therefore key a `dict`/`set` (or a pandas index).
        Object::Range(r) => {
            let len = range_len_bigint(r);
            let zero = BigInt::from(0);
            let (start_obj, step_obj) = if len == zero {
                (Object::None, Object::None)
            } else if len == BigInt::from(1) {
                (r.start_obj(), Object::None)
            } else {
                (r.start_obj(), r.step_obj())
            };
            let triple =
                Object::new_tuple_array([Object::int_from_bigint(len), start_obj, step_obj]);
            py_hash_value(&triple)
        }
        _ => None,
    }
}

pub(crate) fn bigint_from_f64_trunc(f: f64) -> BigInt {
    // 32-bit-sized chunks; works for any finite float.
    if f == 0.0 {
        return BigInt::from(0);
    }
    let neg = f < 0.0;
    let mut x = f.abs();
    let mut bytes: Vec<u8> = Vec::new();
    while x >= 1.0 {
        let lo = (x % 256.0) as u8;
        bytes.push(lo);
        x = (x / 256.0).floor();
    }
    bytes.reverse();
    let bi = BigInt::from_bytes_be(num_bigint::Sign::Plus, &bytes);
    if neg {
        -bi
    } else {
        bi
    }
}

/// Python's shortest float representation, including ties-to-even
/// decimal rounding and its fixed/scientific notation boundaries.
pub fn float_repr(f: f64) -> String {
    let mut out = String::with_capacity(24);
    write_float_repr(&mut out, f).expect("writing to a String cannot fail");
    out
}

/// Write directly into the caller's output without temporary heap strings.
pub(crate) fn write_float_repr(out: &mut impl fmt::Write, f: f64) -> fmt::Result {
    if f.is_nan() {
        return out.write_str("nan");
    }
    if f.is_infinite() {
        return out.write_str(if f < 0.0 { "-inf" } else { "inf" });
    }
    if f.is_sign_negative() {
        out.write_char('-')?;
    }
    // Zmij supplies shortest, correctly rounded digits in a stack buffer.
    // Its fixed notation includes exponent -5; Python switches at -4.
    // Python also pads single-digit scientific exponents with a zero.
    let mut buffer = zmij::Buffer::new();
    let text = buffer.format_finite(f.abs());
    if let Some((mantissa, exponent)) = text.split_once('e') {
        out.write_str(mantissa)?;
        out.write_char('e')?;
        if exponent.len() == 2 {
            out.write_str(&exponent[..1])?;
            out.write_char('0')?;
            out.write_str(&exponent[1..])
        } else {
            out.write_str(exponent)
        }
    } else if let Some(digits) = text.strip_prefix("0.0000") {
        out.write_str(&digits[..1])?;
        if digits.len() > 1 {
            out.write_char('.')?;
            out.write_str(&digits[1..])?;
        }
        out.write_str("e-05")
    } else {
        out.write_str(text)
    }
}

/// Fixed-capacity text for native scalar spellings. Appending complete
/// strings keeps the initialized prefix valid UTF-8 without unsafe code.
struct StackText<const N: usize> {
    bytes: [u8; N],
    len: usize,
}

impl<const N: usize> StackText<N> {
    fn new() -> Self {
        Self {
            bytes: [0; N],
            len: 0,
        }
    }

    fn as_str(&self) -> &str {
        std::str::from_utf8(&self.bytes[..self.len]).expect("complete UTF-8 fragments")
    }
}

impl<const N: usize> fmt::Write for StackText<N> {
    fn write_str(&mut self, text: &str) -> fmt::Result {
        let end = self.len.checked_add(text.len()).ok_or(fmt::Error)?;
        self.bytes
            .get_mut(self.len..end)
            .ok_or(fmt::Error)?
            .copy_from_slice(text.as_bytes());
        self.len = end;
        Ok(())
    }
}

/// Exact native scalars have the same `str` and `repr`. Build their Python
/// string directly, avoiding an intermediate heap-allocated Rust String.
/// Subclasses and large integers retain their protocol and digit-limit paths.
pub(crate) fn native_scalar_repr(value: &Object) -> Option<Object> {
    Some(match value {
        Object::Int(value) => Object::Str(SharedStr::from(itoa::Buffer::new().format(*value))),
        Object::Float(value) => {
            let mut text = StackText::<32>::new();
            write_float_repr(&mut text, *value).expect("float text fits in 32 bytes");
            Object::Str(SharedStr::from(text.as_str()))
        }
        Object::Complex(value) => {
            let mut text = StackText::<64>::new();
            write_complex_repr(&mut text, value.real, value.imag)
                .expect("complex text fits in 64 bytes");
            Object::Str(SharedStr::from(text.as_str()))
        }
        Object::Bool(true) => Object::from_static("True"),
        Object::Bool(false) => Object::from_static("False"),
        Object::None => Object::from_static("None"),
        _ => return None,
    })
}

/// `repr`-shortest rendering of a single complex component. Unlike
/// `float`, CPython renders integer-valued complex components without a
/// trailing `.0` (e.g. `4j`, not `4.0j`), but otherwise uses the same
/// shortest/exponential rules.
pub(crate) fn complex_component_repr(p: f64) -> String {
    let mut text = StackText::<32>::new();
    write_float_repr(&mut text, p).expect("float text fits in 32 bytes");
    text.as_str()
        .strip_suffix(".0")
        .unwrap_or(text.as_str())
        .to_owned()
}

pub(crate) fn complex_repr(real: f64, imag: f64) -> String {
    let mut text = String::with_capacity(52);
    write_complex_repr(&mut text, real, imag).expect("writing to a String cannot fail");
    text
}

fn write_complex_repr(out: &mut impl fmt::Write, real: f64, imag: f64) -> fmt::Result {
    let mut im = StackText::<32>::new();
    write_float_repr(&mut im, imag)?;
    let im = im.as_str().strip_suffix(".0").unwrap_or(im.as_str());
    if real == 0.0 && real.is_sign_positive() {
        out.write_str(im)?;
        out.write_char('j')
    } else {
        // Insert the joining sign based on the *rendered* imaginary part,
        // not its raw sign bit: `-nan` keeps a set sign bit yet renders as
        // "nan" (no leading '-'), so CPython prints `(nan+nanj)`, and a
        // genuine negative like -2.0 renders "-2" and needs no extra '+'.
        let mut re = StackText::<32>::new();
        write_float_repr(&mut re, real)?;
        let re = re.as_str().strip_suffix(".0").unwrap_or(re.as_str());
        out.write_char('(')?;
        out.write_str(re)?;
        if !im.starts_with('-') {
            out.write_char('+')?;
        }
        out.write_str(im)?;
        out.write_str("j)")
    }
}

fn bytes_contains(haystack: &[u8], needle: &[u8]) -> bool {
    if needle.is_empty() {
        return true;
    }
    memchr::memmem::find(haystack, needle).is_some()
}

/// `x in bytes` / `x in bytearray`: a byte value (int in
/// `range(0, 256)`, out-of-range is `ValueError`) or a bytes-like
/// needle. Anything else is the CPython `TypeError`.
fn bytes_membership(haystack: &[u8], item: &Object) -> Result<bool, RuntimeError> {
    let native = item.native_value();
    match native.as_ref().unwrap_or(item) {
        Object::Bool(v) => Ok(haystack.contains(&u8::from(*v))),
        Object::Int(i) => {
            if (0..=255).contains(i) {
                Ok(haystack.contains(&(*i as u8)))
            } else {
                Err(value_error("byte must be in range(0, 256)"))
            }
        }
        Object::Long(_) => Err(value_error("byte must be in range(0, 256)")),
        Object::Bytes(needle) => Ok(bytes_contains(haystack, needle)),
        Object::ByteArray(needle) => Ok(bytes_contains(haystack, &needle.borrow())),
        Object::MemoryView(mv) => Ok(bytes_contains(haystack, &mv.to_bytes())),
        inst @ Object::Instance(_) if crate::instance_method(inst, "__index__").is_some() => {
            let v = crate::builtins::coerce_index_i64(inst)?;
            if (0..=255).contains(&v) {
                Ok(haystack.contains(&(v as u8)))
            } else {
                Err(value_error("byte must be in range(0, 256)"))
            }
        }
        _ => Err(type_error(
            "a bytes-like object is required, not '".to_owned() + item.type_name() + "'",
        )),
    }
}

/// CPython's `Py_UNICODE_ISPRINTABLE`: every character is printable
/// except those in the "Other" (Cc, Cf, Cs, Co, Cn) and "Separator"
/// (Zl, Zp, Zs) general categories, with U+0020 (space) treated as
/// printable. Used by `repr(str)` (and `str.isprintable`).
/// `Py_UNICODE_ISPRINTABLE`, from the generated UCD 16.0.0 tables (the
/// `unicode_properties` crate tracks a newer UCD and drifts on newly
/// assigned code points).
pub(crate) fn char_is_printable(c: char) -> bool {
    crate::unicode_case::is_printable(c)
}

fn bytes_repr(b: &[u8]) -> String {
    bytes_repr_inner(b, true)
}

/// `smartquotes`: `bytes` repr only escapes the active quote character
/// (PyBytes_Repr with smartquotes=1); `bytearray`'s body always
/// backslash-escapes single quotes regardless of the chosen delimiter
/// (Objects/bytearrayobject.c `bytearray_repr`) — so
/// `repr(bytearray(b"'"))` is `bytearray(b"\'")`.
fn bytes_repr_inner(b: &[u8], smartquotes: bool) -> String {
    // CPython prefers single quotes, switching to double quotes when
    // the data contains a single quote but no double quote.
    let quote = if b.contains(&b'\'') && !b.contains(&b'"') {
        b'"'
    } else {
        b'\''
    };
    let mut out = String::with_capacity(b.len() + 3);
    out.push('b');
    out.push(quote as char);
    for &c in b {
        match c {
            b'\\' => out.push_str("\\\\"),
            c if c == quote || (!smartquotes && c == b'\'') => {
                out.push('\\');
                out.push(c as char);
            }
            b'\n' => out.push_str("\\n"),
            b'\r' => out.push_str("\\r"),
            b'\t' => out.push_str("\\t"),
            0x20..=0x7E => out.push(c as char),
            _ => out.push_str(&format!("\\x{c:02x}")),
        }
    }
    out.push(quote as char);
    out
}

/// Render a native `set`/`frozenset` payload tagged with `type_name`,
/// reproducing CPython `set_repr`'s `Py_TYPE(so) != &PySet_Type` branch.
/// The `set.__repr__`/`frozenset.__repr__` slot wrappers use this so an
/// explicit `set.__repr__(subclass_instance)` (as in `class S(set): def
/// __repr__(self): return set.__repr__(self)`) still spells the subclass
/// name rather than the base `{…}` form. Returns `None` for non-set payloads.
pub(crate) fn set_repr_tagged(native: &Object, type_name: &str) -> Option<String> {
    match native {
        Object::Set(s) => Some(set_repr(
            &set_items(&s.borrow()),
            type_name,
            Rc::as_ptr(s).cast::<()>() as usize,
        )),
        Object::FrozenSet(s) => Some(set_repr(
            &set_items(s),
            type_name,
            Rc::as_ptr(s).cast::<()>() as usize,
        )),
        _ => None,
    }
}

/// Snapshot a set payload's elements as owned `Object`s. CPython's
/// `set_repr` first materialises the keys (`PySequence_List`) so the set's
/// own borrow is released before any element `__repr__` runs — an element
/// that mutates the set then can't panic the `RefCell`.
fn set_items(s: &SetData) -> Vec<Object> {
    s.iter().map(|k| k.0.clone()).collect()
}

/// Render a `set`/`frozenset`/subclass whose (already-snapshotted) elements
/// are `items`, tagged with `name` (the type's name). `id` is the payload's
/// identity for the recursive-`repr` guard, so a self-referential set renders
/// `name(...)` — exactly CPython `set_repr`'s `Py_ReprEnter` returning the
/// `"%s(...)"` marker keyed on `Py_TYPE(so)->tp_name`.
fn set_repr(items: &[Object], name: &str, id: usize) -> String {
    if !repr_enter(id) {
        return format!("{name}(...)");
    }
    if items.is_empty() {
        repr_leave();
        return format!("{name}()");
    }
    let mut out = String::new();
    let use_braces = name == "set";
    if !use_braces {
        out.push_str(name);
        out.push('(');
    }
    out.push('{');
    for (i, k) in items.iter().enumerate() {
        if i > 0 {
            out.push_str(", ");
        }
        out.push_str(&k.repr());
    }
    out.push('}');
    if !use_braces {
        out.push(')');
    }
    repr_leave();
    out
}

fn seq_cmp(a: &[Object], b: &[Object]) -> Result<Ordering, RuntimeError> {
    for (x, y) in a.iter().zip(b.iter()) {
        // CPython's sequence comparison first scans for the first *non-equal*
        // pair (identity-shortcut `==` via `PyObject_RichCompareBool`), and
        // only that pair is ordered with `<`. Identical-but-unorderable
        // elements therefore never see the ordering op: sorting
        // `[(Timestamp, "day"), (Timestamp, "floor")]` compares the two type
        // objects for equality only (pandas' `test_nat` builds exactly this).
        // The old `cmp`-first walk raised `'<' not supported` on the tie.
        if member_eq(x, y)? {
            continue;
        }
        return x.cmp(y);
    }
    Ok(a.len().cmp(&b.len()))
}

// ---------- factory helpers ----------

impl Object {
    pub fn from_str(s: impl Into<String>) -> Self {
        Object::Str(SharedStr::from(s.into().as_str()))
    }

    /// Build a `str` from a sequence of code points, each a Unicode scalar
    /// value *or* a lone surrogate (U+D800..U+DFFF). Canonicalises: if no lone
    /// surrogate is present the result is a normal [`Object::Str`] (so the
    /// common path keeps the compact `SharedStr` representation and ordinary
    /// `str` fast paths); only a genuinely surrogate-bearing string becomes an
    /// [`Object::WStr`]. This is the single chokepoint that preserves the
    /// "`WStr` always holds >= 1 surrogate" invariant.
    pub fn str_from_codepoints(cps: Vec<u32>) -> Self {
        if cps.iter().any(|&c| (0xD800..=0xDFFF).contains(&c)) {
            Object::WStr(SharedSlice::from(cps.into_boxed_slice()))
        } else {
            // No surrogates: every code point is a valid scalar value.
            let mut s = String::with_capacity(cps.len());
            for c in cps {
                // Safe: the surrogate range was just excluded, and code points
                // are produced by `char`-range-checked callers.
                if let Some(ch) = char::from_u32(c) {
                    s.push(ch);
                }
            }
            Object::Str(SharedStr::from(s.as_str()))
        }
    }

    /// Code points of a `str`/`WStr` as `u32`s (scalar values, plus lone
    /// surrogates for `WStr`). Returns `None` for non-string objects.
    pub fn str_codepoints(&self) -> Option<Vec<u32>> {
        match self {
            Object::Str(s) => Some(s.chars().map(|c| c as u32).collect()),
            Object::WStr(cps) => Some(cps.to_vec()),
            _ => None,
        }
    }

    /// True for either string representation (`str` or surrogate-bearing
    /// `WStr`). Use at "is this a str?" dispatch points so a `WStr` is treated
    /// as the `str` it is.
    pub fn is_str(&self) -> bool {
        matches!(self, Object::Str(_) | Object::WStr(_))
    }

    /// Identity-stable string: repeated calls with the same text return
    /// the *same* `SharedStr` allocation. Used where CPython exposes a
    /// stored string with stable identity — e.g. `cls.__name__`, which
    /// `inspect.classify_class_attrs` compares with `is`.
    pub fn interned_str(s: &str) -> Self {
        use std::collections::HashSet;
        use std::sync::{Mutex, OnceLock};
        // The canonical string is also the key; don't duplicate its text.
        static TABLE: OnceLock<Mutex<HashSet<SharedStr>>> = OnceLock::new();
        let table = TABLE.get_or_init(|| Mutex::new(HashSet::new()));
        let mut t = table.lock().unwrap();
        if let Some(rc) = t.get(s) {
            return Object::Str(rc.clone());
        }
        let rc: SharedStr = SharedStr::from(s);
        t.insert(rc.clone());
        Object::Str(rc)
    }

    pub fn from_static(s: &'static str) -> Self {
        Object::Str(SharedStr::from(s))
    }

    pub fn new_list(items: Vec<Object>) -> Self {
        Object::List(Rc::new(RefCell::new(items)))
    }

    pub fn new_tuple(items: Vec<Object>) -> Self {
        if items.is_empty() {
            // CPython interns the empty tuple (`() is ()`);
            // `functools.update_wrapper` asserts identity on copied
            // `__type_params__` and similar empty-tuple attributes.
            thread_local! {
                static EMPTY_TUPLE: crate::object::SharedTuple = TupleStorage::from_array([]);
            }
            return Object::Tuple(EMPTY_TUPLE.with(Clone::clone));
        }
        Object::Tuple(TupleStorage::from_vec(items))
    }

    /// Build a fixed-size tuple directly in reference-counted storage,
    /// avoiding an intermediate vector allocation. Empty arrays retain
    /// the ordinary constructor's interned empty tuple.
    #[inline]
    pub fn new_tuple_array<const N: usize>(items: [Object; N]) -> Self {
        if N == 0 {
            return Self::new_tuple(Vec::new());
        }
        Object::Tuple(TupleStorage::from_array(items))
    }

    pub fn new_dict() -> Self {
        Object::Dict(Rc::new(RefCell::new(DictData::default())))
    }

    /// Build a fresh module value whose dict is empty.
    pub fn new_module(name: impl Into<String>, filename: Option<String>) -> Self {
        Object::Module(Rc::new(PyModule {
            name: name.into(),
            filename,
            dict: Rc::new(RefCell::new(DictData::default())),
        }))
    }

    pub fn new_set() -> Self {
        Object::Set(Rc::new(RefCell::new(SetData::default())))
    }

    pub fn new_set_from(iter: impl IntoIterator<Item = Object>) -> Self {
        let mut s = SetData::default();
        for v in iter {
            s.insert(DictKey(v));
        }
        Object::Set(Rc::new(RefCell::new(s)))
    }

    pub fn new_frozenset_from(iter: impl IntoIterator<Item = Object>) -> Self {
        let mut s = SetData::default();
        for v in iter {
            s.insert(DictKey(v));
        }
        if s.is_empty() {
            // CPython serves a shared empty-frozenset singleton:
            // `frozenset() is frozenset()` and the compiled constant
            // `frozenset()` are the same object (test_ast
            // ConstantTests.test_singletons).
            static EMPTY: std::sync::OnceLock<Rc<FrozenSetObj>> = std::sync::OnceLock::new();
            return Object::FrozenSet(
                EMPTY
                    .get_or_init(|| Rc::new(FrozenSetObj::new(SetData::default())))
                    .clone(),
            );
        }
        Object::FrozenSet(Rc::new(FrozenSetObj::new(s)))
    }

    pub fn new_bytes(data: impl Into<Vec<u8>>) -> Self {
        let v = data.into();
        if v.is_empty() {
            // CPython caches the empty bytes object (`b"" is b""` across
            // compiles — test_ast ConstantTests.test_singletons).
            static EMPTY: std::sync::OnceLock<SharedSlice<u8>> = std::sync::OnceLock::new();
            return Object::Bytes(EMPTY.get_or_init(|| SharedSlice::from(&[][..])).clone());
        }
        Object::Bytes(SharedSlice::from(v.as_slice()))
    }

    pub fn new_bytearray(data: impl Into<Vec<u8>>) -> Self {
        Object::ByteArray(Rc::new(RefCell::new(data.into())))
    }

    /// Construct an integer object from a `BigInt`. Auto-demotes to
    /// `Object::Int(i64)` when the value fits, preserving the
    /// small-int fast path.
    pub fn int_from_bigint(b: BigInt) -> Self {
        match b.to_i64() {
            Some(v) => Object::Int(v),
            None => Object::Long(Rc::new(b)),
        }
    }

    /// Construct an integer from an i128, promoting to `Long` when
    /// the value doesn't fit in `i64`.
    pub fn int_from_i128(v: i128) -> Self {
        if let Ok(small) = i64::try_from(v) {
            Object::Int(small)
        } else {
            Object::Long(Rc::new(BigInt::from(v)))
        }
    }

    /// Construct a complex number.
    pub fn new_complex(real: f64, imag: f64) -> Self {
        Object::Complex(Rc::new(PyComplex::new(real, imag)))
    }

    /// View this object as a `BigInt`, treating `Bool`/`Int`/`Long`
    /// uniformly. Returns `None` for any other type.
    pub fn as_bigint(&self) -> Option<BigInt> {
        match self {
            Object::Bool(b) => Some(BigInt::from(i64::from(*b))),
            Object::Int(i) => Some(BigInt::from(*i)),
            Object::Long(b) => Some((**b).clone()),
            _ => None,
        }
    }

    /// View this object as `i64`, succeeding only when the value
    /// genuinely fits in 64 bits. Returns `None` for `Long`s that
    /// don't fit, and for non-integer types.
    /// For an instance of a subclass of a primitive built-in
    /// (`int`, `str`, …) return a clone of the underlying value the
    /// instance wraps; `None` for everything else. The wrapped value
    /// is always itself a primitive (never another `Instance`), so
    /// callers can recurse exactly once.
    #[inline]
    pub fn native_value(&self) -> Option<Object> {
        match self {
            Object::Instance(inst) => inst.native.get().cloned(),
            _ => None,
        }
    }

    pub fn as_i64(&self) -> Option<i64> {
        match self {
            Object::Bool(b) => Some(i64::from(*b)),
            Object::Int(i) => Some(*i),
            Object::Long(b) => b.to_i64(),
            Object::Instance(inst) => inst.native.get().and_then(Object::as_i64),
            _ => None,
        }
    }

    /// View this object as a non-negative `usize`, returning `None`
    /// for negative or out-of-range values.
    pub fn as_usize(&self) -> Option<usize> {
        match self {
            Object::Bool(b) => Some(usize::from(*b)),
            Object::Int(i) if *i >= 0 => usize::try_from(*i).ok(),
            Object::Long(b) if !b.is_negative() => b.to_usize(),
            Object::Instance(inst) => inst.native.get().and_then(Object::as_usize),
            _ => None,
        }
    }

    /// Test whether this object is `int`-flavoured (Bool, Int, or
    /// Long). Useful in the VM where the slot machinery treats all
    /// three uniformly.
    pub fn is_int_like(&self) -> bool {
        matches!(self, Object::Bool(_) | Object::Int(_) | Object::Long(_))
    }

    /// View this object as `f64`, with float / int / bool / long all
    /// converting losslessly-where-possible.
    pub fn as_f64(&self) -> Option<f64> {
        match self {
            Object::Bool(b) => Some(f64::from(i32::from(*b))),
            Object::Int(i) => Some(*i as f64),
            Object::Long(b) => b.to_f64(),
            Object::Float(f) => Some(*f),
            _ => None,
        }
    }

    /// View as `(real, imag)`. Includes int → real promotion.
    pub fn as_complex(&self) -> Option<(f64, f64)> {
        match self {
            Object::Complex(c) => Some((c.real, c.imag)),
            other => other.as_f64().map(|r| (r, 0.0)),
        }
    }

    /// Try to view this value as bytes (works for `bytes`, `bytearray`,
    /// and contiguous `memoryview`). Returns `None` for any other type.
    pub fn as_bytes_view(&self) -> Option<Vec<u8>> {
        match self {
            Object::Bytes(b) => Some(b.to_vec()),
            Object::ByteArray(b) => Some(b.borrow().clone()),
            Object::MemoryView(mv) => Some(mv.to_bytes()),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn small_int_range_collection_preserves_boundary_values() {
        for (start, stop, step, expected) in [
            (i64::MAX, i64::MIN, i64::MIN, vec![i64::MAX, -1]),
            (
                i64::MIN,
                i64::MAX,
                i64::MAX,
                vec![i64::MIN, -1, i64::MAX - 1],
            ),
            (9, 2, 3, vec![]),
            (2, 9, -3, vec![]),
            (11, -1, -3, vec![11, 8, 5, 2]),
        ] {
            let range = Object::Range(Rc::new(Range::new(start.into(), stop.into(), step.into())));
            let result = collect_small_int_range(&range).unwrap().unwrap();
            let ints: Vec<_> = result
                .iter()
                .map(|value| match value {
                    Object::Int(n) => *n,
                    _ => panic!("range value left the inline integer lane"),
                })
                .collect();
            assert_eq!(ints, expected);
        }
        let wide = Object::Range(Rc::new(Range::new(i64::MAX.into(), i128::MAX, 1)));
        assert!(collect_small_int_range(&wide).is_none());
        let huge = BigInt::from(1) << 200;
        let big = Object::Range(Rc::new(Range::from_bigints(
            huge,
            BigInt::from(1) << 201,
            BigInt::from(1),
        )));
        assert!(collect_small_int_range(&big).is_none());
        let iterator = Object::Iter(Rc::new(RefCell::new(PyIterator::Range {
            current: 0,
            stop: 5,
            step: 1,
        })));
        assert!(collect_small_int_range(&iterator).is_none());
    }

    #[test]
    fn small_int_range_collection_rejects_impossible_capacities() {
        // Neither case can attempt a large allocation: the first fails
        // length conversion, and the second exceeds Vec's layout limit.
        for (range, expected) in [
            (
                Range::new(i64::MIN.into(), i64::MAX.into(), 1),
                "OverflowError",
            ),
            (Range::new(0, isize::MAX as i128, 1), "MemoryError"),
        ] {
            let result = collect_small_int_range(&Object::Range(Rc::new(range))).unwrap();
            match result {
                Err(RuntimeError::PyException(error)) => assert_eq!(error.type_name(), expected),
                other => panic!("expected {expected}, got {other:?}"),
            }
        }
    }

    #[test]
    fn empty_tuple_arrays_use_the_interned_tuple() {
        let empty = Object::new_tuple(Vec::new());
        assert!(Object::new_tuple_array([]).is_same(&empty));
    }

    #[test]
    fn tuple_arrays_preserve_order_identity_and_ownership() {
        let text: SharedStr = SharedStr::from("owned by the tuple");
        let weak = SharedStr::downgrade(&text);
        let tuple =
            Object::new_tuple_array([Object::Str(text.clone()), Object::Int(-7), Object::None]);
        let Object::Tuple(items) = &tuple else {
            unreachable!()
        };
        assert!(matches!(
            &items[..],
            [Object::Str(_), Object::Int(-7), Object::None]
        ));
        assert!(items[0].is_same(&Object::Str(text.clone())));
        drop(text);
        assert!(weak.upgrade().is_some());
        drop(tuple);
        assert!(weak.upgrade().is_none());
    }

    /// `hash(b"...")` under `PYTHONHASHSEED=0` on CPython 3.13 (an all-zero
    /// siphash13 key), one value per tail length 0..=7 plus two multi-chunk
    /// inputs, so every branch of the fixed-width tail assembly is pinned
    /// bit-for-bit against the reference implementation.
    #[test]
    fn siphash13_tail_lengths_match_cpython() {
        let pinned: [(&[u8], u64); 9] = [
            (b"a", 4_644_417_185_603_328_019),
            (b"ab", 6_148_830_537_548_944_441),
            (b"abc", 13_851_880_170_939_887_858),
            (b"abcd", 16_416_137_402_921_954_953),
            (b"abcde", 2_674_923_165_546_153_122),
            (b"abcdef", 7_070_790_388_344_807_208),
            (b"abcdefg", 7_904_145_750_247_929_094),
            (b"abcdefgh", 4_574_395_652_268_504_554),
            (b"abcdefghijk", 1_450_545_860_578_130_900),
        ];
        for (data, want) in pinned.iter() {
            assert_eq!(siphash13(0, 0, data), *want, "{data:?}");
        }
    }

    #[test]
    fn truthiness_matches_python_basics() {
        assert!(!Object::None.is_truthy());
        assert!(!Object::Bool(false).is_truthy());
        assert!(Object::Bool(true).is_truthy());
        assert!(!Object::Int(0).is_truthy());
        assert!(Object::Int(1).is_truthy());
        assert!(!Object::Float(0.0).is_truthy());
        // NaN is truthy in Python: bool(float('nan')) is True.
        assert!(Object::Float(f64::NAN).is_truthy());
        assert!(Object::Float(1.5).is_truthy());
        assert!(!Object::from_str("").is_truthy());
        assert!(Object::from_str("x").is_truthy());
        assert!(!Object::new_list(vec![]).is_truthy());
        assert!(Object::new_list(vec![Object::Int(1)]).is_truthy());
    }

    #[test]
    fn equality_handles_numeric_coercion() {
        assert!(Object::Int(1).eq_value(&Object::Bool(true)));
        assert!(Object::Float(1.0).eq_value(&Object::Int(1)));
        assert!(!Object::Int(1).eq_value(&Object::Int(2)));
    }

    #[test]
    fn identity_of_same_list_handle() {
        let a = Object::new_list(vec![Object::Int(1)]);
        let b = a.clone();
        let c = Object::new_list(vec![Object::Int(1)]);
        assert!(a.is_same(&b));
        assert!(!a.is_same(&c));
    }

    #[test]
    fn list_iter_yields_elements_in_order() {
        let lst = Object::new_list(vec![Object::Int(1), Object::Int(2), Object::Int(3)]);
        let mut it = lst.make_iter().expect("iter");
        let a = it.next_value().and_then(|x| match x {
            Object::Int(i) => Some(i),
            _ => None,
        });
        let b = it.next_value().and_then(|x| match x {
            Object::Int(i) => Some(i),
            _ => None,
        });
        let c = it.next_value().and_then(|x| match x {
            Object::Int(i) => Some(i),
            _ => None,
        });
        let d = it.next_value();
        assert_eq!(a, Some(1));
        assert_eq!(b, Some(2));
        assert_eq!(c, Some(3));
        assert!(d.is_none());
    }
}

"""Prove that real pickle reduction reaches the guarded native helper."""
import copyreg
import json
import pickle
from _weave_pickle import lookup_special

assert copyreg._native_lookup_special is lookup_special

class Record:
    def __init__(self, value=7):
        self.value = value

    def __getnewargs__(self):
        return (self.value,)

    def __getstate__(self):
        return {'value': self.value}

calls = []

def observe(obj, name):
    value = lookup_special(obj, name)
    calls.append([name, value is NotImplemented, value is None])
    return value

copyreg._native_lookup_special = observe
try:
    original = Record()
    restored = pickle.loads(pickle.dumps(original, protocol=5))
    assert type(restored) is Record and restored.value == 7
    assert calls == [
        ['__getnewargs_ex__', False, True],
        ['__getnewargs__', False, False],
        ['__getstate__', False, False],
    ], calls
finally:
    copyreg._native_lookup_special = lookup_special
print(json.dumps(calls))

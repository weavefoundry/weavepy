# Value-storage timing is active

Supersedes the build-pending status in performance_phase69_status.md.

Release bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4
is 44,097,168 bytes, 192,352 bytes smaller than ed99. Build session 62902
finished successfully. All 336 source and 75 original method/input hashes
match, plus the separately frozen corrected-method hashes.

The 87 targeted release checks pass. The standard run passed 273 of 275;
exactly two sandbox-blocked loopback fixtures passed on recheck outside the
sandbox. All original failures are retained in the corrected 275-row result.
The additional bytes/codecs suites pass; four explicitly selected nested
C API suites pass. The nonexistent test_unicode.py and empty initial nested
selections are not passes. The actual test_str suite passes in standard checks.
Four exact expected marshal failures persist in both ed99 and bf2, recorded
as a remaining compatibility limitation. Read validation-corrections.md.

No runtime or Python regression source changed after building. Only v2
validation/readiness/measurement launchers may run. Their hashes are in
thin-value-storage-corrected-methods.json. The readiness-v2 check passed.

ACTIVE timing gate: session 75663, thin-value-storage-focused-load.json,
measure_thin_value_storage_focused_v2.sh, outside the filesystem sandbox.
No owned build, test, profile, install, runtime-source edit, or active-method
edit may run while this gate can launch or while it is timing. Preserve every
sample and later host-load observation. There is no full-suite gate yet.
Next: finish all 20 cold and seven warm focused controls, summarize every
metric, then run the full-suite v2 gate without editing the candidate.

The goal remains unachieved. No new commit or push has been made.

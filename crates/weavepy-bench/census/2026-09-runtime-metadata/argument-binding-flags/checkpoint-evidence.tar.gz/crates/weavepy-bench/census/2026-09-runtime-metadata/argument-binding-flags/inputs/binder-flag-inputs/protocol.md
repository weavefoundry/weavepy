# Binder flag storage controls

Prepared before any binder flag candidate build or timing. Ten signature controls
span the inline threshold, large default/keyword-only signatures, variadic slots,
and many body locals. Use seven paired samples, both modes, exact CPython values,
and per-binary frozen caches through the unchanged component helper. These add
to, not replace, the ten existing call shapes and four warm/four cold exceptions.
Perform native coverage checks before interpreting any timer as native work.
Preserve every sample and regression. Complete the current early-entry experiment
before applying the separate binder flag change or measuring these inputs.

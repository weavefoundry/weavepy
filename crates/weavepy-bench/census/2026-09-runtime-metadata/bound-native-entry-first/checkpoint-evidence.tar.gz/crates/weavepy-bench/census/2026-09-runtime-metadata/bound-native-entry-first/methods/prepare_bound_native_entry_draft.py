"""Draft a guarded post-binding native entry without changing runtime sources."""
import difflib
import hashlib
import json
from pathlib import Path

source = Path('crates/weavepy-vm/src/lib.rs')
original = source.read_text()
needle = '''        let mut frame = self.make_frame(
            code.clone(),
            positional,
            f.closure.clone(),
'''
assert original.count(needle) == 1
addition = '''        // Binding has already resolved live defaults and keyword names, so
        // an eligible compiled body can consume its positional slots directly.
        // Keep generators, cells, and variadic/keyword-only layouts on the
        // existing frame path. Native entry rechecks observers, guards, lanes,
        // pending work, and recursion before executing any callee code.
        #[cfg(feature = "jit")]
        if !code.is_generator
            && !code.is_coroutine
            && !code.is_async_generator
            && !has_varargs
            && !has_varkeywords
            && kwonly_count == 0
            && code.cellvars.is_empty()
            && code.freevars.is_empty()
            && f.closure.is_empty()
        {
            if let Some(result) = crate::tier2::try_call_native_direct(
                self,
                f,
                &code,
                &positional[..total_args],
            ) {
                self.recycle_scratch(positional);
                return result;
            }
        }
'''
candidate = original.replace(needle, addition + needle)
root = Path('target/bound-native-entry-draft')
root.mkdir()
(root / 'lib.rs').write_text(candidate)
(root / 'candidate.patch').write_text(''.join(difflib.unified_diff(
    original.splitlines(keepends=True), candidate.splitlines(keepends=True),
    fromfile='a/' + str(source), tofile='b/' + str(source))))
(root / 'index.json').write_text(json.dumps({
    'status': 'Unapplied, unformatted, uncompiled, unvalidated, unmeasured.',
    'base_source_sha256': hashlib.sha256(original.encode()).hexdigest(),
    'draft_sha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'source': str(source),
}, indent=2) + '\n')
print('Saved unapplied post-binding native-entry draft.')

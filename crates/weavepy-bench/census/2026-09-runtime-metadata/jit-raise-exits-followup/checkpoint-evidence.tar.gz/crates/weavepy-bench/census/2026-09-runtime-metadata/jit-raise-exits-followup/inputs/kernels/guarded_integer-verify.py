def guarded_integer(n):
    if n < 0:
        raise ValueError("negative")
    total = 0
    for i in range(n):
        total += i
    return total

def bench(n):
    total = 0
    for i in range(n):
        total += guarded_integer(512)
    return total

import json
for stage in range(2):
    if stage:
        bench(1000)
    value = bench(7)
    assert value == 915712
    print(json.dumps(value))

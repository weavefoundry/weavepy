# Generic native-call argument storage: unapplied follow-up

Finish and archive the ASCII time formatter's four timing stages before changing
runtime source or starting tests, builds, or diagnostics.

Source inspection of tier2.rs call_dyn_impl shows the generic path allocates a
Vec<Object> for every nonempty call, including common one- and two-argument
calls. Existing compiled-callee entry short-circuits before that allocation.
This is separate from the pooled u64/u32 native marshal buffers; avoiding this
Vec would not imply that a whole Python call becomes allocation-free.

A bounded candidate is initialized inline storage for a few positional arguments,
with the existing Vec path for larger signatures and keyword calls. Preserve
argument order, pin cloning, error messages, temporary-reference lifetimes,
activation shells, dirty-state marking, guards_hold, parked results, and exact
integer-result exits. No new unsafe ownership or uninitialized Object storage
is necessary. Do not hold a pool or pin-table borrow across arbitrary Python.

Inspect generated code before deciding where to put the array: increasing the
stack frame of call_dyn_impl can penalize the already compiled short-circuit
path. An outlined generic helper could isolate that storage, but its call and
layout costs need direct measurement too. Treat the old small/native and large/
keyword branches as controls rather than assuming the new representation wins.

Use independent callables with zero through the inline threshold, threshold + 1,
and wide argument lists; keyword-only/default/variadic cases; nested calls;
exceptions and mixed return values; mutation of global callees inside callbacks;
frame/tracing behavior; and weak references proving argument release after calls.
Prove the generic dynamic helper is exercised using existing counters or traces.
Measure cold and repeated calls, the unchanged census, startup, CPU, and memory.

The untimed after-time-format-path-audit separately shows deque_ops bench rejects
at BinarySubscr on an object container. Removing that rejection alone would not
prove the full loop compiles: q[0] + q[-1] has two object operands, and generic
iteration also requires an audit. Supporting object indexing needs a Python-
capable helper with exact side-effect, exception, guard-invalidation, parked-
result, and post-operation deoptimization handling. It must not call __getitem__
twice or use instance attribute lookup in place of special-method lookup.

No implementation or performance result follows from this source audit.

//! Standalone checks of exact integrated storage modules; Object and CachedHash are stubs.
#[path="../../../crates/weavepy-vm/src/shared_value.rs"]
pub mod shared_value;
#[path="../../../crates/weavepy-vm/src/tuple_storage.rs"]
pub mod tuple_storage;
pub mod object {
    #[derive(Debug, Clone)]
    pub enum Object { Int(i64), Str(crate::shared_value::SharedStr) }
}
pub mod sync {
    pub type Rc<T> = std::sync::Arc<T>;
    #[repr(transparent)]
    #[derive(Debug)]
    pub struct CachedHash(std::sync::atomic::AtomicI64);
    impl Default for CachedHash { fn default() -> Self { Self(std::sync::atomic::AtomicI64::new(-1)) } }
    impl CachedHash {
        pub fn get(&self) -> Option<i64> {
            let x = self.0.load(std::sync::atomic::Ordering::Acquire);
            (x != -1).then_some(x)
        }
        pub fn store(&self, x:i64) { self.0.store(if x == -1 {-2} else {x}, std::sync::atomic::Ordering::Release); }
    }
}

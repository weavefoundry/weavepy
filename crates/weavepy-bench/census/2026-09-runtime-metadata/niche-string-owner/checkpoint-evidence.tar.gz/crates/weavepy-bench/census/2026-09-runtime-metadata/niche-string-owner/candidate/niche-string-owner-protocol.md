# Aligned string ownership with a reserved enum byte

Compare only against the retained bf2 build:
bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4.
The candidate changes shared_value.rs only: SharedStr uses aligned inline
length metadata and a zero-only byte that Rust can use for an enclosing enum's
tag. Ordinary ownership uses Arc<str>; an individually owned box stores lengths
that need the reserved byte. Bytes, surrogate strings, and tuples retain their
existing one-word owners and allocation headers. No Python fixture changes.

Preserve standalone model, owning prototype, ordinary tests, strict-provenance
Miri on ARM64 and i686, and generated code. These do not demonstrate whole-VM
soundness or performance. Verify actual Object, Option<Object>, and DictKey
remain 16 bytes on this host. Run the 353 VM tests, full C API package, lint,
format, no-JIT compilation, and 14 exact integrated storage-module Miri tests on
both architectures with documented Object/CachedHash stubs. After a correct
release CLI build, freeze binary, source, method, and input hashes. Run the
unchanged 87 targeted Python checks, including interpreter and GIL-disabled
correctness, and the outside-sandbox 275-check compatibility validator.
Additional bytes, codecs, and four C API suites must be nonempty and pass.
Preserve the four established marshal divergences against bf2 as divergences.

Use unchanged phase69 inputs: 20 cold population controls of 200,000 values
and seven warm operation controls of 20,000 repetitions. The original sampler
verifies all variants against CPython before timing, including GIL-disabled
correctness, then collects seven alternating pairs in JIT and interpreter
modes plus CPython with one declared stabilization cycle per row. Frozen
per-binary-SHA caches must remain unchanged over measured samples.

Run two stages sequentially against bf2: focused controls, then 31 startup/import
samples and five alternating pairs of the unchanged full 24-fixture census.
Keep historical 21-row, current 23-workload, and all-24 process cohorts distinct.
Use same-run pairs for attribution. Retain every sample, loss, failure, load
observation, VM/swap snapshot, and executable/source/input/cache identity.

Every timing stage must use run_serial_performance_gate.py outside the filesystem
sandbox. Its exclusive lease covers the entire load gate and child stage.
Inspect completion before launching the next dependent stage. The unchanged
load gate requires three 10-second observations with one- and five-minute load
averages at most half the CPU count, waiting at most 600 seconds per attempt.
No owned build, test, profile, install, runtime edit, or active-harness edit may
overlap a gate that can launch or a measurement. Keep every launched sample
regardless of later host load. A failed precondition is not a timing result.

Overall superiority to CPython remains unachieved. No universal, energy,
controlled build-time, portability, or native parallel-scaling claim follows.

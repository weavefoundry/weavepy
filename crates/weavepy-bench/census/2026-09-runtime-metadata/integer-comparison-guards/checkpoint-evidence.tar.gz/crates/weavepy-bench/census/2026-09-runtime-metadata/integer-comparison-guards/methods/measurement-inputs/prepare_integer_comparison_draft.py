"""Prepare guarded opaque/integer comparisons without changing active sources."""
from pathlib import Path
import difflib
import hashlib
import json

root = Path("target/integer-comparison-draft")
root.mkdir()
records = {}
patch = ""


def save(name, before, after):
    global patch
    assert before != after
    (root / Path(name).name).write_text(after)
    records[name] = {"base_sha256": hashlib.sha256(before.encode()).hexdigest(), "draft_sha256": hashlib.sha256(after.encode()).hexdigest()}
    patch += "".join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile="a/" + name, tofile="b/" + name))


name = "crates/weavepy-jit/src/analyze.rs"
before = Path(name).read_text()
after = before
old = '''    if (a.is_integral() || a == JitType::Float) && (b.is_integral() || b == JitType::Float) {
        return Ok(());
    }'''
new = '''    if let Some(depth) = integer_operand_guard(a, b) {
        return cmp_check(
            kind,
            if depth == 1 { JitType::Int } else { a },
            if depth == 0 { JitType::Int } else { b },
        );
    }
''' + old
assert after.count(old) == 1
after = after.replace(old, new)
old = '''        OpCode::CompareOp => {
            let kind = cmp_kind(ins.arg)?;
            let b = pop_val(stack)?;
            let a = pop_val(stack)?;
            if a.is_integral() && b.is_integral() {'''
new = '''        OpCode::CompareOp => {
            let kind = cmp_kind(ins.arg)?;
            let mut b = pop_val(stack)?;
            let mut a = pop_val(stack)?;
            if let Some(depth) = integer_operand_guard(a, b) {
                // Guard after producing calls, at the comparison itself.
                // A surprise restores both original operands so rich
                // comparisons and their callbacks execute exactly once.
                stack.push(ESlot::val(a));
                stack.push(ESlot::val(b));
                push(TOp::UnboxInt { depth }, None, stack, stmts);
                stack.pop();
                stack.pop();
                if depth == 0 {
                    b = JitType::Int;
                } else {
                    a = JitType::Int;
                }
            }
            if a.is_integral() && b.is_integral() {'''
assert after.count(old) == 1
after = after.replace(old, new)
save(name, before, after)

name = "crates/weavepy-jit/tests/frame_coverage.rs"
before = Path(name).read_text()
after = before + '''

#[test]
fn opaque_integer_comparisons_guard_at_the_comparison_opcode() {
    use weavepy_compiler::OpCode;
    for op in ["<", "<=", "==", "!=", ">", ">="] {
        for (expression, depth) in [(format!("produce(n) {op} 3"), 1), (format!("3 {op} produce(n)"), 0)] {
            let code = compile_first_fn(&format!("def k(produce, n):\\n    return {expression}\\n"));
            let cfg = Cfg { obj_params: vec![0], ..Cfg::default() };
            let tf = analyze_code_cfg(&code, &cfg).expect("guarded comparison should compile");
            let pc = code.instructions.iter().position(|i| i.op == OpCode::CompareOp).unwrap() as u32;
            assert!(tf.blocks.iter().flat_map(|b| &b.stmts).any(|s| s.pc == pc && s.op == TOp::UnboxInt { depth }));
            assert!(has_op(&tf, |op| matches!(op, TOp::IntCmp(_))));
            assert_eq!(tf.ret_lane, Some(JitType::Bool));
        }
    }
}
'''
save(name, before, after)
(root / "candidate.patch").write_text(patch)
(root / "index.json").write_text(json.dumps({"status": "Unapplied, unformatted, uncompiled, unvalidated, unmeasured.", "sources": records}, indent=2) + "\n")
(root / "README.md").write_text('''# Guarded opaque/integer comparisons

The assertion candidate's datetime trace still rejects _ymd2ord and field
validators with MixedArithTypes. Arithmetic already uses integer_operand_guard
and UnboxInt for an opaque value beside an integral peer; comparisons don't.
This draft reuses that existing exact-Object::Int guard at COMPARE_OP, after
all producer calls. Two opaque values and opaque/float pairs remain unchanged.
Bool objects, large integers, integer subclasses, and rich-comparison objects
miss the exact guard and resume comparison in the interpreter. Scalar bool
peers retain normal integral comparison behavior.

No new runtime helper, native layout, unsafe code, cache, or execution policy.
This initial draft doesn't fuse the producing call; that is a separate possible
optimization after correctness and measurements. It might make frequently
noninteger callbacks slower and may not unblock datetime's other barriers.

The two source copies include the currently applied assertion-exit changes.
Don't overwrite them with older source copies. Apply only after assertion
measurements and evidence preservation, with exact baseline hashes rechecked.
Before use, test all comparisons in both orders, exact integer boundaries,
bool/float/huge integers, subclasses/reflected methods, arbitrary rich-comparison
results and truth conversion, callback effects/exceptions, locals/tracebacks,
tracing, cold/warm fallback and recovery, and actual native guard coverage.
No test or performance result exists for this draft yet.
''')
print("Prepared two-file guarded-comparison draft; active runtime unchanged.")

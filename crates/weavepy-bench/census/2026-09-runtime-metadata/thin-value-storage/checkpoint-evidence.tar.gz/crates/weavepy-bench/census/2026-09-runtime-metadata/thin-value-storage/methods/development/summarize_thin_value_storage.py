"""Summarize every paired storage-control metric without filtering losses."""
import json,math,statistics
from pathlib import Path
root=Path('target/thin-value-storage-focused')
out={'purpose':__doc__,'rows':{}}
for group,count in [('cold',20),('warm',7)]:
    r=json.loads((root/group/'measurements.json').read_text())
    assert len(r['rows'])==count
    for name,row in r['rows'].items():
        assert row['frozen_cache']['unchanged']
        assert all(len(v)==7 for v in row['samples'].values())
        item={'new_over_previous':row['previous_comparisons'],'new_over_cpython':row['cpython_comparisons'],'pairs':{}}
        for mode in ['jit','interp']:
            item['pairs'][mode]={}
            for metric in row['samples'][mode][0]:
                ratios=[a[metric]/b[metric] for a,b in zip(row['samples'][mode],row['samples']['previous_'+mode])]
                item['pairs'][mode][metric]={'ratios':ratios,'wins':sum(x<1 for x in ratios),'minimum':min(ratios),'maximum':max(ratios)}
        out['rows'][group+'/'+name]=item
        new=item['new_over_previous']['jit']
        print(group,name,'time/base %.6f RSS/base %.6f'%(new['ns'],new['rss_bytes']),'paired time wins',item['pairs']['jit']['ns']['wins'],'RSS wins',item['pairs']['jit']['rss_bytes']['wins'])
out['groups']={}
for group in ['cold','warm']:
    rows=[r for name,r in out['rows'].items() if name.startswith(group+'/')]
    out['groups'][group]={}
    for mode in ['jit','interp']:
        out['groups'][group][mode]={}
        for ref in ['new_over_previous','new_over_cpython']:
            out['groups'][group][mode][ref]={k:math.exp(statistics.mean(math.log(r[ref][mode][k]) for r in rows)) for k in rows[0][ref][mode]}
(root/'summary.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['groups'],indent=2))


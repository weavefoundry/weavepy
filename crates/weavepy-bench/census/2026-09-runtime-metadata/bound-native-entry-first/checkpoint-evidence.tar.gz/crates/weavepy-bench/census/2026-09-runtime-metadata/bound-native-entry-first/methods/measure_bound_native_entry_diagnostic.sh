#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/bound-native-entry-validation-stage.txt)" = done
python3.14 - <<'CHECK'
import json
from pathlib import Path
assert json.loads(Path('target/bound-native-entry-coverage/report.json').read_text())['assertions_passed']
CHECK
python3.14 - <<'GATE'
import json
from pathlib import Path
d = json.loads(Path('target/bound-native-entry-focused-load.json').read_text())
assert d['status'] == 'not_started' and 'child_pid' not in d
assert not Path('target/bound-native-entry-focused').exists()
GATE
output=target/bound-native-entry-diagnostic
test ! -e "$output"
mkdir "$output"
base="$(cat target/bound-native-entry-v3-previous.txt)"
binary=target/release/weavepy-runtime-bound-native-entry
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf 'ten call shapes\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/bound-native-entry-inputs/calls --out "$output/calls" --samples 7 > "$output/calls.txt" 2>&1
printf 'four warm exception frequencies\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/bound-native-entry-inputs/exceptions --out "$output/exceptions" --samples 7 > "$output/exceptions.txt" 2>&1
printf 'four cold exception frequencies\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/bound-native-entry-inputs/exceptions --out "$output/cold-exceptions" --samples 7 --cold > "$output/cold-exceptions.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
printf 'done\n' > "$output/stage.txt"

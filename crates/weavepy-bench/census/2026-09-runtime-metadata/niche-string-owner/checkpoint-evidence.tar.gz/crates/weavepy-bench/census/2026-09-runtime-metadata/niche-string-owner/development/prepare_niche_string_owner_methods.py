"""Prepare a fresh aligned-string trial against retained bf2."""
from pathlib import Path

for name in ['build_compact_arc_clone.sh', 'check_compact_arc_clone.sh',
             'validate_compact_arc_clone.sh', 'check_compact_arc_clone_extra.py',
             'measure_compact_arc_clone_focused.sh', 'measure_compact_arc_clone_full.sh',
             'summarize_compact_arc_clone.py', 'verify_compact_arc_clone_ready.py',
             'freeze_compact_arc_clone_sources.py']:
    text = (Path('target') / name).read_text()
    text = text.replace('compact-arc-clone', 'niche-string-owner').replace('compact_arc_clone', 'niche_string_owner')
    text = text.replace('weavepy-runtime-compact-arc-storage', 'weavepy-runtime-thin-value-storage')
    if name.startswith('verify_'):
        text = text.replace('355 passed', '353 passed').replace('16 passed', '14 passed')
        text = text.replace("assert read('target/niche-string-owner-layout.json')['Object'] == 16", "layout = read('target/niche-string-owner-layout.json')\nassert all(layout[k] == 16 for k in ['Object', 'Option<Object>', 'DictKey', 'SharedStr'])\nassert all(layout[k] == 8 for k in ['SharedSlice<u8>', 'SharedSlice<u32>', 'SharedTuple'])")
    if name.startswith('freeze_'):
        text = text.replace("'target/compact-arc-storage-prebuild.json'", "'target/thin-value-storage-prebuild.json'")
        text = text.replace("'run_performance_under_load_gate.py',", "'run_performance_under_load_gate.py', 'run_serial_performance_gate.py',")
    out = Path('target') / name.replace('compact_arc_clone', 'niche_string_owner')
    assert not out.exists(), out
    out.write_text(text)

integrated = Path('target/niche-string-owner-integrated-api')
assert not integrated.exists()
(integrated / 'src').mkdir(parents=True)
(integrated / 'Cargo.toml').write_text('[package]\nname="niche-string-owner-integrated-api"\nversion="0.0.0"\nedition="2021"\n[workspace]\n')
(integrated / 'src/lib.rs').write_text(Path('target/compact-arc-clone-integrated-api/src/lib.rs').read_text())
print('Prepared fresh methods and exact-module Miri harness.')

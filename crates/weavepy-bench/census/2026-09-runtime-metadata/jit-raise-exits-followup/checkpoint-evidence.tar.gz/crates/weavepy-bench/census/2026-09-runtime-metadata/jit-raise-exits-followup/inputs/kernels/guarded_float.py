def guarded_float(n):
    if n < 0:
        raise ValueError("negative")
    value = 1.0
    for i in range(n):
        value = value * 1.00001 + 0.00003
    return value

def bench(n):
    total = 0.0
    for i in range(n):
        total += guarded_float(512)
    return total

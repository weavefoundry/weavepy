#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base="$1"
binary=target/release/weavepy-runtime-bound-native-entry
test -f "$base"
test ! -e "$binary"
test ! -e target/bound-native-entry-v3-stage.txt
printf '%s\n' "$base" > target/bound-native-entry-v3-previous.txt
printf 'corrected native coverage and static checks\n' > target/bound-native-entry-v3-stage.txt
cargo fmt --all -- --check > target/bound-native-entry-v3-format.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 tests::jit_slot_writes_share_code_names_after_deletion -- --exact --nocapture > target/bound-native-entry-v3-vm-tests.txt 2>&1
cargo clippy --offline --locked -p weavepy-vm -p weavepy-jit --lib --tests -j 1 -- -D warnings > target/bound-native-entry-v3-clippy.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/bound-native-entry-v3-no-jit.txt 2>&1
printf 'release build\n' > target/bound-native-entry-v3-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/bound-native-entry-v3-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/bound-native-entry-v3-source-snapshot --extra target/build_bound_native_entry_v3.sh target/prepare_bound_native_entry_draft.py target/check_bound_native_entry.sh target/validate_bound_native_entry.sh > target/bound-native-entry-v3-snapshot.txt 2>&1
printf 'done\n' > target/bound-native-entry-v3-stage.txt

"""Prepare time-formatting, fallback, and inherited binding controls."""
from pathlib import Path
import hashlib
import json

root = Path('target/ascii-time-format-inputs')
assert not root.exists()
cases = {}
for spec in ['hours', 'minutes', 'seconds', 'milliseconds', 'microseconds', 'auto']:
    cases['parts_' + spec] = ("import _pydatetime as pure\n",
        f"text = pure._format_time(i % 24, i % 60, (i * 7) % 60, (i * 1999) % 1000000, {spec!r})\n        total += len(text) + ord(text[-1])")
for spec in ['auto', 'milliseconds', 'microseconds']:
    cases['time_iso_' + spec] = ("from datetime import time\nvalues = [time(i % 24, i % 60, (i * 7) % 60, (i * 1999) % 1000000) for i in range(64)]\n",
        f"text = values[i & 63].isoformat(timespec={spec!r})\n        total += len(text) + ord(text[-1])")
cases['datetime_iso_utc'] = ("from datetime import datetime, timezone\nvalues = [datetime(2024, 2, 29, i % 24, i % 60, (i * 7) % 60, (i * 1999) % 1000000, tzinfo=timezone.utc) for i in range(64)]\n",
    "text = values[i & 63].isoformat()\n        total += len(text) + ord(text[-1])")
cases['format_callback_fallback'] = ("import _pydatetime as pure\nclass Hour(int):\n    def __format__(self, spec):\n        return super().__format__(spec)\nvalues = [Hour(i % 24) for i in range(64)]\n",
    "text = pure._format_time(values[i & 63], 4, 5, 1999, 'seconds')\n        total += len(text) + ord(text[-1])")
cases['invalid_precision_fallback'] = ("import _pydatetime as pure\n",
    "try:\n            pure._format_time(3, 4, 5, 1999, 'invalid')\n        except ValueError:\n            total += 1")
cases['negative_fields_fallback'] = ("import _pydatetime as pure\n",
    "text = pure._format_time(-1, 2, 3, -1234, 'milliseconds')\n        total += len(text) + ord(text[-1])")
cases['ordinary_format_control'] = ("", "text = '{:02d}:{:02d}:{:02d}.{:06d}'.format(i % 24, i % 60, (i * 7) % 60, (i * 1999) % 1000000)\n        total += len(text) + ord(text[-1])")
for group in ['cold', 'warm']:
    folder = root / group
    folder.mkdir(parents=True)
    texts = {}
    for name, (header, body) in cases.items():
        texts[name] = 'import os\n' + header + 'def bench(n):\n    total = 0\n    for i in range(n):\n        ' + body + '\n    return total\n'
        texts[name] += '''
if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))
'''
    inherited = json.loads(Path(f'target/borrowed-keyword-defaults-inputs/{group}/preparation.json').read_text())
    for name in ['override_64_all_supplied', 'kw_compiled_64_omitted', 'kw_override_16_omitted']:
        texts[name] = Path(inherited['rows'][name]['path']).read_text()
    prepared = {'purpose': __doc__, 'work': 20000, 'rows': {}}
    for name, text in texts.items():
        path = folder / (name + '.py')
        path.write_text(text)
        driver = folder / (name + '-verify.py')
        driver.write_text(f'''import importlib.util, json
spec = importlib.util.spec_from_file_location('format_control', {str(path.resolve())!r})
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(20000)
for _ in range(6):
    module.bench(64)
last = module.bench(20000)
print(json.dumps(first))
print(json.dumps(last))
''')
        prepared['rows'][name] = {'path': str(path), 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                                 'driver': str(driver), 'driver_sha256': hashlib.sha256(driver.read_bytes()).hexdigest()}
    (folder / 'preparation.json').write_text(json.dumps(prepared, indent=2) + '\n')
print('Prepared 17 cold and 17 warm controls, including three unchanged binding controls.')

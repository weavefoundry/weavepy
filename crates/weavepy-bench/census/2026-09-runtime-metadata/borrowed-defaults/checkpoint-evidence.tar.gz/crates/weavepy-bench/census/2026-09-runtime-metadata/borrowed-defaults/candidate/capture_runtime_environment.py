import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

here = Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
env = json.loads((here / 'environment.json').read_text())
binary = Path(sys.argv[1])
env['binaries']['new'] = {'path': str(binary), 'bytes': binary.stat().st_size,
                          'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
if len(sys.argv) > 2:
    previous = Path(sys.argv[2])
    env['binaries']['previous'] = {'path': str(previous), 'bytes': previous.stat().st_size,
                                  'sha256': hashlib.sha256(previous.read_bytes()).hexdigest()}
else:
    env['binaries'].pop('previous', None)
# A committed checkpoint is the reconstruction base. Keep the prior source set
# so committing progress doesn't silently drop the files from later snapshots.
delta = subprocess.check_output(['git', 'diff', 'HEAD', '--binary'])
env['git_state'] = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'branch': subprocess.check_output(['git', 'branch', '--show-current'], text=True).strip(),
    'tracked_delta_sha256': hashlib.sha256(delta).hexdigest(),
    'status_porcelain': subprocess.check_output(
        ['git', 'status', '--porcelain=v1', '--untracked-files=all'], text=True),
    'reconstruction': 'Check out head, apply source-changes.diff, then overlay copied sources.'
}
paths = set(env.get('sources', {}))
paths.update(subprocess.check_output(['git', 'diff', 'HEAD', '--name-only'], text=True).splitlines())
paths.update(subprocess.check_output(
    ['git', 'ls-files', '--others', '--exclude-standard', '--', 'tests/regrtest'],
    text=True).splitlines())
paths.update(str(p) for p in Path('tests/regrtest').glob('test_jit_list*.py'))
paths.add('tests/regrtest/test_jit_constants.py')
paths.add('tests/regrtest/test_jit_scalar_results.py')
paths.add('tests/regrtest/test_jit_unboxed_calls.py')
paths.add('tests/regrtest/test_type_cache_names.py')
paths.add('tests/regrtest/test_indexed_slot_access.py')
paths.add('tests/regrtest/test_class_version_tokens.py')
paths.add('tests/regrtest/test_lazy_code_caches.py')
paths.add('tests/regrtest/test_default_suffix.py')
paths.add('tests/regrtest/test_shared_code_caches.py')
paths.add('tests/regrtest/test_lazy_instance_dict.py')
paths.add('tests/regrtest/test_gc_metadata.py')
paths.add('tests/regrtest/test_native_slice_bounds.py')
paths.add('tests/regrtest/test_native_pin_retirement.py')
paths.add('tests/regrtest/test_native_pin_pressure.py')
paths.add('tests/regrtest/test_native_string_callbacks.py')
paths.add('tests/regrtest/test_native_string_arguments.py')
paths.add('tests/regrtest/test_range_collection.py')
paths.add('tests/regrtest/test_sum_streaming.py')
paths.add('tests/regrtest/test_sum_numeric.py')
paths.add('tests/regrtest/test_sum_range.py')
paths.add('tests/regrtest/test_cached_code_relocation.py')
paths.add('tests/regrtest/test_range_iteration_bounds.py')
paths.add('tests/regrtest/test_string_split_gc.py')
paths.add('tests/regrtest/test_native_generator_pin_retirement.py')
paths.add('crates/weavepy-vm/src/lazy_arc.rs')
paths.add('crates/weavepy-vm/src/shared_value.rs')
paths.add('crates/weavepy-vm/examples/value_storage_layout.rs')
paths.add('crates/weavepy-vm/src/stdlib/pickle_accel.rs')
paths.add('crates/weavepy-vm/src/stdlib/pickle_accel/encode.rs')
paths.add('crates/weavepy-compiler/src/cache_snapshot.rs')
paths.update(['tests/regrtest/test_jit_scalar_leaf_calls.py', 'crates/weavepy-jit/tests/helper_registration.rs', 'crates/weavepy-jit/src/engine/tests.rs'])
paths.update(['tests/regrtest/test_hash_results.py', 'tests/regrtest/test_instance_metadata.py', 'tests/regrtest/test_tuple_storage.py'])
paths.update(['tests/regrtest/test_small_slot_storage.py', 'tests/regrtest/test_tuple_hash_cache.py', 'crates/weavepy-vm/src/tuple_storage.rs'])
paths.update(['tests/regrtest/test_float_text.py', 'tests/regrtest/test_key_comparison_state.py',
              'tests/regrtest/test_jit_enumerate.py'])
env['deleted_source_paths'] = sorted(p for p in paths if not Path(p).exists())
env['sources'] = {p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
                  for p in sorted(paths) if Path(p).is_file()
                  and Path(p).suffix in {'.rs', '.toml', '.lock', '.py'}}
scripts = list(here.glob('*.py')) + list(here.glob('*.toml')) + [Path('tools/bench_compare.py'),
          Path('crates/weavepy-bench/census/2026-09-execution/probes.py')]
env['measurement_scripts'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(scripts)}
reference_source = '''
import datetime, _datetime, hashlib, inspect, json, sys, sysconfig
from pathlib import Path
def identify(path):
    if not path:
        return None
    p = Path(path).resolve()
    return {"path": str(p), "bytes": p.stat().st_size,
            "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} if p.is_file() else None
library = Path(sysconfig.get_config_var("LIBDIR") or "") / (sysconfig.get_config_var("LDLIBRARY") or "")
jit = getattr(sys, "_jit", None)
print(json.dumps({
    "version": sys.version,
    "executable": identify(sys.executable),
    "library": identify(library) or identify(Path(sys.base_prefix) / "Python"),
    "datetime_python": identify(datetime.__file__),
    "datetime_native": identify(getattr(_datetime, "__file__", None)),
    "datetime_native_origin": _datetime.__spec__.origin,
    "datetime_constructor_is_builtin": inspect.isbuiltin(datetime.datetime.__new__),
    "gil_enabled": getattr(sys, "_is_gil_enabled", lambda: None)(),
    "jit_available": getattr(jit, "is_available", lambda: None)(),
    "jit_enabled": getattr(jit, "is_enabled", lambda: None)(),
}))
'''
env['python_reference'] = json.loads(subprocess.check_output(
    ['python3.14', '-c', reference_source], text=True))
env['runtime_environment'] = {name: os.environ.get(name) for name in (
    'PYTHON_JIT', 'PYTHON_GIL', 'PYTHONOPTIMIZE', 'PYTHONHASHSEED',
    'PYTHONDONTWRITEBYTECODE', 'PYTHONNOUSERSITE', 'WEAVEPY_JIT',
    'WEAVEPY_JIT_THRESHOLD')}
env['recorded_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(here / 'environment.json').write_text(json.dumps(env, indent=2) + '\n')
print(env['binaries']['new'])

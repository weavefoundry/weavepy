"""Hold an exclusive lease through a complete load gate and measurement stage."""
import fcntl
import os
from pathlib import Path
import shlex
import subprocess
import sys

with Path('target/weavepy-performance-stage.lock').open('a+') as lease:
    try:
        fcntl.flock(lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit('Another owned performance stage holds the lease; no gate launched.')
    # Also reject older unleased controllers or orphaned measurement children.
    # Inspect only known script entry points; never stop unrelated processes.
    active = []
    known = {
        'target/run_performance_under_load_gate.py',
        'target/measure_verified_python_components.py',
        'target/shared_slot_keys_startup_probes.py',
        'tools/bench_compare.py',
        'target/measure_compact_arc_clone_focused.sh',
        'target/measure_compact_arc_clone_full.sh',
    }
    for line in subprocess.check_output(['ps', '-Ao', 'pid=,args='], text=True).splitlines():
        fields = line.strip().split(None, 1)
        if len(fields) != 2 or int(fields[0]) == os.getpid():
            continue
        try:
            argv = shlex.split(fields[1])
        except ValueError:
            continue
        if len(argv) > 1 and argv[1] in known:
            active.append(int(fields[0]))
    if active:
        raise SystemExit(f'An earlier measurement process remains active: {active}; no gate launched.')
    print('Exclusive performance-stage lease acquired.', flush=True)
    result = subprocess.run(['python3.14', 'target/run_performance_under_load_gate.py', *sys.argv[1:]])
    raise SystemExit(result.returncode)

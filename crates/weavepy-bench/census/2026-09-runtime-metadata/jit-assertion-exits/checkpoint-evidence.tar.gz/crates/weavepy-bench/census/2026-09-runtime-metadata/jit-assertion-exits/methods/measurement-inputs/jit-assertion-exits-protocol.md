# Common exception constants as JIT exits

The preceding intern-pool experiment is complete and must be archived before
applying this independent change. Native analysis treats only canonical
AssertionError and NotImplementedError constants as exact-PC interpreter exits.
Cold message construction and exception handling stay with the interpreter;
other common constants remain unsupported. Existing marker-free operand checks,
spill/writeback, and call-span exclusion apply. The draft adds no runtime helper,
object field, cache, or permanent deoptimization policy.

The Python semantic preflight covers normal warming, message identity and side
effects, conditional messages, loop locals and exact traceback line, cleanup,
shadowed exception names, active exception context, error-burst recovery, tracing,
and real bytecode using the second canonical exception constant. It must pass
CPython and unchanged a1e87c1a first. All 17 new workloads likewise need exact
before/after-warmup agreement on CPython and the predecessor in JIT, interpreter,
and gil=0 correctness modes before applying. None establishes candidate validity.

Require all JIT tests, VM tests, formatting, Clippy, no-default-feature check,
69 targeted release checks, standard compatibility, six extra call/inspection/
copy/assertion suites, and instrumented proof that six assertion functions
actually compile and rebuild their error continuations. Untyped locals must
survive framed exits; direct entry must keep its existing all-argument lane
checks. Preserve interpreter loop state and rejection of nonplain call markers.

Focused timing uses 13 warm and four first-invocation controls: integer/float/
list/conditional assertions, four failure frequencies through a wrapper, four
datetime components, and an error-burst recovery case. Each uses work 5000 and
seven pairs of both modes of candidate, immediate a1e87c1a, retained 539c, and
CPython. The four original cold controls have explicit first-invocation timers.
All raw values and stable per-binary frozen caches must agree. Full timing uses
the unchanged 24 fixtures with five pairs plus nine startup/import controls
with 31 pairs, compared with immediate a1e87c1a. The startup helper disables JIT.

Each timing run waits for three observations ten seconds apart with both one-
and five-minute load averages at most 4, up to 600 seconds. Preserve any
no-child expiration before a separately declared diagnostic. Keep every sample,
regression, workload/process wall and CPU metric, RSS, source/binary hash, and
VM/swap/load observation. Don't retry or filter by outcome. No runtime or active
method edits, build, tests, profiling, or other owned heavy jobs while a gate
can launch. Keep 21/23/24 cohort summaries distinct and use same-run paired
ratios for attribution. The existing performance goal remains unachieved;
no universal, energy, controlled build-time, portability, or native parallel
performance claim is supported by this proposal.

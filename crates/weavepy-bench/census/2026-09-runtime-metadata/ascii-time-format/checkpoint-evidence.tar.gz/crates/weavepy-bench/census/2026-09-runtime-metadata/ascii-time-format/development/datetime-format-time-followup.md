# Unapplied bounded time-formatting accelerator

After the combined default-binding experiment, a separate candidate can target
_pydatetime._format_time and datetime_accel.rs. The current Python helper builds
five format-map entries and calls str.format for every ISO time component.
Existing _weave_datetime helpers establish an optional-import/None-fallback
pattern. No implementation or timing result exists for this proposal.

Accept only four exact Object::Int fields in normal time ranges (hour 0-23,
minute/second 0-59, microsecond 0-999999) and an exact Object::Str timespec from
hours/minutes/seconds/milliseconds/microseconds/auto. Return None for all other
inputs, including bools, integer subclasses, huge/negative fields, custom format
objects, string subclasses, and unknown timespecs. This narrower guard leaves
unusual formatting, callbacks, negative floor division, and errors to Python.

A safe 15-byte ASCII stack buffer can hold HH:MM:SS.ffffff. Fill fixed decimal
positions with bounded integer arithmetic. Return prefixes of length 2, 5, 8, 12, or 15
for the five explicit precisions; auto uses 8 if microseconds==0 else 15. Taking
the first three fraction digits implements truncation for the admitted positive
range. Convert through checked str::from_utf8 and Object::from_str; no new unsafe
UTF-8 operation or temporary heap vector is needed. This is only a design.

Use a separate optional import for the new helper so its absence cannot disable
existing normalization helpers. At the top of _format_time, call it only when
available and return only a non-None result. Retain the complete original
function as fallback. Rebinding the new private helper remains observable.

Before measurement, compare every timespec at boundary fields and randomized
valid fields with CPython. Include datetime/time.isoformat, timezone/fold cases,
subclasses, malformed/huge/internal fields, unknown timespecs, and custom
__format__/__eq__ callback sequences against _pydatetime. Include fallback cost
controls. Measure this component separately and the unchanged full census;
formatting occurs only every 16th iteration of datetime_ops, so a component
speedup need not materially improve its arithmetic-heavy result. No speed claim
follows from the design or from buffer size alone.


from datetime import datetime, timedelta, timezone
base = datetime(2000, 1, 1, 3, 5, 7, 11, tzinfo=timezone.utc)
dates = [base + timedelta(days=i, seconds=i * 71) for i in range(256)]
def bench(n):
    total = 0
    for i in range(n):
        delta = dates[i & 255] - base
        total += delta.days + delta.seconds
    return total

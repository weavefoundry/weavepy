"""Verify comparison semantics on CPython and the unchanged assertion build."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

out = Path('target/integer-comparison-baseline-preflight-v2')
out.mkdir()
source = Path('target/test_integer_comparison_guards_v2.py')
shutil.copyfile(source, out/'test.py')
report = {'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'runs': {}}
previous = 'target/release/weavepy-runtime-jit-assertion-exits'
for label,binary,jit,flags in [('cpython',shutil.which('python3.14'),None,[]),('jit',previous,'1',[]),('interp',previous,'0',[]),('gil0',previous,'1',['-X','gil=0'])]:
    digest = hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    env=dict(os.environ)
    for k in ('WEAVEPY_JIT','WEAVEPY_GIL','WEAVEPY_JIT_TRACE','WEAVEPY_VM_STATS','WEAVEPY_JIT_THRESHOLD'):
        env.pop(k,None)
    if jit is not None:
        env.update(WEAVEPY_JIT=jit,WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
                   WEAVEPY_FROZEN_CACHE=str((out/'frozen'/digest).resolve()))
    r=subprocess.run([binary,*flags,str(source)],env=env,capture_output=True,text=True,timeout=180)
    report['runs'][label]={'binary':binary,'sha256':digest,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(label,r.returncode,r.stdout,r.stderr,flush=True)
    assert r.returncode==0
assert len({r['stdout'] for r in report['runs'].values()})==1
report['status']='passed'
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')

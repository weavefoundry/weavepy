#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/jit-assertion-exits-validation-stage.txt)" = done
python3.14 - <<'CHECK'
import json
from pathlib import Path
assert json.loads(Path('target/jit-assertion-exits-extra-checks/report.json').read_text())['status']=='passed'
assert json.loads(Path('target/jit-assertion-exits-extra-discovery/report.json').read_text())['status']=='passed'
assert json.loads(Path('target/jit-assertion-exits-coverage/report.json').read_text())['assertions_passed']
CHECK
output=target/jit-assertion-exits-focused
test ! -e "$output"
mkdir "$output"
base="$(cat target/jit-assertion-exits-previous.txt)"
reference="$(cat target/jit-assertion-exits-reference.txt)"
binary=target/release/weavepy-runtime-jit-assertion-exits
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf '13 warm assertion/datetime/recovery controls\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/assertion-exit-inputs/warm --out "$output/warm" --samples 7 > "$output/warm.txt" 2>&1
printf 'four cold assertion frequencies\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/assertion-exit-inputs/cold --out "$output/cold" --samples 7 --cold > "$output/cold.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
printf 'done\n' > "$output/stage.txt"

# Outlined native-entry eligibility

Complete e507 binder experiment archived: 439 files, 4,442,112 bytes; all indexed
hashes verified. Its combined fallback regressions remain unresolved. Separate
startup memory diagnostics are archived in 40 files, 1,006,060 bytes. Their full
raw stack histories remain local, with hashes recorded. No timing/profiling jobs
were active when the two-file outlined-entry draft was applied by exact hashes.

The same native signature/closure/generator predicates move into a helper with
inlining disabled. The caller no longer uses total_args/has_varargs/
has_varkeywords/kwonly_count after binding; the helper reads the captured code
layout and delegates to existing guarded direct entry. It adds a helper call
to rejected paths and may regress them. No new cache, allocation, field, unsafe,
Python-visible behavior, or permanent deoptimization policy. The hypothesis is
shorter caller live ranges and less interference with the large inlined binder.

cargo fmt completed before freezing prebuild runtime hashes and 17 methods.
The candidate isn't built, validated, or measured yet. Immediate reference is
e507; additional reference and full-suite baseline are retained539c. Same 28
focused cases with v3 signature inputs, seven pairs; unchanged full 24 fixtures
and nine startup/import controls. Both timing runs have fresh strict load gates.
All prior failures, regressions, source and binary identities remain preserved.

Caveat for later work: applying this draft changes tier2.rs. The older unapplied
native-pin-memo draft must be rebased by verified patch if used later; never
copy its old full tier2.rs over the new outlined helper.

52208 CLOSED 0: all 342 VM tests and static checks passed. Release built in an
observed 4m34s, not a controlled build metric. Candidate
5b299d93eecf1ec04d19f517aee7f6c3b60c6418dcf86ec1f5fd71c5791cbd71
is 44,290,800 bytes, 80 more than e507 and 240 more than retained539c. Source
snapshot, prebuild sources, 17 method hashes, and executable hashes verified.
21300 CLOSED 0: all 63 targeted checks passed. 96186 CLOSED 0: all five extra
suites passed. Full standard compatibility and native coverage are running.
No candidate timing has started.

Separate compact-intern-pools-draft is unapplied: two private String-keyed maps
would become sets of the same canonical Rc<str> objects. It preserves pool
boundaries, strong ownership, UTF-8/character identities, pointer-sensitive
intern status, and existing WStr behavior. It targets measured name-table costs
and copies in sys.intern/str_is_interned, but is uncompiled and unvalidated.
No object/sys runtime sources were modified for that draft.

Compatibility completed: all 275 checks PASS; all ten original coverage oracles and corrected many-body-local native-path assertion PASS. All 145 prebuild source hashes and 17 method hashes remain exact. Assembly capture first rejected a broad symbol search that included a closure, before any disassembly; corrected exact symbols are preserved. The helper is outlined and tail-branches to direct entry, but call_python_owned reserves 0x700 after saved registers, versus e507 0x6a0. The proposed smaller stack frame did not materialize; timing will determine retention. No timing has started before this note.

37254 CLOSED 0: all 28 focused cases passed exact values, stable caches, and seven samples per variant. Gate qualified at observation 2 and the complete job finished after 116.901 seconds, end load 2.975/2.896/3.066. Several original call shapes improve 2-4 percent versus e507; sparse/many-local controls stay about 21-22 percent faster than retained 539c. Variadic/keyword-only/closure controls remain 4.3/6.3/4.5 percent slower than 539c. Large-default signatures are about 1 percent slower than e507. No universal or fallback-regression resolution is claimed. Full 24-fixture plus startup census launched through a fresh strict gate.

50621 CLOSED 0: full census completed under qualified gate, launch observation 2, total 338.906 seconds, end load 2.767/2.706/2.879. All 24 fixtures and nine startup/import controls completed with isolated stable caches. JIT 23-workload ratios are 0.995950962 to retained 539c and 3.397883110 to CPython, six of 23 wins. Historical 21 paired mean is 2.096787495 to CPython (ratio-of-medians 2.092741213). All-24 process wall/CPU/RSS ratios to 539c are 1.001412522/1.001173977/1.002276140. RSS is 2.074970234 of CPython, zero wins. Runtime sources and all 17 methods remain exact after timing. No sample exclusions/retries. Candidate remains under refinement with fallback regressions; performance goal unachieved. Complete evidence is being archived before a separate intern-pool experiment.

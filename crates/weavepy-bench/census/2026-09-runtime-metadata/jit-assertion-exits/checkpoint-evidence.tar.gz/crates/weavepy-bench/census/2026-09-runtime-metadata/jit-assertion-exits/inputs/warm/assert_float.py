
def leaf(value):
    assert value >= 0.0, f"negative value {value}"
    return value * 1.5 + 0.25
def bench(n):
    total = 0.0
    for i in range(n):
        total += leaf(i * 0.25)
    return total

#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/native-unobserved-shell-checks/frozen"
binary=target/release/weavepy-runtime-native-unobserved-shell
test "$(cat target/native-unobserved-shell-build-stage.txt)" = done
test ! -e target/native-unobserved-shell-checks
mkdir target/native-unobserved-shell-checks
printf 'targeted binding, native calls, and observability\n' > target/native-unobserved-shell-check-stage.txt
for test in test_native_activation_shell_reuse test_time_format_fastpath test_overridden_keyword_default_ownership test_overridden_default_ownership test_shared_value_storage test_tuple_storage test_tuple_hash_cache test_marshal_roundtrip test_rfc0050_unicode_codecs test_json_buffers test_jit_assertion_exits test_compact_intern_pools test_argument_binding_storage test_bound_native_entry test_default_suffix test_extcall_kwonly_messages test_jit_calls test_jit_dyn_calls test_jit_unboxed_calls test_jit_scalar_leaf_calls test_jit_object_lanes test_jit_raise_exits test_native_call_scratch test_native_pin_retirement test_native_pin_pressure test_frame_recycling test_recursion_guard test_cross_thread_heap test_native_generator_pin_retirement test_jit_cells test_small_slot_storage test_pickle_callables test_weakref_basic; do
    WEAVEPY_JIT=1 "$binary" "tests/regrtest/$test.py" > "target/native-unobserved-shell-checks/$test-jit.txt" 2>&1
    WEAVEPY_JIT=0 "$binary" "tests/regrtest/$test.py" > "target/native-unobserved-shell-checks/$test-interp.txt" 2>&1
    WEAVEPY_JIT=1 "$binary" -X gil=0 "tests/regrtest/$test.py" > "target/native-unobserved-shell-checks/$test-gil0.txt" 2>&1
done
WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_bound_native_entry.py > target/native-unobserved-shell-checks/native-coverage.stdout.txt 2> target/native-unobserved-shell-checks/native-coverage.stderr.txt
WEAVEPY_JIT=1 "$binary" -c 'import _pydatetime as p; import _weave_datetime as n; assert p._format_time_parts is n.format_time_parts; assert p._format_time_parts(3, 4, 5, 1999, "milliseconds") == "03:04:05.001"; print("native formatter active")' > target/native-unobserved-shell-checks/native-format-coverage.txt 2>&1
WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_native_activation_shell_reuse.py > target/native-unobserved-shell-checks/dynamic-coverage.stdout.txt 2> target/native-unobserved-shell-checks/dynamic-coverage.stderr.txt
python3.14 target/check_native_unobserved_shell_coverage.py "$binary" target/native-unobserved-shell-checks/fixture-coverage target/native-unobserved-shell-inputs-v2 > target/native-unobserved-shell-checks/fixture-coverage.txt 2>&1
python3.14 target/check_native_unobserved_shell_frame_identity.py > target/native-unobserved-shell-checks/frame-identity.txt 2>&1
printf 'done\n' > target/native-unobserved-shell-check-stage.txt

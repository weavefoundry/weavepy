"""Archive comparison guards with original fixture failure and every paired result."""
import gzip
import hashlib
import json
from pathlib import Path

parent=Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out=parent/'integer-comparison-guards'
assert not out.exists()
for group in ('focused','full'):
    assert Path('target/integer-comparison-guards-'+group+'/stage.txt').read_text().strip()=='done'
    assert json.loads(Path('target/integer-comparison-guards-'+group+'-load.json').read_text())['status']=='complete'
focused=json.loads(Path('target/integer-comparison-guards-focused/summary.json').read_text())
full=json.loads(Path('target/integer-comparison-guards-full/summary.json').read_text())
validation=json.loads(Path('target/integer-comparison-guards-validation/validation.json').read_text())
assert len(validation)==275 and all(r['passed'] for r in validation)
assert json.loads(Path('target/integer-comparison-guards-extra-checks/report.json').read_text())['status']=='passed'
assert json.loads(Path('target/integer-comparison-guards-coverage/report.json').read_text())['assertions_passed']
assert len(focused['rows'])==19
out.mkdir()
records=[]

def copy(src,dst):
    src=Path(src);raw=src.read_bytes();data=raw
    if len(raw)>=65536 and src.suffix in ('.json','.txt','.diff') and not src.name.startswith('summary'):
        dst+='.gz';data=gzip.compress(raw,compresslevel=9,mtime=0)
    p=out/dst;assert not p.exists(),dst;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    records.append({'path':dst,'source':str(src),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                    'uncompressed_bytes':len(raw),'uncompressed_sha256':hashlib.sha256(raw).hexdigest()})

def folder(src,dst):
    for p in sorted(Path(src).iterdir()):
        if p.is_file() and p.suffix in ('.py','.json','.txt','.md','.sh','.patch'):
            copy(p,str(Path(dst)/p.name))

for group in ('focused','full'):
    folder('target/integer-comparison-guards-'+group,group)
for group in ('warm','cold'):
    copy('target/integer-comparison-guards-focused/'+group+'/measurements.json','focused/'+group+'.json')
    folder('target/integer-comparison-inputs/'+group,'inputs/'+group)
for group in ('checks','validation','extra-checks','coverage','datetime-paths'):
    folder('target/integer-comparison-guards-'+group,'checks/'+group)
for group in ('measurement-inputs','v2-measurement-inputs','datetime-method'):
    folder('target/integer-comparison-guards-'+group,'methods/'+group)
for group in ('integer-comparison-baseline-preflight','integer-comparison-baseline-preflight-v2','integer-comparison-inputs-baseline','assertion-nested-loop-followup','integer-comparison-callback-paths'):
    folder('target/'+group,'checks/'+group)
copy('target/test_integer_comparison_guards.py','checks/original-semantic-preflight.py')
for p in sorted(Path('target').glob('integer-comparison-guards-*.txt')):
    copy(p,'logs/'+p.name)
for name in ('integer-comparison-inputs-baseline.txt','integer-comparison-semantic-baseline-v2.txt','assertion-nested-loop-followup.txt','integer-comparison-callback-paths.txt'):
    copy('target/'+name,'logs/'+name)
for name in ('integer-comparison-guards-focused-load.json','integer-comparison-guards-full-load.json','integer-comparison-guards-prebuild-sources.json','integer-comparison-guards-v2-prebuild-sources.json','performance_phase67_status.md'):
    copy('target/'+name,'conditions/'+name)
for name in ('environment.json','source-changes.diff','tests/regrtest/test_integer_comparison_guards.py'):
    copy('target/integer-comparison-guards-source-snapshot/'+name,'candidate/'+name)
for name in ('candidate.patch','index.json','README.md'):
    copy('target/integer-comparison-draft/'+name,'draft/'+name)
copy('target/inspect_assertion_nested_loop_paths.py','methods/inspect_assertion_nested_loop_paths.py')
copy('target/inspect_comparison_callback_paths.py','methods/inspect_comparison_callback_paths.py')
copy(__file__,'methods/'+Path(__file__).name)

work=full['cohorts']['all_23_workloads_excluding_startup']['metrics']['jit']['ns']
hist=full['cohorts']['historical_21_including_startup']['metrics']['jit']
proc=full['cohorts']['all_processes_including_startup']['metrics']['jit']
lines=['# Guard opaque integer comparisons at the comparison instruction','',
'The overall performance goal remains unachieved. This candidate is under refinement.','',
'Candidate e709418a uses the existing exact-Int guard for one opaque operand',
'beside an integral peer. It guards at COMPARE_OP after producing calls and',
'retains both original operands for misses. Bool/float/large integer/subclass',
'and rich-comparison surprises resume in the interpreter. Two opaque operands',
'and opaque/float pairs keep their earlier analysis. No call fusion, runtime',
'helper, object field, cache, unsafe code, or execution policy is added.',
'The executable is 44,289,536 bytes, 16 bytes larger than immediate ed99.',
'Earlier intern and native-entry changes and their regressions remain included.','',
'The first analyzer fixture failed TypeUnknown because its opaque producer',
'argument had no parameter-lane probe. The fixture was corrected to supply',
'its runtime-equivalent Int lane; the runtime draft was unchanged. Original',
'failing output, methods, and source hashes remain. The corrected continuation',
'uses separate logs and manifests. All 59 JIT tests, 342 VM tests, formatting,',
'Clippy, and no-default-feature checks pass. Observed release build time was',
'4m08s, which is not a controlled build-time metric.','',
'All 72 targeted release checks and 275 standard compatibility checks pass.',
'All six extra comparison/rich-comparison/long-integer/call/unittest suites',
'select nonempty tests and pass. All 19 named comparison functions actually',
'compile and rebuild continuations with exact CPython results. The regression',
'covers all operators and orders, arbitrary rich-comparison results, reflected',
'dispatch, truth conversion, integer boundaries, subclasses, producer and',
'comparison exceptions, callback order, loop locals and exact traceback line,',
'tracing, and recovery. Baseline v1/v2 checks remain separate.','',
'Untimed datetime results agree with CPython; compiled functions rise 26 to 28',
'(__lt__ and __gt__), but native-call deopts rise from 0 to 64 in this driver.',
'_ymd2ord still rejects MixedArithTypes; field validators advance to a formatting',
'operand-lane rejection. These observations do not establish speed gains.',
'A separate untimed a1e/ed99 nested-loop follow-up found identical native stats',
'and zero deopts. It does not explain or erase the earlier 13.4 percent regression.','',
'Focused timing uses 15 warm and four cold controls at work 5000 and seven pairs',
'of candidate, immediate ed99, retained 539c, and CPython. All WeavePy builds',
'are measured in both modes. GIL-disabled runs are correctness controls only.',
'All values and per-binary frozen caches agree. Lower ratios are better.','',
'| Case | Mode | Time / predecessor | RSS / predecessor | Time / CPython |',
'| --- | --- | ---: | ---: | ---: |']
for name,row in focused['rows'].items():
    for mode in ('jit','interp'):
        prev=row['new_over_previous'][mode];cp=row['new_over_cpython'][mode]
        lines.append(f"| {name} | {mode} | {prev['ns']:.4f} | {prev['rss_bytes']:.4f} | {cp['ns']:.4f} |")
lines+=['','Every sample, paired range, regression, workload/process wall and CPU metric,',
'peak RSS, and cache observation remains. Four cold controls have process CPU',
'but no separate workload CPU timer. Native-coverage counts are not speed data.','',
'The full suite retains 24 unchanged fixtures at five pairs and nine startup/',
'import controls at 31 pairs, with immediate ed99 as the baseline. The startup',
'helper disables JIT. Both timing gates qualified; all later load, VM, and swap',
'observations remain. Samples are never selected or retried by outcome.','',
f"The 23-workload JIT mean is {work['new_over_base']:.6f} of its predecessor and",
f"{work['new_over_cpython']:.6f} of CPython, with {work['weavepy_wins']} time wins.",
f"The historical 21-fixture mean is {hist['ns']['new_over_cpython']:.6f} of CPython,",
f"or {hist['ratio_of_medians_new_over_cpython']:.6f} using ratios of medians.",'',
f"All-24 process wall/CPU/RSS ratios to its predecessor are {proc['wall_ns']['new_over_base']:.6f},",
f"{proc['cpu_ns']['new_over_base']:.6f}, and {proc['rss_bytes']['new_over_base']:.6f}.",
f"Peak RSS is {proc['rss_bytes']['new_over_cpython']:.6f} of CPython with {proc['rss_bytes']['weavepy_wins']} wins.",'',
'Keep 21/23/24 cohorts distinct and use same-run pairs for attribution. No',
'universal, energy, controlled build-time, portability, or native parallel',
'performance superiority is established. Large raw text is compressed losslessly;',
'the index verifies both stored and uncompressed sizes and hashes. Executables,',
'frozen caches, and unselected temporary files remain local.','']
(out/'REPORT.md').write_text('\n'.join(lines))
p=out/'REPORT.md';records.append({'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'index.json').write_text(json.dumps(records,indent=2)+'\n')
for row in records:
    data=(out/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
    if 'uncompressed_sha256' in row:
        raw=gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert hashlib.sha256(raw).hexdigest()==row['uncompressed_sha256']
with (parent/'.gitignore').open('a') as f:
    f.write('\n# Integer comparison guards and complete paired evidence.\n')
    for p in sorted(out.rglob('*')):
        if p.is_file():f.write('!'+str(p.relative_to(parent))+'\n')
with (parent/'README.md').open('a') as f:
    f.write('\nThe [guarded integer-comparison experiment](integer-comparison-guards/REPORT.md)\nretains native success and fallback controls, full-suite results, and the\noriginal analyzer-fixture failure. CPython gaps and individual regressions remain.\n')
print('Exported',len(records)+1,'files;',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes; all stored and uncompressed hashes verified.')

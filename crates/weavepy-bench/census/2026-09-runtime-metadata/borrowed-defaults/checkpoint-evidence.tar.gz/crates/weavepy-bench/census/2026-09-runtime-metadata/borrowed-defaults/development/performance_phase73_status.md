# Phase 73: borrow positional default overrides

Active source is retained bf2 plus one safe block change in lib.rs. The owned
slot Object pins the overridden default tuple; bind from a borrowed slice and
clone only missing arguments. No owner layout, unsafe code, keyword-only logic,
or native eligibility change. New test_overridden_default_ownership.py covers
partial/oversized defaults, code replacement, bound methods, required-argument
errors, and weak-reference lifetime when a callee clears its defaults.

The new oracle passes on CPython and bf2 in JIT/interpreter/GIL-disabled modes.
All 347 VM tests pass. C API, clippy, and no-JIT checks are running sequentially
in session 97759 via check_borrowed_defaults_native.sh. No release build or
measurement gate is active yet. Inspect completion before starting the fresh
build_borrowed_defaults.sh; then run check_borrowed_defaults.sh (90 checks),
validate_borrowed_defaults.sh outside the sandbox (275), and readiness verifier.
The new fixture generator prepared 12 cold and 12 warm controls; every CPython
checksum matches independently calculated string lengths and iteration counts.

Planned baseline is bf2 only. Gates: borrowed-defaults-focused-retained then
borrowed-defaults-full-retained, with matching *-load.json files. Mandatory
exclusive run_serial_performance_gate.py wrapper outside sandbox. No builds,
tests, profiles, runtime edits, or active-harness edits while a gate can launch
or timings run. Inspect successful completion before launching each next stage.

Phase 72 is fully archived and deferred. Restored shared_value.rs and the bf2
CLI; all 336 original source hashes matched before this change. Restoration
proof: target/niche-string-owner-restoration.json. Its archive has 573 files;
the final REPORT documents its 1.7% workload regression and memory losses.
The win-column header was clarified after export; affected index hashes were
refreshed and verified. Earlier status files are historical intermediate notes.

No new commit or push in this continuation. Overall goal remains unachieved.

## Release completed

C API156, clippy, and no-JIT checks passed. Sources337 and methods72 were frozen.
The prebuild formatting step was unusually slow but succeeded; compilation then
completed in an observed5m21s (not a controlled build-time measurement).
Candidate target/release/weavepy-runtime-borrowed-defaults is44,096,928bytes,
SHA44c5ae82231f44182d2aac1b216d64fccdf712edce4b812baff573d3ea39befb.
All frozen hashes matched after build. Targeted90 checks are running in
session28729. On successful completion, run validate_borrowed_defaults.sh outside
the sandbox, then readiness verifier. No timing gate is active.

## Validated; focused measurements complete

All 90 targeted and 275 outside-sandbox compatibility checks passed. Native,
source, method, and binary readiness checks passed. Focused gate completed in
isolation under the serial lease, and its session75157 is closed. Summaries:
target/borrowed-defaults-focused-retained/summary.json and summary.txt.
All seven JIT pairs improve for each actually affected override-default case,
about 2-12% depending on width and cold/warm mode. Some unaffected controls
regress about1-2.5%; peak RSS has no consistent improvement. Preserve every pair.

Full gate is now running in session37515, launched only after focused completion
was inspected and asserted. Paths: borrowed-defaults-full-retained and
borrowed-defaults-full-retained-load.json. Do not run builds/tests/profiles or
edit runtime/active harness until this gate and all its children finish. Inspect
completion before any dependent action. Then verify all frozen identities,
review all cohorts/startup results, decide whether to retain or defer, and archive.
The adjacent keyword-only borrowing follow-up remains unapplied in
borrowed-keyword-defaults-followup.md. No new commit/push.

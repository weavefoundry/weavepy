#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-thin-value-storage
binary=target/release/weavepy-runtime-niche-string-owner
test ! -e "$binary"
test ! -e target/niche-string-owner-build-stage.txt
cargo fmt --all -- --check > target/niche-string-owner-format.txt 2>&1
python3.14 target/freeze_niche_string_owner_sources.py
printf 'release build\n' > target/niche-string-owner-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/niche-string-owner-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/niche-string-owner-source-snapshot --extra target/build_niche_string_owner.sh target/check_niche_string_owner.sh target/validate_niche_string_owner.sh target/check_niche_string_owner_extra.py target/measure_niche_string_owner_focused.sh target/measure_niche_string_owner_full.sh target/measure_verified_python_components.py target/niche-string-owner-protocol.md target/verify_niche_string_owner_ready.py target/freeze_niche_string_owner_sources.py target/summarize_niche_string_owner.py > target/niche-string-owner-snapshot.txt 2>&1
printf 'done\n' > target/niche-string-owner-build-stage.txt

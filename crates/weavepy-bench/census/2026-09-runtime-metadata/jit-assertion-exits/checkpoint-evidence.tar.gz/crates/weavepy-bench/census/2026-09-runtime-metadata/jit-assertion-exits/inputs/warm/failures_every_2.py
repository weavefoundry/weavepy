
def leaf(value):
    assert value >= 0, f"negative value {value}"
    return value * 3 + 1
def wrapper(value):
    return leaf(value) + 2
def bench(n):
    total = 0
    for i in range(n):
        value = -1 if 2 and i % 2 == 0 else i
        try:
            total += wrapper(value)
        except AssertionError as error:
            total += len(error.args[0])
    return total

def exact(i):
    return i
def compare(f, i):
    return f(i) < 2500
def bench(n):
    total = 0
    for i in range(n):
        total += compare(exact, i)
    return total

for _ in range(4):
    print(bench(5000))

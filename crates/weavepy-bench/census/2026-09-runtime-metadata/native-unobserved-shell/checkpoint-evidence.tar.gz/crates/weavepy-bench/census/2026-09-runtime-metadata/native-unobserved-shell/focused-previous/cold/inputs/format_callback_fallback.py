import os
import _pydatetime as pure
class Hour(int):
    def __format__(self, spec):
        return super().__format__(spec)
values = [Hour(i % 24) for i in range(64)]
def bench(n):
    total = 0
    for i in range(n):
        text = pure._format_time(values[i & 63], 4, 5, 1999, 'seconds')
        total += len(text) + ord(text[-1])
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

"""Prepare the combined default-borrowing trial against retained bf2."""
from pathlib import Path

for name in ['build_borrowed_defaults.sh', 'check_borrowed_defaults.sh', 'check_borrowed_defaults_native.sh',
             'validate_borrowed_defaults.sh', 'measure_borrowed_defaults_focused.sh',
             'measure_borrowed_defaults_full.sh', 'summarize_borrowed_defaults.py',
             'freeze_borrowed_defaults_sources.py', 'verify_borrowed_defaults_ready.py']:
    text = (Path('target') / name).read_text().replace('borrowed-defaults', 'borrowed-keyword-defaults').replace('borrowed_defaults', 'borrowed_keyword_defaults')
    if name == 'check_borrowed_defaults.sh':
        text = text.replace('for test in ', 'for test in test_overridden_keyword_default_ownership ')
    if name == 'measure_borrowed_defaults_focused.sh':
        text = text.replace('12 first-invocation', '24 first-invocation').replace('12 repeated', '24 repeated')
    if name == 'summarize_borrowed_defaults.py':
        text = text.replace("[('cold',12),('warm',12)]", "[('cold',24),('warm',24)]")
    if name == 'freeze_borrowed_defaults_sources.py':
        text = text.replace('target/thin-value-storage-prebuild.json', 'target/borrowed-defaults-prebuild.json')
        text = text.replace("paths.add('tests/regrtest/test_overridden_default_ownership.py')", "paths.add('tests/regrtest/test_overridden_keyword_default_ownership.py')")
        text = text.replace("fromfile='retained/lib.rs'", "fromfile='positional-predecessor/lib.rs'")
    if name == 'verify_borrowed_defaults_ready.py':
        text = text.replace('overridden positional defaults: ownership and binding ok', 'overridden keyword defaults: ownership and binding ok')
        text = text.replace('== 30', '== 31').replace('test_overridden_default_ownership-', 'test_overridden_keyword_default_ownership-').replace('90 targeted', '93 targeted')
    out = Path('target') / name.replace('borrowed_defaults', 'borrowed_keyword_defaults')
    assert not out.exists(), out
    out.write_text(text)
print('Prepared fresh validation and measurement methods.')

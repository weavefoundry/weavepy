#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test ! -e target/native-unobserved-shell-capi-tests-02.txt
cargo test --offline --locked -p weavepy-capi -j 1 > target/native-unobserved-shell-capi-tests-02.txt 2>&1
cargo clippy --offline --locked -p weavepy-cli -p weavepy-capi --all-targets -j 1 -- -D warnings > target/native-unobserved-shell-clippy-02.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/native-unobserved-shell-nojit-check-02.txt 2>&1

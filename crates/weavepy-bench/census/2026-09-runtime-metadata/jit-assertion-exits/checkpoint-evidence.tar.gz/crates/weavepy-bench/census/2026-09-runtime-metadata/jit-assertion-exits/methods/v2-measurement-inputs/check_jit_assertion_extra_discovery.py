"""Reject zero-test success and run the discoverable unittest package."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

root = Path("target/jit-assertion-exits-extra-discovery")
root.mkdir()
original = Path("target/jit-assertion-exits-extra-checks/report.json")
old = json.loads(original.read_text())


def selected_and_passed(run):
    found = re.search(r"(\d+) total .*?pass (\d+) / fail (\d+) / error (\d+).*?unexpected (\d+)", run["stdout"])
    if not found:
        return False
    total, passed, failures, errors, unexpected = map(int, found.groups())
    return run["returncode"] == 0 and total > 0 and passed == total and failures == errors == unexpected == 0


original_five = ("test_call", "test_extcall", "test_inspect", "test_copy", "test_copyreg")
assert all(selected_and_passed(old["runs"][name]["new"]) for name in original_five)
assert not selected_and_passed(old["runs"]["test_unittest/test_assertions"]["new"])
report = {"purpose": __doc__, "original_sha256": hashlib.sha256(original.read_bytes()).hexdigest(),
          "original_five_nonempty_suites_passed": True, "original_submodule_filter_selected_zero": True, "runs": {}}
for label, binary in [("new", "target/release/weavepy-runtime-jit-assertion-exits"), ("previous", "target/release/weavepy-runtime-compact-intern-pools")]:
    digest = hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    env = dict(os.environ, WEAVEPY_JIT="1", WEAVEPY_STDLIB_CACHE=str(Path("target/performance-stdlib-cache").resolve()),
               WEAVEPY_FROZEN_CACHE=str((root / "frozen" / digest).resolve()))
    command = ["target/release/weavepy-conformance", "regrtest", "--all-cpython", "--mode", "subprocess", "--weavepy", binary,
               "--filter", "cpython/Lib/test/test_unittest", "--stream"]
    result = subprocess.run(command, env=env, text=True, capture_output=True, timeout=900)
    report["runs"][label] = {"binary": binary, "sha256": digest, "command": command, "returncode": result.returncode,
                             "stdout": result.stdout, "stderr": result.stderr}
    (root / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(label, result.returncode, result.stdout[-2500:], flush=True)
    if selected_and_passed(report["runs"][label]):
        break
report["status"] = "passed" if selected_and_passed(report["runs"]["new"]) else "needs_review"
(root / "report.json").write_text(json.dumps(report, indent=2) + "\n")
raise SystemExit(0 if report["status"] == "passed" else 1)

"""Summarize all binder flag cases against both references and CPython."""
import hashlib,json,statistics
from pathlib import Path
root=Path('target/binder-flags-focused')
assert not (root/'summary.json').exists()
summary={'purpose':__doc__,'groups':{},'rows':{}}
ids=None
for group,count in [('calls',10),('signatures',10),('exceptions',4),('cold-exceptions',4)]:
    p=root/group/'measurements.json';data=json.loads(p.read_text())
    assert len(data['rows'])==count
    new_ids={k:v['sha256'] for k,v in data['binaries'].items()}
    if ids is None:ids=new_ids
    assert ids==new_ids
    summary['groups'][group]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'samples':data['samples'],'cold_workload':data['cold_workload']}
    for name,row in data['rows'].items():
        assert row['frozen_cache']['unchanged']
        assert all(len(samples)==7 for samples in row['samples'].values())
        values=data['verification'][name]
        assert all(v['returncode']==0 and v['stdout']==values['cpython']['stdout'] for v in values.values())
        pairs={}
        for reference in ['previous','reference']:
            pairs[reference]={}
            for mode in ['jit','interp']:
                pairs[reference][mode]={}
                for metric in row[reference+'_comparisons'][mode]:
                    ratios=[a[metric]/b[metric] for a,b in zip(row['samples'][mode],row['samples'][reference+'_'+mode])]
                    pairs[reference][mode][metric]={'ratios':ratios,'median':statistics.median(ratios),'range':[min(ratios),max(ratios)],'improved_pairs':sum(r<1 for r in ratios)}
        summary['rows'][group+'/'+name]={'new_over_previous':row['previous_comparisons'],'new_over_reference':row['reference_comparisons'],'new_over_cpython':row['cpython_comparisons'],'pairs':pairs}
summary['binaries']=ids
assert len(summary['rows'])==28
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('All 28 cases, exact values, stable caches, and seven samples per variant verified.')
for name,r in summary['rows'].items():
    print(name,'JIT time/95b',r['new_over_previous']['jit']['ns'],'time/539c',r['new_over_reference']['jit']['ns'],'time/CPython',r['new_over_cpython']['jit']['ns'])

# Fuse comparison producer results

The unfused integer-comparison experiment finished and was archived in 268
selected files, 1,361,935 bytes, with all stored/uncompressed hashes verified.
It remains under refinement: simple controls improve but complex callbacks and
the full workload/RSS means regress. The goal remains unachieved. Focused
baseline is e709, reference ed99; full baseline will be ed99 to measure the
combined comparison change against the preceding assertion build.

The new semantic regression passed CPython and unchanged e709 in JIT,
interpreter, and GIL-disabled modes. All 19 original benchmark inputs remain
unchanged and were already verified against both exact baseline binaries.
The v2 three-file draft was applied by exact source/draft hashes, with the new
regression. Original v1 had incorrect opcode variant spellings, corrected in
v2 before any build/application; both unapplied draft artifacts are preserved.

Fusion reuses the existing exact-integer CallDyn result when a comparison is
adjacent or follows one non-guarding scalar constant. Other shapes retain the
comparison-PC guard. Misses resume after the completed producer. No runtime
helper, pin lifetime, cache, policy, object field, or unsafe code changes.
The candidate is not built, validated, or measured yet. All JIT/VM/static,
75 targeted release, standard compatibility, six nonempty extra suites, and
23-function native coverage must pass before any timing.

All 60 JIT tests and all 342 VM tests passed (36.94s observed VM duration); formatting, Clippy, and no-default-feature checks passed. Release is building. A separate generalized header/tail ownership prototype now covers tuple-like destructors, weak lifetimes, fixed arrays, unique mutable access, and atomic-header thread handoffs. Three ordinary tests and all three strict-provenance Miri tests pass on aarch64 (7317 CLOSED 0, 3.75s observed Miri test time). A 32-bit i686 Miri check is running to check the different pointer/atomic alignment. No runtime memory-layout migration is applied and no timing gate is armed.

9921 CLOSED 0: release candidate c27713f0a717571a76851e285c5495a2406d12590c7c2f251f6d472eece47291 is 44289664 bytes. All 149 source/test and 18 method hashes verified, and default/release candidate binary identities agree. Targeted, extra, and actual native-coverage validation are next. No candidate timing yet.

30618 and 82138 CLOSED 0: all original 75 targeted checks and six nonempty extra suites pass. The original coverage check EXIT 1: 22 of 23 required functions compiled, with cmp_fusion_local rejecting MixedArithTypes. This is not a successful coverage check. Corrected only that integer-input test with n = n + 0 to establish its local lane; CPython/e709 all-mode preflight passes. All Rust sources/binary c277 remain unchanged. The corrected 149-source and 23-method bundles are separately post-build; original 18-method bundle remains intact. The v2 focused launcher additionally requires corrected semantic and 23-function coverage reports. No timing yet. 21489 CLOSED 0: all three separate tuple-prototype Miri tests also pass for i686, 3.60s observed.

The corrected test passes CPython and all three candidate modes; the v2 oracle verifies all 23 functions compile and rebuild. 8289 CLOSED 0: a separate corrected source snapshot preserves the post-build Python-test change with unchanged runtime/binary. Full compatibility runs in 10380. Both isolated prototype reports now preserve exact source/toolchain/log hashes and explicit limits; no memory layout has been changed in WeavePy.

10380 CLOSED 0: all 275 standard compatibility checks pass. Corrected 149 source/test, original 18-method, and corrected 23-method hashes verified. All corrected semantic/23-function coverage and six nonempty extra suites pass. No owned build/test/profile/install jobs remain. Focused 19-control timing is next under the strict gate, using ONLY measure_comparison_call_fusion_focused_v2.sh. Runtime and active methods remain frozen.

67660 CLOSED 0: all 19 focused controls, values, stable caches, and seven pairs pass; both baseline identities retained. Fusion improves the integer branch to .333817 of ed99 time, but complex interpreter callback/no misses still regresses to 1.109114 warm and 1.141680 cold, all seven pairs. Cold 1/100, 1/2, and always-rich cases are 1.064516/1.040175/1.024290 of ed99, all seven pairs slower. Datetime add and several other controls also retain losses.

4906 CLOSED 0: full strict gate qualified and completed in 336.785s; end load 2.6763/2.6406/2.6230. All 149 corrected source/test and 18/23 method hashes verified. Full JIT 23-workload c277/ed99 1.002396612, c277/CPython 3.384971628, six wins; historical 21 paired 2.086925188 (ratio of medians 2.090158224). All-24 wall/CPU/RSS ratios to ed99 are 1.008377539/1.006838275/1.000482787; RSS/CPython 2.060472003, zero wins. All regressions and load/VM/swap observations remain.

DECISION: defer BOTH the opaque integer-comparison guards and comparison call-result fusion. Their simple-control gains do not justify the repeatable complex-callback regressions and lack of a broad-suite gain for the active performance change. Archive all evidence first, then restore only the three owned JIT source files to the exact ed99 assertion snapshot, remove the two owned comparison-only Python tests after hash checks, and restore the verified ed99 default executable. No source restoration has occurred as of this status entry. The earlier assertion/intern/binding/raise changes remain. The overall goal remains unachieved. Thin-owner prototypes are separately archived in 24 selected files (49,113 bytes), with all hashes verified, but no runtime layout migration has started.

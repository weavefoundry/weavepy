#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/native-dynamic-small-args-checks/frozen"
binary=target/release/weavepy-runtime-native-dynamic-small-args
test "$(cat target/native-dynamic-small-args-build-stage.txt)" = done
test ! -e target/native-dynamic-small-args-checks
mkdir target/native-dynamic-small-args-checks
printf 'targeted binding, native calls, and observability\n' > target/native-dynamic-small-args-check-stage.txt
for test in test_dynamic_argument_storage test_time_format_fastpath test_overridden_keyword_default_ownership test_overridden_default_ownership test_shared_value_storage test_tuple_storage test_tuple_hash_cache test_marshal_roundtrip test_rfc0050_unicode_codecs test_json_buffers test_jit_assertion_exits test_compact_intern_pools test_argument_binding_storage test_bound_native_entry test_default_suffix test_extcall_kwonly_messages test_jit_calls test_jit_dyn_calls test_jit_unboxed_calls test_jit_scalar_leaf_calls test_jit_object_lanes test_jit_raise_exits test_native_call_scratch test_native_pin_retirement test_native_pin_pressure test_frame_recycling test_recursion_guard test_cross_thread_heap test_native_generator_pin_retirement test_jit_cells test_small_slot_storage test_pickle_callables test_weakref_basic; do
    WEAVEPY_JIT=1 "$binary" "tests/regrtest/$test.py" > "target/native-dynamic-small-args-checks/$test-jit.txt" 2>&1
    WEAVEPY_JIT=0 "$binary" "tests/regrtest/$test.py" > "target/native-dynamic-small-args-checks/$test-interp.txt" 2>&1
    WEAVEPY_JIT=1 "$binary" -X gil=0 "tests/regrtest/$test.py" > "target/native-dynamic-small-args-checks/$test-gil0.txt" 2>&1
done
WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_bound_native_entry.py > target/native-dynamic-small-args-checks/native-coverage.stdout.txt 2> target/native-dynamic-small-args-checks/native-coverage.stderr.txt
WEAVEPY_JIT=1 "$binary" -c 'import _pydatetime as p; import _weave_datetime as n; assert p._format_time_parts is n.format_time_parts; assert p._format_time_parts(3, 4, 5, 1999, "milliseconds") == "03:04:05.001"; print("native formatter active")' > target/native-dynamic-small-args-checks/native-format-coverage.txt 2>&1
WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_dynamic_argument_storage.py > target/native-dynamic-small-args-checks/dynamic-coverage.stdout.txt 2> target/native-dynamic-small-args-checks/dynamic-coverage.stderr.txt
python3.14 target/check_native_dynamic_small_args_coverage.py "$binary" target/native-dynamic-small-args-checks/fixture-coverage target/native-dynamic-small-args-inputs-v2 > target/native-dynamic-small-args-checks/fixture-coverage.txt 2>&1
printf 'done\n'  > target/native-dynamic-small-args-check-stage.txt

"""Preserve and compare the known native-frame identity limitation, untimed."""
from pathlib import Path
import hashlib,json,os,subprocess
root=Path('target/native-unobserved-shell-checks/frame-identity')
assert not root.exists();root.mkdir()
source=Path('target/native-frame-shell-identity-audit/probe.py')
previous='target/release/weavepy-runtime-ascii-time-format'
new='target/release/weavepy-runtime-native-unobserved-shell'
variants=[('cpython',['python3.14'],{}),('previous-jit',[previous],{'WEAVEPY_JIT':'1'}),('new-jit',[new],{'WEAVEPY_JIT':'1'}),('new-interp',[new],{'WEAVEPY_JIT':'0'}),('new-gil0',[new,'-X','gil=0'],{'WEAVEPY_JIT':'1'})]
report={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'variants':{}}
for label,cmd,extra in variants:
    env={**os.environ,'WEAVEPY_STDLIB_CACHE':str(Path('target/performance-stdlib-cache').resolve()),'WEAVEPY_FROZEN_CACHE':str((root/'frozen').resolve()),'WEAVEPY_JIT_TRACE':'1',**extra}
    p=subprocess.run(cmd+[str(source)],env=env,capture_output=True,text=True,timeout=120)
    (root/(label+'.stdout.txt')).write_text(p.stdout);(root/(label+'.trace.txt')).write_text(p.stderr)
    result=json.loads(p.stdout) if p.returncode==0 else None
    report['variants'][label]={'returncode':p.returncode,'result':result,'driver_compiled':'jit compile "driver"' in p.stderr,'driver_deopts':[line for line in p.stderr.splitlines() if 'deopt' in line and '"driver"' in line]}
    (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    assert p.returncode==0,(label,p.stderr)
    assert result=={'frames':5,'same':label not in ['previous-jit','new-jit'],'names':['driver']*5},(label,result)
    if label.endswith('-jit'):
        assert report['variants'][label]['driver_compiled']
        assert not report['variants'][label]['driver_deopts']
    print(label,result)
print('Known identity mismatch unchanged; no identity-fix claim.')

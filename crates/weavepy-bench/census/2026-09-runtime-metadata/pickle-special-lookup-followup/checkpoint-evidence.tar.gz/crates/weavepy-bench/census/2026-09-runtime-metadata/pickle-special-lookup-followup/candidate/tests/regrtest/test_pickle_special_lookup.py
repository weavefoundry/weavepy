"""Preserve pickle hook binding, mutation, and fallback side effects."""

import copyreg
import gc
import pickle
import weakref

try:
    from _weave_pickle import lookup_special as native_lookup
except ImportError:
    native_lookup = None


class Plain:
    def __init__(self, value=7):
        self.value = value


class Inherited(Plain):
    pass


class Slots:
    __slots__ = ('value', 'label')

    def __init__(self, value=9):
        self.value = value
        self.label = 'slot'


class Hook:
    def __getnewargs__(self):
        return (11,)

    def __getstate__(self):
        return {'value': self.value + 1}


class WithHooks(Hook, Plain):
    pass


class StaticHooks(Plain):
    __getnewargs__ = staticmethod(lambda: (13,))
    __getstate__ = staticmethod(lambda: {'value': 23})


class ClassHooks(Plain):
    @classmethod
    def __getnewargs__(cls):
        return (cls.marker,)

    @classmethod
    def __getstate__(cls):
        return {'value': cls.marker + 1}

    marker = 31


class ClassChild(ClassHooks):
    marker = 41


class ExtendedHooks(Plain):
    def __getnewargs_ex__(self):
        return ((self.value,), {'flag': True})

    def __new__(cls, value=7, *, flag=False):
        return object.__new__(cls)


for protocol in range(2, 6):
    for cls, expected in (
        (Plain, 7), (Inherited, 7), (Slots, 9), (WithHooks, 8),
        (StaticHooks, 23), (ClassHooks, 32), (ClassChild, 42),
        (ExtendedHooks, 7),
    ):
        original = cls()
        restored = pickle.loads(pickle.dumps(original, protocol=protocol))
        assert type(restored) is cls
        assert restored.value == expected, (cls.__name__, protocol)
        if cls is Slots:
            assert restored.label == 'slot'


class Trap(Plain):
    def __getattribute__(self, name):
        if name in ('__getnewargs__', '__getnewargs_ex__'):
            raise AssertionError('instance lookup: ' + name)
        return object.__getattribute__(self, name)

    def __getattr__(self, name):
        raise AssertionError('instance fallback: ' + name)

    def __getnewargs__(self):
        return (17,)

    def __getstate__(self):
        return {'value': 27}


trap = Trap()
for unused in range(100):
    reduced = object.__reduce_ex__(trap, 5)
    assert reduced[1] == (Trap, 17)
    assert reduced[2] == {'value': 27}


events = []


class HookDescriptor:
    def __get__(self, obj, owner):
        events.append(('get', obj, owner))

        def result():
            events.append(('call', obj, owner))
            return {'value': 51}

        return result


class Described(Plain):
    __getstate__ = HookDescriptor()


obj = Described()
for unused in range(100):
    events.clear()
    assert object.__reduce_ex__(obj, 5)[2] == {'value': 51}
    # copyreg may also inspect the hook on the class to distinguish the
    # default implementation. The instance binding and invocation are unique.
    instance_events = [event for event in events if event[1] is obj]
    assert instance_events == [('get', obj, Described), ('call', obj, Described)]


failure = ValueError('descriptor failed')


class RaisingDescriptor:
    def __get__(self, obj, owner):
        events.append('raised')
        raise failure


class Broken(Plain):
    __getstate__ = RaisingDescriptor()


broken = Broken()
for unused in range(100):
    events.clear()
    try:
        object.__reduce_ex__(broken, 5)
    except ValueError as error:
        assert error is failure
        assert events == ['raised']
        failure.__traceback__ = None
    else:
        raise AssertionError('missing descriptor exception')


class Mutable(Plain):
    def __getnewargs__(self):
        return (1,)

    def __getstate__(self):
        return {'value': 61}


class Changed(Plain):
    def __getnewargs__(self):
        return (2,)

    def __getstate__(self):
        return {'value': 71}


class MutableChild(Mutable):
    pass


obj = MutableChild()
for unused in range(100):
    assert object.__reduce_ex__(obj, 5)[1:3] == ((MutableChild, 1), {'value': 61})
Mutable.__getnewargs__ = lambda self: (3,)
Mutable.__getstate__ = lambda self: {'value': 81}
assert object.__reduce_ex__(obj, 5)[1:3] == ((MutableChild, 3), {'value': 81})
MutableChild.__bases__ = (Changed,)
assert object.__reduce_ex__(obj, 5)[1:3] == ((MutableChild, 2), {'value': 71})
obj.__class__ = WithHooks
assert object.__reduce_ex__(obj, 5)[1:3] == ((WithHooks, 11), {'value': 8})


class Meta(type):
    pass


class CustomMeta(Plain, metaclass=Meta):
    def __getnewargs__(self):
        return (19,)


custom = CustomMeta()
assert object.__reduce_ex__(custom, 5)[1] == (CustomMeta, 19)


class NoArgs(Plain):
    __getnewargs__ = None
    __getnewargs_ex__ = None



# The private accelerator must decline a descriptor before invoking it.
if native_lookup is not None:
    # Preserve copyreg's current explicit-None lookup result. Its broader
    # reduction behavior already differs from CPython and is separate here.
    assert native_lookup(NoArgs(), '__getnewargs__') is None
    plain = Plain()
    assert native_lookup(plain, '__getnewargs__') is None
    hook_obj = WithHooks()
    bound = native_lookup(hook_obj, '__getnewargs__')
    assert bound is not NotImplemented
    assert bound.__self__ is hook_obj
    assert bound() == (11,)
    assert native_lookup(StaticHooks(), '__getstate__')() == {'value': 23}
    assert native_lookup(ClassChild(), '__getnewargs__')() == (41,)
    events.clear()
    assert native_lookup(Described(), '__getstate__') is NotImplemented
    assert native_lookup(broken, '__getstate__') is NotImplemented
    assert events == []
    assert native_lookup(custom, '__getnewargs__') is NotImplemented
    assert native_lookup(1, '__getnewargs__') is NotImplemented

    original_lookup = copyreg._lookup_special
    called = []

    def replacement(obj, name):
        called.append(name)
        return original_lookup(obj, name)

    copyreg._lookup_special = replacement
    try:
        assert object.__reduce_ex__(plain, 5)[2] == {'value': 7}
        assert called == ['__getnewargs_ex__', '__getnewargs__', '__getstate__']
    finally:
        copyreg._lookup_special = original_lookup

    ref = weakref.ref(hook_obj)
    del hook_obj
    assert ref() is bound.__self__
    del bound
    gc.collect()
    assert ref() is None

print('pickle special lookup: ok')

PERIOD = 2
class Rich:
    def __lt__(self, other):
        return False
RICH = Rich()
def produce(i):
    return RICH if PERIOD and i % max(PERIOD, 1) == 0 else i
def compare(f, i):
    return f(i) < 2500
def bench(n):
    total = 0
    for i in range(n):
        total += compare(produce, i)
    return total

use super::*;
use std::collections::HashSet;

#[test]
fn complete_length_words_cover_boundaries_and_unaligned_metadata() {
    #[repr(C, packed)]
    struct Odd {
        prefix: u8,
        metadata: StringMetadata,
    }
    let values = [
        0,
        1,
        255,
        256,
        65535,
        65536,
        INDIRECT_LENGTH - 1,
        INDIRECT_LENGTH,
    ];
    for length in values {
        let metadata = StringMetadata::new(length);
        assert_eq!(metadata.word(), length);
        let odd = Odd {
            prefix: 7,
            metadata,
        };
        assert_eq!(odd.metadata.word(), length);
    }
}

#[test]
fn unicode_hash_lookup_and_original_arc_identity_survive_cloning() {
    for text in ["", "a", "x\0y", "mañana", "日本語", "🧶🙂", "e\u{301}"] {
        let original: Arc<str> = Arc::from(text);
        let owner = SharedStr::from_arc(original.clone());
        assert_eq!(SharedStr::as_ptr(&owner), Arc::as_ptr(&original));
        assert_eq!(&*owner, text);
        assert_eq!(
            owner.chars().collect::<Vec<_>>(),
            text.chars().collect::<Vec<_>>()
        );
        let mut set = HashSet::new();
        set.insert(owner.clone());
        assert!(SharedStr::ptr_eq(set.get(text).unwrap(), &owner));
        assert_eq!(SharedStr::from(text.to_owned()), owner);
        assert_eq!(SharedStr::from(text.to_owned().into_boxed_str()), owner);
        let weak = SharedStr::downgrade(&owner);
        assert_eq!(weak.strong_count(), 3);
        drop(set);
        drop(original);
        assert!(SharedStr::ptr_eq(&owner, &weak.upgrade().unwrap()));
        drop(owner);
        assert_eq!(weak.strong_count(), 0);
        assert!(weak.upgrade().is_none());
    }
}

#[test]
fn moved_and_boxed_strings_keep_empty_and_allocation_boundaries() {
    for n in [0, 1, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 65, 129] {
        let text = "é\0x".repeat(n);
        let moved = SharedStr::from(text.clone());
        let boxed = SharedStr::from(text.clone().into_boxed_str());
        assert_eq!(moved.len(), text.len());
        assert_eq!(moved, boxed);
        assert_eq!(moved.metadata.word(), text.len());
        let clone = moved.clone();
        assert!(SharedStr::ptr_eq(&clone, &moved));
    }
}

#[test]
fn boxed_owners_preserve_payload_identity_and_exact_reference_counts() {
    let original: Arc<str> = Arc::from("boxed 🧶\0 text");
    let boxed = SharedStr::indirect(original.clone());
    let second_box = SharedStr::indirect(original.clone());
    assert_ne!(boxed.data, second_box.data);
    assert_eq!(boxed.metadata.word(), INDIRECT_LENGTH);
    assert!(SharedStr::ptr_eq(&boxed, &second_box));
    let clone = boxed.clone();
    assert_ne!(clone.metadata.word(), INDIRECT_LENGTH);
    assert_eq!(SharedStr::strong_count(&boxed), 4);
    let weak = SharedStr::downgrade(&boxed);
    let second_weak = weak.clone();
    let upgrade = weak.upgrade().unwrap();
    assert!(SharedStr::ptr_eq(&upgrade, &boxed));
    assert_eq!(SharedStr::strong_count(&boxed), 5);
    assert_eq!(SharedStr::weak_count(&boxed), 2);
    drop(boxed);
    drop(second_box);
    drop(clone);
    drop(upgrade);
    assert_eq!(weak.strong_count(), 1);
    drop(original);
    assert!(weak.upgrade().is_none());
    assert!(second_weak.upgrade().is_none());
}

#[derive(Clone)]
enum Value {
    None,
    Bool(bool),
    Int(i64),
    Float(f64),
    Text(SharedStr),
    Bytes(Arc<Vec<u8>>),
    Tuple(Arc<Vec<u64>>),
    Heap(Arc<usize>),
}
#[test]
fn enum_tag_sharing_preserves_live_owners_across_variant_changes() {
    if POINTER_BYTES == 8 {
        assert_eq!(size_of::<SharedStr>(), 16);
        assert_eq!(size_of::<Value>(), 16);
        assert_eq!(size_of::<Option<Value>>(), 16);
    }
    let text = SharedStr::from("active 🧶 value");
    let weak = SharedStr::downgrade(&text);
    let mut value = Value::Text(text);
    for _ in 0..20 {
        let clone = value.clone();
        let Value::Text(owner) = clone else {
            panic!("lost string variant")
        };
        assert_eq!(&*owner, "active 🧶 value");
        assert_eq!(SharedStr::strong_count(&owner), 2);
    }
    assert!(matches!(&value, Value::Text(_)));
    value = Value::Int(-7);
    assert!(matches!(value, Value::Int(-7)));
    assert!(weak.upgrade().is_none());
    let values = vec![
        Value::None,
        Value::Bool(true),
        Value::Int(19),
        Value::Float(2.5),
        Value::Text(SharedStr::from("other")),
        Value::Bytes(Arc::new(vec![1, 2])),
        Value::Tuple(Arc::new(vec![7, 9])),
        Value::Heap(Arc::new(23)),
    ];
    for value in values.clone() {
        match value {
            Value::None => {}
            Value::Bool(v) => assert!(v),
            Value::Int(v) => assert_eq!(v, 19),
            Value::Float(v) => assert_eq!(v, 2.5),
            Value::Text(v) => assert_eq!(&*v, "other"),
            Value::Bytes(v) => assert_eq!(&**v, &[1, 2]),
            Value::Tuple(v) => assert_eq!(&**v, &[7, 9]),
            Value::Heap(v) => assert_eq!(*v, 23),
        }
    }
}

#[test]
fn standard_weak_upgrades_and_clones_survive_thread_handoffs() {
    let owner = SharedStr::from("shared 🧶 text");
    let weak = SharedStr::downgrade(&owner);
    std::thread::scope(|scope| {
        for _ in 0..2 {
            let weak = weak.clone();
            scope.spawn(move || {
                for _ in 0..20 {
                    let local = weak.upgrade().unwrap();
                    assert_eq!(&*local.clone(), "shared 🧶 text");
                }
            });
        }
    });
    drop(owner);
    assert!(weak.upgrade().is_none());
}

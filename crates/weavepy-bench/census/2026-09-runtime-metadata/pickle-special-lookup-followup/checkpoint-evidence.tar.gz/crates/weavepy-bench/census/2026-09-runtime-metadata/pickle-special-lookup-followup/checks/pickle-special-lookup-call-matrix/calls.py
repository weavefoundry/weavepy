import sys, types
module = types.ModuleType("_weavepy_bench")
module.__file__ = 'crates/weavepy-bench/fixtures/call_overhead.py'
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
for unused in range(3):
    print(module.bench(300))

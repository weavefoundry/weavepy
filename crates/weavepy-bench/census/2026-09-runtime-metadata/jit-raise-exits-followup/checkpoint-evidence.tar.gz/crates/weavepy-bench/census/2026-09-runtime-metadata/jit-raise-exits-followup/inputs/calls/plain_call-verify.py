def plain_call(n):
    return n * 3 + 1

def bench(n):
    total = 0
    for i in range(n):
        total += plain_call(i)
    return total

import json
for stage in range(2):
    if stage:
        bench(100000)
    value = bench(17)
    assert value == 425
    print(json.dumps(value))

VALUES = list(range(256))
def guarded_list(values):
    if len(values) == 0:
        raise ValueError("empty")
    total = 0
    for value in values:
        total += value
    return total

def bench(n):
    total = 0
    for i in range(n):
        total += guarded_list(VALUES)
    return total

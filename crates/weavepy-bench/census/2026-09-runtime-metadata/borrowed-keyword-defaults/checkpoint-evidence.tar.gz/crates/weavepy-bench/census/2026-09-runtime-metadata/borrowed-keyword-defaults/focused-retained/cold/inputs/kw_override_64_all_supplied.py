import os
values = tuple("default-%d-" % i + "shared-text" * 3 for i in range(64))
provided = "provided-" + "string" * 3
def target(*, a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20, a21, a22, a23, a24, a25, a26, a27, a28, a29, a30, a31, a32, a33, a34, a35, a36, a37, a38, a39, a40, a41, a42, a43, a44, a45, a46, a47, a48, a49, a50, a51, a52, a53, a54, a55, a56, a57, a58, a59, a60, a61, a62, a63):
    return a63
target.__kwdefaults__ = {"a%d" % i: values[i] for i in range(64)}
def bench(n):
    total = 0
    for _ in range(n):
        total += len(target(a0=provided, a1=provided, a2=provided, a3=provided, a4=provided, a5=provided, a6=provided, a7=provided, a8=provided, a9=provided, a10=provided, a11=provided, a12=provided, a13=provided, a14=provided, a15=provided, a16=provided, a17=provided, a18=provided, a19=provided, a20=provided, a21=provided, a22=provided, a23=provided, a24=provided, a25=provided, a26=provided, a27=provided, a28=provided, a29=provided, a30=provided, a31=provided, a32=provided, a33=provided, a34=provided, a35=provided, a36=provided, a37=provided, a38=provided, a39=provided, a40=provided, a41=provided, a42=provided, a43=provided, a44=provided, a45=provided, a46=provided, a47=provided, a48=provided, a49=provided, a50=provided, a51=provided, a52=provided, a53=provided, a54=provided, a55=provided, a56=provided, a57=provided, a58=provided, a59=provided, a60=provided, a61=provided, a62=provided, a63=provided))
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

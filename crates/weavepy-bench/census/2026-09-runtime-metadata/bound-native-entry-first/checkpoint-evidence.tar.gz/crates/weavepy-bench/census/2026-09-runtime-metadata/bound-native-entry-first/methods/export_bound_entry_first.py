"""Preserve the first post-binding entry experiment before refinement."""
import hashlib,json
from pathlib import Path
parent=Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out=parent/'bound-native-entry-first'
assert not out.exists()
assert Path('target/bound-native-entry-full/stage.txt').read_text().strip()=='done'
assert Path('target/bound-native-entry-focused-complete/stage.txt').read_text().strip()=='done'
assert all(r['passed'] for r in json.loads(Path('target/bound-native-entry-validation/validation.json').read_text()))
out.mkdir()
records=[]
def copy(src,dst):
    src=Path(src);dest=out/dst;dest.parent.mkdir(parents=True,exist_ok=True)
    data=src.read_bytes();dest.write_bytes(data)
    records.append({'path':str(dst),'source':str(src),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
def folder(src,dst,recursive=False):
    src=Path(src)
    for p in sorted(src.rglob('*') if recursive else src.iterdir()):
        if p.is_file() and p.suffix in ['.json','.txt','.py','.sh','.md','.patch']:
            copy(p,str(Path(dst)/p.relative_to(src)))
for group in ['full','focused-complete','cold-continuation']:
    folder('target/bound-native-entry-'+group,group)
for group in ['calls','exceptions','cold-exceptions']:
    copy('target/bound-native-entry-focused/'+group+'/measurements.json','focused/'+group+'.json')
folder('target/bound-native-entry-focused','focused')
copy('target/bound-native-entry-cold-continuation/cold-exceptions/measurements.json','cold-continuation/cold-exceptions.json')
for group in ['baseline-preflight','retained-preflight','coverage','checks','validation','extra-checks','call-assembly']:
    folder('target/bound-native-entry-'+group,'checks/'+group)
for group in ['measurement-inputs','v3-measurement-inputs','v4-measurement-inputs','cold-continuation-inputs']:
    folder('target/bound-native-entry-'+group,'methods/'+group)
folder('target/bound-native-entry-inputs','inputs',True)
for p in sorted(Path('target').glob('bound-native-entry-*.txt')):
    copy(p,'logs/'+p.name)
for name in ['bound-native-entry-focused-load.json','bound-native-entry-cold-continuation-load.json','bound-native-entry-full-load.json','bound-native-entry-prebuild-sources.json','bound-native-entry-v3-prebuild-sources.json','bound-native-entry-slot-coverage-diagnostic.patch','bound-native-entry-load-protocol.md','bound-native-cold-continuation-protocol.md','performance_phase61_status.md']:
    copy('target/'+name,'conditions/'+name)
for name in ['environment.json','source-changes.diff','tests/regrtest/test_bound_native_entry.py']:
    copy('target/bound-native-entry-v3-source-snapshot/'+name,'candidate/'+name)
for p in sorted(Path('target').glob('*bound*native*.py')):
    copy(p,'methods/'+p.name)
for p in sorted(Path('target').glob('*bound*native*.sh')):
    copy(p,'methods/'+p.name)
copy(__file__,'methods/'+Path(__file__).name)
report='''# First post-binding native entry experiment

Status: **under refinement**. This is a complete measured experiment, not an
all-metrics acceptance. The performance goal remains unachieved.

Candidate ca6b541d uses already-bound positional slots to enter eligible native
functions before constructing an interpreter frame. Existing binding, live
defaults, observers, pending work, guards, argument lanes, and recursion checks
remain active. Frame buffers were already pooled, so this proves fewer frame
constructions and dispatches, not a measured count of removed heap allocations.
The executable is 44,290,720 bytes, 160 more than predecessor 539c6dd3.

All 275 standard compatibility checks, 60 targeted release checks, five extra
call/inspection/copy suites, and ten instrumented CPython value comparisons
pass. Instrumentation shows sparse-keyword and many-local framed entries fall
from 855 to 3 while direct entries rise from 2 to 854. An initial missing offline
dependency stopped the first build. The next full VM run passed 341 tests and
failed one coverage assertion that counted only framed entries. Values, key
identities, and compilations passed; the diagnostic recorded 2 framed plus 199
direct entries. Counting both kinds preserves the original threshold. That
corrected test passed separately, together with formatting, Clippy, and the
build without default features. A second complete VM run was not performed.

The focused protocol retains seven paired samples for ten call shapes and
four warm and four cold exception frequencies. All load preconditions qualified.
The original focused run completed 14 cases and then failed before any cold
timed sample because warm-only source files had no main timer. Exact original
cold sources were supplied in a separate declared cold-only continuation. No
completed case was rerun. The original failed stage, empty cold measurement,
logs, both gates, and the explicit completion manifest are preserved.

Sparse-keyword and many-local workload medians improved about 16.9 and 19.2
percent relative to 539c; all seven pairs won. However, excluded variadic
keyword, keyword-only, and closure cases regressed about 8.3, 10.2, and 5.9
percent; all seven pairs lost. These regressions require refinement. The earlier
always-raising regression was not recovered. All raw wall, CPU, RSS, and exact
value/cache results remain in the archive for both execution modes.

The complete full run qualified its load precondition and retained every later
sample even when load increased. It includes all 24 unchanged fixtures, five
pairs per execution mode, and nine startup/import controls with 31 pairs. The
startup helper disables JIT. Call-overhead workload time improved about 6.5
percent; the 23-workload geometric mean improved only 0.4 percent. List, numeric,
attribute, and generator controls include regressions. Aggregate process wall,
CPU, and memory are essentially unchanged. Small changes remain provisional.

The 23-workload JIT/CPython geometric mean is 3.4336, with 6 of 23 wins. The same
historical 21-fixture cohort is 2.1165 (2.1184 using ratios of medians). All-24
process peak RSS is 2.0732 times CPython, with zero wins. These distinct cohorts
must not be substituted for one another or described as universal improvement.

Generated-code inspection found that call_python_owned reserves 80 fewer stack
bytes than its predecessor; a larger stack frame does not explain the fallback
regressions. Changed register allocation or code layout is a hypothesis, not an
established cause. A narrower guard order will be tested independently.

The index hashes every selected artifact. Local executables, frozen caches, and
unselected intermediate outputs stay outside Git. These results do not establish
energy, controlled build-time, portability, or free-threaded superiority.
'''
(out/'REPORT.md').write_text(report)
p=out/'REPORT.md';records.append({'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'index.json').write_text(json.dumps(records,indent=2)+'\n')
for row in records:
    assert hashlib.sha256((out/row['path']).read_bytes()).hexdigest()==row['sha256']
with (parent/'.gitignore').open('a') as f:
    f.write('\n# First post-binding entry experiment, including fallback regressions.\n')
    for p in sorted(out.rglob('*')):
        if p.is_file(): f.write('!'+str(p.relative_to(parent))+'\n')
with (parent/'README.md').open('a') as f:
    f.write('\nThe [first post-binding native entry experiment](bound-native-entry-first/REPORT.md)\nrecords complete qualified measurements and compatibility checks. Sparse keyword\nand many-local calls improved, but excluded call shapes consistently regressed.\nIt is under refinement; the 3.4336 workload and 2.0732 peak-RSS ratios to CPython\ndo not satisfy the performance goal. Every original sample and failure is retained.\n')
print('Exported',len(records)+1,'files;',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes; all indexed hashes verified.')

"""Preserve native shell reuse, every measurement, and the untimed ownership correction."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

subprocess.run(['python3.14', 'target/verify_native_unobserved_shell_ready.py'], check=True)
base=Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out=base/'native-unobserved-shell'
assert not out.exists()
labels=['focused-previous','full-previous','focused-retained','full-retained']
for label in labels:
    gate=json.loads(Path(f'target/native-unobserved-shell-{label}-load.json').read_text())
    assert gate['status']=='complete' and gate['returncode']==0
    assert Path(f'target/native-unobserved-shell-{label}/stage.txt').read_text().strip()=='done'
decision=json.loads(Path('target/native-unobserved-shell-decision.json').read_text())
assert set(decision)=={'decision','findings','next_step'}
out.mkdir()
index,destinations=[],set()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def add(source,relative):
    source=Path(source)
    raw=source.read_bytes()
    data=raw
    relative=Path(relative)
    if len(raw)>32768 and source.suffix in {'.json','.jsonl','.txt','.rs','.diff','.s'}:
        data=gzip.compress(raw,mtime=0)
        relative=Path(str(relative)+'.gz')
    assert str(relative) not in destinations,relative
    destinations.add(str(relative))
    dest=out/relative
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    index.append({'path':str(relative),'source':str(source),'bytes':len(data),'sha256':sha(data),
                  'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(raw)})
def tree(source,prefix,exclude=()):
    for path in sorted(Path(source).rglob('*')):
        relative=path.relative_to(source)
        if path.is_file() and not any(part in exclude for part in relative.parts):
            add(path,Path(prefix)/relative)
tree('target/native-unobserved-shell-source-snapshot','candidate')
for label in labels:
    tree(f'target/native-unobserved-shell-{label}',label,['frozen','startup'])
for group in ['checks','validation','preimages','baseline-oracles','baseline-coverage','baseline-coverage-v2','codegen']:
    tree(f'target/native-unobserved-shell-{group}',group,['frozen'])
tree('target/native-unobserved-shell-inputs','original-inputs')
tree('target/native-unobserved-shell-pre-owner-check-v1','pre-owner-check-v1')
for path in sorted(Path('target').glob('native-unobserved-shell*')):
    if path.is_file() and path.name!='native-unobserved-shell-export.txt':
        add(path,Path('development')/path.name)
for name in ['performance_phase77_status.md','native-frame-shell-followup.md',
             'native-object-indexing-followup.md',
             'native-nested-scratch-followup.md','prepare_native_unobserved_shell_methods.py',
             'prepare_native_unobserved_shell_inputs.py','prepare_native_unobserved_shell_inputs_v2.py',
             'check_native_unobserved_shell_native.sh','check_native_unobserved_shell_native_02.sh',
             'prepare_native_unobserved_shell_exporter.py','check_native_unobserved_shell_frame_identity.py',
             'inspect_native_unobserved_shell_codegen.py',
             'check_native_unobserved_shell_coverage.py','export_native_unobserved_shell.py']:
    add(Path('target')/name,Path('development')/name)
frozen=json.loads(Path('target/native-unobserved-shell-prebuild.json').read_text())
for name in frozen['methods']:
    add(name,Path('methods')/name)
env=json.loads(Path('target/native-unobserved-shell-source-snapshot/environment.json').read_text())
binary=env['binaries']['new']
lines=['# Reuse unobserved native activation shells','',
    'Decision: '+decision['decision'],'',*decision['findings'],'',
    'Next step: '+decision['next_step'],'',
    f"Candidate: `{binary['sha256']}`, {binary['bytes']:,} bytes.",
    'Direct reference: time formatter 6810,',
    '`681043b9f62cbd4fdb3f73756ecdf8ac877c1923b6a509f11ff1128dc973443c`.',
    'Retained acceptance reference: thin value storage bf2,',
    '`bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4`.','',
    'The preceding short-argument trial was deferred. Both source preimages and',
    'the 6810 CLI were restored, and all 339 predecessor source identities matched',
    'before this experiment. The new candidate keeps the preceding default-binding',
    'and time-formatter experiments but excludes the short-argument implementation.','',
    'A native CallCtx retains at most one unobserved shell. The cache is empty',
    'throughout each callback, with no cache or mutable shell borrow across Python.',
    'The exact call-site lasti is refreshed before pushing the shell. After the',
    'callback, exclusive ownership is established with Rc::get_mut before the',
    'materialization flag is read. Strong, weak, and frame observers all exclude',
    'reuse. Each of four context constructors starts empty; framed entries pass',
    'through. No new raw pointer, allocator, or ownership representation is added.',
    'Callback arguments and results are not cached. The cache lasts only for its',
    'activation, whose context already owns the shell metadata.','',
    'Source review tightened the observation-check order before timing. The first',
    'draft had read the flag before checking exclusive ownership. Its executable',
    'identity, source/method snapshot, and passing 353 VM / 156 C API / lint / no-JIT',
    'results remain under pre-owner-check-v1. This was a source-review correction,',
    'not an observed Python failure or timed regression. Validation was rerun for',
    'the corrected predicate; all timed-candidate checks use that corrected source.','',
    'Validation passes 353 VM tests, 156 C API tests, strict format/lint, no-JIT',
    'checking, 99 targeted Python checks, and all 275 outside-sandbox compatibility',
    'checks. Test-only native counters require actual allocation, at least 100',
    'reuses, and at least 10 observer exclusions. The separate Rust test exercises',
    'strong, weak, and materialized observers. No counters are present in release.',
    'The portable oracle covers nested calls, captured code identity, exceptions',
    'without replay, global mutation/deoptimization, and weak-reference lifetimes.',
    'It passes on CPython and predecessor JIT/interpreter/GIL0. GIL0 disables JIT',
    'and provides correctness evidence only. Optional extension checks may test',
    'availability internally.','',
    f"All {len(frozen['sources'])} source and {len(frozen['methods'])} declared method/input identities remain unchanged.",
    'Static helper and native-entry prologues are preserved under codegen. Reduced',
    'allocation alone is not evidence of lower stack use or peak RSS. A cache per',
    'nested activation is a possible memory cost, covered by the recursive control.',
    'Observed build durations are not controlled build-time comparisons.','',
    'The original 26 fixture sources are unchanged. The first 28-input set adds',
    'single-callback and observed-frame controls; it and its baseline traces remain.',
    'The v2 set preserves all 28 and adds recursive callbacks. All 29 independent',
    'CPython checksums pass twice. Untimed traces prove intended generic drivers',
    'compile and exceed 30,000 generic calls, while compiled aliases and the single/',
    'recursive native callees compile and exceed 30,000 native calls. The original',
    'wide-argument and tuple-unpack controls remain interpreted. Inherited formatter',
    'and binding controls retain their observed paths. Coverage is not timing.','',
    'A separate frame-identity audit confirms the same known mismatch: five calls',
    'observe one parent-frame identity on CPython and WeavePy interpreter/GIL0,',
    'but distinct identities on both predecessor and candidate JIT. The driver',
    'compiles without deoptimizing. Observed shells are excluded from reuse. This',
    'candidate does not fix native frame identity, full locals materialization,',
    'frame.clear/continuation behavior, or final instruction positions.','',
    'Four timing stages run sequentially under the exclusive lease and unchanged',
    'load gate. Every dependent launch follows inspected completion. No owned',
    'build, test, profile, install, runtime edit, or active-harness edit overlaps a',
    'stage. Keep every launched sample, all frozen-cache assertions, failures,',
    'losses, load observations, and VM/swap snapshots. Ratios below 1 favor the',
    'candidate. Means aggregate per-fixture medians of paired ratios. Keep the',
    'historical 21-row, 23-workload, and 24-process cohorts separate. Retained-',
    'baseline results are measured directly, not multiplied across unrelated runs.','']
for ref in ['previous','retained']:
    full=json.loads(Path(f'target/native-unobserved-shell-full-{ref}/summary.json').read_text())
    focused=json.loads(Path(f'target/native-unobserved-shell-focused-{ref}/summary.json').read_text())
    reference='6810' if ref=='previous' else 'bf2'
    lines += [f'## Direct comparison with {reference}','',
        f'| Metric | Candidate / {reference} | Candidate / CPython | Wins over CPython |',
        '| --- | ---: | ---: | ---: |']
    c=full['cohorts']
    w=c['all_23_workloads_excluding_startup']['metrics']
    m=c['all_processes_including_startup']['metrics']
    for label,row in [('JIT workload time (23)',w['jit']['ns']),
                      ('Interpreter workload time (23)',w['interp']['ns']),
                      ('JIT process wall time (24)',m['jit']['wall_ns']),
                      ('JIT CPU time (24)',m['jit']['cpu_ns']),
                      ('JIT peak RSS (24)',m['jit']['rss_bytes']),
                      ('Interpreter process wall time (24)',m['interp']['wall_ns']),
                      ('Interpreter CPU time (24)',m['interp']['cpu_ns']),
                      ('Interpreter peak RSS (24)',m['interp']['rss_bytes'])]:
        lines.append(f"| {label} | {row['new_over_base']:.9f} | {row['new_over_cpython']:.9f} | {row['weavepy_wins']} |")
    lines += ['',f'| Focused control | JIT time / {reference} | JIT time / CPython | RSS / {reference} | Time wins (7 pairs) |',
        '| --- | ---: | ---: | ---: | ---: |']
    for name,row in focused['rows'].items():
        v=row['new_over_previous']['jit']
        cp=row['new_over_cpython']['jit']
        lines.append(f"| {name} | {v['ns']:.6f} | {cp['ns']:.6f} | {v['rss_bytes']:.6f} | {row['pairs']['jit']['ns']['wins']} |")
    lines += ['']
lines += ['All raw samples, losses, validation outcomes, load observations, VM/swap',
    'snapshots, methods, inputs, and source snapshots remain. Large text artifacts',
    'use lossless gzip; index.json identifies stored and original bytes. Executables',
    'and frozen caches remain local. Intermediate status notes are historical.','',
    'The user goal remains unachieved. No universal, energy, controlled build-time,',
    'portability, or native parallel-scaling conclusion follows.','']
data='\n'.join(lines).encode()
(out/'REPORT.md').write_bytes(data)
index.append({'path':'REPORT.md','bytes':len(data),'sha256':sha(data)})
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n')
for row in index:
    data=(out/row['path']).read_bytes()
    assert sha(data)==row['sha256']
    if 'uncompressed_sha256' in row:
        raw=gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert sha(raw)==row['uncompressed_sha256']
allow={'!native-unobserved-shell/'}
for path in out.rglob('*'):
    allow.add('!'+str(path.relative_to(base))+('/' if path.is_dir() else ''))
with (base/'.gitignore').open('a') as f:
    f.write('\n# Native activation shell reuse and all observed tradeoffs.\n'+'\n'.join(sorted(allow))+'\n')
with (base/'README.md').open('a') as f:
    f.write('\nThe [unobserved native-shell trial](native-unobserved-shell/REPORT.md) preserves\nobserver exclusion, ownership review, and complete direct and retained-baseline comparisons.\n')
print('Archived',len(index)+1,'files;',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes. All hashes verified.')

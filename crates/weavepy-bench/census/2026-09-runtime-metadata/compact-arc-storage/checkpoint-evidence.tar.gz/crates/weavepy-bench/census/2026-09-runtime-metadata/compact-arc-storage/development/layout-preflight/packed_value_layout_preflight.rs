//! Layout and ABI preflight only; these nonowning pointers are never dereferenced.
use std::hint::black_box;
use std::mem::{align_of, size_of};
use std::ptr::NonNull;
#[derive(Clone, Copy)]
struct WideOwner { pointer: NonNull<()>, len: usize }
#[repr(C, packed)]
#[derive(Clone, Copy)]
struct PackedOwner { pointer: NonNull<()>, len: [u8; 7] }
#[derive(Clone, Copy)]
enum WideValue { None, Bool(bool), Int(i64), Float(f64), Text(WideOwner), Heap(NonNull<()>) }
#[derive(Clone, Copy)]
enum ThinValue { None, Bool(bool), Int(i64), Float(f64), Text(NonNull<()>), Heap(NonNull<()>) }
#[derive(Clone, Copy)]
enum PackedValue { None, Bool(bool), Int(i64), Float(f64), Text(PackedOwner), Heap(NonNull<()>) }
#[inline(never)]
#[no_mangle]
fn wide_roundtrip(value: WideValue) -> WideValue { black_box(value) }
#[inline(never)]
#[no_mangle]
fn thin_roundtrip(value: ThinValue) -> ThinValue { black_box(value) }
#[inline(never)]
#[no_mangle]
fn packed_roundtrip(value: PackedValue) -> PackedValue { black_box(value) }
fn main() {
    black_box(wide_roundtrip(WideValue::Int(7)));
    black_box(thin_roundtrip(ThinValue::Int(7)));
    black_box(packed_roundtrip(PackedValue::Int(7)));
    println!("{{\"WideValue\":{},\"ThinValue\":{},\"PackedValue\":{},\"PackedValue_alignment\":{},\"PackedOwner\":{},\"PackedOwner_alignment\":{}}}",
        size_of::<WideValue>(),size_of::<ThinValue>(),size_of::<PackedValue>(),align_of::<PackedValue>(),size_of::<PackedOwner>(),align_of::<PackedOwner>());
}


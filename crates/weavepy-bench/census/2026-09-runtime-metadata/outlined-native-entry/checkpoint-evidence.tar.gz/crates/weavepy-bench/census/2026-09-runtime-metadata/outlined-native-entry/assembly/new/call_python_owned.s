
target/release/weavepy-runtime-outlined-bound-entry:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bb9e0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned>:
1007bb9e0:     	stp	x28, x27, [sp, #-0x60]!
1007bb9e4:     	stp	x26, x25, [sp, #0x10]
1007bb9e8:     	stp	x24, x23, [sp, #0x20]
1007bb9ec:     	stp	x22, x21, [sp, #0x30]
1007bb9f0:     	stp	x20, x19, [sp, #0x40]
1007bb9f4:     	stp	x29, x30, [sp, #0x50]
1007bb9f8:     	add	x29, sp, #0x50
1007bb9fc:     	sub	sp, sp, #0x700
1007bba00:     	str	xzr, [sp]
1007bba04:     	stp	x4, x1, [sp, #0xb0]
1007bba08:     	stp	x0, x3, [sp, #0x48]
1007bba0c:     	str	x2, [sp, #0x30]
1007bba10:     	ldr	x8, [x2]
1007bba14:     	str	x8, [sp, #0x78]
1007bba18:     	add	x0, x8, #0x10
1007bba1c:     	bl	0x1008b3e34 <__RNvMsw_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_10PyFunction4code>
1007bba20:     	add	x24, sp, #0x640
1007bba24:     	add	x25, sp, #0x410
1007bba28:     	add	x22, sp, #0x300
1007bba2c:     	add	x27, sp, #0x200
1007bba30:     	str	x0, [sp, #0x168]
1007bba34:     	ldr	w9, [x0, #0x1d0]
1007bba38:     	ldrb	w10, [x0, #0x1e0]
1007bba3c:     	ldrb	w11, [x0, #0x1e1]
1007bba40:     	ldr	w8, [x0, #0x1d8]
1007bba44:     	str	x8, [sp, #0x108]
1007bba48:     	str	x9, [sp, #0xf8]
1007bba4c:     	add	x26, x8, x9
1007bba50:     	str	w11, [sp, #0x124]
1007bba54:     	tbz	w11, #0x0, 0x1007bba70 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x90>
1007bba58:     	add	x8, x26, x10
1007bba5c:     	str	x8, [sp]
1007bba60:     	ldr	x8, [sp, #0xb0]
1007bba64:     	ldr	x28, [x8, #0x10]
1007bba68:     	mov	w21, #0x1               ; =1
1007bba6c:     	b	0x1007bba80 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xa0>
1007bba70:     	ldr	x8, [sp, #0xb0]
1007bba74:     	ldr	x28, [x8, #0x10]
1007bba78:     	cbz	x28, 0x1007bbd54 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x374>
1007bba7c:     	mov	x21, #0x0               ; =0
1007bba80:     	str	x10, [sp, #0xa8]
1007bba84:     	ldr	x8, [sp, #0x50]
1007bba88:     	ldp	x19, x23, [x8]
1007bba8c:     	ldr	x8, [x8, #0x10]
1007bba90:     	str	x8, [sp, #0x58]
1007bba94:     	ldr	x8, [sp, #0xf8]
1007bba98:     	str	x8, [sp, #0x538]
1007bba9c:     	mov	w8, #0x1                ; =1
1007bbaa0:     	strb	w8, [sp, #0x410]
1007bbaa4:     	ldr	x2, [x0, #0xb0]
1007bbaa8:     	add	x0, sp, #0x540
1007bbaac:     	add	x1, sp, #0x410
1007bbab0:     	stp	x23, x19, [sp, #0x20]
1007bbab4:     	bl	0x10064b208 <__RINvXNtNtCshxvaOLs88l5_5alloc3vec14spec_from_elemNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectNtB3_12SpecFromElem9from_elemNtNtB7_5alloc6GlobalEBP_>
1007bbab8:     	ldr	x8, [sp, #0xa8]
1007bbabc:     	add	x8, x26, x8
1007bbac0:     	add	x0, x8, x21
1007bbac4:     	str	xzr, [sp, #0x560]
1007bbac8:     	str	xzr, [sp, #0x558]
1007bbacc:     	cmp	x0, #0x11
1007bbad0:     	str	x0, [sp, #0xd8]
1007bbad4:     	b.hs	0x1007bbae4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x104>
1007bbad8:     	add	x8, sp, #0x558
1007bbadc:     	str	x8, [sp, #0x160]
1007bbae0:     	b	0x1007bbaf8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x118>
1007bbae4:     	mov	w1, #0x1                ; =1
1007bbae8:     	bl	0x10100fc4c <dyld_stub_binder+0x10100fc4c>
1007bbaec:     	str	x0, [sp, #0x160]
1007bbaf0:     	str	x0, [sp, #0x10]
1007bbaf4:     	cbz	x0, 0x1007bed98 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x33b8>
1007bbaf8:     	ldr	x9, [sp, #0x58]
1007bbafc:     	str	x9, [sp, #0x568]
1007bbb00:     	ldr	x8, [sp, #0x538]
1007bbb04:     	cmp	x8, x9
1007bbb08:     	csel	x20, x8, x9, lo
1007bbb0c:     	mov	w8, #0x18               ; =24
1007bbb10:     	madd	x10, x9, x8, x23
1007bbb14:     	str	x23, [sp, #0x570]
1007bbb18:     	str	x19, [sp, #0x580]
1007bbb1c:     	str	x10, [sp, #0x588]
1007bbb20:     	mov	x19, x23
1007bbb24:     	str	x21, [sp, #0x38]
1007bbb28:     	str	x26, [sp, #0x130]
1007bbb2c:     	str	x28, [sp, #0x158]
1007bbb30:     	cbz	x20, 0x1007bbc2c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x24c>
1007bbb34:     	str	x10, [sp, #0x150]
1007bbb38:     	mov	x22, #0x0               ; =0
1007bbb3c:     	mov	x26, #0x0               ; =0
1007bbb40:     	add	x8, sp, #0x410
1007bbb44:     	mov	x10, x23
1007bbb48:     	orr	x23, x8, #0x1
1007bbb4c:     	ldr	x19, [sp, #0x550]
1007bbb50:     	ldr	x25, [sp, #0x548]
1007bbb54:     	ldr	x8, [sp, #0xf8]
1007bbb58:     	add	x8, x21, x8
1007bbb5c:     	ldr	x9, [sp, #0x108]
1007bbb60:     	ldr	x11, [sp, #0xa8]
1007bbb64:     	add	x9, x11, x9
1007bbb68:     	add	x8, x8, x9
1007bbb6c:     	add	x8, x8, x8, lsl #1
1007bbb70:     	lsl	x27, x8, #3
1007bbb74:     	ldr	x8, [sp, #0x58]
1007bbb78:     	add	x8, x8, x8, lsl #1
1007bbb7c:     	lsl	x28, x8, #3
1007bbb80:     	mov	x8, x10
1007bbb84:     	cmp	x28, x22
1007bbb88:     	b.eq	0x1007bef54 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3574>
1007bbb8c:     	mov	x24, x8
1007bbb90:     	ldrb	w9, [x24], #0x18
1007bbb94:     	cmp	w9, #0xff
1007bbb98:     	b.eq	0x1007bef44 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3564>
1007bbb9c:     	strb	w9, [sp, #0x410]
1007bbba0:     	ldur	w9, [x8, #0x11]
1007bbba4:     	ldurh	w10, [x8, #0x15]
1007bbba8:     	ldrb	w11, [x8, #0x17]
1007bbbac:     	ldur	q0, [x8, #0x1]
1007bbbb0:     	str	q0, [x23]
1007bbbb4:     	strb	w11, [x23, #0x16]
1007bbbb8:     	strh	w10, [x23, #0x14]
1007bbbbc:     	str	w9, [x23, #0x10]
1007bbbc0:     	cmp	x19, x26
1007bbbc4:     	b.eq	0x1007bec18 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3238>
1007bbbc8:     	add	x21, x25, x22
1007bbbcc:     	add	x0, x25, x22
1007bbbd0:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bbbd4:     	add	x8, sp, #0x410
1007bbbd8:     	ldr	q0, [x8]
1007bbbdc:     	ldr	x8, [sp, #0x420]
1007bbbe0:     	str	x8, [x21, #0x10]
1007bbbe4:     	str	q0, [x21]
1007bbbe8:     	cmp	x27, x22
1007bbbec:     	b.eq	0x1007bec40 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3260>
1007bbbf0:     	ldr	x8, [sp, #0x160]
1007bbbf4:     	mov	w9, #0x1                ; =1
1007bbbf8:     	strb	w9, [x8, x26]
1007bbbfc:     	add	x26, x26, #0x1
1007bbc00:     	add	x22, x22, #0x18
1007bbc04:     	mov	x8, x24
1007bbc08:     	cmp	x20, x26
1007bbc0c:     	b.ne	0x1007bbb84 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1a4>
1007bbc10:     	ldr	x23, [sp, #0x20]
1007bbc14:     	add	x19, x23, x22
1007bbc18:     	add	x25, sp, #0x410
1007bbc1c:     	add	x27, sp, #0x200
1007bbc20:     	add	x24, sp, #0x640
1007bbc24:     	ldr	x26, [sp, #0x130]
1007bbc28:     	ldp	x10, x28, [sp, #0x150]
1007bbc2c:     	str	x19, [sp, #0x578]
1007bbc30:     	ldr	x8, [sp, #0xa8]
1007bbc34:     	tbz	w8, #0x0, 0x1007bbcb4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2d4>
1007bbc38:     	sub	x22, x10, x19
1007bbc3c:     	lsr	x8, x22, #3
1007bbc40:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
1007bbc44:     	movk	x9, #0xaaab
1007bbc48:     	mul	x20, x8, x9
1007bbc4c:     	cmp	x23, x19
1007bbc50:     	b.eq	0x1007bbdd0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f0>
1007bbc54:     	ldr	x9, [sp, #0x28]
1007bbc58:     	cmp	x20, x9, lsr #1
1007bbc5c:     	b.hs	0x1007bbdc0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3e0>
1007bbc60:     	mov	x21, #0x0               ; =0
1007bbc64:     	mov	w8, #0x8                ; =8
1007bbc68:     	str	xzr, [sp, #0x300]
1007bbc6c:     	str	x8, [sp, #0x308]
1007bbc70:     	str	xzr, [sp, #0x310]
1007bbc74:     	str	x23, [sp, #0x410]
1007bbc78:     	str	x19, [sp, #0x418]
1007bbc7c:     	str	x9, [sp, #0x420]
1007bbc80:     	str	x10, [sp, #0x428]
1007bbc84:     	cmp	x10, x19
1007bbc88:     	b.ne	0x1007be9e4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3004>
1007bbc8c:     	add	x8, x21, x20
1007bbc90:     	str	x8, [sp, #0x310]
1007bbc94:     	cbz	x9, 0x1007bbca0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2c0>
1007bbc98:     	mov	x0, x23
1007bbc9c:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bbca0:     	ldr	q0, [x27, #0x100]
1007bbca4:     	str	q0, [x27]
1007bbca8:     	ldr	x8, [sp, #0x310]
1007bbcac:     	str	x8, [sp, #0x210]
1007bbcb0:     	b	0x1007bbde0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x400>
1007bbcb4:     	ldr	x9, [sp, #0x568]
1007bbcb8:     	ldr	x8, [sp, #0x538]
1007bbcbc:     	cmp	x9, x8
1007bbcc0:     	ldr	x22, [sp, #0xb8]
1007bbcc4:     	b.ls	0x1007bbd48 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x368>
1007bbcc8:     	ldr	x9, [sp, #0x78]
1007bbccc:     	ldr	x9, [x9, #0x38]
1007bbcd0:     	subs	x8, x8, x9
1007bbcd4:     	csel	x8, xzr, x8, lo
1007bbcd8:     	stur	x8, [x29, #-0xf0]
1007bbcdc:     	adrp	x20, 0x100051000 <__RNvXs6_NtNtCs8Mbv00yxnRz_4core3fmt5floatdNtB7_5Debug3fmt+0x48>
1007bbce0:     	add	x20, x20, #0xf7c
1007bbce4:     	cbz	x9, 0x1007bbe6c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x48c>
1007bbce8:     	sub	x8, x29, #0xf0
1007bbcec:     	str	x8, [sp, #0x410]
1007bbcf0:     	str	x20, [sp, #0x418]
1007bbcf4:     	add	x8, sp, #0x538
1007bbcf8:     	str	x8, [sp, #0x420]
1007bbcfc:     	str	x20, [sp, #0x428]
1007bbd00:     	mov	w8, #0x1                ; =1
1007bbd04:     	str	w8, [sp, #0x64]
1007bbd08:     	mov	x8, #-0x1               ; =-1
1007bbd0c:     	str	x8, [sp, #0xa0]
1007bbd10:     	adrp	x0, 0x10102f000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3362+0x248f>
1007bbd14:     	add	x0, x0, #0xa74
1007bbd18:     	add	x8, sp, #0x300
1007bbd1c:     	add	x1, sp, #0x410
1007bbd20:     	mov	w28, #0x1               ; =1
1007bbd24:     	mov	w19, #0x1               ; =1
1007bbd28:     	mov	w22, #0x1               ; =1
1007bbd2c:     	bl	0x100006330 <__RNvNvNtCshxvaOLs88l5_5alloc3fmt6format12format_inner>
1007bbd30:     	ldr	q0, [x27, #0x100]
1007bbd34:     	str	q0, [x25, #0x1c0]
1007bbd38:     	ldr	x8, [sp, #0x310]
1007bbd3c:     	str	x8, [sp, #0x5e0]
1007bbd40:     	add	x19, sp, #0x300
1007bbd44:     	b	0x1007bbed4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4f4>
1007bbd48:     	mov	w8, #0x1                ; =1
1007bbd4c:     	str	w8, [sp, #0x64]
1007bbd50:     	b	0x1007bbe60 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x480>
1007bbd54:     	ldr	x8, [sp, #0x50]
1007bbd58:     	ldr	x8, [x8, #0x10]
1007bbd5c:     	ldr	x9, [sp, #0xf8]
1007bbd60:     	cmp	x8, x9
1007bbd64:     	ldr	x8, [sp, #0x108]
1007bbd68:     	ccmp	w8, #0x0, #0x0, eq
1007bbd6c:     	b.ne	0x1007bcc04 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1224>
1007bbd70:     	mov	x21, x28
1007bbd74:     	tbnz	w10, #0x0, 0x1007bba80 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xa0>
1007bbd78:     	ldr	x8, [sp, #0x50]
1007bbd7c:     	ldr	q0, [x8]
1007bbd80:     	str	q0, [x27]
1007bbd84:     	ldr	x8, [x8, #0x10]
1007bbd88:     	str	x8, [sp, #0x210]
1007bbd8c:     	ldr	x9, [x0, #0xb0]
1007bbd90:     	mov	w10, #0x1               ; =1
1007bbd94:     	strb	w10, [sp, #0x300]
1007bbd98:     	subs	x1, x9, x8
1007bbd9c:     	b.ls	0x1007bcc0c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x122c>
1007bbda0:     	ldr	q0, [x22]
1007bbda4:     	str	q0, [x25]
1007bbda8:     	ldr	x8, [sp, #0x310]
1007bbdac:     	str	x8, [sp, #0x420]
1007bbdb0:     	add	x0, sp, #0x200
1007bbdb4:     	add	x2, sp, #0x410
1007bbdb8:     	bl	0x10085221c <__RNvMs3_NtCshxvaOLs88l5_5alloc3vecINtB5_3VecNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectE11extend_withBJ_>
1007bbdbc:     	b	0x1007bcc44 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1264>
1007bbdc0:     	mov	x0, x23
1007bbdc4:     	mov	x1, x19
1007bbdc8:     	mov	x2, x22
1007bbdcc:     	bl	0x1010102dc <dyld_stub_binder+0x1010102dc>
1007bbdd0:     	ldr	x8, [sp, #0x28]
1007bbdd4:     	str	x8, [sp, #0x200]
1007bbdd8:     	str	x23, [sp, #0x208]
1007bbddc:     	str	x20, [sp, #0x210]
1007bbde0:     	mov	w28, #0x1               ; =1
1007bbde4:     	mov	x8, #-0x1               ; =-1
1007bbde8:     	str	x8, [sp, #0xa0]
1007bbdec:     	str	wzr, [sp, #0x64]
1007bbdf0:     	add	x8, sp, #0x410
1007bbdf4:     	add	x0, sp, #0x200
1007bbdf8:     	mov	w19, #0x1               ; =1
1007bbdfc:     	mov	w22, #0x1               ; =1
1007bbe00:     	ldr	x20, [sp, #0xd8]
1007bbe04:     	bl	0x100885620 <__RNvMsV_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6Object9new_tuple>
1007bbe08:     	ldr	x1, [sp, #0x550]
1007bbe0c:     	cmp	x26, x1
1007bbe10:     	b.hs	0x1007beda8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x33c8>
1007bbe14:     	ldr	x8, [sp, #0x548]
1007bbe18:     	mov	w9, #0x18               ; =24
1007bbe1c:     	mul	x9, x26, x9
1007bbe20:     	add	x19, x8, x9
1007bbe24:     	mov	x0, x19
1007bbe28:     	add	x21, sp, #0x300
1007bbe2c:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bbe30:     	ldr	x22, [sp, #0xb8]
1007bbe34:     	ldr	q0, [x21, #0x110]
1007bbe38:     	ldr	x8, [sp, #0x420]
1007bbe3c:     	str	x8, [x19, #0x10]
1007bbe40:     	str	q0, [x19]
1007bbe44:     	cmp	x26, x20
1007bbe48:     	ldr	x28, [sp, #0x158]
1007bbe4c:     	b.hs	0x1007bedbc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x33dc>
1007bbe50:     	str	wzr, [sp, #0x64]
1007bbe54:     	mov	w8, #0x1                ; =1
1007bbe58:     	ldr	x9, [sp, #0x160]
1007bbe5c:     	strb	w8, [x9, x26]
1007bbe60:     	mov	x8, #-0x1               ; =-1
1007bbe64:     	str	x8, [sp, #0xa0]
1007bbe68:     	b	0x1007bc1a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x7c0>
1007bbe6c:     	add	x8, sp, #0x538
1007bbe70:     	str	x8, [sp, #0x300]
1007bbe74:     	str	x20, [sp, #0x308]
1007bbe78:     	mov	w8, #0x1                ; =1
1007bbe7c:     	str	w8, [sp, #0x64]
1007bbe80:     	mov	x8, #-0x1               ; =-1
1007bbe84:     	str	x8, [sp, #0xa0]
1007bbe88:     	adrp	x0, 0x10102c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.1781+0xc8d>
1007bbe8c:     	add	x0, x0, #0xb71
1007bbe90:     	add	x8, sp, #0x410
1007bbe94:     	add	x1, sp, #0x300
1007bbe98:     	mov	w28, #0x1               ; =1
1007bbe9c:     	mov	w19, #0x1               ; =1
1007bbea0:     	mov	w22, #0x1               ; =1
1007bbea4:     	bl	0x100006330 <__RNvNvNtCshxvaOLs88l5_5alloc3fmt6format12format_inner>
1007bbea8:     	add	x19, sp, #0x300
1007bbeac:     	ldr	q0, [x19, #0x110]
1007bbeb0:     	str	q0, [x25, #0x1c0]
1007bbeb4:     	ldr	x8, [sp, #0x420]
1007bbeb8:     	str	x8, [sp, #0x5e0]
1007bbebc:     	ldr	x8, [sp, #0x538]
1007bbec0:     	cmp	x8, #0x1
1007bbec4:     	b.ne	0x1007bbed4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4f4>
1007bbec8:     	mov	x8, #0x0                ; =0
1007bbecc:     	mov	w9, #0x1                ; =1
1007bbed0:     	b	0x1007bbee0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x500>
1007bbed4:     	adrp	x9, 0x1011e2000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.1285+0x2c0>
1007bbed8:     	add	x9, x9, #0x2f7
1007bbedc:     	mov	w8, #0x1                ; =1
1007bbee0:     	ldr	x22, [sp, #0xb8]
1007bbee4:     	ldr	x28, [sp, #0x158]
1007bbee8:     	stp	x9, x8, [x29, #-0x80]
1007bbeec:     	adrp	x12, 0x100ce6000 <__RNvXsq_NtCshxvaOLs88l5_5alloc3vecINtB5_3VechENtNtCs8Mbv00yxnRz_4core3fmt5Debug3fmtCshqYhlee0Vj9_10weavepy_vm+0x84>
1007bbef0:     	add	x12, x12, #0x17c
1007bbef4:     	adrp	x11, 0x100cc8000 <__RNvXs1g_NtCs8Mbv00yxnRz_4core3fmtRSNtNtNtCs2shuIYlUyos_6rustls4msgs9handshake20KeyExchangeAlgorithmNtB6_5Debug3fmtCshqYhlee0Vj9_10weavepy_vm+0xa0>
1007bbef8:     	add	x11, x11, #0xfa8
1007bbefc:     	ldr	x13, [sp, #0x168]
1007bbf00:     	cbz	x28, 0x1007bc09c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x6bc>
1007bbf04:     	ldr	x8, [sp, #0x108]
1007bbf08:     	cbz	w8, 0x1007bc09c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x6bc>
1007bbf0c:     	ldr	x8, [x13, #0xb0]
1007bbf10:     	cmp	x26, x8
1007bbf14:     	b.hi	0x1007bc09c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x6bc>
1007bbf18:     	mov	x28, #0x0               ; =0
1007bbf1c:     	mov	x27, #0x0               ; =0
1007bbf20:     	ldr	x8, [sp, #0xb0]
1007bbf24:     	ldr	x26, [x8, #0x8]
1007bbf28:     	str	x13, [sp, #0x150]
1007bbf2c:     	ldr	x8, [x13, #0xa8]
1007bbf30:     	mov	w9, #0x18               ; =24
1007bbf34:     	ldr	x10, [sp, #0xf8]
1007bbf38:     	umaddl	x8, w10, w9, x8
1007bbf3c:     	add	x25, x8, #0x10
1007bbf40:     	ldr	x8, [sp, #0x108]
1007bbf44:     	add	x8, x8, x8, lsl #1
1007bbf48:     	lsl	x22, x8, #3
1007bbf4c:     	mov	w23, #0x30              ; =48
1007bbf50:     	b	0x1007bbf6c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x58c>
1007bbf54:     	mov	x8, #0x0                ; =0
1007bbf58:     	add	x27, x8, x27
1007bbf5c:     	add	x28, x28, #0x1
1007bbf60:     	ldr	x8, [sp, #0x158]
1007bbf64:     	cmp	x28, x8
1007bbf68:     	b.eq	0x1007bbfc4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x5e4>
1007bbf6c:     	madd	x8, x28, x23, x26
1007bbf70:     	ldp	x19, x20, [x8, #0x8]
1007bbf74:     	mov	x24, x22
1007bbf78:     	mov	x21, x25
1007bbf7c:     	b	0x1007bbf8c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x5ac>
1007bbf80:     	add	x21, x21, #0x18
1007bbf84:     	subs	x24, x24, #0x18
1007bbf88:     	b.eq	0x1007bbf54 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x574>
1007bbf8c:     	ldr	x8, [x21]
1007bbf90:     	cmp	x8, x20
1007bbf94:     	b.ne	0x1007bbf80 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x5a0>
1007bbf98:     	ldur	x0, [x21, #-0x8]
1007bbf9c:     	mov	x1, x19
1007bbfa0:     	mov	x2, x20
1007bbfa4:     	bl	0x1010102c4 <dyld_stub_binder+0x1010102c4>
1007bbfa8:     	cbnz	w0, 0x1007bbf80 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x5a0>
1007bbfac:     	mov	w8, #0x1                ; =1
1007bbfb0:     	add	x27, x8, x27
1007bbfb4:     	add	x28, x28, #0x1
1007bbfb8:     	ldr	x8, [sp, #0x158]
1007bbfbc:     	cmp	x28, x8
1007bbfc0:     	b.ne	0x1007bbf6c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x58c>
1007bbfc4:     	stur	x27, [x29, #-0xa0]
1007bbfc8:     	add	x19, sp, #0x300
1007bbfcc:     	ldr	x22, [sp, #0xb8]
1007bbfd0:     	add	x25, sp, #0x410
1007bbfd4:     	add	x24, sp, #0x640
1007bbfd8:     	ldp	x13, x28, [sp, #0x150]
1007bbfdc:     	adrp	x20, 0x100051000 <__RNvXs6_NtNtCs8Mbv00yxnRz_4core3fmt5floatdNtB7_5Debug3fmt+0x48>
1007bbfe0:     	add	x20, x20, #0xf7c
1007bbfe4:     	adrp	x11, 0x100cc8000 <__RNvXs1g_NtCs8Mbv00yxnRz_4core3fmtRSNtNtNtCs2shuIYlUyos_6rustls4msgs9handshake20KeyExchangeAlgorithmNtB6_5Debug3fmtCshqYhlee0Vj9_10weavepy_vm+0xa0>
1007bbfe8:     	add	x11, x11, #0xfa8
1007bbfec:     	adrp	x12, 0x100ce6000 <__RNvXsq_NtCshxvaOLs88l5_5alloc3vecINtB5_3VechENtNtCs8Mbv00yxnRz_4core3fmt5Debug3fmtCshqYhlee0Vj9_10weavepy_vm+0x84>
1007bbff0:     	add	x12, x12, #0x17c
1007bbff4:     	cbz	x27, 0x1007bc0a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x6c0>
1007bbff8:     	ldr	x8, [sp, #0x568]
1007bbffc:     	cmp	x8, #0x1
1007bc000:     	cset	w8, ne
1007bc004:     	adrp	x10, 0x1011e2000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.1285+0x2c0>
1007bc008:     	add	x10, x10, #0x2f7
1007bc00c:     	csinc	x9, x10, xzr, ne
1007bc010:     	str	x9, [sp, #0x200]
1007bc014:     	str	x8, [sp, #0x208]
1007bc018:     	cmp	x27, #0x1
1007bc01c:     	cset	w8, ne
1007bc020:     	csinc	x9, x10, xzr, ne
1007bc024:     	str	x9, [sp, #0x300]
1007bc028:     	str	x8, [sp, #0x308]
1007bc02c:     	add	x8, x13, #0x28
1007bc030:     	str	x8, [sp, #0x410]
1007bc034:     	str	x12, [sp, #0x418]
1007bc038:     	add	x8, sp, #0x5d0
1007bc03c:     	str	x8, [sp, #0x420]
1007bc040:     	str	x12, [sp, #0x428]
1007bc044:     	sub	x8, x29, #0x80
1007bc048:     	str	x8, [sp, #0x430]
1007bc04c:     	str	x11, [sp, #0x438]
1007bc050:     	add	x8, sp, #0x568
1007bc054:     	str	x8, [sp, #0x440]
1007bc058:     	str	x20, [sp, #0x448]
1007bc05c:     	add	x8, sp, #0x200
1007bc060:     	str	x8, [sp, #0x450]
1007bc064:     	str	x11, [sp, #0x458]
1007bc068:     	sub	x8, x29, #0xa0
1007bc06c:     	str	x8, [sp, #0x460]
1007bc070:     	str	x20, [sp, #0x468]
1007bc074:     	add	x8, sp, #0x300
1007bc078:     	str	x8, [sp, #0x470]
1007bc07c:     	str	x11, [sp, #0x478]
1007bc080:     	adrp	x0, 0x10102f000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3362+0x248f>
1007bc084:     	add	x0, x0, #0xab6
1007bc088:     	add	x8, sp, #0x590
1007bc08c:     	add	x1, sp, #0x410
1007bc090:     	bl	0x100006330 <__RNvNvNtCshxvaOLs88l5_5alloc3fmt6format12format_inner>
1007bc094:     	add	x27, sp, #0x200
1007bc098:     	b	0x1007bc120 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x740>
1007bc09c:     	stur	xzr, [x29, #-0xa0]
1007bc0a0:     	adrp	x8, 0x102367000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.19115+0x2d5b>
1007bc0a4:     	add	x8, x8, #0xaa4
1007bc0a8:     	ldr	x9, [sp, #0x568]
1007bc0ac:     	adrp	x10, 0x10120e000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4365+0x17c5>
1007bc0b0:     	add	x10, x10, #0xc19
1007bc0b4:     	cmp	x9, #0x1
1007bc0b8:     	csel	x8, x10, x8, eq
1007bc0bc:     	mov	w9, #0x3                ; =3
1007bc0c0:     	cinc	x9, x9, ne
1007bc0c4:     	str	x8, [sp, #0x300]
1007bc0c8:     	str	x9, [sp, #0x308]
1007bc0cc:     	add	x8, x13, #0x28
1007bc0d0:     	str	x8, [sp, #0x410]
1007bc0d4:     	str	x12, [sp, #0x418]
1007bc0d8:     	add	x8, sp, #0x5d0
1007bc0dc:     	str	x8, [sp, #0x420]
1007bc0e0:     	str	x12, [sp, #0x428]
1007bc0e4:     	sub	x8, x29, #0x80
1007bc0e8:     	str	x8, [sp, #0x430]
1007bc0ec:     	str	x11, [sp, #0x438]
1007bc0f0:     	add	x8, sp, #0x568
1007bc0f4:     	str	x8, [sp, #0x440]
1007bc0f8:     	str	x20, [sp, #0x448]
1007bc0fc:     	add	x8, sp, #0x300
1007bc100:     	str	x8, [sp, #0x450]
1007bc104:     	str	x11, [sp, #0x458]
1007bc108:     	adrp	x0, 0x10102f000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3362+0x248f>
1007bc10c:     	add	x0, x0, #0xa82
1007bc110:     	add	x8, sp, #0x590
1007bc114:     	add	x1, sp, #0x410
1007bc118:     	bl	0x100006330 <__RNvNvNtCshxvaOLs88l5_5alloc3fmt6format12format_inner>
1007bc11c:     	add	x27, sp, #0x200
1007bc120:     	ldr	x8, [sp, #0x590]
1007bc124:     	str	x8, [sp, #0xa0]
1007bc128:     	ldr	x21, [sp, #0x598]
1007bc12c:     	ldr	x8, [sp, #0x5a0]
1007bc130:     	str	x8, [sp, #0x8]
1007bc134:     	ldp	q1, q0, [x25, #0x160]
1007bc138:     	stp	q1, q0, [x19, #0x110]
1007bc13c:     	ldr	x20, [sp, #0x428]
1007bc140:     	ldr	x19, [sp, #0x418]
1007bc144:     	cmp	x19, x20
1007bc148:     	str	x21, [sp, #0x18]
1007bc14c:     	b.eq	0x1007bc17c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x79c>
1007bc150:     	ldr	q0, [x19]
1007bc154:     	str	q0, [x27]
1007bc158:     	ldr	x8, [x19, #0x10]
1007bc15c:     	str	x8, [sp, #0x210]
1007bc160:     	add	x19, x19, #0x18
1007bc164:     	str	q0, [x27, #0x100]
1007bc168:     	str	x8, [sp, #0x310]
1007bc16c:     	add	x0, sp, #0x300
1007bc170:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bc174:     	cmp	x19, x20
1007bc178:     	b.ne	0x1007bc150 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x770>
1007bc17c:     	ldr	x8, [sp, #0x420]
1007bc180:     	cbz	x8, 0x1007bc18c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x7ac>
1007bc184:     	ldr	x0, [sp, #0x410]
1007bc188:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bc18c:     	ldr	x8, [sp, #0x5d0]
1007bc190:     	cbz	x8, 0x1007bc19c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x7bc>
1007bc194:     	ldr	x0, [sp, #0x5d8]
1007bc198:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bc19c:     	str	wzr, [sp, #0x64]
1007bc1a0:     	mov	w8, #0x8                ; =8
1007bc1a4:     	str	xzr, [sp, #0x200]
1007bc1a8:     	str	x8, [sp, #0x208]
1007bc1ac:     	str	xzr, [sp, #0x210]
1007bc1b0:     	adrp	x8, 0x10261b000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.167+0x140>
1007bc1b4:     	add	x8, x8, #0xc60
1007bc1b8:     	ldp	q0, q1, [x8]
1007bc1bc:     	stur	q0, [x27, #0x18]
1007bc1c0:     	stur	q1, [x27, #0x28]
1007bc1c4:     	mov	x8, x22
1007bc1c8:     	ldr	x9, [x8, #0x80]!
1007bc1cc:     	cbnz	x9, 0x1007be98c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2fac>
1007bc1d0:     	mov	x9, #-0x1               ; =-1
1007bc1d4:     	str	x9, [x22, #0x80]
1007bc1d8:     	ldr	x9, [x22, #0x88]
1007bc1dc:     	str	x9, [sp, #0x110]
1007bc1e0:     	str	x9, [sp, #0x5a8]
1007bc1e4:     	stp	xzr, xzr, [x8]
1007bc1e8:     	ldr	x8, [sp, #0x168]
1007bc1ec:     	ldr	w8, [x8, #0x1d4]
1007bc1f0:     	str	x8, [sp, #0x150]
1007bc1f4:     	cbz	x28, 0x1007bc28c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x8ac>
1007bc1f8:     	ldr	w8, [sp, #0x124]
1007bc1fc:     	tbnz	w8, #0x0, 0x1007bc28c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x8ac>
1007bc200:     	ldr	x8, [sp, #0x150]
1007bc204:     	cbz	w8, 0x1007bc28c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x8ac>
1007bc208:     	ldr	x8, [sp, #0xb0]
1007bc20c:     	ldr	x20, [x8, #0x8]
1007bc210:     	add	x8, x28, x28, lsl #1
1007bc214:     	lsl	x19, x8, #3
1007bc218:     	mov	x0, x19
1007bc21c:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bc220:     	cbz	x0, 0x1007bedec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x340c>
1007bc224:     	mov	x21, #0x0               ; =0
1007bc228:     	str	x28, [sp, #0x410]
1007bc22c:     	str	x0, [sp, #0x418]
1007bc230:     	add	x22, x0, #0x8
1007bc234:     	str	x20, [sp, #0x88]
1007bc238:     	add	x23, x20, #0x10
1007bc23c:     	b	0x1007bc260 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x880>
1007bc240:     	mov	w20, #0x1               ; =1
1007bc244:     	add	x23, x23, #0x30
1007bc248:     	stp	x19, x20, [x22, #-0x8]
1007bc24c:     	str	x19, [x22, #0x8]
1007bc250:     	add	x21, x21, #0x1
1007bc254:     	add	x22, x22, #0x18
1007bc258:     	cmp	x28, x21
1007bc25c:     	b.eq	0x1007bc3a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x9c8>
1007bc260:     	ldr	x19, [x23]
1007bc264:     	cbz	x19, 0x1007bc240 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x860>
1007bc268:     	ldur	x26, [x23, #-0x8]
1007bc26c:     	mov	x0, x19
1007bc270:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bc274:     	cbz	x0, 0x1007becc4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x32e4>
1007bc278:     	mov	x20, x0
1007bc27c:     	mov	x1, x26
1007bc280:     	mov	x2, x19
1007bc284:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007bc288:     	b	0x1007bc244 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x864>
1007bc28c:     	mov	w8, #0x8                ; =8
1007bc290:     	str	xzr, [sp, #0x5b0]
1007bc294:     	str	x8, [sp, #0x5b8]
1007bc298:     	str	xzr, [sp, #0x5c0]
1007bc29c:     	ldr	x8, [sp, #0xb0]
1007bc2a0:     	ldp	x9, x21, [x8]
1007bc2a4:     	mov	w8, #0x30               ; =48
1007bc2a8:     	madd	x20, x28, x8, x21
1007bc2ac:     	str	x21, [sp, #0x5d0]
1007bc2b0:     	str	x21, [sp, #0x5d8]
1007bc2b4:     	str	x9, [sp, #0x40]
1007bc2b8:     	str	x9, [sp, #0x5e0]
1007bc2bc:     	str	x20, [sp, #0x5e8]
1007bc2c0:     	str	x21, [sp, #0x88]
1007bc2c4:     	cbnz	x28, 0x1007bc3e0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xa00>
1007bc2c8:     	sub	x8, x20, x21
1007bc2cc:     	lsr	x8, x8, #4
1007bc2d0:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
1007bc2d4:     	movk	x9, #0xaaab
1007bc2d8:     	mov	x10, #0x1               ; =1
1007bc2dc:     	madd	x20, x8, x9, x10
1007bc2e0:     	ldr	x23, [sp, #0xd8]
1007bc2e4:     	ldr	x28, [sp, #0x38]
1007bc2e8:     	b	0x1007bc2fc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x91c>
1007bc2ec:     	add	x19, x21, #0x30
1007bc2f0:     	add	x0, x21, #0x18
1007bc2f4:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bc2f8:     	mov	x21, x19
1007bc2fc:     	subs	x20, x20, #0x1
1007bc300:     	b.eq	0x1007bc318 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x938>
1007bc304:     	ldr	x8, [x21]
1007bc308:     	cbz	x8, 0x1007bc2ec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x90c>
1007bc30c:     	ldr	x0, [x21, #0x8]
1007bc310:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bc314:     	b	0x1007bc2ec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x90c>
1007bc318:     	ldr	x26, [sp, #0x130]
1007bc31c:     	ldr	x8, [sp, #0x40]
1007bc320:     	ldr	x19, [sp, #0x8]
1007bc324:     	cbz	x8, 0x1007bc330 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x950>
1007bc328:     	ldr	x0, [sp, #0x88]
1007bc32c:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bc330:     	ldr	x8, [sp, #0xa0]
1007bc334:     	cmn	x8, #0x1
1007bc338:     	cset	w9, eq
1007bc33c:     	str	w9, [sp, #0x150]
1007bc340:     	ldr	x9, [sp, #0x18]
1007bc344:     	b.eq	0x1007bca10 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1030>
1007bc348:     	str	x8, [sp, #0x300]
1007bc34c:     	str	x9, [sp, #0x308]
1007bc350:     	mov	w8, #0x1                ; =1
1007bc354:     	str	w8, [sp, #0x158]
1007bc358:     	str	x19, [sp, #0x310]
1007bc35c:     	add	x0, sp, #0x410
1007bc360:     	add	x1, sp, #0x300
1007bc364:     	bl	0x100616cac <__RINvNtCshqYhlee0Vj9_10weavepy_vm5error10type_errorNtNtCshxvaOLs88l5_5alloc6string6StringEB4_>
1007bc368:     	mov	w24, #0x0               ; =0
1007bc36c:     	ldur	q0, [x25, #0x8]
1007bc370:     	str	q0, [sp, #0x1e0]
1007bc374:     	ldr	x21, [sp, #0x410]
1007bc378:     	ldr	x8, [sp, #0x428]
1007bc37c:     	str	x8, [sp, #0x1f0]
1007bc380:     	ldp	q0, q1, [x25, #0x20]
1007bc384:     	stp	q0, q1, [sp, #0x1b0]
1007bc388:     	ldr	x8, [sp, #0x450]
1007bc38c:     	mov	w9, #0x1                ; =1
1007bc390:     	str	w9, [sp, #0x158]
1007bc394:     	str	x8, [sp, #0x1d0]
1007bc398:     	ldr	x19, [sp, #0x5b8]
1007bc39c:     	ldr	x20, [sp, #0x5c0]
1007bc3a0:     	cbnz	x20, 0x1007bdb74 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2194>
1007bc3a4:     	b	0x1007bdb9c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x21bc>
1007bc3a8:     	add	x8, sp, #0x300
1007bc3ac:     	ldr	q0, [x8, #0x110]
1007bc3b0:     	str	q0, [x25, #0x1a0]
1007bc3b4:     	str	x28, [sp, #0x5c0]
1007bc3b8:     	ldr	x8, [sp, #0xb0]
1007bc3bc:     	ldr	x10, [x8]
1007bc3c0:     	mov	w8, #0x30               ; =48
1007bc3c4:     	ldr	x9, [sp, #0x88]
1007bc3c8:     	madd	x20, x28, x8, x9
1007bc3cc:     	str	x9, [sp, #0x5d0]
1007bc3d0:     	str	x9, [sp, #0x5d8]
1007bc3d4:     	str	x10, [sp, #0x40]
1007bc3d8:     	str	x10, [sp, #0x5e0]
1007bc3dc:     	str	x20, [sp, #0x5e8]
1007bc3e0:     	ldr	x8, [sp, #0x108]
1007bc3e4:     	add	x8, x8, x8, lsl #1
1007bc3e8:     	lsl	x8, x8, #3
1007bc3ec:     	str	x8, [sp, #0x98]
1007bc3f0:     	adrp	x0, 0x102676000 <_BZ2_rNums+0x2d8>
1007bc3f4:     	add	x0, x0, #0xba8
1007bc3f8:     	ldr	x8, [x0]
1007bc3fc:     	blr	x8
1007bc400:     	str	x0, [sp, #0x140]
1007bc404:     	mov	x28, #0x0               ; =0
1007bc408:     	add	x8, sp, #0x410
1007bc40c:     	orr	x8, x8, #0x1
1007bc410:     	str	x8, [sp, #0xd0]
1007bc414:     	add	x8, sp, #0x648
1007bc418:     	orr	x8, x8, #0x1
1007bc41c:     	str	x8, [sp, #0x100]
1007bc420:     	ldr	x21, [sp, #0x88]
1007bc424:     	sub	x8, x20, x21
1007bc428:     	sub	x19, x8, #0x30
1007bc42c:     	mov	w9, #0x18               ; =24
1007bc430:     	ldr	x8, [sp, #0x150]
1007bc434:     	umull	x8, w8, w9
1007bc438:     	add	x8, x8, #0x10
1007bc43c:     	str	x8, [sp, #0x80]
1007bc440:     	ldr	x8, [sp, #0xf8]
1007bc444:     	umull	x8, w8, w9
1007bc448:     	add	x8, x8, #0x10
1007bc44c:     	str	x8, [sp, #0x90]
1007bc450:     	mov	w8, #0x1                ; =1
1007bc454:     	dup.2d	v0, x8
1007bc458:     	str	q0, [sp, #0xe0]
1007bc45c:     	str	x20, [sp, #0x128]
1007bc460:     	b	0x1007bc47c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xa9c>
1007bc464:     	ldr	x19, [sp, #0x158]
1007bc468:     	ldr	x20, [sp, #0x128]
1007bc46c:     	sub	x19, x19, #0x30
1007bc470:     	add	x28, x28, #0x30
1007bc474:     	cmp	x21, x20
1007bc478:     	b.eq	0x1007bc2c8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x8e8>
1007bc47c:     	mov	x23, x21
1007bc480:     	add	x21, x21, #0x30
1007bc484:     	str	x21, [sp, #0x5d8]
1007bc488:     	ldr	x22, [x23]
1007bc48c:     	ldur	q0, [x23, #0x8]
1007bc490:     	str	q0, [x27, #0x100]
1007bc494:     	ldur	q0, [x23, #0x18]
1007bc498:     	str	q0, [x27, #0x110]
1007bc49c:     	ldr	x8, [x23, #0x28]
1007bc4a0:     	str	x8, [sp, #0x320]
1007bc4a4:     	cmn	x22, #0x1
1007bc4a8:     	b.eq	0x1007bc2c8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x8e8>
1007bc4ac:     	str	x19, [sp, #0x158]
1007bc4b0:     	str	x22, [sp, #0x5f8]
1007bc4b4:     	ldr	q0, [x27, #0x100]
1007bc4b8:     	add	x8, sp, #0x5f8
1007bc4bc:     	stur	q0, [x8, #0x8]
1007bc4c0:     	ldur	q0, [x23, #0x18]
1007bc4c4:     	str	q0, [x25, #0x200]
1007bc4c8:     	ldr	x8, [x23, #0x28]
1007bc4cc:     	str	x8, [sp, #0x620]
1007bc4d0:     	ldr	x9, [sp, #0x168]
1007bc4d4:     	ldr	x8, [sp, #0x538]
1007bc4d8:     	ldp	x10, x20, [x9, #0xa8]
1007bc4dc:     	str	x10, [sp, #0x138]
1007bc4e0:     	str	x9, [sp, #0x118]
1007bc4e4:     	ldr	x9, [sp, #0x150]
1007bc4e8:     	cmp	x8, x9
1007bc4ec:     	b.lo	0x1007bc504 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xb24>
1007bc4f0:     	cmp	x8, x20
1007bc4f4:     	b.hi	0x1007bc504 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xb24>
1007bc4f8:     	ldr	x9, [sp, #0x150]
1007bc4fc:     	subs	x8, x8, x9
1007bc500:     	b.ne	0x1007bc5dc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xbfc>
1007bc504:     	ldr	x8, [sp, #0x130]
1007bc508:     	cmp	x8, x20
1007bc50c:     	b.hi	0x1007bc56c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xb8c>
1007bc510:     	ldr	x8, [sp, #0x108]
1007bc514:     	cbz	w8, 0x1007bc56c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xb8c>
1007bc518:     	mov	x24, #0x0               ; =0
1007bc51c:     	ldr	x19, [sp, #0x600]
1007bc520:     	ldr	x26, [sp, #0x608]
1007bc524:     	ldp	x8, x27, [sp, #0x90]
1007bc528:     	ldr	x9, [sp, #0x138]
1007bc52c:     	add	x25, x9, x8
1007bc530:     	b	0x1007bc544 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xb64>
1007bc534:     	sub	x24, x24, #0x1
1007bc538:     	add	x25, x25, #0x18
1007bc53c:     	subs	x27, x27, #0x18
1007bc540:     	b.eq	0x1007bc56c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xb8c>
1007bc544:     	ldr	x8, [x25]
1007bc548:     	cmp	x8, x26
1007bc54c:     	b.ne	0x1007bc534 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xb54>
1007bc550:     	ldur	x0, [x25, #-0x8]
1007bc554:     	mov	x1, x19
1007bc558:     	mov	x2, x26
1007bc55c:     	bl	0x1010102c4 <dyld_stub_binder+0x1010102c4>
1007bc560:     	cbnz	w0, 0x1007bc534 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xb54>
1007bc564:     	ldr	x8, [sp, #0xf8]
1007bc568:     	b	0x1007bc634 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xc54>
1007bc56c:     	ldr	w8, [sp, #0x124]
1007bc570:     	tbz	w8, #0x0, 0x1007bcb7c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x119c>
1007bc574:     	ldr	x27, [sp, #0x110]
1007bc578:     	cbz	x27, 0x1007bc5b8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xbd8>
1007bc57c:     	ldr	x8, [sp, #0x140]
1007bc580:     	ldr	x1, [x8]
1007bc584:     	add	x24, sp, #0x640
1007bc588:     	cbz	x1, 0x1007bc6bc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xcdc>
1007bc58c:     	ldr	x8, [x27, #0x18]
1007bc590:     	cmp	x8, x1
1007bc594:     	b.ne	0x1007bc6d8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xcf8>
1007bc598:     	ldr	w8, [x27, #0x20]
1007bc59c:     	add	w8, w8, #0x1
1007bc5a0:     	str	w8, [x27, #0x20]
1007bc5a4:     	ldr	x8, [x27, #0x10]
1007bc5a8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1007bc5ac:     	cmp	x8, x9
1007bc5b0:     	b.lo	0x1007bc704 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd24>
1007bc5b4:     	b	0x1007bc9d0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xff0>
1007bc5b8:     	ldr	x26, [sp, #0x600]
1007bc5bc:     	ldr	x19, [sp, #0x608]
1007bc5c0:     	add	x25, sp, #0x410
1007bc5c4:     	add	x24, sp, #0x640
1007bc5c8:     	mov	x8, #-0x18              ; =-24
1007bc5cc:     	movk	x8, #0x7fff, lsl #48
1007bc5d0:     	cmp	x19, x8
1007bc5d4:     	b.ls	0x1007bc874 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xe94>
1007bc5d8:     	b	0x1007becd4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x32f4>
1007bc5dc:     	mov	x24, #0x0               ; =0
1007bc5e0:     	ldr	x19, [sp, #0x600]
1007bc5e4:     	ldr	x26, [sp, #0x608]
1007bc5e8:     	add	x8, x8, x8, lsl #1
1007bc5ec:     	lsl	x27, x8, #3
1007bc5f0:     	ldr	x8, [sp, #0x80]
1007bc5f4:     	ldr	x9, [sp, #0x138]
1007bc5f8:     	add	x25, x9, x8
1007bc5fc:     	b	0x1007bc610 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xc30>
1007bc600:     	sub	x24, x24, #0x1
1007bc604:     	add	x25, x25, #0x18
1007bc608:     	subs	x27, x27, #0x18
1007bc60c:     	b.eq	0x1007bc504 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xb24>
1007bc610:     	ldr	x8, [x25]
1007bc614:     	cmp	x8, x26
1007bc618:     	b.ne	0x1007bc600 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xc20>
1007bc61c:     	ldur	x0, [x25, #-0x8]
1007bc620:     	mov	x1, x19
1007bc624:     	mov	x2, x26
1007bc628:     	bl	0x1010102c4 <dyld_stub_binder+0x1010102c4>
1007bc62c:     	cbnz	w0, 0x1007bc600 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xc20>
1007bc630:     	ldr	x8, [sp, #0x150]
1007bc634:     	sub	x19, x8, x24
1007bc638:     	ldr	x8, [sp, #0xd8]
1007bc63c:     	cmp	x19, x8
1007bc640:     	add	x25, sp, #0x410
1007bc644:     	add	x27, sp, #0x200
1007bc648:     	add	x24, sp, #0x640
1007bc64c:     	b.hs	0x1007becfc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x331c>
1007bc650:     	ldr	x8, [sp, #0x160]
1007bc654:     	ldrb	w8, [x8, x19]
1007bc658:     	tbnz	w8, #0x0, 0x1007bcc5c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x127c>
1007bc65c:     	ldur	q0, [x23, #0x18]
1007bc660:     	str	q0, [x25]
1007bc664:     	ldur	x8, [x23, #0x28]
1007bc668:     	str	x8, [sp, #0x420]
1007bc66c:     	ldr	x1, [sp, #0x550]
1007bc670:     	cmp	x19, x1
1007bc674:     	b.hs	0x1007bed14 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3334>
1007bc678:     	ldr	x8, [sp, #0x548]
1007bc67c:     	mov	w9, #0x18               ; =24
1007bc680:     	madd	x26, x19, x9, x8
1007bc684:     	mov	x0, x26
1007bc688:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bc68c:     	ldr	q0, [x25]
1007bc690:     	ldr	x8, [sp, #0x420]
1007bc694:     	str	x8, [x26, #0x10]
1007bc698:     	str	q0, [x26]
1007bc69c:     	ldr	x8, [sp, #0x160]
1007bc6a0:     	mov	w9, #0x1                ; =1
1007bc6a4:     	strb	w9, [x8, x19]
1007bc6a8:     	ldr	x8, [sp, #0x5f8]
1007bc6ac:     	cbz	x8, 0x1007bc464 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xa84>
1007bc6b0:     	ldr	x0, [sp, #0x600]
1007bc6b4:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bc6b8:     	b	0x1007bc464 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xa84>
1007bc6bc:     	bl	0x1010105d0 <dyld_stub_binder+0x1010105d0>
1007bc6c0:     	mov	x1, x0
1007bc6c4:     	ldr	x8, [sp, #0x140]
1007bc6c8:     	str	x0, [x8]
1007bc6cc:     	ldr	x8, [x27, #0x18]
1007bc6d0:     	cmp	x8, x0
1007bc6d4:     	b.eq	0x1007bc598 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xbb8>
1007bc6d8:     	mov	x8, #0x0                ; =0
1007bc6dc:     	add	x9, x27, #0x18
1007bc6e0:     	casa	x8, x1, [x9]
1007bc6e4:     	cmp	x8, #0x0
1007bc6e8:     	b.ne	0x1007bc9b8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xfd8>
1007bc6ec:     	mov	w8, #0x1                ; =1
1007bc6f0:     	str	w8, [x27, #0x20]
1007bc6f4:     	ldr	x8, [x27, #0x10]
1007bc6f8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1007bc6fc:     	cmp	x8, x9
1007bc700:     	b.hs	0x1007bc9d0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xff0>
1007bc704:     	add	x8, x8, #0x1
1007bc708:     	str	x8, [x27, #0x10]
1007bc70c:     	ldr	x9, [sp, #0x140]
1007bc710:     	ldr	x8, [x9, #0x8]
1007bc714:     	add	x8, x8, #0x1
1007bc718:     	str	x8, [x9, #0x8]
1007bc71c:     	ldr	x8, [x27, #0x38]
1007bc720:     	cbz	x8, 0x1007bc810 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xe30>
1007bc724:     	ldr	x19, [x27, #0x30]
1007bc728:     	lsl	x9, x8, #6
1007bc72c:     	sub	x22, x9, x8, lsl #3
1007bc730:     	mov	x25, x19
1007bc734:     	b	0x1007bc75c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd7c>
1007bc738:     	mov	w23, #0xff              ; =255
1007bc73c:     	cbz	x20, 0x1007bc748 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd68>
1007bc740:     	mov	x0, x26
1007bc744:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bc748:     	cmp	w23, #0xff
1007bc74c:     	b.ne	0x1007bc998 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xfb8>
1007bc750:     	mov	x19, x25
1007bc754:     	subs	x22, x22, #0x38
1007bc758:     	b.eq	0x1007bc810 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xe30>
1007bc75c:     	ldrb	w8, [x25], #0x38
1007bc760:     	sub	w9, w8, #0x7
1007bc764:     	cmp	w9, #0x2
1007bc768:     	b.hs	0x1007bc7e0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xe00>
1007bc76c:     	add	x8, sp, #0x410
1007bc770:     	mov	x0, x19
1007bc774:     	bl	0x10087d71c <__RNvMsR_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6Object6to_str>
1007bc778:     	ldr	x20, [sp, #0x410]
1007bc77c:     	ldr	x26, [sp, #0x418]
1007bc780:     	ldr	x2, [sp, #0x420]
1007bc784:     	cmn	x20, #0x1
1007bc788:     	b.eq	0x1007bc750 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd70>
1007bc78c:     	ldr	x8, [sp, #0x608]
1007bc790:     	cmp	x2, x8
1007bc794:     	b.ne	0x1007bc738 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd58>
1007bc798:     	ldr	x1, [sp, #0x600]
1007bc79c:     	mov	x0, x26
1007bc7a0:     	bl	0x1010102c4 <dyld_stub_binder+0x1010102c4>
1007bc7a4:     	cbnz	w0, 0x1007bc738 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd58>
1007bc7a8:     	add	x0, sp, #0x410
1007bc7ac:     	mov	x1, x19
1007bc7b0:     	bl	0x100cd53fc <__RNvXsW_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6ObjectNtNtCs8Mbv00yxnRz_4core5clone5Clone5clone>
1007bc7b4:     	ldrb	w23, [sp, #0x410]
1007bc7b8:     	ldr	x9, [sp, #0xd0]
1007bc7bc:     	ldr	w8, [x9]
1007bc7c0:     	stur	w8, [x29, #-0x80]
1007bc7c4:     	ldur	w8, [x9, #0x3]
1007bc7c8:     	stur	w8, [x24, #0x93]
1007bc7cc:     	ldr	x9, [sp, #0x418]
1007bc7d0:     	ldr	x8, [sp, #0x420]
1007bc7d4:     	stp	x8, x9, [sp, #0xc0]
1007bc7d8:     	cbnz	x20, 0x1007bc740 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd60>
1007bc7dc:     	b	0x1007bc748 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd68>
1007bc7e0:     	cmp	w8, #0x15
1007bc7e4:     	b.ne	0x1007bc750 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd70>
1007bc7e8:     	ldr	x0, [x19, #0x8]
1007bc7ec:     	ldapur	x8, [x0, #0x30]
1007bc7f0:     	cbnz	x8, 0x1007bc750 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd70>
1007bc7f4:     	ldrb	w8, [x0, #0x38]!
1007bc7f8:     	sub	w8, w8, #0x7
1007bc7fc:     	cmp	w8, #0x1
1007bc800:     	b.hi	0x1007bc750 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd70>
1007bc804:     	add	x8, sp, #0x410
1007bc808:     	bl	0x10087d71c <__RNvMsR_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6Object6to_str>
1007bc80c:     	b	0x1007bc778 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd98>
1007bc810:     	mov	w23, #0xff              ; =255
1007bc814:     	add	x25, sp, #0x410
1007bc818:     	ldr	x8, [x27, #0x10]
1007bc81c:     	sub	x8, x8, #0x1
1007bc820:     	str	x8, [x27, #0x10]
1007bc824:     	ldr	w8, [x27, #0x20]
1007bc828:     	subs	w8, w8, #0x1
1007bc82c:     	str	w8, [x27, #0x20]
1007bc830:     	b.ne	0x1007bc838 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xe58>
1007bc834:     	stlur	xzr, [x27, #0x18]
1007bc838:     	ldr	x10, [sp, #0x140]
1007bc83c:     	ldr	x8, [x10, #0x8]
1007bc840:     	cmp	x8, #0x0
1007bc844:     	cset	w9, ne
1007bc848:     	sub	x8, x8, x9
1007bc84c:     	str	x8, [x10, #0x8]
1007bc850:     	ldr	x22, [sp, #0x5f8]
1007bc854:     	ldr	x26, [sp, #0x600]
1007bc858:     	cmp	w23, #0xff
1007bc85c:     	b.ne	0x1007bc97c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xf9c>
1007bc860:     	ldr	x19, [sp, #0x608]
1007bc864:     	mov	x8, #-0x18              ; =-24
1007bc868:     	movk	x8, #0x7fff, lsl #48
1007bc86c:     	cmp	x19, x8
1007bc870:     	b.hi	0x1007becd4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x32f4>
1007bc874:     	add	x20, x19, #0x17
1007bc878:     	and	x0, x20, #0x7ffffffffffffff8
1007bc87c:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bc880:     	cbz	x0, 0x1007befa0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35c0>
1007bc884:     	mov	x27, x0
1007bc888:     	ldr	q0, [sp, #0xe0]
1007bc88c:     	str	q0, [x0], #0x10
1007bc890:     	mov	x1, x26
1007bc894:     	mov	x2, x19
1007bc898:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007bc89c:     	mov	w23, #0x7               ; =7
1007bc8a0:     	cbz	x22, 0x1007bc8ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xecc>
1007bc8a4:     	mov	x0, x26
1007bc8a8:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bc8ac:     	strb	w23, [sp, #0x648]
1007bc8b0:     	ldr	w8, [sp, #0x640]
1007bc8b4:     	ldr	x9, [sp, #0x100]
1007bc8b8:     	str	w8, [x9]
1007bc8bc:     	ldur	w8, [x24, #0x3]
1007bc8c0:     	stur	w8, [x9, #0x3]
1007bc8c4:     	str	x27, [sp, #0x650]
1007bc8c8:     	str	x19, [sp, #0x658]
1007bc8cc:     	ldr	q0, [x25, #0x200]
1007bc8d0:     	str	q0, [x24, #0x20]
1007bc8d4:     	ldr	x8, [sp, #0x620]
1007bc8d8:     	stur	x8, [x29, #-0xe0]
1007bc8dc:     	add	x0, sp, #0x648
1007bc8e0:     	bl	0x100912d9c <__RNvNtCshqYhlee0Vj9_10weavepy_vm6object13py_hash_value>
1007bc8e4:     	add	x27, sp, #0x200
1007bc8e8:     	ldr	x19, [sp, #0x158]
1007bc8ec:     	ldr	x20, [sp, #0x128]
1007bc8f0:     	cmp	x0, #0x1
1007bc8f4:     	b.eq	0x1007bc904 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xf24>
1007bc8f8:     	add	x0, sp, #0x648
1007bc8fc:     	bl	0x1009125d0 <__RNvNtCshqYhlee0Vj9_10weavepy_vm6object13identity_hash>
1007bc900:     	mov	x1, x0
1007bc904:     	mov	x8, #0xa95              ; =2709
1007bc908:     	movk	x8, #0x2722, lsl #16
1007bc90c:     	movk	x8, #0xc1b7, lsl #32
1007bc910:     	movk	x8, #0x517c, lsl #48
1007bc914:     	mul	x2, x1, x8
1007bc918:     	add	x8, sp, #0x549
1007bc91c:     	ldur	q0, [x8, #0xff]
1007bc920:     	str	q0, [x24, #0x70]
1007bc924:     	ldr	x8, [sp, #0x658]
1007bc928:     	stur	x8, [x29, #-0x90]
1007bc92c:     	ldr	q0, [x24, #0x20]
1007bc930:     	str	q0, [x24, #0x90]
1007bc934:     	ldur	x8, [x29, #-0xe0]
1007bc938:     	stur	x8, [x29, #-0x70]
1007bc93c:     	add	x0, sp, #0x410
1007bc940:     	add	x1, sp, #0x200
1007bc944:     	sub	x3, x29, #0xa0
1007bc948:     	sub	x4, x29, #0x80
1007bc94c:     	bl	0x100890184 <__RNvMs_NtCskjxBf4UiEDI_8indexmap5innerINtB4_4CoreNtNtCshqYhlee0Vj9_10weavepy_vm6object7DictKeyNtBM_6ObjectE11insert_fullBO_>
1007bc950:     	add	x8, sp, #0x410
1007bc954:     	ldur	q0, [x8, #0x8]
1007bc958:     	str	q0, [x24, #0x90]
1007bc95c:     	ldur	x8, [x8, #0x18]
1007bc960:     	stur	x8, [x29, #-0x70]
1007bc964:     	ldurb	w8, [x29, #-0x80]
1007bc968:     	cmp	w8, #0xff
1007bc96c:     	b.eq	0x1007bc46c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xa8c>
1007bc970:     	sub	x0, x29, #0x80
1007bc974:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bc978:     	b	0x1007bc46c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xa8c>
1007bc97c:     	ldr	w8, [sp, #0x410]
1007bc980:     	str	w8, [sp, #0x640]
1007bc984:     	ldur	w8, [x25, #0x3]
1007bc988:     	stur	w8, [x24, #0x3]
1007bc98c:     	ldp	x27, x19, [sp, #0x68]
1007bc990:     	cbnz	x22, 0x1007bc8a4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xec4>
1007bc994:     	b	0x1007bc8ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xecc>
1007bc998:     	ldur	w8, [x29, #-0x80]
1007bc99c:     	str	w8, [sp, #0x410]
1007bc9a0:     	ldur	w8, [x24, #0x93]
1007bc9a4:     	add	x25, sp, #0x410
1007bc9a8:     	stur	w8, [x25, #0x3]
1007bc9ac:     	ldp	x9, x8, [sp, #0xc0]
1007bc9b0:     	stp	x8, x9, [sp, #0x68]
1007bc9b4:     	b	0x1007bc818 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xe38>
1007bc9b8:     	add	x0, x27, #0x10
1007bc9bc:     	bl	0x100fdaa6c <__RNvMsf_NtCshqYhlee0Vj9_10weavepy_vm4syncINtB5_7GilCellNtNtB7_6object6ObjectE14lock_contendedB7_>
1007bc9c0:     	ldr	x8, [x27, #0x10]
1007bc9c4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1007bc9c8:     	cmp	x8, x9
1007bc9cc:     	b.lo	0x1007bc704 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xd24>
1007bc9d0:     	ldr	w8, [x27, #0x20]
1007bc9d4:     	subs	w8, w8, #0x1
1007bc9d8:     	str	w8, [x27, #0x20]
1007bc9dc:     	b.ne	0x1007bc9e8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1008>
1007bc9e0:     	ldr	x8, [sp, #0x110]
1007bc9e4:     	stlur	xzr, [x8, #0x18]
1007bc9e8:     	adrp	x0, 0x1011e0000 <_anon.62c35deff83376c58a4fa8d541d7c1d3.553+0x6342>
1007bc9ec:     	add	x0, x0, #0x975
1007bc9f0:     	adrp	x3, 0x102627000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3425+0x800>
1007bc9f4:     	add	x3, x3, #0xec8
1007bc9f8:     	adrp	x4, 0x102622000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.300+0x63a0>
1007bc9fc:     	add	x4, x4, #0x9f8
1007bca00:     	sub	x2, x29, #0x61
1007bca04:     	mov	w1, #0x29               ; =41
1007bca08:     	bl	0x100f8b518 <__RNvNtCs8Mbv00yxnRz_4core6result13unwrap_failed>
1007bca0c:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bca10:     	add	x9, sp, #0x300
1007bca14:     	ldr	x20, [sp, #0x78]
1007bca18:     	tbz	w28, #0x0, 0x1007bcae4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1104>
1007bca1c:     	ldr	x8, [sp, #0x230]
1007bca20:     	str	x8, [sp, #0x348]
1007bca24:     	ldp	q0, q1, [x27, #0x10]
1007bca28:     	stur	q1, [x9, #0x38]
1007bca2c:     	ldr	q1, [x27]
1007bca30:     	stur	q0, [x9, #0x28]
1007bca34:     	stur	q1, [x9, #0x18]
1007bca38:     	str	wzr, [sp, #0x310]
1007bca3c:     	str	xzr, [sp, #0x308]
1007bca40:     	str	xzr, [sp, #0x300]
1007bca44:     	mov	w8, #0x1                ; =1
1007bca48:     	ldp	q0, q1, [x9, #0x20]
1007bca4c:     	ldp	q3, q2, [x9]
1007bca50:     	stp	q2, q0, [x25, #0x20]
1007bca54:     	ldr	q0, [x9, #0x40]
1007bca58:     	stp	q1, q0, [x25, #0x40]
1007bca5c:     	dup.2d	v0, x8
1007bca60:     	stp	q0, q3, [x25]
1007bca64:     	mov	w0, #0x60               ; =96
1007bca68:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bca6c:     	cbz	x0, 0x1007be9d4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2ff4>
1007bca70:     	ldp	q0, q1, [x25, #0x20]
1007bca74:     	stp	q0, q1, [x0, #0x20]
1007bca78:     	ldp	q0, q1, [x25, #0x40]
1007bca7c:     	stp	q0, q1, [x0, #0x40]
1007bca80:     	ldp	q0, q1, [x25]
1007bca84:     	stp	q0, q1, [x0]
1007bca88:     	str	x0, [sp, #0x418]
1007bca8c:     	mov	w8, #0xb                ; =11
1007bca90:     	strb	w8, [sp, #0x410]
1007bca94:     	ldr	x1, [sp, #0x550]
1007bca98:     	ldr	x10, [sp]
1007bca9c:     	cmp	x10, x1
1007bcaa0:     	b.hs	0x1007bee6c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x348c>
1007bcaa4:     	ldr	x8, [sp, #0x548]
1007bcaa8:     	mov	w9, #0x18               ; =24
1007bcaac:     	madd	x19, x10, x9, x8
1007bcab0:     	mov	x0, x19
1007bcab4:     	mov	x21, x10
1007bcab8:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bcabc:     	ldr	q0, [x25]
1007bcac0:     	ldr	x8, [sp, #0x420]
1007bcac4:     	str	x8, [x19, #0x10]
1007bcac8:     	str	q0, [x19]
1007bcacc:     	cmp	x21, x23
1007bcad0:     	mov	x0, x21
1007bcad4:     	b.hs	0x1007bee80 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x34a0>
1007bcad8:     	mov	w8, #0x1                ; =1
1007bcadc:     	ldr	x9, [sp, #0x160]
1007bcae0:     	strb	w8, [x9, x0]
1007bcae4:     	eor	w8, w28, #0x1
1007bcae8:     	str	w8, [sp, #0x158]
1007bcaec:     	ldr	x8, [sp, #0x538]
1007bcaf0:     	cbz	x8, 0x1007bd1cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x17ec>
1007bcaf4:     	sub	x8, x8, #0x1
1007bcaf8:     	mov	x9, x23
1007bcafc:     	ldr	x10, [sp, #0x160]
1007bcb00:     	cbz	x9, 0x1007bd1cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x17ec>
1007bcb04:     	ldrb	w11, [x10], #0x1
1007bcb08:     	eor	w12, w11, #0x1
1007bcb0c:     	cmp	x8, #0x0
1007bcb10:     	csinc	w11, w12, w11, eq
1007bcb14:     	sub	x8, x8, #0x1
1007bcb18:     	sub	x9, x9, #0x1
1007bcb1c:     	and	w11, w11, #0x3
1007bcb20:     	cmp	w11, #0x2
1007bcb24:     	b.eq	0x1007bcb00 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1120>
1007bcb28:     	cbz	w11, 0x1007bd1cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x17ec>
1007bcb2c:     	adrp	x1, 0x10120c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.1703+0x7d1b>
1007bcb30:     	add	x1, x1, #0xccf
1007bcb34:     	add	x8, sp, #0x5d0
1007bcb38:     	add	x0, x20, #0x10
1007bcb3c:     	mov	w2, #0xc                ; =12
1007bcb40:     	bl	0x1008b3fa4 <__RNvMsw_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_10PyFunction4slot>
1007bcb44:     	ldrb	w8, [sp, #0x5d0]
1007bcb48:     	cmp	w8, #0x9
1007bcb4c:     	b.eq	0x1007bcfa4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x15c4>
1007bcb50:     	add	x21, sp, #0x410
1007bcb54:     	cbnz	w8, 0x1007bd01c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x163c>
1007bcb58:     	mov	w24, #0x0               ; =0
1007bcb5c:     	mov	x23, #0x0               ; =0
1007bcb60:     	mov	w20, #0x8               ; =8
1007bcb64:     	str	xzr, [sp, #0x300]
1007bcb68:     	str	x20, [sp, #0x308]
1007bcb6c:     	str	xzr, [sp, #0x310]
1007bcb70:     	mov	w8, #0x1                ; =1
1007bcb74:     	str	w8, [sp, #0x140]
1007bcb78:     	b	0x1007bd0ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x16cc>
1007bcb7c:     	add	x25, sp, #0x410
1007bcb80:     	add	x27, sp, #0x200
1007bcb84:     	ldr	x8, [sp, #0x150]
1007bcb88:     	cbz	w8, 0x1007bccb0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x12d0>
1007bcb8c:     	cbz	x20, 0x1007bccb0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x12d0>
1007bcb90:     	add	x8, x20, x20, lsl #1
1007bcb94:     	lsl	x8, x8, #3
1007bcb98:     	ldr	x19, [sp, #0x600]
1007bcb9c:     	ldr	x20, [sp, #0x608]
1007bcba0:     	ldr	x9, [sp, #0x138]
1007bcba4:     	add	x23, x9, #0x10
1007bcba8:     	sub	x21, x8, #0x18
1007bcbac:     	ldr	x8, [sp, #0x150]
1007bcbb0:     	sub	x22, x8, #0x1
1007bcbb4:     	str	x22, [sp, #0x160]
1007bcbb8:     	mov	x24, x21
1007bcbbc:     	ldr	x8, [x23]
1007bcbc0:     	cmp	x8, x20
1007bcbc4:     	b.eq	0x1007bcbd0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x11f0>
1007bcbc8:     	cbnz	x22, 0x1007bcbe8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1208>
1007bcbcc:     	b	0x1007bccb0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x12d0>
1007bcbd0:     	ldur	x0, [x23, #-0x8]
1007bcbd4:     	mov	x1, x19
1007bcbd8:     	mov	x2, x20
1007bcbdc:     	bl	0x1010102c4 <dyld_stub_binder+0x1010102c4>
1007bcbe0:     	cbz	x22, 0x1007bcca8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x12c8>
1007bcbe4:     	cbz	w0, 0x1007bcca8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x12c8>
1007bcbe8:     	cbz	x24, 0x1007bccb0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x12d0>
1007bcbec:     	sub	x24, x24, #0x18
1007bcbf0:     	sub	x22, x22, #0x1
1007bcbf4:     	ldr	x8, [x23, #0x18]!
1007bcbf8:     	cmp	x8, x20
1007bcbfc:     	b.ne	0x1007bcbc8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x11e8>
1007bcc00:     	b	0x1007bcbd0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x11f0>
1007bcc04:     	mov	x21, x28
1007bcc08:     	b	0x1007bba80 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0xa0>
1007bcc0c:     	ldr	x10, [sp, #0x208]
1007bcc10:     	mov	w11, #0x18              ; =24
1007bcc14:     	madd	x0, x9, x11, x10
1007bcc18:     	str	x9, [sp, #0x210]
1007bcc1c:     	sub	x8, x8, x9
1007bcc20:     	add	x20, x8, #0x1
1007bcc24:     	subs	x20, x20, #0x1
1007bcc28:     	b.eq	0x1007bcc3c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x125c>
1007bcc2c:     	add	x19, x0, #0x18
1007bcc30:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bcc34:     	mov	x0, x19
1007bcc38:     	b	0x1007bcc24 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1244>
1007bcc3c:     	add	x0, sp, #0x300
1007bcc40:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bcc44:     	ldr	q0, [x27]
1007bcc48:     	str	q0, [sp, #0x170]
1007bcc4c:     	ldr	x8, [sp, #0x210]
1007bcc50:     	str	x8, [sp, #0x180]
1007bcc54:     	mov	w28, #0x1               ; =1
1007bcc58:     	b	0x1007bdcdc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x22fc>
1007bcc5c:     	adrp	x8, 0x100ce6000 <__RNvXsq_NtCshxvaOLs88l5_5alloc3vecINtB5_3VechENtNtCs8Mbv00yxnRz_4core3fmt5Debug3fmtCshqYhlee0Vj9_10weavepy_vm+0x84>
1007bcc60:     	add	x8, x8, #0x17c
1007bcc64:     	ldr	x9, [sp, #0x118]
1007bcc68:     	add	x9, x9, #0x28
1007bcc6c:     	str	x9, [sp, #0x410]
1007bcc70:     	str	x8, [sp, #0x418]
1007bcc74:     	add	x9, sp, #0x5f8
1007bcc78:     	str	x9, [sp, #0x420]
1007bcc7c:     	str	x8, [sp, #0x428]
1007bcc80:     	adrp	x0, 0x10102f000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3362+0x248f>
1007bcc84:     	add	x0, x0, #0xb23
1007bcc88:     	add	x8, sp, #0x628
1007bcc8c:     	add	x1, sp, #0x410
1007bcc90:     	ldr	x23, [sp, #0xd8]
1007bcc94:     	bl	0x100006330 <__RNvNvNtCshxvaOLs88l5_5alloc3fmt6format12format_inner>
1007bcc98:     	add	x0, sp, #0x410
1007bcc9c:     	add	x1, sp, #0x628
1007bcca0:     	bl	0x100616cac <__RINvNtCshqYhlee0Vj9_10weavepy_vm5error10type_errorNtNtCshxvaOLs88l5_5alloc6string6StringEB4_>
1007bcca4:     	b	0x1007bccf8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1318>
1007bcca8:     	cbnz	x22, 0x1007bcdac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x13cc>
1007bccac:     	cbz	w0, 0x1007bcdac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x13cc>
1007bccb0:     	adrp	x8, 0x100ce6000 <__RNvXsq_NtCshxvaOLs88l5_5alloc3vecINtB5_3VechENtNtCs8Mbv00yxnRz_4core3fmt5Debug3fmtCshqYhlee0Vj9_10weavepy_vm+0x84>
1007bccb4:     	add	x8, x8, #0x17c
1007bccb8:     	ldr	x9, [sp, #0x118]
1007bccbc:     	add	x9, x9, #0x28
1007bccc0:     	str	x9, [sp, #0x410]
1007bccc4:     	str	x8, [sp, #0x418]
1007bccc8:     	add	x9, sp, #0x5f8
1007bcccc:     	str	x9, [sp, #0x420]
1007bccd0:     	str	x8, [sp, #0x428]
1007bccd4:     	adrp	x0, 0x10102e000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3362+0x148f>
1007bccd8:     	add	x0, x0, #0xbe9
1007bccdc:     	sub	x8, x29, #0xb8
1007bcce0:     	add	x1, sp, #0x410
1007bcce4:     	ldr	x23, [sp, #0xd8]
1007bcce8:     	bl	0x100006330 <__RNvNvNtCshxvaOLs88l5_5alloc3fmt6format12format_inner>
1007bccec:     	add	x0, sp, #0x410
1007bccf0:     	sub	x1, x29, #0xb8
1007bccf4:     	bl	0x100616cac <__RINvNtCshqYhlee0Vj9_10weavepy_vm5error10type_errorNtNtCshxvaOLs88l5_5alloc6string6StringEB4_>
1007bccf8:     	ldur	q0, [x25, #0x8]
1007bccfc:     	str	q0, [sp, #0x1e0]
1007bcd00:     	ldr	x21, [sp, #0x410]
1007bcd04:     	ldr	x8, [sp, #0x428]
1007bcd08:     	str	x8, [sp, #0x1f0]
1007bcd0c:     	ldp	q0, q1, [x25, #0x20]
1007bcd10:     	stp	q0, q1, [sp, #0x1b0]
1007bcd14:     	ldr	x8, [sp, #0x450]
1007bcd18:     	str	x8, [sp, #0x1d0]
1007bcd1c:     	ldr	x22, [sp, #0x88]
1007bcd20:     	ldr	x19, [sp, #0x158]
1007bcd24:     	add	x0, sp, #0x610
1007bcd28:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bcd2c:     	ldr	x8, [sp, #0x5f8]
1007bcd30:     	cbz	x8, 0x1007bcd3c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x135c>
1007bcd34:     	ldr	x0, [sp, #0x600]
1007bcd38:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bcd3c:     	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
1007bcd40:     	movk	x8, #0xaaab
1007bcd44:     	umulh	x8, x19, x8
1007bcd48:     	lsr	x8, x8, #5
1007bcd4c:     	add	x19, x8, #0x1
1007bcd50:     	b	0x1007bcd60 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1380>
1007bcd54:     	add	x28, x28, #0x30
1007bcd58:     	add	x0, x20, #0x48
1007bcd5c:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bcd60:     	subs	x19, x19, #0x1
1007bcd64:     	b.eq	0x1007bcd80 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x13a0>
1007bcd68:     	add	x20, x22, x28
1007bcd6c:     	ldr	x8, [x20, #0x30]
1007bcd70:     	cbz	x8, 0x1007bcd54 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1374>
1007bcd74:     	ldr	x0, [x20, #0x38]
1007bcd78:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bcd7c:     	b	0x1007bcd54 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1374>
1007bcd80:     	ldr	x8, [sp, #0x40]
1007bcd84:     	cbz	x8, 0x1007bcd90 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x13b0>
1007bcd88:     	mov	x0, x22
1007bcd8c:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bcd90:     	mov	w8, #0x1                ; =1
1007bcd94:     	str	w8, [sp, #0x158]
1007bcd98:     	mov	w24, #0x1               ; =1
1007bcd9c:     	ldr	x19, [sp, #0x5b8]
1007bcda0:     	ldr	x20, [sp, #0x5c0]
1007bcda4:     	cbnz	x20, 0x1007bdb74 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2194>
1007bcda8:     	b	0x1007bdb9c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x21bc>
1007bcdac:     	ldr	x8, [sp, #0x5c0]
1007bcdb0:     	cbz	x8, 0x1007bd058 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1678>
1007bcdb4:     	ldr	x20, [sp, #0x5b8]
1007bcdb8:     	mov	w9, #0x18               ; =24
1007bcdbc:     	madd	x8, x8, x9, x20
1007bcdc0:     	str	x8, [sp, #0x150]
1007bcdc4:     	ldr	x8, [sp, #0x138]
1007bcdc8:     	add	x8, x8, #0x10
1007bcdcc:     	str	x8, [sp, #0x140]
1007bcdd0:     	b	0x1007bcde0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1400>
1007bcdd4:     	ldr	x8, [sp, #0x150]
1007bcdd8:     	cmp	x20, x8
1007bcddc:     	b.eq	0x1007bd038 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1658>
1007bcde0:     	mov	x23, x20
1007bcde4:     	add	x20, x20, #0x18
1007bcde8:     	ldr	x19, [x23, #0x10]
1007bcdec:     	ldr	x22, [sp, #0x160]
1007bcdf0:     	mov	x24, x21
1007bcdf4:     	ldr	x25, [sp, #0x140]
1007bcdf8:     	ldr	x8, [x25]
1007bcdfc:     	cmp	x8, x19
1007bce00:     	b.eq	0x1007bce0c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x142c>
1007bce04:     	cbnz	x22, 0x1007bce28 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1448>
1007bce08:     	b	0x1007bcdd4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x13f4>
1007bce0c:     	ldur	x0, [x25, #-0x8]
1007bce10:     	ldr	x26, [x23, #0x8]
1007bce14:     	mov	x1, x26
1007bce18:     	mov	x2, x19
1007bce1c:     	bl	0x1010102c4 <dyld_stub_binder+0x1010102c4>
1007bce20:     	cbz	x22, 0x1007bce44 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1464>
1007bce24:     	cbz	w0, 0x1007bce44 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1464>
1007bce28:     	cbz	x24, 0x1007bcdd4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x13f4>
1007bce2c:     	sub	x24, x24, #0x18
1007bce30:     	sub	x22, x22, #0x1
1007bce34:     	ldr	x8, [x25, #0x18]!
1007bce38:     	cmp	x8, x19
1007bce3c:     	b.ne	0x1007bce04 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1424>
1007bce40:     	b	0x1007bce0c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x142c>
1007bce44:     	cbnz	x22, 0x1007bce4c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x146c>
1007bce48:     	cbnz	w0, 0x1007bcdd4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x13f4>
1007bce4c:     	mov	w0, #0x40               ; =64
1007bce50:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bce54:     	cbz	x0, 0x1007bef90 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35b0>
1007bce58:     	stp	x26, x19, [x0]
1007bce5c:     	mov	w8, #0x4                ; =4
1007bce60:     	str	x8, [sp, #0x410]
1007bce64:     	str	x0, [sp, #0x418]
1007bce68:     	mov	w2, #0x1                ; =1
1007bce6c:     	str	x2, [sp, #0x420]
1007bce70:     	ldr	x8, [sp, #0x150]
1007bce74:     	cmp	x20, x8
1007bce78:     	ldr	x23, [sp, #0xd8]
1007bce7c:     	add	x25, sp, #0x410
1007bce80:     	add	x21, sp, #0x640
1007bce84:     	ldr	x22, [sp, #0x88]
1007bce88:     	b.eq	0x1007be8bc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2edc>
1007bce8c:     	mov	w2, #0x1                ; =1
1007bce90:     	str	x0, [sp, #0x130]
1007bce94:     	ldr	x9, [sp, #0x168]
1007bce98:     	ldr	x8, [x9, #0xb0]
1007bce9c:     	str	x9, [sp, #0x118]
1007bcea0:     	cbz	x8, 0x1007be8bc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2edc>
1007bcea4:     	ldr	x9, [x9, #0xa8]
1007bcea8:     	add	x8, x8, x8, lsl #1
1007bceac:     	lsl	x8, x8, #3
1007bceb0:     	add	x9, x9, #0x10
1007bceb4:     	stp	x2, x9, [sp, #0x138]
1007bceb8:     	sub	x21, x8, #0x18
1007bcebc:     	b	0x1007bcecc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x14ec>
1007bcec0:     	ldr	x8, [sp, #0x150]
1007bcec4:     	cmp	x20, x8
1007bcec8:     	b.eq	0x1007be8a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2ec8>
1007bcecc:     	mov	x23, x20
1007bced0:     	add	x20, x20, #0x18
1007bced4:     	ldr	x19, [x23, #0x10]
1007bced8:     	ldr	x22, [sp, #0x160]
1007bcedc:     	mov	x24, x21
1007bcee0:     	ldr	x25, [sp, #0x140]
1007bcee4:     	ldr	x8, [x25]
1007bcee8:     	cmp	x8, x19
1007bceec:     	b.eq	0x1007bcef8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1518>
1007bcef0:     	cbnz	x22, 0x1007bcf14 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1534>
1007bcef4:     	b	0x1007bcec0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x14e0>
1007bcef8:     	ldur	x0, [x25, #-0x8]
1007bcefc:     	ldr	x26, [x23, #0x8]
1007bcf00:     	mov	x1, x26
1007bcf04:     	mov	x2, x19
1007bcf08:     	bl	0x1010102c4 <dyld_stub_binder+0x1010102c4>
1007bcf0c:     	cbz	x22, 0x1007bcf30 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1550>
1007bcf10:     	cbz	w0, 0x1007bcf30 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1550>
1007bcf14:     	cbz	x24, 0x1007bcec0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x14e0>
1007bcf18:     	sub	x24, x24, #0x18
1007bcf1c:     	sub	x22, x22, #0x1
1007bcf20:     	ldr	x8, [x25, #0x18]!
1007bcf24:     	cmp	x8, x19
1007bcf28:     	b.ne	0x1007bcef0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1510>
1007bcf2c:     	b	0x1007bcef8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1518>
1007bcf30:     	cbnz	x22, 0x1007bcf38 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1558>
1007bcf34:     	cbnz	w0, 0x1007bcec0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x14e0>
1007bcf38:     	ldr	x8, [sp, #0x410]
1007bcf3c:     	ldp	x0, x2, [sp, #0x130]
1007bcf40:     	cmp	x2, x8
1007bcf44:     	ldr	x23, [sp, #0xd8]
1007bcf48:     	add	x25, sp, #0x410
1007bcf4c:     	add	x21, sp, #0x640
1007bcf50:     	ldr	x22, [sp, #0x88]
1007bcf54:     	b.ne	0x1007bcf7c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x159c>
1007bcf58:     	add	x0, sp, #0x410
1007bcf5c:     	mov	x24, x2
1007bcf60:     	mov	x1, x2
1007bcf64:     	mov	w2, #0x1                ; =1
1007bcf68:     	mov	w3, #0x8                ; =8
1007bcf6c:     	mov	w4, #0x10               ; =16
1007bcf70:     	bl	0x100fd8830 <__RINvNvMs2_NtCshxvaOLs88l5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshqYhlee0Vj9_10weavepy_vm>
1007bcf74:     	ldr	x0, [sp, #0x418]
1007bcf78:     	mov	x2, x24
1007bcf7c:     	add	x8, x0, x2, lsl #4
1007bcf80:     	stp	x26, x19, [x8]
1007bcf84:     	add	x2, x2, #0x1
1007bcf88:     	str	x2, [sp, #0x420]
1007bcf8c:     	ldr	x8, [sp, #0x150]
1007bcf90:     	cmp	x20, x8
1007bcf94:     	b.ne	0x1007bce90 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x14b0>
1007bcf98:     	ldr	x8, [sp, #0x168]
1007bcf9c:     	str	x8, [sp, #0x118]
1007bcfa0:     	b	0x1007be8bc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2edc>
1007bcfa4:     	ldr	x22, [sp, #0x5d8]
1007bcfa8:     	ldr	x23, [sp, #0x5e0]
1007bcfac:     	stp	x22, x23, [x29, #-0x80]
1007bcfb0:     	cmp	x23, #0x0
1007bcfb4:     	cset	w26, eq
1007bcfb8:     	cbz	x23, 0x1007bd074 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1694>
1007bcfbc:     	add	x8, x23, x23, lsl #1
1007bcfc0:     	lsl	x19, x8, #3
1007bcfc4:     	mov	x0, x19
1007bcfc8:     	mov	w1, #0x8                ; =8
1007bcfcc:     	bl	0x100000b00 <__RNvCs1njKG4L9aB3_7___rustc12___rust_alloc>
1007bcfd0:     	cbz	x0, 0x1007bef34 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3554>
1007bcfd4:     	mov	x20, x0
1007bcfd8:     	add	x19, x22, #0x18
1007bcfdc:     	mov	x24, x0
1007bcfe0:     	mov	x25, x23
1007bcfe4:     	add	x21, sp, #0x410
1007bcfe8:     	add	x0, sp, #0x410
1007bcfec:     	mov	x1, x19
1007bcff0:     	bl	0x100cd53fc <__RNvXsW_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6ObjectNtNtCs8Mbv00yxnRz_4core5clone5Clone5clone>
1007bcff4:     	ldr	q0, [x21]
1007bcff8:     	str	q0, [x24]
1007bcffc:     	ldr	x8, [sp, #0x420]
1007bd000:     	str	x8, [x24, #0x10]
1007bd004:     	add	x24, x24, #0x18
1007bd008:     	add	x19, x19, #0x18
1007bd00c:     	subs	x25, x25, #0x1
1007bd010:     	b.ne	0x1007bcfe8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1608>
1007bd014:     	add	x21, sp, #0x410
1007bd018:     	b	0x1007bd07c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x169c>
1007bd01c:     	str	wzr, [sp, #0x140]
1007bd020:     	mov	x8, #-0x1               ; =-1
1007bd024:     	str	x8, [sp, #0x300]
1007bd028:     	ldr	x8, [sp, #0x78]
1007bd02c:     	ldp	x20, x23, [x8, #0x30]
1007bd030:     	mov	w24, #0x1               ; =1
1007bd034:     	b	0x1007bd0ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x16cc>
1007bd038:     	mov	x2, #0x0                ; =0
1007bd03c:     	mov	w19, #0x1               ; =1
1007bd040:     	ldr	x23, [sp, #0xd8]
1007bd044:     	add	x25, sp, #0x410
1007bd048:     	add	x21, sp, #0x640
1007bd04c:     	ldr	x22, [sp, #0x88]
1007bd050:     	mov	w20, #0x8               ; =8
1007bd054:     	b	0x1007be8cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2eec>
1007bd058:     	mov	x2, #0x0                ; =0
1007bd05c:     	mov	w19, #0x1               ; =1
1007bd060:     	mov	w20, #0x8               ; =8
1007bd064:     	ldr	x23, [sp, #0xd8]
1007bd068:     	add	x21, sp, #0x640
1007bd06c:     	ldr	x22, [sp, #0x88]
1007bd070:     	b	0x1007be8cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2eec>
1007bd074:     	add	x21, sp, #0x410
1007bd078:     	mov	w20, #0x8               ; =8
1007bd07c:     	str	x23, [sp, #0x300]
1007bd080:     	str	x20, [sp, #0x308]
1007bd084:     	str	x23, [sp, #0x310]
1007bd088:     	mov	x8, #-0x1               ; =-1
1007bd08c:     	ldaddl	x8, x8, [x22]
1007bd090:     	cmp	x8, #0x1
1007bd094:     	b.ne	0x1007bd0a4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x16c4>
1007bd098:     	dmb	ishld
1007bd09c:     	sub	x0, x29, #0x80
1007bd0a0:     	bl	0x1008b1b7c <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcNtNtCshqYhlee0Vj9_10weavepy_vm13tuple_storage12TupleStorageE9drop_slowBK_>
1007bd0a4:     	str	w26, [sp, #0x140]
1007bd0a8:     	mov	w24, #0x0               ; =0
1007bd0ac:     	ldr	x8, [sp, #0x538]
1007bd0b0:     	subs	x9, x23, x8
1007bd0b4:     	csel	x9, xzr, x9, lo
1007bd0b8:     	cmp	x9, x23
1007bd0bc:     	b.ne	0x1007bd0f0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1710>
1007bd0c0:     	add	x25, sp, #0x410
1007bd0c4:     	ldr	x28, [sp, #0x38]
1007bd0c8:     	ldr	x26, [sp, #0x130]
1007bd0cc:     	tbnz	w24, #0x0, 0x1007bd1a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x17c8>
1007bd0d0:     	add	x22, x23, #0x1
1007bd0d4:     	mov	x0, x20
1007bd0d8:     	subs	x22, x22, #0x1
1007bd0dc:     	b.eq	0x1007bd198 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x17b8>
1007bd0e0:     	add	x19, x0, #0x18
1007bd0e4:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bd0e8:     	mov	x0, x19
1007bd0ec:     	b	0x1007bd0d8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x16f8>
1007bd0f0:     	mov	w10, #0x18              ; =24
1007bd0f4:     	madd	x26, x9, x10, x20
1007bd0f8:     	ldr	x19, [sp, #0x550]
1007bd0fc:     	ldr	x9, [sp, #0x548]
1007bd100:     	cmp	x23, x8
1007bd104:     	csel	x11, x23, x8, lo
1007bd108:     	sub	x22, x8, x11
1007bd10c:     	mul	x8, x8, x10
1007bd110:     	add	x10, x11, x11, lsl #1
1007bd114:     	lsl	x25, x10, #3
1007bd118:     	sub	x8, x8, x25
1007bd11c:     	add	x27, x9, x8
1007bd120:     	mov	w28, #0x1               ; =1
1007bd124:     	b	0x1007bd154 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1774>
1007bd128:     	ldr	q0, [x21]
1007bd12c:     	ldr	x8, [sp, #0x420]
1007bd130:     	str	x8, [x27, #0x10]
1007bd134:     	str	q0, [x27]
1007bd138:     	ldr	x8, [sp, #0x160]
1007bd13c:     	strb	w28, [x8, x22]
1007bd140:     	add	x26, x26, #0x18
1007bd144:     	add	x22, x22, #0x1
1007bd148:     	add	x27, x27, #0x18
1007bd14c:     	subs	x25, x25, #0x18
1007bd150:     	b.eq	0x1007bd0c0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x16e0>
1007bd154:     	ldr	x8, [sp, #0x538]
1007bd158:     	cmp	x22, x8
1007bd15c:     	b.hs	0x1007bd140 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1760>
1007bd160:     	ldr	x8, [sp, #0xd8]
1007bd164:     	cmp	x22, x8
1007bd168:     	b.hs	0x1007bedfc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x341c>
1007bd16c:     	ldr	x8, [sp, #0x160]
1007bd170:     	ldrb	w8, [x8, x22]
1007bd174:     	tbnz	w8, #0x0, 0x1007bd140 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1760>
1007bd178:     	add	x0, sp, #0x410
1007bd17c:     	mov	x1, x26
1007bd180:     	bl	0x100cd53fc <__RNvXsW_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6ObjectNtNtCs8Mbv00yxnRz_4core5clone5Clone5clone>
1007bd184:     	cmp	x22, x19
1007bd188:     	b.hs	0x1007bee2c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x344c>
1007bd18c:     	mov	x0, x27
1007bd190:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bd194:     	b	0x1007bd128 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1748>
1007bd198:     	ldr	w8, [sp, #0x140]
1007bd19c:     	tbnz	w8, #0x0, 0x1007bd1a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x17c8>
1007bd1a0:     	mov	x0, x20
1007bd1a4:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bd1a8:     	ldrb	w8, [sp, #0x5d0]
1007bd1ac:     	cmp	w8, #0xff
1007bd1b0:     	ccmp	w8, #0x9, #0x4, ne
1007bd1b4:     	ldr	x23, [sp, #0xd8]
1007bd1b8:     	add	x24, sp, #0x640
1007bd1bc:     	b.eq	0x1007bd1c8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x17e8>
1007bd1c0:     	add	x0, sp, #0x5d0
1007bd1c4:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bd1c8:     	ldr	x20, [sp, #0x78]
1007bd1cc:     	ldr	x8, [sp, #0x108]
1007bd1d0:     	cbz	w8, 0x1007bd5ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1bcc>
1007bd1d4:     	adrp	x1, 0x10120c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.1703+0x7d1b>
1007bd1d8:     	add	x1, x1, #0xcdb
1007bd1dc:     	sub	x8, x29, #0x80
1007bd1e0:     	add	x0, x20, #0x10
1007bd1e4:     	mov	w2, #0xe                ; =14
1007bd1e8:     	bl	0x1008b3fa4 <__RNvMsw_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_10PyFunction4slot>
1007bd1ec:     	ldurb	w8, [x29, #-0x80]
1007bd1f0:     	cbz	w8, 0x1007bd360 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1980>
1007bd1f4:     	cmp	w8, #0xb
1007bd1f8:     	b.ne	0x1007bd37c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x199c>
1007bd1fc:     	ldur	x19, [x29, #-0x78]
1007bd200:     	str	x19, [sp, #0x648]
1007bd204:     	adrp	x0, 0x102676000 <_BZ2_rNums+0x2d8>
1007bd208:     	add	x0, x0, #0xba8
1007bd20c:     	ldr	x8, [x0]
1007bd210:     	blr	x8
1007bd214:     	mov	x22, x0
1007bd218:     	ldr	x1, [x0]
1007bd21c:     	cbz	x1, 0x1007beb04 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3124>
1007bd220:     	ldr	x8, [x19, #0x18]
1007bd224:     	cmp	x8, x1
1007bd228:     	b.ne	0x1007beb1c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x313c>
1007bd22c:     	ldr	w8, [x19, #0x20]
1007bd230:     	add	w8, w8, #0x1
1007bd234:     	str	w8, [x19, #0x20]
1007bd238:     	ldr	x8, [x19, #0x10]
1007bd23c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1007bd240:     	cmp	x8, x9
1007bd244:     	b.hs	0x1007beb48 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3168>
1007bd248:     	add	x8, x8, #0x1
1007bd24c:     	str	x8, [x19, #0x10]
1007bd250:     	ldr	x8, [x22, #0x8]
1007bd254:     	add	x8, x8, #0x1
1007bd258:     	str	x8, [x22, #0x8]
1007bd25c:     	ldp	x8, x9, [x19, #0x30]
1007bd260:     	mov	w10, #0x38              ; =56
1007bd264:     	madd	x9, x9, x10, x8
1007bd268:     	stp	x8, x9, [x29, #-0xf0]
1007bd26c:     	add	x0, sp, #0x300
1007bd270:     	sub	x1, x29, #0xf0
1007bd274:     	bl	0x10064f770 <__RINvYINtNtNtCskjxBf4UiEDI_8indexmap3map4iter4IterNtNtCshqYhlee0Vj9_10weavepy_vm6object7DictKeyNtBN_6ObjectENtNtNtNtCs8Mbv00yxnRz_4core4iter6traits8iterator8Iterator8find_mapTNtNtCshxvaOLs88l5_5alloc6string6StringB1u_EQNCNvMs2_BP_NtBP_11Interpreter16bind_python_argss7_0EBP_>
1007bd278:     	ldr	x8, [sp, #0x300]
1007bd27c:     	cmn	x8, #0x1
1007bd280:     	b.eq	0x1007bd394 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x19b4>
1007bd284:     	add	x21, sp, #0x300
1007bd288:     	ldp	q0, q1, [x21]
1007bd28c:     	stp	q0, q1, [x25]
1007bd290:     	ldr	q0, [x21, #0x20]
1007bd294:     	str	q0, [x25, #0x20]
1007bd298:     	ldr	q0, [x24, #0x20]
1007bd29c:     	str	q0, [sp, #0x140]
1007bd2a0:     	mov	w0, #0xc0               ; =192
1007bd2a4:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bd2a8:     	cbz	x0, 0x1007beed8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x34f8>
1007bd2ac:     	mov	x20, x0
1007bd2b0:     	ldp	q0, q1, [x21]
1007bd2b4:     	stp	q0, q1, [x0]
1007bd2b8:     	ldr	q0, [x21, #0x20]
1007bd2bc:     	str	q0, [x0, #0x20]
1007bd2c0:     	mov	w8, #0x4                ; =4
1007bd2c4:     	str	x8, [sp, #0x5d0]
1007bd2c8:     	str	x0, [sp, #0x5d8]
1007bd2cc:     	mov	w27, #0x1               ; =1
1007bd2d0:     	str	x27, [sp, #0x5e0]
1007bd2d4:     	ldr	q0, [sp, #0x140]
1007bd2d8:     	str	q0, [x24, #0x70]
1007bd2dc:     	mov	w21, #0x30              ; =48
1007bd2e0:     	b	0x1007bd30c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x192c>
1007bd2e4:     	ldr	x20, [sp, #0x5d8]
1007bd2e8:     	add	x8, x20, x21
1007bd2ec:     	add	x9, sp, #0x300
1007bd2f0:     	ldp	q0, q1, [x9]
1007bd2f4:     	ldr	q2, [x9, #0x20]
1007bd2f8:     	stp	q1, q2, [x8, #0x10]
1007bd2fc:     	str	q0, [x8]
1007bd300:     	add	x27, x27, #0x1
1007bd304:     	str	x27, [sp, #0x5e0]
1007bd308:     	add	x21, x21, #0x30
1007bd30c:     	add	x0, sp, #0x300
1007bd310:     	sub	x1, x29, #0xa0
1007bd314:     	bl	0x10064f770 <__RINvYINtNtNtCskjxBf4UiEDI_8indexmap3map4iter4IterNtNtCshqYhlee0Vj9_10weavepy_vm6object7DictKeyNtBN_6ObjectENtNtNtNtCs8Mbv00yxnRz_4core4iter6traits8iterator8Iterator8find_mapTNtNtCshxvaOLs88l5_5alloc6string6StringB1u_EQNCNvMs2_BP_NtBP_11Interpreter16bind_python_argss7_0EBP_>
1007bd318:     	ldr	x8, [sp, #0x300]
1007bd31c:     	cmn	x8, #0x1
1007bd320:     	b.eq	0x1007bd38c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x19ac>
1007bd324:     	add	x8, sp, #0x300
1007bd328:     	ldp	q0, q1, [x8]
1007bd32c:     	stp	q0, q1, [x25]
1007bd330:     	ldr	q0, [x8, #0x20]
1007bd334:     	str	q0, [x25, #0x20]
1007bd338:     	ldr	x8, [sp, #0x5d0]
1007bd33c:     	cmp	x27, x8
1007bd340:     	b.ne	0x1007bd2e8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1908>
1007bd344:     	add	x0, sp, #0x5d0
1007bd348:     	mov	x1, x27
1007bd34c:     	mov	w2, #0x1                ; =1
1007bd350:     	mov	w3, #0x8                ; =8
1007bd354:     	mov	w4, #0x30               ; =48
1007bd358:     	bl	0x100fd8830 <__RINvNvMs2_NtCshxvaOLs88l5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshqYhlee0Vj9_10weavepy_vm>
1007bd35c:     	b	0x1007bd2e4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1904>
1007bd360:     	mov	x24, #0x0               ; =0
1007bd364:     	mov	x27, #0x0               ; =0
1007bd368:     	mov	w20, #0x8               ; =8
1007bd36c:     	str	xzr, [sp, #0x300]
1007bd370:     	str	x20, [sp, #0x308]
1007bd374:     	str	xzr, [sp, #0x310]
1007bd378:     	b	0x1007bd550 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1b70>
1007bd37c:     	mov	x8, #-0x1               ; =-1
1007bd380:     	str	x8, [sp, #0x300]
1007bd384:     	ldr	x8, [sp, #0x78]
1007bd388:     	b	0x1007bd420 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1a40>
1007bd38c:     	ldr	x21, [sp, #0x5d0]
1007bd390:     	b	0x1007bd3a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x19c0>
1007bd394:     	mov	x21, #0x0               ; =0
1007bd398:     	mov	x27, #0x0               ; =0
1007bd39c:     	mov	w20, #0x8               ; =8
1007bd3a0:     	str	x21, [sp, #0x300]
1007bd3a4:     	str	x20, [sp, #0x308]
1007bd3a8:     	str	x27, [sp, #0x310]
1007bd3ac:     	ldr	x8, [x19, #0x10]
1007bd3b0:     	sub	x8, x8, #0x1
1007bd3b4:     	str	x8, [x19, #0x10]
1007bd3b8:     	ldr	w8, [x19, #0x20]
1007bd3bc:     	subs	w8, w8, #0x1
1007bd3c0:     	str	w8, [x19, #0x20]
1007bd3c4:     	b.ne	0x1007bd3cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x19ec>
1007bd3c8:     	stlur	xzr, [x19, #0x18]
1007bd3cc:     	ldr	x8, [x22, #0x8]
1007bd3d0:     	cmp	x8, #0x0
1007bd3d4:     	cset	w9, ne
1007bd3d8:     	sub	x8, x8, x9
1007bd3dc:     	str	x8, [x22, #0x8]
1007bd3e0:     	mov	x8, #-0x1               ; =-1
1007bd3e4:     	ldaddl	x8, x8, [x19]
1007bd3e8:     	cmp	x8, #0x1
1007bd3ec:     	b.ne	0x1007bd3fc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1a1c>
1007bd3f0:     	dmb	ishld
1007bd3f4:     	add	x0, sp, #0x648
1007bd3f8:     	bl	0x1008b0354 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcINtNtCshqYhlee0Vj9_10weavepy_vm4sync7GilCellINtNtCskjxBf4UiEDI_8indexmap3map8IndexMapNtNtBL_6object7DictKeyNtB25_6ObjectNtNtBL_8fasthash13FxBuildHasherEEE9drop_slowBL_>
1007bd3fc:     	cmn	x21, #0x1
1007bd400:     	ldr	x8, [sp, #0x78]
1007bd404:     	b.eq	0x1007bd420 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1a40>
1007bd408:     	str	x21, [sp, #0x128]
1007bd40c:     	str	wzr, [sp, #0x124]
1007bd410:     	mov	x24, x20
1007bd414:     	mov	x8, x27
1007bd418:     	cbnz	x27, 0x1007bd438 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1a58>
1007bd41c:     	b	0x1007bd53c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1b5c>
1007bd420:     	ldp	x24, x8, [x8, #0x48]
1007bd424:     	mov	x9, #-0x1               ; =-1
1007bd428:     	str	x9, [sp, #0x128]
1007bd42c:     	mov	w9, #0x1                ; =1
1007bd430:     	str	w9, [sp, #0x124]
1007bd434:     	cbz	x8, 0x1007bd53c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1b5c>
1007bd438:     	mov	w9, #0x30               ; =48
1007bd43c:     	madd	x28, x8, x9, x24
1007bd440:     	ldr	x8, [sp, #0x108]
1007bd444:     	add	x8, x8, x8, lsl #1
1007bd448:     	lsl	x25, x8, #3
1007bd44c:     	ldr	x10, [sp, #0x550]
1007bd450:     	ldr	x9, [sp, #0x548]
1007bd454:     	mov	w21, #0x18              ; =24
1007bd458:     	ldr	x8, [sp, #0xf8]
1007bd45c:     	str	x9, [sp, #0x118]
1007bd460:     	umaddl	x8, w8, w21, x9
1007bd464:     	stp	x8, x10, [sp, #0x138]
1007bd468:     	b	0x1007bd49c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1abc>
1007bd46c:     	add	x8, sp, #0x410
1007bd470:     	ldr	q0, [x8]
1007bd474:     	ldr	x8, [sp, #0x420]
1007bd478:     	str	x8, [x23, #0x10]
1007bd47c:     	str	q0, [x23]
1007bd480:     	ldr	x8, [sp, #0x160]
1007bd484:     	mov	w9, #0x1                ; =1
1007bd488:     	strb	w9, [x8, x22]
1007bd48c:     	add	x24, x24, #0x30
1007bd490:     	cmp	x24, x28
1007bd494:     	ldr	x26, [sp, #0x130]
1007bd498:     	b.eq	0x1007bd53c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1b5c>
1007bd49c:     	ldr	x8, [sp, #0x168]
1007bd4a0:     	ldr	x9, [x8, #0xb0]
1007bd4a4:     	cmp	x26, x9
1007bd4a8:     	b.hi	0x1007bd48c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1aac>
1007bd4ac:     	mov	x19, #0x0               ; =0
1007bd4b0:     	ldr	x8, [x8, #0xa8]
1007bd4b4:     	ldr	x22, [sp, #0xf8]
1007bd4b8:     	umaddl	x23, w22, w21, x8
1007bd4bc:     	ldr	x26, [x24, #0x10]
1007bd4c0:     	b	0x1007bd4d4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1af4>
1007bd4c4:     	add	x22, x22, #0x1
1007bd4c8:     	add	x19, x19, #0x18
1007bd4cc:     	cmp	x25, x19
1007bd4d0:     	b.eq	0x1007bd48c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1aac>
1007bd4d4:     	add	x8, x23, x19
1007bd4d8:     	ldr	x9, [x8, #0x10]
1007bd4dc:     	cmp	x9, x26
1007bd4e0:     	b.ne	0x1007bd4c4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1ae4>
1007bd4e4:     	ldr	x0, [x8, #0x8]
1007bd4e8:     	ldr	x1, [x24, #0x8]
1007bd4ec:     	mov	x2, x26
1007bd4f0:     	bl	0x1010102c4 <dyld_stub_binder+0x1010102c4>
1007bd4f4:     	cbnz	w0, 0x1007bd4c4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1ae4>
1007bd4f8:     	ldr	x8, [sp, #0xd8]
1007bd4fc:     	cmp	x22, x8
1007bd500:     	b.hs	0x1007bee14 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3434>
1007bd504:     	ldr	x8, [sp, #0x160]
1007bd508:     	ldrb	w8, [x8, x22]
1007bd50c:     	tbnz	w8, #0x0, 0x1007bd48c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1aac>
1007bd510:     	add	x0, sp, #0x410
1007bd514:     	add	x1, x24, #0x18
1007bd518:     	bl	0x100cd53fc <__RNvXsW_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6ObjectNtNtCs8Mbv00yxnRz_4core5clone5Clone5clone>
1007bd51c:     	ldr	x8, [sp, #0x140]
1007bd520:     	cmp	x22, x8
1007bd524:     	b.hs	0x1007bee54 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3474>
1007bd528:     	ldr	x8, [sp, #0x138]
1007bd52c:     	add	x23, x8, x19
1007bd530:     	add	x0, x8, x19
1007bd534:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bd538:     	b	0x1007bd46c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1a8c>
1007bd53c:     	ldr	x23, [sp, #0xd8]
1007bd540:     	ldr	x28, [sp, #0x38]
1007bd544:     	ldr	x24, [sp, #0x128]
1007bd548:     	ldr	w8, [sp, #0x124]
1007bd54c:     	tbnz	w8, #0x0, 0x1007bd594 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1bb4>
1007bd550:     	add	x21, x27, #0x1
1007bd554:     	mov	x22, x20
1007bd558:     	b	0x1007bd56c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1b8c>
1007bd55c:     	add	x19, x22, #0x30
1007bd560:     	add	x0, x22, #0x18
1007bd564:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bd568:     	mov	x22, x19
1007bd56c:     	subs	x21, x21, #0x1
1007bd570:     	b.eq	0x1007bd588 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1ba8>
1007bd574:     	ldr	x8, [x22]
1007bd578:     	cbz	x8, 0x1007bd55c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1b7c>
1007bd57c:     	ldr	x0, [x22, #0x8]
1007bd580:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bd584:     	b	0x1007bd55c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1b7c>
1007bd588:     	cbz	x24, 0x1007bd594 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1bb4>
1007bd58c:     	mov	x0, x20
1007bd590:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bd594:     	ldurb	w8, [x29, #-0x80]
1007bd598:     	cmp	w8, #0xff
1007bd59c:     	ccmp	w8, #0xb, #0x4, ne
1007bd5a0:     	b.eq	0x1007bd5ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1bcc>
1007bd5a4:     	sub	x0, x29, #0x80
1007bd5a8:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bd5ac:     	ldr	x8, [sp, #0x160]
1007bd5b0:     	add	x19, x8, x23
1007bd5b4:     	ldr	x21, [sp, #0x538]
1007bd5b8:     	cbz	x21, 0x1007bd624 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1c44>
1007bd5bc:     	mov	x8, #0x0                ; =0
1007bd5c0:     	ldr	x9, [sp, #0x160]
1007bd5c4:     	add	x24, x9, x21
1007bd5c8:     	sub	x26, x21, #0x1
1007bd5cc:     	sub	x0, x21, #0x1
1007bd5d0:     	ldr	x9, [sp, #0xf8]
1007bd5d4:     	add	x9, x28, x9
1007bd5d8:     	ldr	x10, [sp, #0xa8]
1007bd5dc:     	add	x9, x9, x10
1007bd5e0:     	ldr	x10, [sp, #0x108]
1007bd5e4:     	add	x9, x9, x10
1007bd5e8:     	cmp	x9, x8
1007bd5ec:     	b.eq	0x1007bd624 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1c44>
1007bd5f0:     	mov	x27, x8
1007bd5f4:     	ldr	x8, [sp, #0x160]
1007bd5f8:     	ldrb	w10, [x8, x27]
1007bd5fc:     	subs	x25, x26, x27
1007bd600:     	b.eq	0x1007bd620 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1c40>
1007bd604:     	add	x8, x27, #0x1
1007bd608:     	tbnz	w10, #0x0, 0x1007bd5e8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1c08>
1007bd60c:     	sub	x0, x8, #0x1
1007bd610:     	ldr	x9, [sp, #0x160]
1007bd614:     	add	x24, x9, x8
1007bd618:     	add	x21, x27, #0x1
1007bd61c:     	b	0x1007bd7b0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1dd0>
1007bd620:     	tbz	w10, #0x0, 0x1007bd7b0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1dd0>
1007bd624:     	ldr	x8, [sp, #0x108]
1007bd628:     	ldr	x11, [sp, #0xf8]
1007bd62c:     	cbz	w8, 0x1007bd6a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1cc0>
1007bd630:     	cbz	w11, 0x1007bd64c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1c6c>
1007bd634:     	sub	x8, x11, #0x1
1007bd638:     	cmp	x8, x23
1007bd63c:     	b.hs	0x1007bd6a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1cc0>
1007bd640:     	ldr	x8, [sp, #0x160]
1007bd644:     	add	x8, x8, x11
1007bd648:     	str	x8, [sp, #0x160]
1007bd64c:     	mov	x25, #0x0               ; =0
1007bd650:     	ldr	x10, [sp, #0x108]
1007bd654:     	sub	x21, x10, #0x1
1007bd658:     	add	x8, x11, x11, lsl #1
1007bd65c:     	lsl	x8, x8, #3
1007bd660:     	ldr	x9, [sp, #0xa8]
1007bd664:     	add	x9, x28, x9
1007bd668:     	add	x9, x9, x10
1007bd66c:     	cmp	x9, x25
1007bd670:     	b.eq	0x1007bd6a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1cc0>
1007bd674:     	mov	x26, x25
1007bd678:     	ldr	x10, [sp, #0x160]
1007bd67c:     	ldrb	w10, [x10, x25]
1007bd680:     	add	x25, x25, #0x1
1007bd684:     	add	x8, x8, #0x18
1007bd688:     	cmp	x21, x26
1007bd68c:     	b.eq	0x1007bd694 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1cb4>
1007bd690:     	cbnz	w10, 0x1007bd66c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1c8c>
1007bd694:     	cmp	x21, x26
1007bd698:     	b.ne	0x1007bd970 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1f90>
1007bd69c:     	tbz	w10, #0x0, 0x1007bd970 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1f90>
1007bd6a0:     	add	x25, sp, #0x410
1007bd6a4:     	ldr	q0, [x25, #0x130]
1007bd6a8:     	str	q0, [sp, #0x1e0]
1007bd6ac:     	ldr	x8, [sp, #0x550]
1007bd6b0:     	str	x8, [sp, #0x1f0]
1007bd6b4:     	ldr	x19, [sp, #0x5b8]
1007bd6b8:     	ldr	x20, [sp, #0x5c0]
1007bd6bc:     	add	x27, sp, #0x200
1007bd6c0:     	cbz	x20, 0x1007bd6ec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1d0c>
1007bd6c4:     	add	x21, x19, #0x8
1007bd6c8:     	b	0x1007bd6d8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1cf8>
1007bd6cc:     	add	x21, x21, #0x18
1007bd6d0:     	subs	x20, x20, #0x1
1007bd6d4:     	b.eq	0x1007bd6ec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1d0c>
1007bd6d8:     	ldur	x8, [x21, #-0x8]
1007bd6dc:     	cbz	x8, 0x1007bd6cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1cec>
1007bd6e0:     	ldr	x0, [x21]
1007bd6e4:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bd6e8:     	b	0x1007bd6cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1cec>
1007bd6ec:     	ldr	x8, [sp, #0x5b0]
1007bd6f0:     	cbz	x8, 0x1007bd6fc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1d1c>
1007bd6f4:     	mov	x0, x19
1007bd6f8:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bd6fc:     	ldr	x9, [sp, #0x110]
1007bd700:     	cbz	x9, 0x1007bd728 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1d48>
1007bd704:     	mov	x8, #-0x1               ; =-1
1007bd708:     	ldaddl	x8, x8, [x9]
1007bd70c:     	cmp	x8, #0x1
1007bd710:     	b.ne	0x1007bd728 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1d48>
1007bd714:     	dmb	ishld
1007bd718:     	mov	w24, #0x1               ; =1
1007bd71c:     	mov	w19, #0x0               ; =0
1007bd720:     	add	x0, sp, #0x5a8
1007bd724:     	bl	0x1008b0354 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcINtNtCshqYhlee0Vj9_10weavepy_vm4sync7GilCellINtNtCskjxBf4UiEDI_8indexmap3map8IndexMapNtNtBL_6object7DictKeyNtB25_6ObjectNtNtBL_8fasthash13FxBuildHasherEEE9drop_slowBL_>
1007bd728:     	cbnz	w28, 0x1007bd748 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1d68>
1007bd72c:     	mov	w28, #0x1               ; =1
1007bd730:     	mov	x8, #-0x1               ; =-1
1007bd734:     	str	x8, [sp, #0xa0]
1007bd738:     	mov	w19, #0x0               ; =0
1007bd73c:     	mov	w22, #0x0               ; =0
1007bd740:     	add	x0, sp, #0x200
1007bd744:     	bl	0x1005fa178 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCskjxBf4UiEDI_8indexmap3map8IndexMapNtNtCshqYhlee0Vj9_10weavepy_vm6object7DictKeyNtB1i_6ObjectNtNtB1k_8fasthash13FxBuildHasherEEB1k_>
1007bd748:     	ldr	w8, [sp, #0x64]
1007bd74c:     	tbz	w8, #0x0, 0x1007bd798 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1db8>
1007bd750:     	ldr	x0, [sp, #0x578]
1007bd754:     	ldr	x8, [sp, #0x588]
1007bd758:     	sub	x8, x8, x0
1007bd75c:     	lsr	x8, x8, #3
1007bd760:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
1007bd764:     	movk	x9, #0xaaab
1007bd768:     	mov	x10, #0x1               ; =1
1007bd76c:     	madd	x20, x8, x9, x10
1007bd770:     	subs	x20, x20, #0x1
1007bd774:     	b.eq	0x1007bd788 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1da8>
1007bd778:     	add	x19, x0, #0x18
1007bd77c:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bd780:     	mov	x0, x19
1007bd784:     	b	0x1007bd770 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1d90>
1007bd788:     	ldr	x8, [sp, #0x580]
1007bd78c:     	cbz	x8, 0x1007bd798 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1db8>
1007bd790:     	ldr	x0, [sp, #0x570]
1007bd794:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bd798:     	cmp	x23, #0x11
1007bd79c:     	b.lo	0x1007bd7a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1dc8>
1007bd7a0:     	ldr	x0, [sp, #0x10]
1007bd7a4:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bd7a8:     	add	x22, sp, #0x300
1007bd7ac:     	b	0x1007bdcc8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x22e8>
1007bd7b0:     	ldr	x8, [sp, #0x168]
1007bd7b4:     	ldr	x1, [x8, #0xb0]
1007bd7b8:     	cmp	x0, x1
1007bd7bc:     	b.hs	0x1007bee98 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x34b8>
1007bd7c0:     	ldr	x8, [x8, #0xa8]
1007bd7c4:     	mov	w9, #0x18               ; =24
1007bd7c8:     	madd	x8, x0, x9, x8
1007bd7cc:     	ldp	x22, x23, [x8, #0x8]
1007bd7d0:     	mov	w0, #0x40               ; =64
1007bd7d4:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bd7d8:     	cbz	x0, 0x1007beea8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x34c8>
1007bd7dc:     	mov	x20, x0
1007bd7e0:     	stp	x22, x23, [x0]
1007bd7e4:     	mov	w23, #0x4               ; =4
1007bd7e8:     	str	x23, [sp, #0x410]
1007bd7ec:     	str	x0, [sp, #0x418]
1007bd7f0:     	mov	w22, #0x1               ; =1
1007bd7f4:     	str	x22, [sp, #0x420]
1007bd7f8:     	cmp	x26, x27
1007bd7fc:     	b.eq	0x1007bd8d0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1ef0>
1007bd800:     	mov	w22, #0x1               ; =1
1007bd804:     	b	0x1007bd828 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1e48>
1007bd808:     	mvn	x8, x27
1007bd80c:     	add	x25, x8, x25
1007bd810:     	add	x8, x20, x22, lsl #4
1007bd814:     	stp	x28, x23, [x8]
1007bd818:     	add	x22, x22, #0x1
1007bd81c:     	str	x22, [sp, #0x420]
1007bd820:     	cmp	x26, x27
1007bd824:     	b.eq	0x1007bd8c8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1ee8>
1007bd828:     	mov	x10, #0x0               ; =0
1007bd82c:     	add	x8, x24, x25
1007bd830:     	add	x9, x21, x25
1007bd834:     	sub	x0, x9, #0x1
1007bd838:     	sub	x26, x25, #0x1
1007bd83c:     	mov	x27, x10
1007bd840:     	add	x10, x24, x10
1007bd844:     	cmp	x10, x19
1007bd848:     	b.eq	0x1007bd8c8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1ee8>
1007bd84c:     	ldrb	w11, [x10]
1007bd850:     	cmp	x26, x27
1007bd854:     	b.eq	0x1007bd870 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1e90>
1007bd858:     	add	x10, x27, #0x1
1007bd85c:     	tbnz	w11, #0x0, 0x1007bd83c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1e5c>
1007bd860:     	add	x21, x21, x10
1007bd864:     	sub	x0, x21, #0x1
1007bd868:     	add	x24, x24, x10
1007bd86c:     	b	0x1007bd87c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1e9c>
1007bd870:     	mov	x24, x8
1007bd874:     	mov	x21, x9
1007bd878:     	tbnz	w11, #0x0, 0x1007bd8c8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1ee8>
1007bd87c:     	ldr	x8, [sp, #0x168]
1007bd880:     	ldr	x1, [x8, #0xb0]
1007bd884:     	cmp	x0, x1
1007bd888:     	b.hs	0x1007beec8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x34e8>
1007bd88c:     	ldr	x8, [x8, #0xa8]
1007bd890:     	mov	w9, #0x18               ; =24
1007bd894:     	madd	x8, x0, x9, x8
1007bd898:     	ldp	x28, x23, [x8, #0x8]
1007bd89c:     	ldr	x8, [sp, #0x410]
1007bd8a0:     	cmp	x22, x8
1007bd8a4:     	b.ne	0x1007bd808 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1e28>
1007bd8a8:     	add	x0, sp, #0x410
1007bd8ac:     	mov	x1, x22
1007bd8b0:     	mov	w2, #0x1                ; =1
1007bd8b4:     	mov	w3, #0x8                ; =8
1007bd8b8:     	mov	w4, #0x10               ; =16
1007bd8bc:     	bl	0x100fd8830 <__RINvNvMs2_NtCshxvaOLs88l5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshqYhlee0Vj9_10weavepy_vm>
1007bd8c0:     	ldr	x20, [sp, #0x418]
1007bd8c4:     	b	0x1007bd808 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1e28>
1007bd8c8:     	ldr	x23, [sp, #0x410]
1007bd8cc:     	ldr	x20, [sp, #0x418]
1007bd8d0:     	adrp	x1, 0x101208000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.1703+0x3d1b>
1007bd8d4:     	add	x1, x1, #0x9ec
1007bd8d8:     	add	x8, sp, #0x300
1007bd8dc:     	ldr	x9, [sp, #0x78]
1007bd8e0:     	add	x0, x9, #0x10
1007bd8e4:     	mov	w2, #0xc                ; =12
1007bd8e8:     	bl	0x1008b3fa4 <__RNvMsw_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_10PyFunction4slot>
1007bd8ec:     	add	x25, sp, #0x410
1007bd8f0:     	add	x27, sp, #0x200
1007bd8f4:     	ldrb	w8, [sp, #0x300]
1007bd8f8:     	cmp	w8, #0xff
1007bd8fc:     	b.eq	0x1007bd938 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1f58>
1007bd900:     	add	x8, sp, #0x410
1007bd904:     	add	x0, sp, #0x300
1007bd908:     	bl	0x10087d71c <__RNvMsR_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6Object6to_str>
1007bd90c:     	ldr	x8, [sp, #0x410]
1007bd910:     	ldr	x19, [sp, #0x418]
1007bd914:     	ldr	x26, [sp, #0x420]
1007bd918:     	cmp	x8, #0x0
1007bd91c:     	cset	w24, eq
1007bd920:     	ldrb	w8, [sp, #0x300]
1007bd924:     	cmp	w8, #0xff
1007bd928:     	b.eq	0x1007bdaf4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2114>
1007bd92c:     	add	x0, sp, #0x300
1007bd930:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bd934:     	b	0x1007bdaf4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2114>
1007bd938:     	ldr	x8, [sp, #0x168]
1007bd93c:     	ldr	x26, [x8, #0x38]
1007bd940:     	cbz	x26, 0x1007bdaec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x210c>
1007bd944:     	ldr	x27, [x8, #0x30]
1007bd948:     	mov	x0, x26
1007bd94c:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bd950:     	cbz	x0, 0x1007bef14 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3534>
1007bd954:     	mov	x19, x0
1007bd958:     	mov	x1, x27
1007bd95c:     	mov	x2, x26
1007bd960:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007bd964:     	mov	w24, #0x0               ; =0
1007bd968:     	add	x27, sp, #0x200
1007bd96c:     	b	0x1007bdaf4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2114>
1007bd970:     	add	x24, x11, x25
1007bd974:     	sub	x0, x24, #0x1
1007bd978:     	ldr	x9, [sp, #0x168]
1007bd97c:     	ldr	x1, [x9, #0xb0]
1007bd980:     	cmp	x0, x1
1007bd984:     	b.hs	0x1007beef4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3514>
1007bd988:     	ldr	x9, [x9, #0xa8]
1007bd98c:     	add	x8, x9, x8
1007bd990:     	ldp	x22, x23, [x8, #-0x10]
1007bd994:     	mov	w0, #0x40               ; =64
1007bd998:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bd99c:     	cbz	x0, 0x1007bef04 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3524>
1007bd9a0:     	mov	x20, x0
1007bd9a4:     	stp	x22, x23, [x0]
1007bd9a8:     	mov	w23, #0x4               ; =4
1007bd9ac:     	str	x23, [sp, #0x410]
1007bd9b0:     	str	x0, [sp, #0x418]
1007bd9b4:     	mov	w22, #0x1               ; =1
1007bd9b8:     	str	x22, [sp, #0x420]
1007bd9bc:     	cmp	x21, x26
1007bd9c0:     	b.eq	0x1007bda9c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x20bc>
1007bd9c4:     	ldr	x8, [sp, #0x108]
1007bd9c8:     	sub	x21, x8, x25
1007bd9cc:     	ldr	x8, [sp, #0x160]
1007bd9d0:     	add	x23, x8, x25
1007bd9d4:     	mov	w22, #0x1               ; =1
1007bd9d8:     	mov	x27, #0x0               ; =0
1007bd9dc:     	sub	x25, x21, #0x1
1007bd9e0:     	add	x8, x24, x24, lsl #1
1007bd9e4:     	lsl	x8, x8, #3
1007bd9e8:     	add	x9, x23, x27
1007bd9ec:     	cmp	x9, x19
1007bd9f0:     	b.eq	0x1007bda94 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x20b4>
1007bd9f4:     	mov	x26, x27
1007bd9f8:     	ldrb	w9, [x9]
1007bd9fc:     	add	x27, x27, #0x1
1007bda00:     	add	x8, x8, #0x18
1007bda04:     	cmp	x25, x26
1007bda08:     	b.eq	0x1007bda10 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2030>
1007bda0c:     	cbnz	w9, 0x1007bd9e8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2008>
1007bda10:     	cmp	x25, x26
1007bda14:     	b.ne	0x1007bda1c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x203c>
1007bda18:     	tbnz	w9, #0x0, 0x1007bda94 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x20b4>
1007bda1c:     	add	x28, x24, x27
1007bda20:     	sub	x10, x28, #0x1
1007bda24:     	ldr	x9, [sp, #0x168]
1007bda28:     	ldr	x1, [x9, #0xb0]
1007bda2c:     	cmp	x10, x1
1007bda30:     	b.hs	0x1007bef78 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3598>
1007bda34:     	ldr	x9, [x9, #0xa8]
1007bda38:     	add	x8, x9, x8
1007bda3c:     	ldp	x24, x8, [x8, #-0x10]
1007bda40:     	str	x8, [sp, #0x160]
1007bda44:     	ldr	x8, [sp, #0x410]
1007bda48:     	cmp	x22, x8
1007bda4c:     	b.ne	0x1007bda6c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x208c>
1007bda50:     	add	x0, sp, #0x410
1007bda54:     	mov	x1, x22
1007bda58:     	mov	w2, #0x1                ; =1
1007bda5c:     	mov	w3, #0x8                ; =8
1007bda60:     	mov	w4, #0x10               ; =16
1007bda64:     	bl	0x100fd8830 <__RINvNvMs2_NtCshxvaOLs88l5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshqYhlee0Vj9_10weavepy_vm>
1007bda68:     	ldr	x20, [sp, #0x418]
1007bda6c:     	sub	x21, x21, x27
1007bda70:     	add	x23, x23, x27
1007bda74:     	add	x8, x20, x22, lsl #4
1007bda78:     	ldr	x9, [sp, #0x160]
1007bda7c:     	stp	x24, x9, [x8]
1007bda80:     	add	x22, x22, #0x1
1007bda84:     	str	x22, [sp, #0x420]
1007bda88:     	mov	x24, x28
1007bda8c:     	cmp	x25, x26
1007bda90:     	b.ne	0x1007bd9d8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1ff8>
1007bda94:     	ldr	x23, [sp, #0x410]
1007bda98:     	ldr	x20, [sp, #0x418]
1007bda9c:     	add	x27, sp, #0x200
1007bdaa0:     	adrp	x1, 0x101208000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.1703+0x3d1b>
1007bdaa4:     	add	x1, x1, #0x9ec
1007bdaa8:     	add	x8, sp, #0x300
1007bdaac:     	ldr	x9, [sp, #0x78]
1007bdab0:     	add	x0, x9, #0x10
1007bdab4:     	mov	w2, #0xc                ; =12
1007bdab8:     	bl	0x1008b3fa4 <__RNvMsw_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_10PyFunction4slot>
1007bdabc:     	add	x25, sp, #0x410
1007bdac0:     	ldrb	w8, [sp, #0x300]
1007bdac4:     	cmp	w8, #0xff
1007bdac8:     	b.eq	0x1007be820 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e40>
1007bdacc:     	add	x8, sp, #0x410
1007bdad0:     	add	x0, sp, #0x300
1007bdad4:     	bl	0x10087d71c <__RNvMsR_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6Object6to_str>
1007bdad8:     	ldr	q0, [x25]
1007bdadc:     	str	q0, [x25, #0x1c0]
1007bdae0:     	ldr	x8, [sp, #0x420]
1007bdae4:     	str	x8, [sp, #0x5e0]
1007bdae8:     	b	0x1007be830 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e50>
1007bdaec:     	mov	w24, #0x1               ; =1
1007bdaf0:     	mov	w19, #0x1               ; =1
1007bdaf4:     	adrp	x3, 0x10120e000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4365+0x17c5>
1007bdaf8:     	add	x3, x3, #0xc28
1007bdafc:     	add	x0, sp, #0x300
1007bdb00:     	mov	x1, x19
1007bdb04:     	mov	x2, x26
1007bdb08:     	mov	w4, #0xa                ; =10
1007bdb0c:     	mov	x5, x20
1007bdb10:     	mov	x6, x22
1007bdb14:     	bl	0x1006e2788 <__RNvCshqYhlee0Vj9_10weavepy_vm24format_missing_arguments>
1007bdb18:     	add	x0, sp, #0x410
1007bdb1c:     	add	x1, sp, #0x300
1007bdb20:     	bl	0x100616cac <__RINvNtCshqYhlee0Vj9_10weavepy_vm5error10type_errorNtNtCshxvaOLs88l5_5alloc6string6StringEB4_>
1007bdb24:     	ldur	q0, [x25, #0x8]
1007bdb28:     	str	q0, [sp, #0x1e0]
1007bdb2c:     	ldr	x21, [sp, #0x410]
1007bdb30:     	ldr	x8, [sp, #0x428]
1007bdb34:     	str	x8, [sp, #0x1f0]
1007bdb38:     	ldp	q0, q1, [x25, #0x20]
1007bdb3c:     	stp	q0, q1, [sp, #0x1b0]
1007bdb40:     	ldr	x8, [sp, #0x450]
1007bdb44:     	str	x8, [sp, #0x1d0]
1007bdb48:     	tbnz	w24, #0x0, 0x1007bdb54 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2174>
1007bdb4c:     	mov	x0, x19
1007bdb50:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bdb54:     	cbz	x23, 0x1007bdb60 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2180>
1007bdb58:     	mov	x0, x20
1007bdb5c:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bdb60:     	mov	w24, #0x1               ; =1
1007bdb64:     	ldr	x23, [sp, #0xd8]
1007bdb68:     	ldr	x19, [sp, #0x5b8]
1007bdb6c:     	ldr	x20, [sp, #0x5c0]
1007bdb70:     	cbz	x20, 0x1007bdb9c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x21bc>
1007bdb74:     	add	x22, x19, #0x8
1007bdb78:     	b	0x1007bdb88 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x21a8>
1007bdb7c:     	add	x22, x22, #0x18
1007bdb80:     	subs	x20, x20, #0x1
1007bdb84:     	b.eq	0x1007bdb9c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x21bc>
1007bdb88:     	ldur	x8, [x22, #-0x8]
1007bdb8c:     	cbz	x8, 0x1007bdb7c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x219c>
1007bdb90:     	ldr	x0, [x22]
1007bdb94:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bdb98:     	b	0x1007bdb7c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x219c>
1007bdb9c:     	ldr	x8, [sp, #0x5b0]
1007bdba0:     	cbz	x8, 0x1007bdbac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x21cc>
1007bdba4:     	mov	x0, x19
1007bdba8:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bdbac:     	ldr	x9, [sp, #0x110]
1007bdbb0:     	cbz	x9, 0x1007bdbd4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x21f4>
1007bdbb4:     	mov	x8, #-0x1               ; =-1
1007bdbb8:     	ldaddl	x8, x8, [x9]
1007bdbbc:     	cmp	x8, #0x1
1007bdbc0:     	b.ne	0x1007bdbd4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x21f4>
1007bdbc4:     	dmb	ishld
1007bdbc8:     	mov	w19, #0x1               ; =1
1007bdbcc:     	add	x0, sp, #0x5a8
1007bdbd0:     	bl	0x1008b0354 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcINtNtCshqYhlee0Vj9_10weavepy_vm4sync7GilCellINtNtCskjxBf4UiEDI_8indexmap3map8IndexMapNtNtBL_6object7DictKeyNtB25_6ObjectNtNtBL_8fasthash13FxBuildHasherEEE9drop_slowBL_>
1007bdbd4:     	mov	x28, x24
1007bdbd8:     	ldr	w8, [sp, #0x158]
1007bdbdc:     	tbz	w8, #0x0, 0x1007bdc08 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2228>
1007bdbe0:     	ldr	x8, [sp, #0x220]
1007bdbe4:     	cbz	x8, 0x1007bdbf8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2218>
1007bdbe8:     	ldr	x9, [sp, #0x218]
1007bdbec:     	sub	x8, x9, x8, lsl #3
1007bdbf0:     	sub	x0, x8, #0x8
1007bdbf4:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bdbf8:     	mov	w19, #0x1               ; =1
1007bdbfc:     	mov	w22, #0x0               ; =0
1007bdc00:     	add	x0, sp, #0x200
1007bdc04:     	bl	0x1005f4ae4 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecINtCskjxBf4UiEDI_8indexmap6BucketNtNtCshqYhlee0Vj9_10weavepy_vm6object7DictKeyNtB1H_6ObjectEEEB1J_>
1007bdc08:     	ldr	x8, [sp, #0xa0]
1007bdc0c:     	sub	x8, x8, #0x1
1007bdc10:     	cmn	x8, #0x2
1007bdc14:     	csel	w8, wzr, w28, hs
1007bdc18:     	tbz	w8, #0x0, 0x1007bdc24 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2244>
1007bdc1c:     	ldr	x0, [sp, #0x18]
1007bdc20:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bdc24:     	ldr	w8, [sp, #0x64]
1007bdc28:     	tbz	w8, #0x0, 0x1007bdc74 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2294>
1007bdc2c:     	ldr	x0, [sp, #0x578]
1007bdc30:     	ldr	x8, [sp, #0x588]
1007bdc34:     	sub	x8, x8, x0
1007bdc38:     	lsr	x8, x8, #3
1007bdc3c:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
1007bdc40:     	movk	x9, #0xaaab
1007bdc44:     	mov	x10, #0x1               ; =1
1007bdc48:     	madd	x20, x8, x9, x10
1007bdc4c:     	subs	x20, x20, #0x1
1007bdc50:     	b.eq	0x1007bdc64 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2284>
1007bdc54:     	add	x19, x0, #0x18
1007bdc58:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bdc5c:     	mov	x0, x19
1007bdc60:     	b	0x1007bdc4c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x226c>
1007bdc64:     	ldr	x8, [sp, #0x580]
1007bdc68:     	cbz	x8, 0x1007bdc74 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2294>
1007bdc6c:     	ldr	x0, [sp, #0x570]
1007bdc70:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bdc74:     	cmp	x23, #0x11
1007bdc78:     	b.lo	0x1007bdc84 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x22a4>
1007bdc7c:     	ldr	x0, [sp, #0x10]
1007bdc80:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bdc84:     	ldr	x19, [sp, #0x548]
1007bdc88:     	ldr	x8, [sp, #0x550]
1007bdc8c:     	add	x22, x8, #0x1
1007bdc90:     	mov	x0, x19
1007bdc94:     	subs	x22, x22, #0x1
1007bdc98:     	b.eq	0x1007bdcac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x22cc>
1007bdc9c:     	add	x20, x0, #0x18
1007bdca0:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bdca4:     	mov	x0, x20
1007bdca8:     	b	0x1007bdc94 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x22b4>
1007bdcac:     	ldr	x8, [sp, #0x540]
1007bdcb0:     	cbz	x8, 0x1007bdcbc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x22dc>
1007bdcb4:     	mov	x0, x19
1007bdcb8:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bdcbc:     	cmn	x21, #0x2
1007bdcc0:     	add	x22, sp, #0x300
1007bdcc4:     	b.ne	0x1007bdd90 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x23b0>
1007bdcc8:     	mov	w28, #0x0               ; =0
1007bdccc:     	ldr	x8, [sp, #0x1f0]
1007bdcd0:     	ldr	q0, [sp, #0x1e0]
1007bdcd4:     	str	q0, [sp, #0x170]
1007bdcd8:     	str	x8, [sp, #0x180]
1007bdcdc:     	ldp	x4, x5, [sp, #0x178]
1007bdce0:     	add	x0, sp, #0x300
1007bdce4:     	add	x3, sp, #0x168
1007bdce8:     	ldr	x1, [sp, #0xb8]
1007bdcec:     	ldr	x2, [sp, #0x30]
1007bdcf0:     	bl	0x100909c88 <__RNvNtCshqYhlee0Vj9_10weavepy_vm5tier221try_call_native_bound>
1007bdcf4:     	ldr	x8, [sp, #0x300]
1007bdcf8:     	cmn	x8, #0x3
1007bdcfc:     	b.ne	0x1007bdde4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2404>
1007bdd00:     	ldr	x8, [sp, #0x168]
1007bdd04:     	mov	w9, #0x1                ; =1
1007bdd08:     	ldadd	x9, x8, [x8]
1007bdd0c:     	tbnz	x8, #0x3f, 0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bdd10:     	ldr	x20, [sp, #0x168]
1007bdd14:     	str	x20, [sp, #0x300]
1007bdd18:     	ldr	x8, [sp, #0x78]
1007bdd1c:     	ldr	x22, [x8, #0x68]
1007bdd20:     	cbz	x22, 0x1007bde38 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2458>
1007bdd24:     	add	x26, sp, #0x410
1007bdd28:     	ldr	x25, [x8, #0x60]
1007bdd2c:     	add	x8, x22, x22, lsl #1
1007bdd30:     	lsl	x21, x8, #3
1007bdd34:     	mov	x0, x21
1007bdd38:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bdd3c:     	cbz	x0, 0x1007bee44 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3464>
1007bdd40:     	mov	x19, x0
1007bdd44:     	mov	x23, #0x0               ; =0
1007bdd48:     	mov	x24, x22
1007bdd4c:     	mov	x1, x25
1007bdd50:     	cmp	x21, x23
1007bdd54:     	b.eq	0x1007bdd88 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x23a8>
1007bdd58:     	sub	x24, x24, #0x1
1007bdd5c:     	add	x25, x1, #0x18
1007bdd60:     	add	x0, sp, #0x410
1007bdd64:     	bl	0x100cd53fc <__RNvXsW_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6ObjectNtNtCs8Mbv00yxnRz_4core5clone5Clone5clone>
1007bdd68:     	add	x8, x19, x23
1007bdd6c:     	ldr	q0, [x26]
1007bdd70:     	str	q0, [x8]
1007bdd74:     	ldr	x9, [sp, #0x420]
1007bdd78:     	str	x9, [x8, #0x10]
1007bdd7c:     	add	x23, x23, #0x18
1007bdd80:     	mov	x1, x25
1007bdd84:     	cbnz	x24, 0x1007bdd50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2370>
1007bdd88:     	add	x25, sp, #0x410
1007bdd8c:     	b	0x1007bde3c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x245c>
1007bdd90:     	ldr	q0, [sp, #0x1e0]
1007bdd94:     	str	q0, [sp, #0x190]
1007bdd98:     	ldr	x8, [sp, #0x1f0]
1007bdd9c:     	str	x8, [sp, #0x1a0]
1007bdda0:     	ldp	q1, q2, [sp, #0x1b0]
1007bdda4:     	ldr	x10, [sp, #0x48]
1007bdda8:     	stp	q1, q2, [x10, #0x20]
1007bddac:     	ldr	x9, [sp, #0x1d0]
1007bddb0:     	str	x9, [x10, #0x40]
1007bddb4:     	stur	q0, [x10, #0x8]
1007bddb8:     	str	x8, [x10, #0x18]
1007bddbc:     	str	x21, [x10]
1007bddc0:     	ldr	x8, [sp, #0x168]
1007bddc4:     	mov	x9, #-0x1               ; =-1
1007bddc8:     	ldaddl	x9, x8, [x8]
1007bddcc:     	cmp	x8, #0x1
1007bddd0:     	b.ne	0x1007be800 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e20>
1007bddd4:     	dmb	ishld
1007bddd8:     	add	x0, sp, #0x168
1007bdddc:     	bl	0x100501eb8 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcNtCsdQKgh9VQBAd_16weavepy_compiler10CodeObjectE9drop_slowBI_>
1007bdde0:     	b	0x1007be800 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e20>
1007bdde4:     	ldp	q0, q1, [x22, #0x20]
1007bdde8:     	stp	q0, q1, [x25, #0x20]
1007bddec:     	ldr	x8, [sp, #0x340]
1007bddf0:     	str	x8, [sp, #0x450]
1007bddf4:     	ldp	q1, q0, [x22]
1007bddf8:     	stp	q1, q0, [x25]
1007bddfc:     	ldr	q0, [sp, #0x170]
1007bde00:     	str	q0, [x27]
1007bde04:     	ldr	x8, [sp, #0x180]
1007bde08:     	str	x8, [sp, #0x210]
1007bde0c:     	add	x1, sp, #0x200
1007bde10:     	ldr	x0, [sp, #0xb8]
1007bde14:     	bl	0x1007a6524 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter15recycle_scratch>
1007bde18:     	ldp	q0, q1, [x22, #0x20]
1007bde1c:     	ldr	x9, [sp, #0x48]
1007bde20:     	stp	q0, q1, [x9, #0x20]
1007bde24:     	ldr	x8, [sp, #0x340]
1007bde28:     	str	x8, [x9, #0x40]
1007bde2c:     	ldp	q1, q0, [x22]
1007bde30:     	stp	q1, q0, [x9]
1007bde34:     	b	0x1007be38c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x29ac>
1007bde38:     	mov	w19, #0x8               ; =8
1007bde3c:     	str	x22, [sp, #0x410]
1007bde40:     	str	x19, [sp, #0x418]
1007bde44:     	str	x22, [sp, #0x420]
1007bde48:     	ldr	x10, [sp, #0x78]
1007bde4c:     	ldr	x8, [x10, #0x70]
1007bde50:     	mov	w9, #0x1                ; =1
1007bde54:     	ldadd	x9, x8, [x8]
1007bde58:     	tbnz	x8, #0x3f, 0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bde5c:     	ldp	x5, x8, [x10, #0x70]
1007bde60:     	mov	w9, #0x1                ; =1
1007bde64:     	ldadd	x9, x8, [x8]
1007bde68:     	ldr	x22, [sp, #0xb8]
1007bde6c:     	tbnz	x8, #0x3f, 0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bde70:     	ldr	x6, [x10, #0x78]
1007bde74:     	add	x0, sp, #0x200
1007bde78:     	add	x3, sp, #0x170
1007bde7c:     	add	x4, sp, #0x410
1007bde80:     	mov	x1, x22
1007bde84:     	mov	x2, x20
1007bde88:     	bl	0x10074679c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter10make_frame>
1007bde8c:     	ldr	x8, [sp, #0x168]
1007bde90:     	ldrb	w10, [x8, #0x1e3]
1007bde94:     	ldrb	w9, [x8, #0x1e4]
1007bde98:     	tbz	w10, #0x0, 0x1007bdea4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x24c4>
1007bde9c:     	tbnz	w9, #0x0, 0x1007bdea8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x24c8>
1007bdea0:     	b	0x1007bdf6c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x258c>
1007bdea4:     	cbz	w9, 0x1007bdf60 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2580>
1007bdea8:     	adrp	x0, 0x102677000 <__RNvNCNKNvNtNtCshqYhlee0Vj9_10weavepy_vm6stdlib2io14TW_REPR_ACTIVE0023___RUST_STD_INTERNAL_VAL+0x8>
1007bdeac:     	add	x0, x0, #0x70
1007bdeb0:     	ldr	x8, [x0]
1007bdeb4:     	blr	x8
1007bdeb8:     	ldr	x8, [x0]
1007bdebc:     	str	x8, [sp, #0x160]
1007bdec0:     	cmp	x8, #0x0
1007bdec4:     	b.le	0x1007bdf6c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x258c>
1007bdec8:     	ldr	x23, [x22, #0x2f0]
1007bdecc:     	adrp	x0, 0x102676000 <_BZ2_rNums+0x2d8>
1007bded0:     	add	x0, x0, #0xba8
1007bded4:     	ldr	x8, [x0]
1007bded8:     	blr	x8
1007bdedc:     	mov	x24, x0
1007bdee0:     	ldr	x1, [x0]
1007bdee4:     	cbz	x1, 0x1007bea2c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x304c>
1007bdee8:     	ldr	x8, [x23, #0x18]
1007bdeec:     	cmp	x8, x1
1007bdef0:     	b.ne	0x1007bea44 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3064>
1007bdef4:     	ldr	w8, [x23, #0x20]
1007bdef8:     	add	w8, w8, #0x1
1007bdefc:     	str	w8, [x23, #0x20]
1007bdf00:     	ldr	x8, [x23, #0x10]
1007bdf04:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1007bdf08:     	cmp	x8, x9
1007bdf0c:     	b.hs	0x1007bea70 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3090>
1007bdf10:     	mov	x9, #0x5555555555555555 ; =6148914691236517205
1007bdf14:     	movk	x9, #0x5556
1007bdf18:     	movk	x9, #0x555, lsl #48
1007bdf1c:     	add	x8, x8, #0x1
1007bdf20:     	str	x8, [x23, #0x10]
1007bdf24:     	ldr	x8, [x24, #0x8]
1007bdf28:     	add	x8, x8, #0x1
1007bdf2c:     	str	x8, [x24, #0x8]
1007bdf30:     	ldr	x19, [x23, #0x38]
1007bdf34:     	ldr	x8, [sp, #0x160]
1007bdf38:     	cmp	x8, x19
1007bdf3c:     	csel	x20, x8, x19, lo
1007bdf40:     	add	x8, x20, x20, lsl #1
1007bdf44:     	lsl	x1, x8, #3
1007bdf48:     	sub	x8, x9, #0x1
1007bdf4c:     	cmp	x20, x8
1007bdf50:     	b.ls	0x1007bdf78 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2598>
1007bdf54:     	mov	x0, #0x0                ; =0
1007bdf58:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bdf5c:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bdf60:     	ldrb	w8, [x8, #0x1e5]
1007bdf64:     	cmp	w8, #0x1
1007bdf68:     	b.ne	0x1007bdfa4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x25c4>
1007bdf6c:     	mov	w8, #0xff               ; =255
1007bdf70:     	sturb	w8, [x29, #-0xb8]
1007bdf74:     	b	0x1007be2a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x28c8>
1007bdf78:     	ldr	x21, [x23, #0x30]
1007bdf7c:     	str	w28, [sp, #0x158]
1007bdf80:     	str	x23, [sp, #0x150]
1007bdf84:     	str	x24, [sp, #0x140]
1007bdf88:     	cbz	x1, 0x1007bdfb8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x25d8>
1007bdf8c:     	mov	x22, x1
1007bdf90:     	mov	x0, x1
1007bdf94:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007bdf98:     	cbz	x0, 0x1007beee8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3508>
1007bdf9c:     	ldr	x22, [sp, #0xb8]
1007bdfa0:     	b	0x1007bdfc0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x25e0>
1007bdfa4:     	add	x2, sp, #0x200
1007bdfa8:     	ldr	x0, [sp, #0x48]
1007bdfac:     	mov	x1, x22
1007bdfb0:     	bl	0x100839514 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter9run_frame>
1007bdfb4:     	b	0x1007be780 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2da0>
1007bdfb8:     	mov	x20, #0x0               ; =0
1007bdfbc:     	mov	w0, #0x8                ; =8
1007bdfc0:     	mov	x26, #0x0               ; =0
1007bdfc4:     	add	x28, sp, #0x410
1007bdfc8:     	str	x20, [sp, #0x5d0]
1007bdfcc:     	str	x0, [sp, #0x5d8]
1007bdfd0:     	sub	x21, x21, #0x8
1007bdfd4:     	str	xzr, [sp, #0x5e0]
1007bdfd8:     	lsl	x24, x19, #3
1007bdfdc:     	add	x27, x0, #0x10
1007bdfe0:     	mov	w23, #0x1               ; =1
1007bdfe4:     	cbz	x24, 0x1007be1dc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x27fc>
1007bdfe8:     	ldr	x8, [x21, x24]
1007bdfec:     	ldr	x8, [x8, #0x50]
1007bdff0:     	cbz	x8, 0x1007be99c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2fbc>
1007bdff4:     	ldr	x20, [x8, #0x50]
1007bdff8:     	cbz	x20, 0x1007be040 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2660>
1007bdffc:     	ldr	x22, [x8, #0x48]
1007be000:     	mov	x0, x20
1007be004:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be008:     	cbz	x0, 0x1007bed50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3370>
1007be00c:     	mov	x19, x0
1007be010:     	mov	x1, x22
1007be014:     	mov	x2, x20
1007be018:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007be01c:     	mov	x8, #-0x18              ; =-24
1007be020:     	movk	x8, #0x7fff, lsl #48
1007be024:     	cmp	x20, x8
1007be028:     	b.hi	0x1007bed28 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3348>
1007be02c:     	add	x25, x20, #0x17
1007be030:     	and	x0, x25, #0x7ffffffffffffff8
1007be034:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be038:     	cbnz	x0, 0x1007be054 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2674>
1007be03c:     	b	0x1007befb0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35d0>
1007be040:     	mov	w19, #0x1               ; =1
1007be044:     	add	x25, x20, #0x17
1007be048:     	and	x0, x25, #0x7ffffffffffffff8
1007be04c:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be050:     	cbz	x0, 0x1007befb0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35d0>
1007be054:     	mov	x22, x0
1007be058:     	dup.2d	v0, x23
1007be05c:     	str	q0, [x0], #0x10
1007be060:     	mov	x1, x19
1007be064:     	mov	x2, x20
1007be068:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007be06c:     	stp	x22, x20, [sp, #0x1b8]
1007be070:     	mov	w8, #0x7                ; =7
1007be074:     	strb	w8, [sp, #0x1b0]
1007be078:     	cbz	x20, 0x1007be084 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x26a4>
1007be07c:     	mov	x0, x19
1007be080:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007be084:     	ldr	x19, [x21, x24]
1007be088:     	add	x0, x19, #0x10
1007be08c:     	bl	0x100858668 <__RNvMs5_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_10FrameShell14current_lineno>
1007be090:     	mov	w8, w0
1007be094:     	str	x8, [sp, #0x418]
1007be098:     	mov	w8, #0x3                ; =3
1007be09c:     	strb	w8, [sp, #0x410]
1007be0a0:     	ldr	x8, [x19, #0x50]
1007be0a4:     	cbz	x8, 0x1007be9b8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2fd8>
1007be0a8:     	ldr	x19, [x8, #0x20]
1007be0ac:     	cbz	x19, 0x1007be0f4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2714>
1007be0b0:     	ldr	x22, [x8, #0x18]
1007be0b4:     	mov	x0, x19
1007be0b8:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be0bc:     	cbz	x0, 0x1007bed88 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x33a8>
1007be0c0:     	mov	x20, x0
1007be0c4:     	mov	x1, x22
1007be0c8:     	mov	x2, x19
1007be0cc:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007be0d0:     	mov	x8, #-0x18              ; =-24
1007be0d4:     	movk	x8, #0x7fff, lsl #48
1007be0d8:     	cmp	x19, x8
1007be0dc:     	b.hi	0x1007bed60 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3380>
1007be0e0:     	add	x25, x19, #0x17
1007be0e4:     	and	x0, x25, #0x7ffffffffffffff8
1007be0e8:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be0ec:     	cbnz	x0, 0x1007be108 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2728>
1007be0f0:     	b	0x1007befc0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35e0>
1007be0f4:     	mov	w20, #0x1               ; =1
1007be0f8:     	add	x25, x19, #0x17
1007be0fc:     	and	x0, x25, #0x7ffffffffffffff8
1007be100:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be104:     	cbz	x0, 0x1007befc0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35e0>
1007be108:     	mov	x22, x0
1007be10c:     	dup.2d	v0, x23
1007be110:     	str	q0, [x0], #0x10
1007be114:     	mov	x1, x20
1007be118:     	mov	x2, x19
1007be11c:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007be120:     	cbz	x19, 0x1007be12c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x274c>
1007be124:     	mov	x0, x20
1007be128:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007be12c:     	ldr	x8, [sp, #0x1c0]
1007be130:     	str	x8, [sp, #0x310]
1007be134:     	ldr	q0, [sp, #0x1b0]
1007be138:     	add	x9, sp, #0x300
1007be13c:     	str	q0, [x9]
1007be140:     	add	x25, sp, #0x410
1007be144:     	ldr	q1, [x25]
1007be148:     	add	x10, sp, #0x300
1007be14c:     	stur	q1, [x10, #0x18]
1007be150:     	ldr	x8, [sp, #0x420]
1007be154:     	stur	x8, [x10, #0x28]
1007be158:     	stur	q0, [x28, #0x18]
1007be15c:     	ldp	q0, q1, [x9, #0x10]
1007be160:     	stur	q0, [x28, #0x28]
1007be164:     	stur	q1, [x28, #0x38]
1007be168:     	mov	w8, #0x7                ; =7
1007be16c:     	strb	w8, [sp, #0x458]
1007be170:     	str	x22, [sp, #0x460]
1007be174:     	str	x19, [sp, #0x468]
1007be178:     	dup.2d	v0, x23
1007be17c:     	str	q0, [x25]
1007be180:     	mov	x8, #-0x1               ; =-1
1007be184:     	str	x8, [sp, #0x420]
1007be188:     	mov	w0, #0x60               ; =96
1007be18c:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be190:     	cbz	x0, 0x1007be97c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2f9c>
1007be194:     	ldp	q0, q1, [x25, #0x20]
1007be198:     	stp	q0, q1, [x0, #0x20]
1007be19c:     	ldp	q0, q1, [x25, #0x40]
1007be1a0:     	stp	q0, q1, [x0, #0x40]
1007be1a4:     	ldp	q0, q1, [x25]
1007be1a8:     	stp	q0, q1, [x0]
1007be1ac:     	mov	w8, #0x9                ; =9
1007be1b0:     	sturb	w8, [x27, #-0x10]
1007be1b4:     	add	x26, x26, #0x1
1007be1b8:     	mov	w8, #0x3                ; =3
1007be1bc:     	stp	x0, x8, [x27, #-0x8]
1007be1c0:     	add	x27, x27, #0x18
1007be1c4:     	sub	x24, x24, #0x8
1007be1c8:     	ldr	x8, [sp, #0x160]
1007be1cc:     	cmp	x8, x26
1007be1d0:     	ldr	x22, [sp, #0xb8]
1007be1d4:     	b.ne	0x1007bdfe4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2604>
1007be1d8:     	ldr	x26, [sp, #0x160]
1007be1dc:     	ldr	q0, [x25, #0x1c0]
1007be1e0:     	add	x27, sp, #0x200
1007be1e4:     	str	q0, [x27, #0xe0]
1007be1e8:     	str	x26, [sp, #0x2f0]
1007be1ec:     	ldr	w28, [sp, #0x158]
1007be1f0:     	cbz	x26, 0x1007be210 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2830>
1007be1f4:     	add	x0, sp, #0x2e0
1007be1f8:     	bl	0x10070a960 <__RNvMNtCshqYhlee0Vj9_10weavepy_vm13tuple_storageNtB2_12TupleStorage8from_vec>
1007be1fc:     	mov	x19, x0
1007be200:     	mov	x20, x1
1007be204:     	ldr	x21, [sp, #0x150]
1007be208:     	ldr	x24, [sp, #0x140]
1007be20c:     	b	0x1007be268 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2888>
1007be210:     	adrp	x0, 0x102677000 <__RNvNCNKNvNtNtCshqYhlee0Vj9_10weavepy_vm6stdlib2io14TW_REPR_ACTIVE0023___RUST_STD_INTERNAL_VAL+0x8>
1007be214:     	add	x0, x0, #0x250
1007be218:     	ldr	x8, [x0]
1007be21c:     	blr	x8
1007be220:     	ldrb	w8, [x0, #0x10]
1007be224:     	cmp	w8, #0x1
1007be228:     	b.ne	0x1007bec84 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x32a4>
1007be22c:     	ldp	x19, x20, [x0]
1007be230:     	mov	w8, #0x1                ; =1
1007be234:     	ldadd	x8, x8, [x19]
1007be238:     	ldr	x21, [sp, #0x150]
1007be23c:     	ldr	x24, [sp, #0x140]
1007be240:     	tbnz	x8, #0x3f, 0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007be244:     	ldr	x22, [sp, #0x2e8]
1007be248:     	mov	x0, x22
1007be24c:     	mov	x1, #0x0                ; =0
1007be250:     	bl	0x100612b04 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueSNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBG_>
1007be254:     	ldr	x8, [sp, #0x2e0]
1007be258:     	cbz	x8, 0x1007be264 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2884>
1007be25c:     	mov	x0, x22
1007be260:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007be264:     	ldr	x22, [sp, #0xb8]
1007be268:     	mov	w8, #0x9                ; =9
1007be26c:     	sturb	w8, [x29, #-0xb8]
1007be270:     	stp	x19, x20, [x29, #-0xb0]
1007be274:     	ldr	x8, [x21, #0x10]
1007be278:     	sub	x8, x8, #0x1
1007be27c:     	str	x8, [x21, #0x10]
1007be280:     	ldr	w8, [x21, #0x20]
1007be284:     	subs	w8, w8, #0x1
1007be288:     	str	w8, [x21, #0x20]
1007be28c:     	b.ne	0x1007be294 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x28b4>
1007be290:     	stlur	xzr, [x21, #0x18]
1007be294:     	ldr	x8, [x24, #0x8]
1007be298:     	cmp	x8, #0x0
1007be29c:     	cset	w9, ne
1007be2a0:     	sub	x8, x8, x9
1007be2a4:     	str	x8, [x24, #0x8]
1007be2a8:     	mov	w8, #0xff               ; =255
1007be2ac:     	strb	w8, [sp, #0x300]
1007be2b0:     	add	x0, sp, #0x410
1007be2b4:     	add	x2, sp, #0x200
1007be2b8:     	add	x3, sp, #0x300
1007be2bc:     	mov	x1, x22
1007be2c0:     	bl	0x100818530 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter25run_until_yield_or_return>
1007be2c4:     	ldr	x8, [sp, #0x410]
1007be2c8:     	ldur	q0, [x25, #0x8]
1007be2cc:     	ldur	q1, [x25, #0x18]
1007be2d0:     	stp	q0, q1, [sp, #0x1b0]
1007be2d4:     	cmn	x8, #0x2
1007be2d8:     	ldr	x21, [sp, #0x78]
1007be2dc:     	b.ne	0x1007be34c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x296c>
1007be2e0:     	add	x23, sp, #0x640
1007be2e4:     	ldp	q0, q1, [sp, #0x1b0]
1007be2e8:     	stp	q0, q1, [x25, #0x1c0]
1007be2ec:     	ldr	x26, [sp, #0x5d0]
1007be2f0:     	cmp	x26, #0x2
1007be2f4:     	cset	w24, ne
1007be2f8:     	b.eq	0x1007be3f0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2a10>
1007be2fc:     	mov	w19, #0x34              ; =52
1007be300:     	mov	w0, #0x34               ; =52
1007be304:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be308:     	cbz	x0, 0x1007beeb8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x34d8>
1007be30c:     	mov	w8, #0x5441             ; =21569
1007be310:     	movk	w8, #0x524f, lsl #16
1007be314:     	str	w8, [x0, #0x30]
1007be318:     	adrp	x8, 0x10120f000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.5486+0x923>
1007be31c:     	add	x8, x8, #0x2d4
1007be320:     	ldp	q0, q1, [x8]
1007be324:     	stp	q0, q1, [x0]
1007be328:     	ldr	q0, [x8, #0x20]
1007be32c:     	str	q0, [x0, #0x20]
1007be330:     	adrp	x8, 0x1011da000 <_anon.62c35deff83376c58a4fa8d541d7c1d3.553+0x342>
1007be334:     	ldr	q0, [x8, #0x610]
1007be338:     	ldr	x9, [sp, #0x48]
1007be33c:     	str	q0, [x9]
1007be340:     	mov	w8, #0x34               ; =52
1007be344:     	stp	x0, x8, [x9, #0x10]
1007be348:     	b	0x1007be74c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2d6c>
1007be34c:     	ldur	q0, [x25, #0x28]
1007be350:     	ldr	x9, [sp, #0x48]
1007be354:     	stur	q0, [x9, #0x28]
1007be358:     	ldur	q0, [x25, #0x38]
1007be35c:     	stur	q0, [x9, #0x38]
1007be360:     	ldp	q0, q1, [sp, #0x1b0]
1007be364:     	stur	q0, [x9, #0x8]
1007be368:     	stur	q1, [x9, #0x18]
1007be36c:     	str	x8, [x9]
1007be370:     	ldurb	w8, [x29, #-0xb8]
1007be374:     	cmp	w8, #0xff
1007be378:     	b.eq	0x1007be384 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x29a4>
1007be37c:     	sub	x0, x29, #0xb8
1007be380:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007be384:     	add	x0, sp, #0x200
1007be388:     	bl	0x1006021b4 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtCshqYhlee0Vj9_10weavepy_vm5FrameEBD_>
1007be38c:     	ldr	x8, [sp, #0x168]
1007be390:     	mov	x9, #-0x1               ; =-1
1007be394:     	ldaddl	x9, x8, [x8]
1007be398:     	cmp	x8, #0x1
1007be39c:     	b.ne	0x1007be3ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x29cc>
1007be3a0:     	dmb	ishld
1007be3a4:     	add	x0, sp, #0x168
1007be3a8:     	bl	0x100501eb8 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcNtCsdQKgh9VQBAd_16weavepy_compiler10CodeObjectE9drop_slowBI_>
1007be3ac:     	cbz	w28, 0x1007be800 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e20>
1007be3b0:     	ldr	x8, [sp, #0xb0]
1007be3b4:     	ldp	x20, x8, [x8, #0x8]
1007be3b8:     	add	x21, x8, #0x1
1007be3bc:     	mov	x22, x20
1007be3c0:     	b	0x1007be3d4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x29f4>
1007be3c4:     	add	x19, x22, #0x30
1007be3c8:     	add	x0, x22, #0x18
1007be3cc:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007be3d0:     	mov	x22, x19
1007be3d4:     	subs	x21, x21, #0x1
1007be3d8:     	b.eq	0x1007be7ec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e0c>
1007be3dc:     	ldr	x8, [x22]
1007be3e0:     	cbz	x8, 0x1007be3c4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x29e4>
1007be3e4:     	ldr	x0, [x22, #0x8]
1007be3e8:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007be3ec:     	b	0x1007be3c4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x29e4>
1007be3f0:     	ldr	x8, [sp, #0x168]
1007be3f4:     	ldrb	w9, [x8, #0x1e4]
1007be3f8:     	tbz	w9, #0x0, 0x1007be404 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2a24>
1007be3fc:     	mov	w20, #0x1               ; =1
1007be400:     	b	0x1007be40c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2a2c>
1007be404:     	ldrb	w8, [x8, #0x1e5]
1007be408:     	lsl	w20, w8, #1
1007be40c:     	ldr	x8, [sp, #0x30]
1007be410:     	stur	x8, [x29, #-0xf0]
1007be414:     	adrp	x2, 0x1011cb000 <__RNvNtCs2D3IxEleHGH_12weavepy_capi6abi31413NATIVE_LAYOUT+0xa2a>
1007be418:     	add	x2, x2, #0x920
1007be41c:     	add	x0, sp, #0x410
1007be420:     	sub	x1, x29, #0xf0
1007be424:     	mov	w3, #0x8                ; =8
1007be428:     	bl	0x100679204 <__RNCNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB7_11Interpreter17call_python_owneds_0B7_>
1007be42c:     	ldr	x8, [sp, #0x410]
1007be430:     	cmn	x8, #0x1
1007be434:     	b.eq	0x1007be44c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2a6c>
1007be438:     	ldr	q0, [x25]
1007be43c:     	str	q0, [x23, #0x70]
1007be440:     	ldr	x8, [sp, #0x420]
1007be444:     	stur	x8, [x29, #-0x90]
1007be448:     	b	0x1007be484 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2aa4>
1007be44c:     	ldr	x19, [x21, #0x20]
1007be450:     	cbz	x19, 0x1007be478 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2a98>
1007be454:     	ldr	x22, [x21, #0x18]
1007be458:     	mov	x0, x19
1007be45c:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be460:     	cbz	x0, 0x1007beeb8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x34d8>
1007be464:     	mov	x21, x0
1007be468:     	mov	x1, x22
1007be46c:     	mov	x2, x19
1007be470:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007be474:     	b	0x1007be47c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2a9c>
1007be478:     	mov	w21, #0x1               ; =1
1007be47c:     	stp	x19, x21, [x29, #-0xa0]
1007be480:     	stur	x19, [x29, #-0x90]
1007be484:     	adrp	x2, 0x101208000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.1703+0x3d1b>
1007be488:     	add	x2, x2, #0x9ec
1007be48c:     	add	x0, sp, #0x410
1007be490:     	sub	x1, x29, #0xf0
1007be494:     	mov	w3, #0xc                ; =12
1007be498:     	bl	0x100679204 <__RNCNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB7_11Interpreter17call_python_owneds_0B7_>
1007be49c:     	ldr	x8, [sp, #0x410]
1007be4a0:     	cmn	x8, #0x1
1007be4a4:     	b.eq	0x1007be4bc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2adc>
1007be4a8:     	ldr	q0, [x25]
1007be4ac:     	str	q0, [x23, #0x90]
1007be4b0:     	ldr	x8, [sp, #0x420]
1007be4b4:     	stur	x8, [x29, #-0x70]
1007be4b8:     	b	0x1007be4f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2b18>
1007be4bc:     	ldr	x8, [sp, #0x168]
1007be4c0:     	ldr	x19, [x8, #0x38]
1007be4c4:     	cbz	x19, 0x1007be4ec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2b0c>
1007be4c8:     	ldr	x22, [x8, #0x30]
1007be4cc:     	mov	x0, x19
1007be4d0:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be4d4:     	cbz	x0, 0x1007bef24 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3544>
1007be4d8:     	mov	x21, x0
1007be4dc:     	mov	x1, x22
1007be4e0:     	mov	x2, x19
1007be4e4:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007be4e8:     	b	0x1007be4f0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2b10>
1007be4ec:     	mov	w21, #0x1               ; =1
1007be4f0:     	stp	x19, x21, [x29, #-0x80]
1007be4f4:     	stur	x19, [x29, #-0x70]
1007be4f8:     	ldr	x8, [sp, #0x288]
1007be4fc:     	mov	w9, #0x1                ; =1
1007be500:     	ldadd	x9, x8, [x8]
1007be504:     	tbnz	x8, #0x3f, 0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007be508:     	ldr	x8, [sp, #0x288]
1007be50c:     	ldp	x22, x19, [x29, #-0xa0]
1007be510:     	ldp	x23, x21, [x29, #-0x80]
1007be514:     	mov	w9, #0x10               ; =16
1007be518:     	strb	w9, [sp, #0x570]
1007be51c:     	str	x8, [sp, #0x578]
1007be520:     	ldp	q0, q1, [x27, #0xa0]
1007be524:     	stp	q0, q1, [x25, #0xa0]
1007be528:     	ldp	q0, q1, [x27, #0xc0]
1007be52c:     	stp	q0, q1, [x25, #0xc0]
1007be530:     	ldp	q0, q1, [x27, #0x60]
1007be534:     	stp	q0, q1, [x25, #0x60]
1007be538:     	ldp	q0, q1, [x27, #0x80]
1007be53c:     	stp	q0, q1, [x25, #0x80]
1007be540:     	ldp	q0, q1, [x27, #0x20]
1007be544:     	stp	q0, q1, [x25, #0x20]
1007be548:     	ldp	q0, q1, [x27, #0x40]
1007be54c:     	stp	q0, q1, [x25, #0x40]
1007be550:     	ldp	q0, q1, [x27]
1007be554:     	stp	q0, q1, [x25]
1007be558:     	mov	w0, #0xe0               ; =224
1007be55c:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be560:     	cbz	x0, 0x1007beaac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x30cc>
1007be564:     	mov	x5, x0
1007be568:     	ldp	q0, q1, [x27, #0xa0]
1007be56c:     	stp	q0, q1, [x0, #0xa0]
1007be570:     	ldp	q0, q1, [x27, #0xc0]
1007be574:     	stp	q0, q1, [x0, #0xc0]
1007be578:     	ldp	q0, q1, [x27, #0x60]
1007be57c:     	stp	q0, q1, [x0, #0x60]
1007be580:     	ldp	q0, q1, [x27, #0x80]
1007be584:     	stp	q0, q1, [x0, #0x80]
1007be588:     	ldp	q0, q1, [x27, #0x20]
1007be58c:     	stp	q0, q1, [x0, #0x20]
1007be590:     	ldp	q0, q1, [x27, #0x40]
1007be594:     	stp	q0, q1, [x0, #0x40]
1007be598:     	ldp	q0, q1, [x27]
1007be59c:     	stp	q0, q1, [x0]
1007be5a0:     	add	x0, sp, #0x300
1007be5a4:     	sub	x1, x29, #0xa0
1007be5a8:     	sub	x2, x29, #0x80
1007be5ac:     	add	x4, sp, #0x570
1007be5b0:     	mov	x3, x20
1007be5b4:     	bl	0x1005e6fc8 <__RINvMsD_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB6_11PyGenerator3newNtNtCshxvaOLs88l5_5alloc6string6StringB11_EB8_>
1007be5b8:     	mov	w8, #0x1                ; =1
1007be5bc:     	dup.2d	v0, x8
1007be5c0:     	str	q0, [x25]
1007be5c4:     	add	x19, sp, #0x410
1007be5c8:     	add	x0, x19, #0x10
1007be5cc:     	add	x1, sp, #0x300
1007be5d0:     	mov	w2, #0x110              ; =272
1007be5d4:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007be5d8:     	mov	w0, #0x120              ; =288
1007be5dc:     	bl	0x10101024c <dyld_stub_binder+0x10101024c>
1007be5e0:     	cbz	x0, 0x1007beabc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x30dc>
1007be5e4:     	mov	x20, x0
1007be5e8:     	add	x1, sp, #0x410
1007be5ec:     	mov	w2, #0x120              ; =288
1007be5f0:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007be5f4:     	stur	x20, [x29, #-0xd0]
1007be5f8:     	mov	x0, x20
1007be5fc:     	bl	0x1007e68ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter19set_frame_gen_owner>
1007be600:     	ldurb	w22, [x29, #-0xb8]
1007be604:     	cmp	w22, #0xff
1007be608:     	cset	w21, eq
1007be60c:     	b.eq	0x1007be6b4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2cd4>
1007be610:     	ldur	q0, [x29, #-0xb8]
1007be614:     	str	q0, [x25]
1007be618:     	ldur	x8, [x29, #-0xa8]
1007be61c:     	str	x8, [sp, #0x420]
1007be620:     	adrp	x0, 0x102676000 <_BZ2_rNums+0x2d8>
1007be624:     	add	x0, x0, #0xba8
1007be628:     	ldr	x8, [x0]
1007be62c:     	blr	x8
1007be630:     	mov	x19, x0
1007be634:     	ldr	x1, [x0]
1007be638:     	cbz	x1, 0x1007beba0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x31c0>
1007be63c:     	ldr	x8, [x20, #0xa8]
1007be640:     	cmp	x8, x1
1007be644:     	b.ne	0x1007bebb8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x31d8>
1007be648:     	ldr	w8, [x20, #0xb0]
1007be64c:     	add	w8, w8, #0x1
1007be650:     	str	w8, [x20, #0xb0]
1007be654:     	ldr	x8, [x20, #0xa0]
1007be658:     	cbnz	x8, 0x1007bebdc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x31fc>
1007be65c:     	mov	x8, #-0x1               ; =-1
1007be660:     	str	x8, [x20, #0xa0]
1007be664:     	ldr	x8, [x19, #0x8]
1007be668:     	add	x8, x8, #0x1
1007be66c:     	str	x8, [x19, #0x8]
1007be670:     	add	x0, x20, #0xb8
1007be674:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007be678:     	ldr	q0, [x25]
1007be67c:     	stur	q0, [x20, #0xb8]
1007be680:     	ldr	x8, [sp, #0x420]
1007be684:     	stur	x8, [x20, #0xc8]
1007be688:     	str	xzr, [x20, #0xa0]
1007be68c:     	ldr	w8, [x20, #0xb0]
1007be690:     	subs	w8, w8, #0x1
1007be694:     	str	w8, [x20, #0xb0]
1007be698:     	b.ne	0x1007be6a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2cc0>
1007be69c:     	stlur	xzr, [x20, #0xa8]
1007be6a0:     	ldr	x8, [x19, #0x8]
1007be6a4:     	cmp	x8, #0x0
1007be6a8:     	cset	w9, ne
1007be6ac:     	sub	x8, x8, x9
1007be6b0:     	str	x8, [x19, #0x8]
1007be6b4:     	ldr	x8, [sp, #0x168]
1007be6b8:     	ldrb	w9, [x8, #0x1e4]
1007be6bc:     	tbz	w9, #0x0, 0x1007be6c8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2ce8>
1007be6c0:     	mov	w8, #0x18               ; =24
1007be6c4:     	b	0x1007be6dc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2cfc>
1007be6c8:     	ldrb	w8, [x8, #0x1e5]
1007be6cc:     	mov	w9, #0x17               ; =23
1007be6d0:     	mov	w10, #0x19              ; =25
1007be6d4:     	cmp	w8, #0x0
1007be6d8:     	csel	w8, w10, w9, ne
1007be6dc:     	str	x20, [sp, #0x308]
1007be6e0:     	strb	w8, [sp, #0x300]
1007be6e4:     	add	x0, sp, #0x410
1007be6e8:     	add	x1, sp, #0x300
1007be6ec:     	bl	0x100cd53fc <__RNvXsW_NtCshqYhlee0Vj9_10weavepy_vm6objectNtB5_6ObjectNtNtCs8Mbv00yxnRz_4core5clone5Clone5clone>
1007be6f0:     	add	x0, sp, #0x410
1007be6f4:     	bl	0x1009b2820 <__RNvNtCshqYhlee0Vj9_10weavepy_vm8gc_trace5track>
1007be6f8:     	adrp	x8, 0x102670000 <__RNvNtCshqYhlee0Vj9_10weavepy_vm14descr_registry6TAGGED+0x28>
1007be6fc:     	add	x8, x8, #0x840
1007be700:     	ldapr	x8, [x8]
1007be704:     	cbnz	x8, 0x1007beacc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x30ec>
1007be708:     	adrp	x0, 0x102670000 <__RNvNtCshqYhlee0Vj9_10weavepy_vm14descr_registry6TAGGED+0x28>
1007be70c:     	add	x0, x0, #0x560
1007be710:     	bl	0x10084bb8c <__RNvMs2_NtCshqYhlee0Vj9_10weavepy_vm8gc_traceNtB5_7GcState18maybe_auto_collect>
1007be714:     	cbz	w0, 0x1007be724 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2d44>
1007be718:     	bl	0x1009b2400 <__RNvNtCshqYhlee0Vj9_10weavepy_vm8gc_trace26sweep_weakref_only_targets>
1007be71c:     	ldr	x0, [sp, #0xb8]
1007be720:     	bl	0x1007fffbc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter22run_pending_finalizers>
1007be724:     	add	x8, sp, #0x300
1007be728:     	ldr	q0, [x8]
1007be72c:     	ldr	x9, [sp, #0x48]
1007be730:     	stur	q0, [x9, #0x8]
1007be734:     	ldr	x8, [sp, #0x310]
1007be738:     	str	x8, [x9, #0x18]
1007be73c:     	mov	x8, #-0x2               ; =-2
1007be740:     	str	x8, [x9]
1007be744:     	cmp	w22, #0xff
1007be748:     	b.ne	0x1007be760 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2d80>
1007be74c:     	ldurb	w8, [x29, #-0xb8]
1007be750:     	cmp	w8, #0xff
1007be754:     	b.eq	0x1007be760 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2d80>
1007be758:     	sub	x0, x29, #0xb8
1007be75c:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007be760:     	ldr	x8, [sp, #0x5d0]
1007be764:     	cmp	x8, #0x1
1007be768:     	b.hi	0x1007be778 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2d98>
1007be76c:     	add	x8, sp, #0x5d0
1007be770:     	orr	x0, x8, #0x8
1007be774:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007be778:     	cmp	x26, #0x2
1007be77c:     	b.eq	0x1007be788 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2da8>
1007be780:     	add	x0, sp, #0x200
1007be784:     	bl	0x1006021b4 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtCshqYhlee0Vj9_10weavepy_vm5FrameEBD_>
1007be788:     	ldr	x8, [sp, #0x168]
1007be78c:     	mov	x9, #-0x1               ; =-1
1007be790:     	ldaddl	x9, x8, [x8]
1007be794:     	cmp	x8, #0x1
1007be798:     	b.ne	0x1007be7a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2dc8>
1007be79c:     	dmb	ishld
1007be7a0:     	add	x0, sp, #0x168
1007be7a4:     	bl	0x100501eb8 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcNtCsdQKgh9VQBAd_16weavepy_compiler10CodeObjectE9drop_slowBI_>
1007be7a8:     	tbz	w28, #0x0, 0x1007be800 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e20>
1007be7ac:     	ldr	x8, [sp, #0xb0]
1007be7b0:     	ldp	x20, x8, [x8, #0x8]
1007be7b4:     	add	x21, x8, #0x1
1007be7b8:     	mov	x22, x20
1007be7bc:     	b	0x1007be7d0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2df0>
1007be7c0:     	add	x19, x22, #0x30
1007be7c4:     	add	x0, x22, #0x18
1007be7c8:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007be7cc:     	mov	x22, x19
1007be7d0:     	subs	x21, x21, #0x1
1007be7d4:     	b.eq	0x1007be7ec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e0c>
1007be7d8:     	ldr	x8, [x22]
1007be7dc:     	cbz	x8, 0x1007be7c0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2de0>
1007be7e0:     	ldr	x0, [x22, #0x8]
1007be7e4:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007be7e8:     	b	0x1007be7c0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2de0>
1007be7ec:     	ldr	x8, [sp, #0xb0]
1007be7f0:     	ldr	x8, [x8]
1007be7f4:     	cbz	x8, 0x1007be800 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e20>
1007be7f8:     	mov	x0, x20
1007be7fc:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007be800:     	add	sp, sp, #0x700
1007be804:     	ldp	x29, x30, [sp, #0x50]
1007be808:     	ldp	x20, x19, [sp, #0x40]
1007be80c:     	ldp	x22, x21, [sp, #0x30]
1007be810:     	ldp	x24, x23, [sp, #0x20]
1007be814:     	ldp	x26, x25, [sp, #0x10]
1007be818:     	ldp	x28, x27, [sp], #0x60
1007be81c:     	ret
1007be820:     	ldr	x9, [sp, #0x168]
1007be824:     	add	x8, sp, #0x5d0
1007be828:     	add	x0, x9, #0x28
1007be82c:     	bl	0x1000066c0 <__RNvXs4_NtCshxvaOLs88l5_5alloc6stringNtB5_6StringNtNtCs8Mbv00yxnRz_4core5clone5Clone5clone>
1007be830:     	ldrb	w8, [sp, #0x300]
1007be834:     	cmp	w8, #0xff
1007be838:     	b.eq	0x1007be844 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2e64>
1007be83c:     	add	x0, sp, #0x300
1007be840:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007be844:     	ldr	x19, [sp, #0x5d8]
1007be848:     	ldr	x2, [sp, #0x5e0]
1007be84c:     	adrp	x3, 0x10120e000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4365+0x17c5>
1007be850:     	add	x3, x3, #0xc1c
1007be854:     	add	x0, sp, #0x300
1007be858:     	mov	x1, x19
1007be85c:     	mov	w4, #0xc                ; =12
1007be860:     	mov	x5, x20
1007be864:     	mov	x6, x22
1007be868:     	bl	0x1006e2788 <__RNvCshqYhlee0Vj9_10weavepy_vm24format_missing_arguments>
1007be86c:     	add	x0, sp, #0x410
1007be870:     	add	x1, sp, #0x300
1007be874:     	bl	0x100616cac <__RINvNtCshqYhlee0Vj9_10weavepy_vm5error10type_errorNtNtCshxvaOLs88l5_5alloc6string6StringEB4_>
1007be878:     	ldur	q0, [x25, #0x8]
1007be87c:     	str	q0, [sp, #0x1e0]
1007be880:     	ldr	x21, [sp, #0x410]
1007be884:     	ldr	x8, [sp, #0x428]
1007be888:     	str	x8, [sp, #0x1f0]
1007be88c:     	ldp	q0, q1, [x25, #0x20]
1007be890:     	stp	q0, q1, [sp, #0x1b0]
1007be894:     	ldr	x8, [sp, #0x450]
1007be898:     	str	x8, [sp, #0x1d0]
1007be89c:     	ldr	x8, [sp, #0x5d0]
1007be8a0:     	cbnz	x8, 0x1007bdb4c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x216c>
1007be8a4:     	b	0x1007bdb54 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2174>
1007be8a8:     	ldr	x23, [sp, #0xd8]
1007be8ac:     	add	x25, sp, #0x410
1007be8b0:     	add	x21, sp, #0x640
1007be8b4:     	ldr	x22, [sp, #0x88]
1007be8b8:     	ldr	x2, [sp, #0x138]
1007be8bc:     	ldr	x8, [sp, #0x410]
1007be8c0:     	ldr	x20, [sp, #0x418]
1007be8c4:     	cmp	x8, #0x0
1007be8c8:     	cset	w19, eq
1007be8cc:     	adrp	x3, 0x1011e2000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.1285+0x2c0>
1007be8d0:     	add	x3, x3, #0x2f5
1007be8d4:     	add	x0, sp, #0x410
1007be8d8:     	mov	x1, x20
1007be8dc:     	mov	w4, #0x2                ; =2
1007be8e0:     	bl	0x10061da18 <__RINvNtCshxvaOLs88l5_5alloc3str17join_generic_copyehReECshqYhlee0Vj9_10weavepy_vm>
1007be8e4:     	ldr	x8, [sp, #0x118]
1007be8e8:     	add	x8, x8, #0x28
1007be8ec:     	ldr	q0, [x25]
1007be8f0:     	str	q0, [x21, #0x90]
1007be8f4:     	ldr	x9, [sp, #0x420]
1007be8f8:     	adrp	x10, 0x100ce6000 <__RNvXsq_NtCshxvaOLs88l5_5alloc3vecINtB5_3VechENtNtCs8Mbv00yxnRz_4core3fmt5Debug3fmtCshqYhlee0Vj9_10weavepy_vm+0x84>
1007be8fc:     	add	x10, x10, #0x17c
1007be900:     	stur	x9, [x29, #-0x70]
1007be904:     	str	x8, [sp, #0x410]
1007be908:     	str	x10, [sp, #0x418]
1007be90c:     	sub	x8, x29, #0x80
1007be910:     	str	x8, [sp, #0x420]
1007be914:     	str	x10, [sp, #0x428]
1007be918:     	adrp	x0, 0x10102f000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3362+0x248f>
1007be91c:     	add	x0, x0, #0xb4e
1007be920:     	sub	x8, x29, #0xd0
1007be924:     	add	x1, sp, #0x410
1007be928:     	bl	0x100006330 <__RNvNvNtCshxvaOLs88l5_5alloc3fmt6format12format_inner>
1007be92c:     	ldur	x8, [x29, #-0x80]
1007be930:     	cbz	x8, 0x1007be93c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2f5c>
1007be934:     	ldur	x0, [x29, #-0x78]
1007be938:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007be93c:     	add	x0, sp, #0x410
1007be940:     	sub	x1, x29, #0xd0
1007be944:     	bl	0x100616cac <__RINvNtCshqYhlee0Vj9_10weavepy_vm5error10type_errorNtNtCshxvaOLs88l5_5alloc6string6StringEB4_>
1007be948:     	ldur	q0, [x25, #0x8]
1007be94c:     	str	q0, [sp, #0x1e0]
1007be950:     	ldr	x21, [sp, #0x410]
1007be954:     	ldr	x8, [sp, #0x428]
1007be958:     	str	x8, [sp, #0x1f0]
1007be95c:     	ldp	q0, q1, [x25, #0x20]
1007be960:     	stp	q0, q1, [sp, #0x1b0]
1007be964:     	ldr	x8, [sp, #0x450]
1007be968:     	str	x8, [sp, #0x1d0]
1007be96c:     	tbnz	w19, #0x0, 0x1007bcd20 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1340>
1007be970:     	mov	x0, x20
1007be974:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007be978:     	b	0x1007bcd20 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1340>
1007be97c:     	mov	w0, #0x8                ; =8
1007be980:     	mov	w1, #0x60               ; =96
1007be984:     	bl	0x100f8a6fc <__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error>
1007be988:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007be98c:     	adrp	x0, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007be990:     	add	x0, x0, #0x9d0
1007be994:     	bl	0x100f8b46c <__RNvNtCs8Mbv00yxnRz_4core4cell22panic_already_borrowed>
1007be998:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007be99c:     	adrp	x0, 0x1011e1000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.255+0x68b>
1007be9a0:     	add	x0, x0, #0x241
1007be9a4:     	adrp	x2, 0x102621000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.300+0x53a0>
1007be9a8:     	add	x2, x2, #0xe18
1007be9ac:     	mov	w1, #0x19               ; =25
1007be9b0:     	bl	0x100f8b4cc <__RNvNtCs8Mbv00yxnRz_4core6option13expect_failed>
1007be9b4:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007be9b8:     	adrp	x0, 0x1011e1000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.255+0x68b>
1007be9bc:     	add	x0, x0, #0x241
1007be9c0:     	adrp	x2, 0x102621000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.300+0x53a0>
1007be9c4:     	add	x2, x2, #0xe18
1007be9c8:     	mov	w1, #0x19               ; =25
1007be9cc:     	bl	0x100f8b4cc <__RNvNtCs8Mbv00yxnRz_4core6option13expect_failed>
1007be9d0:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007be9d4:     	mov	w0, #0x8                ; =8
1007be9d8:     	mov	w1, #0x60               ; =96
1007be9dc:     	bl	0x100f8a6fc <__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error>
1007be9e0:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007be9e4:     	add	x0, sp, #0x300
1007be9e8:     	mov	x1, #0x0                ; =0
1007be9ec:     	mov	x2, x20
1007be9f0:     	mov	w3, #0x8                ; =8
1007be9f4:     	mov	w4, #0x18               ; =24
1007be9f8:     	bl	0x100fd8830 <__RINvNvMs2_NtCshxvaOLs88l5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECshqYhlee0Vj9_10weavepy_vm>
1007be9fc:     	ldr	x21, [sp, #0x310]
1007bea00:     	ldr	x8, [sp, #0x308]
1007bea04:     	mov	w9, #0x18               ; =24
1007bea08:     	madd	x0, x21, x9, x8
1007bea0c:     	mov	x1, x19
1007bea10:     	mov	x2, x22
1007bea14:     	bl	0x1010102d0 <dyld_stub_binder+0x1010102d0>
1007bea18:     	ldr	x9, [sp, #0x28]
1007bea1c:     	add	x8, x21, x20
1007bea20:     	str	x8, [sp, #0x310]
1007bea24:     	cbnz	x9, 0x1007bbc98 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2b8>
1007bea28:     	b	0x1007bbca0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2c0>
1007bea2c:     	bl	0x1010105d0 <dyld_stub_binder+0x1010105d0>
1007bea30:     	mov	x1, x0
1007bea34:     	str	x0, [x24]
1007bea38:     	ldr	x8, [x23, #0x18]
1007bea3c:     	cmp	x8, x0
1007bea40:     	b.eq	0x1007bdef4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2514>
1007bea44:     	mov	x8, #0x0                ; =0
1007bea48:     	add	x9, x23, #0x18
1007bea4c:     	casa	x8, x1, [x9]
1007bea50:     	cmp	x8, #0x0
1007bea54:     	b.ne	0x1007beb84 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x31a4>
1007bea58:     	mov	w8, #0x1                ; =1
1007bea5c:     	str	w8, [x23, #0x20]
1007bea60:     	ldr	x8, [x23, #0x10]
1007bea64:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1007bea68:     	cmp	x8, x9
1007bea6c:     	b.lo	0x1007bdf10 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2530>
1007bea70:     	ldr	w8, [x23, #0x20]
1007bea74:     	subs	w8, w8, #0x1
1007bea78:     	str	w8, [x23, #0x20]
1007bea7c:     	b.ne	0x1007bea84 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x30a4>
1007bea80:     	stlur	xzr, [x23, #0x18]
1007bea84:     	adrp	x0, 0x1011e0000 <_anon.62c35deff83376c58a4fa8d541d7c1d3.553+0x6342>
1007bea88:     	add	x0, x0, #0x975
1007bea8c:     	adrp	x3, 0x102627000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3425+0x800>
1007bea90:     	add	x3, x3, #0xec8
1007bea94:     	adrp	x4, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bea98:     	add	x4, x4, #0xde8
1007bea9c:     	sub	x2, x29, #0x61
1007beaa0:     	mov	w1, #0x29               ; =41
1007beaa4:     	bl	0x100f8b518 <__RNvNtCs8Mbv00yxnRz_4core6result13unwrap_failed>
1007beaa8:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beaac:     	mov	w0, #0x8                ; =8
1007beab0:     	mov	w1, #0xe0               ; =224
1007beab4:     	bl	0x100f8a6fc <__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error>
1007beab8:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beabc:     	mov	w0, #0x8                ; =8
1007beac0:     	mov	w1, #0x120              ; =288
1007beac4:     	bl	0x100f8a6fc <__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error>
1007beac8:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beacc:     	adrp	x8, 0x102670000 <__RNvNtCshqYhlee0Vj9_10weavepy_vm14descr_registry6TAGGED+0x28>
1007bead0:     	add	x8, x8, #0x560
1007bead4:     	str	x8, [sp, #0x570]
1007bead8:     	add	x9, sp, #0x570
1007beadc:     	str	x9, [sp, #0x410]
1007beae0:     	adrp	x3, 0x10261b000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.167+0x140>
1007beae4:     	add	x3, x3, #0x3e8
1007beae8:     	adrp	x4, 0x102619000 <_anon.62c35deff83376c58a4fa8d541d7c1d3.2+0x1c8>
1007beaec:     	add	x4, x4, #0xb20
1007beaf0:     	add	x0, x8, #0x2e0
1007beaf4:     	add	x2, sp, #0x410
1007beaf8:     	mov	w1, #0x1                ; =1
1007beafc:     	bl	0x100fb1aa8 <__RNvMNtNtNtNtCs82bWklYMk3w_3std3sys4sync4once5queueNtB2_4Once4call>
1007beb00:     	b	0x1007be708 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2d28>
1007beb04:     	bl	0x1010105d0 <dyld_stub_binder+0x1010105d0>
1007beb08:     	mov	x1, x0
1007beb0c:     	str	x0, [x22]
1007beb10:     	ldr	x8, [x19, #0x18]
1007beb14:     	cmp	x8, x0
1007beb18:     	b.eq	0x1007bd22c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x184c>
1007beb1c:     	mov	x8, #0x0                ; =0
1007beb20:     	add	x9, x19, #0x18
1007beb24:     	casa	x8, x1, [x9]
1007beb28:     	cmp	x8, #0x0
1007beb2c:     	b.ne	0x1007bec68 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3288>
1007beb30:     	mov	w8, #0x1                ; =1
1007beb34:     	str	w8, [x19, #0x20]
1007beb38:     	ldr	x8, [x19, #0x10]
1007beb3c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1007beb40:     	cmp	x8, x9
1007beb44:     	b.lo	0x1007bd248 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1868>
1007beb48:     	ldr	w8, [x19, #0x20]
1007beb4c:     	subs	w8, w8, #0x1
1007beb50:     	str	w8, [x19, #0x20]
1007beb54:     	b.ne	0x1007beb5c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x317c>
1007beb58:     	stlur	xzr, [x19, #0x18]
1007beb5c:     	adrp	x0, 0x1011e0000 <_anon.62c35deff83376c58a4fa8d541d7c1d3.553+0x6342>
1007beb60:     	add	x0, x0, #0x975
1007beb64:     	adrp	x3, 0x102627000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3425+0x800>
1007beb68:     	add	x3, x3, #0xec8
1007beb6c:     	adrp	x4, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007beb70:     	add	x4, x4, #0x928
1007beb74:     	sub	x2, x29, #0x61
1007beb78:     	mov	w1, #0x29               ; =41
1007beb7c:     	bl	0x100f8b518 <__RNvNtCs8Mbv00yxnRz_4core6result13unwrap_failed>
1007beb80:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beb84:     	add	x0, x23, #0x10
1007beb88:     	bl	0x100fdaa6c <__RNvMsf_NtCshqYhlee0Vj9_10weavepy_vm4syncINtB5_7GilCellNtNtB7_6object6ObjectE14lock_contendedB7_>
1007beb8c:     	ldr	x8, [x23, #0x10]
1007beb90:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1007beb94:     	cmp	x8, x9
1007beb98:     	b.lo	0x1007bdf10 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2530>
1007beb9c:     	b	0x1007bea70 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3090>
1007beba0:     	bl	0x1010105d0 <dyld_stub_binder+0x1010105d0>
1007beba4:     	mov	x1, x0
1007beba8:     	str	x0, [x19]
1007bebac:     	ldr	x8, [x20, #0xa8]
1007bebb0:     	cmp	x8, x0
1007bebb4:     	b.eq	0x1007be648 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2c68>
1007bebb8:     	mov	x8, #0x0                ; =0
1007bebbc:     	add	x9, x20, #0xa8
1007bebc0:     	casa	x8, x1, [x9]
1007bebc4:     	cmp	x8, #0x0
1007bebc8:     	b.ne	0x1007becb0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x32d0>
1007bebcc:     	mov	w8, #0x1                ; =1
1007bebd0:     	str	w8, [x20, #0xb0]
1007bebd4:     	ldr	x8, [x20, #0xa0]
1007bebd8:     	cbz	x8, 0x1007be65c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2c7c>
1007bebdc:     	ldr	w8, [x20, #0xb0]
1007bebe0:     	subs	w8, w8, #0x1
1007bebe4:     	str	w8, [x20, #0xb0]
1007bebe8:     	b.ne	0x1007bebf0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3210>
1007bebec:     	stlur	xzr, [x20, #0xa8]
1007bebf0:     	adrp	x0, 0x1011e0000 <_anon.62c35deff83376c58a4fa8d541d7c1d3.553+0x6342>
1007bebf4:     	add	x0, x0, #0x948
1007bebf8:     	adrp	x3, 0x102627000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.3425+0x800>
1007bebfc:     	add	x3, x3, #0xee8
1007bec00:     	adrp	x4, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bec04:     	add	x4, x4, #0xe00
1007bec08:     	sub	x2, x29, #0x61
1007bec0c:     	mov	w1, #0x2d               ; =45
1007bec10:     	bl	0x100f8b518 <__RNvNtCs8Mbv00yxnRz_4core6result13unwrap_failed>
1007bec14:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bec18:     	ldr	x8, [sp, #0x20]
1007bec1c:     	add	x8, x8, x22
1007bec20:     	add	x8, x8, #0x18
1007bec24:     	str	x8, [sp, #0x578]
1007bec28:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bec2c:     	add	x2, x2, #0xa00
1007bec30:     	mov	x0, x19
1007bec34:     	mov	x1, x19
1007bec38:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bec3c:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bec40:     	ldr	x8, [sp, #0x20]
1007bec44:     	add	x8, x8, x22
1007bec48:     	add	x8, x8, #0x18
1007bec4c:     	str	x8, [sp, #0x578]
1007bec50:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bec54:     	add	x2, x2, #0xa18
1007bec58:     	ldr	x0, [sp, #0xd8]
1007bec5c:     	mov	x1, x0
1007bec60:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bec64:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bec68:     	add	x0, x19, #0x10
1007bec6c:     	bl	0x100fdaa6c <__RNvMsf_NtCshqYhlee0Vj9_10weavepy_vm4syncINtB5_7GilCellNtNtB7_6object6ObjectE14lock_contendedB7_>
1007bec70:     	ldr	x8, [x19, #0x10]
1007bec74:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1007bec78:     	cmp	x8, x9
1007bec7c:     	b.lo	0x1007bd248 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x1868>
1007bec80:     	b	0x1007beb48 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3168>
1007bec84:     	mov	x19, x28
1007bec88:     	mov	x1, #0x0                ; =0
1007bec8c:     	bl	0x100fc9a58 <__RINvMs0_NtNtNtNtCs82bWklYMk3w_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCshxvaOLs88l5_5alloc4sync3ArcNtNtCshqYhlee0Vj9_10weavepy_vm13tuple_storage12TupleStorageEuE16get_or_init_slowNvNvNvMsV_NtB1Q_6objectNtB3e_6Object9new_tuple11EMPTY_TUPLE27___rust_std_internal_init_fnEB1Q_>
1007bec90:     	add	x25, sp, #0x410
1007bec94:     	add	x27, sp, #0x200
1007bec98:     	mov	x28, x19
1007bec9c:     	cbnz	x0, 0x1007be22c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x284c>
1007beca0:     	adrp	x0, 0x10261b000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.167+0x140>
1007beca4:     	add	x0, x0, #0x510
1007beca8:     	bl	0x100fb2900 <__RNvNtNtCs82bWklYMk3w_3std6thread5local18panic_access_error>
1007becac:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007becb0:     	add	x0, x20, #0xa0
1007becb4:     	bl	0x100fdaa6c <__RNvMsf_NtCshqYhlee0Vj9_10weavepy_vm4syncINtB5_7GilCellNtNtB7_6object6ObjectE14lock_contendedB7_>
1007becb8:     	ldr	x8, [x20, #0xa0]
1007becbc:     	cbz	x8, 0x1007be65c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2c7c>
1007becc0:     	b	0x1007bebdc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x31fc>
1007becc4:     	mov	w0, #0x1                ; =1
1007becc8:     	mov	x1, x19
1007beccc:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007becd0:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007becd4:     	adrp	x0, 0x101047000 <dyld_stub_binder+0x101047000>
1007becd8:     	add	x0, x0, #0x70
1007becdc:     	adrp	x3, 0x1025c8000 <dyld_stub_binder+0x1025c8000>
1007bece0:     	add	x3, x3, #0x140
1007bece4:     	adrp	x4, 0x1025c8000 <dyld_stub_binder+0x1025c8000>
1007bece8:     	add	x4, x4, #0x1c8
1007becec:     	sub	x2, x29, #0x61
1007becf0:     	mov	w1, #0x2b               ; =43
1007becf4:     	bl	0x100f8b518 <__RNvNtCs8Mbv00yxnRz_4core6result13unwrap_failed>
1007becf8:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007becfc:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bed00:     	add	x2, x2, #0x9a0
1007bed04:     	mov	x0, x19
1007bed08:     	ldr	x1, [sp, #0xd8]
1007bed0c:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bed10:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bed14:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bed18:     	add	x2, x2, #0x9b8
1007bed1c:     	mov	x0, x19
1007bed20:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bed24:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bed28:     	adrp	x0, 0x101047000 <dyld_stub_binder+0x101047000>
1007bed2c:     	add	x0, x0, #0x70
1007bed30:     	adrp	x3, 0x1025c8000 <dyld_stub_binder+0x1025c8000>
1007bed34:     	add	x3, x3, #0x140
1007bed38:     	adrp	x4, 0x1025c8000 <dyld_stub_binder+0x1025c8000>
1007bed3c:     	add	x4, x4, #0x1c8
1007bed40:     	sub	x2, x29, #0x61
1007bed44:     	mov	w1, #0x2b               ; =43
1007bed48:     	bl	0x100f8b518 <__RNvNtCs8Mbv00yxnRz_4core6result13unwrap_failed>
1007bed4c:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bed50:     	mov	w0, #0x1                ; =1
1007bed54:     	mov	x1, x20
1007bed58:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bed5c:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bed60:     	adrp	x0, 0x101047000 <dyld_stub_binder+0x101047000>
1007bed64:     	add	x0, x0, #0x70
1007bed68:     	adrp	x3, 0x1025c8000 <dyld_stub_binder+0x1025c8000>
1007bed6c:     	add	x3, x3, #0x140
1007bed70:     	adrp	x4, 0x1025c8000 <dyld_stub_binder+0x1025c8000>
1007bed74:     	add	x4, x4, #0x1c8
1007bed78:     	sub	x2, x29, #0x61
1007bed7c:     	mov	w1, #0x2b               ; =43
1007bed80:     	bl	0x100f8b518 <__RNvNtCs8Mbv00yxnRz_4core6result13unwrap_failed>
1007bed84:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bed88:     	mov	w0, #0x1                ; =1
1007bed8c:     	mov	x1, x19
1007bed90:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bed94:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bed98:     	mov	w0, #0x1                ; =1
1007bed9c:     	ldr	x1, [sp, #0xd8]
1007beda0:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007beda4:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beda8:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bedac:     	add	x2, x2, #0x8c8
1007bedb0:     	mov	x0, x26
1007bedb4:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bedb8:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bedbc:     	mov	w28, #0x1               ; =1
1007bedc0:     	mov	x8, #-0x1               ; =-1
1007bedc4:     	str	x8, [sp, #0xa0]
1007bedc8:     	str	wzr, [sp, #0x64]
1007bedcc:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bedd0:     	add	x2, x2, #0x8e0
1007bedd4:     	mov	w19, #0x1               ; =1
1007bedd8:     	mov	w22, #0x1               ; =1
1007beddc:     	mov	x0, x26
1007bede0:     	mov	x1, x20
1007bede4:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bede8:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bedec:     	mov	w0, #0x8                ; =8
1007bedf0:     	mov	x1, x19
1007bedf4:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bedf8:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bedfc:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bee00:     	add	x2, x2, #0x970
1007bee04:     	mov	x0, x22
1007bee08:     	ldr	x1, [sp, #0xd8]
1007bee0c:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bee10:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bee14:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bee18:     	add	x2, x2, #0x940
1007bee1c:     	mov	x0, x22
1007bee20:     	ldr	x1, [sp, #0xd8]
1007bee24:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bee28:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bee2c:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bee30:     	add	x2, x2, #0x988
1007bee34:     	mov	x0, x22
1007bee38:     	mov	x1, x19
1007bee3c:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bee40:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bee44:     	mov	w0, #0x8                ; =8
1007bee48:     	mov	x1, x21
1007bee4c:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bee50:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bee54:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bee58:     	add	x2, x2, #0x958
1007bee5c:     	mov	x0, x22
1007bee60:     	ldr	x1, [sp, #0x140]
1007bee64:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bee68:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bee6c:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bee70:     	add	x2, x2, #0x8f8
1007bee74:     	mov	x0, x10
1007bee78:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bee7c:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bee80:     	str	wzr, [sp, #0x158]
1007bee84:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bee88:     	add	x2, x2, #0x910
1007bee8c:     	mov	x1, x23
1007bee90:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bee94:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bee98:     	adrp	x2, 0x102622000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.300+0x63a0>
1007bee9c:     	add	x2, x2, #0xa10
1007beea0:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007beea4:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beea8:     	mov	w0, #0x8                ; =8
1007beeac:     	mov	w1, #0x40               ; =64
1007beeb0:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007beeb4:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beeb8:     	mov	w0, #0x1                ; =1
1007beebc:     	mov	x1, x19
1007beec0:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007beec4:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beec8:     	adrp	x2, 0x102622000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.300+0x63a0>
1007beecc:     	add	x2, x2, #0xa10
1007beed0:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007beed4:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beed8:     	mov	w0, #0x8                ; =8
1007beedc:     	mov	w1, #0xc0               ; =192
1007beee0:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007beee4:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007beee8:     	mov	w0, #0x8                ; =8
1007beeec:     	mov	x1, x22
1007beef0:     	b	0x1007bdf58 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x2578>
1007beef4:     	adrp	x2, 0x102622000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.300+0x63a0>
1007beef8:     	add	x2, x2, #0xa28
1007beefc:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bef00:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bef04:     	mov	w0, #0x8                ; =8
1007bef08:     	mov	w1, #0x40               ; =64
1007bef0c:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bef10:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bef14:     	mov	w0, #0x1                ; =1
1007bef18:     	mov	x1, x26
1007bef1c:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bef20:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bef24:     	mov	w0, #0x1                ; =1
1007bef28:     	mov	x1, x19
1007bef2c:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bef30:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bef34:     	mov	w0, #0x8                ; =8
1007bef38:     	mov	x1, x19
1007bef3c:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bef40:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bef44:     	ldr	x8, [sp, #0x20]
1007bef48:     	add	x8, x8, x22
1007bef4c:     	add	x8, x8, #0x18
1007bef50:     	str	x8, [sp, #0x150]
1007bef54:     	ldr	x8, [sp, #0x150]
1007bef58:     	str	x8, [sp, #0x578]
1007bef5c:     	adrp	x0, 0x10120e000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4365+0x17c5>
1007bef60:     	add	x0, x0, #0xc32
1007bef64:     	adrp	x2, 0x10262c000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.4936+0x1c20>
1007bef68:     	add	x2, x2, #0x9e8
1007bef6c:     	mov	w1, #0x13               ; =19
1007bef70:     	bl	0x100f8b4cc <__RNvNtCs8Mbv00yxnRz_4core6option13expect_failed>
1007bef74:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bef78:     	add	x8, x24, x27
1007bef7c:     	sub	x0, x8, #0x1
1007bef80:     	adrp	x2, 0x102622000 <_anon.4a648d71e3f4ceef3490e5ee9c9cf32f.300+0x63a0>
1007bef84:     	add	x2, x2, #0xa28
1007bef88:     	bl	0x100f8b598 <__RNvNtCs8Mbv00yxnRz_4core9panicking18panic_bounds_check>
1007bef8c:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007bef90:     	mov	w0, #0x8                ; =8
1007bef94:     	mov	w1, #0x40               ; =64
1007bef98:     	bl	0x100f8a714 <__RNvNtCshxvaOLs88l5_5alloc7raw_vec12handle_error>
1007bef9c:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007befa0:     	and	x1, x20, #0x7ffffffffffffff8
1007befa4:     	mov	w0, #0x8                ; =8
1007befa8:     	bl	0x100f8a6fc <__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error>
1007befac:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007befb0:     	and	x1, x25, #0x7ffffffffffffff8
1007befb4:     	mov	w0, #0x8                ; =8
1007befb8:     	bl	0x100f8a6fc <__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error>
1007befbc:     	b	0x1007befcc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x35ec>
1007befc0:     	and	x1, x25, #0x7ffffffffffffff8
1007befc4:     	mov	w0, #0x8                ; =8
1007befc8:     	bl	0x100f8a6fc <__RNvNtCshxvaOLs88l5_5alloc5alloc18handle_alloc_error>
1007befcc:     	brk	#0x1
1007befd0:     	mov	x21, x0
1007befd4:     	add	x0, sp, #0x2e0
1007befd8:     	bl	0x1005f6ba8 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1c_>
1007befdc:     	mov	x28, x19
1007befe0:     	b	0x1007bf0f4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3714>
1007befe4:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007befe8:     	str	x0, [sp, #0x160]
1007befec:     	add	x0, sp, #0x410
1007beff0:     	bl	0x1005fc92c <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtNtCshxvaOLs88l5_5alloc3vec9into_iter8IntoIterNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1t_>
1007beff4:     	add	x0, sp, #0x300
1007beff8:     	bl	0x1005f6ba8 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1c_>
1007beffc:     	ldr	x8, [sp, #0xd8]
1007bf000:     	cmp	x8, #0x11
1007bf004:     	b.lo	0x1007bf010 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3630>
1007bf008:     	ldr	x0, [sp, #0x10]
1007bf00c:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf010:     	mov	w21, #0x0               ; =0
1007bf014:     	mov	w22, #0x1               ; =1
1007bf018:     	b	0x1007bfae4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4104>
1007bf01c:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf020:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf024:     	str	x0, [sp, #0x160]
1007bf028:     	ldr	x8, [sp, #0x410]
1007bf02c:     	cbz	x8, 0x1007bf91c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f3c>
1007bf030:     	ldr	x0, [sp, #0x418]
1007bf034:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf038:     	b	0x1007bf91c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f3c>
1007bf03c:     	mov	x21, x0
1007bf040:     	ldr	w28, [sp, #0x158]
1007bf044:     	cbnz	x19, 0x1007bf45c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3a7c>
1007bf048:     	b	0x1007bfa4c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x406c>
1007bf04c:     	mov	x21, x0
1007bf050:     	ldr	w28, [sp, #0x158]
1007bf054:     	cbnz	x20, 0x1007bf474 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3a94>
1007bf058:     	b	0x1007bfbec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x420c>
1007bf05c:     	b	0x1007bf228 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3848>
1007bf060:     	b	0x1007bf228 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3848>
1007bf064:     	str	x0, [sp, #0x160]
1007bf068:     	b	0x1007bf4e0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b00>
1007bf06c:     	str	x0, [sp, #0x160]
1007bf070:     	mov	x8, #-0x1               ; =-1
1007bf074:     	ldaddl	x8, x8, [x22]
1007bf078:     	cmp	x8, #0x1
1007bf07c:     	b.ne	0x1007bf4e0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b00>
1007bf080:     	dmb	ishld
1007bf084:     	sub	x0, x29, #0x80
1007bf088:     	bl	0x1008b1b7c <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcNtNtCshqYhlee0Vj9_10weavepy_vm13tuple_storage12TupleStorageE9drop_slowBK_>
1007bf08c:     	b	0x1007bf4e0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b00>
1007bf090:     	str	x0, [sp, #0x160]
1007bf094:     	ldur	x8, [x29, #-0x80]
1007bf098:     	cbz	x8, 0x1007bf118 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3738>
1007bf09c:     	ldur	x0, [x29, #-0x78]
1007bf0a0:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf0a4:     	b	0x1007bf118 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3738>
1007bf0a8:     	mov	x23, x21
1007bf0ac:     	mov	x21, x0
1007bf0b0:     	ldr	x8, [sp, #0x2e0]
1007bf0b4:     	cbz	x8, 0x1007bfc10 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4230>
1007bf0b8:     	mov	x0, x22
1007bf0bc:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf0c0:     	b	0x1007bfc10 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4230>
1007bf0c4:     	str	x0, [sp, #0x160]
1007bf0c8:     	ldrb	w8, [sp, #0x300]
1007bf0cc:     	cmp	w8, #0xff
1007bf0d0:     	b.eq	0x1007bf2a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38c8>
1007bf0d4:     	add	x0, sp, #0x300
1007bf0d8:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf0dc:     	b	0x1007bf2a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38c8>
1007bf0e0:     	str	x0, [sp, #0x160]
1007bf0e4:     	b	0x1007bf2a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38c8>
1007bf0e8:     	str	x0, [sp, #0x160]
1007bf0ec:     	b	0x1007bf698 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3cb8>
1007bf0f0:     	mov	x21, x0
1007bf0f4:     	ldr	x23, [sp, #0x150]
1007bf0f8:     	ldr	x24, [sp, #0x140]
1007bf0fc:     	b	0x1007bfc10 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4230>
1007bf100:     	str	x0, [sp, #0x160]
1007bf104:     	add	x0, sp, #0x410
1007bf108:     	bl	0x100613b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueTNtNtCshxvaOLs88l5_5alloc6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1i_>
1007bf10c:     	b	0x1007bf538 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b58>
1007bf110:     	b	0x1007bf228 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3848>
1007bf114:     	str	x0, [sp, #0x160]
1007bf118:     	tbnz	w19, #0x0, 0x1007bf91c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f3c>
1007bf11c:     	mov	x0, x20
1007bf120:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf124:     	b	0x1007bf91c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f3c>
1007bf128:     	str	x0, [sp, #0x160]
1007bf12c:     	ldr	q0, [x25]
1007bf130:     	stur	q0, [x20, #0xb8]
1007bf134:     	ldr	x8, [sp, #0x420]
1007bf138:     	stur	x8, [x20, #0xc8]
1007bf13c:     	str	xzr, [x20, #0xa0]
1007bf140:     	ldr	w8, [x20, #0xb0]
1007bf144:     	subs	w8, w8, #0x1
1007bf148:     	str	w8, [x20, #0xb0]
1007bf14c:     	b.ne	0x1007bf154 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3774>
1007bf150:     	stlur	xzr, [x20, #0xa8]
1007bf154:     	mov	w21, #0x0               ; =0
1007bf158:     	ldr	x8, [x19, #0x8]
1007bf15c:     	cmp	x8, #0x0
1007bf160:     	cset	w9, ne
1007bf164:     	sub	x8, x8, x9
1007bf168:     	str	x8, [x19, #0x8]
1007bf16c:     	b	0x1007bf1cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x37ec>
1007bf170:     	str	x0, [sp, #0x160]
1007bf174:     	add	x0, sp, #0x410
1007bf178:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf17c:     	mov	w21, #0x0               ; =0
1007bf180:     	b	0x1007bf1cc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x37ec>
1007bf184:     	str	x0, [sp, #0x160]
1007bf188:     	b	0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf18c:     	b	0x1007bf190 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x37b0>
1007bf190:     	str	x0, [sp, #0x160]
1007bf194:     	b	0x1007bf5e0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3c00>
1007bf198:     	str	x0, [sp, #0x160]
1007bf19c:     	ldr	x8, [sp, #0x5d0]
1007bf1a0:     	cbz	x8, 0x1007bf2a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38c8>
1007bf1a4:     	ldr	x0, [sp, #0x5d8]
1007bf1a8:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf1ac:     	cbnz	x23, 0x1007bf2ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38cc>
1007bf1b0:     	b	0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf1b4:     	str	x0, [sp, #0x160]
1007bf1b8:     	b	0x1007bf538 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b58>
1007bf1bc:     	str	x0, [sp, #0x160]
1007bf1c0:     	b	0x1007bf56c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b8c>
1007bf1c4:     	str	x0, [sp, #0x160]
1007bf1c8:     	mov	w21, #0x1               ; =1
1007bf1cc:     	mov	x8, #-0x1               ; =-1
1007bf1d0:     	ldaddl	x8, x8, [x20]
1007bf1d4:     	cmp	x8, #0x1
1007bf1d8:     	b.ne	0x1007bf2c4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38e4>
1007bf1dc:     	dmb	ishld
1007bf1e0:     	sub	x0, x29, #0xd0
1007bf1e4:     	bl	0x1008b2380 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcNtNtCshqYhlee0Vj9_10weavepy_vm6object11PyGeneratorE9drop_slowBK_>
1007bf1e8:     	b	0x1007bf2c4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38e4>
1007bf1ec:     	str	x0, [sp, #0x160]
1007bf1f0:     	cmp	x26, #0x2
1007bf1f4:     	b.ne	0x1007bfc48 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4268>
1007bf1f8:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bf1fc:     	str	x0, [sp, #0x160]
1007bf200:     	b	0x1007bf9a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3fc0>
1007bf204:     	str	x0, [sp, #0x160]
1007bf208:     	b	0x1007bf9c0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3fe0>
1007bf20c:     	str	x0, [sp, #0x160]
1007bf210:     	ldrb	w8, [sp, #0x300]
1007bf214:     	cmp	w8, #0xff
1007bf218:     	b.eq	0x1007bf2a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38c8>
1007bf21c:     	add	x0, sp, #0x300
1007bf220:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf224:     	b	0x1007bf2a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38c8>
1007bf228:     	str	x0, [sp, #0x160]
1007bf22c:     	ldr	x8, [sp, #0x410]
1007bf230:     	cbz	x8, 0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf234:     	ldr	x0, [sp, #0x418]
1007bf238:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf23c:     	b	0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf240:     	str	x0, [sp, #0x160]
1007bf244:     	ldur	x8, [x29, #-0xa0]
1007bf248:     	cbz	x8, 0x1007bf290 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38b0>
1007bf24c:     	ldur	x0, [x29, #-0x98]
1007bf250:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf254:     	b	0x1007bf290 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38b0>
1007bf258:     	str	x0, [sp, #0x160]
1007bf25c:     	b	0x1007bf2a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38c8>
1007bf260:     	str	x0, [sp, #0x160]
1007bf264:     	str	wzr, [sp, #0x158]
1007bf268:     	ldr	q0, [x25]
1007bf26c:     	ldr	x8, [sp, #0x420]
1007bf270:     	str	x8, [x19, #0x10]
1007bf274:     	str	q0, [x19]
1007bf278:     	b	0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf27c:     	str	x0, [sp, #0x160]
1007bf280:     	add	x0, sp, #0x410
1007bf284:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf288:     	b	0x1007bf9f4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4014>
1007bf28c:     	str	x0, [sp, #0x160]
1007bf290:     	mov	w24, #0x1               ; =1
1007bf294:     	b	0x1007bf9a4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3fc4>
1007bf298:     	str	x0, [sp, #0x160]
1007bf29c:     	tbnz	w24, #0x0, 0x1007bf2a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x38c8>
1007bf2a0:     	mov	x0, x19
1007bf2a4:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf2a8:     	cbz	x23, 0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf2ac:     	mov	x0, x20
1007bf2b0:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf2b4:     	b	0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf2b8:     	str	x0, [sp, #0x160]
1007bf2bc:     	add	x0, sp, #0x300
1007bf2c0:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf2c4:     	mov	w24, #0x0               ; =0
1007bf2c8:     	b	0x1007bf9a8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3fc8>
1007bf2cc:     	str	x0, [sp, #0x160]
1007bf2d0:     	mov	w8, #0x18               ; =24
1007bf2d4:     	ldr	x9, [sp, #0xf8]
1007bf2d8:     	ldr	x10, [sp, #0x118]
1007bf2dc:     	umaddl	x8, w9, w8, x10
1007bf2e0:     	add	x9, sp, #0x410
1007bf2e4:     	ldr	q0, [x9]
1007bf2e8:     	ldr	x9, [sp, #0x420]
1007bf2ec:     	add	x8, x8, x19
1007bf2f0:     	str	x9, [x8, #0x10]
1007bf2f4:     	str	q0, [x8]
1007bf2f8:     	b	0x1007bf3e4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3a04>
1007bf2fc:     	str	x0, [sp, #0x160]
1007bf300:     	add	x0, sp, #0x410
1007bf304:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf308:     	b	0x1007bf3e4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3a04>
1007bf30c:     	str	x0, [sp, #0x160]
1007bf310:     	add	x0, sp, #0x170
1007bf314:     	bl	0x1005f6ba8 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1c_>
1007bf318:     	mov	x8, #-0x1               ; =-1
1007bf31c:     	ldaddl	x8, x8, [x20]
1007bf320:     	cmp	x8, #0x1
1007bf324:     	b.ne	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bf328:     	dmb	ishld
1007bf32c:     	add	x0, sp, #0x300
1007bf330:     	bl	0x100501eb8 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcNtCsdQKgh9VQBAd_16weavepy_compiler10CodeObjectE9drop_slowBI_>
1007bf334:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bf338:     	str	x0, [sp, #0x160]
1007bf33c:     	ldr	q0, [x21]
1007bf340:     	ldr	x8, [sp, #0x420]
1007bf344:     	str	x8, [x27, #0x10]
1007bf348:     	str	q0, [x27]
1007bf34c:     	b	0x1007bf3f4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3a14>
1007bf350:     	str	x0, [sp, #0x160]
1007bf354:     	add	x0, sp, #0x410
1007bf358:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf35c:     	b	0x1007bf3f4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3a14>
1007bf360:     	str	x0, [sp, #0x160]
1007bf364:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bf368:     	str	x0, [sp, #0x160]
1007bf36c:     	b	0x1007bfc48 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4268>
1007bf370:     	str	x0, [sp, #0x160]
1007bf374:     	ldurb	w8, [x29, #-0xb8]
1007bf378:     	cmp	w8, #0xff
1007bf37c:     	b.eq	0x1007bfc48 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4268>
1007bf380:     	sub	x0, x29, #0xb8
1007bf384:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf388:     	b	0x1007bfc48 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4268>
1007bf38c:     	str	x0, [sp, #0x160]
1007bf390:     	mov	w8, #0x1                ; =1
1007bf394:     	str	w8, [sp, #0x64]
1007bf398:     	mov	x8, #-0x1               ; =-1
1007bf39c:     	str	x8, [sp, #0xa0]
1007bf3a0:     	b	0x1007bf700 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3d20>
1007bf3a4:     	str	x0, [sp, #0x160]
1007bf3a8:     	b	0x1007bf92c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f4c>
1007bf3ac:     	mov	x28, x24
1007bf3b0:     	str	x0, [sp, #0x160]
1007bf3b4:     	mov	w22, #0x0               ; =0
1007bf3b8:     	b	0x1007bfa34 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4054>
1007bf3bc:     	str	x0, [sp, #0x160]
1007bf3c0:     	tbnz	w28, #0x0, 0x1007bfc74 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4294>
1007bf3c4:     	b	0x1007bfc8c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x42ac>
1007bf3c8:     	str	x0, [sp, #0x160]
1007bf3cc:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bf3d0:     	str	x0, [sp, #0x160]
1007bf3d4:     	add	x0, sp, #0x410
1007bf3d8:     	bl	0x1005f17d0 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectNtNtB11_5error12RuntimeErrorEEB11_>
1007bf3dc:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bf3e0:     	str	x0, [sp, #0x160]
1007bf3e4:     	add	x0, sp, #0x300
1007bf3e8:     	bl	0x1005efb18 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCshxvaOLs88l5_5alloc3vec3VecTNtNtB12_6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEEEB1V_>
1007bf3ec:     	b	0x1007bf698 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3cb8>
1007bf3f0:     	str	x0, [sp, #0x160]
1007bf3f4:     	add	x0, sp, #0x300
1007bf3f8:     	bl	0x1005ef9f8 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEEB1y_>
1007bf3fc:     	b	0x1007bf4e0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b00>
1007bf400:     	str	x0, [sp, #0x160]
1007bf404:     	b	0x1007bf7ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3dcc>
1007bf408:     	str	x0, [sp, #0x160]
1007bf40c:     	ldr	q0, [x21, #0x110]
1007bf410:     	ldr	x8, [sp, #0x420]
1007bf414:     	str	x8, [x19, #0x10]
1007bf418:     	str	q0, [x19]
1007bf41c:     	b	0x1007bf42c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3a4c>
1007bf420:     	str	x0, [sp, #0x160]
1007bf424:     	add	x0, sp, #0x410
1007bf428:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf42c:     	mov	w22, #0x1               ; =1
1007bf430:     	ldr	x8, [sp, #0xd8]
1007bf434:     	cmp	x8, #0x11
1007bf438:     	b.hs	0x1007bf824 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3e44>
1007bf43c:     	b	0x1007bfae0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4100>
1007bf440:     	str	x0, [sp, #0x160]
1007bf444:     	mov	w21, #0x1               ; =1
1007bf448:     	mov	w22, #0x1               ; =1
1007bf44c:     	b	0x1007bfae4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4104>
1007bf450:     	b	0x1007bfa44 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4064>
1007bf454:     	mov	x21, x0
1007bf458:     	ldr	w28, [sp, #0x158]
1007bf45c:     	mov	x0, x20
1007bf460:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf464:     	b	0x1007bfa4c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x406c>
1007bf468:     	b	0x1007bfa64 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4084>
1007bf46c:     	mov	x21, x0
1007bf470:     	ldr	w28, [sp, #0x158]
1007bf474:     	mov	x0, x19
1007bf478:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf47c:     	b	0x1007bfbec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x420c>
1007bf480:     	str	x0, [sp, #0x160]
1007bf484:     	add	x0, sp, #0x410
1007bf488:     	bl	0x100613b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueTNtNtCshxvaOLs88l5_5alloc6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1i_>
1007bf48c:     	b	0x1007bf530 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b50>
1007bf490:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf494:     	str	x0, [sp, #0x160]
1007bf498:     	add	x0, sp, #0x170
1007bf49c:     	bl	0x1005f6ba8 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1c_>
1007bf4a0:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bf4a4:     	mov	x21, x0
1007bf4a8:     	ldr	w28, [sp, #0x158]
1007bf4ac:     	b	0x1007bfa54 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4074>
1007bf4b0:     	str	x0, [sp, #0x160]
1007bf4b4:     	subs	x22, x22, #0x1
1007bf4b8:     	b.eq	0x1007bf4d0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3af0>
1007bf4bc:     	add	x23, x19, #0x18
1007bf4c0:     	mov	x0, x19
1007bf4c4:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf4c8:     	mov	x19, x23
1007bf4cc:     	b	0x1007bf4b4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3ad4>
1007bf4d0:     	ldr	w8, [sp, #0x140]
1007bf4d4:     	tbnz	w8, #0x0, 0x1007bf4e0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b00>
1007bf4d8:     	mov	x0, x20
1007bf4dc:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf4e0:     	ldrb	w8, [sp, #0x5d0]
1007bf4e4:     	cmp	w8, #0x9
1007bf4e8:     	b.eq	0x1007bf6ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3ccc>
1007bf4ec:     	cmp	w8, #0xff
1007bf4f0:     	b.eq	0x1007bf6ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3ccc>
1007bf4f4:     	add	x0, sp, #0x5d0
1007bf4f8:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf4fc:     	b	0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf500:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf504:     	str	x0, [sp, #0x160]
1007bf508:     	mov	w21, #0x1               ; =1
1007bf50c:     	b	0x1007bfb20 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4140>
1007bf510:     	str	x0, [sp, #0x160]
1007bf514:     	ldr	x19, [sp, #0x110]
1007bf518:     	ldr	w28, [sp, #0x150]
1007bf51c:     	b	0x1007bfa00 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4020>
1007bf520:     	str	x0, [sp, #0x160]
1007bf524:     	mov	w19, #0x1               ; =1
1007bf528:     	b	0x1007bfc78 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4298>
1007bf52c:     	str	x0, [sp, #0x160]
1007bf530:     	add	x0, sp, #0x5d0
1007bf534:     	bl	0x1005f7b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecTNtNtBG_6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEEB1y_>
1007bf538:     	ldr	x8, [x19, #0x10]
1007bf53c:     	sub	x8, x8, #0x1
1007bf540:     	str	x8, [x19, #0x10]
1007bf544:     	ldr	w8, [x19, #0x20]
1007bf548:     	subs	w8, w8, #0x1
1007bf54c:     	str	w8, [x19, #0x20]
1007bf550:     	b.ne	0x1007bf558 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3b78>
1007bf554:     	stlur	xzr, [x19, #0x18]
1007bf558:     	ldr	x8, [x22, #0x8]
1007bf55c:     	cmp	x8, #0x0
1007bf560:     	cset	w9, ne
1007bf564:     	sub	x8, x8, x9
1007bf568:     	str	x8, [x22, #0x8]
1007bf56c:     	mov	x8, #-0x1               ; =-1
1007bf570:     	ldaddl	x8, x8, [x19]
1007bf574:     	cmp	x8, #0x1
1007bf578:     	b.ne	0x1007bf698 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3cb8>
1007bf57c:     	dmb	ishld
1007bf580:     	add	x0, sp, #0x648
1007bf584:     	bl	0x1008b0354 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcINtNtCshqYhlee0Vj9_10weavepy_vm4sync7GilCellINtNtCskjxBf4UiEDI_8indexmap3map8IndexMapNtNtBL_6object7DictKeyNtB25_6ObjectNtNtBL_8fasthash13FxBuildHasherEEE9drop_slowBL_>
1007bf588:     	b	0x1007bf698 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3cb8>
1007bf58c:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf590:     	str	x0, [sp, #0x160]
1007bf594:     	ldr	q0, [x25]
1007bf598:     	ldr	x8, [sp, #0x420]
1007bf59c:     	str	x8, [x26, #0x10]
1007bf5a0:     	str	q0, [x26]
1007bf5a4:     	b	0x1007bf92c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f4c>
1007bf5a8:     	str	x0, [sp, #0x160]
1007bf5ac:     	add	x0, sp, #0x410
1007bf5b0:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf5b4:     	b	0x1007bf92c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f4c>
1007bf5b8:     	str	x0, [sp, #0x160]
1007bf5bc:     	subs	x20, x20, #0x1
1007bf5c0:     	b.eq	0x1007bf5d8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3bf8>
1007bf5c4:     	add	x21, x19, #0x18
1007bf5c8:     	mov	x0, x19
1007bf5cc:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf5d0:     	mov	x19, x21
1007bf5d4:     	b	0x1007bf5bc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3bdc>
1007bf5d8:     	add	x0, sp, #0x300
1007bf5dc:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf5e0:     	add	x0, sp, #0x200
1007bf5e4:     	bl	0x1005f6ba8 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1c_>
1007bf5e8:     	mov	w28, #0x1               ; =1
1007bf5ec:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bf5f0:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf5f4:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf5f8:     	str	x0, [sp, #0x160]
1007bf5fc:     	b	0x1007bfa88 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40a8>
1007bf600:     	str	x0, [sp, #0x160]
1007bf604:     	subs	x21, x21, #0x1
1007bf608:     	b.eq	0x1007bf754 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3d74>
1007bf60c:     	add	x22, x19, #0x30
1007bf610:     	mov	x0, x19
1007bf614:     	bl	0x100613b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueTNtNtCshxvaOLs88l5_5alloc6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1i_>
1007bf618:     	mov	x19, x22
1007bf61c:     	b	0x1007bf604 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3c24>
1007bf620:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf624:     	str	x0, [sp, #0x160]
1007bf628:     	subs	x20, x20, #0x1
1007bf62c:     	b.eq	0x1007bf644 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3c64>
1007bf630:     	add	x21, x19, #0x18
1007bf634:     	mov	x0, x19
1007bf638:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf63c:     	mov	x19, x21
1007bf640:     	b	0x1007bf628 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3c48>
1007bf644:     	ldr	x8, [sp, #0x580]
1007bf648:     	cbz	x8, 0x1007bf654 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3c74>
1007bf64c:     	ldr	x0, [sp, #0x570]
1007bf650:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf654:     	ldr	x8, [sp, #0xd8]
1007bf658:     	cmp	x8, #0x11
1007bf65c:     	b.lo	0x1007bfb58 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4178>
1007bf660:     	ldr	x0, [sp, #0x10]
1007bf664:     	b	0x1007bfb64 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4184>
1007bf668:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf66c:     	str	x0, [sp, #0x160]
1007bf670:     	subs	x21, x21, #0x1
1007bf674:     	b.eq	0x1007bf68c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3cac>
1007bf678:     	add	x22, x19, #0x30
1007bf67c:     	mov	x0, x19
1007bf680:     	bl	0x100613b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueTNtNtCshxvaOLs88l5_5alloc6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1i_>
1007bf684:     	mov	x19, x22
1007bf688:     	b	0x1007bf670 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3c90>
1007bf68c:     	cbz	x24, 0x1007bf698 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3cb8>
1007bf690:     	mov	x0, x20
1007bf694:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf698:     	ldurb	w8, [x29, #-0x80]
1007bf69c:     	cmp	w8, #0xb
1007bf6a0:     	b.eq	0x1007bf6ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3ccc>
1007bf6a4:     	cmp	w8, #0xff
1007bf6a8:     	b.ne	0x1007bf6b8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3cd8>
1007bf6ac:     	ldr	x19, [sp, #0x110]
1007bf6b0:     	mov	w28, #0x1               ; =1
1007bf6b4:     	b	0x1007bfa00 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4020>
1007bf6b8:     	sub	x0, x29, #0x80
1007bf6bc:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf6c0:     	b	0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf6c4:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf6c8:     	b	0x1007bf72c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3d4c>
1007bf6cc:     	str	x0, [sp, #0x160]
1007bf6d0:     	cbnz	x22, 0x1007bf6dc <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3cfc>
1007bf6d4:     	mov	w19, #0x0               ; =0
1007bf6d8:     	b	0x1007bf920 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f40>
1007bf6dc:     	mov	x0, x26
1007bf6e0:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf6e4:     	mov	w19, #0x0               ; =0
1007bf6e8:     	b	0x1007bf920 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f40>
1007bf6ec:     	str	x0, [sp, #0x160]
1007bf6f0:     	str	x19, [sp, #0x418]
1007bf6f4:     	add	x0, sp, #0x410
1007bf6f8:     	bl	0x100ce08b0 <__RNvXse_NtNtCshxvaOLs88l5_5alloc3vec9into_iterINtB5_8IntoIterNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectENtNtNtCs8Mbv00yxnRz_4core3ops4drop4Drop4dropB10_>
1007bf6fc:     	str	wzr, [sp, #0x64]
1007bf700:     	ldr	x8, [sp, #0x5d0]
1007bf704:     	cbz	x8, 0x1007bf710 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3d30>
1007bf708:     	ldr	x0, [sp, #0x5d8]
1007bf70c:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf710:     	mov	w28, #0x1               ; =1
1007bf714:     	mov	w19, #0x1               ; =1
1007bf718:     	mov	w22, #0x1               ; =1
1007bf71c:     	b	0x1007bfa88 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40a8>
1007bf720:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf724:     	str	x0, [sp, #0x160]
1007bf728:     	b	0x1007bf91c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f3c>
1007bf72c:     	str	x0, [sp, #0x160]
1007bf730:     	b	0x1007bf93c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f5c>
1007bf734:     	str	x0, [sp, #0x160]
1007bf738:     	subs	x21, x21, #0x1
1007bf73c:     	b.eq	0x1007bf754 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3d74>
1007bf740:     	add	x22, x19, #0x30
1007bf744:     	mov	x0, x19
1007bf748:     	bl	0x100613b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueTNtNtCshxvaOLs88l5_5alloc6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1i_>
1007bf74c:     	mov	x19, x22
1007bf750:     	b	0x1007bf738 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3d58>
1007bf754:     	ldr	x8, [sp, #0xb0]
1007bf758:     	ldr	x8, [x8]
1007bf75c:     	cbz	x8, 0x1007bfc8c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x42ac>
1007bf760:     	mov	x0, x20
1007bf764:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf768:     	ldr	x0, [sp, #0x160]
1007bf76c:     	bl	0x10100fab4 <dyld_stub_binder+0x10100fab4>
1007bf770:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf774:     	str	x0, [sp, #0x160]
1007bf778:     	add	x8, x22, x28
1007bf77c:     	add	x0, x8, #0x30
1007bf780:     	subs	x19, x19, #0x1
1007bf784:     	b.eq	0x1007bf890 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3eb0>
1007bf788:     	add	x20, x0, #0x30
1007bf78c:     	bl	0x100613b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueTNtNtCshxvaOLs88l5_5alloc6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1i_>
1007bf790:     	mov	x0, x20
1007bf794:     	b	0x1007bf780 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3da0>
1007bf798:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf79c:     	str	x0, [sp, #0x160]
1007bf7a0:     	str	x21, [sp, #0x420]
1007bf7a4:     	add	x0, sp, #0x410
1007bf7a8:     	bl	0x1005f5a94 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtBG_6string6StringEECshqYhlee0Vj9_10weavepy_vm>
1007bf7ac:     	mov	w8, #0x1                ; =1
1007bf7b0:     	str	w8, [sp, #0x158]
1007bf7b4:     	mov	w28, #0x1               ; =1
1007bf7b8:     	mov	w22, #0x1               ; =1
1007bf7bc:     	ldr	x19, [sp, #0x110]
1007bf7c0:     	b	0x1007bfa0c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x402c>
1007bf7c4:     	str	x0, [sp, #0x160]
1007bf7c8:     	sub	x0, x29, #0xf0
1007bf7cc:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf7d0:     	add	x0, sp, #0x648
1007bf7d4:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf7d8:     	b	0x1007bf93c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f5c>
1007bf7dc:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf7e0:     	str	x0, [sp, #0x160]
1007bf7e4:     	subs	x20, x20, #0x1
1007bf7e8:     	b.eq	0x1007bf800 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3e20>
1007bf7ec:     	add	x21, x19, #0x18
1007bf7f0:     	mov	x0, x19
1007bf7f4:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf7f8:     	mov	x19, x21
1007bf7fc:     	b	0x1007bf7e4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3e04>
1007bf800:     	ldr	x8, [sp, #0x580]
1007bf804:     	cbz	x8, 0x1007bf810 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3e30>
1007bf808:     	ldr	x0, [sp, #0x570]
1007bf80c:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf810:     	mov	w22, #0x0               ; =0
1007bf814:     	mov	w21, #0x0               ; =0
1007bf818:     	ldr	x8, [sp, #0xd8]
1007bf81c:     	cmp	x8, #0x11
1007bf820:     	b.lo	0x1007bfae4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4104>
1007bf824:     	ldr	x0, [sp, #0x10]
1007bf828:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf82c:     	b	0x1007bfae0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4100>
1007bf830:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf834:     	str	x0, [sp, #0x160]
1007bf838:     	ldr	x8, [sp, #0x20]
1007bf83c:     	add	x8, x8, x22
1007bf840:     	add	x8, x8, #0x18
1007bf844:     	str	x8, [sp, #0x578]
1007bf848:     	ldr	x8, [sp, #0x420]
1007bf84c:     	add	x9, sp, #0x410
1007bf850:     	ldr	q0, [x9]
1007bf854:     	str	q0, [x21]
1007bf858:     	str	x8, [x21, #0x10]
1007bf85c:     	b	0x1007bf954 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f74>
1007bf860:     	str	x0, [sp, #0x160]
1007bf864:     	add	x0, sp, #0x410
1007bf868:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf86c:     	b	0x1007bf954 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f74>
1007bf870:     	str	x0, [sp, #0x160]
1007bf874:     	subs	x20, x20, #0x1
1007bf878:     	b.eq	0x1007bf890 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3eb0>
1007bf87c:     	add	x21, x19, #0x30
1007bf880:     	mov	x0, x19
1007bf884:     	bl	0x100613b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueTNtNtCshxvaOLs88l5_5alloc6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1i_>
1007bf888:     	mov	x19, x21
1007bf88c:     	b	0x1007bf874 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3e94>
1007bf890:     	ldr	x8, [sp, #0x40]
1007bf894:     	cbz	x8, 0x1007bf944 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f64>
1007bf898:     	ldr	x0, [sp, #0x88]
1007bf89c:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf8a0:     	b	0x1007bf944 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f64>
1007bf8a4:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf8a8:     	str	x0, [sp, #0x160]
1007bf8ac:     	subs	x22, x22, #0x1
1007bf8b0:     	b.eq	0x1007bf8c8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3ee8>
1007bf8b4:     	add	x21, x20, #0x18
1007bf8b8:     	mov	x0, x20
1007bf8bc:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf8c0:     	mov	x20, x21
1007bf8c4:     	b	0x1007bf8ac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3ecc>
1007bf8c8:     	ldr	x8, [sp, #0x540]
1007bf8cc:     	cbz	x8, 0x1007bfb58 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4178>
1007bf8d0:     	mov	x0, x19
1007bf8d4:     	b	0x1007bfb64 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4184>
1007bf8d8:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf8dc:     	str	x0, [sp, #0x160]
1007bf8e0:     	ldr	x8, [x27, #0x10]
1007bf8e4:     	sub	x8, x8, #0x1
1007bf8e8:     	str	x8, [x27, #0x10]
1007bf8ec:     	ldr	w8, [x27, #0x20]
1007bf8f0:     	subs	w8, w8, #0x1
1007bf8f4:     	str	w8, [x27, #0x20]
1007bf8f8:     	b.ne	0x1007bf904 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f24>
1007bf8fc:     	ldr	x8, [sp, #0x110]
1007bf900:     	stlur	xzr, [x8, #0x18]
1007bf904:     	ldr	x10, [sp, #0x140]
1007bf908:     	ldr	x8, [x10, #0x8]
1007bf90c:     	cmp	x8, #0x0
1007bf910:     	cset	w9, ne
1007bf914:     	sub	x8, x8, x9
1007bf918:     	str	x8, [x10, #0x8]
1007bf91c:     	mov	w19, #0x1               ; =1
1007bf920:     	add	x0, sp, #0x610
1007bf924:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf928:     	tbz	w19, #0x0, 0x1007bf93c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f5c>
1007bf92c:     	ldr	x8, [sp, #0x5f8]
1007bf930:     	cbz	x8, 0x1007bf93c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3f5c>
1007bf934:     	ldr	x0, [sp, #0x600]
1007bf938:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf93c:     	add	x0, sp, #0x5d0
1007bf940:     	bl	0x1005fccc8 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtNtCshxvaOLs88l5_5alloc3vec9into_iter8IntoIterTNtNtBI_6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEEB1P_>
1007bf944:     	mov	w8, #0x1                ; =1
1007bf948:     	str	w8, [sp, #0x158]
1007bf94c:     	b	0x1007bf9f8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4018>
1007bf950:     	str	x0, [sp, #0x160]
1007bf954:     	mov	w22, #0x1               ; =1
1007bf958:     	mov	w19, #0x1               ; =1
1007bf95c:     	b	0x1007bfaac <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40cc>
1007bf960:     	str	x0, [sp, #0x160]
1007bf964:     	add	x0, x19, #0x10
1007bf968:     	bl	0x10060c610 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object11PyGeneratorEBF_>
1007bf96c:     	b	0x1007bf9a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3fc0>
1007bf970:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf974:     	str	x0, [sp, #0x160]
1007bf978:     	add	x0, sp, #0x410
1007bf97c:     	bl	0x1006021b4 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtCshqYhlee0Vj9_10weavepy_vm5FrameEBD_>
1007bf980:     	add	x0, sp, #0x570
1007bf984:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf988:     	cbz	x23, 0x1007bf994 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3fb4>
1007bf98c:     	mov	x0, x21
1007bf990:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf994:     	cbz	x22, 0x1007bf9a0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3fc0>
1007bf998:     	mov	x0, x19
1007bf99c:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bf9a0:     	mov	w24, #0x0               ; =0
1007bf9a4:     	mov	w21, #0x1               ; =1
1007bf9a8:     	cbz	w21, 0x1007bf9c0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3fe0>
1007bf9ac:     	ldurb	w8, [x29, #-0xb8]
1007bf9b0:     	cmp	w8, #0xff
1007bf9b4:     	b.eq	0x1007bf9c0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3fe0>
1007bf9b8:     	sub	x0, x29, #0xb8
1007bf9bc:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf9c0:     	ldr	x8, [sp, #0x5d0]
1007bf9c4:     	cmp	x8, #0x1
1007bf9c8:     	b.hi	0x1007bf9d8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x3ff8>
1007bf9cc:     	add	x8, sp, #0x5d0
1007bf9d0:     	orr	x0, x8, #0x8
1007bf9d4:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bf9d8:     	tbnz	w24, #0x0, 0x1007bfc48 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4268>
1007bf9dc:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bf9e0:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bf9e4:     	str	x0, [sp, #0x160]
1007bf9e8:     	add	x8, sp, #0x410
1007bf9ec:     	add	x0, x8, #0x28
1007bf9f0:     	bl	0x1005ee918 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtB4_4cell10UnsafeCellINtNtCskjxBf4UiEDI_8indexmap3map8IndexMapNtNtCshqYhlee0Vj9_10weavepy_vm6object7DictKeyNtB1H_6ObjectNtNtB1J_8fasthash13FxBuildHasherEEEB1J_>
1007bf9f4:     	str	wzr, [sp, #0x158]
1007bf9f8:     	mov	w28, #0x1               ; =1
1007bf9fc:     	ldr	x19, [sp, #0x110]
1007bfa00:     	add	x0, sp, #0x5b0
1007bfa04:     	bl	0x1005f5a94 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtBG_6string6StringEECshqYhlee0Vj9_10weavepy_vm>
1007bfa08:     	mov	w22, #0x0               ; =0
1007bfa0c:     	cbz	x19, 0x1007bfa30 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4050>
1007bfa10:     	mov	x8, #-0x1               ; =-1
1007bfa14:     	ldr	x9, [sp, #0x110]
1007bfa18:     	ldaddl	x8, x8, [x9]
1007bfa1c:     	cmp	x8, #0x1
1007bfa20:     	b.ne	0x1007bfa30 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4050>
1007bfa24:     	dmb	ishld
1007bfa28:     	add	x0, sp, #0x5a8
1007bfa2c:     	bl	0x1008b0354 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcINtNtCshqYhlee0Vj9_10weavepy_vm4sync7GilCellINtNtCskjxBf4UiEDI_8indexmap3map8IndexMapNtNtBL_6object7DictKeyNtB25_6ObjectNtNtBL_8fasthash13FxBuildHasherEEE9drop_slowBL_>
1007bfa30:     	mov	w19, #0x1               ; =1
1007bfa34:     	ldr	w8, [sp, #0x158]
1007bfa38:     	tbnz	w8, #0x0, 0x1007bfa80 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40a0>
1007bfa3c:     	b	0x1007bfa88 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40a8>
1007bfa40:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bfa44:     	mov	x21, x0
1007bfa48:     	ldr	w28, [sp, #0x158]
1007bfa4c:     	add	x0, sp, #0x410
1007bfa50:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bfa54:     	add	x0, sp, #0x1b0
1007bfa58:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bfa5c:     	b	0x1007bfbec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x420c>
1007bfa60:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bfa64:     	mov	x21, x0
1007bfa68:     	ldr	w28, [sp, #0x158]
1007bfa6c:     	b	0x1007bfbec <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x420c>
1007bfa70:     	str	x0, [sp, #0x160]
1007bfa74:     	mov	w22, #0x1               ; =1
1007bfa78:     	mov	w19, #0x1               ; =1
1007bfa7c:     	mov	w28, #0x1               ; =1
1007bfa80:     	add	x0, sp, #0x200
1007bfa84:     	bl	0x1005fa178 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCskjxBf4UiEDI_8indexmap3map8IndexMapNtNtCshqYhlee0Vj9_10weavepy_vm6object7DictKeyNtB1i_6ObjectNtNtB1k_8fasthash13FxBuildHasherEEB1k_>
1007bfa88:     	ldr	x8, [sp, #0xa0]
1007bfa8c:     	cmn	x8, #0x1
1007bfa90:     	b.eq	0x1007bfaa4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40c4>
1007bfa94:     	tbz	w28, #0x0, 0x1007bfaa4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40c4>
1007bfa98:     	cbz	x8, 0x1007bfaa4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40c4>
1007bfa9c:     	ldr	x0, [sp, #0x18]
1007bfaa0:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bfaa4:     	ldr	w8, [sp, #0x64]
1007bfaa8:     	tbz	w8, #0x0, 0x1007bfab4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40d4>
1007bfaac:     	add	x0, sp, #0x570
1007bfab0:     	bl	0x1005fc92c <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtNtCshxvaOLs88l5_5alloc3vec9into_iter8IntoIterNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1t_>
1007bfab4:     	ldr	x8, [sp, #0xd8]
1007bfab8:     	cmp	x8, #0x11
1007bfabc:     	b.hs	0x1007bfad4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40f4>
1007bfac0:     	tbnz	w19, #0x0, 0x1007bfae0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4100>
1007bfac4:     	mov	w21, #0x0               ; =0
1007bfac8:     	mov	w28, #0x0               ; =0
1007bfacc:     	tbnz	w22, #0x0, 0x1007bfb20 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4140>
1007bfad0:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bfad4:     	ldr	x0, [sp, #0x10]
1007bfad8:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bfadc:     	cbz	w19, 0x1007bfac4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x40e4>
1007bfae0:     	mov	w21, #0x0               ; =0
1007bfae4:     	ldr	x19, [sp, #0x548]
1007bfae8:     	ldr	x8, [sp, #0x550]
1007bfaec:     	add	x23, x8, #0x1
1007bfaf0:     	mov	x0, x19
1007bfaf4:     	subs	x23, x23, #0x1
1007bfaf8:     	b.eq	0x1007bfb0c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x412c>
1007bfafc:     	add	x20, x0, #0x18
1007bfb00:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bfb04:     	mov	x0, x20
1007bfb08:     	b	0x1007bfaf4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4114>
1007bfb0c:     	ldr	x8, [sp, #0x540]
1007bfb10:     	cbz	x8, 0x1007bfb1c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x413c>
1007bfb14:     	mov	x0, x19
1007bfb18:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bfb1c:     	tbz	w22, #0x0, 0x1007bfb28 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4148>
1007bfb20:     	ldr	x0, [sp, #0xb0]
1007bfb24:     	bl	0x1005f7b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecTNtNtBG_6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEEB1y_>
1007bfb28:     	tbz	w21, #0x0, 0x1007bfb58 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4178>
1007bfb2c:     	ldr	x8, [sp, #0x58]
1007bfb30:     	add	x20, x8, #0x1
1007bfb34:     	ldr	x0, [sp, #0x20]
1007bfb38:     	subs	x20, x20, #0x1
1007bfb3c:     	b.eq	0x1007bfb50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4170>
1007bfb40:     	add	x19, x0, #0x18
1007bfb44:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bfb48:     	mov	x0, x19
1007bfb4c:     	b	0x1007bfb38 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4158>
1007bfb50:     	ldr	x8, [sp, #0x28]
1007bfb54:     	cbnz	x8, 0x1007bfb60 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4180>
1007bfb58:     	mov	w28, #0x0               ; =0
1007bfb5c:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bfb60:     	ldr	x0, [sp, #0x20]
1007bfb64:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bfb68:     	mov	w28, #0x0               ; =0
1007bfb6c:     	b	0x1007bfc50 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4270>
1007bfb70:     	subs	x20, x20, #0x1
1007bfb74:     	b.eq	0x1007bfb8c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x41ac>
1007bfb78:     	add	x21, x19, #0x18
1007bfb7c:     	mov	x0, x19
1007bfb80:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bfb84:     	mov	x19, x21
1007bfb88:     	b	0x1007bfb70 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4190>
1007bfb8c:     	ldr	x8, [sp, #0x28]
1007bfb90:     	cbz	x8, 0x1007bfbd8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x41f8>
1007bfb94:     	ldr	x0, [sp, #0x20]
1007bfb98:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bfb9c:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bfba0:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bfba4:     	subs	x23, x23, #0x1
1007bfba8:     	b.eq	0x1007bfbc0 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x41e0>
1007bfbac:     	add	x21, x20, #0x18
1007bfbb0:     	mov	x0, x20
1007bfbb4:     	bl	0x10060d250 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEBF_>
1007bfbb8:     	mov	x20, x21
1007bfbbc:     	b	0x1007bfba4 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x41c4>
1007bfbc0:     	ldr	x8, [sp, #0x540]
1007bfbc4:     	cbz	x8, 0x1007bfbd8 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x41f8>
1007bfbc8:     	mov	x0, x19
1007bfbcc:     	bl	0x10100ff1c <dyld_stub_binder+0x10100ff1c>
1007bfbd0:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bfbd4:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bfbd8:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bfbdc:     	mov	x21, x0
1007bfbe0:     	add	x0, sp, #0x410
1007bfbe4:     	bl	0x1005f8b78 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc4sync8ArcInnerINtNtCshqYhlee0Vj9_10weavepy_vm13tuple_storage12TupleStorageANtNtB1j_6object6Objectj3_EEEB1j_>
1007bfbe8:     	ldr	w28, [sp, #0x158]
1007bfbec:     	str	x26, [sp, #0x5e0]
1007bfbf0:     	add	x0, sp, #0x5d0
1007bfbf4:     	bl	0x1005f6ba8 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1c_>
1007bfbf8:     	ldr	x23, [sp, #0x150]
1007bfbfc:     	ldr	x24, [sp, #0x140]
1007bfc00:     	b	0x1007bfc10 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4230>
1007bfc04:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bfc08:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>
1007bfc0c:     	mov	x21, x0
1007bfc10:     	str	x21, [sp, #0x160]
1007bfc14:     	ldr	x8, [x23, #0x10]
1007bfc18:     	sub	x8, x8, #0x1
1007bfc1c:     	str	x8, [x23, #0x10]
1007bfc20:     	ldr	w8, [x23, #0x20]
1007bfc24:     	subs	w8, w8, #0x1
1007bfc28:     	str	w8, [x23, #0x20]
1007bfc2c:     	b.ne	0x1007bfc34 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4254>
1007bfc30:     	stlur	xzr, [x23, #0x18]
1007bfc34:     	ldr	x8, [x24, #0x8]
1007bfc38:     	cmp	x8, #0x0
1007bfc3c:     	cset	w9, ne
1007bfc40:     	sub	x8, x8, x9
1007bfc44:     	str	x8, [x24, #0x8]
1007bfc48:     	add	x0, sp, #0x200
1007bfc4c:     	bl	0x1006021b4 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueNtCshqYhlee0Vj9_10weavepy_vm5FrameEBD_>
1007bfc50:     	ldr	x8, [sp, #0x168]
1007bfc54:     	mov	x9, #-0x1               ; =-1
1007bfc58:     	ldaddl	x9, x8, [x8]
1007bfc5c:     	cmp	x8, #0x1
1007bfc60:     	b.ne	0x1007bfc70 <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x4290>
1007bfc64:     	dmb	ishld
1007bfc68:     	add	x0, sp, #0x168
1007bfc6c:     	bl	0x100501eb8 <__RNvMsn_NtCshxvaOLs88l5_5alloc4syncINtB5_3ArcNtCsdQKgh9VQBAd_16weavepy_compiler10CodeObjectE9drop_slowBI_>
1007bfc70:     	tbz	w28, #0x0, 0x1007bfc8c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x42ac>
1007bfc74:     	mov	w19, #0x0               ; =0
1007bfc78:     	ldr	x0, [sp, #0xb0]
1007bfc7c:     	bl	0x1005f7b14 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecTNtNtBG_6string6StringNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEEB1y_>
1007bfc80:     	tbz	w19, #0x0, 0x1007bfc8c <__RNvMs2_CshqYhlee0Vj9_10weavepy_vmNtB5_11Interpreter17call_python_owned+0x42ac>
1007bfc84:     	ldr	x0, [sp, #0x50]
1007bfc88:     	bl	0x1005f6ba8 <__RINvNtCs8Mbv00yxnRz_4core3ptr9drop_glueINtNtCshxvaOLs88l5_5alloc3vec3VecNtNtCshqYhlee0Vj9_10weavepy_vm6object6ObjectEEB1c_>
1007bfc8c:     	ldr	x0, [sp, #0x160]
1007bfc90:     	bl	0x10100fab4 <dyld_stub_binder+0x10100fab4>
1007bfc94:     	bl	0x100f8b580 <__RNvNtCs8Mbv00yxnRz_4core9panicking16panic_in_cleanup>

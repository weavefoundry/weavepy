"""Compare candidate and checkpoint I/O behavior while preserving full errors."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

out = Path('target/jit-raise-exits-io-diagnostic')
assert not out.exists()
out.mkdir()
wrapper = Path('target/capture_io_diagnostic_child.py').resolve()
wrapper.chmod(0o755)
report = {'purpose': __doc__, 'wrapper_sha256': hashlib.sha256(wrapper.read_bytes()).hexdigest(), 'rows': {}}
variants = [('new_jit', 'target/release/weavepy-runtime-jit-raise-exits', '1'),
            ('base_jit', 'target/release/weavepy-runtime-weakref-shared-keys', '1'),
            ('new_interp', 'target/release/weavepy-runtime-jit-raise-exits', '0')]
for label, binary, jit in variants:
    directory = (out / label).resolve()
    directory.mkdir()
    binary = Path(binary).resolve()
    env = dict(os.environ, WEAVEPY_IO_DIAGNOSTIC_OUT=str(directory),
               WEAVEPY_IO_DIAGNOSTIC_BINARY=str(binary), WEAVEPY_JIT=jit,
               WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
               WEAVEPY_FROZEN_CACHE=str((out / 'frozen' / hashlib.sha256(binary.read_bytes()).hexdigest()).resolve()))
    command = ['target/release/weavepy-conformance', 'regrtest', '--mode', 'subprocess',
               '--weavepy', str(wrapper), '--filter', 'cpython/Lib/test/test_io.py', '--stream']
    result = subprocess.run(command, env=env, capture_output=True, text=True, timeout=900)
    (directory / 'runner.stdout.txt').write_text(result.stdout)
    (directory / 'runner.stderr.txt').write_text(result.stderr)
    report['rows'][label] = {'binary': str(binary), 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
                             'command': command, 'returncode': result.returncode,
                             'stdout': result.stdout, 'stderr': result.stderr}
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(label, result.returncode, flush=True)

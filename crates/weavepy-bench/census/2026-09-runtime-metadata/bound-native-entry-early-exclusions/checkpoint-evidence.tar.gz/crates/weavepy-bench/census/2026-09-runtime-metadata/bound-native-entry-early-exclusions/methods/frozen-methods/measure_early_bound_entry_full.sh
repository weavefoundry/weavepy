#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
focused="$1"
output="$2"
test "$(cat target/early-bound-entry-validation-stage.txt)" = done
test "$(cat "$focused/stage.txt")" = done
test ! -e "$output"
mkdir "$output"
base="$(cat target/early-bound-entry-previous.txt)"
binary=target/release/weavepy-runtime-early-bound-entry
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf 'startup and imports\n' > "$output/stage.txt"
python3.14 target/shared_slot_keys_startup_probes.py --base "$base" --new "$binary" --samples 31 --out "$output/startup.json" > "$output/startup.txt" 2>&1
printf 'full 24-fixture census\n' > "$output/stage.txt"
python3.14 tools/bench_compare.py --base "$base" --new "$binary" --samples 5 --frozen-cache-root "$output/frozen" --out "$output/suite.json" > "$output/suite.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
python3.14 target/summarize_runtime_suite.py --suite "$output/suite.json" --out "$output/summary.json" > "$output/summary.txt" 2>&1
printf 'done\n' > "$output/stage.txt"

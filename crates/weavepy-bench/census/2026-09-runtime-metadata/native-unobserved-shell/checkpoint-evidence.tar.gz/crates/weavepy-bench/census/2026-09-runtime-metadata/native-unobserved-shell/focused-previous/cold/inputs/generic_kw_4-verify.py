import importlib.util, json
spec = importlib.util.spec_from_file_location('shell_control', '/Users/owencarey/Documents/weavefoundry/weavepy/target/native-unobserved-shell-inputs-v2/cold/generic_kw_4.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(20000)
for _ in range(6):
    module.bench(64)
last = module.bench(20000)
print(json.dumps(first))
print(json.dumps(last))

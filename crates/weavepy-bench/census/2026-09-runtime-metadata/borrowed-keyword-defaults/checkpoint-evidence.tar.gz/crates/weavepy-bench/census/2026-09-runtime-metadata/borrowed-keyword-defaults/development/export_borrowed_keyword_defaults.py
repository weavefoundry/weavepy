"""Preserve positional-default gains and the unresolved broader regressions."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

subprocess.run(['python3.14', 'target/verify_borrowed_keyword_defaults_ready.py'], check=True)
base = Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out = base / 'borrowed-keyword-defaults'
assert not out.exists()
for label in ['focused-retained', 'full-retained']:
    gate = json.loads(Path(f'target/borrowed-keyword-defaults-{label}-load.json').read_text())
    assert gate['status'] == 'complete' and gate['returncode'] == 0
    assert Path(f'target/borrowed-keyword-defaults-{label}/stage.txt').read_text().strip() == 'done'
out.mkdir()
index, destinations = [], set()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def add(source, relative):
    source = Path(source)
    raw = source.read_bytes()
    data = raw
    relative = Path(relative)
    if len(raw) > 32768 and source.suffix in {'.json', '.jsonl', '.txt', '.rs', '.diff', '.s'}:
        data = gzip.compress(raw, mtime=0)
        relative = Path(str(relative) + '.gz')
    assert str(relative) not in destinations, relative
    destinations.add(str(relative))
    dest = out / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    index.append({'path': str(relative), 'source': str(source), 'bytes': len(data), 'sha256': sha(data),
                  'uncompressed_bytes': len(raw), 'uncompressed_sha256': sha(raw)})
def tree(source, prefix, exclude=()):
    for path in sorted(Path(source).rglob('*')):
        relative = path.relative_to(source)
        if path.is_file() and not any(part in exclude for part in relative.parts):
            add(path, Path(prefix) / relative)
tree('target/borrowed-keyword-defaults-source-snapshot', 'candidate')
for label in ['focused-retained', 'full-retained']:
    tree(f'target/borrowed-keyword-defaults-{label}', label, ['frozen', 'startup'])
for group in ['checks', 'validation', 'preimages']:
    tree(f'target/borrowed-keyword-defaults-{group}', group, ['frozen'])
for path in sorted(Path('target').glob('borrowed-keyword-defaults*')):
    if path.is_file() and path.name != 'borrowed-keyword-defaults-export.txt':
        add(path, Path('development') / path.name)
for name in ['performance_phase74_status.md', 'prepare_borrowed_keyword_defaults_methods.py',
             'prepare_borrowed_keyword_defaults_inputs.py', 'check_borrowed_keyword_defaults_native.sh',
             'export_borrowed_keyword_defaults.py', 'niche-string-owner-restoration.json']:
    add(Path('target') / name, Path('development') / name)
for name in json.loads(Path('target/borrowed-keyword-defaults-prebuild.json').read_text())['methods']:
    add(name, Path('methods') / name)

full = json.loads(Path('target/borrowed-keyword-defaults-full-retained/summary.json').read_text())
focused = json.loads(Path('target/borrowed-keyword-defaults-focused-retained/summary.json').read_text())
lines = ['# Borrow positional and keyword-only defaults', '',
    'Decision: retain as an experimental foundation for further refinement. The',
    'targeted gains are strong and correctness checks pass, but broader JIT time',
    'and RSS remain slightly worse. Retained bf2 remains the acceptance reference.',
    'Do not describe this as an overall or universal improvement over bf2 or',
    'CPython. The user goal remains unachieved.', '',
    'Candidate: `bc88bf2b02abaaf0ad6a3d7427a17cab11f864a400a8161fc2effe5f396dd695`,',
    '44,080,336 bytes. Measured reference: retained bf2,',
    '`bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4`,',
    '44,097,168 bytes. Source predecessor is positional-only 44c5; no new direct',
    'performance comparison against 44c5 is claimed.', '',
    'The combined runtime change affects two adjacent default-binding blocks in',
    'lib.rs. Positional defaults borrow the pinned override tuple. Keyword-only',
    'defaults borrow the override dictionary and preserve plain-string iteration',
    'and order. Both clone only values filling missing arguments. Keyword default',
    'processing is skipped when all keyword-only arguments are already supplied.',
    'No string-key hash probe can invoke exotic equality under the borrow. All',
    'borrows end before user code and error rendering. Compiled defaults, None',
    'clearing, suffix rules, and native eligibility retain their existing behavior.',
    'No unsafe operation or ownership/allocation layout was added or changed.', '',
    'The new keyword oracle passes on CPython and bf2 in JIT, interpreter, and',
    'GIL-disabled modes. It checks sparse/all-supplied calls, unrelated keys,',
    'aliases, None/deletion, code replacement, errors, bound receivers, and',
    'clearing the defaults dictionary inside the callee. Required values stay',
    'alive; unused values do not acquire a hidden lifetime. The positional oracle',
    'also remains. All 24 fixture checksums match independently calculated CPython',
    'results; the earlier positional fixture sources are unchanged.', '',
    'Validation passed 347 VM tests, 156 C API tests, strict lint/format, a no-JIT',
    'check, all 93 targeted Python checks, and all 275 outside-sandbox compatibility',
    'checks. Optional extension tests may check availability internally. This safe',
    'borrowing change does not add raw ownership operations requiring new Miri',
    'trials. All 338 source identities and 120 method/input identities remained',
    'unchanged through building and measurement. The observed 4m03s release build',
    'is not a controlled build-time comparison.', '',
    'Both stages used the exclusive serial lease and unchanged outside-sandbox',
    'load gate. The full stage launched only after focused completion was inspected.',
    'All samples, load observations, and frozen-cache assertions are retained.', '',
    'Ratios below 1 favor the candidate. Means aggregate per-fixture medians of',
    'paired ratios. Keep the 21-, 23-, and 24-row cohorts distinct.', '',
    '| Metric | Candidate / bf2 | Candidate / CPython | Wins over CPython |',
    '| --- | ---: | ---: | ---: |']
c = full['cohorts']
w = c['all_23_workloads_excluding_startup']['metrics']
m = c['all_processes_including_startup']['metrics']
for label, row in [('JIT workload time (23)', w['jit']['ns']),
                   ('Interpreter workload time (23)', w['interp']['ns']),
                   ('JIT process wall time (24)', m['jit']['wall_ns']),
                   ('JIT CPU time (24)', m['jit']['cpu_ns']),
                   ('JIT peak RSS (24)', m['jit']['rss_bytes']),
                   ('Interpreter process wall time (24)', m['interp']['wall_ns']),
                   ('Interpreter CPU time (24)', m['interp']['cpu_ns']),
                   ('Interpreter peak RSS (24)', m['interp']['rss_bytes'])]:
    lines.append(f"| {label} | {row['new_over_base']:.9f} | {row['new_over_cpython']:.9f} | {row['weavepy_wins']} |")
lines += ['', 'Every JIT pair improves in each keyword-only override control, cold and',
    'warm, with roughly 11-39% less time. Positional override gains remain. Wide',
    'positional all-supplied and compiled keyword-only controls retain roughly',
    '1-2% regressions. Peak RSS is mixed, not consistently improved. Full JIT',
    'workload/wall/CPU/RSS record 12/16/17/12 median regressions respectively.',
    'Interpreter aggregates improve slightly. No confidence or noise argument',
    'removes the observed losses.', '',
    '| Focused control | Time / bf2 | RSS / bf2 | Time wins (7 pairs) |',
    '| --- | ---: | ---: | ---: |']
for name, row in focused['rows'].items():
    v = row['new_over_previous']['jit']
    lines.append(f"| {name} | {v['ns']:.6f} | {v['rss_bytes']:.6f} | {row['pairs']['jit']['ns']['wins']} |")
lines += ['', 'All raw samples, losses, validation outcomes, load observations, VM/swap',
    'snapshots, methods, inputs, and source snapshots remain. Large text artifacts',
    'use lossless gzip; index.json identifies stored and original bytes. Executables',
    'and frozen caches remain local. Intermediate status notes are historical.', '',
    'A separate time-formatting prototype was prepared during compatibility checks',
    'and finished before any measurement gate launched. It did not change this',
    'candidate and is outside this trial. Its correctness results are not runtime',
    'performance measurements.', '',
    'No universal, energy, controlled build-time, portability, or native parallel-',
    'scaling conclusion follows from these measurements.', '']
data = '\n'.join(lines).encode()
(out / 'REPORT.md').write_bytes(data)
index.append({'path': 'REPORT.md', 'bytes': len(data), 'sha256': sha(data)})
(out / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
for row in index:
    data = (out / row['path']).read_bytes()
    assert sha(data) == row['sha256']
    if 'uncompressed_sha256' in row:
        raw = gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert sha(raw) == row['uncompressed_sha256']
allow = {'!borrowed-keyword-defaults/'}
for path in out.rglob('*'):
    allow.add('!' + str(path.relative_to(base)) + ('/' if path.is_dir() else ''))
with (base / '.gitignore').open('a') as f:
    f.write('\n# Combined default borrowing and remaining broader regressions.\n' + '\n'.join(sorted(allow)) + '\n')
with (base / 'README.md').open('a') as f:
    f.write('\nThe [combined-default borrowing trial](borrowed-keyword-defaults/REPORT.md) records\nstrong keyword and positional gains alongside remaining broader JIT regressions. It remains under\nrefinement; bf2 remains the retained acceptance reference.\n')
print('Archived', len(index) + 1, 'files;', sum(p.stat().st_size for p in out.rglob('*') if p.is_file()), 'bytes. All hashes verified.')

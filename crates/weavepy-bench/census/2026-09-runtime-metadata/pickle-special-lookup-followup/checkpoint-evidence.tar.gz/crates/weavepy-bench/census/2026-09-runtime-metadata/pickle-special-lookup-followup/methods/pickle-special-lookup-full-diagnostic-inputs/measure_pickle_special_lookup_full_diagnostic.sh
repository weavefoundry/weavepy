#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/pickle-special-lookup-validation-stage.txt)" = done
test "$(cat target/pickle-special-lookup-diagnostic/stage.txt)" = done
test ! -e target/pickle-special-lookup-full-diagnostic
mkdir target/pickle-special-lookup-full-diagnostic
base=target/release/weavepy-runtime-jit-raise-call-spans
binary=target/release/weavepy-runtime-pickle-special-lookup
vm_stat > target/pickle-special-lookup-full-diagnostic/vm-before.txt
sysctl hw.memsize vm.swapusage > target/pickle-special-lookup-full-diagnostic/memory-before.txt
printf 'startup and imports\n' > target/pickle-special-lookup-full-diagnostic/stage.txt
python3.14 target/shared_slot_keys_startup_probes.py --base "$base" --new "$binary" --samples 31 --out target/pickle-special-lookup-full-diagnostic/startup.json > target/pickle-special-lookup-full-diagnostic/startup.txt 2>&1
printf 'full 24-fixture census\n' > target/pickle-special-lookup-full-diagnostic/stage.txt
python3.14 tools/bench_compare.py --base "$base" --new "$binary" --samples 5 --frozen-cache-root target/pickle-special-lookup-full-diagnostic/frozen --out target/pickle-special-lookup-full-diagnostic/suite.json > target/pickle-special-lookup-full-diagnostic/suite.txt 2>&1
vm_stat > target/pickle-special-lookup-full-diagnostic/vm-after.txt
sysctl hw.memsize vm.swapusage > target/pickle-special-lookup-full-diagnostic/memory-after.txt
python3.14 target/summarize_runtime_suite.py --suite target/pickle-special-lookup-full-diagnostic/suite.json --out target/pickle-special-lookup-full-diagnostic/summary.json > target/pickle-special-lookup-full-diagnostic/summary.txt 2>&1
printf 'done\n' > target/pickle-special-lookup-full-diagnostic/stage.txt

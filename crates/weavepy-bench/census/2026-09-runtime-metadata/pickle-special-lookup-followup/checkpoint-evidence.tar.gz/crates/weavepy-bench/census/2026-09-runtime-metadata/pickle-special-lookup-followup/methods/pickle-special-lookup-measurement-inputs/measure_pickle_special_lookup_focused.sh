#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/pickle-special-lookup-validation-stage.txt)" = done
test ! -e target/pickle-special-lookup-focused
mkdir target/pickle-special-lookup-focused
base=target/release/weavepy-runtime-jit-raise-call-spans
binary=target/release/weavepy-runtime-pickle-special-lookup
vm_stat > target/pickle-special-lookup-focused/vm-before.txt
sysctl hw.memsize vm.swapusage > target/pickle-special-lookup-focused/memory-before.txt
for group in components hooks; do
    printf '%s\n' "$group" > target/pickle-special-lookup-focused/stage.txt
    python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs "target/pickle-special-lookup-inputs/$group" --out "target/pickle-special-lookup-focused/$group" --samples 7 > "target/pickle-special-lookup-focused/$group.txt" 2>&1
done
vm_stat > target/pickle-special-lookup-focused/vm-after.txt
sysctl hw.memsize vm.swapusage > target/pickle-special-lookup-focused/memory-after.txt
printf 'done\n' > target/pickle-special-lookup-focused/stage.txt

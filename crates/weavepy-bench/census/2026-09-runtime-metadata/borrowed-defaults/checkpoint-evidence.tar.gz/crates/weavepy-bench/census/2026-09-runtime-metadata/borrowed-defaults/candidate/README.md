# Frozen candidate inputs

The environment file identifies the executable and all copied source and
measurement inputs. These files were captured after building and before full
compatibility validation and timing. Consult the adjacent results for their
outcomes; this snapshot alone makes no validation or performance claim.

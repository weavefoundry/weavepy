"""Freeze all candidate sources and methods immediately before the release build."""
import hashlib
import json
from pathlib import Path

out = Path('target/compact-arc-clone-prebuild.json')
assert not out.exists()
for name, digest in json.loads(Path('target/compact-arc-clone-integrated-miri-report.json').read_text())['hashes'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
paths = set(json.loads(Path('target/compact-arc-storage-prebuild.json').read_text())['sources'])
paths.update(['Cargo.toml', 'Cargo.lock'])
methods = [Path('target') / name for name in [
    'build_compact_arc_clone.sh', 'check_compact_arc_clone.sh',
    'validate_compact_arc_clone.sh', 'check_compact_arc_clone_extra.py',
    'measure_compact_arc_clone_focused.sh', 'measure_compact_arc_clone_full.sh',
    'compact-arc-clone-protocol.md', 'verify_compact_arc_clone_ready.py',
    'freeze_compact_arc_clone_sources.py', 'summarize_compact_arc_clone.py',
    'measure_verified_python_components.py', 'freeze_runtime_candidate.py',
    'capture_runtime_environment.py', 'run_performance_under_load_gate.py',
    'summarize_runtime_suite.py', 'shared_slot_keys_startup_probes.py',
    'thin-value-storage-capi-selection.toml',
    'compact-arc-clone-integrated-miri-report.json',
]]
methods += [Path('tools/bench_compare.py'), Path('tests/regrtest/expectations.toml'),
    Path('crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py')]
methods += list(Path('target/thin-value-storage-inputs').rglob('*.py'))
methods += list(Path('target/thin-value-storage-inputs').rglob('preparation.json'))
def hashes(names):
    return {str(p): hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(names)}
report = {'sources': hashes(paths), 'methods': hashes(methods)}
out.write_text(json.dumps(report, indent=2) + '\n')
print('Frozen', len(report['sources']), 'sources and', len(report['methods']), 'methods/inputs.')

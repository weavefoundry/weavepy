#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
binary=target/release/weavepy-runtime-pickle-special-lookup
base=target/release/weavepy-runtime-jit-raise-call-spans
test ! -e "$binary"
test ! -e target/pickle-special-lookup-v2-stage.txt
printf 'VM tests and static checks\n' > target/pickle-special-lookup-v2-stage.txt
cargo fmt --all -- --check > target/pickle-special-lookup-v2-format.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/pickle-special-lookup-v2-vm-tests.txt 2>&1
cargo clippy --offline --locked -p weavepy-vm -p weavepy-jit --lib --tests -j 1 -- -D warnings > target/pickle-special-lookup-v2-clippy.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/pickle-special-lookup-v2-no-jit.txt 2>&1
printf 'release build\n' > target/pickle-special-lookup-v2-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/pickle-special-lookup-v2-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/pickle-special-lookup-v2-source-snapshot --extra target/build_pickle_special_lookup_v2.sh target/preflight_pickle_special_lookup_v3.py target/pickle-special-lookup-baseline-preflight-v3/report.json > target/pickle-special-lookup-v2-snapshot.txt 2>&1
printf 'done\n' > target/pickle-special-lookup-v2-stage.txt

# Cold-only continuation after a missing timer

The original focused run met its strict host-load precondition and completed
all ten call shapes and four warm exception cases with seven pairs each. Keep
all of those samples, cache checks, and load observations. Its final stage
failed on the first unmeasured cache-stabilization invocation because warm
probe definitions were incorrectly used as standalone cold programs. The
process exited successfully without printing a timer. The cold group's value
checks passed, but it recorded no timing rows or retained samples.

Do not retry any completed case. Preserve the original failure, launcher, and
input bundle. Copy the four existing cold-exception sources from the preceding
raise-exit experiment; they contain the same workload bodies and work=5000,
plus the established __main__ timer. Keep their exact source hashes and use
new verification drivers pointing to the copied inputs.

Run only these four cold cases, seven pairs and five variants, in a fresh
continuation directory after the same strict load gate (1/5 minute <=4, three
ten-second observations, maximum 600 seconds). Retain every sample and all
telemetry. If the gate expires without a child or samples, any busy diagnostic
must be separately recorded and cannot claim qualification. Do not run heavy
competing work or edit runtime/active harness sources while the gate or timing
is active. Runtime candidate ca6b541d and predecessor 539c6dd3 are unchanged.

Create a completion manifest only after the original fourteen cases and all
four continuation cases are verified complete. Its status must explicitly
record completion through a separate cold continuation and preserve the
original failed stage. Use that manifest for subsequent full-suite validation;
do not mark the original failed stage successful or omit its failure.

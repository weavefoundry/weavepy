import os
class Fn:
    def __call__(self, a, b, c, d):
        return len(a) + len(b) + len(c) + len(d)
FN = Fn()
A = [1, 2]
B = (3, 4, 5)
C = {"x": 7}
D = "text"

def bench(n):
    f = FN
    a, b, c, d = A, B, C, D
    total = 0
    for i in range(n):
        total += f(a, b, c, d)
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

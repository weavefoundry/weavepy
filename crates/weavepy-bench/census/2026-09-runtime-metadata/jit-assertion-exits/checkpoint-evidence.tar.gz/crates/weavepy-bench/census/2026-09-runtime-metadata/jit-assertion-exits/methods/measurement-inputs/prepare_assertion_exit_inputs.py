"""Prepare assertion success/failure and datetime controls before JIT edits."""
import hashlib
import json
from pathlib import Path

root = Path("target/assertion-exit-inputs")
root.mkdir()
warm = {
    "assert_int": '''
def leaf(value):
    assert value >= 0, f"negative value {value}"
    return value * 3 + 1
def bench(n):
    total = 0
    for i in range(n):
        total += leaf(i)
    return total
''',
    "assert_float": '''
def leaf(value):
    assert value >= 0.0, f"negative value {value}"
    return value * 1.5 + 0.25
def bench(n):
    total = 0.0
    for i in range(n):
        total += leaf(i * 0.25)
    return total
''',
    "assert_list": '''
def leaf(values):
    assert len(values) > 0, f"empty values {values}"
    return values[0] + 1
def bench(n):
    values = [3, 4, 5]
    total = 0
    for i in range(n):
        total += leaf(values)
    return total
''',
    "assert_chain": '''
def leaf(value):
    assert 0 <= value <= 1000000, ("too low" if value < 0 else "too high")
    return value + 1
def bench(n):
    total = 0
    for i in range(n):
        total += leaf(i)
    return total
''',
}
cold = {}
for period in (0, 100, 2, 1):
    name = "failures_" + ("none" if period == 0 else "every_%d" % period)
    source = f'''
def leaf(value):
    assert value >= 0, f"negative value {{value}}"
    return value * 3 + 1
def wrapper(value):
    return leaf(value) + 2
def bench(n):
    total = 0
    for i in range(n):
        value = -1 if {period} and i % {max(period, 1)} == 0 else i
        try:
            total += wrapper(value)
        except AssertionError as error:
            total += len(error.args[0])
    return total
'''
    warm[name] = source
    cold[name] = source
warm["date_toordinal"] = '''
from datetime import date, timedelta
dates = [date(2000, 1, 1) + timedelta(days=i * 7) for i in range(256)]
def bench(n):
    total = 0
    for i in range(n):
        total += dates[i & 255].toordinal()
    return total
'''
warm["date_weekday"] = warm["date_toordinal"].replace(".toordinal()", ".weekday()")
warm["datetime_add"] = '''
from datetime import datetime, timedelta, timezone
base = datetime(2000, 1, 1, 3, 5, 7, 11, tzinfo=timezone.utc)
step = timedelta(minutes=37, seconds=11, microseconds=7)
def bench(n):
    current = base
    total = 0
    for i in range(n):
        current = current + step
        total += current.day + current.minute
    return total
'''
warm["datetime_subtract"] = '''
from datetime import datetime, timedelta, timezone
base = datetime(2000, 1, 1, 3, 5, 7, 11, tzinfo=timezone.utc)
dates = [base + timedelta(days=i, seconds=i * 71) for i in range(256)]
def bench(n):
    total = 0
    for i in range(n):
        delta = dates[i & 255] - base
        total += delta.days + delta.seconds
    return total
'''
for group, cases in [("warm", warm), ("cold", cold)]:
    directory = root / group
    directory.mkdir()
    work = 5000
    rows = {}
    for name, source in cases.items():
        if group == "cold":
            source += '''
if __name__ == "__main__":
    import os
    import time
    n = int(os.environ["WEAVEPY_BENCH_WORK"])
    start = time.perf_counter_ns()
    result = bench(n)
    elapsed = time.perf_counter_ns() - start
    print("WEAVEPY_BENCH_NS=%d" % elapsed)
'''
        p = directory / (name + ".py")
        p.write_text(source)
        driver = directory / (name + "-verify.py")
        driver.write_text(f'''import importlib.util
import json
spec = importlib.util.spec_from_file_location("assertion_control", {str(p.resolve())!r})
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench({work})
for _ in range(6):
    module.bench({work})
last = module.bench({work})
print(json.dumps(first))
print(json.dumps(last))
''')
        rows[name] = {"path": str(p), "source_sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                      "driver": str(driver), "driver_sha256": hashlib.sha256(driver.read_bytes()).hexdigest()}
    (directory / "preparation.json").write_text(json.dumps({"work": work, "rows": rows}, indent=2) + "\n")
print("Prepared 12 warm and four cold assertion/datetime controls.")

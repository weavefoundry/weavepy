import os
values = tuple("default-%d-" % i + "shared-text" * 3 for i in range(1))
provided = "provided-" + "string" * 3
def target(a0):
    return a0
target.__defaults__ = values
def bench(n):
    total = 0
    for _ in range(n):
        total += len(target(a0=provided))
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

"""Freeze the one-block binding change and declared measurement methods."""
from pathlib import Path
import hashlib
import json
import difflib

out = Path('target/borrowed-keyword-defaults-prebuild.json')
assert not out.exists()
original = json.loads(Path('target/borrowed-defaults-prebuild.json').read_text())['sources']
changed = [p for p, digest in original.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest() != digest]
assert changed == ['crates/weavepy-vm/src/lib.rs'], changed
paths = set(original)
paths.add('tests/regrtest/test_overridden_keyword_default_ownership.py')
methods = [Path('target') / name for name in [
    'build_borrowed_keyword_defaults.sh', 'check_borrowed_keyword_defaults.sh', 'check_borrowed_keyword_defaults_native.sh',
    'validate_borrowed_keyword_defaults.sh', 'measure_borrowed_keyword_defaults_focused.sh', 'measure_borrowed_keyword_defaults_full.sh',
    'summarize_borrowed_keyword_defaults.py', 'verify_borrowed_keyword_defaults_ready.py', 'freeze_borrowed_keyword_defaults_sources.py',
    'borrowed-keyword-defaults-protocol.md', 'prepare_borrowed_keyword_defaults_inputs.py', 'prepare_borrowed_keyword_defaults_methods.py',
    'measure_verified_python_components.py', 'freeze_runtime_candidate.py', 'capture_runtime_environment.py',
    'run_serial_performance_gate.py', 'run_performance_under_load_gate.py', 'shared_slot_keys_startup_probes.py',
    'summarize_runtime_suite.py',
]]
methods += [Path('tools/bench_compare.py'), Path('tests/regrtest/expectations.toml'),
            Path('crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py')]
methods += list(Path('target/borrowed-keyword-defaults-inputs').rglob('*.py'))
methods += list(Path('target/borrowed-keyword-defaults-inputs').rglob('preparation.json'))
def hashes(names):
    return {str(p): hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(names)}
out.write_text(json.dumps({'sources': hashes(paths), 'methods': hashes(methods)}, indent=2) + '\n')
before = Path('target/borrowed-keyword-defaults-preimages/lib.rs').read_text()
after = Path('crates/weavepy-vm/src/lib.rs').read_text()
Path('target/borrowed-keyword-defaults-review.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='positional-predecessor/lib.rs', tofile='candidate/lib.rs')))
print('Frozen', len(paths), 'source identities and', len(methods), 'methods/inputs.')

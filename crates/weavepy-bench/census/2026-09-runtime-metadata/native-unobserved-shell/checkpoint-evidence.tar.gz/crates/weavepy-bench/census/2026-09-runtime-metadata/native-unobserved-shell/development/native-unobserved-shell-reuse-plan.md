# Reuse unobserved native activation shells: proposed trial

This is an unapplied performance experiment. Finish and archive all four phase
76 timing stages before editing runtime code, building, or testing.

A narrower step than full native-frame materialization is to keep one shell in
its own CallCtx only while nobody has materialized or retained that shell.
Use a Cell<Option<Rc<FrameShell>>>. Take the option before invoking arbitrary
Python, leaving the cell empty for the entire callback. Create a shell only on
a miss. Refresh the exact call-site lasti before pushing the existing shell.
After the callback and raw spine pop, keep the shell only if it is still
unmaterialized and Rc::get_mut proves exclusive ownership (including no weak
owners). Keep all borrows out of the callback. Drop all other shells with the
existing behavior. Each of the four CallCtx construction sites initializes the
cell empty. Framed entries pass through and never allocate this cache.

Only the current native activation retains the reusable allocation. Its code,
cells, globals, and builtins already have identical owning references in that
CallCtx, so the shell must not prolong a Python object beyond the activation.
The locals cell is still the existing empty native mirror. It must not retain
callback arguments, results, or temporary payloads. No cross-activation pool or
new raw pointer is needed. Check all shell-local accesses for observability.

This deliberately leaves the separately verified native-frame identity mismatch
unresolved: a materialized shell is never reused. It also does not claim to fix
native f_locals, final lasti, frame.clear, or continuation identity. Do not hide
those limitations behind an allocation counter or a passing conformance suite.
The broader correct materialization design remains in native-frame-shell-followup.md.

Before changes, run a portable callback oracle on CPython and the predecessor
in JIT/interpreter/GIL-disabled modes. Cover repeated callbacks, changing call
sites, nested callback chains, captured frame code/line stability after later
calls, global mutation/deoptimization, raised callbacks without replay, weak
lifetimes, and recursion. Keep separate observed-frame audit outputs even when
they document baseline divergences. Add test-only counters for actual fresh
shell allocation, reuse, and observed/shared rejection; require native reuse
and rejection paths to execute. No release instrumentation. Reuse the existing
argument-path oracle and unchanged 26-fixture coverage set. Inspect generated
CallCtx/entry stack sizes, since one extra field is not a stack reduction claim.

Measure all inherited controls plus explicit repeated and single-callback
controls. Establish independent CPython output oracles and untimed compiled-path
coverage before timing. Preserve the exact phase 76 inputs and fixed executable.
Use the same exclusive lease, load gate, frozen caches, alternating pairs, full
24-fixture census, startup probes, and direct retained-baseline comparison.
Record every gain and regression, all method/source identities, and failed
attempts. The user goal remains unachieved.

#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test ! -e target/niche-string-owner-vm-tests-01.txt
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/niche-string-owner-vm-tests-01.txt 2>&1
cargo test --offline --locked -p weavepy-capi -j 1 > target/niche-string-owner-capi-tests-01.txt 2>&1
cargo clippy --offline --locked -p weavepy-cli -p weavepy-capi --all-targets -j 1 -- -D warnings > target/niche-string-owner-clippy-01.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/niche-string-owner-nojit-check.txt 2>&1
MIRIFLAGS='-Zmiri-strict-provenance' cargo +nightly miri test --offline --manifest-path target/niche-string-owner-integrated-api/Cargo.toml > target/niche-string-owner-integrated-miri-arm64-01.txt 2>&1
MIRIFLAGS='-Zmiri-strict-provenance' cargo +nightly miri test --offline --target i686-unknown-linux-gnu --manifest-path target/niche-string-owner-integrated-api/Cargo.toml > target/niche-string-owner-integrated-miri-i686-01.txt 2>&1
python3.14 - <<'PY'
from pathlib import Path
import json, hashlib
names = ['crates/weavepy-vm/src/shared_value.rs', 'crates/weavepy-vm/src/tuple_storage.rs',
         'target/niche-string-owner-integrated-api/src/lib.rs',
         'target/niche-string-owner-integrated-api/Cargo.toml', 'target/niche-string-owner-integrated-api/Cargo.lock',
         'target/niche-string-owner-integrated-miri-arm64-01.txt', 'target/niche-string-owner-integrated-miri-i686-01.txt']
for name in names[-2:]:
    assert 'test result: ok. 14 passed' in Path(name).read_text(), name
report = {'purpose': 'Exact integrated storage modules with Object/CachedHash stubs; 14 strict-provenance Miri tests each on ARM64 and i686. Not whole-VM validation or formal soundness proof.',
          'hashes': {name: hashlib.sha256(Path(name).read_bytes()).hexdigest() for name in names}}
out = Path('target/niche-string-owner-integrated-miri-report.json')
assert not out.exists()
out.write_text(json.dumps(report, indent=2) + '\n')
PY

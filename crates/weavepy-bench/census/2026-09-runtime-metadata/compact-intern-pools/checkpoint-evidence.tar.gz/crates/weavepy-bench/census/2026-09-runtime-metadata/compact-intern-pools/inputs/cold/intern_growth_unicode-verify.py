import importlib.util
import json
spec = importlib.util.spec_from_file_location("intern_control", '/Users/owencarey/Documents/weavefoundry/weavepy/target/compact-intern-inputs/cold/intern_growth_unicode.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(10000)
for _ in range(6):
    module.bench(10000)
last = module.bench(10000)
print(json.dumps(first))
print(json.dumps(last))

#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/binder-flags-validation-stage.txt)" = done
python3.14 - <<'CHECK'
import json
from pathlib import Path
assert json.loads(Path('target/binder-flags-coverage/report.json').read_text())['assertions_passed']
assert json.loads(Path('target/binder-flags-signature-paths-v3/report.json').read_text())['assertions_passed']
assert json.loads(Path('target/binder-flags-extra-checks/report.json').read_text())['status']=='passed'
CHECK
output=target/binder-flags-focused
test ! -e "$output"
mkdir "$output"
base="$(cat target/binder-flags-previous.txt)"
reference="$(cat target/binder-flags-reference.txt)"
binary=target/release/weavepy-runtime-binder-flags
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf 'ten original call shapes\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/bound-native-entry-inputs/calls --out "$output/calls" --samples 7 > "$output/calls.txt" 2>&1
printf 'ten signature storage controls\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/binder-flag-inputs-v3 --out "$output/signatures" --samples 7 > "$output/signatures.txt" 2>&1
printf 'four warm exception frequencies\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/bound-native-entry-inputs/exceptions --out "$output/exceptions" --samples 7 > "$output/exceptions.txt" 2>&1
printf 'four cold exception frequencies\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components_with_reference.py --binary "$binary" --previous "$base" --reference "$reference" --inputs target/bound-native-entry-inputs/cold-exceptions --out "$output/cold-exceptions" --samples 7 --cold > "$output/cold-exceptions.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
python3.14 target/summarize_binder_flags.py > "$output/summary.txt" 2>&1
printf 'done\n' > "$output/stage.txt"

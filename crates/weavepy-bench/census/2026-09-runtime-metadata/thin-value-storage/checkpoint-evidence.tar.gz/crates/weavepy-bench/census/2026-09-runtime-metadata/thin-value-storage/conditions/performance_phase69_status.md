# Reduce general value storage

Comparison guards and comparison-return fusion were deferred after complete
validation and paired measurements. The latter archive has 250 selected files,
1,335,042 bytes; all stored/uncompressed hashes verified. Strong simple-control
gains coexist with repeatable 11-14 percent complex-callback losses and a
0.24 percent full workload regression versus ed99. No universal win exists.

After archive verification, three owned JIT files were restored to the exact
ed99 assertion snapshot. The two owned comparison-only Python tests were
removed only after exact archive-content checks. All 147 original source/test
hashes now match ed99, and target/release/weavepy was restored to the verified
ed99 executable. The deferred e709 and c277 binaries and evidence remain local.
Earlier assertion, intern, binding, and raise optimizations remain active.
The overall goal is unachieved. No new commit or push was made in this turn.

Next: a carefully measured value-layout experiment. Current Object has FOUR
wide owners: Str, WStr, Bytes, and Tuple (TupleStorage has an unsized [Object]
tail). All four must be addressed to shrink Object. Two standalone prototypes
retain standard Arc/Weak ownership; their exact source and ordinary/Miri evidence
are archived in thin-owner-prototypes (24 files, 49,113 bytes). The generic
header/tail prototype also passes Miri on i686 for pointer/atomic alignment.
These checks aren't a soundness proof or a VM/memory/performance result.
No runtime memory-layout migration has started yet. Need preserve UTF-8 and
surrogates, interned identity, tuple hash/recycling and destructors, weak C API
owners, exported buffers, frozen caches, and cross-thread behavior. Measure
both shared populations and unique short strings/bytes, where added length
metadata can offset smaller Object slots. Don't assume a universal improvement.

## Integration progress

The value layout is now integrated in 45 existing Rust source files plus the
new shared_value.rs, a layout example, and Python ownership regressions. The
JIT crate has a documentation-only storage-name update; its generated-code
logic is unchanged from ed99. Compiler source and the independent non-atomic
type-cache names are unchanged. All preimages are retained with 274 hashes.

Actual ARM64 layout: Object 16 bytes (previously 24), DictKey 16, Option<Object>
16, SharedStr/SharedSlice/SharedTuple 8 each. Tuple allocations add a length word
before their existing cached hash. Strings/bytes add a length word. No runtime
speed or RSS conclusion has been measured yet.

Final VM unit tests: 347 passed. C API: 34 unit plus nine loader integration
tests passed. Strict lint checks and the build without JIT passed. Miri checks
of the exact integrated storage modules pass eight tests on ARM64 and i686;
Object/CachedHash are stubs in this standalone harness. Current evidence is
in thin-value-storage-integrated-miri-report.json and the v2 Miri logs.
Earlier compile/lint failures and all draft revisions remain in target.

The first Python tuple-hash test expected uncached successful hashes and failed
on CPython 3.14. Its source and output are retained. Corrected semantics pass
on CPython and ed99 in JIT, interpreter, and GIL-disabled modes. All 27 workload
inputs likewise agree on those four variants (108 verified runs).

336 runtime/source/configuration hashes and 75 method/input hashes were frozen
immediately before the release build. Build session 62902 is active; no timing
gate exists. Next: finish release, source/binary snapshot, 87 targeted checks,
275 established compatibility checks, eight additional nonempty storage/C API
suites, then gated focused and full comparisons. Keep all regressions and
failures. Goal remains unachieved; no commit or push made in this continuation.

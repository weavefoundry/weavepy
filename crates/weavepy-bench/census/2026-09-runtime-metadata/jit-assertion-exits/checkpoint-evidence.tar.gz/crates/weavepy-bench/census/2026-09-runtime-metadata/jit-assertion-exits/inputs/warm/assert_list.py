
def leaf(values):
    assert len(values) > 0, f"empty values {values}"
    return values[0] + 1
def bench(n):
    values = [3, 4, 5]
    total = 0
    for i in range(n):
        total += leaf(values)
    return total

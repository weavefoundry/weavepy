"""Require complete validation and unchanged binary, source, and method identities."""
import hashlib
import json
from pathlib import Path

def read(name):
    return json.loads(Path(name).read_text())

for group in read('target/compact-arc-clone-prebuild.json').values():
    for name, digest in group.items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
env = read('target/compact-arc-clone-source-snapshot/environment.json')
for label in ['new', 'previous']:
    value = env['binaries'][label]
    assert hashlib.sha256(Path(value['path']).read_bytes()).hexdigest() == value['sha256'], label
assert hashlib.sha256(Path('target/release/weavepy-runtime-thin-value-storage').read_bytes()).hexdigest() == 'bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4'
validation = read('target/compact-arc-clone-validation/validation.json')
assert len(validation) == 275 and all(r['passed'] for r in validation)
assert read('target/compact-arc-clone-extra-checks/report.json')['status'] == 'passed'
assert Path('target/compact-arc-clone-check-stage.txt').read_text().strip() == 'done'
assert 'test result: ok. 355 passed' in Path('target/compact-arc-clone-vm-tests-01.txt').read_text()
assert 'test result: ok. 34 passed' in Path('target/compact-arc-clone-capi-tests-01.txt').read_text()
assert 'test result: FAILED' not in Path('target/compact-arc-clone-capi-tests-01.txt').read_text()
for arch in ['arm64', 'i686']:
    assert 'test result: ok. 16 passed' in Path(f'target/compact-arc-clone-integrated-miri-{arch}-01.txt').read_text()
for name in ['clippy-01', 'nojit-check']:
    assert 'Finished' in Path(f'target/compact-arc-clone-{name}.txt').read_text()
assert read('target/compact-arc-clone-layout.json')['Object'] == 16
print('Unchanged candidate and methods verified; marshal divergences remain explicit.')

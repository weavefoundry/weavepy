
from datetime import datetime, timedelta, timezone
base = datetime(2000, 1, 1, 3, 5, 7, 11, tzinfo=timezone.utc)
step = timedelta(minutes=37, seconds=11, microseconds=7)
def bench(n):
    current = base
    total = 0
    for i in range(n):
        current = current + step
        total += current.day + current.minute
    return total

"""Freeze native activation-shell reuse and declared measurement methods."""
from pathlib import Path
import hashlib
import json
import difflib

out = Path('target/native-unobserved-shell-prebuild.json')
assert not out.exists()
original = json.loads(Path('target/ascii-time-format-prebuild.json').read_text())['sources']
changed = [p for p, digest in original.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest() != digest]
assert set(changed) == {'crates/weavepy-vm/src/tier2.rs', 'crates/weavepy-vm/src/lib.rs'}, changed
paths = set(original)
paths.add('tests/regrtest/test_native_activation_shell_reuse.py')
methods = [Path('target') / name for name in [
    'build_native_unobserved_shell.sh', 'check_native_unobserved_shell.sh', 'check_native_unobserved_shell_native.sh', 'check_native_unobserved_shell_native_02.sh', 'native-unobserved-shell-owner-check-review.md', 'native-unobserved-shell-pre-owner-check-v1/retention.json',
    'validate_native_unobserved_shell.sh', 'measure_native_unobserved_shell_focused.sh', 'measure_native_unobserved_shell_full.sh',
    'summarize_native_unobserved_shell.py', 'verify_native_unobserved_shell_ready.py', 'freeze_native_unobserved_shell_sources.py',
    'native-unobserved-shell-protocol.md', 'prepare_native_unobserved_shell_inputs.py', 'prepare_native_unobserved_shell_inputs_v2.py', 'prepare_native_unobserved_shell_methods.py',
    'check_native_unobserved_shell_coverage.py', 'check_native_unobserved_shell_frame_identity.py', 'native-unobserved-shell-input-oracles-v2.json', 'native-unobserved-shell-oracle.py', 'native-unobserved-shell-baseline-oracles/report.json', 'inspect_native_unobserved_shell_codegen.py', 'native-frame-shell-identity-audit/probe.py',
    'measure_verified_python_components.py', 'freeze_runtime_candidate.py', 'capture_runtime_environment.py',
    'run_serial_performance_gate.py', 'run_performance_under_load_gate.py', 'shared_slot_keys_startup_probes.py',
    'summarize_runtime_suite.py',
]]
methods += [Path('tools/bench_compare.py'), Path('tests/regrtest/expectations.toml'),
            Path('crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py')]
methods += list(Path('target/native-unobserved-shell-inputs-v2').rglob('*.py'))
methods += list(Path('target/native-unobserved-shell-inputs-v2').rglob('preparation.json'))
def hashes(names):
    return {str(p): hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(names)}
out.write_text(json.dumps({'sources': hashes(paths), 'methods': hashes(methods)}, indent=2) + '\n')
diff = []
for name in changed:
    before = (Path('target/native-unobserved-shell-preimages') / Path(name).name).read_text()
    after = Path(name).read_text()
    diff += difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='predecessor/' + name, tofile='candidate/' + name)
Path('target/native-unobserved-shell-review.diff').write_text(''.join(diff))
print('Frozen', len(paths), 'source identities and', len(methods), 'methods/inputs.')

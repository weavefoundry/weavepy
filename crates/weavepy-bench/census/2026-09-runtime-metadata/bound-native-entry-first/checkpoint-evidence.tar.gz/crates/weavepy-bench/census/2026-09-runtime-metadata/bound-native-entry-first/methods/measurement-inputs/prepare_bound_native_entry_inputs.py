"""Freeze component and hook controls before candidate measurements."""
import hashlib
import json
from pathlib import Path

root=Path('target/bound-native-entry-inputs');root.mkdir()

def save_group(group, work, cases):
    directory=root/group;directory.mkdir()
    rows={}
    for name,source in cases.items():
        path=directory/(name+'.py');path.write_text(source)
        driver=directory/(name+'-verify.py')
        driver.write_text(f'''import json, sys, types
module = types.ModuleType("_weavepy_bench")
module.__file__ = {str(path)!r}
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
first = module.bench({work})
for unused in range(3):
    module.bench({work})
last = module.bench({work})
print(json.dumps(first, sort_keys=True))
print(json.dumps(last, sort_keys=True))
''')
        rows[name]={'path':str(path),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                    'driver':str(driver),'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest()}
    (directory/'preparation.json').write_text(json.dumps({'work':work,'rows':rows},indent=2)+'\n')

shapes={}
for path in sorted(Path('target/pickle-special-lookup-individual-calls').glob('*.py')):
    source=path.read_text()
    source=source.split('\nfor unused in range(3):')[0]
    shapes[path.stem]=source
assert len(shapes)==7
shapes['keyword_only'] = """def leaf(a, *, b=2):
    return a + b

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(b=3, a=i)
    return total
"""
shapes['closure'] = """def outer(value):
    def leaf(a, b=2):
        return value + a + b
    return leaf
leaf = outer(7)

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(b=3, a=i)
    return total
"""
shapes['many_locals'] = """def leaf(a, b=2, c=3, d=4):
    x = a + b
    y = x + c
    z = y + d
    w = z + a
    return w

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(d=5, a=i)
    return total
"""
save_group('calls', 10000, shapes)
(root/'protocol.md').write_text("""# Post-binding native entry experiment

Compare one frozen candidate against its declared retained predecessor and
CPython 3.14.7. Before timing, pass the baseline and candidate argument-binding
regressions, native coverage proof, VM/static checks, targeted observer/lifetime/
recursion/side-exit tests, and full standard compatibility checks. Source and
executable identities must be preserved. No competing heavy work or runtime or
active harness edits during timing.

Ten call shapes use work=10000 with seven paired samples, JIT and interpreter
modes for each WeavePy binary and CPython. This includes positional/defaults,
sparse and variadic keywords, methods, bound methods, builtins, keyword-only,
closure, and extra-local-slot cases. Value checks additionally use -X gil=0.
Keep all samples, failures, and cache/load/VM/swap observations. The shared
harness uses one declared unmeasured cache stabilization cycle and alternating
variant order. No sample filtering or automatic retry.

Run the historical full 24-fixture census and nine startup/import cases after
the focused screen; report the 21-row historical cohort separately from the
23 workload timers and all 24 process metric rows. Busy-host diagnostics cannot
replace the preceding qualified headline. Any declared quiet-host gate must
retain its result even if it expires without starting measurements. No claims
of universal, energy, controlled build, portability, or free-threaded gains.
""")
print('Prepared ten call-shape controls with source and driver checksums.')

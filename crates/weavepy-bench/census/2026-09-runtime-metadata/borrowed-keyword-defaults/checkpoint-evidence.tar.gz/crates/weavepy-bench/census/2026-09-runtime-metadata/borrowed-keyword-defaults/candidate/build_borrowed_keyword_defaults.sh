#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-thin-value-storage
binary=target/release/weavepy-runtime-borrowed-keyword-defaults
test ! -e "$binary"
test ! -e target/borrowed-keyword-defaults-build-stage.txt
cargo fmt --all -- --check > target/borrowed-keyword-defaults-format.txt 2>&1
python3.14 target/freeze_borrowed_keyword_defaults_sources.py
printf 'release build\n' > target/borrowed-keyword-defaults-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/borrowed-keyword-defaults-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/borrowed-keyword-defaults-source-snapshot --extra target/build_borrowed_keyword_defaults.sh target/check_borrowed_keyword_defaults.sh target/validate_borrowed_keyword_defaults.sh target/measure_borrowed_keyword_defaults_focused.sh target/measure_borrowed_keyword_defaults_full.sh target/measure_verified_python_components.py target/borrowed-keyword-defaults-protocol.md target/verify_borrowed_keyword_defaults_ready.py target/freeze_borrowed_keyword_defaults_sources.py target/summarize_borrowed_keyword_defaults.py > target/borrowed-keyword-defaults-snapshot.txt 2>&1
printf 'done\n' > target/borrowed-keyword-defaults-build-stage.txt

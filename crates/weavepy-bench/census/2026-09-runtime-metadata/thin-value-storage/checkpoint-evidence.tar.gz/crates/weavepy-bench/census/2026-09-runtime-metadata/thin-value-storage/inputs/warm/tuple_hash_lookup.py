
keys = [(i, 'key-' + str(i), bytes([i])) for i in range(256)]
values = {key: i for i, key in enumerate(keys)}
def bench(n):
    total = 0
    for i in range(n):
        total += values[keys[i & 255]]
    return total

"""Run nonempty comparison, integer, rich-comparison, and call suites."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

root = Path('target/comparison-call-fusion-extra-checks')
root.mkdir()
runner = 'target/release/weavepy-conformance'
report = {'purpose': __doc__, 'runner_sha256': hashlib.sha256(Path(runner).read_bytes()).hexdigest(), 'runs': {}}

def selected_and_passed(run):
    match = re.search(r'(\d+) total .*?pass (\d+) / fail (\d+) / error (\d+).*?unexpected (\d+)', run['stdout'])
    if match is None:
        return False
    total, passed, failures, errors, unexpected = map(int, match.groups())
    return run['returncode'] == 0 and total > 0 and total == passed and failures == errors == unexpected == 0

for case in ['test_compare', 'test_richcmp', 'test_long', 'test_call', 'test_extcall', 'test_unittest']:
    report['runs'][case] = {}
    for label, binary in [('new', 'target/release/weavepy-runtime-comparison-call-fusion'), ('previous', 'target/release/weavepy-runtime-integer-comparison-guards')]:
        digest = hashlib.sha256(Path(binary).read_bytes()).hexdigest()
        env = dict(os.environ, WEAVEPY_JIT='1', WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
                   WEAVEPY_FROZEN_CACHE=str((root/'frozen'/digest).resolve()))
        command = [runner, 'regrtest', '--all-cpython', '--mode', 'subprocess', '--weavepy', binary,
                   '--filter', 'cpython/Lib/test/' + case + ('' if case == 'test_unittest' else '.py'), '--stream']
        result = subprocess.run(command, env=env, text=True, capture_output=True, timeout=900)
        run = report['runs'][case][label] = {'binary_sha256': digest, 'command': command, 'returncode': result.returncode,
                                           'stdout': result.stdout, 'stderr': result.stderr}
        run['nonempty_and_passed'] = selected_and_passed(run)
        (root/'report.json').write_text(json.dumps(report, indent=2)+'\n')
        print(case, label, result.returncode, 'nonempty pass:', run['nonempty_and_passed'], result.stdout[-1800:], flush=True)
        if run['nonempty_and_passed']:
            break
report['status'] = 'passed' if all(r['new']['nonempty_and_passed'] for r in report['runs'].values()) else 'needs_review'
(root/'report.json').write_text(json.dumps(report, indent=2)+'\n')
raise SystemExit(0 if report['status'] == 'passed' else 1)

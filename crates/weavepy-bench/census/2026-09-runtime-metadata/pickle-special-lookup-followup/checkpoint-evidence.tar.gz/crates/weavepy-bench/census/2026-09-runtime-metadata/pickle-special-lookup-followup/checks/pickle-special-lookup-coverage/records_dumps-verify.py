import sys, types, pickle, json
module = types.ModuleType("_weavepy_bench")
module.__file__ = 'target/pickle-component-probes/records_dumps.py'
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
module.protocol = 5
payload = getattr(module, 'records')
module.blob = pickle.dumps(payload, protocol=5)
cp_blob = None
if cp_blob is not None:
    module.blob = bytes.fromhex(cp_blob)
result = module.once()
if 'dumps' == 'dumps':
    blob = result
    back = pickle.loads(blob)
else:
    blob = module.blob
    back = result
if 'records' == 'payload':
    assert back == payload
    shape = [len(back['ints']), len(back['floats']), len(back['strs']), len(back['nested']), len(back['tuples']), len(back['bytes'])]
else:
    def describe(records):
        return [[item.ident, item.name, [[p.x, p.y, p.tag] for p in item.points], item.meta] for item in records]
    shape = describe(back)
    assert shape == describe(payload)
    assert all(type(item) is module.Record for item in back)
    assert all(type(p) is module.Point for item in back for p in item.points)
print(json.dumps({'blob_hex': blob.hex(), 'blob_bytes': len(blob), 'shape': shape}, sort_keys=True))

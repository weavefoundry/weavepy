"""Report explicit benchmark cohorts and every recorded performance metric."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--suite', type=Path, required=True)
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
assert not a.out.exists()
suite = json.loads(a.suite.read_text())
rows = suite['rows']
historical_path = Path('crates/weavepy-bench/census/2026-09-runtime-metadata/headline-cohorts/historical-baseline.json')
historical = json.loads(historical_path.read_text())
historical_names = [row['name'] for row in historical['rows']]
assert len(historical_names) == 21 and all(name in rows for name in historical_names)
geomean = lambda values: math.exp(statistics.mean(math.log(value) for value in values))
report = {'purpose': __doc__, 'suite_path': str(a.suite),
          'suite_sha256': hashlib.sha256(a.suite.read_bytes()).hexdigest(),
          'binaries': suite['binaries'], 'samples_per_variant': suite['samples'],
          'historical_cohort_sha256': hashlib.sha256(historical_path.read_bytes()).hexdigest(),
          'aggregation': 'Geometric mean of per-fixture medians of paired ratios, unless explicitly labeled ratio_of_medians.',
          'cohorts': {}, 'rows': {}}
groups = [('historical_21_including_startup', historical_names, ['ns']),
          ('all_23_workloads_excluding_startup', [name for name in rows if name != 'startup'], ['ns']),
          ('all_processes_including_startup', list(rows), ['wall_ns', 'cpu_ns', 'rss_bytes'])]
for label, names, metrics in groups:
    group = report['cohorts'][label] = {'fixtures': names, 'count': len(names), 'metrics': {}}
    for mode in ['jit', 'interp']:
        group['metrics'][mode] = {}
        for metric in metrics:
            group['metrics'][mode][metric] = {
                'new_over_cpython': geomean([rows[n]['cpython_comparisons'][mode][metric] for n in names]),
                'new_over_base': geomean([rows[n]['comparisons'][mode][metric] for n in names]),
                'weavepy_wins': sum(rows[n]['cpython_comparisons'][mode][metric] < 1 for n in names),
                'base_regressions': sum(rows[n]['comparisons'][mode][metric] > 1 for n in names),
            }
        variant = 'new' if mode == 'jit' else 'new_interp'
        if label == 'historical_21_including_startup':
            group['metrics'][mode]['ratio_of_medians_new_over_cpython'] = geomean([
                rows[n][variant]['ns'] / rows[n]['cpython']['ns'] for n in names])
for name, row in rows.items():
    assert row['frozen_cache']['unchanged'], name
    report['rows'][name] = {'work': row['work'], 'new_over_base': row['comparisons'],
                           'new_over_cpython': row['cpython_comparisons']}
a.out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['cohorts'], indent=2))

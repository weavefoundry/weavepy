import importlib.util
import json
spec = importlib.util.spec_from_file_location("intern_control", '/Users/owencarey/Documents/weavefoundry/weavepy/target/compact-intern-inputs/warm/intern_hits_16.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(20000)
for _ in range(6):
    module.bench(20000)
last = module.bench(20000)
print(json.dumps(first))
print(json.dumps(last))

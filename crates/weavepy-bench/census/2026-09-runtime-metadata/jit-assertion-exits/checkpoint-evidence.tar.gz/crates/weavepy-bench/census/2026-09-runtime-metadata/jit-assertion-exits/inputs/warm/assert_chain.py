
def leaf(value):
    assert 0 <= value <= 1000000, ("too low" if value < 0 else "too high")
    return value + 1
def bench(n):
    total = 0
    for i in range(n):
        total += leaf(i)
    return total

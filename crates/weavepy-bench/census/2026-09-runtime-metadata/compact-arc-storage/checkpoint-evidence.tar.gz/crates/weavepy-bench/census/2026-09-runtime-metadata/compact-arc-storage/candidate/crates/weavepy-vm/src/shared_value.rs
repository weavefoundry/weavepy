//! Shared immutable values with compact pointer metadata.
//!
//! Keeping a 64-bit pointer and seven metadata bytes in each owner leaves room
//! for the Object discriminant in a 16-byte value slot. Strings and slices keep
//! their standard Arc allocation layout, without a separate length header.
//! Full-size metadata remains available through an escape representation.
use std::borrow::Borrow;
use std::fmt;
use std::hash::{Hash, Hasher};
use std::marker::PhantomData;
use std::mem::{size_of, ManuallyDrop};
use std::ops::Deref;
use std::ptr::{self, NonNull};
use std::sync::{Arc, Weak};

mod sealed {
    pub trait Sealed {}
}

/// Metadata needed to reconstruct exactly the original Arc pointee.
///
/// # Safety
/// metadata and pointer must round-trip every valid pointee, preserving its
/// address, metadata, size, alignment, validity, and destruction. Implementations
/// are sealed and may not infer a different allocation or modify the pointee.
pub unsafe trait ArcMetadata: sealed::Sealed {
    fn metadata(&self) -> usize;
    fn pointer(data: *const (), metadata: usize) -> *const Self;
}
impl<T> sealed::Sealed for [T] {}
// SAFETY: a slice's only pointer metadata is its unchanged element count.
unsafe impl<T> ArcMetadata for [T] {
    fn metadata(&self) -> usize {
        self.len()
    }
    fn pointer(data: *const (), len: usize) -> *const Self {
        ptr::slice_from_raw_parts(data.cast::<T>(), len)
    }
}
impl sealed::Sealed for str {}
// SAFETY: str has byte-slice metadata, and only valid Arc<str> values enter.
unsafe impl ArcMetadata for str {
    fn metadata(&self) -> usize {
        self.len()
    }
    fn pointer(data: *const (), len: usize) -> *const Self {
        ptr::slice_from_raw_parts(data.cast::<u8>(), len) as *const str
    }
}

const POINTER_BYTES: usize = size_of::<usize>();
const METADATA_BYTES: usize = if POINTER_BYTES == 8 { 7 } else { POINTER_BYTES };
const INDIRECT: [u8; METADATA_BYTES] = [u8::MAX; METADATA_BYTES];

/// An Arc strong reference with compact pointer metadata.
///
/// On 64-bit targets the handle is 15 bytes, aligned to one byte. Packed fields
/// are copied by value; no references to the potentially unaligned pointer are
/// formed. Metadata that doesn't fit is stored in an individually owned Box of
/// the original Arc, so compact metadata never imposes an allocation-size cap.
#[repr(C, packed)]
pub struct CompactArc<T: ?Sized + ArcMetadata> {
    data: NonNull<()>,
    metadata: [u8; METADATA_BYTES],
    ownership: PhantomData<Arc<T>>,
}
// SAFETY: the pointer only owns Arc references. These are Arc's Send/Sync
// bounds; packed pointer fields are read by value without misaligned references.
unsafe impl<T: ?Sized + ArcMetadata + Send + Sync> Send for CompactArc<T> {}
unsafe impl<T: ?Sized + ArcMetadata + Send + Sync> Sync for CompactArc<T> {}

pub struct CompactWeak<T: ?Sized + ArcMetadata>(Weak<T>);
impl<T: ?Sized + ArcMetadata> CompactArc<T> {
    pub fn from_arc(arc: Arc<T>) -> Self {
        let len = arc.metadata();
        let bytes = len.to_le_bytes();
        let mut metadata = [0; METADATA_BYTES];
        metadata.copy_from_slice(&bytes[..METADATA_BYTES]);
        if bytes[METADATA_BYTES..].iter().any(|&b| b != 0) || metadata == INDIRECT {
            return Self::indirect(arc);
        }
        let raw = Arc::into_raw(arc).cast::<()>().cast_mut();
        Self {
            // SAFETY: Arc::into_raw returns a non-null, live allocation pointer.
            data: unsafe { NonNull::new_unchecked(raw) },
            metadata,
            ownership: PhantomData,
        }
    }
    fn indirect(arc: Arc<T>) -> Self {
        Self {
            data: NonNull::from(Box::leak(Box::new(arc))).cast(),
            metadata: INDIRECT,
            ownership: PhantomData,
        }
    }
    #[inline]
    fn inline_metadata(&self) -> usize {
        let mut bytes = [0; POINTER_BYTES];
        // Read exactly the stored bytes. An eight-byte load from a seven-byte
        // field could overread the enclosing owner, so don't use one here.
        bytes[..METADATA_BYTES].copy_from_slice(&self.metadata);
        usize::from_le_bytes(bytes)
    }
    #[inline]
    fn raw(&self) -> *const T {
        if self.metadata == INDIRECT {
            // SAFETY: this handle uniquely owns this Box<Arc<T>>. The Arc in
            // that box owns one reference to the original payload.
            let arc = unsafe { &*self.data.cast::<Arc<T>>().as_ptr() };
            Arc::as_ptr(arc)
        } else {
            T::pointer(self.data.as_ptr(), self.inline_metadata())
        }
    }
    #[inline]
    fn arc_view(&self) -> ManuallyDrop<Arc<T>> {
        // SAFETY: borrow our one accounted strong reference without releasing
        // it. For indirect handles the Box still owns that same Arc reference.
        ManuallyDrop::new(unsafe { Arc::from_raw(self.raw()) })
    }
    #[inline]
    pub fn as_ptr(this: &Self) -> *const T {
        this.raw()
    }
    #[inline]
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        Arc::ptr_eq(&this.arc_view(), &other.arc_view())
    }
    pub fn strong_count(this: &Self) -> usize {
        Arc::strong_count(&this.arc_view())
    }
    pub fn weak_count(this: &Self) -> usize {
        Arc::weak_count(&this.arc_view())
    }
    pub fn downgrade(this: &Self) -> CompactWeak<T> {
        CompactWeak(Arc::downgrade(&this.arc_view()))
    }
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        let mut view = this.arc_view();
        let raw = ptr::from_mut(Arc::get_mut(&mut view)?);
        // SAFETY: Arc checked unique strong ownership and no weak references.
        // The returned borrow is tied to &mut this; the temporary view neither
        // adds nor releases ownership. Slice metadata cannot change through it.
        unsafe { Some(&mut *raw) }
    }
}
impl<T: ?Sized + ArcMetadata> Clone for CompactArc<T> {
    #[inline]
    fn clone(&self) -> Self {
        Self::from_arc(Arc::clone(&self.arc_view()))
    }
}
impl<T: ?Sized + ArcMetadata> Drop for CompactArc<T> {
    #[inline]
    fn drop(&mut self) {
        if self.metadata == INDIRECT {
            // SAFETY: exactly this strong handle owns this Box and its Arc.
            // Other indirect clones have distinct boxes and their own Arcs.
            unsafe { drop(Box::from_raw(self.data.cast::<Arc<T>>().as_ptr())) }
        } else {
            // SAFETY: release exactly the strong reference consumed by from_arc.
            unsafe { drop(Arc::from_raw(self.raw())) }
        }
    }
}
impl<T: ?Sized + ArcMetadata> Deref for CompactArc<T> {
    type Target = T;
    #[inline]
    fn deref(&self) -> &T {
        // SAFETY: reconstruction preserves the original initialized pointee,
        // which remains alive through this owner's accounted Arc reference.
        unsafe { &*self.raw() }
    }
}
impl<T: ?Sized + ArcMetadata> AsRef<T> for CompactArc<T> {
    fn as_ref(&self) -> &T {
        self
    }
}
impl<T: ?Sized + ArcMetadata + fmt::Debug> fmt::Debug for CompactArc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}
impl<T: ?Sized + ArcMetadata + PartialEq> PartialEq for CompactArc<T> {
    fn eq(&self, other: &Self) -> bool {
        **self == **other
    }
}
impl<T: ?Sized + ArcMetadata + Eq> Eq for CompactArc<T> {}
impl<T: ?Sized + ArcMetadata + PartialOrd> PartialOrd for CompactArc<T> {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        (**self).partial_cmp(&**other)
    }
}
impl<T: ?Sized + ArcMetadata + Ord> Ord for CompactArc<T> {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        (**self).cmp(&**other)
    }
}
impl<T: ?Sized + ArcMetadata + Hash> Hash for CompactArc<T> {
    fn hash<H: Hasher>(&self, h: &mut H) {
        (**self).hash(h)
    }
}
impl<T: ?Sized + ArcMetadata> CompactWeak<T> {
    pub fn upgrade(&self) -> Option<CompactArc<T>> {
        self.0.upgrade().map(CompactArc::from_arc)
    }
    pub fn strong_count(&self) -> usize {
        self.0.strong_count()
    }
    pub fn weak_count(&self) -> usize {
        self.0.weak_count()
    }
}
impl<T: ?Sized + ArcMetadata> Clone for CompactWeak<T> {
    fn clone(&self) -> Self {
        Self(self.0.clone())
    }
}
impl<T: ?Sized + ArcMetadata> fmt::Debug for CompactWeak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.0, f)
    }
}
pub type SharedSlice<T> = CompactArc<[T]>;
pub type WeakSlice<T> = CompactWeak<[T]>;
pub type SharedStr = CompactArc<str>;
pub type WeakStr = CompactWeak<str>;
impl<T> Borrow<[T]> for SharedSlice<T> {
    fn borrow(&self) -> &[T] {
        self
    }
}
impl Borrow<str> for SharedStr {
    fn borrow(&self) -> &str {
        self
    }
}
impl<T> From<Vec<T>> for SharedSlice<T> {
    fn from(value: Vec<T>) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl<T> From<Box<[T]>> for SharedSlice<T> {
    fn from(value: Box<[T]>) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl<T: Clone> From<&[T]> for SharedSlice<T> {
    fn from(value: &[T]) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl<T: Clone, const N: usize> From<&[T; N]> for SharedSlice<T> {
    fn from(value: &[T; N]) -> Self {
        Self::from(&value[..])
    }
}
impl From<&str> for SharedStr {
    fn from(value: &str) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl From<String> for SharedStr {
    fn from(value: String) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl From<&String> for SharedStr {
    fn from(value: &String) -> Self {
        Self::from(value.as_str())
    }
}
impl From<Box<str>> for SharedStr {
    fn from(value: Box<str>) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl fmt::Display for SharedStr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

impl sealed::Sealed for crate::tuple_storage::TupleStorage {}
// SAFETY: TupleStorage is repr(C) with a final [Object] tail. Its metadata is
// exactly that tail's element count. Reconstructing the original data address
// and length preserves the hash header, payload alignment, and Arc destruction.
unsafe impl ArcMetadata for crate::tuple_storage::TupleStorage {
    fn metadata(&self) -> usize {
        self.len()
    }
    fn pointer(data: *const (), len: usize) -> *const Self {
        ptr::slice_from_raw_parts(data.cast::<crate::object::Object>(), len) as *const Self
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;
    use std::sync::atomic::{AtomicUsize, Ordering};

    #[test]
    fn strings_preserve_utf8_hash_lookup_and_data_identity() {
        for text in ["", "a", "x\0y", "mañana", "日本語", "🧶🙂", "e\u{301}"] {
            let value = SharedStr::from(text);
            assert_eq!(&*value, text);
            assert_eq!(SharedStr::as_ptr(&value).cast::<u8>(), value.as_ptr());
            assert_eq!(
                value.chars().collect::<Vec<_>>(),
                text.chars().collect::<Vec<_>>()
            );
            let mut set = HashSet::new();
            set.insert(value.clone());
            assert!(SharedStr::ptr_eq(set.get(text).unwrap(), &value));
            assert_eq!(SharedStr::from(text.to_owned()), value);
            assert_eq!(SharedStr::from(text.to_owned().into_boxed_str()), value);
            let weak = SharedStr::downgrade(&value);
            assert_eq!(SharedStr::weak_count(&value), 1);
            drop(set);
            assert_eq!(weak.strong_count(), 1);
            assert!(SharedStr::ptr_eq(&weak.upgrade().unwrap(), &value));
            drop(value);
            assert!(weak.upgrade().is_none());
            assert_eq!(weak.strong_count(), 0);
        }
    }

    #[test]
    fn copy_slices_preserve_empty_boundaries_alignment_and_identity() {
        for n in [0, 1, 2, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 65, 257] {
            let input: Vec<u32> = (0..n).map(|i| 0xd800 + i).collect();
            let copy = SharedSlice::from(input.as_slice());
            let moved = SharedSlice::from(input.clone());
            let boxed = SharedSlice::from(input.clone().into_boxed_slice());
            assert_eq!(&*copy, input.as_slice());
            assert_eq!(copy, moved);
            assert_eq!(copy, boxed);
            assert_eq!(CompactArc::as_ptr(&copy).cast::<u32>(), copy.as_ptr());
            let clone = copy.clone();
            assert!(CompactArc::ptr_eq(&copy, &clone));
            assert!(!CompactArc::ptr_eq(&copy, &moved));
            assert_eq!(CompactArc::strong_count(&copy), 2);
        }
        assert_eq!(&*SharedSlice::from(&[1_u128, u128::MAX]), &[1, u128::MAX]);
        assert_eq!(SharedSlice::from(vec![(); 5]).len(), 5);
        assert_eq!(SharedSlice::from(&[(); 7]).len(), 7);
    }

    #[test]
    fn element_destructors_wait_for_last_strong_but_not_weak_owner() {
        struct Item(Arc<AtomicUsize>);
        impl Drop for Item {
            fn drop(&mut self) {
                self.0.fetch_add(1, Ordering::SeqCst);
            }
        }
        for n in [0, 1, 2, 15, 33, 64] {
            let drops = Arc::new(AtomicUsize::new(0));
            let value = SharedSlice::from((0..n).map(|_| Item(drops.clone())).collect::<Vec<_>>());
            let clone = value.clone();
            let weak = CompactArc::downgrade(&value);
            let second_weak = weak.clone();
            assert_eq!(weak.weak_count(), 2);
            drop(value);
            assert_eq!(drops.load(Ordering::SeqCst), 0);
            assert_eq!(weak.upgrade().unwrap().len(), n);
            drop(clone);
            assert_eq!(drops.load(Ordering::SeqCst), n);
            assert!(weak.upgrade().is_none());
            assert!(second_weak.upgrade().is_none());
            drop(weak);
            drop(second_weak);
            assert_eq!(drops.load(Ordering::SeqCst), n);
        }
    }

    #[test]
    fn unique_access_rejects_strong_and_weak_aliases() {
        let mut value = SharedSlice::from(&[11_u8, 22, 33]);
        let clone = value.clone();
        assert!(CompactArc::get_mut(&mut value).is_none());
        drop(clone);
        let weak = CompactArc::downgrade(&value);
        assert!(CompactArc::get_mut(&mut value).is_none());
        drop(weak);
        assert_eq!(CompactArc::get_mut(&mut value).unwrap(), &[11, 22, 33]);
    }

    #[test]
    fn weak_upgrades_and_shared_text_survive_thread_handoffs() {
        let value = SharedStr::from("shared 🧶 text");
        let weak = SharedStr::downgrade(&value);
        std::thread::scope(|scope| {
            for _ in 0..2 {
                let weak = weak.clone();
                scope.spawn(move || {
                    for _ in 0..20 {
                        let local = weak.upgrade().unwrap();
                        assert_eq!(&*local, "shared 🧶 text");
                        assert_eq!(local.chars().count(), 13);
                    }
                });
            }
        });
        drop(value);
        assert!(weak.upgrade().is_none());
    }
}

#[cfg(test)]
mod compact_metadata_tests {
    use super::*;
    use std::collections::HashSet;
    use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};

    #[test]
    fn text_hashes_utf8_and_payload_addresses_match_arc() {
        for text in ["", "a", "x\0y", "mañana", "日本語", "🧶🙂", "e\u{301}"] {
            let original: Arc<str> = Arc::from(text);
            let owner = SharedStr::from_arc(original.clone());
            assert_eq!(SharedStr::as_ptr(&owner), Arc::as_ptr(&original));
            assert_eq!(&*owner, text);
            assert_eq!(SharedStr::strong_count(&owner), 2);
            let mut set = HashSet::new();
            set.insert(owner.clone());
            assert!(SharedStr::ptr_eq(set.get(text).unwrap(), &owner));
            assert_eq!(SharedStr::from(text.to_owned()), owner);
            assert_eq!(SharedStr::from(text.to_owned().into_boxed_str()), owner);
            let weak = SharedStr::downgrade(&owner);
            assert_eq!(weak.strong_count(), 3);
            drop(set);
            drop(original);
            assert!(SharedStr::ptr_eq(&owner, &weak.upgrade().unwrap()));
            assert_eq!(SharedStr::weak_count(&owner), 1);
            drop(owner);
            assert_eq!(weak.strong_count(), 0);
            assert!(weak.upgrade().is_none());
        }
    }

    #[test]
    fn moved_and_copied_slices_keep_values_identity_and_alignment() {
        for n in [0, 1, 2, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 65, 257] {
            let values: Vec<u32> = (0..n).map(|i| 0xd800 + i).collect();
            let copied = SharedSlice::from(values.as_slice());
            let moved = SharedSlice::from(values.clone());
            let boxed = SharedSlice::from(values.clone().into_boxed_slice());
            assert_eq!(&*copied, values.as_slice());
            assert_eq!(copied, moved);
            assert_eq!(copied, boxed);
            assert_eq!(SharedSlice::as_ptr(&copied).cast::<u32>(), copied.as_ptr());
            assert!(SharedSlice::ptr_eq(&copied, &copied.clone()));
            assert!(!SharedSlice::ptr_eq(&copied, &moved));
        }
        assert_eq!(&*SharedSlice::from(&[1_u128, u128::MAX]), &[1, u128::MAX]);
        assert_eq!(SharedSlice::from(vec![(); 5]).len(), 5);
        #[repr(align(64))]
        struct Aligned(u32);
        let aligned = SharedSlice::from(vec![Aligned(19), Aligned(23)]);
        assert_eq!(aligned.as_ptr().align_offset(64), 0);
        assert_eq!(aligned.clone()[1].0, 23);
    }

    #[test]
    fn destructible_elements_drop_at_last_strong_before_weak_release() {
        struct Item(Arc<AtomicUsize>, usize);
        impl Drop for Item {
            fn drop(&mut self) {
                self.0.fetch_add(1, Ordering::SeqCst);
            }
        }
        for n in [0, 1, 2, 7, 15, 33, 64] {
            let drops = Arc::new(AtomicUsize::new(0));
            let owner =
                SharedSlice::from((0..n).map(|i| Item(drops.clone(), i)).collect::<Vec<_>>());
            for (i, value) in owner.iter().enumerate() {
                assert_eq!(value.1, i);
            }
            let clone = owner.clone();
            let weak = SharedSlice::downgrade(&owner);
            let second = weak.clone();
            assert_eq!(weak.weak_count(), 2);
            drop(owner);
            assert_eq!(drops.load(Ordering::SeqCst), 0);
            assert_eq!(weak.upgrade().unwrap().len(), n);
            drop(clone);
            assert_eq!(drops.load(Ordering::SeqCst), n);
            assert!(weak.upgrade().is_none());
            assert!(second.upgrade().is_none());
            drop(weak);
            drop(second);
            assert_eq!(drops.load(Ordering::SeqCst), n);
        }
    }

    #[test]
    fn unique_mutation_rejects_strong_and_weak_aliases() {
        let mut owner = SharedSlice::from(&[11_u128, 22, 33]);
        let clone = owner.clone();
        assert!(SharedSlice::get_mut(&mut owner).is_none());
        drop(clone);
        let weak = SharedSlice::downgrade(&owner);
        assert!(SharedSlice::get_mut(&mut owner).is_none());
        drop(weak);
        SharedSlice::get_mut(&mut owner).unwrap()[1] = 88;
        assert_eq!(&*owner, &[11, 88, 33]);
    }

    #[test]
    fn boxed_and_inline_handles_share_exact_arc_counts_and_identity() {
        let original: Arc<[u8]> = Arc::from(&b"boxed value"[..]);
        let mut boxed = SharedSlice::indirect(original.clone());
        assert_eq!(boxed.metadata, INDIRECT);
        assert_eq!(SharedSlice::as_ptr(&boxed), Arc::as_ptr(&original));
        let clone = boxed.clone();
        assert_ne!(clone.metadata, INDIRECT);
        let weak = SharedSlice::downgrade(&boxed);
        assert_eq!(SharedSlice::strong_count(&boxed), 3);
        assert!(SharedSlice::ptr_eq(&boxed, &clone));
        let upgrade = weak.upgrade().unwrap();
        assert!(SharedSlice::ptr_eq(&boxed, &upgrade));
        assert_eq!(SharedSlice::strong_count(&boxed), 4);
        assert!(SharedSlice::get_mut(&mut boxed).is_none());
        drop(original);
        drop(clone);
        drop(upgrade);
        assert!(SharedSlice::get_mut(&mut boxed).is_none());
        drop(weak);
        SharedSlice::get_mut(&mut boxed).unwrap()[0] = b'B';
        assert_eq!(&*boxed, b"Boxed value");
    }

    #[test]
    fn extreme_zero_sized_lengths_use_full_metadata_without_a_size_cap() {
        let mut max_inline_bytes = [0; POINTER_BYTES];
        max_inline_bytes[..METADATA_BYTES].copy_from_slice(&INDIRECT);
        let escape = usize::from_le_bytes(max_inline_bytes);
        for len in [Some(escape), escape.checked_add(123)]
            .into_iter()
            .flatten()
        {
            // SAFETY: () has no bytes and exactly one valid value. No uninitialized
            // data is read, even at these lengths; the Arc allocation is just its
            // normal reference-count block and the slice has zero total bytes.
            let original: Arc<[()]> = unsafe { Arc::<[()]>::new_uninit_slice(len).assume_init() };
            let mut owner = SharedSlice::from_arc(original.clone());
            assert_eq!(owner.metadata, INDIRECT);
            assert_eq!(owner.len(), len);
            assert_eq!(SharedSlice::as_ptr(&owner), Arc::as_ptr(&original));
            let clone = owner.clone();
            assert_eq!(clone.metadata, INDIRECT);
            assert_eq!(SharedSlice::strong_count(&owner), 3);
            let weak = SharedSlice::downgrade(&owner);
            let upgrade = weak.upgrade().unwrap();
            assert_eq!(upgrade.len(), len);
            assert_eq!(upgrade.metadata, INDIRECT);
            assert!(SharedSlice::ptr_eq(&owner, &upgrade));
            assert_eq!(SharedSlice::strong_count(&owner), 4);
            drop(original);
            drop(clone);
            drop(upgrade);
            assert!(SharedSlice::get_mut(&mut owner).is_none());
            drop(weak);
            assert_eq!(SharedSlice::get_mut(&mut owner).unwrap().len(), len);
        }
    }

    #[repr(C)]
    struct HeaderSlice<T: ?Sized> {
        hash: AtomicU64,
        items: T,
    }
    impl sealed::Sealed for HeaderSlice<[u128]> {}
    // SAFETY: real Arc unsizing supplies the unchanged length of the final slice.
    unsafe impl ArcMetadata for HeaderSlice<[u128]> {
        fn metadata(&self) -> usize {
            self.items.len()
        }
        fn pointer(data: *const (), len: usize) -> *const Self {
            ptr::slice_from_raw_parts(data.cast::<u128>(), len) as *const Self
        }
    }

    #[test]
    fn header_and_tail_keep_their_original_arc_layout_and_unique_mutation() {
        let original: Arc<HeaderSlice<[u128]>> = Arc::new(HeaderSlice {
            hash: AtomicU64::new(7),
            items: [11_u128, 22, 33],
        });
        let mut owner = CompactArc::from_arc(original.clone());
        assert_eq!(CompactArc::as_ptr(&owner), Arc::as_ptr(&original));
        assert_eq!(owner.hash.load(Ordering::Relaxed), 7);
        assert_eq!(owner.items, [11, 22, 33]);
        drop(original);
        let weak = CompactArc::downgrade(&owner);
        assert!(CompactArc::get_mut(&mut owner).is_none());
        drop(weak);
        let value = CompactArc::get_mut(&mut owner).unwrap();
        value.hash.store(19, Ordering::Relaxed);
        value.items[1] = 88;
        assert_eq!(owner.hash.load(Ordering::Relaxed), 19);
        assert_eq!(owner.items, [11, 88, 33]);
    }

    #[test]
    fn shared_owners_and_weak_upgrades_survive_thread_handoffs() {
        let owner = SharedStr::from("shared 🧶 text");
        let weak = SharedStr::downgrade(&owner);
        std::thread::scope(|scope| {
            for _ in 0..2 {
                let weak = weak.clone();
                scope.spawn(move || {
                    for _ in 0..20 {
                        let value = weak.upgrade().unwrap();
                        assert_eq!(&*value, "shared 🧶 text");
                        assert_eq!(value.chars().count(), 13);
                    }
                });
            }
        });
        drop(owner);
        assert!(weak.upgrade().is_none());
    }
}

import copyreg, json
class Example:
    def __getstate__(self):
        return {'value': 7}
obj = Example()
method = copyreg._lookup_special(obj, '__getstate__')
print(json.dumps({'binding_type': type(method).__name__,
                  'function_type_has_get': hasattr(type(Example.__getstate__), '__get__'),
                  'state': method()}, sort_keys=True))

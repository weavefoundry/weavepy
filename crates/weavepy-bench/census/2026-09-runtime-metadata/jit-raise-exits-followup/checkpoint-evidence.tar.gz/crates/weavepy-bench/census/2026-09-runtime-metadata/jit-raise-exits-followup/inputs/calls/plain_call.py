def plain_call(n):
    return n * 3 + 1

def bench(n):
    total = 0
    for i in range(n):
        total += plain_call(i)
    return total

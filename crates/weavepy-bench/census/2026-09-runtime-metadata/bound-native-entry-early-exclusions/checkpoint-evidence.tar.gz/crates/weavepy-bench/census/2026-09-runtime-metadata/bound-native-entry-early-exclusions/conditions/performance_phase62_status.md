# Early post-binding exclusions

The complete ca6b experiment is archived in bound-native-entry-first (304 files,
3,205,131 bytes; every indexed SHA verified). Its excluded-call regressions are
not accepted as an all-metrics win. No owned timing/build job was active when
the new guard order was applied against the verified lib.rs base hash.

This candidate moves already-bound variadic/keyword-only and live closure
exclusions before code flags and removes redundant code cell/free checks that
native_callable/native_method_callable already enforce in direct_entry_for.
It keeps generator families on the frame path and leaves tier2 unchanged.
No new allocation, cache, field, or unsafe code. Correctness/performance unknown.
Compare to retained 539c, preserve ca6b as a separate complete experiment.

49872 CLOSED 0. All 342 VM tests passed, followed by formatting, Clippy, the
build without default features, and the release CLI. Candidate 95b52f651d09d96af2a892077dd4731954e89e2fd73b369418e16ae7b06aa492 is 44,290,720 bytes,
the same size as ca6b and 160 bytes more than 539c. Snapshot and all prebuild
runtime/measurement hashes verified. 69188 is running the 60 targeted release
checks and instrumented binding test outside the filesystem sandbox.

Separate argument-binder-flags-draft is unapplied: small signatures use 16 inline
binding flags, larger signatures a heap slice, and the extent includes only
parameter/*args/**kwargs slots. It preserves a distinct filled marker rather
than assuming Object::Unbound can never be passed internally. Boundary tests
are prepared but haven't run. No runtime edits during current checks/timing.

69188 CLOSED 0: all 60 targeted checks plus instrumented regression passed.
33502 CLOSED 0: ten native-entry CPython oracles passed, followed by all 275
standard compatibility checks. 70855 CLOSED 0: all five extra suites passed.
Binder storage baseline preflight also CLOSED 0: CPython, retained 539c, and
95b in JIT/interpreter/gil0 pass every boundary case. No binder draft applied.
Assembly diagnostic saved: call_python_owned reserves 0x650 after its 0x60
register save, 16 bytes fewer than ca6b and 96 fewer than 539c. This is layout
evidence only. All validation jobs finished before the timing gate below.

76533 CLOSED 0: all 18 focused cases completed with seven paired samples for
all five variants, exact CPython values and frozen caches passed. The load gate
qualified, but 1-minute load later rose above five. Very wide paired timing
ranges affect both modes. Sparse keyword median new/539c = 0.8504, many locals
= 0.6601; keyword-only = 1.2887 and closure = 1.1214, with broad ranges crossing
one. These medians do not prove that the earlier exclusion regressions are fixed.
No completed samples were selected or repeated.

51233 CLOSED 0: full qualified run completed all 24 fixtures x five pairs and
nine startup/import controls x 31 pairs. Every later sample, load observation,
and VM/swap record is retained. Call overhead median new/539c = about 0.928;
several attribute/generator/container controls remain slower. Sources and
methods stayed unchanged throughout both runs. Full exact cohort numbers are
in early-bound-entry-full/summary.json. This refinement stays experimental.
The next binder experiment will use both immediate 95b and retained 539c
references to expose, rather than conceal, the combined effect.

#[allow(dead_code)]
#[path = "compact-arc-clone-prototype-v2/src/lib.rs"]
mod owner;
#[no_mangle]
pub fn clone_shared_string(value: &owner::SharedStr) -> owner::SharedStr {
    value.clone()
}
#[no_mangle]
pub fn clone_shared_bytes(value: &owner::SharedSlice<u8>) -> owner::SharedSlice<u8> {
    value.clone()
}

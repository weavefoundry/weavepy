"""Require complete validation and unchanged binary, source, and method identities."""
import hashlib
import json
from pathlib import Path

def read(name):
    return json.loads(Path(name).read_text())

for group in read('target/compact-arc-storage-prebuild.json').values():
    for name, digest in group.items():
        assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
env = read('target/compact-arc-storage-source-snapshot/environment.json')
for label in ['new', 'previous']:
    value = env['binaries'][label]
    assert hashlib.sha256(Path(value['path']).read_bytes()).hexdigest() == value['sha256'], label
assert hashlib.sha256(Path('target/release/weavepy-runtime-jit-assertion-exits').read_bytes()).hexdigest() == 'ed99cdbaf8e403eb7de9e3cbac86687748481596443b0e5055a77057c57a0a29'
validation = read('target/compact-arc-storage-validation/validation.json')
assert len(validation) == 275 and all(r['passed'] for r in validation)
assert read('target/compact-arc-storage-extra-checks/report.json')['status'] == 'passed'
assert Path('target/compact-arc-storage-check-stage.txt').read_text().strip() == 'done'
assert 'test result: ok. 355 passed' in Path('target/compact-arc-storage-vm-tests-01.txt').read_text()
assert 'test result: ok. 34 passed' in Path('target/compact-arc-storage-capi-tests-02.txt').read_text()
assert 'test result: FAILED' not in Path('target/compact-arc-storage-capi-tests-02.txt').read_text()
for arch in ['arm64', 'i686']:
    assert 'test result: ok. 16 passed' in Path(f'target/compact-arc-storage-integrated-miri-{arch}-01.txt').read_text()
for name in ['clippy-01', 'nojit-check']:
    assert 'Finished' in Path(f'target/compact-arc-storage-{name}.txt').read_text()
assert read('target/compact-arc-storage-layout.json')['Object'] == 16
print('Unchanged candidate and methods verified; marshal divergences remain explicit.')

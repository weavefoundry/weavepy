# Full explicit-raise diagnostic under recorded host load

The strict full-census load gate expired after 600 seconds with status
`not_started`. No benchmark child or samples were produced. Keep that result.
This is one separate diagnostic without a quiet-host precondition. Compare
frozen baseline 8899e367 with corrected candidate 539c6dd3 and CPython 3.14.7.
Run all nine startup/import cases with 31 paired samples and all 24 standard
fixtures with five paired samples. Keep all timings, failures, regressions,
and telemetry; do not select, discard, or retry samples based on load.
Use the same immutable fixture work parameters and isolated frozen caches.

Report the original 21-row timing cohort and the full 23-workload cohort
separately, plus all 24 process wall/CPU/RSS rows. Startup/import helper
measurements use JIT disabled; the standard suite also includes JIT modes.
Record swap and VM statistics before and after. Small differences are
provisional under host contention. Do not replace the earlier quiet census
or claim universal, energy, build-time, or free-threaded superiority.

No builds, tests, profiles, runtime edits, or active harness edits during the
run. The only launcher change from the strict run is a fresh output path.

# Guarded pickle hook lookup comparison

Compare the separately frozen lookup candidate against corrected raise-exit
binary 539c6dd3 and CPython 3.14.7. Use JIT and interpreter modes for both
WeavePy binaries, plus exact result checks with -X gil=0. Preserve all samples,
regressions, failures, frozen-cache identities, and host-load telemetry.

Four unchanged pickle components use work=20 and seven hook-reduction controls
use work=1000. Every case has seven paired timed samples after an explicit
unmeasured cache stabilization cycle; alternating variant order is fixed by
the shared harness. Component byte/value oracles and the new Python regression
must pass first. Native-helper assertions verify that the new path is reached;
custom descriptors and metaclasses must fall back before user callbacks.

Attempt the existing strict load gate (one- and five-minute load <=4, three
observations ten seconds apart, maximum wait 600 seconds). A timeout produces
no measurements. Any later busy-host diagnostic must be separately declared
with fresh outputs and retained telemetry. No sample selection or retries.

Record process wall time, CPU time, peak RSS, and timed workload wall/CPU
metrics. Do not infer energy, controlled build cost, universal superiority,
or free-threaded performance from these results. Run standard full-suite and
startup/import controls after focused correctness/performance, with explicit
21-row historical and 23-workload timing cohorts. Do not run competing builds,
tests, profiles, or edit runtime/active harnesses during measurement.

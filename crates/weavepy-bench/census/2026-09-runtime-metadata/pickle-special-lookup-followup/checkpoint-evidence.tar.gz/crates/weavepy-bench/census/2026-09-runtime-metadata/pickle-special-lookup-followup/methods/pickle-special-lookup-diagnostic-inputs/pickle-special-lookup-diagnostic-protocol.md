# Separately declared pickle lookup diagnostic

Run only if the original strict load gate expires without starting any child
measurement. Keep that gate result and every original input unchanged. If the
strict gate starts measurements, do not run this fallback diagnostic.

This diagnostic has no quiet-host precondition. It uses the same eleven cases,
unchanged work parameters, seven paired samples, five timing variants, value
checks, and isolated frozen caches. It compares candidate 5201c72e with 539c6dd3
and CPython 3.14.7. Preserve every sample, failure, regression, and load
observation. Do not select favorable results or retry measured samples.

Require the completed correctness gates first. All 275 standard checks, 45
targeted checks, exact pickle component oracles, actual path assertions, and
the explicit copy/copyreg suites passed. Property and exotic-key fallback
behavior matches the predecessor. Existing differences from CPython remain
recorded separately; these checks do not claim complete language parity.

Record VM statistics and swap before and after. Treat small performance
changes as provisional under contention. This cannot replace a controlled
quiet-host comparison or establish universal/energy/build/free-threaded gains.
No competing builds, tests, profiles, runtime edits, or active harness edits
while the measurement runs. Use fresh diagnostic outputs.

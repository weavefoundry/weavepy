"""Preserve positional-default gains and the unresolved broader regressions."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

subprocess.run(['python3.14', 'target/verify_borrowed_defaults_ready.py'], check=True)
base = Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out = base / 'borrowed-defaults'
assert not out.exists()
for label in ['focused-retained', 'full-retained']:
    gate = json.loads(Path(f'target/borrowed-defaults-{label}-load.json').read_text())
    assert gate['status'] == 'complete' and gate['returncode'] == 0
    assert Path(f'target/borrowed-defaults-{label}/stage.txt').read_text().strip() == 'done'
out.mkdir()
index, destinations = [], set()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def add(source, relative):
    source = Path(source)
    raw = source.read_bytes()
    data = raw
    relative = Path(relative)
    if len(raw) > 32768 and source.suffix in {'.json', '.jsonl', '.txt', '.rs', '.diff', '.s'}:
        data = gzip.compress(raw, mtime=0)
        relative = Path(str(relative) + '.gz')
    assert str(relative) not in destinations, relative
    destinations.add(str(relative))
    dest = out / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    index.append({'path': str(relative), 'source': str(source), 'bytes': len(data), 'sha256': sha(data),
                  'uncompressed_bytes': len(raw), 'uncompressed_sha256': sha(raw)})
def tree(source, prefix, exclude=()):
    for path in sorted(Path(source).rglob('*')):
        relative = path.relative_to(source)
        if path.is_file() and not any(part in exclude for part in relative.parts):
            add(path, Path(prefix) / relative)
tree('target/borrowed-defaults-source-snapshot', 'candidate')
for label in ['focused-retained', 'full-retained']:
    tree(f'target/borrowed-defaults-{label}', label, ['frozen', 'startup'])
for group in ['checks', 'validation', 'preimages']:
    tree(f'target/borrowed-defaults-{group}', group, ['frozen'])
for path in sorted(Path('target').glob('borrowed-defaults*')):
    if path.is_file() and path.name != 'borrowed-defaults-export.txt':
        add(path, Path('development') / path.name)
for name in ['performance_phase73_status.md', 'prepare_borrowed_defaults_methods.py',
             'prepare_borrowed_defaults_inputs.py', 'check_borrowed_defaults_native.sh',
             'export_borrowed_defaults.py', 'niche-string-owner-restoration.json']:
    add(Path('target') / name, Path('development') / name)
for name in json.loads(Path('target/borrowed-defaults-prebuild.json').read_text())['methods']:
    add(name, Path('methods') / name)

full = json.loads(Path('target/borrowed-defaults-full-retained/summary.json').read_text())
focused = json.loads(Path('target/borrowed-defaults-focused-retained/summary.json').read_text())
lines = ['# Borrow overridden positional defaults', '',
    'Decision: preserve this candidate for refinement. The targeted binding gain',
    'is consistent, but the broader JIT process and memory results do not establish',
    'an overall improvement. Retained bf2 remains the acceptance reference. The',
    'candidate remains active only as the source for the next experiment; do not',
    'present it as a universally faster replacement. The user goal is unachieved.', '',
    'Candidate: `44c5ae82231f44182d2aac1b216d64fccdf712edce4b812baff573d3ea39befb`,',
    '44,096,928 bytes. Reference: retained bf2,',
    '`bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4`,',
    '44,097,168 bytes. This is a same-run comparison against bf2 only.', '',
    'The only runtime change is one block in lib.rs. A cloned function-slot value',
    'keeps the override tuple alive while its elements are borrowed. Only defaults',
    'filling missing positional arguments are cloned. The temporary vector of all',
    'overridden defaults is removed. Suffix selection, None clearing, compiled',
    'defaults, keyword-only defaults, errors, and native eligibility remain.',
    'No unsafe operation or ownership/allocation layout was added or changed.', '',
    'The new Python ownership oracle passes on CPython and bf2 in JIT, interpreter,',
    'and GIL-disabled modes. It covers partial and oversized defaults, code',
    'replacement, bound receivers, errors, aliases, and weak-reference lifetime',
    'when a callee clears its defaults. Independent length/count checks validate',
    'all 12 focused fixture results under CPython.', '',
    'Validation passed 347 VM tests, 156 C API tests, strict lint and format,',
    'no-JIT compilation, all 90 targeted Python checks, and all 275 outside-sandbox',
    'compatibility checks. Optional extension tests may check availability internally.',
    'The safe borrowing change adds no new raw ownership behavior requiring a',
    'repeat of earlier Miri experiments. All 337 source identities and 72 method/',
    'input identities remained unchanged through the build and measurements.', '',
    'The release compiler reported 5m21s; an earlier format check was unusually',
    'slow but succeeded. Neither duration is a controlled build-time comparison.',
    'Both timing stages used the serial lease and unchanged outside-sandbox load',
    'gate, completed sequentially, and retained every sample and load observation.', '',
    'Ratios below 1 favor the candidate. Means aggregate per-fixture medians of',
    'paired ratios. Keep the 21-, 23-, and 24-row cohorts distinct.', '',
    '| Metric | Candidate / bf2 | Candidate / CPython | Wins over CPython |',
    '| --- | ---: | ---: | ---: |']
c = full['cohorts']
w = c['all_23_workloads_excluding_startup']['metrics']
m = c['all_processes_including_startup']['metrics']
for label, row in [('JIT workload time (23)', w['jit']['ns']),
                   ('Interpreter workload time (23)', w['interp']['ns']),
                   ('JIT process wall time (24)', m['jit']['wall_ns']),
                   ('JIT CPU time (24)', m['jit']['cpu_ns']),
                   ('JIT peak RSS (24)', m['jit']['rss_bytes']),
                   ('Interpreter process wall time (24)', m['interp']['wall_ns']),
                   ('Interpreter CPU time (24)', m['interp']['cpu_ns']),
                   ('Interpreter peak RSS (24)', m['interp']['rss_bytes'])]:
    lines.append(f"| {label} | {row['new_over_base']:.9f} | {row['new_over_cpython']:.9f} | {row['weavepy_wins']} |")
lines += ['', 'All seven JIT pairs improve in every actually affected override-default',
    'control, both cold and warm: roughly 2-12% less workload time. The width-one',
    'partial-keyword case supplies every argument and is an unaffected control.',
    'Some all-supplied and compiled-default controls regress about 1-2.5%. Peak',
    'RSS does not improve consistently. These losses remain in the table and data.',
    'The full JIT suite records 15 workload, 19 process-wall/CPU, and 16 peak-RSS',
    'median regressions against bf2. Interpreter aggregates improve slightly.',
    'No confidence or noise argument removes the observed JIT regressions.', '',
    '| Focused control | Time / bf2 | RSS / bf2 | Time wins (7 pairs) |',
    '| --- | ---: | ---: | ---: |']
for name, row in focused['rows'].items():
    v = row['new_over_previous']['jit']
    lines.append(f"| {name} | {v['ns']:.6f} | {v['rss_bytes']:.6f} | {row['pairs']['jit']['ns']['wins']} |")
lines += ['', 'All raw samples, losses, validation outcomes, load observations, VM/swap',
    'snapshots, methods, inputs, and source snapshots remain. Larger text artifacts',
    'use lossless gzip; index.json records stored and original hashes. Executables',
    'and frozen caches remain local. Intermediate status notes are historical.', '',
    'No universal, energy, controlled build-time, portability, or native parallel-',
    'scaling conclusion follows from these measurements.', '']
data = '\n'.join(lines).encode()
(out / 'REPORT.md').write_bytes(data)
index.append({'path': 'REPORT.md', 'bytes': len(data), 'sha256': sha(data)})
(out / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
for row in index:
    data = (out / row['path']).read_bytes()
    assert sha(data) == row['sha256']
    if 'uncompressed_sha256' in row:
        raw = gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert sha(raw) == row['uncompressed_sha256']
allow = {'!borrowed-defaults/'}
for path in out.rglob('*'):
    allow.add('!' + str(path.relative_to(base)) + ('/' if path.is_dir() else ''))
with (base / '.gitignore').open('a') as f:
    f.write('\n# Positional default borrowing and unresolved broader regressions.\n' + '\n'.join(sorted(allow)) + '\n')
with (base / 'README.md').open('a') as f:
    f.write('\nThe [positional-default borrowing trial](borrowed-defaults/REPORT.md) records\nconsistent targeted gains alongside broader JIT regressions. It remains under\nrefinement; bf2 remains the retained acceptance reference.\n')
print('Archived', len(index) + 1, 'files;', sum(p.stat().st_size for p in out.rglob('*') if p.is_file()), 'bytes. All hashes verified.')

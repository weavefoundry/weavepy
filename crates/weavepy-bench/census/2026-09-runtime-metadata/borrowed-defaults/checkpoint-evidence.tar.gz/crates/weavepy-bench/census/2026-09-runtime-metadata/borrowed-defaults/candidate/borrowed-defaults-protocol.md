# Borrow positional default overrides during binding

Compare against retained bf2:
bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4.
Change only the positional-default block in lib.rs: retain the owned slot value,
borrow its tuple elements, and clone only values filling missing positional
arguments. Preserve compiled defaults, suffix selection, clearing with None,
keyword-only defaults, errors, and all native eligibility rules. No new unsafe
code or owner/allocation layout change is introduced.

The new ownership/binding oracle must pass on CPython and the retained binary
before candidate measurement. It covers partial keywords, oversized defaults,
code replacement, bound receivers, required-argument errors, and default object
liveness when the callee clears its defaults. Run the existing 347 VM tests,
full C API package, strict lint/format, and no-JIT check. Build the release CLI
package and freeze all source, method, input, and binary identities. Run 90
targeted Python checks in JIT, interpreter, and GIL-disabled modes, including
the new oracle, plus the unchanged 275-check outside-sandbox compatibility suite.
No new raw ownership operations justify repeating the earlier Miri experiments.

Focused inputs exercise widths 1, 4, 16, and 64 with omitted or partially keyword-bound
override defaults, widths 4 and 64 with all arguments supplied, and widths 4 and 64 with
compiled defaults. The width 1 partial-keyword case supplies every argument and
is a control for skipping default binding. Values are strings to include real
reference ownership. Keep cold first-invocation and warmed repetitions separate.
Each of 12 controls per group uses 20,000 calls. The unchanged sampler verifies
all variants against CPython before and after warmup, including GIL-disabled
correctness, then retains seven alternating pairs and one declared stabilization
cycle per row. Per-binary-SHA frozen caches must remain unchanged.

Run two timing stages sequentially: focused controls, then 31 startup/import
samples and five alternating pairs of the unchanged 24-fixture census. Preserve
historical 21-row, 23-workload, and 24-process cohorts separately. All comparisons
are same-run pairs against bf2. Keep every sample, loss, failure, load observation,
VM/swap snapshot, and identity. All timing stages use run_serial_performance_gate.py
outside the filesystem sandbox; inspect successful completion before launching
the next stage. The unchanged gate requires three 10-second load observations
with one- and five-minute averages at most half the CPU count, waiting at most
600 seconds per attempt. No owned build/test/profile/install, runtime edit, or
active-harness edit may overlap a gate that can launch or a measurement.

The user goal remains unachieved. No universal, energy, controlled build-time,
portability, or native parallel-scaling conclusion follows from these trials.

def outer(value):
    def leaf(a, b=2):
        return value + a + b
    return leaf
leaf = outer(7)

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(b=3, a=i)
    return total

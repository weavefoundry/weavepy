"""Replace an Arc operation only on compiler-identified migrated-owner lines."""
import json, re, sys
from pathlib import Path

log = Path(sys.argv[1])
changes = {}
for line in log.read_text().splitlines():
    try:
        r = json.loads(line)
    except ValueError:
        continue
    if r.get('reason') != 'compiler-message' or r['message']['level'] != 'error':
        continue
    m = r['message']
    rendered = m['rendered']
    if not any(name in rendered for name in ['SharedStr', 'WeakStr', 'ThinArc<', 'ThinWeak<']):
        continue
    for span in m['spans']:
        if not span['is_primary'] or not span['file_name'].startswith('crates/'):
            continue
        p = Path(span['file_name'])
        if p.name == 'types.rs' and span['line_start'] == 248:
            continue  # Independent non-atomic type-cache names retain std::rc::Rc.
        source = p.read_text().splitlines(keepends=True)
        i = span['line_start'] - 1
        old = source[i]
        matches = list(re.finditer(r'(?<![A-Za-z0-9_])(?:(?:crate|weavepy_vm)::sync::)?(?:VmRc|Rc)::(from|as_ptr|ptr_eq|strong_count|weak_count|downgrade|get_mut)', old))
        if len(matches) != 1:
            continue
        match = matches[0]
        op = match.group(1)
        owner = 'SharedStr' if 'SharedStr' in rendered or 'WeakStr' in rendered else ('SharedSlice' if op == 'from' else 'ThinArc')
        prefix = 'crate' if 'weavepy-vm' in p.parts else 'weavepy_vm'
        new = old[:match.start()] + prefix+'::shared_value::'+owner+'::'+op + old[match.end():]
        key = (p, i)
        if key in changes:
            assert changes[key] == (old, new), (key, changes[key], new)
        changes[key] = (old, new)
for (p, i), (old, new) in changes.items():
    lines = p.read_text().splitlines(keepends=True)
    assert lines[i] == old
    lines[i] = new
    p.write_text(''.join(lines))
    print(str(p)+':'+str(i+1), old.strip(), '=>', new.strip())

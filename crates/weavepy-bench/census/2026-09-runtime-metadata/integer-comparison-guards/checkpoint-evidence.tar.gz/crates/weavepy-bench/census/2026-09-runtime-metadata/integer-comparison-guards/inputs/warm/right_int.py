def exact(i):
    return i
def compare(f, i):
    return 2500 > f(i)
def bench(n):
    total = 0
    for i in range(n):
        total += compare(exact, i)
    return total

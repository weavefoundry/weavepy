//! Recursive-descent parser for Python source.
//!
//! Consumes the token stream from [`weavepy_lexer::tokenize`] and
//! produces a [`Module`]. Expression precedence follows the Python
//! language reference; chained comparisons (`a < b < c`) are
//! collapsed into a single [`Compare`] node like CPython does.
//!
//! The parser is hand-written so we own diagnostics end-to-end. The
//! feature set tracks RFC 0001 plus its follow-ups: classes (RFC 0003),
//! exceptions and `with` (RFC 0004), f-strings (RFC 0005), generators
//! (RFC 0006), pattern matching (RFC 0009), and imports (RFC 0012).
//! `async def`/`await` (RFC 0006-B) and PEP 701 nested-quote f-strings
//! (RFC 0005-B) remain explicit `ParseError::NotImplemented`s.

use weavepy_lexer::{Keyword, Span, Token, TokenKind};

use crate::ast::{
    Alias, Arg, Arguments, BinOp, BoolOp, CmpOp, Comprehension, Constant, ExceptHandler, Expr,
    ExprKind, Keyword as KwArg, MatchCase, Module, Pattern, PatternKind, Stmt, StmtKind, TypeParam,
    TypeParamKind, UnaryOp, WithItem,
};
use crate::error::ParseError;

/// Parse a module with PEP 401 `barry_as_FLUFL` optionally pre-activated
/// (the `CO_FUTURE_BARRY_AS_BDFL` compile flag; the parser also flips
/// the flag itself on `from __future__ import barry_as_FLUFL`).
///
/// Also reports pegen's `last_stmt_location`: the `(lineno, col_offset)`
/// of the last statement parsed before the error (or the end of input),
/// `(0, 0)` when none was.
pub(crate) fn parse_with_flufl_tracking(
    source: &str,
    tokens: Vec<Token>,
    flufl: bool,
) -> (Result<Module, ParseError>, crate::ParseMeta) {
    let mut p = Parser::new(source, tokens);
    p.flufl = flufl;
    let module = p.parse_module();
    let module = p.apply_poison(module);
    let meta = p.meta(module.is_err());
    (module, meta)
}

/// [`parse_eval_with_flufl`] that also reports where the parser stopped
/// (see [`crate::ParseMeta`]).
pub(crate) fn parse_eval_tracking(
    source: &str,
    tokens: Vec<Token>,
    flufl: bool,
) -> (Result<Module, ParseError>, crate::ParseMeta) {
    let mut p = Parser::new(source, tokens);
    p.flufl = flufl;
    let module = p.parse_eval_module();
    let module = p.apply_poison(module);
    let meta = p.meta(module.is_err());
    (module, meta)
}

/// Describe a token for [`crate::ParseMeta`].
pub(crate) fn stop_token(t: &Token) -> crate::StopToken {
    crate::StopToken {
        kind: match t.kind {
            TokenKind::Newline => crate::StopKind::Newline,
            TokenKind::Dedent => crate::StopKind::Dedent,
            TokenKind::Endmarker => crate::StopKind::Endmarker,
            _ => crate::StopKind::Other,
        },
        start: t.span.start.0,
        end: t.span.end.0,
        expr_start: matches!(
            t.kind,
            TokenKind::Name
                | TokenKind::Number
                | TokenKind::String
                | TokenKind::LPar
                | TokenKind::LSqb
                | TokenKind::LBrace
                | TokenKind::Minus
                | TokenKind::Plus
                | TokenKind::Tilde
                | TokenKind::Star
                | TokenKind::Ellipsis
                | TokenKind::Keyword(
                    Keyword::Not
                        | Keyword::Lambda
                        | Keyword::Await
                        | Keyword::None
                        | Keyword::True
                        | Keyword::False
                )
        ),
    }
}

/// Parse with CPython's `eval` start rule: `expressions NEWLINE* ENDMARKER`.
///
/// The expression grammar simply has no production for statement syntax,
/// so `eval("x = 1")` / `eval("del x")` fail with a *bare* "invalid
/// syntax" anchored at the first token the rule can't accept (the `=`,
/// the `del`, …) — never with statement-level diagnostics like "cannot
/// assign to f-string expression" (`test_fstring` asserts exactly this).
/// Expression-*internal* diagnostics (a missing `else`, an unclosed
/// bracket, f-string field errors, …) still surface unchanged.
pub(crate) fn parse_eval(source: &str, tokens: Vec<Token>) -> Result<Module, ParseError> {
    parse_eval_with_flufl(source, tokens, false)
}

/// [`parse_eval`] with PEP 401 `barry_as_FLUFL` pre-activated.
pub(crate) fn parse_eval_with_flufl(
    source: &str,
    tokens: Vec<Token>,
    flufl: bool,
) -> Result<Module, ParseError> {
    let mut p = Parser::new(source, tokens);
    p.flufl = flufl;
    let module = p.parse_eval_module()?;
    Ok(module)
}

/// Parse with CPython's `func_type_input` start rule (PEP 484 signature
/// type comments; `compile(..., mode="func_type")`):
/// `'(' [type_expressions] ')' '->' expression NEWLINE* ENDMARKER`.
/// Returns the argument-type expressions and the return-type expression.
pub(crate) fn parse_func_type(
    source: &str,
    tokens: Vec<Token>,
) -> Result<(Vec<Expr>, Expr), ParseError> {
    let mut p = Parser::new(source, tokens);
    p.parse_func_type_input()
}

/// [`parse`] with PEP 484 type-comment collection
/// (`ast.parse(type_comments=True)`). Returns the module plus the
/// side tables of claimed `# type:` comments; a `# type:` comment in a
/// position the grammar gives no TYPE_COMMENT slot is a SyntaxError,
/// like pegen.
pub(crate) fn parse_type_comments(
    source: &str,
    tokens: Vec<Token>,
) -> Result<(Module, TypeComments), ParseError> {
    let mut p = Parser::new_inner(source, tokens, true);
    let module = p.parse_module()?;
    let st = p.type_comments.take().expect("type-comment state");
    if let Some((span, _, _)) = st.pending.iter().find(|(_, _, used)| !*used) {
        return Err(ParseError::Unexpected {
            span: *span,
            message: "misplaced type annotation".to_owned(),
        });
    }
    Ok((
        module,
        TypeComments {
            ignores: st.ignores,
            stmts: st.stmts,
            args: st.args,
        },
    ))
}

struct Parser<'src> {
    source: &'src str,
    tokens: Vec<Token>,
    pos: usize,
    /// PEP 401: `from __future__ import barry_as_FLUFL` is active
    /// (either seen while parsing, or passed as a compile flag). Under
    /// FLUFL, `<>` is the inequality operator and `!=` is a
    /// SyntaxError.
    flufl: bool,
    /// PEP 572: whether the *next* expression production may be an
    /// unparenthesized named expression (`NAME := value`). CPython's
    /// grammar threads `namedexpression` through a fixed set of
    /// productions (if/while conditions, `case` guards, match
    /// subjects, decorators, call *positional* arguments, group /
    /// list / set display elements, list/set/genexp comprehension
    /// elements, non-slice subscripts, f-string replacement fields);
    /// everywhere else `expression !':='` applies and a bare walrus
    /// is "invalid syntax". The flag is one-shot: `parse_ternary`
    /// consumes it at entry, so it never leaks into nested
    /// sub-expressions (`if f(a=b := 1):` still rejects the kwarg).
    walrus_ok: bool,
    /// One-shot marker that the expression being parsed is a lambda's
    /// body. A `:=` trailing the body is left unconsumed so
    /// `parse_lambda` can report CPython's `invalid_named_expression`
    /// message ("cannot use assignment expressions with lambda") —
    /// `lambda: x := 1` names the lambda, not the `x`.
    lambda_body: bool,
    /// One-shot marker that the expression being parsed is a walrus's
    /// *value*. A lambda there followed by `:=` — `(x := lambda: y := 1)`
    /// — is pegen's generic "invalid syntax" (the enclosing walrus
    /// already committed, so `invalid_named_expression` never re-matches
    /// the lambda), unlike the standalone-lambda message above.
    walrus_value: bool,
    /// PEP 484 type-comment collection (`ast.parse(type_comments=True)`);
    /// `None` on the default path, where `# type:` comments stay plain
    /// comments.
    type_comments: Option<TypeCommentState>,
    /// `(lineno, col_offset)` of the most recent successfully parsed
    /// statement (pegen's `last_stmt_location`); see
    /// [`Parser::parse_statement`].
    last_stmt: Option<(u32, u32)>,
    /// Index of the token the grammar first rejected, recorded by the
    /// range-anchored diagnostics that go on to consume more tokens
    /// before raising (pegen's first pass stops there; see
    /// [`Parser::meta`]).
    first_fail: Option<usize>,
    /// Index of the token where the innermost pegen `expression` rule
    /// began ([`Parser::parse_ternary`]); rules keyed on a token *at*
    /// an expression start (the 3.14 `invalid_expression` STRING
    /// alternative) test against it.
    expr_entry: usize,
    /// Index of the token where pegen would attempt `star_targets`
    /// (statement start, and after each `=` of an assignment); the
    /// target grammar runs with `invalid_*` rules on before any
    /// `expression` there gets a chance to poison the memo.
    target_entry: usize,
    /// Index of the token where a `STRING expression+ STRING` probe
    /// failed ([`Parser::check_string_expr_string`]); a later failure of
    /// the ordinary grammar at that same token is reported as pegen
    /// would with its memo poisoned (see [`Parser::apply_poison`]).
    poison: Option<usize>,
    /// Set once [`Parser::apply_poison`] downgraded the error: pegen's
    /// error pass fetched no token past the stop token in that case.
    poisoned: bool,
    /// Furthest token index a diagnostic's lookahead fetched beyond the
    /// failure point (see [`Parser::meta`]).
    peeked: Option<usize>,
}

/// Collected `# type:` comments (CPython's TYPE_COMMENT / TYPE_IGNORE
/// tokens). Claimed comments are attached to statements/arguments by
/// span-start key; an unclaimed non-ignore comment after the parse is a
/// SyntaxError, mirroring pegen (TYPE_COMMENT has no grammar slot there).
#[derive(Default)]
struct TypeCommentState {
    /// Non-ignore `# type:` comments: (comment span, payload, claimed).
    pending: Vec<(Span, String, bool)>,
    /// `# type: ignore<tag>`: (comment start offset, tag), in source order.
    ignores: Vec<(u32, String)>,
    /// Claimed statement comments keyed by the statement's span start.
    stmts: Vec<(u32, String)>,
    /// Claimed per-parameter comments keyed by the arg's span start.
    args: Vec<(u32, String)>,
}

/// Type-comment side tables handed back to the `_ast` bridge alongside
/// the module (offsets are byte offsets into the source).
#[derive(Debug)]
pub struct TypeComments {
    pub ignores: Vec<(u32, String)>,
    pub stmts: Vec<(u32, String)>,
    pub args: Vec<(u32, String)>,
}

/// Match CPython's tokenizer `type_comment_prefix` ("# type: ", where
/// each space in the prefix matches any run of spaces/tabs). Returns the
/// payload after the prefix.
fn type_comment_payload(text: &str) -> Option<&str> {
    let b = text.as_bytes();
    if b.first() != Some(&b'#') {
        return None;
    }
    let mut i = 1;
    while matches!(b.get(i), Some(b' ' | b'\t')) {
        i += 1;
    }
    if !text[i..].starts_with("type:") {
        return None;
    }
    i += 5;
    while matches!(b.get(i), Some(b' ' | b'\t')) {
        i += 1;
    }
    Some(&text[i..])
}

impl<'src> Parser<'src> {
    fn new(source: &'src str, tokens: Vec<Token>) -> Self {
        Self::new_inner(source, tokens, false)
    }

    fn new_inner(source: &'src str, tokens: Vec<Token>, type_comments: bool) -> Self {
        // Strip non-significant newlines and comments up front. The
        // lexer emits `Nl` tokens for physical newlines inside
        // brackets so explicit `\` continuations remain a syntactic
        // option; the parser never needs them as discrete tokens,
        // and removing them lets every collection / call site span
        // multiple lines without bespoke trivia handling.
        //
        // Under `type_comments=True`, `# type:` comments are siphoned
        // into a side table on the way out (CPython's tokenizer turns
        // them into TYPE_COMMENT / TYPE_IGNORE tokens).
        let mut tc = type_comments.then(TypeCommentState::default);
        let tokens = tokens
            .into_iter()
            .filter(|t| {
                if matches!(t.kind, TokenKind::Comment) {
                    if let Some(st) = tc.as_mut() {
                        let text = &source[t.span.start.0 as usize..t.span.end.0 as usize];
                        if let Some(payload) = type_comment_payload(text) {
                            let ignore_tag = payload.strip_prefix("ignore").filter(|rest| {
                                // "ignore" must be followed by EOL or a
                                // non-alphanumeric ASCII char (tokenizer.c:
                                // non-ASCII counts as alphanumeric here).
                                match rest.as_bytes().first() {
                                    None => true,
                                    Some(&c) => c < 128 && !c.is_ascii_alphanumeric(),
                                }
                            });
                            if let Some(tag) = ignore_tag {
                                st.ignores.push((t.span.start.0, tag.to_owned()));
                            } else {
                                st.pending.push((t.span, payload.to_owned(), false));
                            }
                        }
                    }
                    return false;
                }
                !matches!(t.kind, TokenKind::Nl)
            })
            .collect();
        Self {
            source,
            tokens,
            pos: 0,
            flufl: false,
            walrus_ok: false,
            lambda_body: false,
            walrus_value: false,
            type_comments: tc,
            last_stmt: None,
            first_fail: None,
            expr_entry: usize::MAX,
            target_entry: usize::MAX,
            poison: None,
            poisoned: false,
            peeked: None,
        }
    }

    fn lexeme(&self, span: Span) -> &'src str {
        &self.source[span.start.0 as usize..span.end.0 as usize]
    }

    /// Identifier text for a NAME token, NFKC-normalized per PEP 3131.
    ///
    /// CPython normalizes every identifier to Normalization Form KC at
    /// parse time (`unicodeobject.c: _PyUnicode_TransformDecimalAndSpaceToASCII`
    /// → `compile.c`/`tokenizer` actually use `PyUnicode_FromString` +
    /// `unicodedata.normalize('NFKC', …)`), so `µ` (U+00B5) and `μ`
    /// (U+03BC) bind the same name, and the mathematical-alphabet
    /// `𝔘𝔫𝔦𝔠𝔬𝔡𝔢` folds to plain `Unicode`. ASCII identifiers — the
    /// overwhelmingly common case — are already in NFKC, so we return the
    /// borrowed slice without touching the normalizer.
    fn ident(&self, span: Span) -> String {
        let raw = self.lexeme(span);
        if raw.is_ascii() {
            raw.to_owned()
        } else {
            use unicode_normalization::UnicodeNormalization;
            raw.nfkc().collect()
        }
    }

    fn peek(&self) -> &TokenKind {
        &self.tokens[self.pos].kind
    }

    fn peek_token(&self) -> &Token {
        &self.tokens[self.pos]
    }

    /// Post-parse metadata: pegen's `last_stmt_location` plus, after a
    /// failure, the token the parser was looking at when it gave up
    /// (errors propagate with `?` without rewinding, so `self.pos` is
    /// the offending token in practice).
    /// Finish a parse: when the ordinary grammar failed at the very
    /// token a `STRING expression+ STRING` probe had already failed on,
    /// pegen's memo holds that failure with the `invalid_*` rules
    /// switched off, and the specific diagnostic never fires; what's
    /// left is the generic "invalid syntax" at the first pass's last
    /// token.
    fn apply_poison(&mut self, result: Result<Module, ParseError>) -> Result<Module, ParseError> {
        let Err(err) = result else { return result };
        let Some(fail) = self.poison else {
            return Err(err);
        };
        let stop = self.first_fail.unwrap_or(self.pos);
        if stop != fail || !matches!(err, ParseError::Unexpected { .. }) {
            return Err(err);
        }
        self.poisoned = true;
        self.first_fail = Some(fail);
        let span = self.tokens[fail.min(self.tokens.len() - 1)].span;
        Err(ParseError::Unexpected {
            span,
            message: "invalid syntax".to_owned(),
        })
    }

    fn meta(&self, failed: bool) -> crate::ParseMeta {
        let (stop, furthest) = if failed {
            let pos = self.first_fail.unwrap_or(self.pos);
            // pegen's error pass re-parses a rejected token that can
            // start an expression as one (`invalid_expression`,
            // `invalid_class_argument_pattern`, ...), fetching the token
            // after it — and, through a `','.x+` loop, each further
            // comma-separated element's follower.
            let mut i = pos;
            let starts_expr =
                |i: usize| self.tokens.get(i).is_some_and(|t| stop_token(t).expr_start);
            // A memo-poisoned failure ran no `invalid_*` rule that would
            // have looked past the stop token.
            if !self.poisoned && starts_expr(i) {
                i += 1;
                while matches!(self.tokens.get(i).map(|t| &t.kind), Some(TokenKind::Comma)) {
                    // The loop fetches the comma's follower to see
                    // whether another element starts there.
                    i += 1;
                    if !starts_expr(i) {
                        break;
                    }
                    i += 1;
                }
            }
            if let (Some(peeked), false) = (self.peeked, self.poisoned) {
                i = i.max(peeked);
            }
            (
                self.tokens.get(pos).map(stop_token),
                self.tokens.get(i).map(stop_token),
            )
        } else {
            (None, None)
        };
        crate::ParseMeta {
            last_stmt: self.last_stmt.unwrap_or((0, 0)),
            stop,
            furthest,
        }
    }

    fn peek_at(&self, k: usize) -> Option<&TokenKind> {
        self.tokens.get(self.pos + k).map(|t| &t.kind)
    }

    fn bump(&mut self) -> Token {
        let t = self.tokens[self.pos].clone();
        self.pos += 1;
        t
    }

    /// Span of the most recently consumed token. Used to extend a
    /// statement's span to its last token (CPython statement positions
    /// cover the whole statement, not just the keyword).
    fn prev_token_span(&self) -> weavepy_lexer::Span {
        self.tokens[self.pos.saturating_sub(1)].span
    }

    fn check(&self, k: &TokenKind) -> bool {
        self.peek() == k
    }

    fn eat(&mut self, k: &TokenKind) -> bool {
        if self.check(k) {
            self.bump();
            true
        } else {
            false
        }
    }

    fn expect(&mut self, k: &TokenKind, what: &str) -> Result<Token, ParseError> {
        if self.check(k) {
            Ok(self.bump())
        } else {
            // CPython pegen only names the missing token when the line
            // simply stopped short (NEWLINE / EOF): `try` ⏎ says
            // "expected ':'". Anywhere else the generic parse failure is
            // a bare "invalid syntax" pointing at the offending token.
            // Only the punctuation pegen has dedicated `invalid_*` rules
            // for is named (`expected ':'`, `expected '('`); a missing
            // NAME or other token is the bare generic error.
            let named = matches!(what, "`:`" | "`(`" | "'('");
            let message =
                if named && matches!(self.peek(), TokenKind::Newline | TokenKind::Endmarker) {
                    format!("expected {}", what.replace('`', "'"))
                } else {
                    "invalid syntax".to_owned()
                };
            Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message,
            })
        }
    }

    fn at_keyword(&self, kw: Keyword) -> bool {
        matches!(self.peek(), TokenKind::Keyword(k) if *k == kw)
    }

    /// CPython's parse-time assignment-target validation (the PEG
    /// grammar's `invalid_assignment` rules): only Name / Attribute /
    /// Subscript / Starred / Tuple / List can be assigned to; container
    /// targets are validated element-wise. Returns the offending
    /// sub-expression and whether it sat *nested* inside a container
    /// (nested offenders get the bare diagnostic, top-level ones the
    /// "Maybe you meant '=='" hint).
    fn find_invalid_target(e: &Expr, nested: bool) -> Option<(&Expr, bool)> {
        match &e.kind {
            ExprKind::Name(_) | ExprKind::Attribute { .. } | ExprKind::Subscript { .. } => None,
            // The starred wrapper itself is fine (`*a, = xs`); its inner
            // expression is a nested target ( `*f(x), = xs` → bare msg).
            ExprKind::Starred(inner) => Self::find_invalid_target(inner, true),
            ExprKind::Tuple(items) | ExprKind::List(items) => items
                .iter()
                .find_map(|it| Self::find_invalid_target(it, true)),
            _ => Some((e, nested)),
        }
    }

    /// Build CPython's "cannot assign to X" `SyntaxError` for an invalid
    /// assignment target found by [`Parser::find_invalid_target`].
    fn assign_target_error(&self, offender: &Expr, nested: bool) -> ParseError {
        // A *bare* top-level yield target (`yield = 1`, `x = yield = 1`)
        // has its own diagnostic in CPython's grammar
        // (`invalid_assignment`'s `yield_expr '='` alternative). A
        // parenthesized `(yield) = 1` instead falls through to the
        // generic "cannot assign to X here. Maybe you meant '=='" hint —
        // the parens make it an ordinary primary. Our AST keeps the
        // *inner* span for parenthesized expressions, so peek at the
        // preceding non-space character to tell the two apart.
        if !nested && matches!(&offender.kind, ExprKind::Yield(_) | ExprKind::YieldFrom(_)) {
            let parenthesized = self.source[..offender.span.start.0 as usize]
                .trim_end()
                .ends_with('(');
            if !parenthesized {
                return ParseError::Unexpected {
                    span: offender.span,
                    message: "assignment to yield expression not possible".to_owned(),
                };
            }
        }
        let name = crate::ast::expr_name(offender);
        // The "Maybe you meant '==' instead of '='?" hint appears only on
        // top-level offenders, and CPython's grammar carves out a handful
        // of forms that keep the bare message even there (keyword
        // constants, conditionals, lambdas, generator expressions,
        // comparisons, and `not`/`and`/`or` operations).
        let bare = nested
            || matches!(
                &offender.kind,
                ExprKind::Constant(Constant::None)
                    | ExprKind::Constant(Constant::Bool(_))
                    | ExprKind::IfExp { .. }
                    | ExprKind::Lambda { .. }
                    | ExprKind::GeneratorExp { .. }
                    | ExprKind::Compare { .. }
                    | ExprKind::BoolOp { .. }
            )
            || matches!(
                &offender.kind,
                ExprKind::UnaryOp {
                    op: UnaryOp::Not,
                    ..
                }
            );
        let message = if bare {
            format!("cannot assign to {name}")
        } else {
            format!("cannot assign to {name} here. Maybe you meant '==' instead of '='?")
        };
        ParseError::Unexpected {
            span: offender.span,
            message,
        }
    }

    /// Validate one statement-level assignment target, erroring exactly
    /// as CPython's parser does.
    fn check_assign_target(&self, target: &Expr) -> Result<(), ParseError> {
        match Self::find_invalid_target(target, false) {
            Some((offender, nested)) => Err(self.assign_target_error(offender, nested)),
            None => Ok(()),
        }
    }

    /// pegen's 3.14 `'as' target` diagnostics (`invalid_dotted_as_name`,
    /// `invalid_import_from_as_name`, `invalid_except_stmt`,
    /// `invalid_as_pattern`): when the token after `as` doesn't start a
    /// plain NAME target, the grammar re-parses the target as a full
    /// `expression` and names its kind ("cannot use attribute as import
    /// target"). Returns `Ok(())` when nothing specific applies, leaving
    /// the caller's ordinary NAME handling to report the generic error.
    ///
    /// `name_ok(next)` says whether a *bare* NAME target followed by
    /// `next` is fine for the enclosing rule; `require_next` gates the
    /// diagnostic on the token after the expression (the except rule
    /// needs the `:`). The position is left untouched.
    fn as_target_diagnostic(
        &mut self,
        require_next: Option<&TokenKind>,
        name_ok: impl Fn(&TokenKind) -> bool,
        message: impl Fn(&str) -> String,
    ) -> Result<(), ParseError> {
        let save = self.pos;
        let bare_name_token = matches!(self.peek(), TokenKind::Name);
        let parsed = self.parse_expression(false);
        let next = self.peek().clone();
        self.pos = save;
        let Ok(target) = parsed else {
            return Ok(());
        };
        if bare_name_token && matches!(target.kind, ExprKind::Name(_)) && name_ok(&next) {
            return Ok(());
        }
        if let Some(req) = require_next {
            if next != *req {
                return Ok(());
            }
        }
        Err(ParseError::Unexpected {
            span: target.span,
            message: message(crate::ast::expr_name(&target)),
        })
    }

    /// Expect the `:` between a dict key and value. A `=` here gets
    /// CPython's "cannot assign to X here. Maybe you meant '==' instead
    /// of '='?", anchored at the key.
    fn expect_dict_colon(&mut self, key: &Expr) -> Result<(), ParseError> {
        if self.check(&TokenKind::Equal) {
            return Err(Self::display_equal_error(key));
        }
        if !self.check(&TokenKind::Colon) {
            // pegen `invalid_dict_key_value` ("{1:2, 3:4, 5}").
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "':' expected after dictionary key".to_owned(),
            });
        }
        self.bump();
        Ok(())
    }

    /// Parse a dict value (the expression after `key:`) with pegen's
    /// dedicated diagnostics for a missing or starred value.
    fn parse_dict_value(&mut self) -> Result<Expr, ParseError> {
        if let TokenKind::Star = self.peek() {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "cannot use a starred expression in a dictionary value".to_owned(),
            });
        }
        if matches!(self.peek(), TokenKind::RBrace | TokenKind::Comma) {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "expression expected after dictionary key and ':'".to_owned(),
            });
        }
        self.parse_ternary()
    }

    /// Like [`Parser::expect`], but when the failure is two adjacent
    /// expressions (e.g. `[a b]`), report CPython's
    /// "invalid syntax. Perhaps you forgot a comma?" spanning from the
    /// previous element through the stray expression.
    fn expect_or_forgot_comma(
        &mut self,
        k: &TokenKind,
        what: &str,
        items: &[Expr],
    ) -> Result<Token, ParseError> {
        if !self.check(k) && self.at_expression_start() {
            if let Some(prev) = items.last() {
                let start = prev.span;
                // Parse (and discard) the stray expression to find its
                // extent; any nested parse error wins.
                self.first_fail.get_or_insert(self.pos);
                let stray = self.parse_ternary()?;
                return Err(ParseError::Unexpected {
                    span: start.merge(stray.span),
                    message: "invalid syntax. Perhaps you forgot a comma?".to_owned(),
                });
            }
        }
        self.expect(k, what)
    }

    // Skip any trivia (NL, COMMENT) between meaningful tokens.
    fn skip_trivia(&mut self) {
        while matches!(self.peek(), TokenKind::Nl | TokenKind::Comment) {
            self.pos += 1;
        }
    }

    /// The end of a compound statement's block, as pegen's `EXTRA` sees
    /// it: the last non-whitespace token consumed. That is the final
    /// statement's last token, except when the suite ended with a
    /// trailing `;` (`def f(): x = 1;`), which the enclosing statement's
    /// span includes even though the simple statement's does not.
    fn block_end(&self, last_stmt: weavepy_lexer::Span) -> weavepy_lexer::Span {
        let mut i = self.pos;
        while i > 0 {
            i -= 1;
            match self.tokens[i].kind {
                TokenKind::Newline
                | TokenKind::Nl
                | TokenKind::Comment
                | TokenKind::Indent
                | TokenKind::Dedent
                | TokenKind::Endmarker => continue,
                TokenKind::Semi if self.tokens[i].span.end.0 > last_stmt.end.0 => {
                    return last_stmt.merge(self.tokens[i].span);
                }
                _ => break,
            }
        }
        last_stmt
    }

    fn skip_trivia_and_newlines(&mut self) {
        while matches!(
            self.peek(),
            TokenKind::Nl | TokenKind::Comment | TokenKind::Newline
        ) {
            self.pos += 1;
        }
    }

    // ============================================================
    // Statements
    // ============================================================

    fn parse_module(&mut self) -> Result<Module, ParseError> {
        let mut body = Vec::new();
        self.skip_trivia_and_newlines();
        while !matches!(self.peek(), TokenKind::Endmarker) {
            let stmt = self.parse_statement()?;
            body.push(stmt);
            self.skip_trivia_and_newlines();
        }
        Ok(Module { body })
    }

    /// CPython's `eval` start rule: `expressions NEWLINE* ENDMARKER`.
    /// See [`parse_eval`] for why this bypasses the statement grammar.
    fn parse_eval_module(&mut self) -> Result<Module, ParseError> {
        self.skip_trivia_and_newlines();
        if matches!(self.peek(), TokenKind::Indent) {
            return Err(ParseError::Indentation {
                span: self.peek_token().span,
                message: "unexpected indent".to_owned(),
            });
        }
        let start_span = self.peek_token().span;
        let first = self.parse_eval_element()?;
        let expr = if self.check(&TokenKind::Comma) {
            let mut items = vec![first];
            while self.eat(&TokenKind::Comma) {
                if matches!(self.peek(), TokenKind::Newline | TokenKind::Endmarker) {
                    break;
                }
                items.push(self.parse_eval_element()?);
            }
            // `expressions` ends at the last consumed token (a closing
            // paren or trailing comma included), like the other tuples.
            let end_span = self.prev_token_span();
            Expr {
                kind: ExprKind::Tuple(items),
                span: start_span.merge(end_span),
            }
        } else {
            first
        };
        self.skip_trivia_and_newlines();
        if !matches!(self.peek(), TokenKind::Endmarker) {
            // The first token the eval rule can't accept: the `=` of an
            // assignment, a `;`, a stray second expression, … — always
            // pegen's bare "invalid syntax", anchored at that token.
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "invalid syntax".to_owned(),
            });
        }
        let span = expr.span;
        Ok(Module {
            body: vec![Stmt {
                kind: StmtKind::Expr(expr),
                span,
            }],
        })
    }

    /// One element of the eval rule's `expressions` list — CPython's
    /// `expression`: a ternary or lambda, with no starred form, no
    /// `yield`, and no top-level walrus.
    fn parse_eval_element(&mut self) -> Result<Expr, ParseError> {
        // `yield`/`*` have no `expression` production; statement keywords
        // (`del`, `import`, `pass`, …) can't start an expression at all.
        // All get pegen's bare "invalid syntax" at the offending token.
        if matches!(self.peek(), TokenKind::Star)
            || self.at_keyword(Keyword::Yield)
            || !self.at_expression_start()
        {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "invalid syntax".to_owned(),
            });
        }
        // No walrus either: consume just the name so the caller's
        // terminator check reports "invalid syntax" at the `:=` itself.
        if matches!(self.peek(), TokenKind::Name)
            && matches!(self.peek_at(1), Some(TokenKind::ColonEqual))
        {
            let tok = self.bump();
            return Ok(Expr {
                kind: ExprKind::Name(self.ident(tok.span)),
                span: tok.span,
            });
        }
        self.parse_ternary()
    }

    /// CPython `func_type_input`. pegen's `type_expressions` accepts
    /// `*expr` / `**expr` markers but appends only the bare expressions
    /// to `argtypes` (Grammar/python.gram).
    fn parse_func_type_input(&mut self) -> Result<(Vec<Expr>, Expr), ParseError> {
        self.skip_trivia_and_newlines();
        self.expect(&TokenKind::LPar, "'('")?;
        let mut argtypes = Vec::new();
        if !self.check(&TokenKind::RPar) {
            // `type_expressions` ordering: plain expressions, then at most
            // one `*expr`, then at most one `**expr` — anything else is a
            // bare "invalid syntax".
            let (mut seen_star, mut seen_dstar) = (false, false);
            loop {
                let bad_order_span = self.peek_token().span;
                let star = self.eat(&TokenKind::Star);
                let dstar = !star && self.eat(&TokenKind::DoubleStar);
                if (star && (seen_star || seen_dstar))
                    || (dstar && seen_dstar)
                    || (!star && !dstar && (seen_star || seen_dstar))
                {
                    return Err(ParseError::Unexpected {
                        span: bad_order_span,
                        message: "invalid syntax".to_owned(),
                    });
                }
                seen_star |= star;
                seen_dstar |= dstar;
                if !self.at_expression_start() {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "invalid syntax".to_owned(),
                    });
                }
                argtypes.push(self.parse_ternary()?);
                if !self.eat(&TokenKind::Comma) {
                    break;
                }
            }
        }
        self.expect(&TokenKind::RPar, "')'")?;
        self.expect(&TokenKind::RArrow, "'->'")?;
        let returns = self.parse_ternary()?;
        self.skip_trivia_and_newlines();
        if !matches!(self.peek(), TokenKind::Endmarker) {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "invalid syntax".to_owned(),
            });
        }
        Ok((argtypes, returns))
    }

    /// pegen's `statement` rule: parse one statement and register it as
    /// the most recent successfully parsed statement
    /// (`_PyPegen_register_stmts`), which the 3.14 parser publishes
    /// through `SyntaxError._metadata` for `traceback`'s keyword-typo
    /// suggestions. Like CPython, an earlier-line statement finishing
    /// later (an enclosing compound statement) doesn't move it backwards.
    fn parse_statement(&mut self) -> Result<Stmt, ParseError> {
        let stmt = self.parse_statement_inner()?;
        // Only `compound_stmt` alternatives go through `register_stmts`.
        let compound = matches!(
            stmt.kind,
            StmtKind::FunctionDef { .. }
                | StmtKind::AsyncFunctionDef { .. }
                | StmtKind::ClassDef { .. }
                | StmtKind::If { .. }
                | StmtKind::While { .. }
                | StmtKind::For { .. }
                | StmtKind::AsyncFor { .. }
                | StmtKind::With { .. }
                | StmtKind::AsyncWith { .. }
                | StmtKind::Try { .. }
                | StmtKind::Match { .. }
        );
        let line = self.line_of(stmt.span);
        if compound && self.last_stmt.is_none_or(|(l, _)| l <= line) {
            let start = stmt.span.start.0 as usize;
            let line_start = self.source[..start].rfind('\n').map_or(0, |i| i + 1);
            // AST `col_offset` is a UTF-8 byte offset.
            let col = (start - line_start) as u32;
            self.last_stmt = Some((line, col));
        }
        Ok(stmt)
    }

    fn parse_statement_inner(&mut self) -> Result<Stmt, ParseError> {
        self.skip_trivia();
        // An INDENT token where a statement should start means the line
        // is indented deeper than its block — CPython's tokenizer
        // raises IndentationError("unexpected indent").
        if matches!(self.peek(), TokenKind::Indent) {
            return Err(ParseError::Indentation {
                span: self.peek_token().span,
                message: "unexpected indent".to_owned(),
            });
        }
        // Decorators apply to the next `def` or `class`.
        if matches!(self.peek(), TokenKind::At) {
            let decorators = self.parse_decorators()?;
            self.skip_trivia();
            return match self.peek() {
                TokenKind::Keyword(Keyword::Def) => self.parse_function_def(decorators),
                TokenKind::Keyword(Keyword::Class) => self.parse_class_def(decorators),
                TokenKind::Keyword(Keyword::Async) => self.parse_async_stmt(decorators),
                other => Err(ParseError::Unexpected {
                    span: self.peek_token().span,
                    message: format!(
                        "expected `def`, `async def`, or `class` after decorator, got {other:?}"
                    ),
                }),
            };
        }
        match self.peek() {
            TokenKind::Keyword(kw) => match kw {
                Keyword::Def => self.parse_function_def(Vec::new()),
                Keyword::Class => self.parse_class_def(Vec::new()),
                Keyword::If => self.parse_if(),
                Keyword::While => self.parse_while(),
                Keyword::For => self.parse_for(),
                Keyword::Return => self.parse_return(),
                Keyword::Pass => self.simple_keyword_stmt(StmtKind::Pass),
                Keyword::Break => self.simple_keyword_stmt(StmtKind::Break),
                Keyword::Continue => self.simple_keyword_stmt(StmtKind::Continue),
                Keyword::Del => self.parse_del(),
                Keyword::Assert => self.parse_assert(),
                Keyword::Import => self.parse_import(),
                Keyword::From => self.parse_import_from(),
                Keyword::Global => self.parse_global(),
                Keyword::Nonlocal => self.parse_nonlocal(),
                Keyword::Try => self.parse_try(),
                Keyword::Raise => self.parse_raise(),
                Keyword::With => self.parse_with(),
                // `yield` at statement start parses as an expression
                // statement so the AST is `Expr(Yield(...))`, matching
                // CPython's lowering.
                Keyword::Yield => self.parse_simple_statement(),
                Keyword::Async => self.parse_async_stmt(Vec::new()),
                // Bare `await ...` at statement level falls through to
                // the expression-statement path; the unary parser
                // handles the `await` keyword as a prefix operator.
                Keyword::Await => self.parse_simple_statement(),
                _ => self.parse_simple_statement(),
            },
            // `match` is a soft keyword — only treated as the statement
            // when followed by an expression, a `:`, and indented `case`.
            TokenKind::Name if self.lexeme(self.peek_token().span) == "match" => {
                if self.looks_like_match_statement() {
                    self.parse_match()
                } else {
                    // pegen tries the regular statement grammar first,
                    // then falls back to `invalid_match_stmt`, so
                    // `match x` ⏎ reports "expected ':'" (not the
                    // generic failure of the expression path).
                    let saved = self.pos;
                    match self.parse_simple_statement() {
                        Ok(stmt) => Ok(stmt),
                        Err(expr_err) => {
                            self.pos = saved;
                            Err(self.match_stmt_fallback_error(expr_err))
                        }
                    }
                }
            }
            // PEP 695 — `type Alias = T` soft keyword. Disambiguate
            // by requiring `type NAME = ...` shape; otherwise treat
            // `type` as an ordinary identifier (e.g. `type(x)` and
            // `type Name: ann = v` annotations).
            TokenKind::Name if self.lexeme(self.peek_token().span) == "type" => {
                if self.looks_like_type_alias_stmt() {
                    self.parse_type_alias_stmt()
                } else {
                    self.parse_simple_statement()
                }
            }
            _ => self.parse_simple_statement(),
        }
    }

    /// PEP 695 — `type X[T] = Y` lookahead.
    fn looks_like_type_alias_stmt(&self) -> bool {
        let mut i = self.pos + 1;
        // Must be followed by a name (the alias target).
        if !matches!(self.tokens.get(i).map(|t| &t.kind), Some(TokenKind::Name)) {
            return false;
        }
        i += 1;
        // Optional `[ ... ]` type-parameter list — scan to its
        // matching close-bracket at depth 0.
        if matches!(self.tokens.get(i).map(|t| &t.kind), Some(TokenKind::LSqb)) {
            let mut depth = 1i32;
            i += 1;
            while let Some(tok) = self.tokens.get(i) {
                match &tok.kind {
                    TokenKind::LSqb => depth += 1,
                    TokenKind::RSqb => {
                        depth -= 1;
                        if depth == 0 {
                            i += 1;
                            break;
                        }
                    }
                    TokenKind::Newline | TokenKind::Endmarker => return false,
                    _ => {}
                }
                i += 1;
            }
        }
        matches!(self.tokens.get(i).map(|t| &t.kind), Some(TokenKind::Equal))
    }

    /// Parse a PEP 695 type-alias statement into the first-class
    /// [`StmtKind::TypeAlias`] node.
    fn parse_type_alias_stmt(&mut self) -> Result<Stmt, ParseError> {
        let type_tok = self.bump(); // `type`
        let name_tok = self.expect(&TokenKind::Name, "type alias name")?;
        let name = self.ident(name_tok.span);
        let type_params = self.collect_pep695_type_params()?;
        self.expect(&TokenKind::Equal, "`=`")?;
        let value = self.parse_expression_list(true)?;
        check_type_param_expr(&value, "a type alias")?;
        self.consume_stmt_end()?;
        let span = type_tok.span.merge(value.span);
        Ok(Stmt {
            kind: StmtKind::TypeAlias {
                name,
                name_span: name_tok.span,
                type_params,
                value: Box::new(value),
            },
            span,
        })
    }

    /// Parses a PEP 695 `[T, T: bound, *Ts, **P, X = default]`
    /// type-parameter list after a `def`/`class`/`type` name.
    fn collect_pep695_type_params(&mut self) -> Result<Vec<TypeParam>, ParseError> {
        if !matches!(self.peek(), TokenKind::LSqb) {
            return Ok(Vec::new());
        }
        let lsqb = self.bump(); // `[`
                                // pegen `invalid_type_params`.
        if matches!(self.peek(), TokenKind::RSqb) {
            return Err(ParseError::Unexpected {
                span: lsqb.span.merge(self.peek_token().span),
                message: "Type parameter list cannot be empty".to_owned(),
            });
        }
        let mut params: Vec<TypeParam> = Vec::new();
        let mut seen_default = false;
        loop {
            self.skip_trivia();
            // CPython's TypeVarTuple/ParamSpec node spans include the
            // `*` / `**` prefix; remember where it started.
            let mut prefix_span: Option<Span> = None;
            let kind_prefix = match self.peek() {
                TokenKind::Star => {
                    prefix_span = Some(self.bump().span);
                    Some(TypeParamKind::TypeVarTuple)
                }
                TokenKind::DoubleStar => {
                    prefix_span = Some(self.bump().span);
                    Some(TypeParamKind::ParamSpec)
                }
                _ => None,
            };
            if matches!(self.peek(), TokenKind::RSqb) {
                if kind_prefix.is_some() {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "invalid syntax".to_owned(),
                    });
                }
                break;
            }
            let name_tok = self.expect(&TokenKind::Name, "type parameter name")?;
            let name = self.ident(name_tok.span);
            if params.iter().any(|p| p.source_name == name) {
                return Err(ParseError::Unexpected {
                    span: name_tok.span,
                    message: format!("duplicate type parameter '{name}'"),
                });
            }
            // `: bound` — legal only for plain TypeVars (CPython's
            // grammar rejects bounds on `*Ts` / `**P`).
            let bound = if matches!(self.peek(), TokenKind::Colon) {
                self.bump();
                let b = self.parse_expression(false)?;
                if let Some(kind) = &kind_prefix {
                    let what = if matches!(b.kind, ExprKind::Tuple(_)) {
                        "constraints"
                    } else {
                        "bound"
                    };
                    let with = match kind {
                        TypeParamKind::TypeVarTuple => "TypeVarTuple",
                        _ => "ParamSpec",
                    };
                    return Err(ParseError::Unexpected {
                        span: name_tok.span,
                        message: format!("cannot use {what} with {with}"),
                    });
                }
                let ctx = if matches!(b.kind, ExprKind::Tuple(_)) {
                    "a TypeVar constraint"
                } else {
                    "a TypeVar bound"
                };
                check_type_param_expr(&b, ctx)?;
                Some(Box::new(b))
            } else {
                None
            };
            // PEP 696 `= default`. A starred default (`*Ts = *tuple[int]`)
            // is grammar for TypeVarTuple only.
            let default = if matches!(self.peek(), TokenKind::Equal) {
                self.bump();
                let starred = if matches!(self.peek(), TokenKind::Star) {
                    if !matches!(kind_prefix, Some(TypeParamKind::TypeVarTuple)) {
                        return Err(ParseError::Unexpected {
                            span: self.peek_token().span,
                            message: "invalid syntax".to_owned(),
                        });
                    }
                    Some(self.bump().span)
                } else {
                    None
                };
                let d = self.parse_expression(false)?;
                let ctx = match kind_prefix {
                    Some(TypeParamKind::TypeVarTuple) => "a TypeVarTuple default",
                    Some(_) => "a ParamSpec default",
                    None => "a TypeVar default",
                };
                check_type_param_expr(&d, ctx)?;
                seen_default = true;
                let d = match starred {
                    Some(star_span) => Expr {
                        span: star_span.merge(d.span),
                        kind: ExprKind::Starred(Box::new(d)),
                    },
                    None => d,
                };
                Some(Box::new(d))
            } else {
                if seen_default {
                    return Err(ParseError::Unexpected {
                        span: name_tok.span,
                        message: format!(
                            "non-default type parameter '{name}' follows default type parameter"
                        ),
                    });
                }
                None
            };
            let kind = kind_prefix.unwrap_or(TypeParamKind::TypeVar { bound });
            // Node span: `*`/`**` prefix (if any) through the default,
            // bound, or bare name — matching CPython's EXTRA range.
            let start = prefix_span.unwrap_or(name_tok.span);
            let end = match (&default, &kind) {
                (Some(d), _) => d.span,
                (None, TypeParamKind::TypeVar { bound: Some(b) }) => b.span,
                _ => name_tok.span,
            };
            params.push(TypeParam {
                source_name: name.clone(),
                name,
                kind,
                default,
                span: start.merge(end),
            });
            if matches!(self.peek(), TokenKind::Comma) {
                self.bump();
            } else {
                break;
            }
        }
        self.expect(&TokenKind::RSqb, "`]`")?;
        Ok(params)
    }

    /// `match` is a soft keyword. The disambiguating signal is
    /// `match <expr>:` followed by NEWLINE INDENT `case`. We look
    /// ahead conservatively — if any of those signals is missing,
    /// we fall back to treating `match` as an identifier.
    fn looks_like_match_statement(&self) -> bool {
        // Skip past `match`.
        let mut i = self.pos + 1;
        // Any non-end-of-statement token is a candidate for the subject.
        match self.tokens.get(i).map(|t| &t.kind) {
            Some(TokenKind::Newline)
            | Some(TokenKind::Semi)
            | Some(TokenKind::Endmarker)
            | Some(TokenKind::Equal)
            | Some(TokenKind::PlusEqual)
            | Some(TokenKind::MinusEqual)
            | Some(TokenKind::StarEqual)
            | Some(TokenKind::SlashEqual)
            | Some(TokenKind::DoubleSlashEqual)
            | Some(TokenKind::PercentEqual)
            | Some(TokenKind::AmperEqual)
            | Some(TokenKind::VbarEqual)
            | Some(TokenKind::CaretEqual)
            | Some(TokenKind::LeftShiftEqual)
            | Some(TokenKind::RightShiftEqual)
            | Some(TokenKind::DoubleStarEqual)
            | Some(TokenKind::AtEqual)
            | Some(TokenKind::ColonEqual)
            | Some(TokenKind::Dot) => return false,
            // NB: `(` and `[` are *not* early-rejected — `match (subject):` and
            // `match [a, b]:` (parenthesised / list subjects, incl. the empty
            // tuple `match ():`) are valid match statements. The depth-aware
            // scan below disambiguates them from a `match(...)` call or a
            // `match[...]: T` annotation by requiring a depth-0 `:` followed by
            // NEWLINE INDENT `case`.
            None => return false,
            _ => {}
        }
        // Scan for a `:` at depth 0 followed by NEWLINE then `case`.
        let mut depth = 0i32;
        while let Some(tok) = self.tokens.get(i) {
            match &tok.kind {
                TokenKind::LPar | TokenKind::LSqb | TokenKind::LBrace => depth += 1,
                TokenKind::RPar | TokenKind::RSqb | TokenKind::RBrace => depth -= 1,
                TokenKind::Newline | TokenKind::Endmarker => return false,
                TokenKind::Colon if depth == 0 => {
                    // Look for NEWLINE (NL|COMMENT)* INDENT (NL|COMMENT)* `case`.
                    let mut j = i + 1;
                    if !matches!(
                        self.tokens.get(j).map(|t| &t.kind),
                        Some(TokenKind::Newline)
                    ) {
                        return false;
                    }
                    j += 1;
                    while matches!(
                        self.tokens.get(j).map(|t| &t.kind),
                        Some(TokenKind::Nl | TokenKind::Comment | TokenKind::Newline)
                    ) {
                        j += 1;
                    }
                    // A missing INDENT is still a match statement —
                    // parse_match then reports CPython's "expected an
                    // indented block after 'match' statement"
                    // (`invalid_match_stmt`). With an INDENT present,
                    // require `case` so `match[x]:`-style annotations
                    // aren't misread.
                    if matches!(self.tokens.get(j).map(|t| &t.kind), Some(TokenKind::Indent)) {
                        j += 1;
                    } else {
                        return true;
                    }
                    while matches!(
                        self.tokens.get(j).map(|t| &t.kind),
                        Some(TokenKind::Nl | TokenKind::Comment)
                    ) {
                        j += 1;
                    }
                    return matches!(
                        self.tokens.get(j).map(|t| (&t.kind, self.lexeme(t.span))),
                        Some((TokenKind::Name, "case"))
                    );
                }
                _ => {}
            }
            i += 1;
        }
        false
    }

    fn parse_decorators(&mut self) -> Result<Vec<Expr>, ParseError> {
        let mut decorators = Vec::new();
        while matches!(self.peek(), TokenKind::At) {
            self.bump();
            // PEP 614: `decorator: '@' named_expression NEWLINE`.
            self.walrus_ok = true;
            let e = self.parse_expression(false)?;
            // After the decorator expression, consume a NEWLINE (and any
            // trivia leading to the next decorator or the def/class).
            self.consume_stmt_end()?;
            self.skip_trivia_and_newlines();
            decorators.push(e);
        }
        Ok(decorators)
    }

    fn simple_keyword_stmt(&mut self, kind: StmtKind) -> Result<Stmt, ParseError> {
        self.check_stmt_as_ifexp_body()?;
        let tok = self.bump();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind,
            span: tok.span,
        })
    }

    /// `'else' ':' block` for `if`/`while`/`for`, plus pegen
    /// `invalid_else_stmt` (3.14): an `elif` right after the else block
    /// is "'elif' block follows an 'else' block" (anchored at the `elif`).
    fn parse_else_block(&mut self) -> Result<Vec<Stmt>, ParseError> {
        let else_tok = self.bump();
        self.expect(&TokenKind::Colon, "`:`")?;
        let block = self.parse_block("'else' statement", else_tok.span)?;
        let save = self.pos;
        self.skip_trivia_and_newlines();
        if self.at_keyword(Keyword::Elif) {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "'elif' block follows an 'else' block".to_owned(),
            });
        }
        self.pos = save;
        Ok(block)
    }

    /// pegen `invalid_expression` (3.14): `(pass_stmt | break_stmt |
    /// continue_stmt) 'if' disjunction 'else' simple_stmt` — a statement
    /// keyword used as a conditional expression's body is "expected
    /// expression before 'if', but statement is given", anchored at the
    /// keyword. Position is left untouched when the shape doesn't match.
    fn check_stmt_as_ifexp_body(&mut self) -> Result<(), ParseError> {
        if !matches!(
            self.peek(),
            TokenKind::Keyword(Keyword::Pass | Keyword::Break | Keyword::Continue)
        ) || !matches!(self.peek_at(1), Some(TokenKind::Keyword(Keyword::If)))
        {
            return Ok(());
        }
        let save = self.pos;
        let kw_span = self.peek_token().span;
        self.pos += 2; // keyword, `if`
        let matched = self.parse_or().is_ok() && self.at_keyword(Keyword::Else);
        self.pos = save;
        if matched {
            return Err(ParseError::Unexpected {
                span: kw_span,
                message: "expected expression before 'if', but statement is given".to_owned(),
            });
        }
        Ok(())
    }

    /// Claim the first unclaimed type comment whose start offset lies in
    /// `[lo, hi)`.
    fn take_type_comment_in(&mut self, lo: u32, hi: u32) -> Option<String> {
        let st = self.type_comments.as_mut()?;
        for (span, text, used) in st.pending.iter_mut() {
            if !*used && span.start.0 >= lo && span.start.0 < hi {
                *used = true;
                return Some(text.clone());
            }
        }
        None
    }

    /// A type comment trailing a simple statement on its own line —
    /// between the statement's last token (`lo`) and the NEWLINE.
    fn take_trailing_type_comment(&mut self, lo: u32) -> Option<String> {
        self.type_comments.as_ref()?;
        if !matches!(self.peek(), TokenKind::Newline | TokenKind::Endmarker) {
            return None;
        }
        let hi = self.peek_token().span.start.0;
        self.take_type_comment_in(lo, hi)
    }

    /// A type comment between a block header's just-consumed `:` and the
    /// next token (for/with/def headers: `for x in y:  # type: T`).
    fn take_colon_type_comment(&mut self) -> Option<String> {
        self.type_comments.as_ref()?;
        let lo = self.prev_token_span().end.0;
        let hi = self.peek_token().span.start.0;
        self.take_type_comment_in(lo, hi)
    }

    /// Own-line type comments between a def header's NEWLINE and the
    /// body's INDENT (`func_body_suite: NEWLINE TYPE_COMMENT NEWLINE
    /// INDENT ...`). Returns the first one and how many were found (a
    /// second is the "two type comments" diagnostic).
    fn take_def_body_type_comments(&mut self) -> (Option<String>, usize) {
        if self.type_comments.is_none() || !matches!(self.peek(), TokenKind::Newline) {
            return (None, 0);
        }
        // Comment-only lines in the gap produce their own Newline
        // tokens; the body's INDENT is the first non-newline token.
        let mut j = self.pos;
        while matches!(
            self.tokens.get(j).map(|t| &t.kind),
            Some(TokenKind::Newline)
        ) {
            j += 1;
        }
        if !matches!(self.tokens.get(j).map(|t| &t.kind), Some(TokenKind::Indent)) {
            return (None, 0);
        }
        let lo = self.peek_token().span.end.0;
        let hi = self.tokens[j].span.start.0;
        let mut first = None;
        let mut count = 0;
        while let Some(text) = self.take_type_comment_in(lo, hi) {
            count += 1;
            if first.is_none() {
                first = Some(text);
            }
        }
        (first, count)
    }

    /// Record a claimed statement type comment under the statement's
    /// span-start key.
    fn record_stmt_type_comment(&mut self, key: u32, text: String) {
        if let Some(st) = self.type_comments.as_mut() {
            st.stmts.push((key, text));
        }
    }

    /// Re-key a recorded statement type comment (an `async` prefix
    /// extends the statement's span leftward after the fact).
    fn retag_stmt_type_comment(&mut self, old: u32, new: u32) {
        if let Some(st) = self.type_comments.as_mut() {
            for (key, _) in st.stmts.iter_mut() {
                if *key == old {
                    *key = new;
                }
            }
        }
    }

    /// Attach type comments inside a def's parameter parens to the
    /// parameter each one follows (`a,  # type: A`). `lo`/`hi` bound the
    /// text between the parens; unattachable comments stay pending and
    /// surface as "misplaced" after the parse.
    fn attach_arg_type_comments(&mut self, args: &Arguments, lo: u32, hi: u32) {
        if self.type_comments.is_none() {
            return;
        }
        // Parameter extents in source order, defaults included.
        let mut extents: Vec<(u32, u32)> = Vec::new();
        let n_pos = args.posonlyargs.len() + args.args.len();
        let d0 = n_pos - args.defaults.len();
        for (i, a) in args.posonlyargs.iter().chain(args.args.iter()).enumerate() {
            let mut end = a.span.end.0;
            if i >= d0 {
                end = end.max(args.defaults[i - d0].span.end.0);
            }
            extents.push((a.span.start.0, end));
        }
        if let Some(v) = &args.vararg {
            extents.push((v.span.start.0, v.span.end.0));
        }
        for (i, a) in args.kwonlyargs.iter().enumerate() {
            let mut end = a.span.end.0;
            if let Some(Some(d)) = args.kw_defaults.get(i) {
                end = end.max(d.span.end.0);
            }
            extents.push((a.span.start.0, end));
        }
        if let Some(k) = &args.kwarg {
            extents.push((k.span.start.0, k.span.end.0));
        }
        extents.sort_unstable();
        let st = self.type_comments.as_mut().expect("checked above");
        for (span, text, used) in st.pending.iter_mut() {
            if *used || span.start.0 < lo || span.start.0 >= hi {
                continue;
            }
            if let Some(&(astart, _)) = extents.iter().rev().find(|&&(_, e)| e <= span.start.0) {
                *used = true;
                st.args.push((astart, text.clone()));
            }
        }
    }

    fn consume_stmt_end(&mut self) -> Result<(), ParseError> {
        match self.peek() {
            TokenKind::Newline | TokenKind::Semi | TokenKind::Endmarker => {
                if !matches!(self.peek(), TokenKind::Endmarker) {
                    self.bump();
                }
                Ok(())
            }
            // Leftover tokens after an otherwise-complete statement are
            // CPython's catch-all "invalid syntax" (e.g. `1 2`, or a bad
            // string prefix like `fu''` which tokenises as NAME + STRING).
            _ => Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "invalid syntax".to_owned(),
            }),
        }
    }

    fn parse_simple_statement(&mut self) -> Result<Stmt, ParseError> {
        let start_span = self.peek_token().span;

        // pegen `yield_stmt`: a statement-level `yield`/`yield from` is
        // an expression statement and cannot continue into assignment
        // or tuple forms (`yield from (), 1` is invalid syntax).
        if self.at_keyword(Keyword::Yield) {
            let e = self.parse_yield()?;
            // `yield = 1` — pegen `invalid_assignment`'s dedicated
            // `yield_expr '='` alternative.
            if self.check(&TokenKind::Equal) {
                return Err(ParseError::Unexpected {
                    span: e.span,
                    message: "assignment to yield expression not possible".to_owned(),
                });
            }
            let end = self.prev_token_span();
            self.consume_stmt_end()?;
            return Ok(Stmt {
                kind: StmtKind::Expr(e),
                span: start_span.merge(end),
            });
        }

        // A statement opening with `(` makes any annotation target
        // non-"simple" (CPython pegen: `('(' single_target ')' | ...) ':'`
        // sets `simple=0`), even when the inner expression is a bare Name.
        let starts_with_lpar = matches!(self.peek(), TokenKind::LPar);

        // Try to parse an expression first; assignment / aug-assignment
        // / ann-assignment are disambiguated by lookahead.
        self.target_entry = self.pos;
        let first = self.parse_expression(true)?;

        // Augmented assignment.
        if let Some(op) = self.try_aug_op() {
            // CPython (`invalid_augmented_assignment`): only a single
            // Name / Attribute / Subscript may be augmented — container
            // targets are illegal here too.
            if !matches!(
                &first.kind,
                ExprKind::Name(_) | ExprKind::Attribute { .. } | ExprKind::Subscript { .. }
            ) {
                return Err(ParseError::Unexpected {
                    span: first.span,
                    message: format!(
                        "'{}' is an illegal expression for augmented assignment",
                        crate::ast::expr_name(&first)
                    ),
                });
            }
            let value = self.parse_assign_rhs()?;
            let end = self.prev_token_span();
            self.consume_stmt_end()?;
            return Ok(Stmt {
                kind: StmtKind::AugAssign {
                    target: first,
                    op,
                    value,
                },
                span: start_span.merge(end),
            });
        }

        // Annotated assignment: `target: annotation = value` (or just `target: annotation`).
        if self.check(&TokenKind::Colon) {
            // CPython (`invalid_ann_assign_target`): a single Name /
            // Attribute / Subscript only; tuples and lists get their own
            // message, everything else is an illegal annotation target.
            match &first.kind {
                ExprKind::Name(_) | ExprKind::Attribute { .. } | ExprKind::Subscript { .. } => {}
                ExprKind::Tuple(_) => {
                    return Err(ParseError::Unexpected {
                        span: first.span,
                        message: "only single target (not tuple) can be annotated".to_owned(),
                    });
                }
                ExprKind::List(_) => {
                    return Err(ParseError::Unexpected {
                        span: first.span,
                        message: "only single target (not list) can be annotated".to_owned(),
                    });
                }
                _ => {
                    return Err(ParseError::Unexpected {
                        span: first.span,
                        message: "illegal target for annotation".to_owned(),
                    });
                }
            }
            self.bump();
            let annotation = self.parse_expression(false)?;
            let value = if self.eat(&TokenKind::Equal) {
                Some(self.parse_assign_rhs()?)
            } else {
                None
            };
            let end = self.prev_token_span();
            self.consume_stmt_end()?;
            let simple = matches!(first.kind, ExprKind::Name(_)) && !starts_with_lpar;
            return Ok(Stmt {
                kind: StmtKind::AnnAssign {
                    target: first,
                    annotation,
                    value,
                    simple,
                },
                span: start_span.merge(end),
            });
        }

        // Chained assignment: `a = b = c = value`.
        if self.check(&TokenKind::Equal) {
            let mut targets = vec![first];
            while self.eat(&TokenKind::Equal) {
                // Every completed target must be assignable — CPython
                // validates this in the grammar, so `ast.parse` (no
                // compile step) rejects `f(x) = 1` too.
                if let Some(t) = targets.last() {
                    self.check_assign_target(t)?;
                }
                // Peek-parse the right-hand side as expression list;
                // re-classify if another `=` follows.
                self.target_entry = self.pos;
                let next = self.parse_assign_rhs()?;
                if self.check(&TokenKind::Equal) {
                    targets.push(next);
                } else {
                    let end = self.prev_token_span();
                    // `x = 1  # type: T` (pegen: `assignment: ... tc=[TYPE_COMMENT]`).
                    let tc = self.take_trailing_type_comment(end.end.0);
                    self.consume_stmt_end()?;
                    let span = start_span.merge(end);
                    if let Some(text) = tc {
                        self.record_stmt_type_comment(span.start.0, text);
                    }
                    return Ok(Stmt {
                        kind: StmtKind::Assign {
                            targets,
                            value: next,
                        },
                        span,
                    });
                }
            }
            // Shouldn't reach here: we only exit the loop after the
            // final RHS has been consumed by the branch above.
            unreachable!("assignment loop fell through");
        }

        // Python-2-style `print foo` / `exec foo`: a bare `print`/`exec`
        // name directly followed by another expression. CPython special-
        // cases the diagnostic (`invalid_legacy_expression`).
        if self.at_expression_start() {
            if let ExprKind::Name(n) = &first.kind {
                if n == "print" || n == "exec" {
                    let stray = self.parse_expression_list(true)?;
                    return Err(ParseError::Unexpected {
                        span: first.span.merge(stray.span),
                        message: format!(
                            "Missing parentheses in call to '{n}'. Did you mean {n}(...)?"
                        ),
                    });
                }
            }
        }

        // Plain expression statement.
        let end = self.prev_token_span();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind: StmtKind::Expr(first),
            span: start_span.merge(end),
        })
    }

    fn try_aug_op(&mut self) -> Option<BinOp> {
        let op = match self.peek() {
            TokenKind::PlusEqual => BinOp::Add,
            TokenKind::MinusEqual => BinOp::Sub,
            TokenKind::StarEqual => BinOp::Mult,
            TokenKind::SlashEqual => BinOp::Div,
            TokenKind::DoubleSlashEqual => BinOp::FloorDiv,
            TokenKind::PercentEqual => BinOp::Mod,
            TokenKind::DoubleStarEqual => BinOp::Pow,
            TokenKind::AmperEqual => BinOp::BitAnd,
            TokenKind::VbarEqual => BinOp::BitOr,
            TokenKind::CaretEqual => BinOp::BitXor,
            TokenKind::LeftShiftEqual => BinOp::LShift,
            TokenKind::RightShiftEqual => BinOp::RShift,
            TokenKind::AtEqual => BinOp::MatMult,
            _ => return None,
        };
        self.bump();
        Some(op)
    }

    fn parse_function_def(&mut self, decorator_list: Vec<Expr>) -> Result<Stmt, ParseError> {
        let def_tok = self.bump(); // `def`
        let name_tok = self.expect(&TokenKind::Name, "function name")?;
        let name = self.ident(name_tok.span);
        // PEP 695: optional `[T, *Ts, **P]` type-parameter list. The
        // captured names desugar into `TypeVar` bindings around the def
        // (see `desugar_pep695_def`) so annotations referencing them
        // resolve and `f.__type_params__` is populated.
        let type_params = self.collect_pep695_type_params()?;
        // pegen `invalid_def_raw` uses a *forced* token here, so the
        // missing-paren diagnostic fires no matter what follows
        // (`def f:` and `def f -> int:` both say "expected '('").
        if !self.check(&TokenKind::LPar) {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "expected '('".to_owned(),
            });
        }
        let lp = self.bump();
        let args = self.parse_function_arguments()?;
        let rp = self.expect(&TokenKind::RPar, "`)`")?;
        // Per-parameter type comments (`a,  # type: A`) live between the
        // parens.
        self.attach_arg_type_comments(&args, lp.span.end.0, rp.span.start.0);
        let returns = if self.eat(&TokenKind::RArrow) {
            Some(self.parse_expression(false)?)
        } else {
            None
        };
        // A generic def's annotations evaluate inside the PEP 695
        // annotation scope, where walrus/yield/await are illegal.
        if !type_params.is_empty() {
            let ctx = "the definition of a generic";
            for arg in args
                .posonlyargs
                .iter()
                .chain(args.args.iter())
                .chain(args.vararg.iter())
                .chain(args.kwonlyargs.iter())
                .chain(args.kwarg.iter())
            {
                if let Some(ann) = &arg.annotation {
                    check_type_param_expr(ann, ctx)?;
                }
            }
            if let Some(r) = &returns {
                check_type_param_expr(r, ctx)?;
            }
        }
        self.expect(&TokenKind::Colon, "`:`")?;
        // `def f():  # type: (...) -> T` and/or an own-line comment as the
        // first thing in the body — one of them, not both (pegen
        // `invalid_double_type_comments`).
        let colon_tc = self.take_colon_type_comment();
        let (body_tc, body_tc_count) = self.take_def_body_type_comments();
        if (colon_tc.is_some() && body_tc_count > 0) || body_tc_count > 1 {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "Cannot have two type comments on def".to_owned(),
            });
        }
        let def_tc = colon_tc.or(body_tc);
        let body = self.parse_block("function definition", def_tok.span)?;
        let span_end = body.last().map_or(def_tok.span, |s| self.block_end(s.span));
        let span = def_tok.span.merge(span_end);
        if let Some(text) = def_tc {
            self.record_stmt_type_comment(span.start.0, text);
        }
        Ok(Stmt {
            kind: StmtKind::FunctionDef {
                name,
                args,
                body,
                decorator_list,
                type_params,
                returns: returns.map(Box::new),
            },
            span,
        })
    }

    /// Dispatch on the construct that follows `async`: `def`, `for`,
    /// or `with`. The `async` keyword itself was already detected by
    /// [`Self::parse_statement`] (or follows a decorator chain).
    fn parse_async_stmt(&mut self, decorator_list: Vec<Expr>) -> Result<Stmt, ParseError> {
        let async_tok = self.bump(); // `async`
        match self.peek() {
            TokenKind::Keyword(Keyword::Def) => {
                let stmt = self.parse_function_def(decorator_list)?;
                let span = async_tok.span.merge(stmt.span);
                self.retag_stmt_type_comment(stmt.span.start.0, span.start.0);
                match stmt.kind {
                    StmtKind::FunctionDef {
                        name,
                        args,
                        body,
                        decorator_list,
                        type_params,
                        returns,
                    } => Ok(Stmt {
                        kind: StmtKind::AsyncFunctionDef {
                            name,
                            args,
                            body,
                            decorator_list,
                            type_params,
                            returns,
                        },
                        span,
                    }),
                    _ => unreachable!("parse_function_def returns FunctionDef"),
                }
            }
            TokenKind::Keyword(Keyword::For) => {
                if !decorator_list.is_empty() {
                    return Err(ParseError::Unexpected {
                        span: async_tok.span,
                        message: "decorators only apply to `async def`, not `async for`".to_owned(),
                    });
                }
                let stmt = self.parse_for()?;
                let span = async_tok.span.merge(stmt.span);
                self.retag_stmt_type_comment(stmt.span.start.0, span.start.0);
                match stmt.kind {
                    StmtKind::For {
                        target,
                        iter,
                        body,
                        orelse,
                    } => Ok(Stmt {
                        kind: StmtKind::AsyncFor {
                            target,
                            iter,
                            body,
                            orelse,
                        },
                        span,
                    }),
                    _ => unreachable!("parse_for returns For"),
                }
            }
            TokenKind::Keyword(Keyword::With) => {
                if !decorator_list.is_empty() {
                    return Err(ParseError::Unexpected {
                        span: async_tok.span,
                        message: "decorators only apply to `async def`, not `async with`"
                            .to_owned(),
                    });
                }
                let stmt = self.parse_with()?;
                let span = async_tok.span.merge(stmt.span);
                self.retag_stmt_type_comment(stmt.span.start.0, span.start.0);
                match stmt.kind {
                    StmtKind::With { items, body } => Ok(Stmt {
                        kind: StmtKind::AsyncWith { items, body },
                        span,
                    }),
                    _ => unreachable!("parse_with returns With"),
                }
            }
            other => Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: format!("expected `def`, `for`, or `with` after `async`, got {other:?}"),
            }),
        }
    }

    fn parse_class_def(&mut self, decorator_list: Vec<Expr>) -> Result<Stmt, ParseError> {
        let class_tok = self.bump(); // `class`
        let name_tok = self.expect(&TokenKind::Name, "class name")?;
        let name = self.ident(name_tok.span);
        // PEP 695: optional `[T, *Ts, **P]` type-parameter list — same
        // desugar as the function form (TypeVar bindings around the def).
        let type_params = self.collect_pep695_type_params()?;
        let (bases, keywords) = if self.check(&TokenKind::LPar) {
            let lp = self.bump();
            let (a, kw) = self.parse_call_args(lp.span)?;
            // `class C(x for x in L):` — pegen's class_def_raw only
            // accepts `arguments`, not a bare genexp; plain "invalid
            // syntax". A *parenthesized* genexp base is grammatically
            // fine (it fails later at runtime instead). A bare genexp's
            // node span starts at the class's own `(`; a parenthesized
            // one starts at its inner `(`.
            if let [only] = a.as_slice() {
                if matches!(only.kind, ExprKind::GeneratorExp { .. })
                    && kw.is_empty()
                    && only.span.start == lp.span.start
                {
                    return Err(ParseError::Unexpected {
                        span: only.span,
                        message: "invalid syntax".to_owned(),
                    });
                }
            }
            self.expect(&TokenKind::RPar, "`)`")?;
            (a, kw)
        } else {
            (Vec::new(), Vec::new())
        };
        // A generic class's bases/keywords evaluate inside the PEP 695
        // annotation scope, where walrus/yield/await are illegal.
        if !type_params.is_empty() {
            let ctx = "the definition of a generic";
            for b in &bases {
                check_type_param_expr(b, ctx)?;
            }
            for k in &keywords {
                check_type_param_expr(&k.value, ctx)?;
            }
        }
        self.expect(&TokenKind::Colon, "`:`")?;
        let body = self.parse_block("class definition", class_tok.span)?;
        let span_end = body
            .last()
            .map_or(class_tok.span, |s| self.block_end(s.span));
        let span = class_tok.span.merge(span_end);
        Ok(Stmt {
            kind: StmtKind::ClassDef {
                name,
                bases,
                keywords,
                body,
                decorator_list,
                type_params,
            },
            span,
        })
    }

    fn parse_try(&mut self) -> Result<Stmt, ParseError> {
        let try_tok = self.bump(); // `try`
        self.expect(&TokenKind::Colon, "`:`")?;
        let body = self.parse_block("'try' statement", try_tok.span)?;
        self.skip_trivia_and_newlines();
        let mut handlers = Vec::new();
        let mut orelse: Vec<Stmt> = Vec::new();
        let mut finalbody: Vec<Stmt> = Vec::new();
        let mut saw_star = false;
        let mut saw_plain = false;
        while self.at_keyword(Keyword::Except) {
            let exc_tok = self.bump(); // `except`
            let is_star = matches!(self.peek(), TokenKind::Star);
            let mut kw_span = exc_tok.span;
            if is_star {
                kw_span = kw_span.merge(self.bump().span);
                saw_star = true;
            } else {
                saw_plain = true;
            }
            if saw_star && saw_plain {
                return Err(ParseError::Unexpected {
                    span: kw_span,
                    message: "cannot have both 'except' and 'except*' on the same 'try'".to_owned(),
                });
            }
            let (type_, name) = if self.check(&TokenKind::Colon) {
                if is_star {
                    // CPython anchors this at the token where the
                    // exception type should have appeared (the `:`).
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "expected one or more exception types".to_owned(),
                    });
                }
                (None, None)
            } else {
                // `except` ⏎ — pegen `invalid_except_stmt`.
                if matches!(self.peek(), TokenKind::Newline) {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "expected ':'".to_owned(),
                    });
                }
                let first_tok_span = self.peek_token().span;
                let t = self.parse_expression(false)?;
                // `except A, B:` — pegen `invalid_except_stmt` on 3.13;
                // under `-X lang=next` (PEP 758, 3.14) an unparenthesized
                // comma list is a tuple of exception types, valid only
                // without an `as` clause.
                let t = if self.check(&TokenKind::Comma) {
                    if !weavepy_lexer::lang_preview() {
                        return Err(ParseError::Unexpected {
                            span: t.span,
                            message: "multiple exception types must be parenthesized".to_owned(),
                        });
                    }
                    let mut elts = vec![t];
                    while self.check(&TokenKind::Comma) {
                        self.bump();
                        // Trailing comma is allowed (`except A, B,:`).
                        if self.check(&TokenKind::Colon) || self.at_keyword(Keyword::As) {
                            break;
                        }
                        elts.push(self.parse_expression(false)?);
                    }
                    if self.at_keyword(Keyword::As) {
                        return Err(ParseError::Unexpected {
                            span: self.peek_token().span,
                            message:
                                "multiple exception types must be parenthesized when using 'as'"
                                    .to_owned(),
                        });
                    }
                    let tup_span = first_tok_span.merge(self.prev_token_span());
                    Expr {
                        kind: ExprKind::Tuple(elts),
                        span: tup_span,
                    }
                } else {
                    t
                };
                let n = if self.at_keyword(Keyword::As) {
                    self.bump();
                    let stmt = if is_star { "except*" } else { "except" };
                    self.as_target_diagnostic(
                        Some(&TokenKind::Colon),
                        |next| *next == TokenKind::Colon,
                        |name| format!("cannot use {stmt} statement with {name}"),
                    )?;
                    let nt = self.expect(&TokenKind::Name, "name after `as`")?;
                    Some(self.ident(nt.span))
                } else {
                    None
                };
                (Some(t), n)
            };
            self.expect(&TokenKind::Colon, "`:`")?;
            let handler_body = self.parse_block(
                if is_star {
                    "'except*' statement"
                } else {
                    "'except' statement"
                },
                exc_tok.span,
            )?;
            let span_end = handler_body
                .last()
                .map_or(exc_tok.span, |s| self.block_end(s.span));
            handlers.push(ExceptHandler {
                type_,
                name,
                body: handler_body,
                span: exc_tok.span.merge(span_end),
                is_star,
            });
            self.skip_trivia_and_newlines();
        }
        if self.at_keyword(Keyword::Else) {
            let else_tok = self.bump();
            self.expect(&TokenKind::Colon, "`:`")?;
            orelse = self.parse_block("'else' statement", else_tok.span)?;
            self.skip_trivia_and_newlines();
        }
        if self.at_keyword(Keyword::Finally) {
            let fin_tok = self.bump();
            self.expect(&TokenKind::Colon, "`:`")?;
            finalbody = self.parse_block("'finally' statement", fin_tok.span)?;
        }
        if handlers.is_empty() && finalbody.is_empty() {
            return Err(ParseError::Unexpected {
                span: try_tok.span,
                message: "expected 'except' or 'finally' block".to_owned(),
            });
        }
        let span_end = finalbody
            .last()
            .or_else(|| orelse.last())
            .or_else(|| handlers.last().map(|h| &h.body).and_then(|b| b.last()))
            .or_else(|| body.last())
            .map_or(try_tok.span, |s| self.block_end(s.span));
        Ok(Stmt {
            kind: StmtKind::Try {
                body,
                handlers,
                orelse,
                finalbody,
            },
            span: try_tok.span.merge(span_end),
        })
    }

    fn parse_raise(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump(); // `raise`
        let (exc, cause) = if matches!(
            self.peek(),
            TokenKind::Newline | TokenKind::Semi | TokenKind::Endmarker
        ) {
            (None, None)
        } else {
            let e = self.parse_expression(false)?;
            let c = if self.at_keyword(Keyword::From) {
                self.bump();
                Some(self.parse_expression(false)?)
            } else {
                None
            };
            (Some(e), c)
        };
        let end = self.prev_token_span();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind: StmtKind::Raise { exc, cause },
            span: kw.span.merge(end),
        })
    }

    fn parse_with(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump(); // `with`
                              // CPython 3.10+ supports `with (a, b as c, d): body` with
                              // parenthesized item lists. The slice supports both forms.
        let mut items = Vec::new();
        let paren = matches!(self.peek(), TokenKind::LPar) && self.is_with_paren_list_start();
        if paren {
            self.bump();
            loop {
                items.push(self.parse_with_item()?);
                if !self.eat(&TokenKind::Comma) {
                    break;
                }
                if self.check(&TokenKind::RPar) {
                    break;
                }
            }
            self.expect(&TokenKind::RPar, "`)`")?;
        } else {
            loop {
                items.push(self.parse_with_item()?);
                if !self.eat(&TokenKind::Comma) {
                    break;
                }
            }
        }
        self.expect(&TokenKind::Colon, "`:`")?;
        let tc = self.take_colon_type_comment();
        if let Some(text) = tc {
            self.record_stmt_type_comment(kw.span.start.0, text);
        }
        let body = self.parse_block("'with' statement", kw.span)?;
        let span_end = body.last().map_or(kw.span, |s| self.block_end(s.span));
        Ok(Stmt {
            kind: StmtKind::With { items, body },
            span: kw.span.merge(span_end),
        })
    }

    /// Lookahead: is the `(` we just saw the start of a parenthesised
    /// `with`-item list (rather than a parenthesised expression like
    /// `with (a + b): ...`)? Heuristic: scan forward for `as` or `,`
    /// at depth 0 before the closing `)` and a `:`.
    fn is_with_paren_list_start(&self) -> bool {
        let mut depth = 0i32;
        let mut i = self.pos;
        while let Some(tok) = self.tokens.get(i) {
            match &tok.kind {
                TokenKind::LPar | TokenKind::LSqb | TokenKind::LBrace => depth += 1,
                TokenKind::RPar | TokenKind::RSqb | TokenKind::RBrace => {
                    depth -= 1;
                    if depth == 0 {
                        return false;
                    }
                }
                TokenKind::Comma if depth == 1 => return true,
                TokenKind::Keyword(Keyword::As) if depth == 1 => return true,
                TokenKind::Newline | TokenKind::Endmarker => return false,
                _ => {}
            }
            i += 1;
        }
        false
    }

    fn parse_with_item(&mut self) -> Result<WithItem, ParseError> {
        let context_expr = self.parse_expression(false)?;
        let optional_vars = if self.at_keyword(Keyword::As) {
            self.bump();
            let target = self.parse_unary()?;
            // CPython (`invalid_with_item`): the `as` target is validated
            // at parse time with the bare "cannot assign to X" message.
            if let Some((offender, _)) = Self::find_invalid_target(&target, false) {
                return Err(self.assign_target_error(offender, true));
            }
            Some(target)
        } else {
            None
        };
        Ok(WithItem {
            context_expr,
            optional_vars,
        })
    }

    fn parse_function_arguments(&mut self) -> Result<Arguments, ParseError> {
        self.parse_arguments_inner(true)
    }

    fn parse_lambda_arguments(&mut self) -> Result<Arguments, ParseError> {
        self.parse_arguments_inner(false)
    }

    fn parse_arguments_inner(&mut self, allow_annotation: bool) -> Result<Arguments, ParseError> {
        let mut args = Arguments::default();
        if self.check(&TokenKind::RPar) || self.check(&TokenKind::Colon) {
            return Ok(args);
        }
        // We walk the list, accumulating into the right bucket based on
        // markers (`/`, `*`, `**`). State machine:
        // 0 = positional (becomes posonlyargs if we see `/`)
        // 1 = post-`/` positional-or-keyword
        // 2 = keyword-only (after `*`)
        let mut phase = 0u8;
        let mut had_default = false;
        // A bare `*` separator (no `*args` name) requires at least one
        // keyword-only argument to follow it; CPython rejects `def f(p, *)`
        // and `def f(p, *, **kw)` with "named arguments must follow bare *".
        let mut bare_star_span: Option<Span> = None;
        // pegen `invalid_parameters` bookkeeping.
        let mut saw_slash = false;
        let mut saw_star = false;
        let mut saw_kwarg = false;
        loop {
            if self.check(&TokenKind::RPar) || self.check(&TokenKind::Colon) {
                break;
            }
            // Nothing may follow `**kwargs` (pegen `invalid_parameters`).
            if saw_kwarg {
                return Err(ParseError::Unexpected {
                    span: self.peek_token().span,
                    message: "arguments cannot follow var-keyword argument".to_owned(),
                });
            }
            // `*args` or bare `*` separator.
            if self.check(&TokenKind::Star) {
                let star_tok = self.bump();
                if saw_star {
                    return Err(ParseError::Unexpected {
                        span: star_tok.span,
                        message: "* argument may appear only once".to_owned(),
                    });
                }
                saw_star = true;
                if matches!(self.peek(), TokenKind::Name) {
                    let n = self.bump();
                    let annotation = self.try_arg_annotation(allow_annotation, true)?;
                    let starred_ann = matches!(
                        annotation.as_deref(),
                        Some(Expr {
                            kind: ExprKind::Starred(_),
                            ..
                        })
                    );
                    // CPython `arg` spans cover `NAME [: annotation]`.
                    let span = match annotation.as_deref() {
                        Some(a) => n.span.merge(a.span),
                        None => n.span,
                    };
                    args.vararg = Some(Arg {
                        name: self.ident(n.span),
                        annotation,
                        span,
                    });
                    if self.check(&TokenKind::Equal) {
                        // CPython's grammar has no default rule for a PEP 646
                        // star-annotated vararg, so `*args: *b = x` fails
                        // generically rather than via `invalid_star_etc`.
                        return Err(ParseError::Unexpected {
                            span: self.peek_token().span,
                            message: if starred_ann {
                                "invalid syntax".to_owned()
                            } else {
                                "var-positional argument cannot have default value".to_owned()
                            },
                        });
                    }
                } else if matches!(
                    self.peek(),
                    TokenKind::Comma | TokenKind::RPar | TokenKind::Colon
                ) {
                    bare_star_span = Some(star_tok.span);
                } else {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "invalid syntax".to_owned(),
                    });
                }
                phase = 2;
                if !self.eat(&TokenKind::Comma) {
                    break;
                }
                continue;
            }
            // `**kwargs`.
            if self.eat(&TokenKind::DoubleStar) {
                let n = self.expect(&TokenKind::Name, "kwarg name")?;
                let annotation = self.try_arg_annotation(allow_annotation, false)?;
                let span = match annotation.as_deref() {
                    Some(a) => n.span.merge(a.span),
                    None => n.span,
                };
                args.kwarg = Some(Arg {
                    name: self.ident(n.span),
                    annotation,
                    span,
                });
                if self.check(&TokenKind::Equal) {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "var-keyword argument cannot have default value".to_owned(),
                    });
                }
                saw_kwarg = true;
                if !self.eat(&TokenKind::Comma) {
                    break;
                }
                continue;
            }
            // `/` separator: everything we've collected becomes posonly.
            if self.check(&TokenKind::Slash) {
                let slash_tok = self.bump();
                // pegen `invalid_parameters` slash rules, in CPython's
                // precedence order.
                if saw_slash {
                    return Err(ParseError::Unexpected {
                        span: slash_tok.span,
                        message: "/ may appear only once".to_owned(),
                    });
                }
                if saw_star {
                    return Err(ParseError::Unexpected {
                        span: slash_tok.span,
                        message: "/ must be ahead of *".to_owned(),
                    });
                }
                if args.args.is_empty() {
                    return Err(ParseError::Unexpected {
                        span: slash_tok.span,
                        message: "at least one argument must precede /".to_owned(),
                    });
                }
                saw_slash = true;
                if self.check(&TokenKind::Star) {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "expected comma between / and *".to_owned(),
                    });
                }
                args.posonlyargs = std::mem::take(&mut args.args);
                phase = 1;
                if !self.eat(&TokenKind::Comma) {
                    break;
                }
                continue;
            }

            // `def f(x, (y, z)):` — pegen `invalid_parameters`.
            if self.check(&TokenKind::LPar) {
                return Err(ParseError::Unexpected {
                    span: self.peek_token().span,
                    message: if allow_annotation {
                        "Function parameters cannot be parenthesized".to_owned()
                    } else {
                        "Lambda expression parameters cannot be parenthesized".to_owned()
                    },
                });
            }
            let n = self.expect(&TokenKind::Name, "parameter name")?;
            let name = self.ident(n.span);
            let annotation = self.try_arg_annotation(allow_annotation, false)?;
            let default = if self.eat(&TokenKind::Equal) {
                // `def f(a, d=, c):` — pegen `invalid_default`.
                if matches!(
                    self.peek(),
                    TokenKind::Comma | TokenKind::RPar | TokenKind::Colon | TokenKind::Newline
                ) {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "expected default value expression".to_owned(),
                    });
                }
                Some(self.parse_expression(false)?)
            } else {
                None
            };
            let span = match annotation.as_deref() {
                Some(a) => n.span.merge(a.span),
                None => n.span,
            };
            let arg = Arg {
                name,
                annotation,
                span,
            };
            if phase == 2 {
                args.kwonlyargs.push(arg);
                args.kw_defaults.push(default);
            } else {
                args.args.push(arg);
                if let Some(d) = default {
                    args.defaults.push(d);
                    had_default = true;
                } else if had_default {
                    return Err(ParseError::Unexpected {
                        span: n.span,
                        message: "parameter without a default follows parameter with a default"
                            .to_owned(),
                    });
                }
            }

            if !self.eat(&TokenKind::Comma) {
                break;
            }
        }
        // A bare `*` must be followed by at least one keyword-only
        // argument (CPython: "named arguments must follow bare *").
        if let Some(span) = bare_star_span {
            if args.kwonlyargs.is_empty() {
                return Err(ParseError::Unexpected {
                    span,
                    message: "named arguments must follow bare *".to_owned(),
                });
            }
            // Under `type_comments=True`, a `# type:` comment trailing the
            // bare `*` itself has no parameter to bind to — pegen's
            // `invalid_star_etc`: "bare * has associated type comment"
            // (test_syntax's ast_for_arguments doctest).
            if self.type_comments.is_some() {
                let first_kwonly = args.kwonlyargs[0].span.start.0;
                if self
                    .take_type_comment_in(span.end.0, first_kwonly)
                    .is_some()
                {
                    return Err(ParseError::Unexpected {
                        span,
                        message: "bare * has associated type comment".to_owned(),
                    });
                }
            }
        }
        // No parameter name may repeat across any section
        // (positional-only, positional-or-keyword, `*args`, keyword-only,
        // `**kwargs`) — CPython raises "duplicate argument '<n>' in
        // function definition".
        let mut seen: Vec<&str> = Vec::new();
        let dup_span = |span: Span, name: &str| ParseError::Unexpected {
            span,
            message: format!("duplicate argument '{name}' in function definition"),
        };
        for a in args
            .posonlyargs
            .iter()
            .chain(args.args.iter())
            .chain(args.vararg.iter())
            .chain(args.kwonlyargs.iter())
            .chain(args.kwarg.iter())
        {
            if seen.contains(&a.name.as_str()) {
                return Err(dup_span(a.span, &a.name));
            }
            seen.push(a.name.as_str());
        }
        Ok(args)
    }

    fn try_arg_annotation(
        &mut self,
        allow: bool,
        star_ok: bool,
    ) -> Result<Option<Box<Expr>>, ParseError> {
        if allow && self.eat(&TokenKind::Colon) {
            // PEP 646: a `*args` parameter may carry an unpacked annotation —
            // `def f(*args: *Ts)`, `*args: *tuple[int, ...]`. Only the vararg
            // position permits this (`star_ok`); the compiler lowers the
            // `Starred` to `(*X,)[0]`, i.e. `Unpack[X]`.
            if star_ok && self.check(&TokenKind::Star) {
                let star_span = self.peek_token().span;
                self.bump();
                let inner = self.parse_expression(false)?;
                let span = star_span.merge(inner.span);
                return Ok(Some(Box::new(Expr {
                    kind: ExprKind::Starred(Box::new(inner)),
                    span,
                })));
            }
            Ok(Some(Box::new(self.parse_expression(false)?)))
        } else {
            Ok(None)
        }
    }

    fn parse_if(&mut self) -> Result<Stmt, ParseError> {
        let if_tok = self.bump(); // `if` (or `elif` — see recursion below)
        let if_what = if matches!(if_tok.kind, TokenKind::Keyword(Keyword::Elif)) {
            "'elif' statement"
        } else {
            "'if' statement"
        };
        // `if`/`elif` conditions are `namedexpression` productions.
        self.walrus_ok = true;
        let test = self.parse_expression(false)?;
        // `if x = 3:` — pegen `invalid_expression`/`invalid_named_expression`.
        if self.check(&TokenKind::Equal) {
            return Err(Self::display_equal_error(&test));
        }
        self.expect(&TokenKind::Colon, "`:`")?;
        let body = self.parse_block(if_what, if_tok.span)?;
        let orelse = if self.at_keyword(Keyword::Elif) {
            // Recurse: elif → nested `if`.
            let nested = self.parse_if()?;
            vec![nested]
        } else if self.at_keyword(Keyword::Else) {
            self.parse_else_block()?
        } else {
            Vec::new()
        };
        let span_end = orelse
            .last()
            .or_else(|| body.last())
            .map_or(if_tok.span, |s| self.block_end(s.span));
        Ok(Stmt {
            kind: StmtKind::If { test, body, orelse },
            span: if_tok.span.merge(span_end),
        })
    }

    fn parse_while(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump();
        // `while` conditions are `namedexpression` productions.
        self.walrus_ok = true;
        let test = self.parse_expression(false)?;
        // `while x = 3:` — same rule as `if`.
        if self.check(&TokenKind::Equal) {
            return Err(Self::display_equal_error(&test));
        }
        self.expect(&TokenKind::Colon, "`:`")?;
        let body = self.parse_block("'while' statement", kw.span)?;
        let orelse = if self.at_keyword(Keyword::Else) {
            self.parse_else_block()?
        } else {
            Vec::new()
        };
        let span_end = orelse
            .last()
            .or_else(|| body.last())
            .map_or(kw.span, |s| self.block_end(s.span));
        Ok(Stmt {
            kind: StmtKind::While { test, body, orelse },
            span: kw.span.merge(span_end),
        })
    }

    fn parse_for(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump();
        // For-loop targets are a constrained subset of expressions —
        // notably, they must not be parsed as comparisons, otherwise
        // `for i in xs` is mis-read as `for (i in xs)`. Use the
        // sub-comparison level.
        let target = self.parse_target_list_no_tuple()?;
        // CPython (`invalid_for_target`): the loop target is validated at
        // parse time, always with the bare "cannot assign to X" message.
        if let Some((offender, _)) = Self::find_invalid_target(&target, false) {
            return Err(self.assign_target_error(offender, true));
        }
        if !self.at_keyword(Keyword::In) {
            // pegen has no dedicated diagnostic here: `for i < ():` and
            // `for a, b` ⏎ are both the generic failure.
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "invalid syntax".to_owned(),
            });
        }
        self.bump();
        let iter = self.parse_expression_list(false)?;
        self.expect(&TokenKind::Colon, "`:`")?;
        let tc = self.take_colon_type_comment();
        if let Some(text) = tc {
            self.record_stmt_type_comment(kw.span.start.0, text);
        }
        let body = self.parse_block("'for' statement", kw.span)?;
        let orelse = if self.at_keyword(Keyword::Else) {
            self.parse_else_block()?
        } else {
            Vec::new()
        };
        let span_end = orelse
            .last()
            .or_else(|| body.last())
            .map_or(kw.span, |s| self.block_end(s.span));
        Ok(Stmt {
            kind: StmtKind::For {
                target,
                iter,
                body,
                orelse,
            },
            span: kw.span.merge(span_end),
        })
    }

    fn parse_return(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump();
        let value = if matches!(
            self.peek(),
            TokenKind::Newline | TokenKind::Semi | TokenKind::Endmarker
        ) {
            None
        } else {
            Some(self.parse_expression_list(true)?)
        };
        let end = self.prev_token_span();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind: StmtKind::Return(value),
            span: kw.span.merge(end),
        })
    }

    fn parse_import(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump();
        // pegen `invalid_import`.
        if matches!(self.peek(), TokenKind::Newline | TokenKind::Endmarker) {
            return Err(ParseError::Unexpected {
                span: kw.span,
                message: "Expected one or more names after 'import'".to_owned(),
            });
        }
        let mut names = Vec::new();
        loop {
            let start = self.peek_token().span;
            let dotted = self.parse_dotted_name()?;
            let asname = if self.at_keyword(Keyword::As) {
                self.bump();
                // pegen `invalid_dotted_as_name` (3.14).
                self.import_as_target_diagnostic()?;
                let n = self.expect(&TokenKind::Name, "name after `as`")?;
                Some(self.ident(n.span))
            } else {
                None
            };
            let alias = Alias {
                name: dotted,
                asname,
                span: start.merge(self.prev_token_span()),
            };
            Self::check_import_alias_debug(&alias)?;
            names.push(alias);
            if !self.eat(&TokenKind::Comma) {
                break;
            }
        }
        // pegen `invalid_import`: `import a from b`.
        if self.at_keyword(Keyword::From) {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "Did you mean to use 'from ... import ...' instead?".to_owned(),
            });
        }
        let end = self.prev_token_span();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind: StmtKind::Import(names),
            span: kw.span.merge(end),
        })
    }

    /// pegen `invalid_dotted_as_name` / `invalid_import_from_as_name`:
    /// `'as' !(NAME (',' | ')' | ';' | NEWLINE)) a=expression` →
    /// "cannot use X as import target".
    fn import_as_target_diagnostic(&mut self) -> Result<(), ParseError> {
        self.as_target_diagnostic(
            None,
            |next| {
                matches!(
                    next,
                    TokenKind::Comma
                        | TokenKind::RPar
                        | TokenKind::Semi
                        | TokenKind::Newline
                        | TokenKind::Endmarker
                )
            },
            |name| format!("cannot use {name} as import target"),
        )
    }

    /// CPython 3.14 (`_PyPegen_checked_alias`… via `alias` actions):
    /// an import that would bind `__debug__` — `import __debug__`,
    /// `import __debug__.x`, `import a as __debug__`, `from a import
    /// __debug__` — is "cannot assign to __debug__" over the alias.
    fn check_import_alias_debug(alias: &Alias) -> Result<(), ParseError> {
        let bound = alias
            .asname
            .as_deref()
            .unwrap_or_else(|| alias.name.split('.').next().unwrap_or(""));
        if bound == "__debug__" {
            return Err(ParseError::Unexpected {
                span: alias.span,
                message: "cannot assign to __debug__".to_owned(),
            });
        }
        Ok(())
    }

    fn parse_dotted_name(&mut self) -> Result<String, ParseError> {
        let first = self.expect(&TokenKind::Name, "module name")?;
        let mut out = self.ident(first.span);
        while self.eat(&TokenKind::Dot) {
            let n = self.expect(&TokenKind::Name, "name after `.`")?;
            out.push('.');
            out.push_str(&self.ident(n.span));
        }
        Ok(out)
    }

    fn parse_import_from(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump(); // `from`
        let mut level = 0u32;
        // `from ...pkg import x`: the lexer greedily tokenises `...` as
        // a single Ellipsis token, so relative-import dots arrive as a
        // mix of `.` and `...`.
        loop {
            if self.eat(&TokenKind::Dot) {
                level += 1;
            } else if self.eat(&TokenKind::Ellipsis) {
                level += 3;
            } else {
                break;
            }
        }
        let module = if matches!(self.peek(), TokenKind::Name) {
            Some(self.parse_dotted_name()?)
        } else {
            None
        };
        if !self.at_keyword(Keyword::Import) {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "expected `import`".to_owned(),
            });
        }
        let import_tok = self.bump();
        let names = if self.eat(&TokenKind::Star) {
            vec![Alias {
                name: "*".to_owned(),
                asname: None,
                span: self.prev_token_span(),
            }]
        } else {
            // pegen `invalid_import_from_targets`.
            if matches!(self.peek(), TokenKind::Newline | TokenKind::Endmarker) {
                return Err(ParseError::Unexpected {
                    span: import_tok.span,
                    message: "Expected one or more names after 'import'".to_owned(),
                });
            }
            let paren = self.eat(&TokenKind::LPar);
            let mut names = Vec::new();
            loop {
                // Tolerate a trailing comma inside parenthesised
                // `from x import (a, b,)` — common in real codebases.
                if paren && matches!(self.peek(), TokenKind::RPar) {
                    break;
                }
                // pegen `invalid_import_from_targets`: an unparenthesised
                // list may not end with a comma.
                if !paren && matches!(self.peek(), TokenKind::Newline | TokenKind::Endmarker) {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "trailing comma not allowed without surrounding parentheses"
                            .to_owned(),
                    });
                }
                let n = self.expect(&TokenKind::Name, "imported name")?;
                let name = self.ident(n.span);
                let asname = if self.at_keyword(Keyword::As) {
                    self.bump();
                    // pegen `invalid_import_from_as_name` (3.14).
                    self.import_as_target_diagnostic()?;
                    let n2 = self.expect(&TokenKind::Name, "name after `as`")?;
                    Some(self.ident(n2.span))
                } else {
                    None
                };
                let alias = Alias {
                    name,
                    asname,
                    span: n.span.merge(self.prev_token_span()),
                };
                Self::check_import_alias_debug(&alias)?;
                names.push(alias);
                if !self.eat(&TokenKind::Comma) {
                    break;
                }
            }
            if paren {
                self.expect(&TokenKind::RPar, "`)`")?;
            }
            names
        };
        // PEP 401: the parser itself activates FLUFL mode when it sees
        // the future import, so later tokens on the same parse are
        // affected even without compile flags (CPython pegen does the
        // same).
        if level == 0
            && module.as_deref() == Some("__future__")
            && names.iter().any(|a| a.name == "barry_as_FLUFL")
        {
            self.flufl = true;
        }
        let end = self.prev_token_span();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind: StmtKind::ImportFrom {
                module,
                names,
                level,
            },
            span: kw.span.merge(end),
        })
    }

    fn parse_global(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump();
        let names = self.parse_name_list()?;
        let end = self.prev_token_span();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind: StmtKind::Global(names),
            span: kw.span.merge(end),
        })
    }

    fn parse_nonlocal(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump();
        let names = self.parse_name_list()?;
        let end = self.prev_token_span();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind: StmtKind::Nonlocal(names),
            span: kw.span.merge(end),
        })
    }

    /// `del target_list`. Each target is any assignable expression; we
    /// reuse `parse_ternary` so subscripts and attribute access are
    /// supported with no extra plumbing.
    fn parse_del(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump();
        // Accept starred targets syntactically (`del *x`) so the
        // dedicated "cannot delete starred" diagnostic below fires
        // instead of a generic parse failure at the `*`.
        let mut targets = vec![self.parse_ternary_or_starred()?];
        while self.eat(&TokenKind::Comma) {
            if matches!(
                self.peek(),
                TokenKind::Newline | TokenKind::Semi | TokenKind::Endmarker
            ) {
                break;
            }
            targets.push(self.parse_ternary_or_starred()?);
        }
        // CPython (`invalid_del_stmt`): del targets are validated at parse
        // time — "cannot delete X" for anything but a name / attribute /
        // subscript / container of those. Unlike assignment, a starred
        // element is *never* deletable ("cannot delete starred").
        fn find_undeletable(e: &Expr) -> Option<&Expr> {
            match &e.kind {
                ExprKind::Name(_) | ExprKind::Attribute { .. } | ExprKind::Subscript { .. } => None,
                ExprKind::Tuple(items) | ExprKind::List(items) => {
                    items.iter().find_map(find_undeletable)
                }
                _ => Some(e),
            }
        }
        for t in &targets {
            if let Some(offender) = find_undeletable(t) {
                let name = if matches!(&offender.kind, ExprKind::Starred(_)) {
                    "starred"
                } else {
                    crate::ast::expr_name(offender)
                };
                return Err(ParseError::Unexpected {
                    span: offender.span,
                    message: format!("cannot delete {name}"),
                });
            }
        }
        let end = self.prev_token_span();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind: StmtKind::Delete(targets),
            span: kw.span.merge(end),
        })
    }

    /// `assert <test> [, <msg>]`
    ///
    /// The grammar is `'assert' test [',' test]` — the message is an
    /// arbitrary expression (not a `,`-separated tuple shorthand). We
    /// accept and store both for the compiler to lower.
    fn parse_assert(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump();
        let test = self.parse_ternary()?;
        let msg = if self.eat(&TokenKind::Comma) {
            Some(self.parse_ternary()?)
        } else {
            None
        };
        let end = self.prev_token_span();
        self.consume_stmt_end()?;
        Ok(Stmt {
            kind: StmtKind::Assert { test, msg },
            span: kw.span.merge(end),
        })
    }

    fn parse_name_list(&mut self) -> Result<Vec<String>, ParseError> {
        let mut names = Vec::new();
        loop {
            let n = self.expect(&TokenKind::Name, "name")?;
            names.push(self.ident(n.span));
            if !self.eat(&TokenKind::Comma) {
                break;
            }
        }
        Ok(names)
    }

    // ---------- match / case ----------

    /// `match subject: NEWLINE INDENT (case_block)+ DEDENT`. Caller has
    /// confirmed via [`Self::looks_like_match_statement`] that the
    /// soft-keyword `match` is in fact starting a match statement.
    fn parse_match(&mut self) -> Result<Stmt, ParseError> {
        let kw = self.bump();
        let subject = self.parse_match_subject()?;
        self.expect(&TokenKind::Colon, "`:`")?;
        self.expect(&TokenKind::Newline, "newline after `match ... :`")?;
        self.skip_trivia_and_newlines();
        if !self.check(&TokenKind::Indent) {
            return Err(ParseError::Indentation {
                span: self.peek_token().span,
                message: format!(
                    "expected an indented block after 'match' statement on line {}",
                    self.line_of(kw.span)
                ),
            });
        }
        self.bump();

        let mut cases = Vec::new();
        loop {
            self.skip_trivia_and_newlines();
            if matches!(self.peek(), TokenKind::Dedent | TokenKind::Endmarker) {
                break;
            }
            cases.push(self.parse_case_clause()?);
        }
        self.eat(&TokenKind::Dedent);
        if cases.is_empty() {
            return Err(ParseError::Unexpected {
                span: kw.span,
                message: "match statement needs at least one case".to_owned(),
            });
        }
        let span_end = cases.last().map_or(kw.span, |c| c.span);
        Ok(Stmt {
            kind: StmtKind::Match { subject, cases },
            span: kw.span.merge(span_end),
        })
    }

    /// pegen `invalid_match_stmt`: after the ordinary statement grammar
    /// rejected a line starting with the soft keyword `match`, retry it
    /// as a match statement; if a subject expression parses cleanly and
    /// a `:` doesn't follow, "expected ':'" wins over the expression
    /// path's error. Any other shape keeps the original error.
    fn match_stmt_fallback_error(&mut self, expr_err: ParseError) -> ParseError {
        let saved = self.pos;
        self.bump(); // `match`
        let subject_ok = self.parse_match_subject().is_ok();
        // Only a line that simply stopped short gets the named-token
        // hint (`match x` ⏎); `match x x:` stays "invalid syntax".
        if subject_ok && matches!(self.peek(), TokenKind::Newline | TokenKind::Endmarker) {
            let span = self.peek_token().span;
            self.pos = saved;
            return ParseError::Unexpected {
                span,
                message: "expected ':'".to_owned(),
            };
        }
        self.pos = saved;
        expr_err
    }

    /// CPython allows `match a, b:` (subject is an implicit tuple). We
    /// follow.
    fn parse_match_subject(&mut self) -> Result<Expr, ParseError> {
        // `subject_expr` admits named expressions (`match y := f():`).
        self.walrus_ok = true;
        let start_span = self.peek_token().span;
        let first = self.parse_ternary()?;
        if !self.check(&TokenKind::Comma) {
            return Ok(first);
        }
        let mut items = vec![first];
        while self.eat(&TokenKind::Comma) {
            if self.check(&TokenKind::Colon) {
                break;
            }
            self.walrus_ok = true;
            items.push(self.parse_ternary()?);
        }
        let end_span = self.prev_token_span();
        Ok(Expr {
            kind: ExprKind::Tuple(items),
            span: start_span.merge(end_span),
        })
    }

    fn parse_case_clause(&mut self) -> Result<MatchCase, ParseError> {
        // The contextual keyword `case` is a `Name` token.
        let case_tok = self.peek_token().clone();
        if !(matches!(self.peek(), TokenKind::Name) && self.lexeme(case_tok.span) == "case") {
            return Err(ParseError::Unexpected {
                span: case_tok.span,
                message: "expected `case`".to_owned(),
            });
        }
        self.bump();
        let pattern = self.parse_patterns()?;
        let guard = if self.at_keyword(Keyword::If) {
            self.bump();
            // `guard: 'if' named_expression`.
            self.walrus_ok = true;
            Some(self.parse_expression(false)?)
        } else {
            None
        };
        self.expect(&TokenKind::Colon, "`:`")?;
        let body = self.parse_block("'case' statement", case_tok.span)?;
        let span_end = body
            .last()
            .map_or(case_tok.span, |s| self.block_end(s.span));
        Ok(MatchCase {
            pattern,
            guard,
            body,
            span: case_tok.span.merge(span_end),
        })
    }

    /// A case clause's patterns: CPython's `patterns` rule, which is an
    /// `open_sequence_pattern` (`maybe_star_pattern ',' …`) *or* a single
    /// `pattern`. The bracket-less, comma-separated form — `case 0, *x:` or
    /// `case a, b:` — is a sequence pattern exactly like `case (0, *x):`; a
    /// lone trailing comma (`case x,:`) is still a one-element sequence. Only a
    /// top-level comma (not one inside `[...]`/`(...)`) triggers this, so a
    /// plain `case 0:` stays a value pattern.
    fn parse_patterns(&mut self) -> Result<Pattern, ParseError> {
        let first = self.parse_pattern()?;
        if !self.check(&TokenKind::Comma) {
            return Ok(first);
        }
        let start = first.span;
        let mut items = vec![first];
        while self.eat(&TokenKind::Comma) {
            // A trailing comma before the guard/colon ends the sequence.
            if self.check(&TokenKind::Colon) || self.at_keyword(Keyword::If) {
                break;
            }
            items.push(self.parse_pattern()?);
        }
        Ok(Pattern {
            span: start.merge(self.prev_token_span()),
            kind: PatternKind::Sequence(items),
        })
    }

    /// Top-level pattern: `or_pattern ('as' NAME)?`.
    fn parse_pattern(&mut self) -> Result<Pattern, ParseError> {
        // pegen `EXTRA`: the `as`/`|` node spans every token it consumed,
        // parentheses around a grouped alternative included (`(0 as z) |
        // (1 as z)` starts at the first `(`), unlike the group pattern
        // itself, which passes its inner pattern's own span through.
        let start = self.peek_token().span;
        let pat = self.parse_or_pattern()?;
        if self.at_keyword(Keyword::As) {
            self.bump();
            // pegen `invalid_as_pattern` (3.14): `or_pattern 'as'
            // a=expression` names the offending target kind.
            self.as_target_diagnostic(
                None,
                |_| true,
                |name| format!("cannot use {name} as pattern target"),
            )?;
            if !self.check(&TokenKind::Name) {
                return Err(ParseError::Unexpected {
                    span: self.peek_token().span,
                    message: "invalid syntax".to_owned(),
                });
            }
            let n = self.bump();
            let name = self.ident(n.span);
            if name == "_" {
                return Err(ParseError::Unexpected {
                    span: n.span,
                    message: "cannot use '_' as a target".to_owned(),
                });
            }
            return Ok(Pattern {
                span: start.merge(n.span),
                kind: PatternKind::As {
                    pattern: Box::new(pat),
                    name,
                },
            });
        }
        Ok(pat)
    }

    /// `or_pattern: closed_pattern ('|' closed_pattern)*`.
    fn parse_or_pattern(&mut self) -> Result<Pattern, ParseError> {
        let start = self.peek_token().span;
        let first = self.parse_closed_pattern()?;
        if !self.check(&TokenKind::Vbar) {
            return Ok(first);
        }
        let mut alts = vec![first];
        while self.eat(&TokenKind::Vbar) {
            alts.push(self.parse_closed_pattern()?);
        }
        Ok(Pattern {
            span: start.merge(self.prev_token_span()),
            kind: PatternKind::Or(alts),
        })
    }

    /// One non-alternation pattern: literal, name, sequence, mapping,
    /// class, parenthesized, etc.
    fn parse_closed_pattern(&mut self) -> Result<Pattern, ParseError> {
        // Star in sequence: `[a, *rest]` or `*_`.
        if self.check(&TokenKind::Star) {
            let star_tok = self.bump();
            let (name, end_span) = match self.peek() {
                TokenKind::Name => {
                    let tok = self.bump();
                    let s = self.ident(tok.span);
                    (if s == "_" { None } else { Some(s) }, tok.span)
                }
                _ => {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "expected name after `*` in pattern".to_owned(),
                    });
                }
            };
            return Ok(Pattern {
                span: star_tok.span.merge(end_span),
                kind: PatternKind::Star(name),
            });
        }
        // Numeric / string / singleton literal patterns. `-N` is
        // allowed (negative numeric literal pattern).
        if matches!(
            self.peek(),
            TokenKind::Number | TokenKind::String | TokenKind::Minus
        ) {
            let e = self.parse_literal_pattern_expr()?;
            return Ok(Pattern {
                span: e.span,
                kind: PatternKind::Value(e),
            });
        }
        if self.at_keyword(Keyword::None) {
            let tok = self.bump();
            return Ok(Pattern {
                span: tok.span,
                kind: PatternKind::Singleton(Constant::None),
            });
        }
        if self.at_keyword(Keyword::True) {
            let tok = self.bump();
            return Ok(Pattern {
                span: tok.span,
                kind: PatternKind::Singleton(Constant::Bool(true)),
            });
        }
        if self.at_keyword(Keyword::False) {
            let tok = self.bump();
            return Ok(Pattern {
                span: tok.span,
                kind: PatternKind::Singleton(Constant::Bool(false)),
            });
        }
        if self.check(&TokenKind::LSqb) {
            return self.parse_sequence_pattern(true);
        }
        if self.check(&TokenKind::LPar) {
            return self.parse_paren_or_tuple_pattern();
        }
        if self.check(&TokenKind::LBrace) {
            return self.parse_mapping_pattern();
        }
        // Identifier-led: capture, wildcard, or value (qualified name)
        // — and possibly a class pattern if `(` follows.
        if matches!(self.peek(), TokenKind::Name) {
            return self.parse_name_pattern();
        }
        Err(ParseError::Unexpected {
            span: self.peek_token().span,
            message: format!("unexpected token in pattern: {:?}", self.peek()),
        })
    }

    /// Parse an expression that appears as the *value* of a literal
    /// pattern. Restricted to numbers, strings, and unary `-` on
    /// numerics — matching PEP 634.
    fn parse_literal_pattern_expr(&mut self) -> Result<Expr, ParseError> {
        let left = self.parse_signed_number_or_atom_pattern()?;
        // PEP 634 forbids f-strings as literal patterns (and mapping keys):
        // they aren't constant expressions.
        if matches!(left.kind, ExprKind::JoinedStr(_)) {
            return Err(ParseError::Unexpected {
                span: left.span,
                message: "patterns may only match literals and attribute lookups".to_owned(),
            });
        }
        // PEP 634 complex-number literal pattern: a signed real number summed
        // with (or differenced from) an imaginary number — `case 1 + 2j`,
        // `case -3 - 4j`, `case 0 + 0j`. Only a *numeric* left-hand side
        // begins one, so strings/singletons are returned untouched.
        fn is_number_constant(kind: &ExprKind) -> bool {
            matches!(
                kind,
                ExprKind::Constant(
                    Constant::Int(_)
                        | Constant::Float(_)
                        | Constant::BigInt(_)
                        | Constant::Complex(..)
                )
            )
        }
        fn is_real_constant(kind: &ExprKind) -> bool {
            matches!(
                kind,
                ExprKind::Constant(Constant::Int(_) | Constant::Float(_) | Constant::BigInt(_))
            )
        }
        let left_is_number = is_number_constant(&left.kind)
            || matches!(&left.kind,
                ExprKind::UnaryOp { op: UnaryOp::USub, operand }
                    if is_number_constant(&operand.kind));
        if left_is_number && matches!(self.peek(), TokenKind::Plus | TokenKind::Minus) {
            // CPython (pegen `invalid_complex_number`): the left operand
            // must be a real literal and the right an imaginary one —
            // `case 0j+0:`, `case 0j+0j:`, `case 0+0:` are all rejected.
            let left_is_real = is_real_constant(&left.kind)
                || matches!(&left.kind,
                    ExprKind::UnaryOp { op: UnaryOp::USub, operand }
                        if is_real_constant(&operand.kind));
            if !left_is_real {
                return Err(ParseError::Unexpected {
                    span: left.span,
                    message: "real number required in complex literal".to_owned(),
                });
            }
            let op_tok = self.bump();
            let op = if matches!(op_tok.kind, TokenKind::Plus) {
                BinOp::Add
            } else {
                BinOp::Sub
            };
            let num = self.peek_token().clone();
            if !matches!(num.kind, TokenKind::Number) {
                return Err(ParseError::Unexpected {
                    span: num.span,
                    message: "expected an imaginary number in complex literal pattern".to_owned(),
                });
            }
            self.bump();
            let value =
                parse_number(self.lexeme(num.span)).map_err(|m| ParseError::Unexpected {
                    span: num.span,
                    message: m,
                })?;
            if !matches!(value, Constant::Complex(..)) {
                return Err(ParseError::Unexpected {
                    span: num.span,
                    message: "imaginary number required in complex literal".to_owned(),
                });
            }
            let right = Expr {
                kind: ExprKind::Constant(value),
                span: num.span,
            };
            let span = left.span.merge(num.span);
            return Ok(Expr {
                kind: ExprKind::BinOp {
                    left: Box::new(left),
                    op,
                    right: Box::new(right),
                },
                span,
            });
        }
        Ok(left)
    }

    /// The `signed_number | atom` core of a literal pattern (a negative
    /// numeric literal, or a plain number/string/etc.). Used on its own and
    /// as the left operand of a complex-number literal pattern.
    fn parse_signed_number_or_atom_pattern(&mut self) -> Result<Expr, ParseError> {
        if self.check(&TokenKind::Minus) {
            let minus = self.bump();
            let tok = self.peek_token().clone();
            if !matches!(tok.kind, TokenKind::Number) {
                return Err(ParseError::Unexpected {
                    span: tok.span,
                    message: "expected numeric literal after `-` in pattern".to_owned(),
                });
            }
            self.bump();
            let value =
                parse_number(self.lexeme(tok.span)).map_err(|m| ParseError::Unexpected {
                    span: tok.span,
                    message: m,
                })?;
            // CPython keeps the sign as `UnaryOp(USub, Constant)` in the
            // AST (`case -1:` / `case -1j:`); folding happens later in the
            // compiler. Folding here broke `ast.unparse` round-trips
            // (test_unparse over test_patma: `-1j` reprinted as `(-0-1j)`).
            return Ok(Expr {
                kind: ExprKind::UnaryOp {
                    op: UnaryOp::USub,
                    operand: Box::new(Expr {
                        kind: ExprKind::Constant(value),
                        span: tok.span,
                    }),
                },
                span: minus.span.merge(tok.span),
            });
        }
        self.parse_atom()
    }

    /// `Name (. Name)* ('(' pat_args ')')?`. The `.`-chain makes it a
    /// value pattern; `(` makes it a class pattern; otherwise capture.
    fn parse_name_pattern(&mut self) -> Result<Pattern, ParseError> {
        let first = self.bump();
        let first_name = self.ident(first.span);
        // Dotted: value pattern.
        if self.check(&TokenKind::Dot) {
            let mut expr = Expr {
                kind: ExprKind::Name(first_name),
                span: first.span,
            };
            while self.eat(&TokenKind::Dot) {
                let n = self.expect(&TokenKind::Name, "attribute name in pattern")?;
                let attr = self.ident(n.span);
                let span = expr.span.merge(n.span);
                expr = Expr {
                    kind: ExprKind::Attribute {
                        value: Box::new(expr),
                        attr,
                    },
                    span,
                };
            }
            if self.check(&TokenKind::LPar) {
                return self.finish_class_pattern(expr);
            }
            return Ok(Pattern {
                span: expr.span,
                kind: PatternKind::Value(expr),
            });
        }
        // Class pattern: bare `Name(...)`.
        if self.check(&TokenKind::LPar) {
            let cls = Expr {
                kind: ExprKind::Name(first_name),
                span: first.span,
            };
            return self.finish_class_pattern(cls);
        }
        // Wildcard `_` binds nothing.
        if first_name == "_" {
            return Ok(Pattern {
                span: first.span,
                kind: PatternKind::Capture(None),
            });
        }
        Ok(Pattern {
            span: first.span,
            kind: PatternKind::Capture(Some(first_name)),
        })
    }

    fn finish_class_pattern(&mut self, cls: Expr) -> Result<Pattern, ParseError> {
        self.expect(&TokenKind::LPar, "`(`")?;
        let mut positionals = Vec::new();
        let mut keywords: Vec<(String, Pattern)> = Vec::new();
        let mut saw_kw = false;
        while !self.check(&TokenKind::RPar) {
            // A keyword arg: `name=pattern`.
            if matches!(self.peek(), TokenKind::Name)
                && matches!(self.peek_at(1), Some(TokenKind::Equal))
            {
                let n = self.bump();
                let name = self.ident(n.span);
                self.bump(); // `=`
                let p = self.parse_pattern()?;
                keywords.push((name, p));
                saw_kw = true;
            } else {
                if saw_kw {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "positional patterns follow keyword patterns".to_owned(),
                    });
                }
                positionals.push(self.parse_pattern()?);
            }
            if !self.eat(&TokenKind::Comma) {
                break;
            }
        }
        let close = self.expect(&TokenKind::RPar, "`)`")?;
        Ok(Pattern {
            span: cls.span.merge(close.span),
            kind: PatternKind::Class {
                cls,
                positionals,
                keywords,
            },
        })
    }

    fn parse_sequence_pattern(&mut self, square: bool) -> Result<Pattern, ParseError> {
        let close = if square {
            TokenKind::RSqb
        } else {
            TokenKind::RPar
        };
        let open_tok = self.bump();
        let mut items = Vec::new();
        while !self.check(&close) {
            items.push(self.parse_pattern()?);
            if !self.eat(&TokenKind::Comma) {
                break;
            }
        }
        let close_tok = self.expect(&close, if square { "`]`" } else { "`)`" })?;
        Ok(Pattern {
            span: open_tok.span.merge(close_tok.span),
            kind: PatternKind::Sequence(items),
        })
    }

    /// `(p)` (parenthesized pattern, equivalent to `p`) or
    /// `(p, q, ...)` (tuple sequence pattern).
    fn parse_paren_or_tuple_pattern(&mut self) -> Result<Pattern, ParseError> {
        let open_tok = self.bump();
        if self.check(&TokenKind::RPar) {
            let close_tok = self.bump();
            return Ok(Pattern {
                span: open_tok.span.merge(close_tok.span),
                kind: PatternKind::Sequence(Vec::new()),
            });
        }
        let first = self.parse_pattern()?;
        if !self.check(&TokenKind::Comma) {
            // A star pattern is only legal inside a *sequence* pattern;
            // `case (*x):` without the trailing comma is a group
            // pattern, which CPython's grammar rejects.
            if matches!(first.kind, PatternKind::Star(_)) {
                return Err(ParseError::Unexpected {
                    span: first.span,
                    message: "invalid syntax".to_owned(),
                });
            }
            // Parenthesized group: CPython keeps the inner pattern's
            // own positions (`group_pattern` has no EXTRA of its own).
            self.expect(&TokenKind::RPar, "`)`")?;
            return Ok(first);
        }
        let mut items = vec![first];
        while self.eat(&TokenKind::Comma) {
            if self.check(&TokenKind::RPar) {
                break;
            }
            items.push(self.parse_pattern()?);
        }
        let close_tok = self.expect(&TokenKind::RPar, "`)`")?;
        Ok(Pattern {
            span: open_tok.span.merge(close_tok.span),
            kind: PatternKind::Sequence(items),
        })
    }

    fn parse_mapping_pattern(&mut self) -> Result<Pattern, ParseError> {
        let open_tok = self.bump();
        let mut keys = Vec::new();
        let mut patterns = Vec::new();
        let mut rest: Option<Option<String>> = None;
        while !self.check(&TokenKind::RBrace) {
            if self.eat(&TokenKind::DoubleStar) {
                let n = self.expect(&TokenKind::Name, "name after `**` in mapping pattern")?;
                let name = self.ident(n.span);
                if name == "_" {
                    // PEP 634 forbids `**_` (pegen `invalid_double_star_pattern`
                    // is a bare "invalid syntax" in 3.13).
                    return Err(ParseError::Unexpected {
                        span: n.span,
                        message: "invalid syntax".to_owned(),
                    });
                }
                rest = Some(Some(name));
                if !self.eat(&TokenKind::Comma) {
                    break;
                }
                // PEP 634: `**rest` must be the last item in a mapping
                // pattern. CPython reports a plain "invalid syntax"
                // anchored at the trailing item.
                if !self.check(&TokenKind::RBrace) {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "invalid syntax".to_owned(),
                    });
                }
                continue;
            }
            let key = self.parse_literal_or_value_key()?;
            self.expect(&TokenKind::Colon, "`:`")?;
            let p = self.parse_pattern()?;
            keys.push(key);
            patterns.push(p);
            if !self.eat(&TokenKind::Comma) {
                break;
            }
        }
        let close_tok = self.expect(&TokenKind::RBrace, "`}`")?;
        Ok(Pattern {
            span: open_tok.span.merge(close_tok.span),
            kind: PatternKind::Mapping {
                keys,
                patterns,
                rest,
            },
        })
    }

    /// Allowed mapping keys per PEP 634: numeric/string literals or
    /// dotted attribute expressions (value patterns).
    fn parse_literal_or_value_key(&mut self) -> Result<Expr, ParseError> {
        if matches!(
            self.peek(),
            TokenKind::Number | TokenKind::String | TokenKind::Minus
        ) {
            return self.parse_literal_pattern_expr();
        }
        if self.at_keyword(Keyword::None) {
            let t = self.bump();
            return Ok(Expr {
                kind: ExprKind::Constant(Constant::None),
                span: t.span,
            });
        }
        if self.at_keyword(Keyword::True) {
            let t = self.bump();
            return Ok(Expr {
                kind: ExprKind::Constant(Constant::Bool(true)),
                span: t.span,
            });
        }
        if self.at_keyword(Keyword::False) {
            let t = self.bump();
            return Ok(Expr {
                kind: ExprKind::Constant(Constant::Bool(false)),
                span: t.span,
            });
        }
        // Dotted name as a value key.
        let n = self.expect(&TokenKind::Name, "key")?;
        let mut expr = Expr {
            kind: ExprKind::Name(self.ident(n.span)),
            span: n.span,
        };
        while self.eat(&TokenKind::Dot) {
            let attr_tok = self.expect(&TokenKind::Name, "attribute name in key")?;
            let attr = self.ident(attr_tok.span);
            let span = expr.span.merge(attr_tok.span);
            expr = Expr {
                kind: ExprKind::Attribute {
                    value: Box::new(expr),
                    attr,
                },
                span,
            };
        }
        Ok(expr)
    }

    /// 1-based source line containing the start of `span`.
    fn line_of(&self, span: weavepy_lexer::Span) -> u32 {
        let start = (span.start.0 as usize).min(self.source.len());
        self.source[..start].bytes().filter(|&b| b == b'\n').count() as u32 + 1
    }

    /// Block suite after `:`. `after` names the introducing construct
    /// for CPython's IndentationError message ("'if' statement",
    /// "function definition", …); `intro_span` is the keyword's span,
    /// whose line number the message cites.
    fn parse_block(
        &mut self,
        after: &str,
        intro_span: weavepy_lexer::Span,
    ) -> Result<Vec<Stmt>, ParseError> {
        // After the `:`, either a single inline statement or a
        // NEWLINE INDENT block DEDENT.
        if matches!(self.peek(), TokenKind::Newline) {
            self.bump();
            self.skip_trivia_and_newlines();
            if !self.check(&TokenKind::Indent) {
                return Err(ParseError::Indentation {
                    span: self.peek_token().span,
                    message: format!(
                        "expected an indented block after {after} on line {}",
                        self.line_of(intro_span)
                    ),
                });
            }
            self.bump();
            let mut body = Vec::new();
            loop {
                self.skip_trivia_and_newlines();
                if matches!(self.peek(), TokenKind::Dedent | TokenKind::Endmarker) {
                    break;
                }
                let s = self.parse_statement()?;
                body.push(s);
            }
            self.eat(&TokenKind::Dedent);
            if body.is_empty() {
                return Err(ParseError::Unexpected {
                    span: self.peek_token().span,
                    message: "empty block".to_owned(),
                });
            }
            Ok(body)
        } else {
            // Inline suite after `:` — Python's `simple_stmt`:
            //   small_stmt (';' small_stmt)* [';'] NEWLINE
            // e.g. `if x: y = 1`, `class A: pass`, and crucially the
            // multi-statement form `def f(): a = 1; return a`. We used to
            // parse only the first statement, leaving `; return a` to be
            // re-parsed by the *enclosing* scope — which then rejected the
            // `return` as "outside function". Each `parse_statement`
            // consumes its own terminator (`;` or NEWLINE via
            // `consume_stmt_end`), so we keep going while that terminator
            // was a `;` and another small statement follows on the line.
            let mut body = Vec::new();
            loop {
                body.push(self.parse_statement()?);
                let ended_with_semi = matches!(
                    self.tokens.get(self.pos.wrapping_sub(1)).map(|t| &t.kind),
                    Some(TokenKind::Semi)
                );
                if !ended_with_semi {
                    break;
                }
                // A trailing `;` right before the line break (`a = 1;`)
                // ends the suite; consume the closing NEWLINE so the
                // caller resumes from a clean statement boundary.
                match self.peek() {
                    TokenKind::Newline => {
                        self.bump();
                        break;
                    }
                    TokenKind::Endmarker | TokenKind::Dedent => break,
                    _ => {}
                }
            }
            Ok(body)
        }
    }

    // ============================================================
    // Expressions
    // ============================================================

    /// Parse one expression. If `allow_tuple` is true, top-level
    /// `,` builds a `Tuple`; if false, comma is a delimiter that
    /// ends the expression.
    fn parse_expression(&mut self, allow_tuple: bool) -> Result<Expr, ParseError> {
        if allow_tuple {
            self.parse_expression_list(true)
        } else {
            self.parse_ternary()
        }
    }

    /// Parse a tuple-or-expression as it appears on the right side
    /// of `=` or `return`.
    ///
    /// Accepts `*x` as a sub-element: this is what makes both
    /// PEP 3132 assignment targets (`a, *b, c = xs`) and the
    /// general iterable-unpacking case in collection literals fall
    /// out of a single parse.
    fn parse_expression_list(&mut self, _allow_trailing_comma: bool) -> Result<Expr, ParseError> {
        // An unparenthesized tuple starts at its first *token*, which
        // is the opening paren when the first element is parenthesized
        // (`(a), b` spans from the `(`; the element itself does not).
        let start_span = self.peek_token().span;
        let first = self.parse_ternary_or_starred()?;
        if !self.check(&TokenKind::Comma) {
            return Ok(first);
        }
        let mut items = vec![first];
        while self.eat(&TokenKind::Comma) {
            if matches!(
                self.peek(),
                TokenKind::Newline
                    | TokenKind::Semi
                    | TokenKind::Endmarker
                    | TokenKind::RPar
                    | TokenKind::RSqb
                    | TokenKind::RBrace
                    | TokenKind::Colon
                    | TokenKind::Equal
            ) {
                break;
            }
            items.push(self.parse_ternary_or_starred()?);
        }
        // `star_expressions` ends at the last consumed token, so a
        // trailing comma is part of the tuple's span (EndPositionTests
        // test_tuples: `1 ,`).
        let end_span = self.prev_token_span();
        Ok(Expr {
            kind: ExprKind::Tuple(items),
            span: start_span.merge(end_span),
        })
    }

    /// `*expr` or a regular ternary. Used wherever a comma-separated
    /// element may legitimately be a starred form (assignment
    /// targets, tuple/list/set literals, function call arguments).
    fn parse_ternary_or_starred(&mut self) -> Result<Expr, ParseError> {
        if let TokenKind::Star = self.peek() {
            let star_tok = self.peek_token().clone();
            self.bump();
            // `'*' bitwise_or` — a starred operand is never a bare
            // walrus, even where the surrounding element allows one.
            self.walrus_ok = false;
            let inner = self.parse_ternary()?;
            // Token-range span (CPython's EXTRA): a parenthesized
            // operand's node span excludes its parens, so merge with
            // the last *consumed token* instead of the child span.
            let span = star_tok.span.merge(self.prev_token_span());
            return Ok(Expr {
                kind: ExprKind::Starred(Box::new(inner)),
                span,
            });
        }
        self.parse_ternary()
    }

    fn parse_ternary(&mut self) -> Result<Expr, ParseError> {
        // Take both one-shot context flags up front so neither leaks
        // into sub-expressions (e.g. `f(lambda: x := 1)` must not let
        // the argument position's walrus permission reach the lambda
        // body).
        let walrus_ok = std::mem::take(&mut self.walrus_ok);
        let in_lambda_body = std::mem::take(&mut self.lambda_body);
        let in_walrus_value = std::mem::take(&mut self.walrus_value);
        self.expr_entry = self.pos;
        if self.at_keyword(Keyword::Lambda) {
            return self.parse_lambda(in_walrus_value);
        }
        // `x = pass if c else 1` (pegen `invalid_expression`, 3.14).
        self.check_stmt_as_ifexp_body()?;
        // `yield` is *not* a general expression in CPython's grammar: a
        // `yield_expr` is only admitted as a whole statement, as the
        // sole RHS of an (aug/ann) assignment, or parenthesized. Those
        // call sites invoke `parse_yield` themselves; anywhere else —
        // `f(yield 1)`, `1, yield`, `not yield` — is "invalid syntax"
        // (the atom fallback below the keyword check reports it).
        // PEP 572 walrus `NAME := expr`. The named-expression form
        // must syntactically be exactly a name followed by `:=`, and it
        // is only admitted where the grammar threads `namedexpression`
        // (the caller signals that via the one-shot `walrus_ok` flag —
        // see the field doc). The compiler enforces the rest of the
        // PEP's restrictions (comprehension-scope binding rules).
        if walrus_ok && matches!(self.peek(), TokenKind::Name) {
            if let Some(next) = self.tokens.get(self.pos + 1) {
                if matches!(next.kind, TokenKind::ColonEqual) {
                    let name_tok = self.peek_token().clone();
                    let name = self.ident(name_tok.span);
                    self.bump(); // name
                    self.bump(); // :=
                    self.walrus_value = true;
                    let value = self.parse_ternary()?;
                    let span = name_tok.span.merge(self.prev_token_span());
                    return Ok(Expr {
                        kind: ExprKind::NamedExpr {
                            target: Box::new(Expr {
                                kind: ExprKind::Name(name),
                                span: name_tok.span,
                            }),
                            value: Box::new(value),
                        },
                        span,
                    });
                }
            }
        }
        let start = self.peek_token().span;
        let body = self.parse_or()?;
        if self.check(&TokenKind::ColonEqual) {
            // Inside a lambda body, leave the `:=` for `parse_lambda`:
            // CPython blames the *lambda* ("cannot use assignment
            // expressions with lambda"), not the trailing name.
            if in_lambda_body {
                return Ok(body);
            }
            // A `:=` after a plain name in a position whose production
            // is `expression !':='` (statement expressions, assignment
            // RHS, keyword-argument values, defaults, annotations, …)
            // is pegen's generic "invalid syntax" at the operator.
            if matches!(body.kind, ExprKind::Name(_)) {
                return Err(ParseError::Unexpected {
                    span: self.peek_token().span,
                    message: "invalid syntax".to_owned(),
                });
            }
            // `(True := 1)` — pegen `invalid_named_expression`: only
            // plain names may be walrus targets; constants get named.
            return Err(ParseError::Unexpected {
                span: body.span,
                message: format!(
                    "cannot use assignment expressions with {}",
                    crate::ast::expr_name(&body)
                ),
            });
        }
        if self.at_keyword(Keyword::If) {
            self.bump();
            let test = self.parse_or()?;
            if !self.at_keyword(Keyword::Else) {
                // pegen `invalid_expression` requires `!(':')` here:
                // with a colon next the generic failure wins.
                if self.check(&TokenKind::Colon) {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "invalid syntax".to_owned(),
                    });
                }
                return Err(ParseError::Unexpected {
                    span: self.peek_token().span,
                    message: "expected 'else' after 'if' expression".to_owned(),
                });
            }
            self.bump();
            // pegen `invalid_expression` (3.14): `a 'if' b 'else'
            // !expression` — a statement keyword (or nothing) after
            // `else` is diagnosed at the next token.
            if !self.at_expression_start() {
                return Err(ParseError::Unexpected {
                    span: self.peek_token().span,
                    message: "expected expression after 'else', but statement is given".to_owned(),
                });
            }
            let orelse = self.parse_ternary()?;
            let span = start.merge(self.prev_token_span());
            return Ok(Expr {
                kind: ExprKind::IfExp {
                    test: Box::new(test),
                    body: Box::new(body),
                    orelse: Box::new(orelse),
                },
                span,
            });
        }
        Ok(body)
    }

    /// pegen's `(yield_expr | star_expressions)` — the RHS of an
    /// assignment / augmented assignment / annotated assignment, where
    /// a whole `yield` expression is legal (but never as a tuple
    /// element: `x = yield, 1` is invalid syntax).
    fn parse_assign_rhs(&mut self) -> Result<Expr, ParseError> {
        if self.at_keyword(Keyword::Yield) {
            return self.parse_yield();
        }
        self.parse_expression_list(true)
    }

    fn parse_yield(&mut self) -> Result<Expr, ParseError> {
        let kw = self.bump(); // `yield`
        if self.at_keyword(Keyword::From) {
            self.bump();
            let value = self.parse_ternary()?;
            let span = kw.span.merge(self.prev_token_span());
            return Ok(Expr {
                kind: ExprKind::YieldFrom(Box::new(value)),
                span,
            });
        }
        // Bare `yield` followed by an end-of-expression token returns
        // `Yield(value=None)`. Otherwise parse a single value (or
        // implicit-tuple `yield 1, 2`).
        if matches!(
            self.peek(),
            TokenKind::Newline
                | TokenKind::Semi
                | TokenKind::Endmarker
                | TokenKind::RPar
                | TokenKind::RSqb
                | TokenKind::RBrace
                | TokenKind::Comma
                | TokenKind::Colon
                | TokenKind::Equal
        ) {
            return Ok(Expr {
                kind: ExprKind::Yield(None),
                span: kw.span,
            });
        }
        let value = self.parse_expression_list(true)?;
        let span = kw.span.merge(self.prev_token_span());
        Ok(Expr {
            kind: ExprKind::Yield(Some(Box::new(value))),
            span,
        })
    }

    fn parse_lambda(&mut self, in_walrus_value: bool) -> Result<Expr, ParseError> {
        let kw = self.bump(); // `lambda`
        let args = if self.check(&TokenKind::Colon) {
            Arguments::default()
        } else {
            self.parse_lambda_arguments()?
        };
        self.expect(&TokenKind::Colon, "`:`")?;
        self.lambda_body = true;
        let body = self.parse_ternary()?;
        let span = kw.span.merge(self.prev_token_span());
        // `lambda: x := 1` — the body parse left the `:=` unconsumed
        // (see `lambda_body`); pegen's `invalid_named_expression` names
        // the lambda as the impossible walrus target. When the lambda is
        // itself a walrus's *value* (`(x := lambda: y := 1)`), that rule
        // never re-matches and the failure is the generic one.
        if self.check(&TokenKind::ColonEqual) {
            return Err(ParseError::Unexpected {
                span: if in_walrus_value {
                    self.peek_token().span
                } else {
                    span
                },
                message: if in_walrus_value {
                    "invalid syntax".to_owned()
                } else {
                    "cannot use assignment expressions with lambda".to_owned()
                },
            });
        }
        Ok(Expr {
            kind: ExprKind::Lambda {
                args,
                body: Box::new(body),
            },
            span,
        })
    }

    fn parse_or(&mut self) -> Result<Expr, ParseError> {
        let start = self.peek_token().span;
        let first = self.parse_and()?;
        if !self.at_keyword(Keyword::Or) {
            return Ok(first);
        }
        let mut values = vec![first];
        while self.at_keyword(Keyword::Or) {
            self.bump();
            values.push(self.parse_and()?);
        }
        let span = start.merge(self.prev_token_span());
        Ok(Expr {
            kind: ExprKind::BoolOp {
                op: BoolOp::Or,
                values,
            },
            span,
        })
    }

    fn parse_and(&mut self) -> Result<Expr, ParseError> {
        let start = self.peek_token().span;
        let first = self.parse_not()?;
        if !self.at_keyword(Keyword::And) {
            return Ok(first);
        }
        let mut values = vec![first];
        while self.at_keyword(Keyword::And) {
            self.bump();
            values.push(self.parse_not()?);
        }
        let span = start.merge(self.prev_token_span());
        Ok(Expr {
            kind: ExprKind::BoolOp {
                op: BoolOp::And,
                values,
            },
            span,
        })
    }

    fn parse_not(&mut self) -> Result<Expr, ParseError> {
        if self.at_keyword(Keyword::Not) {
            let kw = self.bump();
            let operand = self.parse_not()?;
            let span = kw.span.merge(self.prev_token_span());
            return Ok(Expr {
                kind: ExprKind::UnaryOp {
                    op: UnaryOp::Not,
                    operand: Box::new(operand),
                },
                span,
            });
        }
        self.parse_comparison()
    }

    fn parse_comparison(&mut self) -> Result<Expr, ParseError> {
        let start = self.peek_token().span;
        let left = self.parse_bit_or()?;
        let mut ops = Vec::new();
        let mut comparators = Vec::new();
        while let Some(op) = self.try_cmp_op()? {
            ops.push(op);
            comparators.push(self.parse_bit_or()?);
        }
        if ops.is_empty() {
            return Ok(left);
        }
        let span = start.merge(self.prev_token_span());
        Ok(Expr {
            kind: ExprKind::Compare {
                left: Box::new(left),
                ops,
                comparators,
            },
            span,
        })
    }

    fn try_cmp_op(&mut self) -> Result<Option<CmpOp>, ParseError> {
        let op = match self.peek() {
            TokenKind::Less => CmpOp::Lt,
            TokenKind::Greater => CmpOp::Gt,
            TokenKind::LessEqual => CmpOp::LtE,
            TokenKind::GreaterEqual => CmpOp::GtE,
            TokenKind::EqEqual => CmpOp::Eq,
            TokenKind::NotEqual => {
                // PEP 401 (`_PyPegen_check_barry_as_flufl`): the lexer
                // produces NOTEQUAL for both spellings; exactly one is
                // legal depending on whether `barry_as_FLUFL` is
                // active.
                let span = self.peek_token().span;
                let text = self.lexeme(span);
                if self.flufl && text != "<>" {
                    return Err(ParseError::Unexpected {
                        span,
                        message: "with Barry as BDFL, use '<>' instead of '!='".to_owned(),
                    });
                }
                if !self.flufl && text == "<>" {
                    return Err(ParseError::Unexpected {
                        span,
                        message: "invalid syntax".to_owned(),
                    });
                }
                CmpOp::NotEq
            }
            TokenKind::Keyword(Keyword::In) => CmpOp::In,
            TokenKind::Keyword(Keyword::Is) => {
                // Two-token `is not` handled below.
                self.bump();
                if self.at_keyword(Keyword::Not) {
                    self.bump();
                    return Ok(Some(CmpOp::IsNot));
                }
                return Ok(Some(CmpOp::Is));
            }
            TokenKind::Keyword(Keyword::Not) => {
                // `not in`
                if matches!(self.peek_at(1), Some(TokenKind::Keyword(Keyword::In))) {
                    self.bump();
                    self.bump();
                    return Ok(Some(CmpOp::NotIn));
                }
                return Ok(None);
            }
            _ => return Ok(None),
        };
        self.bump();
        Ok(Some(op))
    }

    fn parse_bit_or(&mut self) -> Result<Expr, ParseError> {
        // All the binop ladders use token-range spans (`start` is the
        // first token of the rule, the end is the last consumed token)
        // so a parenthesized operand — whose node span excludes the
        // parens, as in CPython — still yields `(a) + b` spanning from
        // the `(`. PEP-657 caret anchors depend on this.
        let start = self.peek_token().span;
        let mut left = self.parse_bit_xor()?;
        while self.check(&TokenKind::Vbar) {
            self.bump();
            let right = self.parse_bit_xor()?;
            let span = start.merge(self.prev_token_span());
            left = Expr {
                kind: ExprKind::BinOp {
                    left: Box::new(left),
                    op: BinOp::BitOr,
                    right: Box::new(right),
                },
                span,
            };
        }
        Ok(left)
    }

    fn parse_bit_xor(&mut self) -> Result<Expr, ParseError> {
        let start = self.peek_token().span;
        let mut left = self.parse_bit_and()?;
        while self.check(&TokenKind::Caret) {
            self.bump();
            let right = self.parse_bit_and()?;
            let span = start.merge(self.prev_token_span());
            left = Expr {
                kind: ExprKind::BinOp {
                    left: Box::new(left),
                    op: BinOp::BitXor,
                    right: Box::new(right),
                },
                span,
            };
        }
        Ok(left)
    }

    fn parse_bit_and(&mut self) -> Result<Expr, ParseError> {
        let start = self.peek_token().span;
        let mut left = self.parse_shift()?;
        while self.check(&TokenKind::Amper) {
            self.bump();
            let right = self.parse_shift()?;
            let span = start.merge(self.prev_token_span());
            left = Expr {
                kind: ExprKind::BinOp {
                    left: Box::new(left),
                    op: BinOp::BitAnd,
                    right: Box::new(right),
                },
                span,
            };
        }
        Ok(left)
    }

    fn parse_shift(&mut self) -> Result<Expr, ParseError> {
        let start = self.peek_token().span;
        let mut left = self.parse_addsub()?;
        loop {
            let op = match self.peek() {
                TokenKind::LeftShift => BinOp::LShift,
                TokenKind::RightShift => BinOp::RShift,
                _ => break,
            };
            self.bump();
            let right = self.parse_addsub()?;
            let span = start.merge(self.prev_token_span());
            left = Expr {
                kind: ExprKind::BinOp {
                    left: Box::new(left),
                    op,
                    right: Box::new(right),
                },
                span,
            };
        }
        Ok(left)
    }

    fn parse_addsub(&mut self) -> Result<Expr, ParseError> {
        let start = self.peek_token().span;
        let mut left = self.parse_muldiv()?;
        loop {
            let op = match self.peek() {
                TokenKind::Plus => BinOp::Add,
                TokenKind::Minus => BinOp::Sub,
                _ => break,
            };
            self.bump();
            self.reject_not_operand()?;
            let right = self.parse_muldiv()?;
            let span = start.merge(self.prev_token_span());
            left = Expr {
                kind: ExprKind::BinOp {
                    left: Box::new(left),
                    op,
                    right: Box::new(right),
                },
                span,
            };
        }
        Ok(left)
    }

    fn parse_muldiv(&mut self) -> Result<Expr, ParseError> {
        let start = self.peek_token().span;
        let mut left = self.parse_unary()?;
        loop {
            let op = match self.peek() {
                TokenKind::Star => BinOp::Mult,
                TokenKind::Slash => BinOp::Div,
                TokenKind::DoubleSlash => BinOp::FloorDiv,
                TokenKind::Percent => BinOp::Mod,
                TokenKind::At => BinOp::MatMult,
                _ => break,
            };
            self.bump();
            self.reject_not_operand()?;
            let right = self.parse_unary()?;
            let span = start.merge(self.prev_token_span());
            left = Expr {
                kind: ExprKind::BinOp {
                    left: Box::new(left),
                    op,
                    right: Box::new(right),
                },
                span,
            };
        }
        Ok(left)
    }

    fn parse_unary(&mut self) -> Result<Expr, ParseError> {
        // `await expr` (PEP 492 / RFC 0016). `await` sits at the
        // unary level — `await x + y` parses as `(await x) + y`,
        // matching CPython.
        if self.at_keyword(Keyword::Await) {
            let kw = self.bump();
            // CPython grammar: `await_primary: AWAIT primary` — a
            // directly chained `await await x` is invalid syntax
            // (`await (await x)` is fine: the parens make a primary).
            if self.at_keyword(Keyword::Await) {
                return Err(ParseError::Unexpected {
                    span: kw.span,
                    message: "invalid syntax".to_owned(),
                });
            }
            let operand = self.parse_unary()?;
            let span = kw.span.merge(self.prev_token_span());
            return Ok(Expr {
                kind: ExprKind::Await(Box::new(operand)),
                span,
            });
        }
        let op = match self.peek() {
            TokenKind::Plus => UnaryOp::UAdd,
            TokenKind::Minus => UnaryOp::USub,
            TokenKind::Tilde => UnaryOp::Invert,
            _ => return self.parse_power(),
        };
        let kw = self.bump();
        self.reject_not_operand()?;
        let operand = self.parse_unary()?;
        let span = kw.span.merge(self.prev_token_span());
        Ok(Expr {
            kind: ExprKind::UnaryOp {
                op,
                operand: Box::new(operand),
            },
            span,
        })
    }

    /// pegen `invalid_factor` / `invalid_arithmetic`: `not` binds looser
    /// than arithmetic, so it can't appear as an operand (`3 + not 3`,
    /// `- not 3`).
    fn reject_not_operand(&self) -> Result<(), ParseError> {
        if self.at_keyword(Keyword::Not) {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "'not' after an operator must be parenthesized".to_owned(),
            });
        }
        Ok(())
    }

    fn parse_power(&mut self) -> Result<Expr, ParseError> {
        let start = self.peek_token().span;
        let base = self.parse_trailer_chain()?;
        if !self.check(&TokenKind::DoubleStar) {
            return Ok(base);
        }
        self.bump();
        // `**` is right-associative, and binds tighter than unary on
        // the right side. Python's grammar: `power: await? primary ('**' factor)?`
        // where `factor` includes unary.
        let exponent = self.parse_unary()?;
        let span = start.merge(self.prev_token_span());
        Ok(Expr {
            kind: ExprKind::BinOp {
                left: Box::new(base),
                op: BinOp::Pow,
                right: Box::new(exponent),
            },
            span,
        })
    }

    fn parse_trailer_chain(&mut self) -> Result<Expr, ParseError> {
        // Token-range spans: `( a ).m()[0]` chains span from the `(`
        // even though the parenthesized base node itself starts at `a`.
        let start = self.peek_token().span;
        let mut base = self.parse_atom()?;
        loop {
            match self.peek() {
                TokenKind::LPar => {
                    let lp = self.bump();
                    let (args, keywords) = self.parse_call_args(lp.span)?;
                    let rp = self.expect(&TokenKind::RPar, "`)`")?;
                    let span = start.merge(rp.span);
                    base = Expr {
                        kind: ExprKind::Call {
                            func: Box::new(base),
                            args,
                            keywords,
                        },
                        span,
                    };
                }
                TokenKind::LSqb => {
                    self.bump();
                    let slice = self.parse_subscript()?;
                    // `x[a b]`, `x[a:b c]`: the hint spans from the last
                    // expression parsed inside the brackets.
                    let last = std::slice::from_ref(Self::last_subscript_expr(&slice));
                    let rb = self.expect_or_forgot_comma(&TokenKind::RSqb, "`]`", last)?;
                    let span = start.merge(rb.span);
                    base = Expr {
                        kind: ExprKind::Subscript {
                            value: Box::new(base),
                            slice: Box::new(slice),
                        },
                        span,
                    };
                }
                TokenKind::Dot => {
                    self.bump();
                    let n = self.expect(&TokenKind::Name, "attribute name")?;
                    let attr = self.ident(n.span);
                    let span = start.merge(n.span);
                    base = Expr {
                        kind: ExprKind::Attribute {
                            value: Box::new(base),
                            attr,
                        },
                        span,
                    };
                }
                _ => break,
            }
        }
        Ok(base)
    }

    fn parse_call_args(&mut self, lpar_span: Span) -> Result<(Vec<Expr>, Vec<KwArg>), ParseError> {
        let mut args = Vec::new();
        let mut keywords = Vec::new();
        if self.check(&TokenKind::RPar) {
            return Ok((args, keywords));
        }
        // Track keyword state so we can reject a plain positional argument
        // that follows a keyword (CPython: "positional argument follows
        // keyword argument") and a repeated keyword name (CPython:
        // "keyword argument repeated: <name>").
        let mut seen_keyword = false;
        let mut seen_kw_unpack = false;
        let mut kw_names: Vec<String> = Vec::new();
        loop {
            let arg_start = self.peek_token().span;
            if self.eat(&TokenKind::DoubleStar) {
                let val = self.parse_ternary()?;
                // `f(**kwargs={...})` — pegen `invalid_kwarg`.
                if self.check(&TokenKind::Equal) {
                    return Err(ParseError::Unexpected {
                        span: arg_start.merge(val.span),
                        message: "cannot assign to keyword argument unpacking".to_owned(),
                    });
                }
                seen_keyword = true;
                seen_kw_unpack = true;
                let span = arg_start.merge(val.span);
                keywords.push(KwArg {
                    arg: None,
                    value: val,
                    span,
                });
            } else if self.check(&TokenKind::Star) {
                let star_tok = self.bump();
                // A `*` whose operand doesn't parse is pegen's
                // `starred_expression` fallback: "Invalid star expression".
                // This outranks the "follows keyword unpacking" diagnostic:
                // `f(**x, *)` reports the bad star, not the ordering.
                let val = self.parse_ternary().map_err(|_| ParseError::Unexpected {
                    span: star_tok.span,
                    message: "Invalid star expression".to_owned(),
                })?;
                // `f(**x, *y)` — pegen `invalid_arguments`.
                if seen_kw_unpack {
                    return Err(ParseError::Unexpected {
                        span: star_tok.span,
                        message: "iterable argument unpacking follows keyword argument unpacking"
                            .to_owned(),
                    });
                }
                // `f(*args=[0])` — pegen `invalid_starred_expression_unpacking`.
                if self.check(&TokenKind::Equal) {
                    return Err(ParseError::Unexpected {
                        span: star_tok.span.merge(val.span),
                        message: "cannot assign to iterable argument unpacking".to_owned(),
                    });
                }
                let span = star_tok.span.merge(val.span);
                args.push(Expr {
                    kind: ExprKind::Starred(Box::new(val)),
                    span,
                });
            } else {
                // Could be a keyword arg `name=value` — peek ahead.
                if matches!(self.peek(), TokenKind::Name)
                    && matches!(self.peek_at(1), Some(TokenKind::Equal))
                {
                    let nt = self.bump();
                    let name = self.ident(nt.span);
                    if kw_names.contains(&name) {
                        return Err(ParseError::Unexpected {
                            span: nt.span,
                            message: format!("keyword argument repeated: {name}"),
                        });
                    }
                    self.bump(); // `=`
                                 // `f(a=)` — pegen `invalid_kwarg`.
                    if matches!(
                        self.peek(),
                        TokenKind::Comma | TokenKind::RPar | TokenKind::Newline
                    ) {
                        return Err(ParseError::Unexpected {
                            span: self.peek_token().span,
                            message: "expected argument value expression".to_owned(),
                        });
                    }
                    let val = self.parse_ternary()?;
                    // `f(__debug__=1)` — CPython `forbidden_name`; 3.14
                    // reports the whole `name=value` keyword's range.
                    if name == "__debug__" {
                        return Err(ParseError::Unexpected {
                            span: nt.span.merge(val.span),
                            message: "cannot assign to __debug__".to_owned(),
                        });
                    }
                    // `f(a = i for i in xs)` — pegen `invalid_arguments`:
                    // a generator expression can't be a keyword value
                    // without parentheses; CPython points at `a = i` with
                    // the '==' / ':=' hint.
                    if self.at_keyword(Keyword::For) || self.at_keyword(Keyword::Async) {
                        return Err(ParseError::Unexpected {
                            span: nt.span.merge(val.span),
                            message: "invalid syntax. Maybe you meant '==' or ':=' instead of \
                                      '='?"
                                .to_owned(),
                        });
                    }
                    seen_keyword = true;
                    kw_names.push(name.clone());
                    let span = nt.span.merge(val.span);
                    keywords.push(KwArg {
                        arg: Some(name),
                        value: val,
                        span,
                    });
                } else if matches!(
                    self.peek(),
                    TokenKind::Keyword(Keyword::True | Keyword::False | Keyword::None)
                ) && matches!(self.peek_at(1), Some(TokenKind::Equal))
                {
                    // `f(True=1)` — pegen `invalid_kwarg` names the
                    // constant.
                    let nt = self.peek_token().clone();
                    return Err(ParseError::Unexpected {
                        span: nt.span,
                        message: format!("cannot assign to {}", self.lexeme(nt.span)),
                    });
                } else {
                    let positional_tok = self.peek_token().clone();
                    if seen_keyword {
                        // The plain grammar (`kwargs`) stops here; the
                        // "positional follows keyword" diagnostic waits
                        // until a genexp has been ruled out (pegen tries
                        // `args ',' expression for_if_clauses` first).
                        self.first_fail.get_or_insert(self.pos);
                    }
                    // Positional arguments admit named expressions
                    // (`f(x := 1)`, `sum(y := i for i in xs)`).
                    self.walrus_ok = true;
                    let e = match self.parse_ternary() {
                        Ok(e) => e,
                        Err(_) if seen_keyword => {
                            return Err(
                                self.positional_after_keyword(positional_tok.span, seen_kw_unpack)
                            );
                        }
                        Err(e) => return Err(e),
                    };
                    // `f(1=2)` — a non-name expression followed by `=`.
                    if self.check(&TokenKind::Equal) {
                        return Err(ParseError::Unexpected {
                            span: e.span,
                            message: "expression cannot contain assignment, perhaps you meant \
                                      \"==\"?"
                                .to_owned(),
                        });
                    }
                    // Generator expression as single argument: `f(x for x in xs)`.
                    if self.at_keyword(Keyword::For) || self.at_keyword(Keyword::Async) {
                        let elt = e;
                        if !(args.is_empty() && keywords.is_empty()) {
                            // The plain grammar stops at the `for`.
                            self.first_fail.get_or_insert(self.pos);
                        }
                        let generators = self.parse_comp_for()?;
                        // `for_if_clauses` looks at the token after the
                        // last clause for another one.
                        self.peeked = self.peeked.max(Some(self.pos));
                        // CPython's genexp node (and the
                        // must-be-parenthesized error) spans the whole
                        // `elt for … in …`, not just the element.
                        let span = elt.span.merge(self.prev_token_span());
                        // A bare genexp must be the *only* argument.
                        if !(args.is_empty() && keywords.is_empty()) {
                            return Err(ParseError::Unexpected {
                                span,
                                message: "Generator expression must be parenthesized".to_owned(),
                            });
                        }
                        // CPython gives a bare-genexp argument the call's
                        // parentheses as its node span (`f(a for a in b)`
                        // → GeneratorExp spans `(a for a in b)`).
                        let node_span = if self.check(&TokenKind::RPar) {
                            lpar_span.merge(self.peek_token().span)
                        } else {
                            span
                        };
                        args.push(Expr {
                            kind: ExprKind::GeneratorExp {
                                elt: Box::new(elt),
                                generators,
                            },
                            span: node_span,
                        });
                        if self.check(&TokenKind::Comma) {
                            // pegen (`invalid_arguments`): `expression
                            // for_if_clauses ',' [args | expression
                            // for_if_clauses]` — the optional tail is
                            // parsed (with its own diagnostics) before
                            // the genexp error is raised.
                            self.bump();
                            self.peeked = self.peeked.max(Some(self.pos));
                            if !self.check(&TokenKind::RPar) {
                                let save = self.pos;
                                let _ = self.parse_call_args(lpar_span)?;
                                self.pos = save;
                            }
                            return Err(ParseError::Unexpected {
                                span,
                                message: "Generator expression must be parenthesized".to_owned(),
                            });
                        }
                    } else if seen_keyword {
                        return Err(
                            self.positional_after_keyword(positional_tok.span, seen_kw_unpack)
                        );
                    } else {
                        args.push(e);
                    }
                }
            }
            // Span of the most recent argument — CPython's "Perhaps you
            // forgot a comma?" underlines the *previous* element when two
            // expressions abut.
            let last_arg_span = Some(arg_start.merge(self.prev_token_span()));
            if !self.eat(&TokenKind::Comma) {
                // Two adjacent expressions with no comma — CPython's
                // `invalid_expression` rule anchors the error at the
                // *previous* element and suggests the missing comma.
                if !self.check(&TokenKind::RPar) && self.at_expression_start() {
                    if let Some(prev) = last_arg_span {
                        // The range runs through the stray expression
                        // (`invalid_expression: a=disjunction
                        // b=expression_without_invalid`); a nested parse
                        // error inside it wins.
                        self.first_fail.get_or_insert(self.pos);
                        let stray = self.parse_ternary()?;
                        return Err(ParseError::Unexpected {
                            span: prev.merge(stray.span),
                            message: "invalid syntax. Perhaps you forgot a comma?".to_owned(),
                        });
                    }
                }
                break;
            }
            if self.check(&TokenKind::RPar) {
                break;
            }
        }
        Ok((args, keywords))
    }

    fn positional_after_keyword(&self, span: Span, after_unpack: bool) -> ParseError {
        ParseError::Unexpected {
            span,
            message: if after_unpack {
                "positional argument follows keyword argument unpacking".to_owned()
            } else {
                "positional argument follows keyword argument".to_owned()
            },
        }
    }

    /// Could the current token begin an expression? Drives the
    /// "Perhaps you forgot a comma?" heuristic.
    fn at_expression_start(&self) -> bool {
        match self.peek() {
            TokenKind::Name
            | TokenKind::Number
            | TokenKind::String
            | TokenKind::LPar
            | TokenKind::LSqb
            | TokenKind::LBrace
            | TokenKind::Minus
            | TokenKind::Plus
            | TokenKind::Tilde
            | TokenKind::Ellipsis => true,
            TokenKind::Keyword(k) => matches!(
                k,
                Keyword::Lambda
                    | Keyword::Not
                    | Keyword::Await
                    | Keyword::None
                    | Keyword::True
                    | Keyword::False
            ),
            _ => false,
        }
    }

    /// The innermost last expression of a parsed subscript (pegen's
    /// `invalid_expression` fires on the `expression` that precedes a
    /// stray one, not on the enclosing slice or tuple).
    fn last_subscript_expr(e: &Expr) -> &Expr {
        match &e.kind {
            ExprKind::Tuple(elts) if !elts.is_empty() => {
                Self::last_subscript_expr(elts.last().unwrap())
            }
            ExprKind::Slice { lower, upper, step } => step
                .as_deref()
                .or(upper.as_deref())
                .or(lower.as_deref())
                .map_or(e, Self::last_subscript_expr),
            _ => e,
        }
    }

    fn parse_subscript(&mut self) -> Result<Expr, ParseError> {
        // Parse a single (sub)slice (`a`, `a:b`, `a:b:c`, etc.) — the
        // comma-separated form (`x[a, b, c]`) is handled by the outer
        // loop after this call returns.
        let start_tok_span = self.peek_token().span;
        let first = self.parse_subscript_single()?;
        if !self.check(&TokenKind::Comma) {
            // PEP 646: a lone starred element still forms a one-element tuple
            // index — `a[*b]` is `a[(*b,)]` (CPython parses the slice as
            // `Tuple(elts=[Starred(b)])`). Wrapping it here lets the existing
            // starred-tuple codegen build the index with unpacking.
            if matches!(first.kind, ExprKind::Starred(_)) {
                let span = first.span;
                return Ok(Expr {
                    kind: ExprKind::Tuple(vec![first]),
                    span,
                });
            }
            return Ok(first);
        }
        // Multi-element subscript: collect into a tuple. Used by
        // generic typing (`Dict[K, V]`, `Tuple[A, B, C]`), and by
        // NumPy-style indexing (`arr[i, j]`).
        let mut elts = vec![first];
        while self.eat(&TokenKind::Comma) {
            if matches!(self.peek(), TokenKind::RSqb) {
                break;
            }
            elts.push(self.parse_subscript_single()?);
        }
        let span = start_tok_span.merge(self.prev_token_span());
        Ok(Expr {
            kind: ExprKind::Tuple(elts),
            span,
        })
    }

    fn parse_subscript_single(&mut self) -> Result<Expr, ParseError> {
        // PEP 646: a subscript element may be a starred expression —
        // `tuple[int, *Ts]`, `A[float, *tuple[int, ...]]`. A star can't begin a
        // slice, so parse the unpacked expression and stop; the surrounding
        // index tuple is built with unpacking by the compiler.
        if self.check(&TokenKind::Star) {
            let star_span = self.peek_token().span;
            self.bump();
            // `A[*]` / `A[*:]` / `A[*(1:2)]` — pegen's `starred_expression`
            // fallback: "Invalid star expression".
            let value = self.parse_ternary().map_err(|_| ParseError::Unexpected {
                span: star_span,
                message: "Invalid star expression".to_owned(),
            })?;
            let span = star_span.merge(value.span);
            return Ok(Expr {
                kind: ExprKind::Starred(Box::new(value)),
                span,
            });
        }
        // Slice grammar: `lower? ':' upper? (':' step?)?` or plain expr.
        if self.check(&TokenKind::Colon) {
            let colon = self.bump();
            let upper = if matches!(
                self.peek(),
                TokenKind::Colon | TokenKind::RSqb | TokenKind::Comma
            ) {
                None
            } else {
                Some(Box::new(self.parse_ternary()?))
            };
            let step = if self.eat(&TokenKind::Colon) {
                if matches!(self.peek(), TokenKind::RSqb | TokenKind::Comma) {
                    None
                } else {
                    Some(Box::new(self.parse_ternary()?))
                }
            } else {
                None
            };
            // CPython Slice spans cover `':' upper? (':' step?)?`.
            let span = colon.span.merge(self.prev_token_span());
            return Ok(Expr {
                kind: ExprKind::Slice {
                    lower: None,
                    upper,
                    step,
                },
                span,
            });
        }
        // `slice: … | named_expression` — a non-slice subscript element
        // admits a bare walrus (`a[x := 1]`); slice *bounds* do not.
        let first_is_bare_walrus = matches!(self.peek(), TokenKind::Name)
            && matches!(
                self.tokens.get(self.pos + 1).map(|t| &t.kind),
                Some(TokenKind::ColonEqual)
            );
        self.walrus_ok = true;
        // pegen's `slice` rule spans from its first *token*, so a
        // parenthesized lower bound (`x[(a+1):]`) starts the Slice at
        // the `(`, not at the inner expression.
        let first_tok_span = self.peek_token().span;
        let first = self.parse_ternary()?;
        if !self.check(&TokenKind::Colon) {
            return Ok(first);
        }
        // `a[x := 1 : 2]` — the walrus alternative only matches when no
        // slice colon follows (pegen: `slice: [expression] ':' … |
        // named_expression`); with a colon next the walrus is invalid.
        if first_is_bare_walrus {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "invalid syntax".to_owned(),
            });
        }
        self.bump();
        let upper = if matches!(
            self.peek(),
            TokenKind::Colon | TokenKind::RSqb | TokenKind::Comma
        ) {
            None
        } else {
            Some(Box::new(self.parse_ternary()?))
        };
        let step = if self.eat(&TokenKind::Colon) {
            if matches!(self.peek(), TokenKind::RSqb | TokenKind::Comma) {
                None
            } else {
                Some(Box::new(self.parse_ternary()?))
            }
        } else {
            None
        };
        let span = first_tok_span.merge(self.prev_token_span());
        Ok(Expr {
            kind: ExprKind::Slice {
                lower: Some(Box::new(first)),
                upper,
                step,
            },
            span,
        })
    }

    fn parse_atom(&mut self) -> Result<Expr, ParseError> {
        let tok = self.peek_token().clone();
        match &tok.kind {
            TokenKind::Number => {
                self.bump();
                let value =
                    parse_number(self.lexeme(tok.span)).map_err(|m| ParseError::Unexpected {
                        span: tok.span,
                        message: m,
                    })?;
                Ok(Expr {
                    kind: ExprKind::Constant(value),
                    span: tok.span,
                })
            }
            TokenKind::String => self.parse_string_concat(tok),
            TokenKind::Name => {
                self.bump();
                let name = self.ident(tok.span);
                // A non-ASCII identifier that NFKC-normalizes to a constant
                // keyword (`Truᵉ` -> `True`) can't be represented as a Name:
                // CPython's ast2obj_expr raises ValueError
                // (test_constant_as_unicode_name).
                if matches!(name.as_str(), "True" | "False" | "None") {
                    return Err(ParseError::IdentifierConstant {
                        span: tok.span,
                        name,
                    });
                }
                Ok(Expr {
                    kind: ExprKind::Name(name),
                    span: tok.span,
                })
            }
            TokenKind::Keyword(Keyword::True) => {
                self.bump();
                Ok(Expr {
                    kind: ExprKind::Constant(Constant::Bool(true)),
                    span: tok.span,
                })
            }
            TokenKind::Keyword(Keyword::False) => {
                self.bump();
                Ok(Expr {
                    kind: ExprKind::Constant(Constant::Bool(false)),
                    span: tok.span,
                })
            }
            TokenKind::Keyword(Keyword::None) => {
                self.bump();
                Ok(Expr {
                    kind: ExprKind::Constant(Constant::None),
                    span: tok.span,
                })
            }
            TokenKind::Ellipsis => {
                self.bump();
                Ok(Expr {
                    kind: ExprKind::Constant(Constant::Ellipsis),
                    span: tok.span,
                })
            }
            TokenKind::LPar => self.parse_paren_or_tuple(),
            TokenKind::LSqb => self.parse_list_or_listcomp(),
            TokenKind::LBrace => self.parse_dict_or_set(),
            // pegen's generic parse failure: a bare "invalid syntax"
            // pointing at the token the expression grammar rejected.
            _ => Err(ParseError::Unexpected {
                span: tok.span,
                message: "invalid syntax".to_owned(),
            }),
        }
    }

    fn parse_paren_or_tuple(&mut self) -> Result<Expr, ParseError> {
        let lp = self.bump();
        if self.check(&TokenKind::RPar) {
            // Empty tuple — spans both parens.
            let rp = self.bump();
            return Ok(Expr {
                kind: ExprKind::Tuple(Vec::new()),
                span: lp.span.merge(rp.span),
            });
        }
        // pegen `group`: `(yield ...)` admits a yield expression as the
        // *sole* parenthesized content (`(yield, 1)` stays invalid — the
        // `expect` below reports the comma).
        if self.at_keyword(Keyword::Yield) {
            let inner = self.parse_yield()?;
            self.expect(&TokenKind::RPar, "`)`")?;
            return Ok(inner);
        }
        // pegen `group` / `tuple` / `genexp`: parenthesized contents
        // (including each tuple element and a genexp's element) are
        // `named_expression` / `star_named_expression` productions.
        self.walrus_ok = true;
        let first = self.parse_ternary_or_starred()?;
        let first_starred = matches!(first.kind, ExprKind::Starred(_));
        // Generator expression?
        if !first_starred && (self.at_keyword(Keyword::For) || self.at_keyword(Keyword::Async)) {
            let generators = self.parse_comp_for()?;
            let rp = self.expect(&TokenKind::RPar, "`)`")?;
            let span = lp.span.merge(rp.span);
            return Ok(Expr {
                kind: ExprKind::GeneratorExp {
                    elt: Box::new(first),
                    generators,
                },
                span,
            });
        }
        if self.check(&TokenKind::Comma) {
            let mut items = vec![first];
            while self.eat(&TokenKind::Comma) {
                if self.check(&TokenKind::RPar) {
                    break;
                }
                self.walrus_ok = true;
                items.push(self.parse_ternary_or_starred()?);
                // `(x, y, z=3)` — pegen `invalid_named_expression`.
                if self.check(&TokenKind::Equal) {
                    return Err(Self::display_equal_error(
                        items.last().expect("just pushed"),
                    ));
                }
            }
            let rp = self.expect_or_forgot_comma(&TokenKind::RPar, "`)`", &items)?;
            return Ok(Expr {
                kind: ExprKind::Tuple(items),
                span: lp.span.merge(rp.span),
            });
        }
        // A bare `(*a)` with no trailing comma is a syntax error in
        // CPython — starred expressions are only legal inside a tuple/
        // call/assignment context, never as a lone parenthesized value.
        // Only the well-formed `(*a)` gets the dedicated message;
        // `(*a:...)` falls through to the generic failure at the `:`.
        if first_starred && self.check(&TokenKind::RPar) {
            return Err(ParseError::Unexpected {
                span: first.span,
                message: "cannot use starred expression here".to_owned(),
            });
        }
        // Plain parenthesized expression: no wrapper node, and — exactly
        // like CPython's grammar actions — the node keeps the *inner*
        // span, excluding the parentheses. `traceback`'s caret-anchor
        // probe (`ast.parse(f"(\n{segment}\n)")`) depends on this:
        // positions must point into `segment`, not at the added parens.
        self.expect_or_forgot_comma(&TokenKind::RPar, "`)`", std::slice::from_ref(&first))?;
        Ok(first)
    }

    fn parse_list_or_listcomp(&mut self) -> Result<Expr, ParseError> {
        let lb = self.bump();
        if self.eat(&TokenKind::RSqb) {
            return Ok(Expr {
                kind: ExprKind::List(Vec::new()),
                span: lb.span.merge(self.prev_token_span()),
            });
        }
        // List-display elements and a listcomp's element are
        // `star_named_expression` / `named_expression` productions.
        self.walrus_ok = true;
        let first = self.parse_ternary_or_starred()?;
        let first_starred = matches!(first.kind, ExprKind::Starred(_));
        if self.at_keyword(Keyword::For) || self.at_keyword(Keyword::Async) {
            if first_starred {
                return Err(ParseError::Unexpected {
                    span: first.span,
                    message: "iterable unpacking cannot be used in comprehension".to_owned(),
                });
            }
            let generators = self.parse_comp_for()?;
            let rb = self.expect(&TokenKind::RSqb, "`]`")?;
            return Ok(Expr {
                kind: ExprKind::ListComp {
                    elt: Box::new(first),
                    generators,
                },
                span: lb.span.merge(rb.span),
            });
        }
        let mut items = vec![first];
        if self.check(&TokenKind::Equal) {
            return Err(Self::display_equal_error(&items[0]));
        }
        while self.eat(&TokenKind::Comma) {
            if self.check(&TokenKind::RSqb) {
                break;
            }
            self.walrus_ok = true;
            items.push(self.parse_ternary_or_starred()?);
            if self.check(&TokenKind::Equal) {
                return Err(Self::display_equal_error(
                    items.last().expect("just pushed"),
                ));
            }
        }
        // `[x,y for x,y in ...]` — pegen `invalid_comprehension`.
        if self.at_keyword(Keyword::For) {
            let span = items[0].span.merge(items.last().expect("nonempty").span);
            return Err(ParseError::Unexpected {
                span,
                message: "did you forget parentheses around the comprehension target?".to_owned(),
            });
        }
        let rb = self.expect_or_forgot_comma(&TokenKind::RSqb, "`]`", &items)?;
        Ok(Expr {
            kind: ExprKind::List(items),
            span: lb.span.merge(rb.span),
        })
    }

    fn parse_dict_or_set(&mut self) -> Result<Expr, ParseError> {
        let lb = self.bump();
        if self.eat(&TokenKind::RBrace) {
            return Ok(Expr {
                kind: ExprKind::Dict {
                    keys: Vec::new(),
                    values: Vec::new(),
                },
                span: lb.span.merge(self.prev_token_span()),
            });
        }
        // Look ahead to see if it's a dict (key:value) or set (just exprs).
        // Parse first expression; the next token decides.
        if self.eat(&TokenKind::DoubleStar) {
            // {**d, ...} — dict with spread.
            let val = self.parse_ternary()?;
            // `{**{} for a in x}` — pegen's dedicated error
            // (test_unpack_ex doctests).
            if self.at_keyword(Keyword::For) || self.at_keyword(Keyword::Async) {
                return Err(ParseError::Unexpected {
                    span: val.span,
                    message: "dict unpacking cannot be used in dict comprehension".to_owned(),
                });
            }
            let mut keys: Vec<Option<Expr>> = vec![None];
            let mut values = vec![val];
            while self.eat(&TokenKind::Comma) {
                if self.check(&TokenKind::RBrace) {
                    break;
                }
                if self.eat(&TokenKind::DoubleStar) {
                    keys.push(None);
                    values.push(self.parse_ternary()?);
                } else {
                    let k = self.parse_ternary()?;
                    self.expect_dict_colon(&k)?;
                    let v = self.parse_dict_value()?;
                    keys.push(Some(k));
                    values.push(v);
                }
            }
            let rb = self.expect_or_forgot_comma(&TokenKind::RBrace, "`}`", &values)?;
            return Ok(Expr {
                kind: ExprKind::Dict { keys, values },
                span: lb.span.merge(rb.span),
            });
        }
        // A set-display element (or setcomp element) is a
        // `star_named_expression`; a dict *key* is a plain `expression`.
        // Whether `{` opens a dict or a set isn't known until after the
        // first element, so remember whether it began as a bare walrus —
        // `{x := 1, 2}` is a set, but `{x := 1: 2}` is pegen-invalid.
        let first_is_bare_walrus = matches!(self.peek(), TokenKind::Name)
            && matches!(
                self.tokens.get(self.pos + 1).map(|t| &t.kind),
                Some(TokenKind::ColonEqual)
            );
        self.walrus_ok = true;
        let first = self.parse_ternary_or_starred()?;
        let first_starred = matches!(first.kind, ExprKind::Starred(_));
        if first_is_bare_walrus && self.check(&TokenKind::Colon) {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "invalid syntax".to_owned(),
            });
        }
        if !first_starred && self.eat(&TokenKind::Colon) {
            // Dict literal (or dict comprehension).
            let v = self.parse_dict_value()?;
            if self.at_keyword(Keyword::For) || self.at_keyword(Keyword::Async) {
                let generators = self.parse_comp_for()?;
                let rb = self.expect(&TokenKind::RBrace, "`}`")?;
                return Ok(Expr {
                    kind: ExprKind::DictComp {
                        key: Box::new(first),
                        value: Box::new(v),
                        generators,
                    },
                    span: lb.span.merge(rb.span),
                });
            }
            let mut keys: Vec<Option<Expr>> = vec![Some(first)];
            let mut values = vec![v];
            while self.eat(&TokenKind::Comma) {
                if self.check(&TokenKind::RBrace) {
                    break;
                }
                if self.eat(&TokenKind::DoubleStar) {
                    keys.push(None);
                    values.push(self.parse_ternary()?);
                } else {
                    let k = self.parse_ternary()?;
                    self.expect_dict_colon(&k)?;
                    let vv = self.parse_dict_value()?;
                    keys.push(Some(k));
                    values.push(vv);
                }
            }
            let rb = self.expect_or_forgot_comma(&TokenKind::RBrace, "`}`", &values)?;
            return Ok(Expr {
                kind: ExprKind::Dict { keys, values },
                span: lb.span.merge(rb.span),
            });
        }
        // Otherwise: set literal or set comp.
        if self.at_keyword(Keyword::For) || self.at_keyword(Keyword::Async) {
            if first_starred {
                return Err(ParseError::Unexpected {
                    span: first.span,
                    message: "iterable unpacking cannot be used in comprehension".to_owned(),
                });
            }
            let generators = self.parse_comp_for()?;
            let rb = self.expect(&TokenKind::RBrace, "`}`")?;
            return Ok(Expr {
                kind: ExprKind::SetComp {
                    elt: Box::new(first),
                    generators,
                },
                span: lb.span.merge(rb.span),
            });
        }
        // A `=` right after a would-be dict key: `{k=22}`. CPython:
        // "cannot assign to <expr> here. Maybe you meant '==' instead
        // of '='?", anchored at the key.
        if self.check(&TokenKind::Equal) {
            return Err(Self::display_equal_error(&first));
        }
        let mut items = vec![first];
        while self.eat(&TokenKind::Comma) {
            if self.check(&TokenKind::RBrace) {
                break;
            }
            self.walrus_ok = true;
            items.push(self.parse_ternary_or_starred()?);
            if self.check(&TokenKind::Equal) {
                return Err(Self::display_equal_error(
                    items.last().expect("just pushed"),
                ));
            }
        }
        // `{x,y for x,y in ...}` — pegen `invalid_comprehension`.
        if self.at_keyword(Keyword::For) {
            let span = items[0].span.merge(items.last().expect("nonempty").span);
            return Err(ParseError::Unexpected {
                span,
                message: "did you forget parentheses around the comprehension target?".to_owned(),
            });
        }
        let rb = self.expect_or_forgot_comma(&TokenKind::RBrace, "`}`", &items)?;
        Ok(Expr {
            kind: ExprKind::Set(items),
            span: lb.span.merge(rb.span),
        })
    }

    /// pegen `invalid_named_expression`: a stray `=` after an element of
    /// a display/condition where assignment is impossible. Plain names
    /// get the "==' or ':='" hint, anything else the "cannot assign"
    /// wording.
    fn display_equal_error(expr: &Expr) -> ParseError {
        let message = if matches!(expr.kind, ExprKind::Name(_)) {
            "invalid syntax. Maybe you meant '==' or ':=' instead of '='?".to_owned()
        } else {
            format!(
                "cannot assign to {} here. Maybe you meant '==' instead of '='?",
                crate::ast::expr_name(expr)
            )
        };
        ParseError::Unexpected {
            span: expr.span,
            message,
        }
    }

    fn parse_comp_for(&mut self) -> Result<Vec<Comprehension>, ParseError> {
        let mut generators = Vec::new();
        loop {
            // PEP 530: `[x async for x in it]` — an `async` prefix on
            // a comprehension `for` clause marks the generator as
            // async-iterable. The enclosing context must be an
            // `async def`; the compiler enforces that.
            let is_async = if self.at_keyword(Keyword::Async) {
                self.bump();
                if !self.at_keyword(Keyword::For) {
                    return Err(ParseError::Unexpected {
                        span: self.peek_token().span,
                        message: "expected `for` after `async` in comprehension".to_owned(),
                    });
                }
                true
            } else if self.at_keyword(Keyword::For) {
                false
            } else {
                break;
            };
            self.bump();
            let target = self.parse_target_list_no_tuple()?;
            // The missing-`in` diagnostic outranks target validation:
            // `[x for a, b, (c+1) if y]` complains about `in`, not the
            // target (pegen `invalid_comprehension` ordering).
            if !self.at_keyword(Keyword::In) {
                return Err(ParseError::Unexpected {
                    span: self.peek_token().span,
                    message: "'in' expected after for-loop variables".to_owned(),
                });
            }
            // CPython (`invalid_comprehension` / `invalid_for_target`):
            // comprehension targets get the same parse-time validation as
            // statement `for` targets (bare message).
            if let Some((offender, _)) = Self::find_invalid_target(&target, false) {
                return Err(self.assign_target_error(offender, true));
            }
            self.bump();
            let iter = self.parse_or()?;
            let mut ifs = Vec::new();
            while self.at_keyword(Keyword::If) {
                self.bump();
                ifs.push(self.parse_or()?);
            }
            generators.push(Comprehension {
                target,
                iter,
                ifs,
                is_async,
            });
        }
        if generators.is_empty() {
            return Err(ParseError::Unexpected {
                span: self.peek_token().span,
                message: "expected `for` in comprehension".to_owned(),
            });
        }
        Ok(generators)
    }

    fn parse_target_list_no_tuple(&mut self) -> Result<Expr, ParseError> {
        let start_tok_span = self.peek_token().span;
        let first = self.parse_target_or_star()?;
        if !self.check(&TokenKind::Comma) {
            return Ok(first);
        }
        let mut items = vec![first];
        while self.eat(&TokenKind::Comma) {
            if self.at_keyword(Keyword::In) {
                break;
            }
            items.push(self.parse_target_or_star()?);
        }
        let span = start_tok_span.merge(self.prev_token_span());
        Ok(Expr {
            kind: ExprKind::Tuple(items),
            span,
        })
    }

    /// One element of an assignment target list. Accepts both plain
    /// targets (`name`, `name.attr`, `name[i]`) and PEP 3132 starred
    /// targets (`*name`). The compiler enforces "at most one star
    /// per list" later.
    fn parse_target_or_star(&mut self) -> Result<Expr, ParseError> {
        if let TokenKind::Star = self.peek() {
            let star_tok = self.peek_token().clone();
            self.bump();
            let inner = self.parse_bit_or()?;
            let span = star_tok.span.merge(inner.span);
            return Ok(Expr {
                kind: ExprKind::Starred(Box::new(inner)),
                span,
            });
        }
        // Parse at the `bitwise_or` level, exactly like pegen's
        // `invalid_for_target` recovery: `for x+1 in y` must consume the
        // whole `x+1` so the "cannot assign to expression" diagnostic
        // fires instead of a bogus missing-`in` complaint. (Comparisons
        // stay excluded so `for i in xs` isn't mis-read as `i in xs`.)
        self.parse_bit_or()
    }

    /// Handle adjacent-string concatenation, mixing plain strings,
    /// byte strings, and f-strings. The CPython AST flattens these:
    /// `"a" "b"` → `Constant("ab")`, `f"a" "b"` → `JoinedStr(["ab"])`,
    /// `f"a{x}" "b"` → `JoinedStr(["a", FormattedValue(x), "b"])`.
    /// pegen `invalid_expression` (3.14), first alternative:
    /// `STRING (!STRING expression_without_invalid)+ STRING` — a lone
    /// (non f/t) string token, one or more expressions, then another
    /// plain string token is "invalid syntax. Is this intended to be
    /// part of the string?" spanning the expressions (`"a "b" c"`).
    /// Called with the position just past the leading string; leaves it
    /// untouched when the shape doesn't match.
    ///
    /// The rule only applies where pegen invokes `expression` (the
    /// caller checks [`Parser::expr_entry`]). Its `expression_without_invalid`
    /// probe has a side effect worth mirroring: it runs the ordinary
    /// grammar over the expressions after the string with the
    /// `invalid_*` rules switched off, and every memoized rule that
    /// fails there stays failed for the rest of the error pass. So when
    /// one of those expressions is malformed, CPython reports a plain
    /// "invalid syntax" at the token the first pass stopped on instead
    /// of the specific diagnostic (`"a" + f(4, x for x in y)` points at
    /// `for`; test_exceptions `test_encodings`).
    ///
    /// `target_first`: the string sits where `star_targets` is attempted
    /// and a subscript/call follows, so the target grammar (with the
    /// specific diagnostics on) already ran over those tokens; a failure
    /// there isn't downgraded.
    fn check_string_expr_string(&mut self, target_first: bool) -> Result<(), ParseError> {
        if !self.at_expression_start() {
            return Ok(());
        }
        let save = self.pos;
        let (save_first_fail, save_peeked) = (self.first_fail, self.peeked);
        let mut range: Option<Span> = None;
        let result = loop {
            match self.parse_expression(false) {
                Ok(e) => range = Some(range.map_or(e.span, |r| r.merge(e.span))),
                Err(_) if target_first => break None,
                // Errors raised from actions (string decoding) abort
                // the parse outright in pegen too.
                Err(e) if e.syntax_message().starts_with('(') => return Err(e),
                Err(ParseError::Unexpected { .. }) => {
                    let fail = self.first_fail.unwrap_or(self.pos);
                    if self.poison.is_none() {
                        self.poison = Some(fail);
                    }
                    // The probe's own lookahead bookkeeping doesn't
                    // outlive it.
                    self.first_fail = save_first_fail;
                    self.peeked = save_peeked;
                    break None;
                }
                Err(e) => return Err(e),
            }
            if matches!(self.peek(), TokenKind::String) {
                let tok = self.peek_token().clone();
                let plain = self
                    .string_prefix(&tok)
                    .map(|p| !p.interpolated())
                    .unwrap_or(false);
                break if plain { range } else { None };
            }
            if !self.at_expression_start() {
                break None;
            }
        };
        self.pos = save;
        match result {
            Some(span) => Err(ParseError::Unexpected {
                span,
                message: "invalid syntax. Is this intended to be part of the string?".to_owned(),
            }),
            None => Ok(()),
        }
    }

    fn parse_string_concat(&mut self, first: Token) -> Result<Expr, ParseError> {
        let mut span = first.span;
        let first_prefix = self.string_prefix(&first)?;
        let mut accum: AccumString = if first_prefix.template {
            AccumString::Template(self.fstring_parts_for(&first)?)
        } else if first_prefix.fstring {
            AccumString::Joined(self.fstring_parts_for(&first)?)
        } else if first_prefix.bytes {
            match self.decode_string(&first)? {
                Constant::Bytes(b) => AccumString::Bytes(b),
                _ => unreachable!(),
            }
        } else {
            AccumString::Plain(constant_str_cps(self.decode_string(&first)?))
        };
        let at_expr_entry = self.pos == self.expr_entry;
        let at_target_entry = self.pos == self.target_entry;
        self.bump();
        if at_expr_entry
            && !first_prefix.interpolated()
            && !matches!(self.peek(), TokenKind::String)
        {
            let target_first =
                at_target_entry && matches!(self.peek(), TokenKind::LPar | TokenKind::LSqb);
            self.check_string_expr_string(target_first)?;
        }
        while matches!(self.peek(), TokenKind::String) {
            let next_tok = self.peek_token().clone();
            let next_prefix = self.string_prefix(&next_tok)?;
            let prev_span = span;
            span = span.merge(next_tok.span);
            self.bump();
            // PEP 750: t-strings only concatenate with other t-strings.
            let accum_is_template = matches!(accum, AccumString::Template(_));
            if next_prefix.template != accum_is_template {
                return Err(ParseError::Unexpected {
                    span: next_tok.span,
                    message: "cannot mix t-string literals with string or bytes literals"
                        .to_owned(),
                });
            }
            if let AccumString::Template(mut parts) = accum {
                let new_parts = self.fstring_parts_for(&next_tok)?;
                for p in new_parts {
                    if let ExprKind::Constant(c @ (Constant::Str(_) | Constant::WStr(_))) = p.kind {
                        join_str_into_parts(&mut parts, c, p.span);
                    } else {
                        parts.push(p);
                    }
                }
                accum = AccumString::Template(parts);
                continue;
            }
            accum = match (accum, next_prefix.fstring, next_prefix.bytes) {
                // Handled above (both sides template, or mix error).
                (AccumString::Template(_), _, _) => unreachable!(),
                (AccumString::Bytes(mut a), false, true) => match self.decode_string(&next_tok)? {
                    Constant::Bytes(b) => {
                        a.extend_from_slice(&b);
                        AccumString::Bytes(a)
                    }
                    _ => unreachable!(),
                },
                (AccumString::Bytes(_), _, _) => {
                    return Err(ParseError::Unexpected {
                        span: next_tok.span,
                        message: "cannot mix bytes and nonbytes literals".to_owned(),
                    });
                }
                (_, _, true) => {
                    return Err(ParseError::Unexpected {
                        span: next_tok.span,
                        message: "cannot mix bytes and nonbytes literals".to_owned(),
                    });
                }
                (AccumString::Plain(mut a), false, false) => {
                    a.extend(constant_str_cps(self.decode_string(&next_tok)?));
                    AccumString::Plain(a)
                }
                (AccumString::Plain(a), true, false) => {
                    let mut parts: Vec<Expr> = Vec::new();
                    if !a.is_empty() {
                        parts.push(Expr {
                            kind: ExprKind::Constant(cps_to_constant(a)),
                            // All plain fragments accumulated so far.
                            span: prev_span,
                        });
                    }
                    // The f-string's leading literal fuses with the plain
                    // prefix (`"a, " f"not {x}"` is one Constant part).
                    for p in self.fstring_parts_for(&next_tok)? {
                        if let ExprKind::Constant(c @ (Constant::Str(_) | Constant::WStr(_))) =
                            p.kind
                        {
                            join_str_into_parts(&mut parts, c, p.span);
                        } else {
                            parts.push(p);
                        }
                    }
                    AccumString::Joined(parts)
                }
                (AccumString::Joined(mut parts), false, false) => {
                    join_str_into_parts(&mut parts, self.decode_string(&next_tok)?, next_tok.span);
                    AccumString::Joined(parts)
                }
                (AccumString::Joined(mut parts), true, false) => {
                    let new_parts = self.fstring_parts_for(&next_tok)?;
                    for p in new_parts {
                        if let ExprKind::Constant(c @ (Constant::Str(_) | Constant::WStr(_))) =
                            p.kind
                        {
                            join_str_into_parts(&mut parts, c, p.span);
                        } else {
                            parts.push(p);
                        }
                    }
                    AccumString::Joined(parts)
                }
            };
        }
        match accum {
            AccumString::Plain(cps) => Ok(Expr {
                kind: ExprKind::Constant(cps_to_constant(cps)),
                span,
            }),
            AccumString::Bytes(b) => Ok(Expr {
                kind: ExprKind::Constant(Constant::Bytes(b)),
                span,
            }),
            // Any f-string in the concatenation keeps the result a
            // `JoinedStr`, even when it folds to a single literal part
            // (CPython AST shape; not a docstring candidate).
            AccumString::Joined(parts) => Ok(Expr {
                kind: ExprKind::JoinedStr(parts),
                span,
            }),
            AccumString::Template(parts) => Ok(Expr {
                kind: ExprKind::TemplateStr(parts),
                span,
            }),
        }
    }

    /// Decode one f-string token, flattening any nested `JoinedStr`
    /// produced by the debug `{x = }` shortcut into the outer parts list.
    fn fstring_parts_for(&self, tok: &Token) -> Result<Vec<Expr>, ParseError> {
        let parsed = self.parse_fstring_token(tok)?;
        let mut parts = Vec::new();
        match parsed.kind {
            ExprKind::JoinedStr(inner) => {
                for p in inner {
                    if let ExprKind::JoinedStr(more) = p.kind {
                        parts.extend(more);
                    } else {
                        parts.push(p);
                    }
                }
            }
            other => parts.push(Expr {
                kind: other,
                span: parsed.span,
            }),
        }
        Ok(parts)
    }

    // ---------- string / number decoding ----------

    /// Decode a single (non-f) string token into a [`Constant`].
    fn decode_string(&self, tok: &Token) -> Result<Constant, ParseError> {
        let lex = self.lexeme(tok.span);
        let (prefix_str, rest) = split_string_prefix(lex);
        let prefix = weavepy_lexer::StringPrefix::parse(prefix_str).ok_or_else(|| {
            ParseError::Unexpected {
                span: tok.span,
                message: format!("invalid string prefix {prefix_str:?}"),
            }
        })?;
        debug_assert!(
            !prefix.fstring,
            "f-strings should route through decode_string_or_fstring"
        );
        let body = strip_quotes(rest);
        let raw = prefix.raw;
        if prefix.bytes {
            let bytes = decode_bytes_body(body, raw).map_err(|m| ParseError::Unexpected {
                span: tok.span,
                message: m,
            })?;
            return Ok(Constant::Bytes(bytes));
        }
        let c = decode_str_body(body, raw).map_err(|m| ParseError::Unexpected {
            span: tok.span,
            message: m,
        })?;
        Ok(c)
    }

    /// Returns the prefix info for a string token without decoding the body.
    fn string_prefix(&self, tok: &Token) -> Result<weavepy_lexer::StringPrefix, ParseError> {
        let lex = self.lexeme(tok.span);
        let (prefix_str, _) = split_string_prefix(lex);
        weavepy_lexer::StringPrefix::parse(prefix_str).ok_or_else(|| ParseError::Unexpected {
            span: tok.span,
            message: format!("invalid string prefix {prefix_str:?}"),
        })
    }

    /// Parse the interior of an f-string token into an `ExprKind`.
    ///
    /// Walks the body character-by-character. Literal runs become
    /// `Constant::Str` parts; `{...}` runs are re-lexed and re-parsed
    /// to produce `FormattedValue` parts. The result is a `JoinedStr`
    /// (or a single `Constant` when no interpolation appears).
    fn parse_fstring_token(&self, tok: &Token) -> Result<Expr, ParseError> {
        let lex = self.lexeme(tok.span);
        let (_, rest) = split_string_prefix(lex);
        let prefix = self.string_prefix(tok)?;
        let raw = prefix.raw;
        let body = strip_quotes(rest);
        // Absolute byte offset of `body` in the source — `body` is a
        // subslice of the token's lexeme, so pointer arithmetic gives
        // the prefix+quote length. Interior parse errors are reported
        // at their real source location (PEP 701), not the f-string's.
        let body_abs = tok.span.start.0 + (body.as_ptr() as usize - lex.as_ptr() as usize) as u32;
        let parts = self.parse_fstring_body(body, raw, tok.span, body_abs, prefix.template)?;
        // CPython keeps even a pure-literal f-string as a `JoinedStr`
        // (`ast.parse("f'x'")` is JoinedStr([Constant])): it is *not* a
        // docstring candidate and `ast.literal_eval` rejects it. Constant
        // folding happens in the compiler, not here.
        //
        // t-string tokens are wrapped in `JoinedStr` here too; the caller
        // (`parse_string_concat`) re-wraps the flattened parts in
        // `TemplateStr` — only the parts differ (`Interpolation` instead
        // of `FormattedValue`).
        Ok(Expr {
            kind: ExprKind::JoinedStr(parts),
            span: tok.span,
        })
    }

    fn parse_fstring_body(
        &self,
        body: &str,
        raw: bool,
        anchor: Span,
        body_abs: u32,
        template: bool,
    ) -> Result<Vec<Expr>, ParseError> {
        let kind = if template { 't' } else { 'f' };
        self.parse_fstring_body_inner(body, raw, anchor, body_abs, false, template, kind)
    }

    /// `spec_mode` parses a format spec, where `{{`/`}}` are *not*
    /// doubled-brace escapes: in a spec every `{` opens a nested
    /// replacement field (CPython rejects `f'{3:{{>10}'` with "expecting
    /// a valid expression after '{'").
    #[allow(clippy::too_many_arguments)]
    fn parse_fstring_body_inner(
        &self,
        body: &str,
        raw: bool,
        anchor: Span,
        body_abs: u32,
        spec_mode: bool,
        template: bool,
        // CPython's `TOK_GET_STRING_PREFIX`: diagnostics name the kind
        // of the innermost enclosing *literal* ("t-string: expecting
        // '}'") — which a t-string's format spec shares even though its
        // own nested fields build `FormattedValue`s (`template` false).
        kind: char,
    ) -> Result<Vec<Expr>, ParseError> {
        let mut parts = Vec::new();
        let mut literal = String::new();
        // Byte index in `body` where the current literal run began, for
        // the Constant part's source span (CPython anchors each literal
        // part at its own text, not at the whole string token).
        let mut lit_start = 0usize;
        let bytes = body.as_bytes();
        let mut i = 0usize;
        while i < bytes.len() {
            let b = bytes[i];
            if literal.is_empty() {
                lit_start = i;
            }
            // Non-raw backslash escapes are copied into the literal as a
            // unit so the decoder interprets them — and, crucially, so an
            // escaped backslash (`\\`) can't have its second byte misread
            // as the start of a new escape (e.g. `f'\\N{AMPERSAND}'` is a
            // literal `\` then the field `{AMPERSAND}`, not `\N{...}`).
            if b == b'\\' && !raw {
                // `\N{NAME}` named-character escape: the brace group is
                // the Unicode character name, not a replacement field.
                if bytes.get(i + 1) == Some(&b'N') && bytes.get(i + 2) == Some(&b'{') {
                    let mut j = i + 3;
                    while j < bytes.len() && bytes[j] != b'}' {
                        j += 1;
                    }
                    if j < bytes.len() {
                        j += 1; // include the closing `}`
                    }
                    literal.push_str(&body[i..j]);
                    i = j;
                    continue;
                }
                // Any other escape: copy the backslash, then its escaped
                // character — except `{`/`}`, which stay structural (a
                // lone `\` before a brace is a literal backslash followed
                // by a replacement field / brace escape, e.g. `\{6*7}`).
                literal.push('\\');
                i += 1;
                if let Some(&n) = bytes.get(i) {
                    if n != b'{' && n != b'}' {
                        let ch_len = utf8_char_len(n);
                        let end = (i + ch_len).min(bytes.len());
                        literal.push_str(&body[i..end]);
                        i = end;
                    }
                }
                continue;
            }
            if b == b'{' {
                if !spec_mode && i + 1 < bytes.len() && bytes[i + 1] == b'{' {
                    literal.push('{');
                    i += 2;
                    continue;
                }
                if !literal.is_empty() {
                    let decoded =
                        decode_str_body(&literal, raw).map_err(|m| ParseError::Unexpected {
                            span: anchor,
                            message: m,
                        })?;
                    // `_PyPegen_joined_str` drops literal parts that
                    // decode to `''` (a lone `\<newline>` continuation).
                    if !is_empty_str_constant(&decoded) {
                        parts.push(Expr {
                            kind: ExprKind::Constant(decoded),
                            span: Span::new(body_abs + lit_start as u32, body_abs + i as u32),
                        });
                    }
                    literal.clear();
                }
                let (field, end) = match self.scan_fstring_field(body, i + 1, anchor, kind) {
                    Ok(ok) => ok,
                    // Unterminated field ("f-string: expecting '}'"):
                    // CPython's pegen parses the partial expression
                    // first, so an *inner* error (e.g. "Perhaps you
                    // forgot a comma?") wins over the missing brace.
                    Err(scan_err) => {
                        if matches!(&scan_err, ParseError::Unexpected { message, .. }
                            if message.ends_with("-string: expecting '}'"))
                        {
                            let partial = &body[i + 1..];
                            self.parse_fstring_field(
                                partial,
                                anchor,
                                body_abs + (i as u32) + 1,
                                raw,
                                true,
                                template,
                                kind,
                            )?;
                        }
                        return Err(scan_err);
                    }
                };
                let parsed = self.parse_fstring_field(
                    &field,
                    anchor,
                    body_abs + (i as u32) + 1,
                    raw,
                    false,
                    template,
                    kind,
                )?;
                // The debug form `{x=}` comes back as a synthetic
                // JoinedStr([Constant("x="), FormattedValue]); CPython
                // splices those parts directly into the surrounding
                // values list (crucially also *inside a format spec* —
                // `f"{2:{y=}}"` has Constant/FormattedValue as siblings,
                // never a nested JoinedStr).
                // The debug text fuses with a preceding literal run
                // (`_PyPegen_concatenate_strings` merges every run of
                // adjacent Constant parts: `f"abc {m=}"` is
                // `[Constant("abc m="), FormattedValue]`).
                match parsed.kind {
                    ExprKind::JoinedStr(debug_parts) => {
                        for p in debug_parts {
                            if let ExprKind::Constant(c @ (Constant::Str(_) | Constant::WStr(_))) =
                                p.kind
                            {
                                join_str_into_parts(&mut parts, c, p.span);
                            } else {
                                parts.push(p);
                            }
                        }
                    }
                    _ => parts.push(parsed),
                }
                i = end + 1; // skip past the closing `}`
                continue;
            }
            if b == b'}' {
                if !spec_mode && i + 1 < bytes.len() && bytes[i + 1] == b'}' {
                    literal.push('}');
                    i += 2;
                    continue;
                }
                return Err(ParseError::Unexpected {
                    span: anchor,
                    message: format!("{kind}-string: single '}}' is not allowed"),
                });
            }
            // Append the next UTF-8 character (one or more bytes).
            let ch_len = utf8_char_len(b);
            let end = (i + ch_len).min(bytes.len());
            literal.push_str(&body[i..end]);
            i = end;
        }
        // A trailing literal run becomes a final part; an empty body
        // yields an empty `JoinedStr` (CPython: `f''` and the empty
        // format spec `f'{x:}'` both have `values=[]`).
        if !literal.is_empty() {
            let decoded = decode_str_body(&literal, raw).map_err(|m| ParseError::Unexpected {
                span: anchor,
                message: m,
            })?;
            if !is_empty_str_constant(&decoded) {
                parts.push(Expr {
                    kind: ExprKind::Constant(decoded),
                    span: Span::new(body_abs + lit_start as u32, body_abs + i as u32),
                });
            }
        }
        Ok(parts)
    }

    /// Scan from just past the opening `{` to the matching `}` at the
    /// field's top level. Returns the field text and the index of that
    /// closing `}`.
    ///
    /// Bracket nesting is tracked with an explicit stack so we can report
    /// CPython's PEP 701 diagnostics: a `)`/`]`/`}` that doesn't match the
    /// innermost opener yields "closing parenthesis 'X' does not match
    /// opening parenthesis 'Y'", a `)`/`]` with nothing open yields
    /// "f-string: unmatched ')'", and running off the end yields
    /// "f-string: expecting '}'".
    fn scan_fstring_field(
        &self,
        body: &str,
        start: usize,
        anchor: Span,
        kind: char,
    ) -> Result<(String, usize), ParseError> {
        let bytes = body.as_bytes();
        // Openers seen *inside* the field (the field's own `{` is implicit
        // and not pushed); a top-level `}` closes the field.
        let mut stack: Vec<u8> = Vec::new();
        let mut i = start;
        // Once the top-level `:` is seen we're in the format spec, where
        // `#` is literal (e.g. `{x:#06x}`); before it, in the expression
        // part, `#` starts a comment to end of line (legal in multi-line
        // f-strings, PEP 701).
        let mut in_spec = false;
        while i < bytes.len() {
            let b = bytes[i];
            match b {
                // In the format spec's own literal text (top level, past
                // the `:`) a quote is just spec text (`f"{x:'}"`, PEP 701);
                // inside a nested `{...}` field of the spec, expression
                // string tracking applies again.
                b'"' | b'\'' if !(in_spec && stack.is_empty()) => {
                    match skip_field_string(bytes, i) {
                        Some(next) => i = next,
                        // The string never closes inside the field; fall
                        // through to "expecting '}'" — the partial-field
                        // re-parse surfaces the precise inner diagnostic.
                        None => break,
                    }
                }
                b'(' | b'[' | b'{' => {
                    stack.push(b);
                    i += 1;
                }
                b')' => match stack.last() {
                    Some(b'(') => {
                        stack.pop();
                        i += 1;
                    }
                    Some(&open) => return Err(fstring_paren_mismatch(')', open, anchor)),
                    None => {
                        return Err(ParseError::Unexpected {
                            span: anchor,
                            message: format!("{kind}-string: unmatched ')'"),
                        })
                    }
                },
                b']' => match stack.last() {
                    Some(b'[') => {
                        stack.pop();
                        i += 1;
                    }
                    Some(&open) => return Err(fstring_paren_mismatch(']', open, anchor)),
                    None => {
                        return Err(ParseError::Unexpected {
                            span: anchor,
                            message: format!("{kind}-string: unmatched ']'"),
                        })
                    }
                },
                b'}' => match stack.last() {
                    None => return Ok((body[start..i].to_owned(), i)),
                    Some(b'{') => {
                        stack.pop();
                        i += 1;
                    }
                    Some(&open) => return Err(fstring_paren_mismatch('}', open, anchor)),
                },
                b':' if stack.is_empty() && !in_spec => {
                    in_spec = true;
                    i += 1;
                }
                b'#' if !in_spec => {
                    // Comment to end of line; the brackets/quotes it may
                    // contain must not perturb depth or string tracking.
                    while i < bytes.len() && bytes[i] != b'\n' {
                        i += 1;
                    }
                }
                _ => i += 1,
            }
        }
        Err(ParseError::Unexpected {
            span: anchor,
            message: format!("{kind}-string: expecting '}}'"),
        })
    }

    /// Parse one `expr[!conv][:spec]` field and return a
    /// `FormattedValue` (possibly preceded by a synthetic literal
    /// for `{x = }` debug form).
    #[allow(clippy::too_many_arguments)]
    fn parse_fstring_field(
        &self,
        field: &str,
        anchor: Span,
        field_abs: u32,
        raw: bool,
        partial: bool,
        template: bool,
        kind: char,
    ) -> Result<Expr, ParseError> {
        // PEP 701 (3.12+): backslashes *are* allowed inside replacement
        // fields (e.g. `f"{d["a\tb"]}"`). The expression is re-tokenized
        // below, so escapes inside nested string literals are handled by
        // the sub-lexer; a stray backslash in the expression itself just
        // surfaces as a normal sub-parse error.
        let bytes = field.as_bytes();
        // Find the `!conv` and `:spec` boundaries at top level (not
        // inside nested parens/brackets/braces or string literals).
        let mut expr_end = bytes.len();
        let mut conv_start: Option<usize> = None;
        let mut spec_start: Option<usize> = None;
        let mut depth = 0i32;
        let mut i = 0;
        while i < bytes.len() {
            let b = bytes[i];
            // A `#` in the expression part (before any `!conv`/`:spec`,
            // and not inside a string) is a comment to end of line. Skip
            // it so quotes/`!`/`:` it contains can't be mistaken for
            // string delimiters or conv/spec boundaries.
            if b == b'#' && conv_start.is_none() && spec_start.is_none() {
                while i < bytes.len() && bytes[i] != b'\n' {
                    i += 1;
                }
                continue;
            }
            match b {
                b'"' | b'\'' => {
                    match skip_field_string(bytes, i) {
                        Some(next) => i = next,
                        // Unterminated: everything after is string content,
                        // so no further boundaries can appear.
                        None => break,
                    }
                    continue;
                }
                b'(' | b'[' | b'{' => depth += 1,
                b')' | b']' | b'}' => depth -= 1,
                _ => {}
            }
            if depth == 0 {
                if b == b'!' && conv_start.is_none() && spec_start.is_none() {
                    // `!=` is the only `!` that stays part of the
                    // expression (comparison); any other `!` ends the
                    // expression and opens the conversion clause. Catching
                    // it here (rather than only before `s`/`r`/`a`) lets an
                    // empty expression before `!` surface CPython's
                    // "valid expression required before '!'".
                    if bytes.get(i + 1) != Some(&b'=') {
                        expr_end = i;
                        conv_start = Some(i + 1);
                        i += 1;
                        continue;
                    }
                } else if b == b':' && spec_start.is_none() {
                    expr_end = expr_end.min(i);
                    spec_start = Some(i + 1);
                    i += 1;
                    continue;
                }
            }
            i += 1;
        }
        let expr_slice = &field[..expr_end];
        // Debug form `{expr=}`: CPython echoes the *verbatim* source of
        // the expression part (preserving the author's whitespace, e.g.
        // `{val = }` -> "val = 7") and then formats the value. A trailing
        // single `=` triggers it, but `==`/`!=`/`<=`/`>=` must not.
        //
        // PEP 701 allows `#` comments inside (multi-line) replacement
        // fields, e.g.
        //   f"{1+2 = # my comment
        //     }"   ==  '1+2 = \n  3'
        // The comment is removed but the surrounding whitespace stays, and
        // it must not hide the debug `=`. Strip comments first, then both
        // the detection and the echoed literal work on the cleaned text.
        let clean = strip_fstring_field_comments(expr_slice);
        // The parse itself runs on a copy where comments are blanked
        // rather than removed, so every byte offset maps straight back
        // onto `field` (and so onto real source positions).
        let blanked = blank_fstring_field_comments(expr_slice);
        debug_assert_eq!(blanked.len(), expr_slice.len());
        // Only ASCII whitespace is insignificant around the expression
        // (space, tab, formfeed, CR/LF, VT). Notably *not* U+00A0 etc. —
        // CPython rejects those as "invalid non-printable character".
        let ws = |c: char| matches!(c, ' ' | '\t' | '\n' | '\r' | '\x0b' | '\x0c');
        let trimmed_end = blanked.trim_end_matches(ws);
        let is_debug = trimmed_end.ends_with('=')
            && !trimmed_end.ends_with("==")
            && !trimmed_end.ends_with("!=")
            && !trimmed_end.ends_with("<=")
            && !trimmed_end.ends_with(">=");
        let (expr_text, debug_lit) = if is_debug {
            let value_src = trimmed_end[..trimmed_end.len() - 1].trim_matches(ws);
            // Verbatim expression-part slice (through the `=`, including
            // any surrounding spaces, comments removed) is echoed.
            (value_src, Some(clean.clone()))
        } else {
            (blanked.trim_matches(ws), None)
        };
        // A field that *opens* with a lone `=` (`f'{=x}'`): pegen's first
        // token after `{` is `=`, so it reports the missing expression
        // before it rather than the trailing junk.
        let lead = blanked.trim_start_matches(ws);
        if lead.starts_with('=') && !lead.starts_with("==") && !expr_text.is_empty() {
            let at = field_abs + (blanked.len() - lead.len()) as u32;
            return Err(ParseError::Unexpected {
                span: Span::new(at, at + 1),
                message: format!("{kind}-string: valid expression required before '='"),
            });
        }
        if expr_text.is_empty() {
            // Name the terminator that followed the (empty) expression,
            // mirroring CPython: "f-string: valid expression required
            // before '}'/'!'/':'/'='".
            let before = if is_debug {
                '='
            } else if conv_start.is_some() {
                '!'
            } else if spec_start.is_some() {
                ':'
            } else {
                '}'
            };
            // In a *partial* (unterminated) field there is no real `}`;
            // an all-whitespace field defers to the lexer's own
            // diagnostic ("expecting '}'" / "'{' was never closed").
            if partial && before == '}' {
                return Err(ParseError::Unexpected {
                    span: anchor,
                    message: format!("{kind}-string: expecting '}}'"),
                });
            }
            // CPython's caret sits on the *terminator character itself*
            // (`test_cmd_line_script.test_syntaxerror_multi_line_fstring`
            // expects a single `^` under the `}`), not the whole token.
            let term_pos = field_abs
                + match before {
                    '!' => conv_start.map_or(field.len(), |c| c - 1),
                    ':' => spec_start.map_or(field.len(), |s| s - 1),
                    '=' => trimmed_end.len().saturating_sub(1),
                    _ => field.len(),
                } as u32;
            return Err(ParseError::Unexpected {
                span: Span::new(term_pos, term_pos + 1),
                message: format!("{kind}-string: valid expression required before '{before}'"),
            });
        }
        // Recursively tokenize+parse the expression. Inside an f-string
        // replacement field, newlines, comments and indentation are
        // insignificant (PEP 701: the field is parsed in the same
        // implicit line-continuation context as the surrounding `{...}`),
        // so a multi-line field like
        //   f'''{
        //   40  # forty
        //   + 2 # two
        //   }'''
        // must read as `40 + 2`. Wrapping the expression in parentheses
        // reproduces that joining exactly; the parens are transparent for
        // a plain expression (and for a top-level comma the result is the
        // same tuple `parse_expression_list` would have built). The
        // closing paren goes on its own line so a trailing `# comment` in
        // the field can't swallow it.
        // A failure parsing the embedded expression keeps its own
        // message and is re-anchored at the expression's *real* source
        // location (CPython's pegen reports interior errors verbatim —
        // e.g. "invalid decimal literal" inside `f'{(123_a)}'` points
        // at line 3 of a multi-line f-string, not at the `f`).
        // `expr_text` borrows `blanked`, whose offsets equal offsets in
        // `field`.
        let expr_off_in_field = expr_text.as_ptr() as usize - blanked.as_ptr() as usize;
        let expr_abs = field_abs + expr_off_in_field as u32;
        // Map a byte offset in `wrapped` (below) back to the source:
        // subtract the synthetic `(`, clamp to the expression's extent.
        let map_back = |byte: u32| -> u32 {
            let rel = (byte.saturating_sub(1)).min(expr_text.len() as u32);
            expr_abs + rel
        };
        // CPython's expression-start span: the first character of the
        // expression text.
        let expr_start_span = {
            let first_len = expr_text.chars().next().map_or(1, |c| c.len_utf8()) as u32;
            Span::new(expr_abs, expr_abs + first_len)
        };
        // CPython's invalid_replacement_field family of diagnostics:
        // a field whose expression can't be parsed *at all* is
        // "expecting a valid expression after '{'"; junk after a parsed
        // expression is "expecting '=', or '!', or ':', or '}'" — unless
        // the junk itself starts an expression, which pegen's
        // invalid_expression rule turns into the comma hint.
        let value = (|| -> Result<Expr, ParseError> {
            let wrapped = format!("({expr_text}\n)");
            let tokens = weavepy_lexer::tokenize(&wrapped)?;
            let mut sub = Parser::new(&wrapped, tokens);
            sub.skip_trivia_and_newlines();
            let value = sub.parse_expression_list(false)?;
            sub.skip_trivia_and_newlines();
            if !matches!(sub.peek(), TokenKind::Endmarker) {
                let sp = sub.peek_token().span;
                // Junk after a parsed expression: junk that itself begins
                // an expression gets pegen's comma hint (`f'{1 1}'`);
                // other junk names the expected delimiters.
                let junk_is_expr = sub.parse_expression_list(false).is_ok();
                return Err(ParseError::Unexpected {
                    span: sp,
                    message: if junk_is_expr {
                        "invalid syntax. Perhaps you forgot a comma?".to_owned()
                    } else {
                        format!("{kind}-string: expecting '=', or '!', or ':', or '}}'")
                    },
                });
            }
            Ok(value)
        })()
        .map_err(|e| {
            map_fstring_subparse_error(
                e,
                expr_text,
                spec_start,
                field_abs,
                expr_abs,
                expr_start_span,
                &map_back,
                kind,
            )
        })?;
        // Re-anchor the sub-parsed tree from `wrapped` coordinates onto
        // the real source so `ast` positions (lineno/col_offset) and
        // runtime tracebacks point into the actual f-string text.
        let mut value = value;
        remap_expr_spans(&mut value, &map_back);
        // A bare starred expression can't be formatted (`f'{*a}'`); the
        // tuple form `f'{*a,}'` is fine and parses as a tuple instead.
        if !partial {
            if let ExprKind::Starred(_) = value.kind {
                // pegen's *unparenthesized* wording ("can't", not
                // "cannot") — the same message a bare `x = *a` gets.
                return Err(ParseError::Unexpected {
                    span: Span::new(expr_abs, expr_abs + expr_text.len() as u32),
                    message: "can't use starred expression here".to_owned(),
                });
            }
        }

        let conversion = match conv_start {
            Some(idx) if !partial => {
                let conv_end = spec_start.map(|s| s - 1).unwrap_or(field.len());
                let text = &field[idx..conv_end];
                validate_fstring_conversion(text, idx, field, field_abs, kind)?
            }
            // Partial (unterminated) field whose conversion clause *was*
            // terminated by a `:` — the clause is complete enough to
            // validate (`f'{3!:'` is "missing conversion character", not
            // an unterminated-literal error).
            Some(idx) if spec_start.is_some() => {
                let conv_end = spec_start.map(|s| s - 1).unwrap_or(field.len());
                let text = &field[idx..conv_end];
                validate_fstring_conversion(text, idx, field, field_abs, kind)?
            }
            // Partial field with the conversion clause itself cut off:
            // defer to the lexer's diagnostics.
            Some(_) => -1,
            // Debug form defaults to `!r`, but only when no explicit
            // conversion *and* no format spec is given (`{x=:.2f}` uses
            // the spec, not repr).
            None if debug_lit.is_some() && spec_start.is_none() => i32::from(b'r'),
            None => -1,
        };
        let format_spec = match spec_start {
            Some(s) if !partial => {
                let spec = &field[s..];
                // A t-string's format spec is eagerly evaluated to a str
                // at template construction time; its own nested fields
                // stay `FormattedValue` (template=false).
                let inner = self.parse_fstring_body_inner(
                    spec,
                    raw,
                    anchor,
                    field_abs + s as u32,
                    true,
                    false,
                    kind,
                )?;
                // CPython spans the format-spec JoinedStr from its `:`
                // through the end of the spec text (before the `}`).
                let spec_span = Span::new(field_abs + s as u32 - 1, field_abs + field.len() as u32);
                Some(Box::new(Expr {
                    kind: ExprKind::JoinedStr(inner),
                    span: spec_span,
                }))
            }
            _ => None,
        };

        // CPython spans the FormattedValue from its `{` through the
        // matching `}` (the field text sits at `field_abs`, just past
        // the opening brace).
        let fv_span = Span::new(
            field_abs.saturating_sub(1),
            field_abs + field.len() as u32 + 1,
        );
        let fv = Expr {
            kind: if template {
                // PEP 750: `Interpolation.expression` is the source text
                // between the `{` and the terminator with only trailing
                // whitespace and `=` removed (`_strip_interpolation_expr`),
                // so `t"{ a }"` reports `' a'` and `t"{a = }"` reports `'a'`.
                ExprKind::Interpolation {
                    value: Box::new(value),
                    text: clean
                        .trim_end_matches(|c: char| ws(c) || c == '=')
                        .to_owned(),
                    conversion,
                    format_spec,
                }
            } else {
                ExprKind::FormattedValue {
                    value: Box::new(value),
                    conversion,
                    format_spec,
                }
            },
            span: fv_span,
        };
        if let Some(lit) = debug_lit {
            // Wrap in a tiny JoinedStr-equivalent: emit a literal
            // followed by the formatted value. The caller of
            // parse_fstring_field appends parts directly, so we
            // package both into a synthetic JoinedStr that will
            // get flattened by the outer JoinedStr later.
            //
            // `_PyPegen_formatted_value` locates the debug text from
            // just after the `{` to just before the terminator: the
            // `!` of a conversion, the `:` of a format spec, or the
            // `}`.
            let debug_end = field_abs
                + match (conv_start, spec_start) {
                    (Some(c), _) => c - 1,
                    (None, Some(s)) => s - 1,
                    (None, None) => field.len(),
                } as u32;
            return Ok(Expr {
                kind: ExprKind::JoinedStr(vec![
                    Expr {
                        kind: ExprKind::Constant(Constant::Str(lit)),
                        span: Span::new(field_abs, debug_end),
                    },
                    fv,
                ]),
                span: anchor,
            });
        }
        Ok(fv)
    }
}

/// Rewrite every span in an expression tree through `map` (a byte-offset
/// translation). Used to re-anchor an f-string replacement field's
/// sub-parsed expression from its synthetic `( … \n)` wrapper onto the
/// real source, so `ast` positions and runtime tracebacks point at the
/// actual f-string text (CPython parses fields in-place and gets this
/// for free).
fn remap_expr_spans(e: &mut Expr, map: &dyn Fn(u32) -> u32) {
    e.span = Span::new(map(e.span.start.0), map(e.span.end.0));
    let remap_opt = |o: &mut Option<Box<Expr>>, map: &dyn Fn(u32) -> u32| {
        if let Some(inner) = o {
            remap_expr_spans(inner, map);
        }
    };
    let remap_args = |a: &mut crate::ast::Arguments, map: &dyn Fn(u32) -> u32| {
        for arg in a
            .posonlyargs
            .iter_mut()
            .chain(a.args.iter_mut())
            .chain(a.kwonlyargs.iter_mut())
            .chain(a.vararg.iter_mut())
            .chain(a.kwarg.iter_mut())
        {
            arg.span = Span::new(map(arg.span.start.0), map(arg.span.end.0));
            if let Some(ann) = &mut arg.annotation {
                remap_expr_spans(ann, map);
            }
        }
        for d in &mut a.defaults {
            remap_expr_spans(d, map);
        }
        for d in a.kw_defaults.iter_mut().flatten() {
            remap_expr_spans(d, map);
        }
    };
    let remap_comps = |gens: &mut Vec<crate::ast::Comprehension>, map: &dyn Fn(u32) -> u32| {
        for g in gens {
            remap_expr_spans(&mut g.target, map);
            remap_expr_spans(&mut g.iter, map);
            for i in &mut g.ifs {
                remap_expr_spans(i, map);
            }
        }
    };
    match &mut e.kind {
        ExprKind::Constant(_) | ExprKind::Name(_) => {}
        ExprKind::Attribute { value, .. } => remap_expr_spans(value, map),
        ExprKind::Subscript { value, slice } => {
            remap_expr_spans(value, map);
            remap_expr_spans(slice, map);
        }
        ExprKind::Slice { lower, upper, step } => {
            remap_opt(lower, map);
            remap_opt(upper, map);
            remap_opt(step, map);
        }
        ExprKind::BinOp { left, right, .. } => {
            remap_expr_spans(left, map);
            remap_expr_spans(right, map);
        }
        ExprKind::BoolOp { values, .. } => {
            for v in values {
                remap_expr_spans(v, map);
            }
        }
        ExprKind::UnaryOp { operand, .. } => remap_expr_spans(operand, map),
        ExprKind::Compare {
            left, comparators, ..
        } => {
            remap_expr_spans(left, map);
            for c in comparators {
                remap_expr_spans(c, map);
            }
        }
        ExprKind::IfExp { test, body, orelse } => {
            remap_expr_spans(test, map);
            remap_expr_spans(body, map);
            remap_expr_spans(orelse, map);
        }
        ExprKind::NamedExpr { target, value } => {
            remap_expr_spans(target, map);
            remap_expr_spans(value, map);
        }
        ExprKind::Lambda { args, body } | ExprKind::TypeParamFn { args, body } => {
            remap_args(args, map);
            remap_expr_spans(body, map);
        }
        ExprKind::Call {
            func,
            args,
            keywords,
        } => {
            remap_expr_spans(func, map);
            for a in args {
                remap_expr_spans(a, map);
            }
            for k in keywords {
                remap_expr_spans(&mut k.value, map);
            }
        }
        ExprKind::Tuple(items) | ExprKind::List(items) | ExprKind::Set(items) => {
            for i in items {
                remap_expr_spans(i, map);
            }
        }
        ExprKind::Dict { keys, values } => {
            for k in keys.iter_mut().flatten() {
                remap_expr_spans(k, map);
            }
            for v in values {
                remap_expr_spans(v, map);
            }
        }
        ExprKind::ListComp { elt, generators }
        | ExprKind::SetComp { elt, generators }
        | ExprKind::GeneratorExp { elt, generators } => {
            remap_expr_spans(elt, map);
            remap_comps(generators, map);
        }
        ExprKind::DictComp {
            key,
            value,
            generators,
        } => {
            remap_expr_spans(key, map);
            remap_expr_spans(value, map);
            remap_comps(generators, map);
        }
        ExprKind::Starred(inner) | ExprKind::YieldFrom(inner) | ExprKind::Await(inner) => {
            remap_expr_spans(inner, map)
        }
        ExprKind::Yield(inner) => {
            if let Some(i) = inner {
                remap_expr_spans(i, map);
            }
        }
        ExprKind::JoinedStr(parts) | ExprKind::TemplateStr(parts) => {
            for p in parts {
                remap_expr_spans(p, map);
            }
        }
        ExprKind::FormattedValue {
            value, format_spec, ..
        }
        | ExprKind::Interpolation {
            value, format_spec, ..
        } => {
            remap_expr_spans(value, map);
            remap_opt(format_spec, map);
        }
    }
}

#[inline]
fn utf8_char_len(b: u8) -> usize {
    if b < 0x80 {
        1
    } else if b & 0b1110_0000 == 0b1100_0000 {
        2
    } else if b & 0b1111_0000 == 0b1110_0000 {
        3
    } else {
        4
    }
}

/// Build CPython's "closing parenthesis 'X' does not match opening
/// parenthesis 'Y'" diagnostic for a mismatched bracket inside an f-string
/// replacement field.
fn fstring_paren_mismatch(close: char, open: u8, anchor: Span) -> ParseError {
    ParseError::Unexpected {
        span: anchor,
        message: format!(
            "closing parenthesis '{close}' does not match opening parenthesis '{}'",
            open as char
        ),
    }
}

/// Map a failure from the replacement-field sub-parse onto CPython's
/// pegen diagnostics. Specialized messages (the comma hint, a nested
/// f-string's own error, …) survive verbatim; internal phrasing is
/// re-derived: if *some* leading expression parses the field has junk
/// after it ("expecting '=', or '!', or ':', or '}'"), if a lambda lost
/// its `:` to the format spec it gets the dedicated lambda message, and
/// otherwise the expression never started ("expecting a valid expression
/// after '{'").
#[allow(clippy::too_many_arguments)]
fn map_fstring_subparse_error(
    e: ParseError,
    expr_text: &str,
    spec_start: Option<usize>,
    field_abs: u32,
    expr_abs: u32,
    expr_start_span: Span,
    map_back: &dyn Fn(u32) -> u32,
    kind: char,
) -> ParseError {
    let valid_expr_err = || ParseError::Unexpected {
        span: expr_start_span,
        message: format!("{kind}-string: expecting a valid expression after '{{'"),
    };
    // Does a non-empty leading slice of the expression parse as a complete
    // expression list? Returns the junk position (in `wrapped`
    // coordinates) when one does and junk follows.
    let leading_parse = |text: &str| -> Option<(u32, bool)> {
        let wrapped = format!("({text}\n)");
        let tokens = weavepy_lexer::tokenize(&wrapped).ok()?;
        let mut sub = Parser::new(&wrapped, tokens);
        sub.skip_trivia_and_newlines();
        // Consume the synthetic `(` so the parse isn't forced to reach
        // the matching `)`.
        sub.bump();
        sub.skip_trivia_and_newlines();
        sub.parse_expression_list(false).ok()?;
        sub.skip_trivia_and_newlines();
        let sp = sub.peek_token().span;
        let junk_is_expr = sub.parse_expression_list(false).is_ok();
        Some((sp.start.0, junk_is_expr))
    };
    match e {
        ParseError::Lex(weavepy_lexer::LexError::InvalidToken { pos }) => {
            // A byte the tokenizer can't start a token with (`$`, `?`,
            // `` ` ``): pegen sees an error token where it expects
            // `=`/`!`/`:`/`}` — provided some expression precedes it.
            let prefix_end = (pos as usize).saturating_sub(1).min(expr_text.len());
            let prefix = expr_text[..prefix_end].trim();
            let at = map_back(pos);
            if !prefix.is_empty() && leading_parse(prefix).is_some() {
                ParseError::Unexpected {
                    span: Span::new(at, at + 1),
                    message: format!("{kind}-string: expecting '=', or '!', or ':', or '}}'"),
                }
            } else {
                valid_expr_err()
            }
        }
        ParseError::Lex(lex) => {
            let at = map_back(lex.byte_offset());
            ParseError::Unexpected {
                span: Span::new(at, at),
                message: lex.to_string(),
            }
        }
        ParseError::Unexpected { span, message } | ParseError::Indentation { span, message } => {
            // The synthetic `(...)` wrapper makes a bare `f'{*x}'` look
            // parenthesized, picking up pegen's "cannot" wording; the
            // unparenthesized original gets "can't".
            if message == "cannot use starred expression here" {
                return ParseError::Unexpected {
                    span: Span::new(map_back(span.start.0), map_back(span.end.0)),
                    message: "can't use starred expression here".to_owned(),
                };
            }
            let internal = message.starts_with("expected ")
                || message.starts_with("unexpected token")
                || message == "trailing"
                // pegen's catch-all: inside a replacement field it
                // becomes the field-shaped diagnostic ("expecting a
                // valid expression after '{'" / the delimiters list),
                // never the bare form (`f'{.}'`, `f'{lambda x:x}'`).
                || message == "invalid syntax";
            if !internal {
                return ParseError::Unexpected {
                    span: Span::new(map_back(span.start.0), map_back(span.end.0)),
                    message,
                };
            }
            match leading_parse(expr_text) {
                // A leading expression parses; the failure is junk after
                // it (the junk may itself be a `(`-less continuation the
                // paren-wrapped parse choked on).
                Some((junk_pos, junk_is_expr)) => {
                    // pegen takes a lone `=` after the expression as the
                    // debug marker and complains about the *next* token
                    // (`f'{x=y}'`: "expecting '!', or ':', or '}'").
                    let junk_off = (junk_pos as usize).saturating_sub(1).min(expr_text.len());
                    let junk = &expr_text[junk_off..];
                    if junk.starts_with('=') && !junk.starts_with("==") {
                        let rest = &junk[1..];
                        let skip = rest.len() - rest.trim_start().len();
                        let at = map_back(junk_pos + 1 + skip as u32);
                        return ParseError::Unexpected {
                            span: Span::new(at, at + 1),
                            message: format!("{kind}-string: expecting '!', or ':', or '}}'"),
                        };
                    }
                    let at = map_back(junk_pos);
                    ParseError::Unexpected {
                        span: Span::new(at, at + 1),
                        message: if junk_is_expr {
                            "invalid syntax. Perhaps you forgot a comma?".to_owned()
                        } else {
                            format!("{kind}-string: expecting '=', or '!', or ':', or '}}'")
                        },
                    }
                }
                None => fstring_lambda_error(expr_text, spec_start, field_abs, expr_abs, kind)
                    .unwrap_or_else(valid_expr_err),
            }
        }
        ParseError::NotImplemented { .. } => valid_expr_err(),
        // Keep the ValueError-shaped error; just remap the span into the
        // enclosing f-string.
        ParseError::IdentifierConstant { span, name } => ParseError::IdentifierConstant {
            span: Span::new(map_back(span.start.0), map_back(span.end.0)),
            name,
        },
    }
}

/// CPython's pegen has a dedicated rule for a lambda whose body `:` was
/// consumed as the format-spec separator: `f'{lambda x:x}'`. Detected by
/// re-attaching a synthetic `: 0` body — if that parses, the original
/// failure was exactly the missing colon.
fn fstring_lambda_error(
    expr_text: &str,
    spec_start: Option<usize>,
    field_abs: u32,
    expr_abs: u32,
    kind: char,
) -> Option<ParseError> {
    let spec_start = spec_start?;
    if !expr_text.contains("lambda") {
        return None;
    }
    let test = format!("({expr_text}: 0\n)");
    let tokens = weavepy_lexer::tokenize(&test).ok()?;
    let mut sub = Parser::new(&test, tokens);
    sub.skip_trivia_and_newlines();
    sub.parse_expression_list(false).ok()?;
    sub.skip_trivia_and_newlines();
    if !matches!(sub.peek(), TokenKind::Endmarker) {
        return None;
    }
    let lam_off = find_last_toplevel_lambda(expr_text)?;
    Some(ParseError::Unexpected {
        // CPython spans from the `lambda` keyword through the spec colon.
        span: Span::new(expr_abs + lam_off as u32, field_abs + spec_start as u32),
        message: format!("{kind}-string: lambda expressions are not allowed without parentheses"),
    })
}

/// Skip a string literal that appears inside a replacement field's
/// expression text, starting at its opening quote; returns the index just
/// past its closing quote. PEP 701 allows quote reuse, so a nested
/// *f*-string (detected via the immediately-preceding prefix run, like the
/// lexer's `scan_fstring_nested_string`) must have its `{...}` fields
/// scanned as expressions again — recursively — or the nested string's own
/// quote is misread as a terminator (`f'{f'{f'''{1}'''}'}'`,
/// test_unparse test_fstrings_pep701). Returns `None` when the string never
/// closes; precise diagnostics are the sub-parse's job.
fn skip_field_string(bytes: &[u8], quote_at: usize) -> Option<usize> {
    let quote = bytes[quote_at];
    let triple = bytes.get(quote_at + 1) == Some(&quote) && bytes.get(quote_at + 2) == Some(&quote);
    // Walk back over the immediately-preceding ASCII-letter run to recover
    // any prefix (`f`, `rf`, ...); it only counts when not glued to a
    // longer identifier.
    let mut s = quote_at;
    while s > 0 && bytes[s - 1].is_ascii_alphabetic() {
        s -= 1;
    }
    let glued = s > 0 && (bytes[s - 1] == b'_' || bytes[s - 1].is_ascii_digit());
    let fstring = !glued
        && std::str::from_utf8(&bytes[s..quote_at])
            .ok()
            .and_then(weavepy_lexer::StringPrefix::parse)
            .is_some_and(|p| p.fstring);
    let mut i = quote_at + if triple { 3 } else { 1 };
    while i < bytes.len() {
        let b = bytes[i];
        if b == b'\\' {
            // The backslash escapes the next byte for extent purposes in
            // raw and non-raw strings alike (mirrors the lexer).
            i += 2;
            continue;
        }
        if b == quote {
            if !triple {
                return Some(i + 1);
            }
            if bytes.get(i + 1) == Some(&quote) && bytes.get(i + 2) == Some(&quote) {
                return Some(i + 3);
            }
            i += 1;
            continue;
        }
        if fstring && b == b'{' {
            if bytes.get(i + 1) == Some(&b'{') {
                i += 2;
                continue;
            }
            i = skip_field_expr(bytes, i + 1)?;
            continue;
        }
        if fstring && b == b'}' && bytes.get(i + 1) == Some(&b'}') {
            i += 2;
            continue;
        }
        if (b == b'\n' || b == b'\r') && !triple {
            return None;
        }
        i += 1;
    }
    None
}

/// Skip a nested f-string replacement field from just past its `{` to just
/// past its matching `}`, bracket- and string-aware. Companion to
/// [`skip_field_string`]; structural errors inside the nested field are
/// reported by its own re-parse, so a mismatch here only yields `None`.
fn skip_field_expr(bytes: &[u8], start: usize) -> Option<usize> {
    let mut stack: Vec<u8> = Vec::new();
    let mut in_spec = false;
    let mut i = start;
    while i < bytes.len() {
        match bytes[i] {
            b'}' if stack.is_empty() => return Some(i + 1),
            b'\\' => i += 2,
            // At the spec's own top level a quote is literal text.
            b'"' | b'\'' if !(in_spec && stack.is_empty()) => {
                i = skip_field_string(bytes, i)?;
            }
            b @ (b'(' | b'[' | b'{') => {
                stack.push(b);
                i += 1;
            }
            b')' | b']' | b'}' => {
                stack.pop();
                i += 1;
            }
            b':' if stack.is_empty() => {
                in_spec = true;
                i += 1;
            }
            b'#' if !in_spec => {
                while i < bytes.len() && bytes[i] != b'\n' {
                    i += 1;
                }
            }
            _ => i += 1,
        }
    }
    None
}

/// Byte offset of the last top-level `lambda` keyword in `expr` (outside
/// strings and brackets, with identifier boundaries).
fn find_last_toplevel_lambda(expr: &str) -> Option<usize> {
    let bytes = expr.as_bytes();
    let mut depth = 0i32;
    let mut in_str: Option<u8> = None;
    let mut found = None;
    let mut i = 0usize;
    while i < bytes.len() {
        let b = bytes[i];
        if let Some(q) = in_str {
            if b == b'\\' {
                i += 2;
                continue;
            }
            if b == q {
                in_str = None;
            }
            i += 1;
            continue;
        }
        match b {
            b'"' | b'\'' => in_str = Some(b),
            b'(' | b'[' | b'{' => depth += 1,
            b')' | b']' | b'}' => depth -= 1,
            b'l' if depth == 0 => {
                let is_word = bytes[i..].starts_with(b"lambda")
                    && (i == 0 || !is_ident_byte(bytes[i - 1]))
                    && bytes.get(i + 6).is_none_or(|&n| !is_ident_byte(n));
                if is_word {
                    found = Some(i);
                    i += 6;
                    continue;
                }
            }
            _ => {}
        }
        i += 1;
    }
    found
}

#[inline]
fn is_ident_byte(b: u8) -> bool {
    b.is_ascii_alphanumeric() || b == b'_' || b >= 0x80
}

/// Validate the conversion clause text (between `!` and the spec `:` /
/// field end), returning the conversion code or CPython's exact
/// diagnostic. `idx` is the clause's byte offset within `field`.
fn validate_fstring_conversion(
    text: &str,
    idx: usize,
    field: &str,
    field_abs: u32,
    kind: char,
) -> Result<i32, ParseError> {
    let abs = |off: usize| field_abs + (idx + off) as u32;
    if text.is_empty() {
        return Err(ParseError::Unexpected {
            span: Span::new(abs(0), abs(0) + 1),
            message: format!("{kind}-string: missing conversion character"),
        });
    }
    let first = text.chars().next().expect("non-empty");
    if first.is_whitespace() {
        // CPython spans from the `!` through the end of the field.
        return Err(ParseError::Unexpected {
            span: Span::new(field_abs + (idx - 1) as u32, field_abs + field.len() as u32),
            message: format!(
                "{kind}-string: conversion type must come right after the exclamation mark"
            ),
        });
    }
    if !(unicode_ident::is_xid_start(first) || first == '_') {
        return Err(ParseError::Unexpected {
            span: Span::new(abs(0), abs(first.len_utf8())),
            message: format!("{kind}-string: invalid conversion character"),
        });
    }
    let ident_end = text
        .char_indices()
        .find(|(_, c)| !(unicode_ident::is_xid_continue(*c) || *c == '_'))
        .map(|(i, _)| i)
        .unwrap_or(text.len());
    let ident = &text[..ident_end];
    // Trailing whitespace after the conversion is insignificant; anything
    // else expects the spec or the closing brace.
    let rest = &text[ident_end..];
    if let Some((j, c)) = rest.char_indices().find(|(_, c)| !c.is_whitespace()) {
        let at = ident_end + j;
        return Err(ParseError::Unexpected {
            span: Span::new(abs(at), abs(at + c.len_utf8())),
            message: format!("{kind}-string: expecting ':' or '}}'"),
        });
    }
    if !matches!(ident, "s" | "r" | "a") {
        return Err(ParseError::Unexpected {
            span: Span::new(abs(0), abs(ident_end)),
            message: format!(
                "{kind}-string: invalid conversion character '{ident}': expected 's', 'r', or 'a'"
            ),
        });
    }
    Ok(i32::from(ident.as_bytes()[0]))
}

/// Remove `#` comments from the expression part of an f-string replacement
/// field while leaving everything else (including whitespace and newlines)
/// byte-for-byte intact. PEP 701 permits comments inside multi-line fields;
/// a `#` only starts a comment outside of string literals, so this tracks
/// single/triple-quoted strings (and their backslash escapes) to avoid
/// mangling a `#` that lives inside a string. A comment runs to the next
/// newline (the newline itself is preserved).
fn strip_fstring_field_comments(s: &str) -> String {
    scrub_fstring_field_comments(s, false)
}

/// Like [`strip_fstring_field_comments`], but each comment byte becomes a
/// space, so byte offsets into the result equal offsets into `s` (the
/// expression's source span must start at its first real character,
/// even when a comment sits between `{` and the expression).
fn blank_fstring_field_comments(s: &str) -> String {
    scrub_fstring_field_comments(s, true)
}

fn scrub_fstring_field_comments(s: &str, blank: bool) -> String {
    let bytes = s.as_bytes();
    let mut out = String::with_capacity(s.len());
    let mut i = 0usize;
    // `Some(quote)` while inside a string literal; `triple` tracks `"""`/`'''`.
    let mut in_str: Option<u8> = None;
    let mut triple = false;
    while i < bytes.len() {
        let b = bytes[i];
        if let Some(q) = in_str {
            if b == b'\\' {
                // Copy the backslash and its escaped char as a unit so an
                // escaped quote can't be read as closing the string.
                out.push('\\');
                i += 1;
                if i < bytes.len() {
                    let cl = utf8_char_len(bytes[i]);
                    let e = (i + cl).min(bytes.len());
                    out.push_str(&s[i..e]);
                    i = e;
                }
                continue;
            }
            if b == q {
                if triple {
                    if i + 2 < bytes.len() && bytes[i + 1] == q && bytes[i + 2] == q {
                        out.push_str(&s[i..i + 3]);
                        i += 3;
                        in_str = None;
                        triple = false;
                        continue;
                    }
                } else {
                    out.push(q as char);
                    i += 1;
                    in_str = None;
                    continue;
                }
            }
            let cl = utf8_char_len(b);
            let e = (i + cl).min(bytes.len());
            out.push_str(&s[i..e]);
            i = e;
            continue;
        }
        match b {
            b'#' => {
                // Drop the comment up to (but not including) the newline.
                while i < bytes.len() && bytes[i] != b'\n' {
                    if blank {
                        out.push(' ');
                    }
                    i += 1;
                }
            }
            b'"' | b'\'' => {
                if i + 2 < bytes.len() && bytes[i + 1] == b && bytes[i + 2] == b {
                    in_str = Some(b);
                    triple = true;
                    out.push_str(&s[i..i + 3]);
                    i += 3;
                } else {
                    in_str = Some(b);
                    triple = false;
                    out.push(b as char);
                    i += 1;
                }
            }
            _ => {
                let cl = utf8_char_len(b);
                let e = (i + cl).min(bytes.len());
                out.push_str(&s[i..e]);
                i = e;
            }
        }
    }
    out
}

/// Working state while concatenating adjacent string tokens. The `Plain`
/// arm accumulates *code points* (not a `String`) so that a lone surrogate
/// from any fragment survives implicit concatenation; the final value is
/// canonicalised to `Str`/`WStr` by [`cps_to_constant`].
enum AccumString {
    Plain(Vec<u32>),
    Bytes(Vec<u8>),
    Joined(Vec<Expr>),
    /// PEP 750 t-string parts (`-X lang=next`). Only t-strings may join
    /// the concatenation; mixing with str/bytes/f-strings is a
    /// SyntaxError.
    Template(Vec<Expr>),
}

/// Code points of a string [`Constant`] (`Str` or `WStr`); panics on a
/// non-string constant, which the callers structurally exclude.
fn constant_str_cps(c: Constant) -> Vec<u32> {
    match c {
        Constant::Str(s) => s.chars().map(|ch| ch as u32).collect(),
        Constant::WStr(cps) => cps,
        _ => unreachable!("constant_str_cps on non-string constant"),
    }
}

/// Append a literal string onto the tail of a JoinedStr parts list.
/// Merges with the trailing string part (`Str` or `WStr`) if there is one,
/// re-canonicalising the merged value.
fn join_str_into_parts(parts: &mut Vec<Expr>, c: Constant, span: Span) {
    if let Some(last) = parts.last_mut() {
        let merged = match &last.kind {
            ExprKind::Constant(existing @ (Constant::Str(_) | Constant::WStr(_))) => {
                let mut cps = constant_str_cps(existing.clone());
                cps.extend(constant_str_cps(c.clone()));
                Some(cps)
            }
            _ => None,
        };
        if let Some(cps) = merged {
            last.kind = ExprKind::Constant(cps_to_constant(cps));
            // The merged literal spans from the first fragment's start
            // to the last fragment's end (CPython's implicit-concat AST
            // positions cross the token boundary).
            last.span = Span::new(last.span.start.0, span.end.0);
            return;
        }
    }
    // An empty fragment that can't merge contributes nothing: CPython's
    // concat never emits an empty Constant part into a JoinedStr
    // (`f'{1}' ''` has values=[FormattedValue] only —
    // test_unparse test_multiquote_joined_string).
    if matches!(&c, Constant::Str(s) if s.is_empty()) {
        return;
    }
    parts.push(Expr {
        kind: ExprKind::Constant(c),
        span,
    });
}

/// Re-parse an unterminated f-string field (`source[field_start..limit]`)
/// to surface a *specialized* interior diagnostic, if any. Returns
/// `None` when the partial expression parses cleanly or only fails
/// generically — the caller then keeps the original lexer error.
pub(crate) fn partial_fstring_field_error(
    source: &str,
    field_start: u32,
    limit: u32,
    kind: char,
) -> Option<ParseError> {
    let end = (limit as usize).min(source.len());
    let start = (field_start as usize).min(end);
    if !source.is_char_boundary(start) || !source.is_char_boundary(end) {
        return None;
    }
    let field = &source[start..end];
    let tokens = weavepy_lexer::tokenize("").ok()?;
    let p = Parser::new("", tokens);
    let anchor = Span::new(field_start, limit);
    match p.parse_fstring_field(field, anchor, field_start, false, true, kind == 't', kind) {
        Err(e) => {
            // Errors CPython's pegen reports from the tokens it has
            // already seen win over the tokenizer's unterminated-field
            // diagnostic; anything else keeps the lexer error.
            let wins = match &e {
                ParseError::Unexpected { message, .. }
                | ParseError::Indentation { message, .. } => {
                    // Strip the "f-string: " / "t-string: " tag.
                    let body = message
                        .strip_prefix("f-string: ")
                        .or_else(|| message.strip_prefix("t-string: "))
                        .unwrap_or(message);
                    message.starts_with("invalid syntax.")
                        || body.starts_with("valid expression required before")
                        || body == "expecting a valid expression after '{'"
                        || body == "expecting '=', or '!', or ':', or '}'"
                        || body == "missing conversion character"
                        || body.starts_with("invalid conversion character")
                        || body == "conversion type must come right after the exclamation mark"
                        || body == "lambda expressions are not allowed without parentheses"
                }
                _ => false,
            };
            wins.then_some(e)
        }
        Ok(_) => None,
    }
}

fn split_string_prefix(lex: &str) -> (&str, &str) {
    let mut idx = 0;
    for (i, c) in lex.char_indices() {
        if c == '"' || c == '\'' {
            idx = i;
            break;
        }
    }
    lex.split_at(idx)
}

/// `_PyPegen_joined_str` / `_PyPegen_setup_full_format_spec` skip
/// literal f-string parts whose decoded value is the empty string (the
/// tokenizer still emits a part for `\<newline>` continuations).
fn is_empty_str_constant(c: &Constant) -> bool {
    matches!(c, Constant::Str(s) if s.is_empty())
}

fn strip_quotes(s: &str) -> &str {
    let bytes = s.as_bytes();
    if bytes.len() >= 6
        && ((bytes.starts_with(b"\"\"\"") && bytes.ends_with(b"\"\"\""))
            || (bytes.starts_with(b"'''") && bytes.ends_with(b"'''")))
    {
        &s[3..s.len() - 3]
    } else if bytes.len() >= 2 {
        &s[1..s.len() - 1]
    } else {
        ""
    }
}

/// Decode a (non-f) string-literal body. Returns the decoded text plus
/// any invalid-escape diagnostics CPython would surface as a
/// `SyntaxWarning` (unrecognised escapes and octal escapes `> \377`).
/// Each diagnostic carries the byte offset of its backslash *within the
/// body* so the caller can map it back to an absolute source position.
/// Canonicalise a decoded code-point sequence into a string [`Constant`]:
/// [`Constant::Str`] when every code point is a Unicode scalar value, or
/// [`Constant::WStr`] when at least one lone surrogate is present.
fn cps_to_constant(cps: Vec<u32>) -> Constant {
    if cps.iter().any(|&c| (0xD800..=0xDFFF).contains(&c)) {
        Constant::WStr(cps)
    } else {
        let mut s = String::with_capacity(cps.len());
        for c in cps {
            if let Some(ch) = char::from_u32(c) {
                s.push(ch);
            }
        }
        Constant::Str(s)
    }
}

/// `\N{NAME}` resolution outcome supplied by the embedding VM (RFC 0050
/// WS4): the runtime resolves names against its generated UCD tables and
/// honours a poisoned `sys.modules['unicodedata']` the way CPython's
/// tokenizer does.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum UnicodeNameResolution {
    /// Resolved to this code point.
    Code(u32),
    /// No character has this name.
    Unknown,
    /// The unicodedata machinery can't be loaded (CPython: the import of
    /// `unicodedata` failed, e.g. `sys.modules['unicodedata'] = None`).
    Unavailable,
}

static UNICODE_NAME_RESOLVER: std::sync::OnceLock<fn(&str) -> UnicodeNameResolution> =
    std::sync::OnceLock::new();

/// Install the VM-side `\N{NAME}` resolver. First installation wins;
/// standalone parser users fall back to the `unicode_names2` table.
pub fn set_unicode_name_resolver(f: fn(&str) -> UnicodeNameResolution) {
    let _ = UNICODE_NAME_RESOLVER.set(f);
}

fn resolve_unicode_name(name: &str) -> UnicodeNameResolution {
    match UNICODE_NAME_RESOLVER.get() {
        Some(f) => f(name),
        None => match unicode_names2::character(name) {
            Some(ch) => UnicodeNameResolution::Code(ch as u32),
            None => UnicodeNameResolution::Unknown,
        },
    }
}

fn decode_str_body(s: &str, raw: bool) -> Result<Constant, String> {
    if raw {
        return Ok(Constant::Str(s.to_owned()));
    }
    // CPython surfaces escape-decoding failures as the unicodeescape
    // codec's error, with byte positions of the failed escape within the
    // body: "(unicode error) 'unicodeescape' codec can't decode bytes in
    // position {start}-{end}: {reason}". `end` is the last consumed byte.
    let unicode_err = |start: usize, end: usize, reason: &str| -> String {
        let last = end.saturating_sub(1);
        format!(
            "(unicode error) 'unicodeescape' codec can't decode bytes in \
             position {start}-{last}: {reason}"
        )
    };
    let bytes = s.as_bytes();
    // Accumulate code points (each a scalar value *or* a lone surrogate) so a
    // `\udxxx`/`\uXXXX`/`\xXX`/`\N{}` escape that resolves to a surrogate
    // survives to runtime as an `Object::WStr` (canonicalised by
    // `cps_to_constant`). Pure-UTF-8 literals fold straight back to `Str`.
    let mut out: Vec<u32> = Vec::with_capacity(s.len());
    let mut chars = s.char_indices().peekable();
    while let Some((bs, c)) = chars.next() {
        if c != '\\' {
            out.push(c as u32);
            continue;
        }
        let Some((_, esc)) = chars.next() else {
            out.push('\\' as u32);
            break;
        };
        match esc {
            'n' => out.push('\n' as u32),
            'r' => out.push('\r' as u32),
            't' => out.push('\t' as u32),
            '\\' => out.push('\\' as u32),
            '\'' => out.push('\'' as u32),
            '"' => out.push('"' as u32),
            // Octal escape `\ooo`: 1–3 octal digits (CPython accepts up
            // to `\777` = 511 in a str literal). `\0` is just the
            // zero-length-tail case of this rule. Values above `\377`
            // draw a `SyntaxWarning`, detected by the lexer.
            '0'..='7' => {
                let mut val = esc as u32 - '0' as u32;
                for _ in 0..2 {
                    match chars.peek().copied() {
                        Some((_, d @ '0'..='7')) => {
                            val = val * 8 + (d as u32 - '0' as u32);
                            chars.next();
                        }
                        _ => break,
                    }
                }
                out.push(val);
            }
            'a' => out.push('\x07' as u32),
            'b' => out.push('\x08' as u32),
            'f' => out.push('\x0c' as u32),
            'v' => out.push('\x0b' as u32),
            // Line continuation inside the string (`\` + newline). A
            // `\<CR>` (optionally `\<CR><LF>`) continues too.
            '\n' => {}
            '\r' => {
                if matches!(chars.peek(), Some((_, '\n'))) {
                    chars.next();
                }
            }
            'x' | 'u' | 'U' => {
                let want = match esc {
                    'x' => 2,
                    'u' => 4,
                    _ => 8,
                };
                let mut hex = String::new();
                for _ in 0..want {
                    match chars.peek().copied() {
                        Some((_, h)) if h.is_ascii_hexdigit() => {
                            hex.push(h);
                            chars.next();
                        }
                        _ => break,
                    }
                }
                let end = chars.peek().map_or(bytes.len(), |(i, _)| *i);
                if hex.len() < want {
                    let reason = match esc {
                        'x' => "truncated \\xXX escape",
                        'u' => "truncated \\uXXXX escape",
                        _ => "truncated \\UXXXXXXXX escape",
                    };
                    return Err(unicode_err(bs, end, reason));
                }
                let n = u32::from_str_radix(&hex, 16).expect("hex digits");
                // Out-of-range code points are CPython's "illegal Unicode
                // character". Lone surrogates are *valid* in CPython str
                // literals; Rust `char` can't hold them, so they degrade
                // to U+FFFD (pre-existing representation limit).
                if n > 0x0010_FFFF {
                    return Err(unicode_err(bs, end, "illegal Unicode character"));
                }
                // Preserve lone surrogates verbatim (CPython allows them in str
                // literals); `cps_to_constant` decides Str vs WStr.
                out.push(n);
            }
            'N' => {
                // `\N{UNICODE CHARACTER NAME}` — resolve the name against
                // the full UCD name table. CPython requires the brace form
                // and raises a SyntaxError ("malformed \N character escape"
                // / "unknown Unicode character name") otherwise.
                if !matches!(chars.peek(), Some((_, '{'))) {
                    return Err(unicode_err(bs, bs + 2, "malformed \\N character escape"));
                }
                chars.next();
                let mut name = String::new();
                loop {
                    match chars.next() {
                        Some((i, '}')) => {
                            match resolve_unicode_name(&name) {
                                UnicodeNameResolution::Code(cp) => out.push(cp),
                                UnicodeNameResolution::Unknown => {
                                    return Err(unicode_err(
                                        bs,
                                        i + 1,
                                        "unknown Unicode character name",
                                    ))
                                }
                                // CPython's tokenizer message when importing
                                // `unicodedata` fails — *not* wrapped in the
                                // unicodeescape-codec position text.
                                UnicodeNameResolution::Unavailable => {
                                    return Err("(unicode error) \\N escapes not supported \
                                                (can't load unicodedata module)"
                                        .to_owned())
                                }
                            }
                            break;
                        }
                        Some((_, c)) => name.push(c),
                        None => {
                            return Err(unicode_err(
                                bs,
                                bytes.len(),
                                "malformed \\N character escape",
                            ))
                        }
                    }
                }
            }
            other => {
                // CPython issues a `SyntaxWarning` for unknown escapes (the
                // lexer records it) but emits both characters literally.
                out.push('\\' as u32);
                out.push(other as u32);
            }
        }
    }
    Ok(cps_to_constant(out))
}

/// Decode a bytes-literal body. Like [`decode_str_body`] but bytes-valued
/// and ASCII-only: a non-ASCII source character is a `SyntaxError` ("bytes
/// can only contain ASCII literal characters") in both raw and cooked
/// forms, and octal escapes wrap mod 256. Invalid-escape `SyntaxWarning`s
/// are detected separately by the lexer (see
/// [`weavepy_lexer::tokenize_with_escapes`]).
fn decode_bytes_body(s: &str, raw: bool) -> Result<Vec<u8>, String> {
    if raw {
        let mut out = Vec::with_capacity(s.len());
        for c in s.chars() {
            if !c.is_ascii() {
                return Err("bytes can only contain ASCII literal characters".to_owned());
            }
            out.push(c as u8);
        }
        return Ok(out);
    }
    let mut out = Vec::with_capacity(s.len());
    let mut chars = s.chars().peekable();
    while let Some(c) = chars.next() {
        if c.is_ascii() {
            if c != '\\' {
                out.push(c as u8);
                continue;
            }
        } else {
            return Err("bytes can only contain ASCII literal characters".to_owned());
        }
        let Some(esc) = chars.next() else {
            out.push(b'\\');
            break;
        };
        match esc {
            'n' => out.push(b'\n'),
            'r' => out.push(b'\r'),
            't' => out.push(b'\t'),
            '\\' => out.push(b'\\'),
            '\'' => out.push(b'\''),
            '"' => out.push(b'"'),
            // Octal escape `\ooo` (1–3 digits). In a bytes literal the
            // value is stored as a single byte, so CPython wraps it mod
            // 256 (`b'\400'` -> 0x00, `b'\777'` -> 0xFF).
            '0'..='7' => {
                let mut val: u32 = esc as u32 - '0' as u32;
                for _ in 0..2 {
                    match chars.peek().copied() {
                        Some(d @ '0'..='7') => {
                            val = val * 8 + (d as u32 - '0' as u32);
                            chars.next();
                        }
                        _ => break,
                    }
                }
                out.push((val & 0xFF) as u8);
            }
            'a' => out.push(0x07),
            'b' => out.push(0x08),
            'f' => out.push(0x0c),
            'v' => out.push(0x0b),
            '\n' => {}
            'x' => {
                let h1 = chars.next().ok_or("incomplete \\x escape")?;
                let h2 = chars.next().ok_or("incomplete \\x escape")?;
                let hex = format!("{h1}{h2}");
                let n = u8::from_str_radix(&hex, 16).map_err(|e| e.to_string())?;
                out.push(n);
            }
            other => {
                out.push(b'\\');
                if other.is_ascii() {
                    out.push(other as u8);
                }
            }
        }
    }
    Ok(out)
}

thread_local! {
    /// PEP 0467 digit cap for decimal int literals, mirrored from
    /// `sys.int_max_str_digits` by the VM (see
    /// [`set_int_literal_max_digits`]). CPython enforces the cap inside
    /// `parsenumber` via `PyLong_FromString`, so an over-long decimal
    /// literal is a *SyntaxError* (test_ast test_literal_eval_str_int_limit).
    static INT_LITERAL_MAX_DIGITS: std::cell::Cell<i64> = const { std::cell::Cell::new(4300) };
}

/// Sync the decimal int-literal digit cap with `sys.set_int_max_str_digits`
/// (0 disables the limit).
pub fn set_int_literal_max_digits(n: i64) {
    INT_LITERAL_MAX_DIGITS.with(|c| c.set(n));
}

fn parse_number(lex: &str) -> Result<Constant, String> {
    use num_bigint::BigInt;

    let cleaned: String = lex.chars().filter(|c| *c != '_').collect();

    // Imaginary suffix: peel `j`/`J` and parse the body as a float.
    if cleaned.ends_with('j') || cleaned.ends_with('J') {
        let body = &cleaned[..cleaned.len() - 1];
        let imag: f64 = body
            .parse()
            .map_err(|e: std::num::ParseFloatError| e.to_string())?;
        return Ok(Constant::Complex(0.0, imag));
    }

    // Integer literal in a non-decimal radix.
    let try_radix = |prefix_lo: &str, prefix_hi: &str, radix: u32| -> Option<&str> {
        let _ = radix;
        cleaned
            .strip_prefix(prefix_lo)
            .or_else(|| cleaned.strip_prefix(prefix_hi))
    };
    if let Some(rest) = try_radix("0x", "0X", 16) {
        return parse_radix_int(rest, 16);
    }
    if let Some(rest) = try_radix("0o", "0O", 8) {
        return parse_radix_int(rest, 8);
    }
    if let Some(rest) = try_radix("0b", "0B", 2) {
        return parse_radix_int(rest, 2);
    }

    // Float literal.
    let has_float_marker = cleaned.contains('.') || cleaned.contains('e') || cleaned.contains('E');
    if has_float_marker {
        let f: f64 = cleaned
            .parse()
            .map_err(|e: std::num::ParseFloatError| e.to_string())?;
        return Ok(Constant::Float(f));
    }

    // Decimal integer; promote to BigInt on overflow.
    let max_digits = INT_LITERAL_MAX_DIGITS.with(|c| c.get());
    if max_digits > 0 && cleaned.len() as i64 > max_digits {
        return Err(format!(
            "Exceeds the limit ({max_digits} digits) for integer string conversion: \
             value has {} digits; use sys.set_int_max_str_digits() to increase the limit \
             - Consider hexadecimal for huge integer literals to avoid decimal conversion \
             limits.",
            cleaned.len()
        ));
    }
    if let Ok(n) = cleaned.parse::<i64>() {
        return Ok(Constant::Int(n));
    }
    let big: BigInt = cleaned
        .parse()
        .map_err(|_| "invalid integer literal".to_owned())?;
    if let Some(small) = big_to_i64(&big) {
        return Ok(Constant::Int(small));
    }
    Ok(Constant::BigInt(big.to_string()))
}

fn parse_radix_int(rest: &str, radix: u32) -> Result<Constant, String> {
    use num_bigint::BigInt;

    if let Ok(n) = i64::from_str_radix(rest, radix) {
        return Ok(Constant::Int(n));
    }
    let big = BigInt::parse_bytes(rest.as_bytes(), radix)
        .ok_or_else(|| "invalid integer literal".to_owned())?;
    if let Some(small) = big_to_i64(&big) {
        return Ok(Constant::Int(small));
    }
    Ok(Constant::BigInt(big.to_string()))
}

fn big_to_i64(b: &num_bigint::BigInt) -> Option<i64> {
    use num_bigint::Sign;
    let (sign, digits) = b.to_u64_digits();
    match digits.len() {
        0 => Some(0),
        1 => {
            let v = digits[0];
            match sign {
                Sign::Plus | Sign::NoSign => i64::try_from(v).ok(),
                Sign::Minus => {
                    if v == (i64::MAX as u64) + 1 {
                        Some(i64::MIN)
                    } else {
                        i64::try_from(v).ok().map(|n| -n)
                    }
                }
            }
        }
        _ => None,
    }
}

/// PEP 695 annotation scopes (type-parameter bounds/constraints/
/// defaults, `type` alias values, and the header of a generic
/// `def`/`class`) reject `yield`, `yield from`, `await`, and the
/// walrus operator (CPython symtable's TypeVarBound/TypeAlias/
/// TypeParam block checks). Lambda *bodies* are ordinary function
/// scopes and are exempt (their defaults still evaluate here).
pub(crate) fn check_type_param_expr(e: &Expr, ctx: &str) -> Result<(), ParseError> {
    let err = |what: &str, span: Span| -> Result<(), ParseError> {
        Err(ParseError::Unexpected {
            span,
            message: format!("{what} cannot be used within {ctx}"),
        })
    };
    match &e.kind {
        ExprKind::Yield(_) | ExprKind::YieldFrom(_) => return err("yield expression", e.span),
        ExprKind::Await(_) => return err("await expression", e.span),
        ExprKind::NamedExpr { .. } => return err("named expression", e.span),
        ExprKind::Lambda { args, .. } | ExprKind::TypeParamFn { args, .. } => {
            for d in args
                .defaults
                .iter()
                .chain(args.kw_defaults.iter().flatten())
            {
                check_type_param_expr(d, ctx)?;
            }
            return Ok(());
        }
        _ => {}
    }
    for child in expr_children(e) {
        check_type_param_expr(child, ctx)?;
    }
    Ok(())
}

/// Immediate sub-expressions of `e`, for read-only traversal.
pub fn expr_children(e: &Expr) -> Vec<&Expr> {
    let mut out: Vec<&Expr> = Vec::new();
    match &e.kind {
        ExprKind::Constant(_) | ExprKind::Name(_) => {}
        ExprKind::Attribute { value, .. } => out.push(value),
        ExprKind::Subscript { value, slice } => {
            out.push(value);
            out.push(slice);
        }
        ExprKind::Slice { lower, upper, step } => {
            out.extend(lower.as_deref());
            out.extend(upper.as_deref());
            out.extend(step.as_deref());
        }
        ExprKind::BinOp { left, right, .. } => {
            out.push(left);
            out.push(right);
        }
        ExprKind::BoolOp { values, .. } => out.extend(values.iter()),
        ExprKind::UnaryOp { operand, .. } => out.push(operand),
        ExprKind::Compare {
            left, comparators, ..
        } => {
            out.push(left);
            out.extend(comparators.iter());
        }
        ExprKind::IfExp { test, body, orelse } => {
            out.push(test);
            out.push(body);
            out.push(orelse);
        }
        ExprKind::NamedExpr { target, value } => {
            out.push(target);
            out.push(value);
        }
        ExprKind::Call {
            func,
            args,
            keywords,
        } => {
            out.push(func);
            out.extend(args.iter());
            out.extend(keywords.iter().map(|k| &k.value));
        }
        ExprKind::Lambda { args, body } | ExprKind::TypeParamFn { args, body } => {
            out.extend(args.defaults.iter());
            out.extend(args.kw_defaults.iter().flatten());
            out.push(body);
        }
        ExprKind::Tuple(items) | ExprKind::List(items) | ExprKind::Set(items) => {
            out.extend(items.iter());
        }
        ExprKind::Dict { keys, values } => {
            out.extend(keys.iter().flatten());
            out.extend(values.iter());
        }
        ExprKind::ListComp { elt, generators }
        | ExprKind::SetComp { elt, generators }
        | ExprKind::GeneratorExp { elt, generators } => {
            out.push(elt);
            for g in generators {
                out.push(&g.target);
                out.push(&g.iter);
                out.extend(g.ifs.iter());
            }
        }
        ExprKind::DictComp {
            key,
            value,
            generators,
        } => {
            out.push(key);
            out.push(value);
            for g in generators {
                out.push(&g.target);
                out.push(&g.iter);
                out.extend(g.ifs.iter());
            }
        }
        ExprKind::Starred(inner) => out.push(inner),
        ExprKind::Yield(v) => out.extend(v.as_deref()),
        ExprKind::YieldFrom(v) | ExprKind::Await(v) => out.push(v),
        ExprKind::JoinedStr(parts) | ExprKind::TemplateStr(parts) => out.extend(parts.iter()),
        ExprKind::FormattedValue {
            value, format_spec, ..
        }
        | ExprKind::Interpolation {
            value, format_spec, ..
        } => {
            out.push(value);
            out.extend(format_spec.as_deref());
        }
    }
    out
}

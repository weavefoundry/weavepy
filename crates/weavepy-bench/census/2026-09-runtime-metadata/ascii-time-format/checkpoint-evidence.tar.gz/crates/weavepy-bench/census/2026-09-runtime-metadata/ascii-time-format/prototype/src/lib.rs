//! Unapplied safe ASCII formatting for ordinary time fields.

pub struct TimeText {
    bytes: [u8; 15],
    len: usize,
}

impl TimeText {
    pub fn as_str(&self) -> &str {
        std::str::from_utf8(&self.bytes[..self.len]).expect("ASCII time fields")
    }
}

/// Decline invalid fields and unknown precision; callers retain their fallback.
pub fn format_time(
    hour: i64,
    minute: i64,
    second: i64,
    micros: i64,
    spec: &str,
) -> Option<TimeText> {
    if !(0..=23).contains(&hour)
        || !(0..=59).contains(&minute)
        || !(0..=59).contains(&second)
        || !(0..=999_999).contains(&micros)
    {
        return None;
    }
    let len = match spec {
        "hours" => 2,
        "minutes" => 5,
        "seconds" => 8,
        "milliseconds" => 12,
        "microseconds" => 15,
        "auto" => {
            if micros == 0 {
                8
            } else {
                15
            }
        }
        _ => return None,
    };
    let mut bytes = [b'0'; 15];
    for (offset, field) in [(0, hour), (3, minute), (6, second)] {
        bytes[offset] += (field / 10) as u8;
        bytes[offset + 1] += (field % 10) as u8;
    }
    bytes[2] = b':';
    bytes[5] = b':';
    bytes[8] = b'.';
    let mut fraction = micros;
    for byte in bytes[9..].iter_mut().rev() {
        *byte += (fraction % 10) as u8;
        fraction /= 10;
    }
    Some(TimeText { bytes, len })
}

#[cfg(test)]
mod tests {
    use super::format_time;

    #[test]
    fn precisions_pad_and_truncate_without_rounding() {
        for (spec, expected) in [
            ("hours", "03"),
            ("minutes", "03:04"),
            ("seconds", "03:04:05"),
            ("milliseconds", "03:04:05.001"),
            ("microseconds", "03:04:05.001999"),
            ("auto", "03:04:05.001999"),
        ] {
            assert_eq!(format_time(3, 4, 5, 1999, spec).unwrap().as_str(), expected);
        }
    }

    #[test]
    fn automatic_precision_depends_only_on_nonzero_fraction() {
        for (us, expected) in [
            (0, "23:59:59"),
            (1, "23:59:59.000001"),
            (999, "23:59:59.000999"),
            (1000, "23:59:59.001000"),
            (999_999, "23:59:59.999999"),
        ] {
            assert_eq!(
                format_time(23, 59, 59, us, "auto").unwrap().as_str(),
                expected
            );
        }
        assert_eq!(
            format_time(0, 0, 0, 0, "microseconds").unwrap().as_str(),
            "00:00:00.000000"
        );
    }

    #[test]
    fn out_of_range_and_unknown_values_request_fallback() {
        for fields in [
            [i64::MIN, 0, 0, 0],
            [i64::MAX, 0, 0, 0],
            [24, 0, 0, 0],
            [0, -1, 0, 0],
            [0, 60, 0, 0],
            [0, 0, -1, 0],
            [0, 0, 60, 0],
            [0, 0, 0, -1],
            [0, 0, 0, 1_000_000],
            [0, 0, 0, i64::MAX],
        ] {
            assert!(format_time(fields[0], fields[1], fields[2], fields[3], "hours").is_none());
        }
        for spec in ["", "Auto", "nanoseconds", "秒", "seconds\0"] {
            assert!(format_time(1, 2, 3, 4, spec).is_none());
        }
    }
}

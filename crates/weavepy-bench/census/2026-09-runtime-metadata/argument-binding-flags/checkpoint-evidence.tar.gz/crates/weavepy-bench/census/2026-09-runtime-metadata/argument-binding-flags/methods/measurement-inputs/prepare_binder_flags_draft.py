"""Prepare, but don't apply, an inline small-signature binding flag draft."""
import difflib,hashlib,json
from pathlib import Path
p=Path('crates/weavepy-vm/src/lib.rs');s=p.read_text()
old='''        let mut filled = vec![false; code.varnames.len()];'''
new='''        // Only argument slots need binding flags; body locals cannot be
        // supplied by keyword. Keep common signatures inline and retain a
        // heap fallback for arbitrary parameter counts.
        let flag_count = kwonly_end + usize::from(has_varargs) + usize::from(kwargs_slot.is_some());
        let mut inline_filled = [false; 16];
        let mut heap_filled;
        let filled: &mut [bool] = if flag_count <= inline_filled.len() {
            &mut inline_filled[..flag_count]
        } else {
            heap_filled = vec![false; flag_count];
            &mut heap_filled
        };'''
assert s.count(old)==1
n=s.replace(old,new)
root=Path('target/argument-binder-flags-draft');root.mkdir()
(root/'lib.rs').write_text(n)
(root/'candidate.patch').write_text(''.join(difflib.unified_diff(s.splitlines(True),n.splitlines(True),fromfile='a/'+str(p),tofile='b/'+str(p))))
(root/'index.json').write_text(json.dumps({'status':'Unapplied, uncompiled, unvalidated, unmeasured.','source':str(p),'base_sha256':hashlib.sha256(s.encode()).hexdigest(),'draft_sha256':hashlib.sha256(n.encode()).hexdigest()},indent=2)+'\n')

"""Preserve clone prototypes, complete isolated comparisons, and overlap diagnostics."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

subprocess.run(['python3.14', 'target/verify_compact_arc_clone_ready.py'], check=True)
base = Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out = base / 'compact-arc-clone'
assert not out.exists()
def sha(data): return hashlib.sha256(data).hexdigest()
for name, digest in json.loads(Path('target/compact-arc-clone-corrected-methods.json').read_text()).items():
    assert sha(Path(name).read_bytes()) == digest, name
valid = ['focused-previous', 'full-previous-isolated', 'focused-retained-isolated', 'full-retained-isolated']
for label in valid:
    gate = json.loads(Path(f'target/compact-arc-clone-{label}-load.json').read_text())
    assert gate['status'] == 'complete' and gate['returncode'] == 0
    assert Path(f'target/compact-arc-clone-{label}/stage.txt').read_text().strip() == 'done'
out.mkdir()
index = []
destinations = set()
def add(source, relative):
    source = Path(source); raw = source.read_bytes(); data = raw; relative = Path(relative)
    if len(raw) > 32768 and source.suffix in {'.json', '.jsonl', '.txt', '.rs', '.diff', '.s'}:
        data = gzip.compress(raw, mtime=0); relative = Path(str(relative) + '.gz')
    assert str(relative) not in destinations, relative
    destinations.add(str(relative)); dest = out / relative
    dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(data)
    index.append({'path':str(relative),'source':str(source),'bytes':len(data),'sha256':sha(data),
                  'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(raw)})
def tree(source, prefix, exclude=()):
    for path in sorted(Path(source).rglob('*')):
        rel = path.relative_to(source)
        if path.is_file() and not any(part in exclude for part in rel.parts): add(path, Path(prefix) / rel)
tree('target/compact-arc-clone-source-snapshot', 'candidate')
for label in valid:
    tree(f'target/compact-arc-clone-{label}', label, ['frozen', 'startup'])
for label in ['full-previous', 'focused-retained']:
    tree(f'target/compact-arc-clone-{label}', 'overlap-diagnostics/' + label, ['frozen', 'startup'])
for group in ['checks', 'validation', 'extra-checks', 'preimages']:
    tree(f'target/compact-arc-clone-{group}', group, ['frozen'])
for path in sorted(Path('target').glob('compact-arc-clone*')):
    if path.is_file() and path.name != 'compact-arc-clone-export.txt': add(path, Path('development') / path.name)
for name in ['compact-arc-clone-prototype', 'compact-arc-clone-prototype-v2', 'compact-arc-clone-integrated-api']:
    tree(Path('target') / name / 'src', 'development/' + name + '/src')
    for file in ['Cargo.toml', 'Cargo.lock']: add(Path('target') / name / file, Path('development') / name / file)
for name in ['performance_phase71_status.md', 'prepare_compact_arc_clone_methods.py', 'export_compact_arc_clone.py', 'run_serial_performance_gate.py']:
    add(Path('target') / name, Path('development') / name)
for name in json.loads(Path('target/compact-arc-clone-prebuild.json').read_text())['methods']:
    add(name, Path('methods/original') / name)
for name in json.loads(Path('target/compact-arc-clone-corrected-methods.json').read_text()):
    add(name, Path('methods/correction') / name)

full = {ref:json.loads(Path(f'target/compact-arc-clone-full-{ref}-isolated/summary.json').read_text()) for ref in ['previous', 'retained']}
focused = {'previous':json.loads(Path('target/compact-arc-clone-focused-previous/summary.json').read_text()),
           'retained':json.loads(Path('target/compact-arc-clone-focused-retained-isolated/summary.json').read_text())}
lines = ['# Direct cloning of compact metadata', '',
    'Decision: deferred. Neither this clone refinement nor the preceding packed-',
    'owner trial improves on the retained bf2 implementation overall. Return the',
    'active runtime to bf2 after preserving this complete record. The user goal',
    'remains unachieved.', '',
    'Candidate: `75ea4029cf0b323ab53dfb7015485bfa2803b039779db62ba433fc9332972eb2`,',
    '44,317,952 bytes. Direct reference is 65ff (packed owners); retained reference',
    'is bf2 (thin owners). Full executable identities are in the snapshots.', '',
    'Only shared_value.rs changes from 65ff. Ordinary clones increment the standard',
    'Arc count and copy the existing pointer and metadata. An outlined cold helper',
    'retains the exceptional boxed-owner behavior. Allocation, tuple, weak-owner,',
    'and actual VM layout sizes remain unchanged. Object is still 16 bytes.', '',
    'Both preliminary prototypes passed eight ordinary tests, eight strict Miri',
    'tests on each of ARM64 and i686, and clippy. The first direct-copy prototype',
    'kept its modeled 64-byte clone-wrapper frame; outlining the exceptional path',
    'removed that frame from the ordinary standalone wrapper. Those are code-',
    'generation observations, not runtime speed measurements.', '',
    'Integrated validation passed 355 VM tests, 156 C API tests, strict lint and',
    'format, a no-JIT check, all 87 targeted Python checks, and all 275 outside-',
    'sandbox compatibility checks. Optional extension tests may check availability',
    'internally. Bytes/codecs/four additional C API suites passed. Marshal retains',
    'the same four exactly graded divergences against 65ff, not a clean pass.',
    'Exact storage modules passed 16 strict-provenance Miri tests on both ARM64',
    'and i686 with Object/CachedHash stubs. This is not whole-VM Miri validation.', '',
    'The observed release build took 4m02s, not a controlled build-time result.',
    'All 339 source hashes and 77 original method/input hashes remained unchanged;',
    'the added measurement-controller correction is hashed separately.', '',
    '## Measurement correction', '',
    'The first focused run against 65ff completed in isolation. A later scheduling',
    'error started the retained-reference focused stage while the direct-reference',
    'full stage was still running. The attempted early stop found that a child',
    'had already launched; the overlapping owned process tree was then stopped',
    'with exit 143. No unrelated process was stopped. The original full run was',
    'allowed to finish. Preserve both affected runs under overlap-diagnostics;',
    'neither is an isolated headline comparison. No samples were removed.', '',
    'The interrupted raw gate still reports running because its controller was',
    'terminated. The incident record supplies terminal context, process IDs, and',
    'timestamps. This stale JSON state does not mean a process is still active.', '',
    'Before inspecting the affected full-run summary, the correction declared',
    'fresh complete replacements due to the protocol violation, independent of',
    'outcome. A new exclusive file lock and older-process check prevent overlapping',
    'stages; a contention check rejected a second launch before creating any gate.',
    'The corrected full-previous, focused-retained, and full-retained runs finished',
    'sequentially in fresh isolated directories. The original source, inputs,',
    'samplers, cache rules, and sample counts did not change. All original and',
    'replacement samples, failures, and load observations remain.', '',
    '## Isolated results', '',
    'Ratios below 1 favor the candidate. Means use per-fixture medians of paired',
    'ratios; keep the 21-, 23-, and 24-row cohorts distinct. These comparisons',
    'provide no new direct comparison with ed99.', '',
    '| Reference | Work / reference (23) | Work / CPython (23) | Wall / reference (24) | CPU / reference (24) | RSS / reference (24) | RSS / CPython (24) |',
    '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for ref in ['previous', 'retained']:
    cohorts=full[ref]['cohorts']; w=cohorts['all_23_workloads_excluding_startup']['metrics']['jit']['ns']; m=cohorts['all_processes_including_startup']['metrics']['jit']
    lines.append(f"| {ref} | {w['new_over_base']:.9f} | {w['new_over_cpython']:.9f} | {m['wall_ns']['new_over_base']:.9f} | {m['cpu_ns']['new_over_base']:.9f} | {m['rss_bytes']['new_over_base']:.9f} | {m['rss_bytes']['new_over_cpython']:.9f} |")
lines += ['', 'Both full runs retain six JIT workload wins against CPython and zero RSS',
    'wins. Against bf2, all 24 JIT peak-RSS medians regress. Shared string/bytes/',
    'tuple populations remain about 10-11% slower in all seven JIT pairs. Repeated',
    'shared calls and string dictionary lookups also regress in every pair.',
    'The nine-byte allocation memory gain remains, but it does not compensate',
    'for the broader losses. All interpreter and per-fixture results remain in',
    'the summaries and raw measurements.', '',
    '| Focused control | Time / 65ff | RSS / 65ff | Time / bf2 | RSS / bf2 |',
    '| --- | ---: | ---: | ---: | ---: |']
for name,row in focused['previous']['rows'].items():
    p=row['new_over_previous']['jit'];r=focused['retained']['rows'][name]['new_over_previous']['jit']
    lines.append(f"| {name} | {p['ns']:.6f} | {p['rss_bytes']:.6f} | {r['ns']:.6f} | {r['rss_bytes']:.6f} |")
lines += ['', 'Large text/JSON artifacts are losslessly compressed. index.json identifies',
    'both stored and original bytes. Source snapshots, prototypes, assembly, methods,',
    'inputs, validation, incident records, and all timing outcomes are preserved.',
    'Comparison executables and frozen caches stay local. Earlier status notes',
    'record intermediate states; this report gives the completed decision.', '',
    'No universal, energy, controlled build-time, portability, or native parallel-',
    'scaling conclusion follows from these measurements.', '']
data='\n'.join(lines).encode();(out/'REPORT.md').write_bytes(data)
index.append({'path':'REPORT.md','bytes':len(data),'sha256':sha(data)})
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n')
for row in index:
    data=(out/row['path']).read_bytes();assert sha(data)==row['sha256']
    if 'uncompressed_sha256' in row:
        raw=gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert sha(raw)==row['uncompressed_sha256']
allow={'!compact-arc-clone/'}
for path in out.rglob('*'): allow.add('!'+str(path.relative_to(base))+('/' if path.is_dir() else ''))
with (base/'.gitignore').open('a') as f: f.write('\n# Deferred clone trial and complete overlap correction.\n'+'\n'.join(sorted(allow))+'\n')
with (base/'README.md').open('a') as f:
    f.write('\nThe [compact-owner clone follow-up](compact-arc-clone/REPORT.md) retains\nfocused gains, broader regressions, and a transparent correction of overlapping\nmeasurement stages. Both packed-owner trials are deferred in favor of bf2.\n')
print('Archived',len(index)+1,'files;',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes. All hashes verified.')

"""Preserve the complete narrower native-entry experiment with all regressions."""
import hashlib,json
from pathlib import Path
parent=Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out=parent/'bound-native-entry-early-exclusions'
assert not out.exists()
for group in ['focused','full']:
    assert Path('target/early-bound-entry-'+group+'/stage.txt').read_text().strip()=='done'
    assert json.loads(Path('target/early-bound-entry-'+group+'-load.json').read_text())['status']=='complete'
focused=json.loads(Path('target/early-bound-entry-focused/summary.json').read_text())
full=json.loads(Path('target/early-bound-entry-full/summary.json').read_text())
out.mkdir();records=[]
def copy(src,dst):
    src=Path(src);p=out/dst;p.parent.mkdir(parents=True,exist_ok=True)
    b=src.read_bytes();p.write_bytes(b);records.append({'path':str(dst),'source':str(src),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
def folder(src,dst):
    for p in sorted(Path(src).iterdir()):
        if p.is_file() and p.suffix in ['.json','.txt','.py','.sh','.md','.patch']:
            copy(p,str(Path(dst)/p.name))
for group in ['full','focused']:
    folder('target/early-bound-entry-'+group,group)
for group in ['calls','exceptions','cold-exceptions']:
    copy('target/early-bound-entry-focused/'+group+'/measurements.json','focused/'+group+'.json')
for group in ['checks','validation','extra-checks','coverage','call-assembly']:
    folder('target/early-bound-entry-'+group,'checks/'+group)
folder('target/early-bound-entry-measurement-inputs','methods/frozen-methods')
for p in sorted(Path('target').glob('early-bound-entry-*.txt')):copy(p,'logs/'+p.name)
for name in ['early-bound-entry-focused-load.json','early-bound-entry-full-load.json','early-bound-entry-prebuild-sources.json','performance_phase62_status.md']:
    copy('target/'+name,'conditions/'+name)
for name in ['environment.json','source-changes.diff','tests/regrtest/test_bound_native_entry.py']:
    copy('target/early-bound-entry-source-snapshot/'+name,'candidate/'+name)
for name in ['candidate.patch','index.json']:
    copy('target/early-bound-entry-draft/'+name,'draft/'+name)
for p in sorted(Path('target/bound-native-entry-inputs').rglob('*')):
    if p.is_file() and p.suffix in ['.py','.json','.md']:
        copy(p,'inputs/'+str(p.relative_to('target/bound-native-entry-inputs')))
copy(__file__,'methods/'+Path(__file__).name)
work=full['cohorts']['all_23_workloads_excluding_startup']['metrics']['jit']['ns']
hist=full['cohorts']['historical_21_including_startup']['metrics']['jit']
process=full['cohorts']['all_processes_including_startup']['metrics']['jit']
lines=['# Earlier exclusions for post-binding native entry','','Status: **under refinement**. The performance goal remains unachieved.','',
'Candidate 95b52f65 moves existing bound-signature and live-closure exclusions',
'before other code flags and omits two code-cell checks already enforced by',
'the memoized native-entry eligibility check. Generator families still take',
'the frame path. Native guards, lanes, observers, pending work, and recursion',
'checks remain active. No new cache, field, allocation, or unsafe code is added.',
'The release is 44,290,720 bytes, the same as ca6b and 160 more than retained 539c.','',
'All 342 VM tests, formatting, Clippy, the build without default features, 60',
'targeted release checks, all 275 standard compatibility checks, five extra',
'call/inspection/copy suites, and ten CPython/native-coverage cases pass. The',
'full VM run includes the corrected framed-plus-direct coverage assertion.',
'Instrumented traces still establish entry-path coverage, not allocation counts.','',
'The 18 focused cases retain seven paired samples for every variant. The run',
'met its load precondition, but one-minute load subsequently rose above five.',
'Paired timing ranges are wide in both execution modes. The result does not',
'establish that reordering the guards fixes the earlier fallback regressions.',
'All values and frozen caches passed. No sample was filtered or repeated.','',
'The table reports JIT workload time and CPU relative to retained 539c. Lower',
'is better. Every paired value, range, execution mode, process metric, and',
'CPython comparison remains in focused/summary.json. Cold cases lack a separate',
'workload CPU timer; their process CPU measurements remain in the raw data.','',
'| Case | Workload time / 539c | Workload CPU / 539c | Improved time pairs |',
'| --- | ---: | ---: | ---: |']
for name,r in focused['rows'].items():
    j=r['new_over_previous']['jit'];cpu=f"{j['work_cpu_ns']:.4f}" if 'work_cpu_ns' in j else 'n/a'
    lines.append(f"| {name} | {j['ns']:.4f} | {cpu} | {r['pairs']['jit']['ns']['improved_pairs']}/7 |")
lines += ['',
'The full census includes all 24 unchanged fixtures with five pairs and nine',
'startup/import controls with 31 pairs. The startup helper disables JIT. The',
'full load record and VM/swap observations are preserved. Meeting the initial',
'load limit does not imply an otherwise idle host throughout the run.','',
f"The 23-workload JIT geometric mean is {work['new_over_base']:.6f} relative to",
f"539c and {work['new_over_cpython']:.6f} relative to CPython, with",
f"{work['weavepy_wins']} of 23 CPython time wins. The same historical 21-fixture cohort",
f"is {hist['ns']['new_over_cpython']:.6f}, or {hist['ratio_of_medians_new_over_cpython']:.6f} using ratios",
'of medians. These different cohorts must remain separate.','',
f"All-24 process wall/CPU/RSS ratios to 539c are {process['wall_ns']['new_over_base']:.6f},",
f"{process['cpu_ns']['new_over_base']:.6f}, and {process['rss_bytes']['new_over_base']:.6f}. Peak RSS is",
f"{process['rss_bytes']['new_over_cpython']:.6f} times CPython, with {process['rss_bytes']['weavepy_wins']} wins.",'',
'Generated-code inspection finds a 0x650-byte stack reservation after a 0x60-byte',
'register save in call_python_owned. That is 16 bytes less than ca6b and 96 bytes',
'less than 539c. This is a layout observation, not a timing explanation.','',
'All selected artifacts are SHA-256 indexed. Executables, frozen caches, and',
'unselected intermediate outputs remain local and outside Git. These results',
'do not establish energy, controlled build-time, portability, or free-threaded',
'superiority. The separate argument-binder storage draft remains unvalidated',
'until a later candidate is explicitly built and measured.','']
(out/'REPORT.md').write_text('\n'.join(lines));p=out/'REPORT.md'
records.append({'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'index.json').write_text(json.dumps(records,indent=2)+'\n')
for r in records:assert hashlib.sha256((out/r['path']).read_bytes()).hexdigest()==r['sha256']
with (parent/'.gitignore').open('a') as f:
    f.write('\n# Narrower post-binding exclusions and all measured regressions.\n')
    for p in sorted(out.rglob('*')):
        if p.is_file():f.write('!'+str(p.relative_to(parent))+'\n')
with (parent/'README.md').open('a') as f:
    f.write('\nThe [earlier native-entry exclusions](bound-native-entry-early-exclusions/REPORT.md)\npass the full correctness gate, but focused timing has wide dispersion and\nretains fallback regressions. The complete focused and full measurements are\narchived. This refinement does not establish that the regressions are fixed.\n')
print('Exported',len(records)+1,'files;',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes; every indexed SHA verified.')

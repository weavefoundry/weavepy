#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-ascii-time-format
binary=target/release/weavepy-runtime-native-unobserved-shell
test ! -e "$binary"
test ! -e target/native-unobserved-shell-build-stage.txt
cargo fmt --all -- --check > target/native-unobserved-shell-format.txt 2>&1
python3.14 target/freeze_native_unobserved_shell_sources.py
printf 'release build\n' > target/native-unobserved-shell-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/native-unobserved-shell-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/native-unobserved-shell-source-snapshot --extra target/build_native_unobserved_shell.sh target/check_native_unobserved_shell.sh target/validate_native_unobserved_shell.sh target/measure_native_unobserved_shell_focused.sh target/measure_native_unobserved_shell_full.sh target/measure_verified_python_components.py target/native-unobserved-shell-protocol.md target/verify_native_unobserved_shell_ready.py target/freeze_native_unobserved_shell_sources.py target/summarize_native_unobserved_shell.py > target/native-unobserved-shell-snapshot.txt 2>&1
printf 'done\n' > target/native-unobserved-shell-build-stage.txt

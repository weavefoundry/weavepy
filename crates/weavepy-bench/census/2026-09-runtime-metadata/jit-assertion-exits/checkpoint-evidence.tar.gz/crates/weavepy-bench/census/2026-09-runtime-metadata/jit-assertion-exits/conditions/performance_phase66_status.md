# JIT assertion and common-exception exits

The compact intern-pool experiment finished and was archived in 194 selected
files, 702,685 bytes, with all stored and uncompressed hashes verified. It
improves focused intern/marshal and memory controls but retains small full-suite
time regressions. Its a1e87c1a binary is the immediate predecessor for this
independent JIT experiment; retained 539c is a second focused reference.

53961 CLOSED 0: all 17 new benchmark controls agree with CPython before/after
warmup on unchanged a1e87c1a in JIT, interpreter, and gil=0 modes. The v1 Python
semantic test passed all four variants. A separately preserved v2 adds real
bytecode for canonical NotImplementedError, and also passes all four variants.
These baseline checks do not establish candidate validity or performance.

Three draft source changes were applied by exact before/after hashes. Only
common AssertionError and NotImplementedError constants become exact-PC Deopt
terminators; their following message/construction blocks aren't native successors.
Other common constants retain existing analysis. Existing plain-stack checks,
None materialization, spill/writeback, and marker-free call-span exclusion apply.
No new runtime helper, object field, cache, unsafe code, or execution policy.
The new v2 regression is tests/regrtest/test_jit_assertion_exits.py. The original
intern-pool runtime changes remain intact and separately attributed.

Sources were formatted and 147 source/test hashes plus 19 methods frozen before
building. Full JIT/VM/static tests and the correct CLI release build are next.
Require 69 targeted release checks, six extra suites, standard compatibility,
and actual compile/rebuild coverage for six assertion functions before timing.
No candidate executable or performance claim exists yet.

All 58 JIT tests PASS, including the two new analyzer cases; all 342 VM tests PASS (36.53s observed). Formatting, Clippy, and no-default-feature checks pass. Release build is running. A separate untimed datetime path-inspection method is frozen before its future use; no source or original active method changes. No candidate timing yet.

94152 CLOSED 0: release built in observed 4m07s, not a controlled build metric. Candidate ed99cdbaf8e403eb7de9e3cbac86687748481596443b0e5055a77057c57a0a29 is 44,289,520 bytes, unchanged from a1e87c1a. All 147 source/test and 19 method hashes, snapshot files, and binary identity verified. Native coverage completed successfully: all six targeted assertion functions compile and rebuild their error continuations with exact CPython-equivalent semantics. Targeted and extra release suites are running. No timing yet.

87434 CLOSED 0: all 69 targeted release checks passed. 31402 CLOSED 0, but manual discovery audit found that only the five original extra suites selected tests; the added submodule filter selected ZERO modules. Its zero status is not a passing assertion suite. Original report/method preserved. A separate nonempty-discovery check now runs the unittest package and the v2 focused launcher additionally requires that check to pass; the original focused launcher must not be used. No timing had started. The original 19 and corrected 23 methods are frozen separately. Standard compatibility is running. Untimed datetime values match CPython; compiled functions rise 24 to 26 (_cmp and _find_isoformat_datetime_separator), but _ymd2ord remains blocked by other analysis constraints. No performance gain inferred from counts.

54664 CLOSED 0: corrected discovery ran one passing unittest package (about 12s observed); original five nonempty extra suites verified. The zero-test submodule result is retained and not counted. A separate two-file integer-comparison draft is prepared but UNAPPLIED: it reuses existing exact-Int UnboxInt guards at COMPARE_OP for one opaque operand with an integral peer. No new helper or unsafe code, no test/performance result. Its source copies include current assertion exits and must not be applied until this experiment is finished and archived.

90983 CLOSED 0: all 275 standard compatibility checks passed. Corrected extra discovery and all six-function native coverage assertions pass. All 147 source/test, original 19-method, and corrected 23-method hashes remain exact. No owned build, test, or profile jobs remain. Focused 17-control timing is launching under the strict load gate using ONLY measure_jit_assertion_exits_focused_v2.sh. A separate future comparison-guard semantic preflight passed CPython and unchanged ed99 in three modes, but its implementation remains unapplied.

26443 CLOSED 0: focused gate qualified and completed in 103.9s. All 17 controls, seven pairs, values, and frozen caches verified. Integer/float/chain success JIT time ratios to a1e are .158713/.155029/.147878; warm error-burst recovery is .430137. All focused JIT workload medians improve, but several peak-RSS medians increase (float assertion 1.012582); no focused CPython time or RSS win. Interpreter weekday 1.000894 and cold always-failure 1.000081 retain small time regressions. Full 24-fixture/31-pair startup run launched in session 64467 under its separate strict gate. Runtime and active methods unchanged.

64467 CLOSED 0: full strict gate qualified at observation 2; all samples retained, including later one-minute load up to 4.8179. Completed in 337.19s; end load 2.6904/2.7588/2.6108. All 147 source and 19/23 method hashes and ed99 binary identity verified. Full 23-workload JIT new/base .997565067, new/CPython 3.398282316, 6/23 wins; historical 21 paired 2.100195620 (ratio of medians 2.101746198). All-24 process wall/CPU/RSS new/base .998465675/.996697269/1.001719238; RSS/CPython 2.062068206, zero wins. Interpreter work/base .982894250 and RSS/base 1.002151981. Broad memory and individual time regressions remain.
jit ns regressions: {'fib': 1.0053984894314538, 'pidigits': 1.0012479405257078, 'nested_loops': 1.1340055808298053, 'float_math': 1.0027306546192334, 'str_methods': 1.0037827240056285, 'pickle_bench': 1.0005987774849643}
jit rss_bytes regressions: {'fannkuch': 1.0072222222222222, 'fib': 1.0088544548976204, 'richards': 1.0033076074972436, 'sumvm': 1.0022099447513813, 'nested_loops': 1.00109829763866, 'jitloop': 1.0021953896816684, 'float_math': 1.0006107802717972, 'spectral_norm': 1.001086956521739, 'json_bench': 1.0016319869441044, 'list_ops': 1.0027808676307008, 'generators': 1.0038377192982457, 'deque_ops': 1.0006901311249137, 'datetime_ops': 1.0166666666666666, 'startup': 1.0033426183844012}
interp ns regressions: {'fannkuch': 1.012924739001464, 'pidigits': 1.000489715055797, 'richards': 1.014159235924262}
interp rss_bytes regressions: {'fannkuch': 1.0047846889952152, 'nbody': 1.0017910447761194, 'fib': 1.0036014405762306, 'pyaes': 1.0005988023952095, 'richards': 1.0029850746268656, 'sumvm': 1.0023966446974235, 'nested_loops': 1.0066105769230769, 'jitloop': 1.0048019207683074, 'jitkernels': 1.0029815146094216, 'float_math': 1.0006262721152341, 'spectral_norm': 1.00238379022646, 'json_bench': 1.0053956834532374, 'str_methods': 1.0005991611743559, 'dict_ops': 1.0035693039857227, 'list_ops': 1.0077751196172249, 'attr_access': 1.0017910447761194, 'call_overhead': 1.0041816009557945, 'generators': 1.0017942583732058, 'deque_ops': 1.000365096750639, 'startup': 1.0072202166064983}

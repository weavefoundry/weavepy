"""Measure warm startup with isolated caches and explicit filename relocation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import shutil
import statistics
import subprocess
import sys
import tempfile
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--base', required=True)
p.add_argument('--new', required=True)
p.add_argument('--previous')
p.add_argument('--out', type=Path, required=True)
p.add_argument('--samples', type=int, default=31)
a = p.parse_args()
assert a.samples > 0 and not a.out.exists()
root = a.out.with_suffix('')
assert not root.exists()
root.mkdir(parents=True)
bench = runpy.run_path('tools/bench_compare.py')
report = {'purpose': __doc__, 'execution_context': bench['execution_context'](),
          'samples': a.samples, 'jit': False, 'binaries': {}, 'preparation': {}, 'rows': {}}
assert report['execution_context']['declared_launch_context'] == 'outside-tool-filesystem-sandbox (require_escalated)'
variants = []
inputs = [('base', a.base), ('neww', a.new)]
if a.previous:
    inputs.insert(1, ('prev', a.previous))
for label, original in inputs:
    binary = root / 'bin' / label / 'weavepy'
    binary.parent.mkdir(parents=True)
    shutil.copy2(original, binary)
    binary = binary.resolve()
    report['binaries'][label] = {'path': str(binary), 'original': original,
                               'sha256': hashlib.sha256(binary.read_bytes()).hexdigest()}
    variants.append((label, str(binary)))
variants.append(('cpython', shutil.which('python3.14')))
report['binaries']['cpython'] = {'path': str(Path(variants[-1][1]).resolve()),
                               'sha256': hashlib.sha256(Path(variants[-1][1]).read_bytes()).hexdigest()}

def environment(label, condition, preparation=False):
    env = dict(os.environ)
    env.pop('WEAVEPY_JIT', None)
    if label != 'cpython':
        env['WEAVEPY_JIT'] = '0'
        location = 'seedx' if condition == 'reloc' and preparation else condition
        env['WEAVEPY_STDLIB_CACHE'] = str((root / 'stdlib' / label / location).resolve())
        env['WEAVEPY_FROZEN_CACHE'] = str((root / 'frozen' / label / condition).resolve())
    return env

probe = '''import os, sys, json, datetime, collections, pathlib, pickle
assert os.path.isdir(sys._stdlib_dir)
print(sys._stdlib_dir)
'''
for label, binary in variants[:-1]:
    report['preparation'][label] = {}
    for condition in ['match', 'reloc']:
        # Populate the target stdlib tree without populating its frozen-code
        # cache, then write code artifacts at either the matching or old path.
        target_env = environment(label, condition)
        staging = dict(target_env, WEAVEPY_FROZEN_CACHE='0')
        target = subprocess.check_output([binary, '-S', '-c',
            'import sys; print(sys._stdlib_dir)'], env=staging, text=True, timeout=120).strip()
        prepared = subprocess.check_output([binary, '-c', probe],
            env=environment(label, condition, preparation=True), text=True, timeout=120).strip()
        assert Path(target).is_relative_to(target_env['WEAVEPY_STDLIB_CACHE'])
        assert (target == prepared) == (condition == 'match')
        report['preparation'][label][condition] = {'target_stdlib': target, 'artifact_stdlib': prepared,
                                                  'environment': {k: v for k, v in target_env.items() if k.startswith('WEAVEPY_')}}

def artifacts():
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((root / 'frozen').rglob('*')) if p.is_file()}

# Verify serialized root filenames as well as the chosen cache directories.
for label, binary in variants[:-1]:
    for condition in ['match', 'reloc']:
        env = environment(label, condition, preparation=True)
        frozen_root = Path(env['WEAVEPY_FROZEN_CACHE'])
        source = f"""import json, marshal, os
root = {str(frozen_root)!r}
rows = {{}}
for directory, _, names in os.walk(root):
    for name in names:
        path = os.path.join(directory, name)
        with open(path, 'rb') as f:
            data = f.read()
        assert data[:4] == b'WPYF'
        rows[name] = marshal.loads(data[20:]).co_filename
print(json.dumps(rows, sort_keys=True))
"""
        filenames = json.loads(subprocess.check_output([binary, '-S', '-c', source],
            env=dict(env, WEAVEPY_FROZEN_CACHE='0'), text=True, timeout=120))
        assert filenames
        expected = report['preparation'][label][condition]['artifact_stdlib']
        assert all(Path(v).is_relative_to(expected) for v in filenames.values()), filenames
        report['preparation'][label][condition]['artifact_filenames'] = filenames

report['frozen_before'] = artifacts()
cases = {
    'startup_matched': ('match', [], 'pass'),
    'startup_relocated': ('reloc', [], 'pass'),
    'no_site_matched': ('match', ['-S'], 'pass'),
    'imports_matched': ('match', [], 'import json, datetime, collections, pathlib'),
    'imports_relocated': ('reloc', [], 'import json, datetime, collections, pathlib'),
    'pickle_import_matched': ('match', [], 'import pickle'),
    'pickle_import_relocated': ('reloc', [], 'import pickle'),
    'accelerator_first_matched': ('match', [], 'import _pickle; import pickle'),
    'accelerator_first_relocated': ('reloc', [], 'import _pickle; import pickle'),
}
for name, (condition, flags, source) in cases.items():
    row = {'condition': condition, 'flags': flags, 'source': source, 'samples': {label: [] for label, _ in variants}}
    report['rows'][name] = row
    for cycle in range(a.samples + 1):
        for label, binary in variants if cycle % 2 == 0 else reversed(variants):
            env = environment(label, condition)
            with tempfile.TemporaryFile() as output:
                started = time.perf_counter_ns()
                child = subprocess.Popen([binary, *flags, '-c', source], env=env,
                    stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT)
                _, status, usage = os.wait4(child.pid, 0)
                elapsed = time.perf_counter_ns() - started
                child.returncode = os.waitstatus_to_exitcode(status)
                output.seek(0)
                text = output.read().decode(errors='replace')
            assert child.returncode == 0, (name, label, text)
            sample = {'wall_ns': elapsed, 'cpu_ns': round((usage.ru_utime + usage.ru_stime) * 1e9),
                      'rss_bytes': usage.ru_maxrss * (1 if sys.platform == 'darwin' else 1024)}
            if cycle:
                row['samples'][label].append(sample)
    row['medians'] = {label: {key: statistics.median(s[key] for s in values)
                            for key in values[0]} for label, values in row['samples'].items()}
    row['comparisons'] = {label: bench['relative_metrics'](row['samples']['neww'], row['samples'][label])
                          for label, _ in variants if label != 'neww'}
    a.out.write_text(json.dumps(report, indent=2) + '\n')
    print(name, row['comparisons'], flush=True)
report['frozen_after'] = artifacts()
report['frozen_unchanged'] = report['frozen_before'] == report['frozen_after']
a.out.write_text(json.dumps(report, indent=2) + '\n')
assert report['frozen_unchanged'], 'Timed imports must use the prepared frozen artifacts'

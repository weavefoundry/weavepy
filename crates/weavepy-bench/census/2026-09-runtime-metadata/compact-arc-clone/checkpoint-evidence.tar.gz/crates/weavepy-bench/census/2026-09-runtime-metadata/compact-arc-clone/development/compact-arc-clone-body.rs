        if self.metadata == INDIRECT {
            return Self::from_arc(Arc::clone(&self.arc_view()));
        }
        // SAFETY: this live owner already holds one strong Arc reference.
        // Increment it for the new owner, preserving the original pointee and
        // its metadata. Arc performs the same overflow check as Arc::clone.
        unsafe { Arc::increment_strong_count(self.raw()) };
        Self {
            data: self.data,
            metadata: self.metadata,
            ownership: PhantomData,
        }

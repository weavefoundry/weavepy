# Fuse integer call results into comparisons

The unfused e709 comparison candidate must finish and be archived first. It
improves simple controls but loses 12.5 percent warm and 15.1 percent cold with
a complex interpreter callback and no rich-comparison misses. Its full workload
mean regresses 0.27 percent and peak RSS regresses 0.18 percent versus ed99.
Those observations remain preserved; this is an independent refinement.

Reuse the existing exact-integer CallDyn result path for a comparison immediately
after a call, or separated only by one non-guarding scalar constant. General
operand loads keep their COMPARE_OP guard. Misses and invalidated globals park
the completed value and resume after the producer; callback effects are never
repeated. No runtime helper, object field, pin lifetime, cache, unsafe code, or
execution policy changes. The v2 draft corrects opcode variant spelling before
compilation; the original unapplied draft remains preserved.

Baseline semantic checks must pass CPython and unchanged e709 in three modes.
The 19 existing focused inputs retain exact source/work bytes and already pass
all value checks on both baselines. Add keyword, bool-constant, global mutation,
unfused local-operand, callback exception, identity, and tracing coverage. Require
all JIT/VM/static checks, the correct release CLI build, 75 targeted release
checks, standard compatibility, six nonempty extra suites, and real compile/
rebuild coverage for all 23 established/new comparison functions.

Focused measurements retain 15 warm and four cold inputs at work 5000 with seven
pairs of both modes of candidate, immediate e709, retained ed99, and CPython.
This directly measures the unfused regression and the combined change against
the preceding assertion build. Full measurement uses ed99 as baseline, with
24 unchanged fixtures at five pairs and nine startup/import cases at 31 pairs.
The startup helper disables JIT. GIL-disabled runs are correctness checks only.

Use separate timing gates requiring three ten-second observations with one- and
five-minute load averages at most 4, up to 600 seconds. Preserve no-child gate
expirations before declaring any diagnostic. No owned builds, tests, profiles,
installs, runtime edits, or active method edits once a timing gate can launch.
Keep every sample, value, cache check, regression, workload/process wall and CPU
metric, RSS, source/method/binary hash, and VM/swap/load observation. Keep the
21/23/24 cohorts distinct; only same-run pairs support attribution. The overall
goal remains unachieved. No universal, energy, controlled build-time, portability,
or native parallel performance superiority is established.

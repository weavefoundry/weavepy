"""Compare untimed datetime JIT paths and exact outputs after assertion exits."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess

root = Path("target/jit-assertion-exits-datetime-paths")
root.mkdir()
source = Path("crates/weavepy-bench/fixtures/datetime_ops.py")
driver = root / "driver.py"
driver.write_text(source.read_text().split('if __name__ == "__main__":')[0] + "\nfor _ in range(4):\n    print(bench(200))\n")
report = {"purpose": __doc__, "timed_samples": 0, "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
          "driver_sha256": hashlib.sha256(driver.read_bytes()).hexdigest(), "work": 200, "calls": 4, "rows": {}}
for label, binary in [("cpython", shutil.which("python3.14")), ("previous", "target/release/weavepy-runtime-compact-intern-pools"), ("new", "target/release/weavepy-runtime-jit-assertion-exits")]:
    digest = hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    env = dict(os.environ, WEAVEPY_JIT="1", WEAVEPY_JIT_TRACE="1", WEAVEPY_VM_STATS="1",
               WEAVEPY_STDLIB_CACHE=str(Path("target/performance-stdlib-cache").resolve()),
               WEAVEPY_FROZEN_CACHE=str((root / "frozen" / digest).resolve()))
    result = subprocess.run([binary, str(driver)], env=env, text=True, capture_output=True, timeout=180)
    (root / (label + ".trace.txt")).write_text(result.stderr)
    report["rows"][label] = {"binary": binary, "sha256": digest, "returncode": result.returncode, "stdout": result.stdout,
        "trace_sha256": hashlib.sha256(result.stderr.encode()).hexdigest(),
        "compiled": re.findall(r'jit compile "([^"]+)"', result.stderr),
        "rejections": [line for line in result.stderr.splitlines() if line.startswith("jit reject ")],
        "stats": {name: int(value) for name, value in re.findall(r"- ([^\n*]+): \*\*(\d+)\*\*", result.stderr)}}
    (root / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    assert result.returncode == 0, (label, result.stderr)
assert all(row["stdout"] == report["rows"]["cpython"]["stdout"] for row in report["rows"].values())
report["status"] = "values_match"
(root / "report.json").write_text(json.dumps(report, indent=2) + "\n")
for label in ("previous", "new"):
    print(label, "compiled:", report["rows"][label]["compiled"], "stats:", report["rows"][label]["stats"])

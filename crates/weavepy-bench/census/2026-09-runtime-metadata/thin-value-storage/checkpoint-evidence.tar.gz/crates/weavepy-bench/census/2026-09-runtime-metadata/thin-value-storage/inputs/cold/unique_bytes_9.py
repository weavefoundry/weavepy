
def bench(n):
    values = [i.to_bytes(9, 'little') for i in range(n)]
    return [len(values), len(values[0]), len(values[-1]), int.from_bytes(values[-1], 'little')]

if __name__ == '__main__':
    import os, time
    n = int(os.environ['WEAVEPY_BENCH_WORK'])
    start = time.perf_counter_ns()
    cpu = time.process_time_ns()
    result = bench(n)
    cpu_elapsed = time.process_time_ns() - cpu
    elapsed = time.perf_counter_ns() - start
    print('WEAVEPY_BENCH_NS=%d' % elapsed)
    print('WEAVEPY_BENCH_CPU_NS=%d' % cpu_elapsed)

"""Archive every completed comparison and exact candidate inputs, without build caches."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

subprocess.run(['python3.14', 'target/verify_compact_arc_storage_ready.py'], check=True)
base = Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out = base / 'compact-arc-storage'
assert not out.exists()
full = {}
focused = {}
for ref in ['thin', 'wide']:
    for kind in ['focused', 'full']:
        gate = json.loads(Path(f'target/compact-arc-storage-{kind}-{ref}-load.json').read_text())
        assert gate['status'] == 'complete' and gate['returncode'] == 0
        assert Path(f'target/compact-arc-storage-{kind}-{ref}/stage.txt').read_text().strip() == 'done'
    full[ref] = json.loads(Path(f'target/compact-arc-storage-full-{ref}/summary.json').read_text())
    focused[ref] = json.loads(Path(f'target/compact-arc-storage-focused-{ref}/summary.json').read_text())
out.mkdir()
index = []
destinations = set()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def add(path, relative):
    path = Path(path)
    data = path.read_bytes()
    relative = Path(relative)
    raw = data
    if len(data) > 32768 and path.suffix in {'.json', '.jsonl', '.txt', '.rs', '.diff', '.ll'}:
        data = gzip.compress(data, mtime=0)
        relative = Path(str(relative) + '.gz')
    assert str(relative) not in destinations, relative
    destinations.add(str(relative))
    dest = out / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    index.append({'path':str(relative),'source':str(path),'bytes':len(data),'sha256':sha(data),
                  'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(raw)})
def tree(source, prefix, exclude=()):
    for path in sorted(Path(source).rglob('*')):
        rel = path.relative_to(source)
        if path.is_file() and not any(part in exclude for part in rel.parts):
            add(path, Path(prefix) / rel)

tree('target/compact-arc-storage-source-snapshot', 'candidate')
for ref in ['thin', 'wide']:
    for kind in ['focused', 'full']:
        tree(f'target/compact-arc-storage-{kind}-{ref}', f'{kind}-{ref}', ['frozen', 'startup'])
for group in ['checks', 'validation', 'extra-checks']:
    tree(f'target/compact-arc-storage-{group}', group, ['frozen'])
for path in sorted(Path('target').glob('compact-arc-storage*')):
    if path.is_file():
        add(path, Path('development') / path.name)
add('target/compact-arc-storage-preimages/index.json', 'development/preimages/index.json')
for row in json.loads(Path('target/compact-arc-storage-review.json').read_text()):
    add(Path('target/compact-arc-storage-preimages') / row['path'], Path('development/preimages') / row['path'])
tree('target/compact-arc-prototype/src', 'development/prototype/src')
tree('target/compact-arc-storage-integrated-api/src', 'development/integrated-api/src')
for name in ['compact-arc-prototype', 'compact-arc-storage-integrated-api']:
    for file in ['Cargo.toml', 'Cargo.lock']:
        add(Path('target') / name / file, Path('development') / name / file)
for path in sorted(Path('target').glob('compact-arc-prototype-*.txt')):
    add(path, Path('development/prototype') / path.name)
for name in ['packed_value_layout_preflight.rs', 'packed_value_layout_preflight.ll', 'packed_value_layout_build.txt', 'packed_value_layout.json']:
    add(Path('target') / name, Path('development/layout-preflight') / name)
for name in ['performance_phase70_status.md', 'apply_compact_arc_storage.py', 'prepare_compact_arc_storage_methods.py', 'export_compact_arc_storage.py']:
    add(Path('target') / name, Path('development') / name)
for name in json.loads(Path('target/compact-arc-storage-prebuild.json').read_text())['methods']:
    add(name, Path('methods') / name)

lines = ['# Compact metadata beside shared pointers', '',
    'Decision: unfinished candidate under refinement. The packed representation',
    'preserves smaller value slots and removes allocation length headers, but its',
    'first implementation regresses shared-value cloning and broader JIT timing.',
    'It does not achieve the user goal. Preserve both references for the next trial.', '',
    'Candidate: `65ff081f8d85851c247cee8cc9e64bd3ebb1f80d49b617cbd6115ab44141c883`,',
    '44,317,296 bytes. The primary thin-owner reference is bf2; the secondary',
    'wide-owner reference is ed99. Full identities are in the candidate snapshot.', '',
    'Actual ARM64 layout: Object, Option<Object>, and DictKey are 16 bytes;',
    'strong shared owners are 15 bytes. Tuple payloads use 8 + 16*n bytes,',
    'excluding Arc reference counts. These sizes alone are not timing or RSS results.', '',
    'All 355 VM tests passed. The C API run passed 156 tests across 17 groups;',
    'some optional extension tests check availability internally. Strict lint,',
    'format, and no-JIT checks passed. All 87 targeted Python checks and all 275',
    'outside-sandbox compatibility records passed. Extra bytes, codecs, and four',
    'C API suites passed. Marshal retains the same four exactly graded divergences',
    'on candidate and ed99; those are not clean passes.', '',
    'The eight-test prototype passed ordinary tests and strict-provenance Miri on',
    'ARM64 and i686. Exact integrated storage modules then passed 16 Miri tests on',
    'each architecture, with Object and CachedHash stubs. This is not whole-VM',
    'Miri validation or a formal soundness proof.', '',
    'The first C API link failed with ENOSPC. Its log and the cleanup manifest',
    'are retained. Only disposable target/debug output was removed, with no active',
    'compiler or runtime; source, release references, caches, and results survived.',
    'The subsequent fresh C API build and tests passed. The observed release build',
    'took 4m04s; it is not a controlled build-time comparison.', '',
    'All four predeclared load gates completed. Focused runs used seven pairs',
    'for 20 cold and seven warm controls; full runs used 31 startup/import samples',
    'and five pairs for all 24 fixtures. Every sample, loss, and later load',
    'observation remains. Source and method hashes matched before and after timing;',
    'all measured caches remained unchanged. No owned build/test/profile overlapped.', '',
    'Ratios below 1 favor the candidate. Aggregation uses geometric means of',
    'per-fixture medians of paired ratios. Keep the 21-, 23-, and 24-row cohorts',
    'separate. Attribute changes to same-run reference pairs.', '',
    '| Reference | JIT work / reference (23) | JIT work / CPython (23) | Wall / reference (24) | CPU / reference (24) | RSS / reference (24) | RSS / CPython (24) |',
    '| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for ref in ['thin', 'wide']:
    c = full[ref]['cohorts']; work = c['all_23_workloads_excluding_startup']['metrics']['jit']['ns']
    proc = c['all_processes_including_startup']['metrics']['jit']
    lines.append(f"| {ref} | {work['new_over_base']:.9f} | {work['new_over_cpython']:.9f} | {proc['wall_ns']['new_over_base']:.9f} | {proc['cpu_ns']['new_over_base']:.9f} | {proc['rss_bytes']['new_over_base']:.9f} | {proc['rss_bytes']['new_over_cpython']:.9f} |")
lines += ['', 'Both full runs have six JIT workload wins against CPython and no peak-RSS',
    'wins. Versus bf2, shared string/bytes/tuple populations regress 13.6-15.4%',
    'in every JIT pair, while the integer population is nearly unchanged.',
    'Nine-byte strings/bytes use about 6.9% less RSS in every pair. Warm calls',
    'still regress. Versus ed99, all 27 focused RSS medians improve in every',
    'pair, but all ten ASCII/bytes construction timings regress in every pair.', '',
    'The next investigation is direct cloning of ordinary inline metadata while',
    'preserving the reference count and the individually boxed escape path.',
    'It is not implemented or measured by this archived candidate.', '',
    '## Focused JIT results', '',
    '| Control | Time / bf2 | RSS / bf2 | Time / ed99 | RSS / ed99 |',
    '| --- | ---: | ---: | ---: | ---: |']
for name, row in focused['thin']['rows'].items():
    t = row['new_over_previous']['jit']; w = focused['wide']['rows'][name]['new_over_previous']['jit']
    lines.append(f"| {name} | {t['ns']:.6f} | {t['rss_bytes']:.6f} | {w['ns']:.6f} | {w['rss_bytes']:.6f} |")
lines += ['', 'Full summaries retain every fixture, interpreter metric, cohort, and loss;',
    'focused summaries retain all paired ratios and win counts. Large text and',
    'JSON artifacts are losslessly compressed, with both stored and original hashes',
    'in index.json. Comparison executables and frozen caches stay local. Exact',
    'candidate source, changed bf2 preimages, method/input identities, and the',
    'original validation/linker logs are preserved here. Earlier status notes',
    'record historical intermediate states; this report gives the completed result.', '',
    'No universal, energy, controlled build-time, portability, or native parallel',
    'scaling conclusion follows from these measurements.', '']
report = '\n'.join(lines).encode()
(out / 'REPORT.md').write_bytes(report)
index.append({'path':'REPORT.md','bytes':len(report),'sha256':sha(report)})
(out / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
for row in index:
    data = (out / row['path']).read_bytes()
    assert sha(data) == row['sha256']
    if 'uncompressed_sha256' in row:
        raw = gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert sha(raw) == row['uncompressed_sha256']

allow = set()
for path in out.rglob('*'):
    relative = path.relative_to(base)
    allow.add('!' + str(relative) + ('/' if path.is_dir() else ''))
allow.add('!compact-arc-storage/')
with (base / '.gitignore').open('a') as f:
    f.write('\n# Completed compact-metadata trial; keep build outputs excluded.\n' + '\n'.join(sorted(allow)) + '\n')
with (base / 'README.md').open('a') as f:
    f.write('\nThe [compact metadata trial](compact-arc-storage/REPORT.md) preserves both\nreference comparisons, smaller allocation headers, and shared-value cloning\nregressions. It remains unfinished and motivates a narrower clone-path trial.\n')
print('Archived', len(index) + 1, 'files;', sum(p.stat().st_size for p in out.rglob('*') if p.is_file()), 'bytes. All hashes verified.')

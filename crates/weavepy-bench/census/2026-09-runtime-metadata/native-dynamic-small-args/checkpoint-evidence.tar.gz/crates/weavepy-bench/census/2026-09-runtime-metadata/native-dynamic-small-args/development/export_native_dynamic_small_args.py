"""Preserve the complete short-argument trial, including stack and timing losses."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

subprocess.run(['python3.14', 'target/verify_native_dynamic_small_args_ready.py'], check=True)
base=Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out=base/'native-dynamic-small-args'
assert not out.exists()
labels=['focused-previous','full-previous','focused-retained','full-retained']
for label in labels:
    gate=json.loads(Path(f'target/native-dynamic-small-args-{label}-load.json').read_text())
    assert gate['status']=='complete' and gate['returncode']==0
    assert Path(f'target/native-dynamic-small-args-{label}/stage.txt').read_text().strip()=='done'
decision=json.loads(Path('target/native-dynamic-small-args-decision.json').read_text())
assert set(decision)=={'decision','findings','next_step'}
out.mkdir()
index,destinations=[],set()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def add(source,relative):
    source=Path(source)
    raw=source.read_bytes()
    data=raw
    relative=Path(relative)
    if len(raw)>32768 and source.suffix in {'.json','.jsonl','.txt','.rs','.diff','.s'}:
        data=gzip.compress(raw,mtime=0)
        relative=Path(str(relative)+'.gz')
    assert str(relative) not in destinations,relative
    destinations.add(str(relative))
    dest=out/relative
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
    index.append({'path':str(relative),'source':str(source),'bytes':len(data),'sha256':sha(data),
                  'uncompressed_bytes':len(raw),'uncompressed_sha256':sha(raw)})
def tree(source,prefix,exclude=()):
    for path in sorted(Path(source).rglob('*')):
        relative=path.relative_to(source)
        if path.is_file() and not any(part in exclude for part in relative.parts):
            add(path,Path(prefix)/relative)
tree('target/native-dynamic-small-args-source-snapshot','candidate')
for label in labels:
    tree(f'target/native-dynamic-small-args-{label}',label,['frozen','startup'])
for group in ['checks','validation','preimages','baseline-coverage','baseline-coverage-v2','codegen']:
    tree(f'target/native-dynamic-small-args-{group}',group,['frozen'])
tree('target/native-dynamic-small-args-inputs','original-inputs')
tree('target/native-frame-shell-identity-audit','frame-identity-followup',['frozen'])
for path in sorted(Path('target').glob('native-dynamic-small-args*')):
    if path.is_file() and path.name!='native-dynamic-small-args-export.txt':
        add(path,Path('development')/path.name)
for name in ['performance_phase76_status.md','native-frame-shell-followup.md',
             'native-unobserved-shell-reuse-plan.md','prepare_native_dynamic_small_args_methods.py',
             'prepare_native_dynamic_small_args_inputs.py','prepare_native_dynamic_small_args_inputs_v2.py',
             'check_native_dynamic_small_args_native.sh','apply_native_dynamic_small_args.py',
             'check_native_dynamic_small_args_coverage.py','export_native_dynamic_small_args.py']:
    add(Path('target')/name,Path('development')/name)
frozen=json.loads(Path('target/native-dynamic-small-args-prebuild.json').read_text())
for name in frozen['methods']:
    add(name,Path('methods')/name)
env=json.loads(Path('target/native-dynamic-small-args-source-snapshot/environment.json').read_text())
binary=env['binaries']['new']
lines=['# Initialized arguments for short generic native calls','',
    'Decision: '+decision['decision'],'',*decision['findings'],'',
    'Next step: '+decision['next_step'],'',
    f"Candidate: `{binary['sha256']}`, {binary['bytes']:,} bytes.",
    'Direct reference: time formatter 6810,',
    '`681043b9f62cbd4fdb3f73756ecdf8ac877c1923b6a509f11ff1128dc973443c`.',
    'Retained acceptance reference: thin value storage bf2,',
    '`bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4`.','',
    'The runtime change outlines generic dynamic-call dispatch. Up to four',
    'positional arguments use an initialized four-Object array; larger positional',
    'and all keyword calls retain the vector path. Argument order and ownership,',
    'keyword-tail moves, activation shells, dirty marking, global guards, parked',
    'results, integer-result exits, and errors keep their existing behavior.',
    'There is no new uninitialized Object storage or ownership representation.',
    'Existing compiled-callee entry precedes the outlined generic helper. Earlier',
    'default-binding and formatter changes remain in this candidate.','',
    'Static machine-code inspection records both call-entry frames shrinking from',
    '448 to 96 bytes. The new generic helper reserves 624 bytes, including its',
    '96-byte register save. The entry frame stays live across that call, so the',
    'combined generic path reserves 720 bytes instead of 448. This is a stack',
    'tradeoff, not a lower generic-stack or RSS claim. The executable shrinks by',
    '16,512 bytes. The observed 4m05s release build is not a controlled build-time',
    'comparison. Original rejected objdump invocations and corrected output remain.','',
    'The Python semantic oracle passes on CPython, the predecessor, and the new',
    'candidate in their stated modes. It covers arities, aliases, keyword order,',
    'nested calls, weak-reference lifetimes, mixed returns, exceptions, global',
    'mutation inside a callback, and frame visibility. The VM regression asserts',
    'at least 100 executions in each of seven argument paths with test-only',
    'counters. No such counter is present in release code. Initial test-only Cell',
    'qualification and format-check failures are preserved with their correction.','',
    'Validation passed 352 VM tests, 156 C API tests, strict format/lint, a no-JIT',
    'check, 99 targeted Python checks, and all 275 outside-sandbox compatibility',
    'checks. Optional extension tests may check availability internally. GIL-',
    'disabled checks disable JIT and are correctness evidence only. All 340',
    'source identities and 132 method/input identities stayed unchanged.','',
    'The original 25 fixture sources and traces remain. The v2 set preserves',
    'every original source and adds a four-object case using explicit assignments.',
    'All 26 independent CPython checksum oracles pass twice. Untimed predecessor',
    'and candidate traces prove the intended generic drivers compile and make',
    'more than 30,000 generic calls; compiled-alias controls compile and make',
    'more than 30,000 native-to-native calls. Wide 32-argument and original four-',
    'object drivers remain interpreted, as do several inherited controls. These',
    'coverage captures are separate from performance measurements.','',
    'A separate untimed frame-identity diagnostic completed before timing. Five',
    'callbacks from one driver capture the same parent frame in CPython and in',
    'WeavePy interpreter mode. Both the predecessor and candidate JIT builds',
    'return distinct frame objects, although their code names are correct. This',
    'preexisting mismatch remains and motivates the next allocation/observability',
    'investigation. Passing the declared suite does not imply universal semantic',
    'equivalence. All diagnostic outputs and traces are preserved.','',
    'The four timing stages ran sequentially under the exclusive lease and',
    'unchanged host-load gate. Every dependent launch followed inspected',
    'completion. No owned build, test, profile, install, runtime edit, or active-',
    'harness edit overlapped a stage. All samples and frozen-cache assertions',
    'remain, including losses and all load observations.','',
    'Ratios below 1 favor the candidate. Means aggregate per-fixture medians of',
    'paired ratios. Keep the historical 21-row, 23-workload, and 24-process cohorts',
    'separate. The bf2 comparisons are measured directly, not inferred by',
    'multiplying ratios from unrelated runs.','']
for ref in ['previous','retained']:
    full=json.loads(Path(f'target/native-dynamic-small-args-full-{ref}/summary.json').read_text())
    focused=json.loads(Path(f'target/native-dynamic-small-args-focused-{ref}/summary.json').read_text())
    reference='6810' if ref=='previous' else 'bf2'
    lines += [f'## Direct comparison with {reference}','',
        f'| Metric | Candidate / {reference} | Candidate / CPython | Wins over CPython |',
        '| --- | ---: | ---: | ---: |']
    c=full['cohorts']
    w=c['all_23_workloads_excluding_startup']['metrics']
    m=c['all_processes_including_startup']['metrics']
    for label,row in [('JIT workload time (23)',w['jit']['ns']),
                      ('Interpreter workload time (23)',w['interp']['ns']),
                      ('JIT process wall time (24)',m['jit']['wall_ns']),
                      ('JIT CPU time (24)',m['jit']['cpu_ns']),
                      ('JIT peak RSS (24)',m['jit']['rss_bytes']),
                      ('Interpreter process wall time (24)',m['interp']['wall_ns']),
                      ('Interpreter CPU time (24)',m['interp']['cpu_ns']),
                      ('Interpreter peak RSS (24)',m['interp']['rss_bytes'])]:
        lines.append(f"| {label} | {row['new_over_base']:.9f} | {row['new_over_cpython']:.9f} | {row['weavepy_wins']} |")
    lines += ['',f'| Focused control | JIT time / {reference} | JIT time / CPython | RSS / {reference} | Time wins (7 pairs) |',
        '| --- | ---: | ---: | ---: | ---: |']
    for name,row in focused['rows'].items():
        v=row['new_over_previous']['jit']
        cp=row['new_over_cpython']['jit']
        lines.append(f"| {name} | {v['ns']:.6f} | {cp['ns']:.6f} | {v['rss_bytes']:.6f} | {row['pairs']['jit']['ns']['wins']} |")
    lines += ['']
lines += ['All raw samples, losses, validation outcomes, load observations, VM/swap',
    'snapshots, methods, inputs, and source snapshots remain. Large text artifacts',
    'use lossless gzip; index.json identifies stored and original bytes. Executables',
    'and frozen caches remain local. Intermediate status notes are historical.','',
    'The user goal remains unachieved. No universal, energy, controlled build-time,',
    'portability, or native parallel-scaling conclusion follows.','']
data='\n'.join(lines).encode()
(out/'REPORT.md').write_bytes(data)
index.append({'path':'REPORT.md','bytes':len(data),'sha256':sha(data)})
(out/'index.json').write_text(json.dumps(index,indent=2)+'\n')
for row in index:
    data=(out/row['path']).read_bytes()
    assert sha(data)==row['sha256']
    if 'uncompressed_sha256' in row:
        raw=gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert sha(raw)==row['uncompressed_sha256']
allow={'!native-dynamic-small-args/'}
for path in out.rglob('*'):
    allow.add('!'+str(path.relative_to(base))+('/' if path.is_dir() else ''))
with (base/'.gitignore').open('a') as f:
    f.write('\n# Short generic native-call arguments and all observed tradeoffs.\n'+'\n'.join(sorted(allow))+'\n')
with (base/'README.md').open('a') as f:
    f.write('\nThe [short generic-call argument trial](native-dynamic-small-args/REPORT.md) preserves\ncall-path validation, stack tradeoffs, and complete direct and retained-baseline comparisons.\n')
print('Archived',len(index)+1,'files;',sum(p.stat().st_size for p in out.rglob('*') if p.is_file()),'bytes. All hashes verified.')

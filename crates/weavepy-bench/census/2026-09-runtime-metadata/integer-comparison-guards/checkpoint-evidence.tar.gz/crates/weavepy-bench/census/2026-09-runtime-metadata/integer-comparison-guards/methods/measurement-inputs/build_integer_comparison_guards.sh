#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-jit-assertion-exits
reference=target/release/weavepy-runtime-jit-raise-call-spans
binary=target/release/weavepy-runtime-integer-comparison-guards
test -f "$base"
test -f "$reference"
test ! -e "$binary"
test ! -e target/integer-comparison-guards-build-stage.txt
printf '%s\n' "$base" > target/integer-comparison-guards-previous.txt
printf '%s\n' "$reference" > target/integer-comparison-guards-reference.txt
printf 'VM tests and static checks\n' > target/integer-comparison-guards-build-stage.txt
cargo fmt --all -- --check > target/integer-comparison-guards-format.txt 2>&1
cargo test --offline --locked -p weavepy-jit -j 1 > target/integer-comparison-guards-jit-tests.txt 2>&1
cargo test --offline --locked -p weavepy-vm --lib -j 1 > target/integer-comparison-guards-vm-tests.txt 2>&1
cargo clippy --offline --locked -p weavepy-vm -p weavepy-jit --lib --tests -j 1 -- -D warnings > target/integer-comparison-guards-clippy.txt 2>&1
cargo check --offline --locked -p weavepy-vm --no-default-features -j 1 > target/integer-comparison-guards-no-jit.txt 2>&1
printf 'release build\n' > target/integer-comparison-guards-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/integer-comparison-guards-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/integer-comparison-guards-source-snapshot --extra target/build_integer_comparison_guards.sh target/check_integer_comparison_guards.sh target/validate_integer_comparison_guards.sh target/check_integer_comparison_guards_extra.py target/inspect_integer_comparison_guards.py target/measure_integer_comparison_guards_focused.sh target/measure_integer_comparison_guards_full.sh target/measure_verified_python_components_with_reference.py target/integer-comparison-guards-protocol.md > target/integer-comparison-guards-snapshot.txt 2>&1
printf 'done\n' > target/integer-comparison-guards-build-stage.txt

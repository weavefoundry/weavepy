"""Archive the formatter candidate, validation, and both complete comparisons."""
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

subprocess.run(['python3.14', 'target/verify_ascii_time_format_ready.py'], check=True)
base = Path('crates/weavepy-bench/census/2026-09-runtime-metadata')
out = base / 'ascii-time-format'
assert not out.exists()
labels = ['focused-previous', 'full-previous', 'focused-retained', 'full-retained']
for label in labels:
    gate = json.loads(Path(f'target/ascii-time-format-{label}-load.json').read_text())
    assert gate['status'] == 'complete' and gate['returncode'] == 0
    assert Path(f'target/ascii-time-format-{label}/stage.txt').read_text().strip() == 'done'
decision = json.loads(Path('target/ascii-time-format-decision.json').read_text())
assert set(decision) == {'decision', 'findings', 'next_step'}
out.mkdir()
index, destinations = [], set()
def sha(data):
    return hashlib.sha256(data).hexdigest()
def add(source, relative):
    source = Path(source)
    raw = source.read_bytes()
    data = raw
    relative = Path(relative)
    if len(raw) > 32768 and source.suffix in {'.json', '.jsonl', '.txt', '.rs', '.diff', '.s'}:
        data = gzip.compress(raw, mtime=0)
        relative = Path(str(relative) + '.gz')
    assert str(relative) not in destinations, relative
    destinations.add(str(relative))
    dest = out / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    index.append({'path': str(relative), 'source': str(source), 'bytes': len(data), 'sha256': sha(data),
                  'uncompressed_bytes': len(raw), 'uncompressed_sha256': sha(raw)})
def tree(source, prefix, exclude=()):
    for path in sorted(Path(source).rglob('*')):
        relative = path.relative_to(source)
        if path.is_file() and not any(part in exclude for part in relative.parts):
            add(path, Path(prefix) / relative)
tree('target/ascii-time-format-source-snapshot', 'candidate')
for label in labels:
    tree(f'target/ascii-time-format-{label}', label, ['frozen', 'startup'])
for group in ['checks', 'validation', 'preimages', 'oracle']:
    tree(f'target/ascii-time-format-{group}', group, ['frozen'])
tree('target/ascii-time-format-prototype', 'prototype', ['target', '.git'])
tree('target/after-time-format-path-audit', 'followup-path-audit', ['frozen'])
for path in sorted(Path('target').glob('ascii-time-format*')):
    if path.is_file() and path.name != 'ascii-time-format-export.txt':
        add(path, Path('development') / path.name)
for name in ['performance_phase75_status.md', 'prepare_ascii_time_format_methods.py',
             'prepare_ascii_time_format_inputs.py', 'check_ascii_time_format_native.sh',
             'export_ascii_time_format.py', 'datetime-format-time-followup.md',
             'native-dynamic-small-args-followup.md']:
    add(Path('target') / name, Path('development') / name)
frozen = json.loads(Path('target/ascii-time-format-prebuild.json').read_text())
for name in frozen['methods']:
    add(name, Path('methods') / name)
env = json.loads(Path('target/ascii-time-format-source-snapshot/environment.json').read_text())
binary = env['binaries']['new']
lines = ['# Native formatting for ordinary time fields', '',
    'Decision: ' + decision['decision'], '',
    *decision['findings'], '',
    'Next step: ' + decision['next_step'], '',
    f"Candidate: `{binary['sha256']}`, {binary['bytes']:,} bytes.",
    'Direct reference: combined default borrowing bc88,',
    '`bc88bf2b02abaaf0ad6a3d7427a17cab11f864a400a8161fc2effe5f396dd695`.',
    'Retained acceptance reference: thin value storage bf2,',
    '`bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4`.', '',
    'The candidate adds a native formatter for exact integer fields in ordinary',
    'time ranges and exact strings naming six supported precisions. A safe',
    '15-byte ASCII buffer emits zero-padded fields and truncates milliseconds.',
    'Checked UTF-8 conversion produces the final string. There is no unsafe',
    'operation or temporary heap vector. _pydatetime._format_time calls this',
    'optional helper first and keeps its complete previous Python fallback for',
    'unusual values, subclasses, callbacks, and errors. The experimental default-',
    'binding changes from bc88 remain. No other existing runtime source changed.', '',
    'The standalone three-test prototype matches 7,320 independently generated',
    'CPython time.isoformat outputs. These are correctness results, not runtime',
    'performance measurements. The new Python semantic oracle passes on CPython,',
    'the predecessor, and the candidate. It covers all precisions, boundaries,',
    'random valid fields, timezones and fold, invalid precision, negative/large/',
    'boolean fields, unused custom values, formatting/truth/floor callbacks,',
    'integer/string subclasses, and native-helper rebinding. Independent CPython',
    'checksums match all 17 focused inputs before and after warmup.', '',
    'Validation: 351 VM tests, 156 C API tests, strict lint/format, no-JIT check,',
    '96 targeted Python checks, native-helper activation proof, and 275 complete',
    'outside-sandbox compatibility checks passed. GIL-disabled checks disable JIT',
    'and are correctness evidence only. Optional extension tests can check their',
    'availability internally. All 339 source and 92 method/input identities',
    'remained unchanged. The observed 4m27s release build is not a controlled',
    'build-time comparison.', '',
    'A separate untimed path audit completed before timing. Four calls each to',
    'the unchanged datetime and deque fixtures match CPython. JIT rejection and',
    'deoptimization traces motivate follow-up work; they are not timings.', '',
    'Four stages ran sequentially under the exclusive lease and unchanged host-',
    'load gate: focused and full against bc88, then focused and full against bf2.',
    'Each dependent launch required inspected completion. No owned build, test,',
    'profile, install, runtime edit, or active-harness edit overlapped a stage.',
    'All samples, load observations, and frozen-cache assertions are retained.', '',
    'Ratios below 1 favor the candidate. Means aggregate per-fixture medians of',
    'paired ratios. Keep the historical 21-row, 23-workload, and 24-process cohorts',
    'separate. Comparisons with bf2 are measured directly in their own stage,',
    'not inferred by multiplying unrelated historical ratios.', '']
for ref in ['previous', 'retained']:
    full = json.loads(Path(f'target/ascii-time-format-full-{ref}/summary.json').read_text())
    focused = json.loads(Path(f'target/ascii-time-format-focused-{ref}/summary.json').read_text())
    reference = 'bc88' if ref == 'previous' else 'bf2'
    lines += [f'## Direct comparison with {reference}', '',
        f'| Metric | Candidate / {reference} | Candidate / CPython | Wins over CPython |',
        '| --- | ---: | ---: | ---: |']
    c = full['cohorts']
    w = c['all_23_workloads_excluding_startup']['metrics']
    m = c['all_processes_including_startup']['metrics']
    for label, row in [('JIT workload time (23)', w['jit']['ns']),
                       ('Interpreter workload time (23)', w['interp']['ns']),
                       ('JIT process wall time (24)', m['jit']['wall_ns']),
                       ('JIT CPU time (24)', m['jit']['cpu_ns']),
                       ('JIT peak RSS (24)', m['jit']['rss_bytes']),
                       ('Interpreter process wall time (24)', m['interp']['wall_ns']),
                       ('Interpreter CPU time (24)', m['interp']['cpu_ns']),
                       ('Interpreter peak RSS (24)', m['interp']['rss_bytes'])]:
        lines.append(f"| {label} | {row['new_over_base']:.9f} | {row['new_over_cpython']:.9f} | {row['weavepy_wins']} |")
    lines += ['', f'| Focused control | JIT time / {reference} | JIT time / CPython | RSS / {reference} | Time wins (7 pairs) |',
        '| --- | ---: | ---: | ---: | ---: |']
    for name, row in focused['rows'].items():
        v = row['new_over_previous']['jit']
        cp = row['new_over_cpython']['jit']
        lines.append(f"| {name} | {v['ns']:.6f} | {cp['ns']:.6f} | {v['rss_bytes']:.6f} | {row['pairs']['jit']['ns']['wins']} |")
    lines += ['']
lines += ['All raw samples, losses, validation outcomes, load observations, VM/swap',
    'snapshots, methods, inputs, and source snapshots remain. Large text artifacts',
    'use lossless gzip; index.json identifies stored and original bytes. Executables',
    'and frozen caches remain local. Intermediate status notes are historical.', '',
    'The user goal remains unachieved. No universal, energy, controlled build-time,',
    'portability, or native parallel-scaling conclusion follows.', '']
data = '\n'.join(lines).encode()
(out / 'REPORT.md').write_bytes(data)
index.append({'path': 'REPORT.md', 'bytes': len(data), 'sha256': sha(data)})
(out / 'index.json').write_text(json.dumps(index, indent=2) + '\n')
for row in index:
    data = (out / row['path']).read_bytes()
    assert sha(data) == row['sha256']
    if 'uncompressed_sha256' in row:
        raw = gzip.decompress(data) if row['path'].endswith('.gz') else data
        assert sha(raw) == row['uncompressed_sha256']
allow = {'!ascii-time-format/'}
for path in out.rglob('*'):
    allow.add('!' + str(path.relative_to(base)) + ('/' if path.is_dir() else ''))
with (base / '.gitignore').open('a') as f:
    f.write('\n# Native time formatting: complete predecessor and retained comparisons.\n' + '\n'.join(sorted(allow)) + '\n')
with (base / 'README.md').open('a') as f:
    f.write('\nThe [native time-formatting trial](ascii-time-format/REPORT.md) preserves\ncorrectness checks, focused gains and losses, and complete predecessor and retained-baseline comparisons.\n')
print('Archived', len(index) + 1, 'files;', sum(p.stat().st_size for p in out.rglob('*') if p.is_file()), 'bytes. All hashes verified.')

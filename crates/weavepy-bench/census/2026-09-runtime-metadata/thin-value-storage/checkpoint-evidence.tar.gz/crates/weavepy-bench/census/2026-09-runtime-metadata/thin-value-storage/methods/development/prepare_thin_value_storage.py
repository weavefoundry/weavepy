from pathlib import Path

root = Path(__file__).resolve().parents[1]
draft = root / 'target/thin-value-storage-draft'
source = (root / 'crates/weavepy-vm/src/tuple_storage.rs').read_text()
source = source.replace('use crate::sync::{CachedHash, Rc};', 'use crate::sync::{CachedHash, Rc};\nuse crate::shared_value::{SharedStr, ThinArc};\n\npub type SharedTuple = ThinArc<TupleStorage>;')
source = source.replace('/// Immutable tuple storage. The slice metadata still carries the length,\n/// so adding the hash word doesn\'t enlarge an [`Object`] handle.', '/// Immutable tuple storage with length and cached hash in its allocation.')
source = source.replace('    hash: CachedHash,\n    items: T,', '    len: usize,\n    hash: CachedHash,\n    items: T,')
source = source.replace('-> Rc<Self>', '-> SharedTuple')
source = source.replace('        Rc::new(TupleStorage {\n            hash:', '        let arc: Rc<Self> = Rc::new(TupleStorage {\n            len: N,\n            hash:')
source = source.replace('            items,\n        })', '            items,\n        });\n        ThinArc::from_arc(arc)')
source = source.replace('        let (layout, _) = Layout::new::<CachedHash>()', '        let (prefix, _) = Layout::new::<usize>()\n            .extend(Layout::new::<CachedHash>()).expect("tuple prefix exceeds layout limit");\n        let (layout, _) = prefix')
source = source.replace('repr(C) places the hash before the final slice', 'repr(C) places length and hash before the final slice')
source = source.replace('        unsafe {\n            std::ptr::addr_of_mut!((*tuple).hash)', '        unsafe {\n            std::ptr::addr_of_mut!((*tuple).len).write(len);\n            std::ptr::addr_of_mut!((*tuple).hash)')
source = source.replace('            result\n', '            ThinArc::from_arc(result)\n')
source = source.replace('obtained through Arc::get_mut', 'obtained through ThinArc::get_mut')
source = source.replace('let text: Rc<str> = Rc::from(', 'let text = SharedStr::from(')
source = source.replace('Rc::strong_count(&text)', 'SharedStr::strong_count(&text)').replace('Rc::ptr_eq(s, &text)', 'SharedStr::ptr_eq(s, &text)')
source = source.replace('Rc::downgrade(&tuple)', 'ThinArc::downgrade(&tuple)').replace('Rc::get_mut(&mut tuple)', 'ThinArc::get_mut(&mut tuple)')
source = source.replace('use crate::shared_value::{SharedStr, ThinArc};', 'use crate::shared_value::ThinArc;')
source = source.replace('    use super::*;', '    use super::*;\n    use crate::shared_value::SharedStr;')
(draft / 'tuple_storage.rs').write_text(source)
crate = root / 'target/thin-value-storage-api'
(crate / 'src').mkdir(parents=True, exist_ok=True)
(crate / 'Cargo.toml').write_text('[package]\nname="thin-value-storage-api"\nversion="0.0.0"\nedition="2021"\n\n[workspace]\n')
(crate / 'src/lib.rs').write_text('''//! Standalone checks of exact draft storage modules; Object and CachedHash are stubs.
#[path="../../thin-value-storage-draft/shared_value.rs"]
pub mod shared_value;
#[path="../../thin-value-storage-draft/tuple_storage.rs"]
pub mod tuple_storage;
pub mod object {
    #[derive(Debug, Clone)]
    pub enum Object { Int(i64), Str(crate::shared_value::SharedStr) }
}
pub mod sync {
    pub type Rc<T> = std::sync::Arc<T>;
    #[repr(transparent)]
    #[derive(Debug)]
    pub struct CachedHash(std::sync::atomic::AtomicI64);
    impl Default for CachedHash { fn default() -> Self { Self(std::sync::atomic::AtomicI64::new(-1)) } }
    impl CachedHash {
        pub fn get(&self) -> Option<i64> {
            let x = self.0.load(std::sync::atomic::Ordering::Acquire);
            (x != -1).then_some(x)
        }
        pub fn store(&self, x:i64) { self.0.store(if x == -1 {-2} else {x}, std::sync::atomic::Ordering::Release); }
    }
}
''')

#!/bin/bash
set -euo pipefail
export CARGO_INCREMENTAL=0
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
base=target/release/weavepy-runtime-borrowed-keyword-defaults
binary=target/release/weavepy-runtime-ascii-time-format
test ! -e "$binary"
test ! -e target/ascii-time-format-build-stage.txt
cargo fmt --all -- --check > target/ascii-time-format-format.txt 2>&1
python3.14 target/freeze_ascii_time_format_sources.py
printf 'release build\n' > target/ascii-time-format-build-stage.txt
cargo build --offline --locked --release -p weavepy-cli --bin weavepy -j 1 > target/ascii-time-format-build.txt 2>&1
cp target/release/weavepy "$binary"
python3.14 target/freeze_runtime_candidate.py --binary "$binary" --previous "$base" --out target/ascii-time-format-source-snapshot --extra target/build_ascii_time_format.sh target/check_ascii_time_format.sh target/validate_ascii_time_format.sh target/measure_ascii_time_format_focused.sh target/measure_ascii_time_format_full.sh target/measure_verified_python_components.py target/ascii-time-format-protocol.md target/verify_ascii_time_format_ready.py target/freeze_ascii_time_format_sources.py target/summarize_ascii_time_format.py > target/ascii-time-format-snapshot.txt 2>&1
printf 'done\n' > target/ascii-time-format-build-stage.txt

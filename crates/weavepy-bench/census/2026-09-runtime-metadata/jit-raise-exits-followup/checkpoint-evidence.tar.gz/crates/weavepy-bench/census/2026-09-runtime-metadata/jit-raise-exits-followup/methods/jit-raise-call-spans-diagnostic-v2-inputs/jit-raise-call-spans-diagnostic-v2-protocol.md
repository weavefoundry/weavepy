# Separate busy-host diagnostic, declared before any timing

The strict focused protocol requires one- and five-minute load averages at
most 4. This separate diagnostic may run only after that 600-second gate
expires without launching a child or collecting any samples. Preserve its
original telemetry unchanged. The host is running a separate WeaveC compiler
workload and system storage services; neither is controlled by this task.

Use candidate 539c6dd3 and checkpoint 8899e367 in JIT and interpreter modes
plus CPython 3.14.7. Use exactly the same twelve warm cases and four cold
exception controls, work sizes, and seven paired samples declared in the
focused protocol. No fixture selection, work-size tuning, or sample omission.
Use fresh output directories and fresh per-binary frozen caches, and verify
all values and unchanged cached bytes. Retain full wall-time, CPU-time,
peak-RSS, load, VM, and swap observations.

This diagnostic has no quiet-host precondition. Its purpose is to expose
large effects and potential regressions while other work continues, rather
than postpone all investigation indefinitely. Changing system load, frequency,
and memory pressure limit interpretation. Small differences cannot establish
improvement or regression; even large effects need their absolute CPython
ratios labeled as observations under contention. Do not replace the quiet
census headline with this screen, or call this a quiet or controlled recording.

Do not run other builds, tests, or profiles from this task, or change runtime
sources or active measurement inputs during the diagnostic. Keep any failure
in place. A retry, further comparison, or changed candidate requires a fresh,
explicitly identified run. The full quiet census remains separate work.

## Launcher correction before measurement

The first diagnostic launcher failed before starting any benchmark process:
macOS Bash 3.2 treats an empty array expansion under nounset as unbound.
Its telemetry and output remain in place. This separately named run makes
the argument array nonempty for every case and uses a fresh output root.
The candidate, fixtures, work sizes, sample counts, and all interpretation
limits are unchanged. No timing sample was collected or discarded.

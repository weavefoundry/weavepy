"""Run nonempty storage, encoding, serialization, and C API suites."""
import hashlib, json, os, re, subprocess
from pathlib import Path
root=Path('target/niche-string-owner-extra-checks')
root.mkdir()
runner='target/release/weavepy-conformance'
report={'runner_sha256':hashlib.sha256(Path(runner).read_bytes()).hexdigest(),'runs':{}}
def passed(run):
    match=re.search(r'(\d+) total .*?pass (\d+) / fail (\d+) / error (\d+).*?unexpected (\d+)',run['stdout'])
    if not match:
        return False
    total,ok,fail,error,unexpected=map(int,match.groups())
    return run['returncode']==0 and total>0 and total==ok and fail==error==unexpected==0
for case in ['test_bytes','test_codecs','test_marshal','test_capi/test_bytes','test_capi/test_unicode','test_capi/test_list','test_capi/test_dict']:
    report['runs'][case]={}
    for label,binary in [('new','target/release/weavepy-runtime-niche-string-owner'),('previous','target/release/weavepy-runtime-thin-value-storage')]:
        digest=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
        env=dict(os.environ,WEAVEPY_JIT='1',WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),WEAVEPY_FROZEN_CACHE=str((root/'frozen'/digest).resolve()))
        command=[runner,'regrtest',*(['--expectations','target/thin-value-storage-capi-selection.toml'] if case.startswith('test_capi/') else []),'--all-cpython','--mode','subprocess','--weavepy',binary,'--filter','cpython/Lib/test/'+case+'.py','--stream']
        try:
            result=subprocess.run(command,env=env,text=True,capture_output=True,timeout=900)
            run={'command':command,'binary_sha256':digest,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
        except subprocess.TimeoutExpired as error:
            run={'command':command,'binary_sha256':digest,'returncode':None,'timeout':True,'stdout':(error.stdout or b'').decode(errors='replace'),'stderr':(error.stderr or b'').decode(errors='replace')}
        run['nonempty_and_passed']=passed(run)
        run['expected_marshal_divergence'] = case == 'test_marshal' and run['returncode'] == 0 and '1 total' in run['stdout'] and 'divergence 1' in run['stdout'] and 'unexpected 0' in run['stdout'] and '| divergence | divergence |' in run['stdout']
        run['accepted'] = run['nonempty_and_passed'] or run['expected_marshal_divergence']
        report['runs'][case][label]=run
        (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
        print(case,label,'pass:',run['nonempty_and_passed'],run['stdout'][-2000:],flush=True)
        if run['nonempty_and_passed']:
            break
report['status']='passed' if all(r['new']['accepted'] for r in report['runs'].values()) and all(r['accepted'] for r in report['runs']['test_marshal'].values()) else 'needs_review'
(root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if report['status']=='passed' else 1)


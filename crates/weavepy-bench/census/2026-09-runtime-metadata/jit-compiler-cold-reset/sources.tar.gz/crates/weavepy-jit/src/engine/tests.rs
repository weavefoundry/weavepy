//! Scalar-leaf certification excludes helpers and nonlocal effects.
use super::is_scalar_leaf;
use crate::ir::{ArithKind, TBlock, TFunc, TOp, TStmt, TTerm};
use crate::value::JitType;

fn function(ops: &[TOp]) -> TFunc {
    TFunc {
        n_locals: 2,
        local_types: vec![Some(JitType::Int), Some(JitType::Int)],
        livein_locals: vec![0, 1],
        max_stack: 2,
        entry_block: 0,
        global_guards: vec![],
        range_loops: vec![],
        list_loops: vec![],
        iter_loops: vec![],
        comp_saved: vec![],
        resume_entries: vec![],
        callee_spans: vec![],
        len_spans: vec![],
        method_spans: vec![],
        attr_sites: vec![],
        method_sites: vec![],
        str_method_sites: vec![],
        str_method_spans: vec![],
        math_guards: vec![],
        math_spans: vec![],
        null_spans: vec![],
        osr_entries: vec![],
        max_call_args: 0,
        ret_lane: Some(JitType::Int),
        ret_none: false,
        blocks: vec![TBlock {
            entry_stack: vec![],
            stmts: ops
                .iter()
                .enumerate()
                .map(|(pc, &op)| TStmt { pc: pc as u32, op })
                .collect(),
            term: TTerm::Return,
        }],
    }
}

#[test]
fn scalar_leaf_allowlist_is_conservative() {
    let pure = function(&[
        TOp::LoadLocal(0),
        TOp::LoadLocal(1),
        TOp::IntArith(ArithKind::Add),
    ]);
    assert!(is_scalar_leaf(&pure));
    let mut changed = pure.clone();
    changed.blocks.push(changed.blocks[0].clone());
    assert!(!is_scalar_leaf(&changed));
    let mut changed = pure.clone();
    changed.local_types[0] = Some(JitType::Obj);
    assert!(!is_scalar_leaf(&changed));
    let mut changed = pure.clone();
    changed.ret_lane = Some(JitType::Obj);
    assert!(!is_scalar_leaf(&changed));
    let mut changed = pure.clone();
    changed.blocks[0].stmts.resize(
        65,
        TStmt {
            pc: 0,
            op: TOp::Pop,
        },
    );
    assert!(!is_scalar_leaf(&changed));
    for op in [
        TOp::FloatArith(ArithKind::FloorDiv),
        TOp::FloatArith(ArithKind::Mod),
        TOp::UnboxInt { depth: 0 },
        TOp::PushConstStr { idx: 0 },
        TOp::PushConstTuple { idx: 0 },
        TOp::TupleLen,
        TOp::CallDyn {
            argc: 0,
            kwc: 0,
            names: 0,
            int_result: true,
        },
        TOp::ListLen,
        TOp::DynAttrGet { name: 0 },
    ] {
        assert!(!is_scalar_leaf(&function(&[op])), "{op:?}");
    }
}

#[test]
fn scalar_leaf_returns_and_deopts_with_no_embedder_context() {
    use crate::runtime::{JitFrame, JitStatus, SlotTag};
    let tfunc = function(&[
        TOp::LoadLocal(0),
        TOp::LoadLocal(1),
        TOp::IntArith(ArithKind::Add),
    ]);
    let mut engine = super::JitEngine::new().expect("host ISA");
    let cf = engine.compile_tfunc(&tfunc).expect("compile scalar leaf");
    assert!(cf.is_scalar_leaf());
    for (a, b, expected) in [
        (40, 2, JitStatus::Returned),
        (i64::MAX, 1, JitStatus::Deopt),
    ] {
        let mut locals = [a as u64, b as u64];
        let mut spill = [0u64; 3];
        let mut tags = [0u32; 3];
        let mut frame = JitFrame {
            locals: locals.as_mut_ptr(),
            n_locals: 2,
            entry_pc: 0,
            ret_bits: 0,
            ret_tag: 0,
            deopt_pc: 0,
            stack_spill: spill.as_mut_ptr(),
            stack_tags: tags.as_mut_ptr(),
            stack_len: 0,
            stack_cap: 3,
            ctx: std::ptr::null_mut(),
            call_args: std::ptr::null_mut(),
            call_tags: std::ptr::null_mut(),
        };
        // SAFETY: the certified scalar leaf needs no helper context, all
        // buffers fit its metadata, and the owning engine is still alive.
        assert_eq!(unsafe { cf.enter(&raw mut frame) }, expected);
        if expected == JitStatus::Returned {
            assert_eq!(frame.ret_bits, 42);
            assert_eq!(frame.ret_tag, SlotTag::Int as u32);
        } else {
            assert_eq!(frame.deopt_pc, 2);
            assert_eq!(frame.stack_len, 2);
            assert_eq!(&spill[..2], &[a as u64, b as u64]);
            assert_eq!(&tags[..2], &[SlotTag::Int as u32; 2]);
        }
    }
}

#[test]
fn explicit_exit_preserves_operands_and_updated_locals() {
    use crate::runtime::{JitFrame, JitStatus, SlotTag};
    let mut tf = function(&[
        TOp::LoadLocal(0),
        TOp::PushConstInt(99),
        TOp::StoreLocal(0),
        TOp::LoadLocal(1),
    ]);
    tf.blocks[0].term = TTerm::Deopt { pc: 17 };
    assert!(!is_scalar_leaf(&tf));
    let mut engine = super::JitEngine::new().expect("host ISA");
    let compiled = engine.compile_tfunc(&tf).expect("compile explicit exit");
    let mut locals = [41u64, 7];
    let mut spill = [0u64; 3];
    let mut tags = [0u32; 3];
    let mut frame = JitFrame {
        locals: locals.as_mut_ptr(),
        n_locals: 2,
        entry_pc: 0,
        ret_bits: 0,
        ret_tag: 0,
        deopt_pc: 0,
        stack_spill: spill.as_mut_ptr(),
        stack_tags: tags.as_mut_ptr(),
        stack_len: 0,
        stack_cap: 3,
        ctx: std::ptr::null_mut(),
        call_args: std::ptr::null_mut(),
        call_tags: std::ptr::null_mut(),
    };
    // SAFETY: this IR uses only scalar loads/stores and an explicit exit,
    // needs no helpers, and all buffers fit the live compiled metadata.
    assert_eq!(unsafe { compiled.enter(&raw mut frame) }, JitStatus::Deopt);
    assert_eq!(frame.deopt_pc, 17);
    assert_eq!(frame.stack_len, 2);
    assert_eq!(&spill[..2], &[41, 7]);
    assert_eq!(&tags[..2], &[SlotTag::Int as u32; 2]);
    assert_eq!(locals, [99, 7]);
}

fn oversized_function(kind: ArithKind) -> TFunc {
    // Distinct dead constants grow compiler IR without requiring helpers or
    // performing extra work when the resulting native function is entered.
    let mut ops = Vec::new();
    for value in 0..=super::MAX_RETAINED_IR_INSTRUCTIONS {
        ops.push(TOp::PushConstInt(value as i64));
        ops.push(TOp::Pop);
    }
    ops.extend([TOp::LoadLocal(0), TOp::LoadLocal(1), TOp::IntArith(kind)]);
    function(&ops)
}

fn check_scalar_entry(compiled: &super::CompiledFrame, a: i64, b: i64, expected: Result<i64, u32>) {
    use crate::runtime::{JitFrame, JitStatus, SlotTag};
    let mut locals = [a as u64, b as u64];
    let mut spill = [0u64; 3];
    let mut tags = [0u32; 3];
    let mut frame = JitFrame {
        locals: locals.as_mut_ptr(),
        n_locals: 2,
        entry_pc: 0,
        ret_bits: 0,
        ret_tag: 0,
        deopt_pc: 0,
        stack_spill: spill.as_mut_ptr(),
        stack_tags: tags.as_mut_ptr(),
        stack_len: 0,
        stack_cap: 3,
        ctx: std::ptr::null_mut(),
        call_args: std::ptr::null_mut(),
        call_tags: std::ptr::null_mut(),
    };
    // SAFETY: the tests keep the owning engine alive. These functions use only
    // scalar operations with no helpers, and all exchange buffers fit their IR.
    let status = unsafe { compiled.enter(&raw mut frame) };
    match expected {
        Ok(value) => {
            assert_eq!(status, JitStatus::Returned);
            assert_eq!(frame.ret_bits, value as u64);
            assert_eq!(frame.ret_tag, SlotTag::Int as u32);
        }
        Err(pc) => {
            assert_eq!(status, JitStatus::Deopt);
            assert_eq!(frame.deopt_pc, pc);
            assert_eq!(frame.stack_len, 2);
            assert_eq!(&spill[..2], &[a as u64, b as u64]);
            assert_eq!(&tags[..2], &[SlotTag::Int as u32; 2]);
        }
    }
    assert_eq!(locals, [a as u64, b as u64]);
}

#[test]
fn compiler_scratch_reset_preserves_old_code_and_exact_exits() {
    let mut engine = super::JitEngine::new().expect("host ISA");
    let small = |kind| function(&[TOp::LoadLocal(0), TOp::LoadLocal(1), TOp::IntArith(kind)]);
    let first = engine.compile_tfunc(&small(ArithKind::Add)).unwrap();
    let large_ir = oversized_function(ArithKind::Sub);
    let large_pc = large_ir.blocks[0].stmts.last().unwrap().pc;
    let large = engine.compile_tfunc(&large_ir).unwrap();
    let last = engine.compile_tfunc(&small(ArithKind::Mul)).unwrap();

    // Enter every function after subsequent compilations have recycled the
    // contexts. Distinct results also catch an accidentally replaced entry.
    for _ in 0..3 {
        check_scalar_entry(&first, 40, 2, Ok(42));
        check_scalar_entry(&large, 40, 2, Ok(38));
        check_scalar_entry(&last, 40, 2, Ok(80));
        check_scalar_entry(&first, i64::MAX, 1, Err(2));
        check_scalar_entry(&large, i64::MIN, 1, Err(large_pc));
        check_scalar_entry(&last, i64::MAX, 2, Err(2));
    }
}

#[test]
fn failed_definition_clears_scratch_and_preserves_old_code() {
    let mut engine = super::JitEngine::new().expect("host ISA");
    let small = function(&[
        TOp::LoadLocal(0),
        TOp::LoadLocal(1),
        TOp::IntArith(ArithKind::Add),
    ]);
    let first = engine.compile_tfunc(&small).unwrap();
    // Reuse an already-defined symbol to make module definition fail after
    // lowering a large body. No invalid IR or platform-specific ISA is needed.
    engine.next_id = 0;
    let large_ir = oversized_function(ArithKind::Sub);
    assert!(matches!(
        engine.compile_tfunc(&large_ir),
        Err(crate::analyze::JitVerdict::NotConverged)
    ));
    assert_eq!(engine.ctx.func.dfg.num_insts(), 0);
    assert!(engine.ctx.compiled_code().is_none());
    check_scalar_entry(&first, 40, 2, Ok(42));
    check_scalar_entry(&first, i64::MAX, 1, Err(2));

    let recovered = engine.compile_tfunc(&large_ir).unwrap();
    let last = engine.compile_tfunc(&small).unwrap();
    check_scalar_entry(&recovered, 40, 2, Ok(38));
    check_scalar_entry(&last, 40, 2, Ok(42));
    check_scalar_entry(&first, 40, 2, Ok(42));
}

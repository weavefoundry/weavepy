//! The native-call ABI: the `#[repr(C)]` [`JitFrame`] the VM fills
//! before entering compiled code and reads after it exits, plus the
//! side-exit status protocol.
//!
//! A compiled frame is a single native function with the signature
//!
//! ```text
//! extern "C" fn(frame: *mut JitFrame) -> i64   // an i64 JitStatus
//! ```
//!
//! On a [`JitStatus::Returned`] exit the function has written
//! [`JitFrame::ret_bits`] / [`JitFrame::ret_tag`]. On a
//! [`JitStatus::Deopt`] exit it has written [`JitFrame::deopt_pc`] and
//! spilled the live abstract operand stack into
//! [`JitFrame::stack_spill`] / [`JitFrame::stack_tags`] (bottom-to-top)
//! with [`JitFrame::stack_len`] entries, plus written back every
//! JIT-managed local into [`JitFrame::locals`]. The VM then rebuilds its
//! interpreter state and resumes at `deopt_pc`, bit-for-bit as though
//! the JIT had never run.

/// The status returned (as an `i64`) by a compiled frame.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(i64)]
pub enum JitStatus {
    /// The frame ran to a `RETURN_VALUE`. The return value is in
    /// [`JitFrame::ret_bits`] / [`JitFrame::ret_tag`].
    Returned = 0,
    /// The frame took a side exit. The VM resumes interpretation at
    /// [`JitFrame::deopt_pc`] with the spilled stack + written-back
    /// locals.
    Deopt = 1,
    /// RFC 0059 WS3 — a native Python-to-Python call raised. The frame
    /// state is written back exactly as for [`JitStatus::Deopt`] (with
    /// the call's operands already consumed), [`JitFrame::deopt_pc`]
    /// names the `CALL` instruction for traceback attribution, and the
    /// exception itself travels through the embedder's side channel
    /// (the `wpjit_call_py` helper parked it before returning its
    /// raised status).
    Raised = 2,
    /// RFC 0070 WS2 — a generator body reached `YIELD_VALUE`. The
    /// frame state is written back exactly as for
    /// [`JitStatus::Deopt`], with [`JitFrame::deopt_pc`] naming the
    /// `YIELD_VALUE` instruction itself and the yielded value on top
    /// of the spilled stack: the embedder resumes interpretation *at*
    /// the yield, whose ordinary execution performs the suspension
    /// (park, `gi_frame` consistency, exception-state swap-out).
    /// Distinct from `Deopt` only so the embedder's deopt-backoff
    /// budget ignores it — yielding is the healthy exit of a
    /// generator activation, not a sign of shape trouble.
    Yielded = 3,
}

impl JitStatus {
    /// Decode the raw `i64` a compiled frame returns.
    #[inline]
    #[must_use]
    pub fn from_raw(v: i64) -> JitStatus {
        match v {
            0 => JitStatus::Returned,
            2 => JitStatus::Raised,
            3 => JitStatus::Yielded,
            _ => JitStatus::Deopt,
        }
    }
}

/// Status codes the embedder's `wpjit_call_py` helper returns to native
/// code (RFC 0059 WS3). Distinct from [`JitStatus`]: this is the
/// per-*call* protocol, which the compiled code translates into either
/// a pushed result, a `Deopt` exit (representation/guard trouble), or a
/// `Raised` exit (exception propagation).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(i64)]
pub enum CallStatus {
    /// The callee returned a scalar; `out_bits`/`out_tag` hold it.
    Ok = 0,
    /// The callee raised; the embedder parked the exception. The caller
    /// must take its `Raised` exit at the call's pc.
    Raised = 1,
    /// The callee returned a value native code cannot represent (or a
    /// caller guard no longer holds); the embedder parked the *result*
    /// and set `out_tag` to [`SlotTag::Boxed`]. The caller must deopt
    /// *after* the call with the result spilled — the call must never
    /// re-execute.
    Boxed = 2,
    /// RFC 0069 WS1 — the call was *rejected before running* (a method
    /// guard mismatch: different class, mutated class version, rebound
    /// `__code__`). The caller must deopt **at** the call's pc with the
    /// receiver and arguments spilled, so the interpreter re-executes
    /// the call generically. Never returned once the callee has run.
    Reject = 3,
}

/// How to interpret a `u64` slot in [`JitFrame::locals`] /
/// [`JitFrame::stack_spill`].
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u32)]
pub enum SlotTag {
    /// `i64` bit pattern → `Object::Int`.
    Int = 0,
    /// `f64` bit pattern (via `to_bits`) → `Object::Float`.
    Float = 1,
    /// `0`/`1` → `Object::Bool`.
    Bool = 2,
    /// RFC 0059 WS3 — the value is a full Python object parked in the
    /// embedder's side channel (a native call's unrepresentable
    /// result). Only ever appears in a deopt spill, never in locals.
    Boxed = 3,
    /// RFC 0061 WS5 — the value is an index into the embedder's
    /// per-entry pinned-object table (a pinned `list`). The embedder
    /// rebuilds the real object from the table on deopt/return.
    ListPin = 4,
    /// RFC 0065 WS5 — the value is an index into the embedder's
    /// per-entry pinned-object table (a pinned *instance* receiver).
    /// Same reconstruction contract as [`SlotTag::ListPin`].
    ///
    /// RFC 0070 WS1 — the lane is nullable: the bits `-1` (`u64::MAX`,
    /// never a valid pin index) stand for the `None` singleton, and
    /// the embedder rebuilds `None` instead of a table lookup.
    ObjPin = 5,
    /// RFC 0069 WS1 — the Python `None` singleton (a `ReturnNone`
    /// exit, or a provably-`None` method-call result). The bits are
    /// ignored; the embedder rebuilds `Object::None`.
    None = 6,
}

impl SlotTag {
    /// Decode a raw tag written by native code.
    #[inline]
    #[must_use]
    pub fn from_raw(v: u32) -> SlotTag {
        match v {
            1 => SlotTag::Float,
            2 => SlotTag::Bool,
            3 => SlotTag::Boxed,
            4 => SlotTag::ListPin,
            5 => SlotTag::ObjPin,
            6 => SlotTag::None,
            _ => SlotTag::Int,
        }
    }
}

/// The exchange buffer the VM passes to a compiled frame.
///
/// The VM owns the backing storage (`Vec<u64>` / `Vec<u32>`); this
/// struct holds raw pointers to it for the duration of one native call.
/// All indices the native code touches are bounded by `n_locals` /
/// `stack_cap`, which the VM sizes from the compiled frame's analysis.
#[repr(C)]
#[derive(Debug)]
pub struct JitFrame {
    /// Slot-indexed local storage, one `u64` per code-object local.
    /// Holds `i64` / `f64`-bits / `bool` per the local's stable type.
    pub locals: *mut u64,
    /// One assignment flag per local, in disjoint `n_locals`-wide storage.
    /// A nonzero flag means native code assigned this slot. On side exits,
    /// unassigned slots retain their original interpreter objects. Initialize
    /// flags to zero for a new activation and preserve them across yields.
    pub local_written: *mut u32,
    /// Number of valid entries in [`Self::locals`].
    pub n_locals: u32,
    /// OSR entry: the bytecode pc to begin execution at. `0` enters at
    /// the function start; a recognized loop-header pc enters mid-frame
    /// through the entry dispatch (RFC 0059 WS3b).
    pub entry_pc: u32,

    /// `Returned`: the return value's bit pattern. Also serves as the
    /// out-slot the `wpjit_call_py` helper writes a call result into
    /// (it is dead between calls and only meaningful at `Returned`).
    pub ret_bits: u64,
    /// `Returned`: the return value's [`SlotTag`]. Doubles as the call
    /// helper's out-tag, as above.
    pub ret_tag: u32,

    /// `Deopt`: the bytecode pc to resume interpretation at.
    pub deopt_pc: u32,
    /// `Deopt`: spilled abstract operand stack, bottom-to-top.
    pub stack_spill: *mut u64,
    /// `Deopt`: matching [`SlotTag`]s for [`Self::stack_spill`].
    pub stack_tags: *mut u32,
    /// `Deopt`: number of spilled stack entries.
    pub stack_len: u32,
    /// Capacity of [`Self::stack_spill`] / [`Self::stack_tags`].
    pub stack_cap: u32,

    /// RFC 0059 WS3 — opaque embedder context for the `wpjit_call_py`
    /// helper (the VM's per-activation `CallCtx`: interpreter pointer,
    /// callee table, caller guards). Null when the frame makes no calls.
    pub ctx: *mut u8,
    /// Argument marshal buffer for native Python-to-Python calls, at
    /// least `max_call_args` wide.
    pub call_args: *mut u64,
    /// Matching [`SlotTag`]s for [`Self::call_args`].
    pub call_tags: *mut u32,
}

impl JitFrame {
    /// Reinterpret an `f64` as the `u64` stored in a slot.
    #[inline]
    #[must_use]
    pub fn f64_to_bits(v: f64) -> u64 {
        v.to_bits()
    }

    /// Reinterpret a slot's `u64` as the `f64` it encodes.
    #[inline]
    #[must_use]
    pub fn bits_to_f64(bits: u64) -> f64 {
        f64::from_bits(bits)
    }
}

/// The embedder's Python-to-Python call helper (RFC 0059 WS3). Compiled
/// code marshals the arguments into [`JitFrame::call_args`] /
/// [`JitFrame::call_tags`] (bottom-to-top), then calls this with the
/// callee-table `token`, the argument count, and the [`SlotTag`] the
/// caller expects back. The helper performs the full call through the
/// interpreter and returns a [`CallStatus`]; on `Ok` it has written the
/// result into [`JitFrame::ret_bits`] / [`JitFrame::ret_tag`].
///
/// # Safety contract (for implementors)
///
/// `frame` is the same pointer the native function was entered with; it
/// and its buffers stay valid for the whole native activation. The
/// helper may run arbitrary Python (including re-entering compiled
/// code) but must not unwind across the FFI boundary.
pub type CallPyHelper =
    unsafe extern "C" fn(frame: *mut JitFrame, token: u32, argc: u32, expect_tag: u32) -> i64;

/// The registered [`CallPyHelper`], as a `usize` so lowering can burn it
/// into compiled code as an absolute address. `0` = not registered
/// (frames containing calls then refuse to compile).
static CALL_PY_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide Python-call helper. Must be called before
/// the first frame containing a `CallPy` is compiled; later calls must
/// pass the same function (compiled code holds burned-in addresses).
pub fn register_call_py_helper(helper: CallPyHelper) {
    CALL_PY_HELPER.store(helper as usize, std::sync::atomic::Ordering::Release);
}

/// The registered helper's address, or 0 when absent.
#[must_use]
pub(crate) fn call_py_helper_addr() -> usize {
    CALL_PY_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0061 WS5 — the embedder's pinned-list *read* helper. `pin`
/// indexes the per-entry pinned-object table on the embedder context;
/// `idx` is the (possibly negative) Python index. Returns `0` (Ok) with
/// the element's bits written into [`JitFrame::ret_bits`], or non-zero
/// when the access must deopt (out of range, or the element no longer
/// matches the pinned lane — aliased mutation through a callee).
///
/// # Safety contract (for implementors)
///
/// Same as [`CallPyHelper`]: `frame`/`ctx` are the live buffers of the
/// current native activation. The helper must not run Python code and
/// must not unwind across the FFI boundary.
pub type ListGetHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, idx: i64) -> i64;

/// RFC 0061 WS5 — the embedder's pinned-list *write* helper. The value
/// to store is pre-staged in [`JitFrame::ret_bits`] (interpreted per
/// the pin's element lane); returns `0` (Ok) or non-zero to deopt
/// (out of range). Same safety contract as [`ListGetHelper`].
pub type ListSetHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, idx: i64) -> i64;

static LIST_GET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static LIST_SET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide pinned-list helpers (RFC 0061 WS5). Must
/// precede the first compile of a frame containing list ops; later
/// calls must pass the same functions.
pub fn register_list_helpers(get: ListGetHelper, set: ListSetHelper) {
    LIST_GET_HELPER.store(get as usize, std::sync::atomic::Ordering::Release);
    LIST_SET_HELPER.store(set as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn list_get_helper_addr() -> usize {
    LIST_GET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn list_set_helper_addr() -> usize {
    LIST_SET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0065 WS5 — the embedder's pinned-list *length* helper. Returns
/// the list's length (always `>= 0`), or a negative value on a
/// pin-table miss (defensive — deopts). Never runs Python code and
/// never drops a heap object; same safety contract as
/// [`ListGetHelper`].
pub type ListLenHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64) -> i64;

/// RFC 0065 WS5 — the embedder's pinned-list *append* helper. The
/// value to append is pre-staged in [`JitFrame::ret_bits`] with its
/// [`JitFrame::ret_tag`]. Generic lists accept native scalars or object
/// pins; typed lists require their exact element lane. Returns `0` (Ok) or
/// non-zero to deopt (defensive). Same safety contract as
/// [`ListGetHelper`].
pub type ListAppendHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64) -> i64;

static LIST_LEN_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static LIST_APPEND_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide pinned-list length/append helpers
/// (RFC 0065 WS5). Must precede the first compile of a frame
/// containing `ListLen`/`ListAppend` ops.
pub fn register_list_extra_helpers(len: ListLenHelper, append: ListAppendHelper) {
    LIST_LEN_HELPER.store(len as usize, std::sync::atomic::Ordering::Release);
    LIST_APPEND_HELPER.store(append as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn list_len_helper_addr() -> usize {
    LIST_LEN_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn list_append_helper_addr() -> usize {
    LIST_APPEND_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0076 WS6 — the embedder's closure-cell *read* helper. `idx`
/// indexes the activation's cell array (`cellvars` then `freevars`,
/// the interpreter's `LOAD_DEREF` layout) and `lane` is the site's
/// burned [`crate::value::JitType::cell_lane_code`] — both
/// compile-time constants. Returns `0` (Ok) with the cell value's bits in
/// [`JitFrame::ret_bits`], or non-zero to deopt — the cell is unbound
/// (the interpreter re-executes and raises the exact
/// `NameError`/`UnboundLocalError`) or its value left the burned lane
/// (an aliased write through another closure). Never runs Python code;
/// same safety contract as [`ListGetHelper`].
pub type CellGetHelper = unsafe extern "C" fn(frame: *mut JitFrame, idx: i64, lane: i64) -> i64;

/// RFC 0076 WS6 — the embedder's closure-cell *write* helper. The
/// value is pre-staged in [`JitFrame::ret_bits`], interpreted per the
/// site's burned `lane` code; returns `0` (Ok) or non-zero to deopt
/// (a displaced heap value must drop on the interpreter's store
/// path). Same safety contract as [`ListGetHelper`].
pub type CellSetHelper = unsafe extern "C" fn(frame: *mut JitFrame, idx: i64, lane: i64) -> i64;

static CELL_GET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static CELL_SET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide closure-cell helpers (RFC 0076 WS6).
/// Must precede the first compile of a frame containing
/// `CellGet`/`CellSet` ops.
pub fn register_cell_helpers(get: CellGetHelper, set: CellSetHelper) {
    CELL_GET_HELPER.store(get as usize, std::sync::atomic::Ordering::Release);
    CELL_SET_HELPER.store(set as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn cell_get_helper_addr() -> usize {
    CELL_GET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn cell_set_helper_addr() -> usize {
    CELL_SET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0071 WS4 — the embedder's list-loop *step* helper, called by
/// the [`crate::ir::TTerm::ForList`] terminator each iteration with
/// the pinned list and the current index. Re-checks the index against
/// the live length and re-validates the element lane. Returns:
///
/// - `0` — an element was yielded; its lane-typed bits are in
///   [`JitFrame::ret_bits`] (an object element was pinned; `None`
///   rides as `-1`);
/// - `1` — the list is exhausted (index ≥ live length);
/// - any other value — deopt at the header pc (element-shape
///   surprise, pin miss, or pin-cap pressure).
///
/// Never runs Python code; same safety contract as [`ListGetHelper`].
pub type ListNextHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, idx: i64) -> i64;

static LIST_NEXT_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide list-loop step helper (RFC 0071 WS4).
/// Must precede the first compile of a frame containing a `ForList`
/// terminator.
pub fn register_list_next_helper(next: ListNextHelper) {
    LIST_NEXT_HELPER.store(next as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn list_next_helper_addr() -> usize {
    LIST_NEXT_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0071 WS6 — the embedder's pinned-`str` equality helper. Both
/// operands are pin-table indices; identical pins and pointer-equal
/// payloads answer before any content compare. Returns `0` (unequal),
/// `1` (equal), or any other value to deopt (pin miss — defensive).
/// Never runs Python code; same safety contract as [`ListGetHelper`].
pub type StrEqHelper = unsafe extern "C" fn(frame: *mut JitFrame, a: i64, b: i64) -> i64;

/// RFC 0071 WS6 — the embedder's pinned-`str`/`bytes` *length* helper
/// (`str` answers the character count, `bytes` the byte count).
/// Returns the length (always `>= 0`) or a negative value to deopt
/// (pin miss). Same safety contract as [`ListGetHelper`].
pub type StrLenHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64) -> i64;

/// RFC 0071 WS6 — the embedder's pinned-`bytes` subscript helper.
/// Returns `0` with the byte value in [`JitFrame::ret_bits`], or
/// non-zero to deopt (out of range, pin miss); negative indices are
/// normalized against the length first. Same safety contract as
/// [`ListGetHelper`].
pub type BytesGetHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, idx: i64) -> i64;

static STR_EQ_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static STR_LEN_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static BYTES_LEN_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static BYTES_GET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide string/bytes read helpers (RFC 0071 WS6).
/// Must precede the first compile of a frame containing `StrEq`,
/// `StrLen`, `BytesLen`, or `BytesGetItem` ops.
pub fn register_str_helpers(
    eq: StrEqHelper,
    str_len: StrLenHelper,
    bytes_len: StrLenHelper,
    bytes_get: BytesGetHelper,
) {
    STR_EQ_HELPER.store(eq as usize, std::sync::atomic::Ordering::Release);
    STR_LEN_HELPER.store(str_len as usize, std::sync::atomic::Ordering::Release);
    BYTES_LEN_HELPER.store(bytes_len as usize, std::sync::atomic::Ordering::Release);
    BYTES_GET_HELPER.store(bytes_get as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn str_eq_helper_addr() -> usize {
    STR_EQ_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn str_len_helper_addr() -> usize {
    STR_LEN_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn bytes_len_helper_addr() -> usize {
    BYTES_LEN_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn bytes_get_helper_addr() -> usize {
    BYTES_GET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0073 WS2 — key-lane discriminant passed to the dict helpers
/// (burned per site by the lowering): the key operand's bits are a
/// signed integer.
pub const DICT_KEY_INT: i64 = 0;
/// The key operand's bits are a pin-table index of an exact `str`.
pub const DICT_KEY_STR: i64 = 1;
/// RFC 0073 WS2 — value-lane discriminants for the dict helpers.
pub const DICT_VAL_INT: i64 = 0;
pub const DICT_VAL_FLOAT: i64 = 1;
/// The value rides the nullable object lane (pin index, `-1` = `None`).
pub const DICT_VAL_OBJ: i64 = 2;

/// RFC 0073 WS2 — the shared dict-access helper shape:
/// `(frame, pin, key_bits, key_tag, val_tag) -> status` with `status`
/// `0` = ok (result, if any, in `ret_bits`), `1` = deopt at the op's
/// pc, `2` = raised (the helper parked the exception — the missing-key
/// `KeyError`). For `set` the value is pre-staged in `ret_bits`; for
/// `contains` the `bool` result lands in `ret_bits` and `val_tag` is
/// ignored. Same safety contract as [`ListGetHelper`].
pub type DictAccessHelper = unsafe extern "C" fn(
    frame: *mut JitFrame,
    pin: i64,
    key_bits: i64,
    key_tag: i64,
    val_tag: i64,
) -> i64;

static DICT_GET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static DICT_SET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static DICT_CONTAINS_HELPER: std::sync::atomic::AtomicUsize =
    std::sync::atomic::AtomicUsize::new(0);
static DICT_LEN_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide dict-lane helpers (RFC 0073 WS2). Must
/// precede the first compile of a frame containing `DictGet`,
/// `DictSet`, `DictContains`, or `DictLen` ops. `len` shares the
/// [`StrLenHelper`] `(frame, pin) -> status` shape.
pub fn register_dict_helpers(
    get: DictAccessHelper,
    set: DictAccessHelper,
    contains: DictAccessHelper,
    len: StrLenHelper,
) {
    DICT_GET_HELPER.store(get as usize, std::sync::atomic::Ordering::Release);
    DICT_SET_HELPER.store(set as usize, std::sync::atomic::Ordering::Release);
    DICT_CONTAINS_HELPER.store(contains as usize, std::sync::atomic::Ordering::Release);
    DICT_LEN_HELPER.store(len as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn dict_get_helper_addr() -> usize {
    DICT_GET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn dict_set_helper_addr() -> usize {
    DICT_SET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn dict_contains_helper_addr() -> usize {
    DICT_CONTAINS_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn dict_len_helper_addr() -> usize {
    DICT_LEN_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0071 WS4 — the embedder's opaque-iterator *capture* helper,
/// called by [`crate::ir::TOp::IterCapture`] behind an erased
/// `GET_ITER` whose operand rides the object lane. Admits only
/// objects where `iter(x) is x` (generators, builtin iterators);
/// returns `0` (the pin may be stored as the loop's iterator) or
/// non-zero to deopt (the interpreter executes the `GET_ITER` — and
/// the loop — generically). Never runs Python code; same safety
/// contract as [`ListGetHelper`].
pub type GetIterHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64) -> i64;

/// RFC 0071 WS4 — the embedder's opaque-iterator *step* helper,
/// called by the [`crate::ir::TTerm::ForIter`] terminator each
/// iteration with the pinned iterator and the compiled element lane
/// (a [`SlotTag`] discriminant). **Runs Python code** (the iterator
/// protocol through the interpreter core — generator bodies,
/// `__next__`). Returns:
///
/// - `0` — an element was yielded in the compiled lane; its bits are
///   in [`JitFrame::ret_bits`] (an object element was pinned; `None`
///   rides as `-1`);
/// - `1` — the iterator is exhausted (the pin stays — it may be
///   shared with a local slot — and dies with the activation under
///   RFC 0070's runtime-pin drain);
/// - `2` — deopt at the header pc, nothing consumed (pin miss);
/// - `3` — the element was consumed but is outside the compiled
///   lane: its raw object was pinned (index in `ret_bits`, `None` as
///   `-1`) and the deopt resumes at the fused store's pc with the
///   element spilled on top;
/// - `4` — the iterator raised; the exception is parked for the
///   ordinary `Raised` exit at the header pc.
pub type IterNextHelper =
    unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, elem_tag: i64) -> i64;

/// RFC 0071 WS4 — the embedder's `BUILD_LIST` helper: build a fresh
/// list from `n` elements staged in the marshal buffer (lane-tagged
/// per `elem_tag`; `none_fill` passes `n` with an empty buffer), pin
/// it, and return the pin index — or a negative value to deopt (cap
/// pressure). RFC 0073 WS1 — a *negative* `elem_tag` means the
/// elements carry per-slot [`SlotTag`]s in [`JitFrame::call_tags`]
/// (a mixed-lane literal); each element boxes by its own tag and the
/// result rides the object-element lane. Never runs Python code;
/// same safety contract as [`ListGetHelper`].
pub type BuildListHelper =
    unsafe extern "C" fn(frame: *mut JitFrame, n: i64, elem_tag: i64, none_fill: i64) -> i64;

/// RFC 0073 WS1 — the embedder's `BUILD_TUPLE` helper: build a fresh
/// tuple from `n` elements staged in the marshal buffer with per-slot
/// [`SlotTag`]s in [`JitFrame::call_tags`], pin it on the object
/// lane, and return the pin index — or a negative value to deopt
/// (cap pressure). Never runs Python code; same safety contract as
/// [`ListGetHelper`].
pub type BuildTupleHelper = unsafe extern "C" fn(frame: *mut JitFrame, n: i64) -> i64;

/// RFC 0071 WS4 — the embedder's `list * int` helper: build the
/// repeated list (element `Arc`s shared, CPython's aliasing), pin it
/// on the same lane, and return the pin index — or a negative value
/// to deopt. Never runs Python code.
pub type ListRepeatHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, count: i64) -> i64;

/// RFC 0071 WS4 — the embedder's list *slice* helper (`xs[a:b]`,
/// unit step): bounds are pre-clamped CPython-style; `i64::MIN`
/// marks an absent bound. Returns the fresh pin index or a negative
/// value to deopt. Never runs Python code.
pub type ListSliceHelper =
    unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, start: i64, stop: i64) -> i64;

static GET_ITER_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static ITER_NEXT_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static BUILD_LIST_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static BUILD_TUPLE_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static LIST_REPEAT_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static LIST_SLICE_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide opaque-iterator and list/tuple
/// construction helpers (RFC 0071 WS4 / RFC 0073 WS1). Must precede
/// the first compile of a frame containing `ForIter`, `IterCapture`,
/// `BuildList`, `BuildTuple`, `ListRepeat`, or `ListSlice`.
pub fn register_iter_helpers(
    get_iter: GetIterHelper,
    next: IterNextHelper,
    build: BuildListHelper,
    build_tuple: BuildTupleHelper,
    repeat: ListRepeatHelper,
    slice: ListSliceHelper,
) {
    GET_ITER_HELPER.store(get_iter as usize, std::sync::atomic::Ordering::Release);
    ITER_NEXT_HELPER.store(next as usize, std::sync::atomic::Ordering::Release);
    BUILD_LIST_HELPER.store(build as usize, std::sync::atomic::Ordering::Release);
    BUILD_TUPLE_HELPER.store(build_tuple as usize, std::sync::atomic::Ordering::Release);
    LIST_REPEAT_HELPER.store(repeat as usize, std::sync::atomic::Ordering::Release);
    LIST_SLICE_HELPER.store(slice as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn get_iter_helper_addr() -> usize {
    GET_ITER_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn iter_next_helper_addr() -> usize {
    ITER_NEXT_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn build_list_helper_addr() -> usize {
    BUILD_LIST_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn build_tuple_helper_addr() -> usize {
    BUILD_TUPLE_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn list_repeat_helper_addr() -> usize {
    LIST_REPEAT_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn list_slice_helper_addr() -> usize {
    LIST_SLICE_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static BUILD_MAP_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide `BUILD_MAP` helper (RFC 0073 WS2): build
/// a fresh dict from `n` key/value pairs staged in the marshal buffer
/// (interleaved `k1, v1, …`, per-slot tags), pin it, and return the
/// pin index — or a negative value to deopt (cap pressure, or a key
/// outside the `str`/`int` lanes). Shares the [`BuildTupleHelper`]
/// `(frame, n) -> i64` shape (`n` counts *pairs*). Must precede the
/// first compile of a frame containing `BuildMap`.
pub fn register_build_map_helper(f: BuildTupleHelper) {
    BUILD_MAP_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn build_map_helper_addr() -> usize {
    BUILD_MAP_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static CONST_STR_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide `str`-constant helper (RFC 0073 WS2):
/// materialize the activation's code-object constant `idx` as an
/// exact `str` pin, memoized per `(activation, idx)` so loops reuse
/// one pin. Returns the pin index or a negative value to deopt (cap
/// pressure). Shares the [`StrLenHelper`] `(frame, i64) -> i64`
/// shape. Must precede the first compile of a frame containing
/// `PushConstStr`.
pub fn register_const_str_helper(f: StrLenHelper) {
    CONST_STR_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn const_str_helper_addr() -> usize {
    CONST_STR_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static CONST_TUPLE_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static TUPLE_LEN_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register helpers for immutable tuple constants and exact-tuple length.
/// Both return a negative value to deopt without running Python code.
/// Registration must precede compilation of either operation.
pub fn register_tuple_read_helpers(constant: StrLenHelper, len: StrLenHelper) {
    CONST_TUPLE_HELPER.store(constant as usize, std::sync::atomic::Ordering::Release);
    TUPLE_LEN_HELPER.store(len as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn const_tuple_helper_addr() -> usize {
    CONST_TUPLE_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn tuple_len_helper_addr() -> usize {
    TUPLE_LEN_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static UNBOX_INT_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the exact-integer pin guard. On success it writes the integer
/// to frame.ret_bits and returns zero. A nonzero status deopts without
/// invoking Python code or changing the pinned object.
pub fn register_unbox_int_helper(f: StrLenHelper) {
    UNBOX_INT_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn unbox_int_helper_addr() -> usize {
    UNBOX_INT_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static DICT_ITER_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide dict-iterator capture helper (RFC 0073
/// WS2): materialize the pinned exact dict's real `DictKeys` iterator
/// and answer its fresh pin index — or a negative value to deopt
/// (pin surprise, cap pressure). Shares the [`StrLenHelper`]
/// `(frame, pin) -> i64` shape. Must precede the first compile of a
/// frame containing `DictIterNew`.
pub fn register_dict_iter_helper(f: StrLenHelper) {
    DICT_ITER_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn dict_iter_helper_addr() -> usize {
    DICT_ITER_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static STR_CONCAT_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static STR_GET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static BUILD_STRING_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide string write-lane helpers (RFC 0073
/// WS3): `concat` joins two `str` pins (`(frame, a_pin, b_pin) ->
/// pin-or-negative`, the [`ListGetHelper`] shape), `get` is ASCII-only
/// `s[i]` (`(frame, pin, idx) -> pin-or-negative`, same shape), and
/// `build` concatenates `n` staged `str` pins (`(frame, n) ->
/// pin-or-negative`, the [`BuildTupleHelper`] shape). Must precede the
/// first compile of a frame containing `StrConcat`, `StrGetItem`, or
/// `BuildString`.
pub fn register_str_write_helpers(
    concat: ListGetHelper,
    get: ListGetHelper,
    build: BuildTupleHelper,
) {
    STR_CONCAT_HELPER.store(concat as usize, std::sync::atomic::Ordering::Release);
    STR_GET_HELPER.store(get as usize, std::sync::atomic::Ordering::Release);
    BUILD_STRING_HELPER.store(build as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn str_concat_helper_addr() -> usize {
    STR_CONCAT_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn str_get_helper_addr() -> usize {
    STR_GET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn build_string_helper_addr() -> usize {
    BUILD_STRING_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0073 WS2 — the `wpjit_iter_next` element discriminant for an
/// exact-`str` element lane (a dict-keys loop over str keys). The
/// [`SlotTag`] domain collapses `Str` into `ObjPin`, whose packing
/// only admits instances; this out-of-band value tells the step
/// helper to pin exact-`str` elements (anything else surrenders the
/// consumed element through the store-pc deopt).
pub const ITER_ELEM_STR: i64 = 100;

/// RFC 0067 WS2 — the embedder's eval-breaker poll. Called from loop
/// headers every `JIT_POLL_STRIDE` iterations: the embedder performs
/// its cooperative GIL hand-off inline (no interpreter state needed)
/// and returns non-zero iff pending work *requires* the interpreter
/// (signals, parked finalizers, async exceptions, finalization,
/// observer installation) — the caller then takes the standard deopt
/// exit at the loop-header pc so the interpreter's prologue handles
/// the work with full fidelity.
///
/// # Safety contract (for implementors)
///
/// Same as [`ListGetHelper`]: `frame` is the live buffer of the
/// current native activation. The helper may block (GIL hand-off) but
/// must not run Python code and must not unwind across the FFI
/// boundary.
pub type PollHelper = unsafe extern "C" fn(frame: *mut JitFrame) -> i64;

/// How many loop iterations run between two `PollHelper` calls. A
/// tight native loop covers a stride in single-digit microseconds —
/// far inside the 5 ms GIL switch interval — and the quiet-path cost
/// is one register decrement + predictable branch per iteration.
pub const JIT_POLL_STRIDE: i64 = 1024;

static POLL_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide eval-breaker poll helper (RFC 0067 WS2).
/// Should precede the first compile; frames compiled while it is
/// unregistered (e.g. this crate's standalone unit tests) simply emit
/// no polls — a liveness property, never a correctness one.
pub fn register_poll_helper(poll: PollHelper) {
    POLL_HELPER.store(poll as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn poll_helper_addr() -> usize {
    POLL_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0065 WS5 — the embedder's pinned-instance attribute *read*
/// helper. `pin` indexes the pinned-object table; `site` indexes the
/// compiled frame's attribute-site table (name, class fingerprint,
/// dict index, value lane). Returns `0` (Ok) with the value's bits in
/// [`JitFrame::ret_bits`], or non-zero to deopt (class changed, dict
/// reshaped, value left its lane). Never runs Python code; same
/// safety contract as [`CallPyHelper`].
pub type AttrGetHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, site: i64) -> i64;

/// RFC 0065 WS5 — the embedder's pinned-instance attribute *write*
/// helper. The value is pre-staged in [`JitFrame::ret_bits`]
/// (interpreted per the site's lane); returns `0` (Ok) or non-zero to
/// deopt — including when the *displaced* value is a heap object,
/// whose drop belongs to the interpreter's store path. Same safety
/// contract as [`AttrGetHelper`].
pub type AttrSetHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, site: i64) -> i64;

static ATTR_GET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static ATTR_SET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide pinned-instance attribute helpers
/// (RFC 0065 WS5). Must precede the first compile of a frame
/// containing `AttrGet`/`AttrSet` ops.
pub fn register_attr_helpers(get: AttrGetHelper, set: AttrSetHelper) {
    ATTR_GET_HELPER.store(get as usize, std::sync::atomic::Ordering::Release);
    ATTR_SET_HELPER.store(set as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn attr_get_helper_addr() -> usize {
    ATTR_GET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn attr_set_helper_addr() -> usize {
    ATTR_SET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0069 WS1 — the embedder's guarded method-call helper. Compiled
/// code marshals `argc` scalar arguments into [`JitFrame::call_args`] /
/// [`JitFrame::call_tags`] (bottom-to-top, receiver *not* included),
/// then calls this with the method-table `token`, the receiver's pin
/// index, the argument count, and the expected result [`SlotTag`].
/// The helper re-validates the burned-in class fingerprint and
/// `__code__` identity against the live receiver, performs the call
/// (natively when the callee is compiled and shape-eligible, through
/// the interpreter otherwise), and returns a [`CallStatus`] — with
/// [`CallStatus::Reject`] when the guard failed and the call must be
/// re-executed by the interpreter at the call's pc.
///
/// # Safety contract (for implementors)
///
/// Same as [`CallPyHelper`].
pub type CallMethodHelper = unsafe extern "C" fn(
    frame: *mut JitFrame,
    token: u32,
    recv_pin: i64,
    argc: u32,
    expect_tag: u32,
) -> i64;

static CALL_METHOD_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide method-call helper (RFC 0069 WS1). Must
/// precede the first compile of a frame containing `CallMethod` ops.
pub fn register_call_method_helper(helper: CallMethodHelper) {
    CALL_METHOD_HELPER.store(helper as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn call_method_helper_addr() -> usize {
    CALL_METHOD_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static STR_METHOD_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide native `str`-method helper (RFC 0073
/// WS3). Shares [`CallMethodHelper`]'s shape — the `token` parameter
/// carries the burned [`crate::ir::StrMethod`] discriminant instead
/// of a site token. Must precede the first compile of a frame
/// containing `CallStrMethod` ops.
pub fn register_str_method_helper(helper: CallMethodHelper) {
    STR_METHOD_HELPER.store(helper as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn str_method_helper_addr() -> usize {
    STR_METHOD_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0069 WS2 — a unary libm-backed math helper (`sin`/`cos`),
/// bit-identical to what the interpreter's `math` module computes.
/// Never runs Python code, never unwinds across the FFI boundary.
pub type MathUnaryHelper = extern "C" fn(f64) -> f64;

/// RFC 0069 WS2 — a binary float helper carrying Python's floor-div /
/// mod semantics (result sign follows the divisor). The zero-divisor
/// case deopts *before* the helper is called, so implementations may
/// assume a non-zero divisor.
pub type MathBinaryHelper = extern "C" fn(f64, f64) -> f64;

static MATH_SIN_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static MATH_COS_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static FLOAT_FLOORDIV_HELPER: std::sync::atomic::AtomicUsize =
    std::sync::atomic::AtomicUsize::new(0);
static FLOAT_MOD_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide math helpers (RFC 0069 WS2): the libm
/// `sin`/`cos` intrinsics and the Python-semantics float floor-div /
/// mod. Must precede the first compile of a frame containing
/// `MathIntrinsic` or float floor-div/mod ops.
pub fn register_math_helpers(
    sin: MathUnaryHelper,
    cos: MathUnaryHelper,
    floordiv: MathBinaryHelper,
    fmod: MathBinaryHelper,
) {
    MATH_SIN_HELPER.store(sin as usize, std::sync::atomic::Ordering::Release);
    MATH_COS_HELPER.store(cos as usize, std::sync::atomic::Ordering::Release);
    FLOAT_FLOORDIV_HELPER.store(floordiv as usize, std::sync::atomic::Ordering::Release);
    FLOAT_MOD_HELPER.store(fmod as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn math_sin_helper_addr() -> usize {
    MATH_SIN_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn math_cos_helper_addr() -> usize {
    MATH_COS_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn float_floordiv_helper_addr() -> usize {
    FLOAT_FLOORDIV_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn float_mod_helper_addr() -> usize {
    FLOAT_MOD_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0074 WS2 — the embedder's *opaque-call* helper
/// ([`crate::ir::TOp::CallDyn`]). Compiled code marshals the `argc`
/// positional (plus `kwc` keyword) values into [`JitFrame::call_args`]
/// / [`JitFrame::call_tags`] (bottom-to-top, callee *not* included),
/// then calls this with the callee's pin index, both counts, and —
/// for the keyword form — the constant-pool index of the interned
/// kwnames tuple. The helper boxes everything, runs the call through
/// the interpreter core (**arbitrary Python runs**; the dirtiness
/// discipline applies), and returns a [`CallStatus`]:
///
/// - `Ok` — the pinned result's index is in [`JitFrame::ret_bits`]
///   (`None` as `-1`); native execution continues;
/// - `Raised` — the exception is parked; exit `Raised` at the call pc;
/// - `Boxed` — the call *completed* but a caller guard was
///   invalidated (or pin-cap pressure): the result is parked and the
///   caller deopts *after* the call — never re-executed;
/// - `Reject` — the callee pin didn't resolve (defensive, before any
///   Python ran): deopt at the call pc and re-execute generically.
///
/// # Safety contract (for implementors)
///
/// Same as [`CallPyHelper`].
pub type CallDynHelper = unsafe extern "C" fn(
    frame: *mut JitFrame,
    callee_pin: i64,
    argc: u32,
    kwc: u32,
    names: u32,
) -> i64;

static CALL_DYN_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static CALL_DYN_INT_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide opaque-call helper (RFC 0074 WS2). Must
/// precede the first compile of a frame containing `CallDyn` ops.
pub fn register_call_dyn_helper(helper: CallDynHelper) {
    CALL_DYN_HELPER.store(helper as usize, std::sync::atomic::Ordering::Release);
}

/// Register a generic-call helper that returns exact integers unboxed.
/// Other completed results use `Boxed`, including booleans and subclasses.
/// Argument staging and exception/rejection statuses match [`CallDynHelper`].
pub fn register_call_dyn_int_helper(helper: CallDynHelper) {
    CALL_DYN_INT_HELPER.store(helper as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn call_dyn_int_helper_addr() -> usize {
    CALL_DYN_INT_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn call_dyn_helper_addr() -> usize {
    CALL_DYN_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0074 WS2/WS4 — the embedder's *generic attribute* helpers
/// ([`crate::ir::TOp::DynAttrGet`] / [`crate::ir::TOp::DynAttrSet`]).
/// Shape: `(frame, pin, name_idx) -> status` (the [`ListGetHelper`]
/// signature). Both run the interpreter's exact attribute machinery
/// (**arbitrary Python may run** — descriptors, `__getattr__`,
/// `__setattr__`; the dirtiness discipline applies). For the store,
/// the value is staged in `call_args[0]` / `call_tags[0]`. Status:
///
/// - `0` — ok; for the get, the loaded value's fresh pin index is in
///   [`JitFrame::ret_bits`] (`None` as `-1`);
/// - `1` — raised (exact `AttributeError` and friends): exit `Raised`
///   at this pc, receiver consumed;
/// - `2` — the access *completed* but a guard was invalidated (or,
///   for the get, pin-cap pressure): the result (get) is parked and
///   the caller deopts at the *next* pc — never re-executed;
/// - `3` — rejected before any Python ran (pin miss — defensive):
///   deopt at this pc and re-execute generically.
pub type DynAttrHelper = unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, name: i64) -> i64;

static DYN_ATTR_GET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static DYN_ATTR_SET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide generic attribute helpers (RFC 0074
/// WS2/WS4). Must precede the first compile of a frame containing
/// `DynAttrGet`/`DynAttrSet` ops.
pub fn register_dyn_attr_helpers(get: DynAttrHelper, set: DynAttrHelper) {
    DYN_ATTR_GET_HELPER.store(get as usize, std::sync::atomic::Ordering::Release);
    DYN_ATTR_SET_HELPER.store(set as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn dyn_attr_get_helper_addr() -> usize {
    DYN_ATTR_GET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn dyn_attr_set_helper_addr() -> usize {
    DYN_ATTR_SET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// Generic subscription with an integer index and an unboxed integer result.
/// Arguments are `(frame, receiver_pin, index)`. Statuses follow
/// [`DynAttrHelper`]: 0 returns integer bits in `ret_bits`, 1 raises at this
/// instruction, 2 parks an already-computed noninteger or invalidated result
/// and resumes at the next instruction, and 3 rejects before any lookup.
pub type ObjGetItemIntHelper = DynAttrHelper;

static OBJ_GETITEM_INT_HELPER: std::sync::atomic::AtomicUsize =
    std::sync::atomic::AtomicUsize::new(0);

/// Register the subscription helper before compiling [`crate::TOp::ObjGetItemInt`].
pub fn register_obj_getitem_int_helper(helper: ObjGetItemIntHelper) {
    OBJ_GETITEM_INT_HELPER.store(helper as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn obj_getitem_int_helper_addr() -> usize {
    OBJ_GETITEM_INT_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static TRUTH_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// RFC 0076 WS8 — register the process-wide truthiness helper
/// ([`crate::ir::TOp::Truth`]). Shape: `(frame, pin, reserved) ->
/// status` (the [`ListGetHelper`] signature; `reserved` is unused).
/// The pure kinds (`None`, scalars, container emptiness) answer
/// without running Python; an instance carrying `__bool__`/`__len__`
/// (or a foreign value's `nb_bool`) dispatches the interpreter's
/// exact protocol — **arbitrary Python may run**, the dirtiness
/// discipline applies. Status protocol as [`DynAttrHelper`]: `0` ok
/// (the bool's bits in [`JitFrame::ret_bits`]), `1` raised, `2`
/// completed-but-guards-fell (parked bool, deopt at the *next* pc —
/// the dunder never re-runs), `3` rejected before any Python ran.
/// Must precede the first compile of a frame containing `Truth` ops.
pub fn register_truth_helper(f: DynAttrHelper) {
    TRUTH_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn truth_helper_addr() -> usize {
    TRUTH_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static CONTAINS_DYN_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// RFC 0076 WS8 — register the process-wide generic membership helper
/// ([`crate::ir::TOp::ContainsDyn`]). Shape: `(frame, pin, negate) ->
/// status` (the [`DynAttrHelper`] signature). The item is staged
/// tag-typed in `call_args[0]` / `call_tags[0]`; the helper runs the
/// interpreter's exact `in` protocol (**arbitrary Python may run** —
/// `__contains__`, `__eq__` per element; the dirtiness discipline
/// applies) and answers the already-negated bool in
/// [`JitFrame::ret_bits`]. Status protocol as the truth helper. Must
/// precede the first compile of a frame containing `ContainsDyn` ops.
pub fn register_contains_dyn_helper(f: DynAttrHelper) {
    CONTAINS_DYN_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn contains_dyn_helper_addr() -> usize {
    CONTAINS_DYN_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static BUILD_SET_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// RFC 0076 WS8 — register the process-wide set-construction helper
/// ([`crate::ir::TOp::BuildSet`]). Shares the [`BuildTupleHelper`]
/// `(frame, n) -> pin-or-negative` shape: `n` per-element-tagged
/// entries stage in the marshal buffer; the helper builds the fresh
/// set and answers its pin index — or negative to deopt (cap
/// pressure, or an element whose hashing could run Python — the
/// interpreter re-executes the `BUILD_SET` generically). Never runs
/// Python code. Must precede the first compile of a frame containing
/// `BuildSet` ops.
pub fn register_build_set_helper(f: BuildTupleHelper) {
    BUILD_SET_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn build_set_helper_addr() -> usize {
    BUILD_SET_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static GLOBAL_OBJ_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide obj-global helper (RFC 0074 WS1,
/// [`crate::ir::TOp::PushGlobalObj`]): pin the snapshotted object
/// behind obj-global table index `token`, memoized per
/// `(activation, token)`, and return the pin index — or a negative
/// value to deopt (lane surprise — impossible while the identity
/// guard holds — or cap pressure). Never runs Python code. Shares the
/// [`StrLenHelper`] `(frame, i64) -> i64` shape. Must precede the
/// first compile of a frame containing `PushGlobalObj`.
pub fn register_global_obj_helper(f: StrLenHelper) {
    GLOBAL_OBJ_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn global_obj_helper_addr() -> usize {
    GLOBAL_OBJ_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

static ITER_NEW_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide *generic* iterator-capture helper (RFC
/// 0074 WS3, the materializing arm of [`crate::ir::TOp::IterCapture`]):
/// build `iter(x)` through the interpreter core for the pinned
/// iterable (**a user `__iter__` may run**; the dirtiness discipline
/// applies — invalidated guards report through the negative status)
/// and answer the fresh iterator's pin index — or a negative value to
/// deopt (non-iterable → the interpreter re-executes the `GET_ITER`
/// and raises exactly; dirty guards; cap pressure). Shares the
/// [`StrLenHelper`] `(frame, pin) -> i64` shape. Must precede the
/// first compile of a frame containing a materializing `IterCapture`.
pub fn register_iter_new_helper(f: StrLenHelper) {
    ITER_NEW_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn iter_new_helper_addr() -> usize {
    ITER_NEW_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0074 WS3 — the embedder's tuple-target *step* helper, called
/// by the [`crate::ir::TTerm::ForIterPair`] terminator each iteration
/// with the pinned iterator and both compiled element lanes
/// ([`SlotTag`] discriminants, [`ITER_ELEM_STR`] admitted). **Runs
/// Python code** (the iterator protocol through the interpreter
/// core). Returns:
///
/// - `0` — a 2-sequence element was yielded and unpacked in the
///   compiled lanes: the first element's bits are in
///   [`JitFrame::ret_bits`], the second's in `call_args[0]`;
/// - `1` — the iterator is exhausted;
/// - `2` — deopt at the header pc, nothing consumed (pin miss);
/// - `3` — the element was consumed but is not a 2-sequence in the
///   compiled lanes: its raw object was pinned (index in `ret_bits`)
///   and the deopt resumes at the erased `UNPACK_SEQUENCE`'s pc with
///   the element spilled on top (the interpreter re-executes the
///   unpack, raising the exact error when malformed);
/// - `4` — the iterator raised; the exception is parked for the
///   ordinary `Raised` exit at the header pc.
pub type IterNextPairHelper =
    unsafe extern "C" fn(frame: *mut JitFrame, pin: i64, tag1: i64, tag2: i64) -> i64;

static ITER_NEXT_PAIR_HELPER: std::sync::atomic::AtomicUsize =
    std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide tuple-target step helper (RFC 0074 WS3).
/// Must precede the first compile of a frame containing a
/// `ForIterPair` terminator.
pub fn register_iter_next_pair_helper(f: IterNextPairHelper) {
    ITER_NEXT_PAIR_HELPER.store(f as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn iter_next_pair_helper_addr() -> usize {
    ITER_NEXT_PAIR_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

/// RFC 0074 WS5 — the embedder's `str % x` helper
/// ([`crate::ir::TOp::StrMod`]): `(frame, lhs_pin, rhs_bits,
/// rhs_tag) -> status`, running the interpreter's `%`-formatting
/// (**`__str__`/`__repr__` of the operands may run**; the dirtiness
/// discipline applies). Status: `0` = ok, the fresh exact-`str`
/// result's pin index in [`JitFrame::ret_bits`]; `1` = raised (exit
/// `Raised` at this pc); `2` = the format *completed* but the result
/// is not an exact `str`, a guard was invalidated, or cap pressure:
/// the result is parked and the caller deopts at the *next* pc —
/// formatting side effects never re-run; `3` = rejected before any
/// Python ran (pin/tag miss — defensive): deopt at this pc.
pub type StrModHelper =
    unsafe extern "C" fn(frame: *mut JitFrame, lhs_pin: i64, rhs_bits: i64, rhs_tag: i64) -> i64;

static STR_MOD_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);
static STR_SLICE_HELPER: std::sync::atomic::AtomicUsize = std::sync::atomic::AtomicUsize::new(0);

/// Register the process-wide `str` formatting/slicing helpers (RFC
/// 0074 WS5). `slice` shares the [`ListSliceHelper`]
/// `(frame, pin, start, stop) -> pin-or-negative` shape (CPython
/// slice clamping, `i64::MIN` = absent bound; never runs Python
/// code). Must precede the first compile of a frame containing
/// `StrMod`/`StrSlice` ops.
pub fn register_str_format_helpers(mod_: StrModHelper, slice: ListSliceHelper) {
    STR_MOD_HELPER.store(mod_ as usize, std::sync::atomic::Ordering::Release);
    STR_SLICE_HELPER.store(slice as usize, std::sync::atomic::Ordering::Release);
}

#[must_use]
pub(crate) fn str_mod_helper_addr() -> usize {
    STR_MOD_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

#[must_use]
pub(crate) fn str_slice_helper_addr() -> usize {
    STR_SLICE_HELPER.load(std::sync::atomic::Ordering::Acquire)
}

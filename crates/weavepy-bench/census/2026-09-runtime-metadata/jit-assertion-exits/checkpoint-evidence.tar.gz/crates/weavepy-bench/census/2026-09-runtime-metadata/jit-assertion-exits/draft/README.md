# JIT exits before common exception constants

An untimed CPython-checked datetime trace rejects _ymd2ord, _cmp, and other
functions at LOAD_COMMON_CONSTANT. This draft permits canonical AssertionError
and NotImplementedError constants as exact-PC interpreter exits. The normal
path can compile while exception construction, formatted messages, callbacks,
and handlers execute through the interpreter. All other common constants stay
on their existing unsupported path. This does not implement arbitrary constants
or assert that every affected function will become JITable.

The existing Deopt terminator spills values and locals without consuming the
operation. The existing marker-free operand checks and call-span exclusion apply
to these exits too. Blocks following an exit don't become native successors;
other incoming branches must retain normal reachability. Enclosing loop iterator
and generator state must remain intact. No new native helper or execution policy.

The draft is unapplied and uncompiled. Verify the loop's instruction reference
type when formatting/building; no test has established this implementation yet.
Before applying, finish and archive compact intern-pool measurements. Preflight
Python assertions against CPython and the unchanged predecessor, then verify
message side effects, canonical builtins under shadowing, tracebacks/locals,
causes, cleanup, conditional expressions, loops, handlers, and observability.
Measure never/rare/often/always failures, recovery after an error burst, ordinary
calls, datetime components, startup, and the unchanged full suite in both modes.
No new performance, memory, or universal superiority claim is established.

#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/native-unobserved-shell-validation/frozen"
binary=target/release/weavepy-runtime-native-unobserved-shell
output=target/native-unobserved-shell-validation
test "$(cat target/native-unobserved-shell-check-stage.txt)" = done
test ! -e "$output"
mkdir "$output"
printf 'full compatibility\n' > target/native-unobserved-shell-validation-stage.txt
python3.14 crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py --binary "$binary" --out "$output/validation.json" > "$output/validation.txt" 2>&1
printf 'done\n' > target/native-unobserved-shell-validation-stage.txt

#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/jit-raise-call-spans-validation-stage.txt)" = done
test "$(cat target/jit-raise-call-spans-diagnostic-v2/stage.txt)" = done
test ! -e target/jit-raise-call-spans-full-diagnostic
mkdir target/jit-raise-call-spans-full-diagnostic
base=target/release/weavepy-runtime-weakref-shared-keys
binary=target/release/weavepy-runtime-jit-raise-call-spans
vm_stat > target/jit-raise-call-spans-full-diagnostic/vm-before.txt
sysctl hw.memsize vm.swapusage > target/jit-raise-call-spans-full-diagnostic/memory-before.txt
printf 'startup and imports\n' > target/jit-raise-call-spans-full-diagnostic/stage.txt
python3.14 target/shared_slot_keys_startup_probes.py --base "$base" --new "$binary" --samples 31 --out target/jit-raise-call-spans-full-diagnostic/startup.json > target/jit-raise-call-spans-full-diagnostic/startup.txt 2>&1
printf 'full 24-fixture census\n' > target/jit-raise-call-spans-full-diagnostic/stage.txt
python3.14 tools/bench_compare.py --base "$base" --new "$binary" --samples 5 --frozen-cache-root target/jit-raise-call-spans-full-diagnostic/frozen --out target/jit-raise-call-spans-full-diagnostic/suite.json > target/jit-raise-call-spans-full-diagnostic/suite.txt 2>&1
vm_stat > target/jit-raise-call-spans-full-diagnostic/vm-after.txt
sysctl hw.memsize vm.swapusage > target/jit-raise-call-spans-full-diagnostic/memory-after.txt
python3.14 target/summarize_runtime_suite.py --suite target/jit-raise-call-spans-full-diagnostic/suite.json --out target/jit-raise-call-spans-full-diagnostic/summary.json > target/jit-raise-call-spans-full-diagnostic/summary.txt 2>&1
printf 'done\n' > target/jit-raise-call-spans-full-diagnostic/stage.txt

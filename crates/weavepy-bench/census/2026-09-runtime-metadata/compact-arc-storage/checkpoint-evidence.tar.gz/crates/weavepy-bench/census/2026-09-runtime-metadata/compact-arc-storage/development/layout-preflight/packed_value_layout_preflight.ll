; ModuleID = 'packed_value_layout_preflight.29773d6d86569b87-cgu.0'
source_filename = "packed_value_layout_preflight.29773d6d86569b87-cgu.0"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx11.0.0"

@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr, ptr, ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNSNvYNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0INtNtNtCs8Mbv00yxnRz_4core3ops8function6FnOnceuE9call_once6vtableCs3yIIYXvwsPH_29packed_value_layout_preflight, ptr @_RNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0Cs3yIIYXvwsPH_29packed_value_layout_preflight, ptr @_RNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0Cs3yIIYXvwsPH_29packed_value_layout_preflight }>, align 8
@alloc_b1a1c27c6d41023e30ee48eec611ccbe = private unnamed_addr constant [8 x i8] c"\18\00\00\00\00\00\00\00", align 8
@alloc_87930ff84f26c4dc0d3a344636709737 = private unnamed_addr constant [8 x i8] c"\10\00\00\00\00\00\00\00", align 8
@alloc_a30fbd7ee764311b5438e9cf554fd24e = private unnamed_addr constant [8 x i8] c"\08\00\00\00\00\00\00\00", align 8
@alloc_97f44004d2f00dfa2525c501584f0c44 = private unnamed_addr constant [8 x i8] c"\0F\00\00\00\00\00\00\00", align 8
@alloc_edb3ed16ed07237eac14eb16826c52e0 = private unnamed_addr constant [8 x i8] c"\01\00\00\00\00\00\00\00", align 8
@alloc_d24f858293ee7de1c6753c16024dfdb1 = private unnamed_addr constant [122 x i8] c"\0D{\22WideValue\22:\C0\0D,\22ThinValue\22:\C0\0F,\22PackedValue\22:\C0\19,\22PackedValue_alignment\22:\C0\0F,\22PackedOwner\22:\C0\19,\22PackedOwner_alignment\22:\C0\02}\0A\00", align 1

@thin_roundtrip = unnamed_addr alias void (ptr, ptr), ptr @packed_roundtrip

; std::rt::lang_start::<()>
; Function Attrs: uwtable
define hidden noundef i64 @_RINvNtCs82bWklYMk3w_3std2rt10lang_startuECs3yIIYXvwsPH_29packed_value_layout_preflight(ptr noundef nonnull %main, i64 noundef %argc, ptr noundef %argv, i8 noundef %sigpipe) unnamed_addr #0 {
start:
  %_7 = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_7)
  store ptr %main, ptr %_7, align 8
; call std::rt::lang_start_internal
  %_0 = call noundef i64 @_RNvNtCs82bWklYMk3w_3std2rt19lang_start_internal(ptr noundef nonnull %_7, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(48) @vtable.0, i64 noundef %argc, ptr noundef %argv, i8 noundef %sigpipe)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7)
  ret i64 %_0
}

; std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
; Function Attrs: noinline uwtable
define internal fastcc void @_RINvNtNtCs82bWklYMk3w_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs3yIIYXvwsPH_29packed_value_layout_preflight(ptr noundef nonnull readonly captures(none) %f) unnamed_addr #1 {
start:
  tail call void %f()
  tail call void asm sideeffect "", "~{memory}"() #8, !srcloc !5
  ret void
}

; std::rt::lang_start::<()>::{closure#0}
; Function Attrs: inlinehint uwtable
define internal noundef i32 @_RNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0Cs3yIIYXvwsPH_29packed_value_layout_preflight(ptr noalias nofree noundef readonly align 8 captures(none) dereferenceable(8) %_1) unnamed_addr #2 {
start:
  %_4 = load ptr, ptr %_1, align 8, !nonnull !6, !noundef !6
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  tail call fastcc void @_RINvNtNtCs82bWklYMk3w_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs3yIIYXvwsPH_29packed_value_layout_preflight(ptr noundef nonnull %_4) #9
  ret i32 0
}

; <std::rt::lang_start<()>::{closure#0} as core::ops::function::FnOnce<()>>::call_once::{shim:vtable#0}
; Function Attrs: inlinehint uwtable
define internal noundef i32 @_RNSNvYNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0INtNtNtCs8Mbv00yxnRz_4core3ops8function6FnOnceuE9call_once6vtableCs3yIIYXvwsPH_29packed_value_layout_preflight(ptr noundef readonly captures(none) %_1) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = load ptr, ptr %_1, align 8, !nonnull !6, !noundef !6
; call std::sys::backtrace::__rust_begin_short_backtrace::<fn(), ()>
  tail call fastcc void @_RINvNtNtCs82bWklYMk3w_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs3yIIYXvwsPH_29packed_value_layout_preflight(ptr noundef nonnull readonly %0) #9, !noalias !7
  ret i32 0
}

; packed_value_layout_preflight::main
; Function Attrs: uwtable
define hidden void @_RNvCs3yIIYXvwsPH_29packed_value_layout_preflight4main() unnamed_addr #0 {
start:
  %args = alloca [96 x i8], align 8
  %_9 = alloca [16 x i8], align 8
  %_7 = alloca [16 x i8], align 8
  %_6 = alloca [16 x i8], align 8
  %_4 = alloca [16 x i8], align 8
  %_3 = alloca [24 x i8], align 8
  %_1 = alloca [24 x i8], align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_1)
  call void @llvm.lifetime.start.p0(ptr nonnull %_3)
  %0 = getelementptr inbounds nuw i8, ptr %_3, i64 8
  store i64 7, ptr %0, align 8
  store i8 2, ptr %_3, align 8
  call void @wide_roundtrip(ptr noalias nofree noundef nonnull sret([24 x i8]) align 8 captures(address) dereferenceable(24) %_1, ptr noalias nofree noundef nonnull align 8 captures(address) dereferenceable(24) %_3) #9
  call void @llvm.lifetime.end.p0(ptr nonnull %_3)
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %_1) #8, !srcloc !5
  call void @llvm.lifetime.end.p0(ptr nonnull %_1)
  call void @llvm.lifetime.start.p0(ptr nonnull %_4)
  call void @llvm.lifetime.start.p0(ptr nonnull %_6)
  %1 = getelementptr inbounds nuw i8, ptr %_6, i64 8
  store i64 7, ptr %1, align 8
  store i8 2, ptr %_6, align 8
  call void @packed_roundtrip(ptr noalias nofree noundef nonnull sret([16 x i8]) align 8 captures(address) dereferenceable(16) %_4, ptr noalias nofree noundef nonnull align 8 captures(address) dereferenceable(16) %_6) #9
  call void @llvm.lifetime.end.p0(ptr nonnull %_6)
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %_4) #8, !srcloc !5
  call void @llvm.lifetime.end.p0(ptr nonnull %_4)
  call void @llvm.lifetime.start.p0(ptr nonnull %_7)
  call void @llvm.lifetime.start.p0(ptr nonnull %_9)
  %2 = getelementptr inbounds nuw i8, ptr %_9, i64 8
  store i64 7, ptr %2, align 8
  store i8 2, ptr %_9, align 8
  call void @packed_roundtrip(ptr noalias nofree noundef nonnull sret([16 x i8]) align 8 captures(address) dereferenceable(16) %_7, ptr noalias nofree noundef nonnull align 8 captures(address) dereferenceable(16) %_9) #9
  call void @llvm.lifetime.end.p0(ptr nonnull %_9)
  call void asm sideeffect "", "r,~{memory}"(ptr nonnull %_7) #8, !srcloc !5
  call void @llvm.lifetime.end.p0(ptr nonnull %_7)
  call void @llvm.lifetime.start.p0(ptr nonnull %args)
  store ptr @alloc_b1a1c27c6d41023e30ee48eec611ccbe, ptr %args, align 8
  %_13.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args, i64 8
  store ptr @_RNvXsi_NtNtNtCs8Mbv00yxnRz_4core3fmt3num3impjNtB9_7Display3fmt, ptr %_13.sroa.4.0..sroa_idx, align 8
  %3 = getelementptr inbounds nuw i8, ptr %args, i64 16
  store ptr @alloc_87930ff84f26c4dc0d3a344636709737, ptr %3, align 8
  %_14.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args, i64 24
  store ptr @_RNvXsi_NtNtNtCs8Mbv00yxnRz_4core3fmt3num3impjNtB9_7Display3fmt, ptr %_14.sroa.4.0..sroa_idx, align 8
  %4 = getelementptr inbounds nuw i8, ptr %args, i64 32
  store ptr @alloc_87930ff84f26c4dc0d3a344636709737, ptr %4, align 8
  %_15.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args, i64 40
  store ptr @_RNvXsi_NtNtNtCs8Mbv00yxnRz_4core3fmt3num3impjNtB9_7Display3fmt, ptr %_15.sroa.4.0..sroa_idx, align 8
  %5 = getelementptr inbounds nuw i8, ptr %args, i64 48
  store ptr @alloc_a30fbd7ee764311b5438e9cf554fd24e, ptr %5, align 8
  %_16.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args, i64 56
  store ptr @_RNvXsi_NtNtNtCs8Mbv00yxnRz_4core3fmt3num3impjNtB9_7Display3fmt, ptr %_16.sroa.4.0..sroa_idx, align 8
  %6 = getelementptr inbounds nuw i8, ptr %args, i64 64
  store ptr @alloc_97f44004d2f00dfa2525c501584f0c44, ptr %6, align 8
  %_17.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args, i64 72
  store ptr @_RNvXsi_NtNtNtCs8Mbv00yxnRz_4core3fmt3num3impjNtB9_7Display3fmt, ptr %_17.sroa.4.0..sroa_idx, align 8
  %7 = getelementptr inbounds nuw i8, ptr %args, i64 80
  store ptr @alloc_edb3ed16ed07237eac14eb16826c52e0, ptr %7, align 8
  %_18.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args, i64 88
  store ptr @_RNvXsi_NtNtNtCs8Mbv00yxnRz_4core3fmt3num3impjNtB9_7Display3fmt, ptr %_18.sroa.4.0..sroa_idx, align 8
; call std::io::stdio::_print
  call void @_RNvNtNtCs82bWklYMk3w_3std2io5stdio6__print(ptr noundef nonnull @alloc_d24f858293ee7de1c6753c16024dfdb1, ptr noundef nonnull %args)
  call void @llvm.lifetime.end.p0(ptr nonnull %args)
  ret void
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @packed_roundtrip(ptr dead_on_unwind noalias nofree noundef writable sret([16 x i8]) align 8 captures(address) dereferenceable(16) initializes((0, 16)) %_0, ptr dead_on_return noalias nofree noundef readonly align 8 captures(none) dereferenceable(16) %value) unnamed_addr #3 {
start:
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %_0, ptr noundef nonnull align 8 dereferenceable(16) %value, i64 16, i1 false)
  tail call void asm sideeffect "", "r,~{memory}"(ptr nonnull %_0) #8, !srcloc !5
  ret void
}

; Function Attrs: noinline nounwind uwtable
define dso_local void @wide_roundtrip(ptr dead_on_unwind noalias nofree noundef writable sret([24 x i8]) align 8 captures(address) dereferenceable(24) initializes((0, 24)) %_0, ptr dead_on_return noalias nofree noundef readonly align 8 captures(none) dereferenceable(24) %value) unnamed_addr #3 {
start:
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %value, i64 24, i1 false)
  tail call void asm sideeffect "", "r,~{memory}"(ptr nonnull %_0) #8, !srcloc !5
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #4

; std::rt::lang_start_internal
; Function Attrs: uwtable
declare noundef i64 @_RNvNtCs82bWklYMk3w_3std2rt19lang_start_internal(ptr noundef nonnull, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(48), i64 noundef, ptr noundef, i8 noundef) unnamed_addr #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #4

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #5

; <usize as core::fmt::Display>::fmt
; Function Attrs: uwtable
declare noundef zeroext i1 @_RNvXsi_NtNtNtCs8Mbv00yxnRz_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias nofree noundef align 8 dereferenceable(24)) unnamed_addr #0

; std::io::stdio::_print
; Function Attrs: uwtable
declare void @_RNvNtNtCs82bWklYMk3w_3std2io5stdio6__print(ptr noundef nonnull, ptr noundef nonnull) unnamed_addr #0

; Function Attrs: nounwind uwtable
declare noundef range(i32 0, 10) i32 @rust_eh_personality(i32 noundef, i32 noundef, i64 noundef, ptr noundef, ptr noundef) unnamed_addr #6

define noundef i32 @main(i32 %0, ptr %1) unnamed_addr #7 {
top:
  %_7.i = alloca [8 x i8], align 8
  %2 = sext i32 %0 to i64
  call void @llvm.lifetime.start.p0(ptr nonnull %_7.i)
  store ptr @_RNvCs3yIIYXvwsPH_29packed_value_layout_preflight4main, ptr %_7.i, align 8
; call std::rt::lang_start_internal
  %_0.i = call noundef i64 @_RNvNtCs82bWklYMk3w_3std2rt19lang_start_internal(ptr noundef nonnull %_7.i, ptr noalias nofree noundef readonly align 8 captures(address, read_provenance) dereferenceable(48) @vtable.0, i64 noundef %2, ptr noundef %1, i8 noundef 0)
  call void @llvm.lifetime.end.p0(ptr nonnull %_7.i)
  %3 = trunc i64 %_0.i to i32
  ret i32 %3
}

attributes #0 = { uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #1 = { noinline uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #2 = { inlinehint uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #3 = { noinline nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #4 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #5 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #7 = { "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="apple-m1" }
attributes #8 = { nounwind }
attributes #9 = { noinline }

!llvm.module.flags = !{!0, !1, !2, !3}
!llvm.ident = !{!4}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 7, !"PIE Level", i32 2}
!2 = !{i32 7, !"uwtable", i32 2}
!3 = !{i32 7, !"frame-pointer", i32 1}
!4 = !{!"rustc version 1.98.1 (48a229cea 2026-09-01)"}
!5 = !{i64 1269682527306402}
!6 = !{}
!7 = !{!8}
!8 = distinct !{!8, !9, !"_RNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0Cs3yIIYXvwsPH_29packed_value_layout_preflight: %_1"}
!9 = distinct !{!9, !"_RNCINvNtCs82bWklYMk3w_3std2rt10lang_startuE0Cs3yIIYXvwsPH_29packed_value_layout_preflight"}

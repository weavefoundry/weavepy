//! Thread-safe synchronisation primitives + workspace-wide
//! interior-mutability layer — RFCs 0024 and 0025.
//!
//! After RFC 0025 the entire VM heap is `Arc`-rooted: every
//! `Object` variant, every `TypeObject`, every `CodeObject` reaches
//! across threads through the aliases defined here. Existing call
//! sites compile unchanged after swapping
//! `use std::rc::Rc;` / `use std::cell::{Cell, RefCell};` for
//! `use crate::sync::{Rc, Cell, RefCell};`.
//!
//! Types exported by this module (the RFC 0025 surface):
//!
//! - [`Rc`] — type alias for [`std::sync::Arc`]. `Arc::ptr_eq` /
//!   `Arc::clone` / `Arc::as_ptr` / `Arc::strong_count` /
//!   `Arc::try_unwrap` / `Arc::get_mut` / `Arc::downgrade` all
//!   work unchanged.
//! - [`Weak`] — type alias for [`std::sync::Weak`].
//! - [`GilCell`] — interior-mutability primitive whose surface
//!   matches [`std::cell::RefCell`] (and the [`std::cell::Cell`]
//!   methods for `T: Copy`), but is `Send + Sync` when `T: Send`.
//!   Backed by a `parking_lot::ReentrantMutex` so the codebase's
//!   pervasive nested-borrow patterns keep working.
//! - [`RefCell`] aliases [`GilCell`] for borrowed data. [`Cell`] holds
//!   copyable values in compact atomic storage without borrow guards.
//!
//! The RFC 0024 surface (real lock / event / barrier primitives
//! that back `threading.Lock` etc.) lives below the new aliases.

pub use crate::lazy_arc::LazyArc;

use std::cell::UnsafeCell;
use std::fmt;
use std::hash::{Hash, Hasher};
use std::ops::{Deref, DerefMut};
use std::sync::atomic::{AtomicIsize, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use parking_lot::{Condvar, Mutex, ReentrantMutex};

// ---------------------------------------------------------------------------
// RFC 0025 — drop-in replacements for `std::rc::Rc`, `std::rc::Weak`,
// `std::cell::RefCell`, `std::cell::Cell`.
// ---------------------------------------------------------------------------

/// Drop-in replacement for [`std::rc::Rc`]. Backed by
/// [`std::sync::Arc`], so it carries the same atomic refcount
/// behaviour. Every method on `Arc` (`ptr_eq`, `clone`, `as_ptr`,
/// `strong_count`, `weak_count`, `downgrade`, `try_unwrap`,
/// `get_mut`, `into_inner`) is identical to the `Rc` API the
/// workspace already calls.
pub type Rc<T> = std::sync::Arc<T>;

/// Drop-in replacement for [`std::rc::Weak`]. Backed by
/// [`std::sync::Weak`].
pub type Weak<T> = std::sync::Weak<T>;

/// An interior-mutability cell that's `Send + Sync` (when the
/// payload is `Send`) and supports both the `RefCell` and `Cell`
/// surfaces. Backed by a [`parking_lot::ReentrantMutex`] so nested
/// borrows on the same thread (extremely common in the
/// dispatcher's descriptor / metaclass / dunder paths) don't
/// deadlock. A `RefCell`-style borrow counter on top of the mutex
/// preserves the "no concurrent shared-and-mutable borrow"
/// invariant.
///
/// Cross-thread synchronisation is the mutex's job — a
/// `borrow()`/`borrow_mut()` on thread A blocks any `borrow()` or
/// `borrow_mut()` on thread B until A drops its guard. Within a
/// single thread the mutex is reentrant, so nested `borrow()`
/// calls succeed; `borrow_mut()` while any borrow is live still
/// panics (mirroring `std::cell::RefCell`).
pub struct GilCell<T: ?Sized> {
    /// CPython-shaped borrow counter:
    ///
    /// - `0` — unborrowed.
    /// - `>0` — that many shared borrows are live.
    /// - `< 0` — a mutable borrow is live (always exactly `-1`).
    ///
    /// Atomic because `GilCell` is `Sync`; the owner lock below makes
    /// cross-thread access exclusive, but within a single OS thread
    /// the lock is reentrant — the counter prevents undefined
    /// behaviour on nested `borrow_mut()`.
    borrow: AtomicIsize,
    /// The cross-thread reentrant lock, hand-rolled for the hot path.
    /// `0` means unowned; otherwise it holds the owning thread's id
    /// ([`crate::gil::current_thread_id`]). The uncontended borrow —
    /// the only case bytecode execution under the GIL ever sees — is
    /// one relaxed load (same-thread reentry) or one compare-exchange
    /// (fresh acquire), versus the `parking_lot::ReentrantMutex` +
    /// thread-local bookkeeping this replaced, which dominated
    /// interpreter profiles (RFC 0047 wave 5: every `Cell::get` on an
    /// object field paid ~10× the cost of the field read itself).
    owner: AtomicU64,
    /// Recursion depth. Only ever touched by the thread that owns
    /// [`Self::owner`], so a plain (unsafe) cell is sound.
    depth: UnsafeCell<u32>,
    /// The guarded payload. Access is gated by holding the owner
    /// lock; the borrow counter rules out aliasing `&mut T` within a
    /// thread. Last field so `T: ?Sized` cells stay layout-legal.
    data: UnsafeCell<T>,
}

// SAFETY: `GilCell<T>` is `Send` whenever `T: Send` — moving a cell
// across threads is fine because we move the payload too.
// `GilCell<T>` is `Sync` whenever `T: Send` because the
// `ReentrantMutex` guarantees that only one thread accesses the
// `UnsafeCell` at a time and the borrow counter prevents the same
// thread from creating aliasing `&mut T`. Together those rule out
// the data race / aliasing UB that a bare `UnsafeCell<T>` would
// otherwise produce.
unsafe impl<T: ?Sized + Send> Send for GilCell<T> {}
unsafe impl<T: ?Sized + Send> Sync for GilCell<T> {}

/// `RefCell<T>` is the workspace's name for [`GilCell`] when the
/// caller previously imported `std::cell::RefCell`.
pub type RefCell<T> = GilCell<T>;

/// A thread-safe cell for copyable object metadata.
///
/// Loads acquire and stores release. Values must fit a native atomic;
/// construction checks this at compile time. No operation runs callbacks
/// or exposes a reference to the payload, so it needs
/// no reentrant owner lock or live-borrow bookkeeping. Data that must be
/// borrowed still uses [`RefCell`]. The cell occupies only its payload's
/// space, avoiding a separate lock in every object flag.
///
/// Larger or insufficiently aligned values must use [`GilCell`], whose
/// owner lock supports recovery after `fork()`. Crossbeam's global-lock
/// fallback cannot recover a lock held by a thread absent in the child.
#[repr(transparent)]
pub struct Cell<T: Copy>(crossbeam_utils::atomic::AtomicCell<T>);

impl<T: Copy> Cell<T> {
    pub const fn new(value: T) -> Self {
        const {
            assert!(
                crossbeam_utils::atomic::AtomicCell::<T>::is_lock_free(),
                "use GilCell for metadata without native atomic support"
            );
        }
        Self(crossbeam_utils::atomic::AtomicCell::new(value))
    }

    #[inline]
    pub fn get(&self) -> T {
        self.0.load()
    }

    #[inline]
    pub fn set(&self, value: T) {
        self.0.store(value);
    }

    #[inline]
    pub fn replace(&self, value: T) -> T {
        self.0.swap(value)
    }

    pub fn into_inner(self) -> T {
        self.0.into_inner()
    }

    pub fn take(&self) -> T
    where
        T: Default,
    {
        self.0.take()
    }
}

impl<T: Copy + Default> Default for Cell<T> {
    fn default() -> Self {
        Self::new(T::default())
    }
}

impl<T: Copy> From<T> for Cell<T> {
    fn from(value: T) -> Self {
        Self::new(value)
    }
}

impl<T: Copy> Clone for Cell<T> {
    fn clone(&self) -> Self {
        Self::new(self.get())
    }
}

impl<T: Copy + fmt::Debug> fmt::Debug for Cell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("Cell").field(&self.get()).finish()
    }
}

/// An initially empty cache for a normalized Python hash.
///
/// Python reserves `-1` for errors and maps a successful hash of `-1`
/// to `-2`. That leaves one native atomic word for both the value and
/// the empty state, with acquiring reads and releasing writes. Stores
/// normalize their input so an initialized cache never becomes empty.
#[repr(transparent)]
pub struct CachedHash {
    value: Cell<i64>,
}

impl CachedHash {
    const fn normalize(value: i64) -> i64 {
        if value == -1 {
            -2
        } else {
            value
        }
    }

    pub const fn new(value: Option<i64>) -> Self {
        Self {
            value: Cell::new(match value {
                Some(value) => Self::normalize(value),
                None => -1,
            }),
        }
    }

    #[inline]
    pub fn get(&self) -> Option<i64> {
        let value = self.value.get();
        (value != -1).then_some(value)
    }

    #[inline]
    pub fn store(&self, value: i64) {
        self.value.set(Self::normalize(value));
    }
}

impl Default for CachedHash {
    fn default() -> Self {
        Self::new(None)
    }
}

impl Clone for CachedHash {
    fn clone(&self) -> Self {
        Self::new(self.get())
    }
}

impl fmt::Debug for CachedHash {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_tuple("CachedHash").field(&self.get()).finish()
    }
}

/// A plain `std::cell::RefCell` for state that one interpreter owns
/// outright and never publishes to another thread: the frame, stack,
/// scratch, and shell free-lists (RFC 0077 WS3). Those are touched on
/// every Python call, and a [`GilCell`] borrow there bought nothing
/// but a thread-id lookup and two atomic RMWs. `ThreadCell` is `Send`
/// (a worker thread takes its interpreter by move) and, like the
/// `std` cell, not `Sync`: the compiler refuses the day one is shared.
pub type ThreadCell<T> = std::cell::RefCell<T>;

std::thread_local! {
    /// Number of live [`GilCell`] borrow guards ([`Ref`]/[`RefMut`]) on
    /// this thread. Guards are `!Send` (they wrap a
    /// `ReentrantMutexGuard`), so acquire and release always happen on
    /// the same thread and a plain thread-local counter is exact.
    ///
    /// RFC 0047 (wave 5): consulted by `gil::maybe_yield_gil` to refuse a
    /// cooperative GIL hand-off while *any* cell borrow is live. Handing
    /// off mid-borrow is the GIL ↔ cell-mutex inversion previously only
    /// guarded piecemeal (`no_gil_handoff` around container hash/eq): the
    /// new holder blocks on this thread's cell mutex while this thread
    /// parks waiting for the GIL back — observed as a wedge in pandas'
    /// multi-thread `read_csv` (a container `repr` re-entering Python
    /// yielded the GIL with the container's borrow held; a sibling's
    /// `len()` on the same container then deadlocked the process).
    ///
    /// RFC 0077 (WS3): shares one thread-local block with the cached
    /// native thread id. On macOS every distinct `thread_local!` costs
    /// a `_tlv_get_addr` call, and a borrow used to pay two (the id for
    /// the lock word, then this counter); the acquire path now takes
    /// one, reading both fields through a single reference.
    pub(crate) static CELL_TLS: CellTls = const {
        CellTls {
            thread_id: std::cell::Cell::new(0),
            live_guards: std::cell::Cell::new(0),
        }
    };
}

/// The per-thread state [`GilCell`] consults on every borrow.
pub(crate) struct CellTls {
    /// Cached [`crate::gil::current_thread_id`]; `0` until derived (never
    /// a valid id: pthread ids are pointers, Windows ids are non-zero for
    /// live threads, and the hash fallback re-derives on collision).
    pub(crate) thread_id: std::cell::Cell<u64>,
    /// Live [`Ref`]/[`RefMut`] guards on this thread.
    live_guards: std::cell::Cell<usize>,
}

impl CellTls {
    #[inline]
    fn thread_id(&self) -> u64 {
        let id = self.thread_id.get();
        if id != 0 {
            id
        } else {
            let id = crate::gil::derive_thread_id();
            self.thread_id.set(id);
            id
        }
    }
}

// `try_with`, not `with`, throughout: guards can be dropped from TLS
// destructors at thread teardown, where the counter cell itself may
// already be gone — the count is then irrelevant, so a no-op is right.
#[inline]
fn note_cell_guard_released() {
    let _ = CELL_TLS.try_with(|t| t.live_guards.set(t.live_guards.get().saturating_sub(1)));
}

/// True iff the calling thread holds at least one live [`GilCell`]
/// borrow guard. The GIL hand-off checkpoint refuses to yield while
/// this is true (see [`CELL_TLS`]).
#[inline]
pub fn cell_guards_live() -> bool {
    CELL_TLS
        .try_with(|t| t.live_guards.get() > 0)
        .unwrap_or(false)
}

/// Error returned by [`GilCell::try_borrow`] when the cell is
/// already mutably borrowed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BorrowError;

impl fmt::Display for BorrowError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("already mutably borrowed")
    }
}

impl std::error::Error for BorrowError {}

/// Error returned by [`GilCell::try_borrow_mut`] when the cell is
/// already borrowed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BorrowMutError;

impl fmt::Display for BorrowMutError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("already borrowed")
    }
}

impl std::error::Error for BorrowMutError {}

impl<T> GilCell<T> {
    /// Build a cell holding `value`. `const`-callable so the
    /// codebase's existing `thread_local!{ static FOO: RefCell<…> =
    /// const { RefCell::new(None) }; }` patterns keep working.
    #[must_use]
    pub const fn new(value: T) -> Self {
        Self {
            borrow: AtomicIsize::new(0),
            owner: AtomicU64::new(0),
            depth: UnsafeCell::new(0),
            data: UnsafeCell::new(value),
        }
    }

    /// Move out the cell's payload, consuming the cell.
    pub fn into_inner(self) -> T {
        // The lock carries no payload; the data cell's `into_inner`
        // extracts the value.
        self.data.into_inner()
    }

    /// Reinitialise the cell's lock in a `fork(2)` child, preserving the
    /// payload. `parking_lot::ReentrantMutex` is not fork-safe: a sibling
    /// thread that vanished in the fork may have held `inner` (or left
    /// `borrow` non-zero), so the inherited lock would wedge the child's next
    /// `borrow()` forever. Rebuild the mutex around the *existing* payload —
    /// the exact analogue of CPython reinitialising a `pthread_mutex` in
    /// `PyOS_AfterFork_Child`. `into_inner` extracts the payload by value
    /// without taking the (possibly poisoned) lock, so this never blocks.
    ///
    /// Retained for callers that proactively reset specific cells in the fork
    /// child (e.g. the cycle collector's `GcState`). Equivalent to the lazy
    /// recovery [`borrow`](Self::borrow) now performs on demand, but eager.
    ///
    /// # Safety
    ///
    /// `this` must point at a live `GilCell<T>` on the lone surviving
    /// thread of a fork child, where nothing else can be touching the cell — so
    /// the in-place rebuild cannot race, and the payload, last mutated under
    /// the GIL the forking thread now holds, is in a consistent state.
    pub unsafe fn reinit_lock_after_fork(this: *mut Self) {
        unsafe { (*this).rebuild_lock() }
    }
}

impl<T: ?Sized> GilCell<T> {
    /// Acquire the cross-thread reentrant lock.
    ///
    /// The two hot cases are branch-one: *fresh acquire* (owner is 0 —
    /// one compare-exchange) and *same-thread reentry* (owner is us —
    /// one relaxed load plus a depth bump). Cross-thread contention
    /// and `fork(2)` recovery live in the cold path.
    #[inline]
    fn lock_acquire(&self) {
        self.lock_acquire_as(crate::gil::current_thread_id());
    }

    /// [`Self::lock_acquire`] with the caller's thread id in hand.
    #[inline]
    fn lock_acquire_as(&self, me: u64) {
        // Same-thread reentry: the owner field can only equal `me` if
        // this thread stored it, so the relaxed load is authoritative.
        if self.owner.load(Ordering::Relaxed) == me {
            // SAFETY: this thread owns the lock; `depth` is only ever
            // touched by the owner.
            unsafe { *self.depth.get() += 1 };
            return;
        }
        if self
            .owner
            .compare_exchange(0, me, Ordering::Acquire, Ordering::Relaxed)
            .is_ok()
        {
            // SAFETY: we just became the owner.
            unsafe { *self.depth.get() = 1 };
            return;
        }
        self.lock_contended(me);
    }

    /// Contended / fork-recovery acquire.
    ///
    /// Under the GIL only the GIL holder ever borrows a `GilCell`, so
    /// genuine cross-thread contention is rare and short (a C-API
    /// thread poking a shared container). Spin briefly, then yield.
    ///
    /// `fork(2)` recovery: the child keeps just the forking thread, yet
    /// inherits every lock word exactly as it stood in the parent —
    /// including cells a sibling thread (now vanished) was mid-borrow
    /// on. That owner can never release, so a contended lock in a
    /// process with exactly **one** live OS thread cannot have a living
    /// owner — steal it and reset the borrow counter. With two or more
    /// live threads the contention is genuine; keep waiting.
    #[cold]
    fn lock_contended(&self, me: u64) {
        let mut spins = 0u32;
        loop {
            if self
                .owner
                .compare_exchange_weak(0, me, Ordering::Acquire, Ordering::Relaxed)
                .is_ok()
            {
                // SAFETY: we just became the owner.
                unsafe { *self.depth.get() = 1 };
                return;
            }
            spins += 1;
            if spins < 64 {
                std::hint::spin_loop();
            } else {
                if spins.is_multiple_of(64)
                    && crate::stdlib::os_process::count_os_threads() == Some(1)
                {
                    // Fork orphan: no living owner. Steal.
                    self.borrow.store(0, Ordering::Release);
                    self.owner.store(me, Ordering::Release);
                    // SAFETY: sole surviving thread of the fork child.
                    unsafe { *self.depth.get() = 1 };
                    return;
                }
                std::thread::yield_now();
            }
        }
    }

    /// Release one level of the reentrant lock.
    #[inline]
    fn lock_release(&self) {
        // SAFETY: only the owner thread calls release (guards are
        // `!Send`), so the depth cell is ours.
        unsafe {
            let d = &mut *self.depth.get();
            *d -= 1;
            if *d == 0 {
                self.owner.store(0, Ordering::Release);
            }
        }
    }

    /// Replace the cross-thread lock state with a pristine one, leaving the
    /// payload untouched. Resets the borrow counter too, since an orphaned
    /// lock may have been left mid-borrow.
    ///
    /// SAFETY: the caller must guarantee no other thread can be touching this
    /// cell for the duration of the call (the lone surviving thread of a
    /// `fork(2)` child satisfies this).
    unsafe fn rebuild_lock(&self) {
        self.borrow.store(0, Ordering::Release);
        self.owner.store(0, Ordering::Release);
        // SAFETY: see method contract — sole thread.
        unsafe { *self.depth.get() = 0 };
    }

    /// Borrow the cell immutably. Multiple immutable borrows can
    /// coexist on the same thread. Panics if a mutable borrow is
    /// already live (matches `std::cell::RefCell::borrow`).
    #[track_caller]
    pub fn borrow(&self) -> Ref<'_, T> {
        self.try_borrow()
            .expect("GilCell::borrow: cell is mutably borrowed")
    }

    /// Borrow the cell mutably. Panics if any borrow is already
    /// live (matches `std::cell::RefCell::borrow_mut`).
    #[track_caller]
    pub fn borrow_mut(&self) -> RefMut<'_, T> {
        self.try_borrow_mut()
            .expect("GilCell::borrow_mut: cell is already borrowed")
    }

    /// Non-panicking variant of [`borrow`](Self::borrow). Returns
    /// [`BorrowError`] if a mutable borrow is live.
    pub fn try_borrow(&self) -> Result<Ref<'_, T>, BorrowError> {
        // One thread-local access covers the lock word's owner id and
        // the live-guard count. If the block is already torn down (a
        // guard taken from a TLS destructor) fall back to the uncached
        // id and skip the count, which is irrelevant by then.
        let ok = CELL_TLS
            .try_with(|t| {
                self.lock_acquire_as(t.thread_id());
                if self.borrow_shared() {
                    t.live_guards.set(t.live_guards.get() + 1);
                    true
                } else {
                    false
                }
            })
            .unwrap_or_else(|_| {
                self.lock_acquire();
                self.borrow_shared()
            });
        if !ok {
            return Err(BorrowError);
        }
        // SAFETY: we hold the reentrant lock (so no other thread
        // can race) and the borrow counter is `>= 1` (so no `&mut T`
        // to the data exists). The raw dereference yields a shared
        // reference valid for as long as the guard (and thus the
        // lock) is held.
        let value: &T = unsafe { &*self.data.get() };
        Ok(Ref {
            cell: self,
            value,
            _not_send: std::marker::PhantomData,
        })
    }

    /// Bump the borrow counter under the held lock. If we observed a
    /// negative value (a mutable borrow is live on this thread — the
    /// reentrant lock let us in), unwind, release, and report failure.
    #[inline]
    fn borrow_shared(&self) -> bool {
        // The owner lock already serializes access across threads. The
        // counter only checks same-thread reentry, so it needs no atomic
        // read-modify-write or second acquire/release barrier.
        let prev = self.borrow.load(Ordering::Relaxed);
        if prev < 0 || prev == isize::MAX {
            self.lock_release();
            return false;
        }
        self.borrow.store(prev + 1, Ordering::Relaxed);
        true
    }

    /// Claim the exclusive borrow under the held lock: only succeeds if
    /// the counter is exactly zero (no shared borrow and no nested
    /// mutable borrow); releases the lock and reports failure otherwise.
    #[inline]
    fn borrow_exclusive(&self) -> bool {
        if self.borrow.load(Ordering::Relaxed) != 0 {
            self.lock_release();
            return false;
        }
        self.borrow.store(-1, Ordering::Relaxed);
        true
    }

    /// Non-panicking variant of [`borrow_mut`](Self::borrow_mut).
    /// Returns [`BorrowMutError`] if any borrow is live.
    pub fn try_borrow_mut(&self) -> Result<RefMut<'_, T>, BorrowMutError> {
        let ok = CELL_TLS
            .try_with(|t| {
                self.lock_acquire_as(t.thread_id());
                if self.borrow_exclusive() {
                    t.live_guards.set(t.live_guards.get() + 1);
                    true
                } else {
                    false
                }
            })
            .unwrap_or_else(|_| {
                self.lock_acquire();
                self.borrow_exclusive()
            });
        if !ok {
            return Err(BorrowMutError);
        }
        // SAFETY: reentrant lock held; borrow counter is `-1` so
        // no other `&T` or `&mut T` to the data exists. Safe to
        // hand out an exclusive `&mut T` for the lock's lifetime.
        let value: &mut T = unsafe { &mut *self.data.get() };
        Ok(RefMut {
            cell: self,
            value,
            _not_send: std::marker::PhantomData,
        })
    }

    /// Returns a raw pointer to the inner data. Doesn't claim any
    /// borrow; the caller is responsible for ensuring the pointer
    /// isn't dereferenced concurrently with another borrow.
    pub fn as_ptr(&self) -> *mut T {
        self.data.get()
    }
}

impl<T> GilCell<T> {
    /// Replace the inner value with `new`, returning the old one.
    pub fn replace(&self, new: T) -> T {
        std::mem::replace(&mut *self.borrow_mut(), new)
    }

    /// Apply `f` to the current value, then store its return into
    /// the cell. Returns the previous value.
    pub fn replace_with<F>(&self, f: F) -> T
    where
        F: FnOnce(&mut T) -> T,
    {
        let mut guard = self.borrow_mut();
        let new = f(&mut guard);
        std::mem::replace(&mut *guard, new)
    }

    /// Swap the contents of two cells. The cells may be the same
    /// (no-op).
    pub fn swap(&self, other: &Self) {
        if std::ptr::eq(self, other) {
            return;
        }
        let mut a = self.borrow_mut();
        let mut b = other.borrow_mut();
        std::mem::swap(&mut *a, &mut *b);
    }

    /// Move the value out, leaving `Default::default()` in its
    /// place.
    pub fn take(&self) -> T
    where
        T: Default,
    {
        std::mem::take(&mut *self.borrow_mut())
    }
}

impl<T: Copy> GilCell<T> {
    /// Get the inner value (copying it). Equivalent to
    /// `*self.borrow()` but skips guard construction and the
    /// [`CELL_TLS`] live-guard bookkeeping (RFC 0058 WS2): a `Copy`
    /// read cannot re-enter Python, so no GIL hand-off can occur
    /// while the lock is held — the yield-refusal counter exists
    /// only for guards that outlive a re-entrant call. `Cell::get`
    /// on object fields is the single hottest operation in the
    /// interpreter, and the two thread-local touches per access
    /// dominated its cost.
    #[track_caller]
    pub fn get(&self) -> T {
        // RFC 0065 (WS2): the documented fast path, restored. Debug
        // builds keep the checked `borrow()` route so misuse (a `get`
        // racing a live same-thread `borrow_mut`) still surfaces as a
        // panic under `cargo test`; release builds read the payload
        // directly under the owner lock — no borrow-counter RMWs, no
        // guard construction, no `CELL_TLS` thread-local
        // touches.
        #[cfg(debug_assertions)]
        {
            *self.borrow()
        }
        #[cfg(not(debug_assertions))]
        {
            self.lock_acquire();
            // SAFETY: the owner lock is held, so no other thread can
            // touch the payload; a `T: Copy` read cannot re-enter
            // Python, so no GIL hand-off (and thus no cross-thread
            // mutation) can occur while the lock is held. A same-thread
            // outstanding `&mut T` cannot exist mid-`get` because the
            // interpreter never suspends between a `borrow_mut` and its
            // guard drop without going through a call boundary, and
            // `Copy` cells are never borrowed across call boundaries.
            let v = unsafe { *self.data.get() };
            self.lock_release();
            v
        }
    }

    /// Replace the inner value with `value`. Equivalent to
    /// `*self.borrow_mut() = value` minus the guard machinery — see
    /// [`Self::get`] for why that's sound.
    #[track_caller]
    pub fn set(&self, value: T) {
        // RFC 0065 (WS2): symmetric fast path; see `get`.
        #[cfg(debug_assertions)]
        {
            *self.borrow_mut() = value;
        }
        #[cfg(not(debug_assertions))]
        {
            self.lock_acquire();
            // SAFETY: as in `get`; the write is a plain `Copy` store
            // under the owner lock.
            unsafe { *self.data.get() = value };
            self.lock_release();
        }
    }
}

impl<T: Default> Default for GilCell<T> {
    fn default() -> Self {
        Self::new(T::default())
    }
}

impl<T> From<T> for GilCell<T> {
    fn from(value: T) -> Self {
        Self::new(value)
    }
}

impl<T: Clone> Clone for GilCell<T> {
    fn clone(&self) -> Self {
        Self::new(self.borrow().clone())
    }
}

impl<T: fmt::Debug> fmt::Debug for GilCell<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.try_borrow() {
            Ok(borrow) => f.debug_tuple("GilCell").field(&*borrow).finish(),
            Err(_) => f.debug_tuple("GilCell").field(&"<borrowed>").finish(),
        }
    }
}

impl<T: PartialEq> PartialEq for GilCell<T> {
    fn eq(&self, other: &Self) -> bool {
        if std::ptr::eq(self, other) {
            return true;
        }
        *self.borrow() == *other.borrow()
    }
}

impl<T: Eq> Eq for GilCell<T> {}

impl<T: PartialOrd> PartialOrd for GilCell<T> {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        self.borrow().partial_cmp(&*other.borrow())
    }
}

impl<T: Ord> Ord for GilCell<T> {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.borrow().cmp(&*other.borrow())
    }
}

impl<T: Hash> Hash for GilCell<T> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.borrow().hash(state);
    }
}

/// RAII guard returned by [`GilCell::borrow`]. Releases the borrow
/// counter and the cell's reentrant lock on drop.
///
/// `!Send` (via the `PhantomData<*mut ()>` marker): the lock's
/// release must run on the acquiring thread because the reentrancy
/// accounting (owner id + depth) is per-thread.
pub struct Ref<'a, T: ?Sized + 'a> {
    cell: &'a GilCell<T>,
    value: &'a T,
    _not_send: std::marker::PhantomData<*mut ()>,
}

impl<T: ?Sized> Deref for Ref<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        self.value
    }
}

impl<T: ?Sized + fmt::Debug> fmt::Debug for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(self.value, f)
    }
}

impl<T: ?Sized + fmt::Display> fmt::Display for Ref<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(self.value, f)
    }
}

impl<T: ?Sized> Drop for Ref<'_, T> {
    fn drop(&mut self) {
        let count = self.cell.borrow.load(Ordering::Relaxed);
        self.cell.borrow.store(count - 1, Ordering::Relaxed);
        self.cell.lock_release();
        note_cell_guard_released();
    }
}

/// RAII guard returned by [`GilCell::borrow_mut`]. Resets the
/// borrow counter and releases the cell's reentrant lock on drop.
/// `!Send` for the same reason as [`Ref`].
pub struct RefMut<'a, T: ?Sized + 'a> {
    cell: &'a GilCell<T>,
    value: &'a mut T,
    _not_send: std::marker::PhantomData<*mut ()>,
}

impl<T: ?Sized> Deref for RefMut<'_, T> {
    type Target = T;
    fn deref(&self) -> &T {
        self.value
    }
}

impl<T: ?Sized> DerefMut for RefMut<'_, T> {
    fn deref_mut(&mut self) -> &mut T {
        self.value
    }
}

impl<T: ?Sized + fmt::Debug> fmt::Debug for RefMut<'_, T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.value, f)
    }
}

impl<T: ?Sized> Drop for RefMut<'_, T> {
    fn drop(&mut self) {
        // From -1 back to 0 — there's only ever one outstanding
        // mutable borrow at a time.
        self.cell.borrow.store(0, Ordering::Relaxed);
        self.cell.lock_release();
        note_cell_guard_released();
    }
}

// ---------------------------------------------------------------------------
// RFC 0024 — real cross-thread synchronisation primitives.
// ---------------------------------------------------------------------------

/// A real cross-thread mutex with CPython `_thread.LockType`
/// semantics. `acquire(blocking=True, timeout=-1)` blocks until
/// the lock is available; `acquire(blocking=False)` returns
/// immediately. `release()` unlocks; calling release on an
/// unlocked lock raises `RuntimeError` upstream.
///
/// The lock is *not* reentrant — see [`RealRLock`] for that. The
/// owner thread id is tracked so cross-thread releases can be
/// detected and surfaced as `RuntimeError("release unlocked
/// lock")` per CPython.
#[derive(Debug)]
pub struct RealLock {
    state: Mutex<LockState>,
    cv: Condvar,
}

#[derive(Debug, Default)]
struct LockState {
    held: bool,
    owner: Option<u64>,
}

impl Default for RealLock {
    fn default() -> Self {
        Self::new()
    }
}

impl RealLock {
    pub fn new() -> Self {
        Self {
            state: Mutex::new(LockState::default()),
            cv: Condvar::new(),
        }
    }

    /// Try once without blocking. Returns `true` if acquired.
    pub fn try_acquire(&self, owner: u64) -> bool {
        let mut state = self.state.lock();
        if state.held {
            false
        } else {
            state.held = true;
            state.owner = Some(owner);
            true
        }
    }

    /// Acquire, blocking forever if necessary.
    pub fn acquire(&self, owner: u64) {
        let mut state = self.state.lock();
        while state.held {
            self.cv.wait(&mut state);
        }
        state.held = true;
        state.owner = Some(owner);
    }

    /// Acquire, blocking until the deadline. Returns `true` if
    /// acquired in time.
    pub fn acquire_timeout(&self, owner: u64, timeout: Duration) -> bool {
        let deadline = Instant::now() + timeout;
        let mut state = self.state.lock();
        while state.held {
            let now = Instant::now();
            if now >= deadline {
                return false;
            }
            let remaining = deadline - now;
            let result = self.cv.wait_for(&mut state, remaining);
            if result.timed_out() && state.held {
                return false;
            }
        }
        state.held = true;
        state.owner = Some(owner);
        true
    }

    /// Release the lock. Returns `Ok(())` on success, `Err` if
    /// the lock isn't held.
    pub fn release(&self) -> Result<(), &'static str> {
        let mut state = self.state.lock();
        if !state.held {
            return Err("release unlocked lock");
        }
        state.held = false;
        state.owner = None;
        drop(state);
        self.cv.notify_one();
        Ok(())
    }

    pub fn is_locked(&self) -> bool {
        self.state.lock().held
    }

    /// Forcibly return the lock to the fresh, unlocked state, ignoring any
    /// current holder. This backs `_thread.lock._at_fork_reinit()`: after a
    /// `fork()` the child inherits the lock's *memory* but none of the other
    /// threads, so a lock left `held` by a now-defunct thread would deadlock
    /// forever. CPython reinitialises the underlying mutex here
    /// (`pthread_mutex_init`); we do the exact equivalent below.
    ///
    /// We must NOT take `self.state.lock()` or call `self.cv.notify_all()` to
    /// do this: `parking_lot`'s primitives are not `fork`-safe. A sibling
    /// thread that vanished in the `fork(2)` may have held the inner `state`
    /// mutex, or been parked in `cv.wait` — leaving a stale waiter entry (and
    /// possibly a *held bucket lock*) in `parking_lot`'s process-global
    /// parking-lot hash table. Locking `state` would then block on a holder
    /// that no longer exists, and `notify_all` would walk the poisoned bucket;
    /// either wedges the child forever (`test_threading.test_reinit_tls_after_fork`
    /// forks from 16 threads — ~10% of children lost this race). Reinitialising
    /// the primitives in place sidesteps the global table entirely: a fresh
    /// `Condvar` has no registered waiters, and a fresh `Mutex` is unlocked, so
    /// neither touches a bucket on its fast path.
    ///
    /// SAFETY: `_at_fork_reinit` only runs from the `after_in_child` fork
    /// handlers, where this process has exactly one (the forking) thread, so
    /// nothing can race this in-place write. `ptr::write` deliberately skips
    /// dropping the old — possibly locked — primitives (dropping a locked
    /// `parking_lot` mutex is a no-op anyway, but the inherited parked state
    /// must not be touched).
    pub fn force_reset(&self) {
        unsafe {
            let p = std::ptr::from_ref(self).cast_mut();
            std::ptr::write(
                std::ptr::addr_of_mut!((*p).state),
                Mutex::new(LockState::default()),
            );
            std::ptr::write(std::ptr::addr_of_mut!((*p).cv), Condvar::new());
        }
    }
}

/// A real cross-thread reentrant mutex with CPython
/// `_thread.RLock` semantics. Multiple `acquire()`s from the
/// same OS thread succeed without blocking; release counts
/// down to zero before the lock actually becomes free.
#[derive(Debug)]
pub struct RealRLock {
    state: Mutex<RLockState>,
    cv: Condvar,
}

#[derive(Debug, Default)]
struct RLockState {
    owner: Option<u64>,
    depth: usize,
}

impl Default for RealRLock {
    fn default() -> Self {
        Self::new()
    }
}

impl RealRLock {
    pub fn new() -> Self {
        Self {
            state: Mutex::new(RLockState::default()),
            cv: Condvar::new(),
        }
    }

    pub fn try_acquire(&self, owner: u64) -> bool {
        let mut state = self.state.lock();
        match state.owner {
            Some(o) if o == owner => {
                state.depth += 1;
                true
            }
            None => {
                state.owner = Some(owner);
                state.depth = 1;
                true
            }
            _ => false,
        }
    }

    pub fn acquire(&self, owner: u64) {
        let mut state = self.state.lock();
        loop {
            match state.owner {
                Some(o) if o == owner => {
                    state.depth += 1;
                    return;
                }
                None => {
                    state.owner = Some(owner);
                    state.depth = 1;
                    return;
                }
                _ => self.cv.wait(&mut state),
            }
        }
    }

    pub fn acquire_timeout(&self, owner: u64, timeout: Duration) -> bool {
        let deadline = Instant::now() + timeout;
        let mut state = self.state.lock();
        loop {
            match state.owner {
                Some(o) if o == owner => {
                    state.depth += 1;
                    return true;
                }
                None => {
                    state.owner = Some(owner);
                    state.depth = 1;
                    return true;
                }
                _ => {
                    let now = Instant::now();
                    if now >= deadline {
                        return false;
                    }
                    let result = self.cv.wait_for(&mut state, deadline - now);
                    if result.timed_out() && state.owner.is_some() && state.owner != Some(owner) {
                        return false;
                    }
                }
            }
        }
    }

    /// Release. Returns the resulting depth (0 means fully released).
    pub fn release(&self, owner: u64) -> Result<usize, &'static str> {
        let mut state = self.state.lock();
        match state.owner {
            Some(o) if o == owner => {
                state.depth -= 1;
                if state.depth == 0 {
                    state.owner = None;
                    drop(state);
                    self.cv.notify_one();
                    Ok(0)
                } else {
                    Ok(state.depth)
                }
            }
            Some(_) => Err("cannot release foreign lock"),
            None => Err("cannot release un-acquired lock"),
        }
    }

    pub fn is_owned_by(&self, owner: u64) -> bool {
        self.state.lock().owner == Some(owner)
    }

    pub fn depth(&self) -> usize {
        self.state.lock().depth
    }

    /// `(owner thread id or 0, recursion depth)` in one snapshot — what
    /// 3.14's `RLock.__repr__` prints (`owner=… count=…`).
    pub fn owner_and_depth(&self) -> (u64, usize) {
        let state = self.state.lock();
        (state.owner.unwrap_or(0), state.depth)
    }

    /// Forcibly drop all ownership/recursion state, backing
    /// `_thread.RLock._at_fork_reinit()`. See [`RealLock::force_reset`] for the
    /// full rationale: `parking_lot` is not `fork`-safe, so we reinitialise the
    /// inner `Mutex`/`Condvar` in place (CPython's `pthread_mutex_init`) rather
    /// than locking/notifying the inherited — possibly poisoned — primitives.
    ///
    /// SAFETY: runs only on the lone surviving thread of a `fork(2)` child, so
    /// nothing can race this write; `ptr::write` skips dropping the old state.
    pub fn force_reset(&self) {
        unsafe {
            let p = std::ptr::from_ref(self).cast_mut();
            std::ptr::write(
                std::ptr::addr_of_mut!((*p).state),
                Mutex::new(RLockState::default()),
            );
            std::ptr::write(std::ptr::addr_of_mut!((*p).cv), Condvar::new());
        }
    }
}

/// A real cross-thread `threading.Event`. `set()` flips a
/// boolean; `clear()` flips it back; `wait(timeout=None)` blocks
/// until set or until the timeout expires. Backed by `Condvar`
/// so wakeups are immediate.
#[derive(Debug)]
pub struct RealEvent {
    state: Mutex<bool>,
    cv: Condvar,
}

impl Default for RealEvent {
    fn default() -> Self {
        Self::new()
    }
}

impl RealEvent {
    pub fn new() -> Self {
        Self {
            state: Mutex::new(false),
            cv: Condvar::new(),
        }
    }

    pub fn is_set(&self) -> bool {
        *self.state.lock()
    }

    pub fn set(&self) {
        let mut state = self.state.lock();
        *state = true;
        drop(state);
        self.cv.notify_all();
    }

    pub fn clear(&self) {
        *self.state.lock() = false;
    }

    /// Block until set. Always returns `true`.
    pub fn wait(&self) -> bool {
        let mut state = self.state.lock();
        while !*state {
            self.cv.wait(&mut state);
        }
        true
    }

    /// Block until set or until `timeout` elapses. Returns
    /// the flag's value at the time of return.
    pub fn wait_timeout(&self, timeout: Duration) -> bool {
        let deadline = Instant::now() + timeout;
        let mut state = self.state.lock();
        while !*state {
            let now = Instant::now();
            if now >= deadline {
                return *state;
            }
            self.cv.wait_for(&mut state, deadline - now);
        }
        *state
    }
}

/// Real `threading.Semaphore`. A counter that `acquire`
/// decrements (blocking when zero) and `release` increments.
#[derive(Debug)]
pub struct RealSemaphore {
    state: Mutex<usize>,
    cv: Condvar,
}

impl RealSemaphore {
    pub fn new(initial: usize) -> Self {
        Self {
            state: Mutex::new(initial),
            cv: Condvar::new(),
        }
    }

    pub fn try_acquire(&self) -> bool {
        let mut count = self.state.lock();
        if *count == 0 {
            false
        } else {
            *count -= 1;
            true
        }
    }

    pub fn acquire(&self) {
        let mut count = self.state.lock();
        while *count == 0 {
            self.cv.wait(&mut count);
        }
        *count -= 1;
    }

    pub fn acquire_timeout(&self, timeout: Duration) -> bool {
        let deadline = Instant::now() + timeout;
        let mut count = self.state.lock();
        while *count == 0 {
            let now = Instant::now();
            if now >= deadline {
                return false;
            }
            self.cv.wait_for(&mut count, deadline - now);
        }
        *count -= 1;
        true
    }

    pub fn release(&self, n: usize) {
        let mut count = self.state.lock();
        *count = count.saturating_add(n);
        drop(count);
        self.cv.notify_all();
    }

    pub fn current(&self) -> usize {
        *self.state.lock()
    }
}

/// Real `threading.Condition`. A `Mutex` + `Condvar` pair.
/// `wait()` releases the mutex, blocks until notified, and
/// re-acquires; `notify`/`notify_all` wake one or all waiters.
#[derive(Debug)]
pub struct RealCondition {
    /// The protected boolean is just a tick counter — Python
    /// callers track their own predicate state, we just need
    /// somewhere for `wait()` to release-and-reacquire.
    state: Mutex<u64>,
    cv: Condvar,
}

impl Default for RealCondition {
    fn default() -> Self {
        Self::new()
    }
}

impl RealCondition {
    pub fn new() -> Self {
        Self {
            state: Mutex::new(0),
            cv: Condvar::new(),
        }
    }

    pub fn wait(&self) {
        let mut tick = self.state.lock();
        let start = *tick;
        while *tick == start {
            self.cv.wait(&mut tick);
        }
    }

    pub fn wait_timeout(&self, timeout: Duration) -> bool {
        let deadline = Instant::now() + timeout;
        let mut tick = self.state.lock();
        let start = *tick;
        while *tick == start {
            let now = Instant::now();
            if now >= deadline {
                return false;
            }
            let result = self.cv.wait_for(&mut tick, deadline - now);
            if result.timed_out() {
                return *tick != start;
            }
        }
        true
    }

    pub fn notify(&self, n: usize) {
        let mut tick = self.state.lock();
        *tick = tick.wrapping_add(1);
        drop(tick);
        for _ in 0..n {
            self.cv.notify_one();
        }
    }

    pub fn notify_all(&self) {
        let mut tick = self.state.lock();
        *tick = tick.wrapping_add(1);
        drop(tick);
        self.cv.notify_all();
    }
}

/// Real `threading.Barrier`. `wait()` blocks until `parties`
/// threads have called it, then releases all of them.
#[derive(Debug)]
pub struct RealBarrier {
    parties: usize,
    state: Mutex<BarrierState>,
    cv: Condvar,
}

#[derive(Debug)]
struct BarrierState {
    waiting: usize,
    generation: u64,
    broken: bool,
}

impl RealBarrier {
    pub fn new(parties: usize) -> Self {
        Self {
            parties: parties.max(1),
            state: Mutex::new(BarrierState {
                waiting: 0,
                generation: 0,
                broken: false,
            }),
            cv: Condvar::new(),
        }
    }

    /// Wait at the barrier. Returns `Some(index)` (0..parties)
    /// if released normally; `None` if the barrier was broken.
    pub fn wait(&self, timeout: Option<Duration>) -> Option<usize> {
        let mut state = self.state.lock();
        if state.broken {
            return None;
        }
        let my_gen = state.generation;
        state.waiting += 1;
        let my_index = state.waiting - 1;
        if state.waiting == self.parties {
            state.generation = state.generation.wrapping_add(1);
            state.waiting = 0;
            drop(state);
            self.cv.notify_all();
            return Some(my_index);
        }
        if let Some(t) = timeout {
            let deadline = Instant::now() + t;
            while state.generation == my_gen && !state.broken {
                let now = Instant::now();
                if now >= deadline {
                    state.broken = true;
                    drop(state);
                    self.cv.notify_all();
                    return None;
                }
                self.cv.wait_for(&mut state, deadline - now);
            }
        } else {
            while state.generation == my_gen && !state.broken {
                self.cv.wait(&mut state);
            }
        }
        if state.broken {
            None
        } else {
            Some(my_index)
        }
    }

    pub fn reset(&self) {
        let mut state = self.state.lock();
        state.waiting = 0;
        state.generation = state.generation.wrapping_add(1);
        state.broken = false;
        drop(state);
        self.cv.notify_all();
    }

    pub fn abort(&self) {
        let mut state = self.state.lock();
        state.broken = true;
        drop(state);
        self.cv.notify_all();
    }

    pub fn n_waiting(&self) -> usize {
        self.state.lock().waiting
    }

    pub fn parties(&self) -> usize {
        self.parties
    }

    pub fn broken(&self) -> bool {
        self.state.lock().broken
    }
}

/// A reentrant guard for the GIL. A re-entrant mutex is necessary
/// because the eval loop may call back into Rust functions that
/// themselves want to assert "the GIL is held"; using a non-
/// reentrant mutex would deadlock the second nested acquisition.
#[derive(Debug)]
pub struct GilLock(ReentrantMutex<()>);

impl Default for GilLock {
    fn default() -> Self {
        Self::new()
    }
}

impl GilLock {
    pub fn new() -> Self {
        Self(ReentrantMutex::new(()))
    }

    pub fn lock(&self) -> parking_lot::ReentrantMutexGuard<'_, ()> {
        self.0.lock()
    }

    pub fn try_lock(&self) -> Option<parking_lot::ReentrantMutexGuard<'_, ()>> {
        self.0.try_lock()
    }

    pub fn try_lock_for(
        &self,
        timeout: std::time::Duration,
    ) -> Option<parking_lot::ReentrantMutexGuard<'_, ()>> {
        self.0.try_lock_for(timeout)
    }
}

/// A typed Arc alias for the threading primitives. Each `Object`
/// variant that wraps one of these uses this alias so the
/// "this is a thread-shareable handle" contract is visible at
/// the type level.
pub type Shared<T> = Arc<T>;

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;
    use std::thread;

    #[test]
    fn copy_cells_are_compact() {
        assert_eq!(std::mem::size_of::<Cell<bool>>(), 1);
        assert_eq!(std::mem::size_of::<Cell<u64>>(), 8);
    }

    #[test]
    fn cached_hash_preserves_python_hash_boundaries() {
        assert_eq!(std::mem::size_of::<CachedHash>(), 8);
        let cache = CachedHash::new(None);
        assert_eq!(cache.get(), None);
        assert_eq!(cache.clone().get(), None);
        for (value, expected) in [
            (0, 0),
            (-1, -2),
            (-2, -2),
            (1, 1),
            (i64::MIN, i64::MIN),
            (i64::MAX, i64::MAX),
        ] {
            cache.store(value);
            assert_eq!(cache.get(), Some(expected));
            let cloned = cache.clone();
            cache.store(value.wrapping_add(1));
            assert_eq!(cloned.get(), Some(expected));
            assert_eq!(CachedHash::new(Some(value)).get(), Some(expected));
        }
    }

    #[test]
    fn cached_hash_publication_and_updates_do_not_tear() {
        let cache = CachedHash::new(None);
        let barrier = std::sync::Barrier::new(5);
        let values = [i64::MIN, i64::MAX, -1, 0x1234_5678_7654_3210];
        let expected = [i64::MIN, i64::MAX, -2, 0x1234_5678_7654_3210];
        thread::scope(|scope| {
            for value in values {
                let cache = &cache;
                let barrier = &barrier;
                scope.spawn(move || {
                    barrier.wait();
                    for _ in 0..10_000 {
                        cache.store(value);
                    }
                });
            }
            barrier.wait();
            let mut published = false;
            for _ in 0..10_000 {
                match cache.get() {
                    Some(value) => {
                        assert!(expected.contains(&value));
                        published = true;
                    }
                    None => assert!(!published),
                }
            }
        });
        assert!(expected.contains(&cache.get().expect("writers published a hash")));
    }

    #[test]
    fn copy_cell_publishes_prior_writes() {
        use std::sync::atomic::{AtomicUsize, Ordering};
        let ready = Cell::new(false);
        let value = AtomicUsize::new(0);
        thread::scope(|scope| {
            scope.spawn(|| {
                value.store(42, Ordering::Relaxed);
                ready.set(true);
            });
            while !ready.get() {
                thread::yield_now();
            }
            assert_eq!(value.load(Ordering::Relaxed), 42);
        });
    }

    #[test]
    fn copy_cell_replacements_do_not_tear() {
        let cell = Cell::new(0_u64);
        let barrier = std::sync::Barrier::new(5);
        thread::scope(|scope| {
            for writer in 1_u64..=4 {
                let cell = &cell;
                let barrier = &barrier;
                scope.spawn(move || {
                    barrier.wait();
                    for _ in 0..10_000 {
                        let previous = cell.replace(writer << 32 | writer);
                        assert_eq!(previous >> 32, previous & 0xffff_ffff);
                    }
                });
            }
            barrier.wait();
            for _ in 0..10_000 {
                let observed = cell.get();
                assert_eq!(observed >> 32, observed & 0xffff_ffff);
            }
        });
    }

    // ----- GilCell tests (RFC 0025) -----

    #[test]
    fn gilcell_borrow_returns_inner() {
        let c = GilCell::new(42);
        assert_eq!(*c.borrow(), 42);
    }

    #[test]
    fn gilcell_borrow_mut_mutates() {
        let c = GilCell::new(1);
        *c.borrow_mut() = 7;
        assert_eq!(*c.borrow(), 7);
    }

    #[test]
    fn gilcell_multi_shared_borrows() {
        let c = GilCell::new(String::from("hello"));
        let a = c.borrow();
        let b = c.borrow();
        assert_eq!(&*a, &*b);
    }

    #[test]
    fn gilcell_mut_borrow_blocks_shared() {
        let c = GilCell::new(0_i32);
        let _m = c.borrow_mut();
        assert!(c.try_borrow().is_err());
    }

    #[test]
    fn gilcell_shared_borrow_blocks_mut() {
        let c = GilCell::new(0_i32);
        let _r = c.borrow();
        assert!(c.try_borrow_mut().is_err());
    }

    #[test]
    fn gilcell_release_re_enables() {
        let c = GilCell::new(0_i32);
        {
            let mut m = c.borrow_mut();
            *m = 9;
        }
        assert_eq!(c.get(), 9);
    }

    #[test]
    fn gilcell_replace_returns_old() {
        let c = GilCell::new(1);
        let old = c.replace(2);
        assert_eq!(old, 1);
        assert_eq!(c.get(), 2);
    }

    #[test]
    fn gilcell_take_resets_to_default() {
        let c: GilCell<Vec<i32>> = GilCell::new(vec![1, 2, 3]);
        let v = c.take();
        assert_eq!(v, vec![1, 2, 3]);
        assert!(c.borrow().is_empty());
    }

    #[test]
    fn gilcell_swap_exchanges() {
        let a = GilCell::new(1);
        let b = GilCell::new(2);
        a.swap(&b);
        assert_eq!(a.get(), 2);
        assert_eq!(b.get(), 1);
    }

    #[test]
    fn gilcell_is_send_sync() {
        fn assert_send<T: Send>() {}
        fn assert_sync<T: Sync>() {}
        assert_send::<GilCell<i32>>();
        assert_sync::<GilCell<i32>>();
        assert_send::<Rc<GilCell<String>>>();
        assert_sync::<Rc<GilCell<String>>>();
    }

    #[test]
    fn gilcell_cross_thread_mutation() {
        // The classic "list captured by worker mutates parent's
        // view" assertion that RFC 0025 promises.
        let shared = Rc::new(GilCell::new(Vec::<i32>::new()));
        let s2 = Rc::clone(&shared);
        let handle = thread::spawn(move || {
            for i in 0..5 {
                s2.borrow_mut().push(i);
            }
        });
        handle.join().unwrap();
        assert_eq!(*shared.borrow(), vec![0, 1, 2, 3, 4]);
    }

    #[test]
    fn gilcell_contended_borrows_publish_consistent_state() {
        let shared = Rc::new(GilCell::new((0_u64, 0_u64)));
        let start = Arc::new(std::sync::Barrier::new(8));
        let workers: Vec<_> = (0..8)
            .map(|_| {
                let shared = shared.clone();
                let start = start.clone();
                thread::spawn(move || {
                    start.wait();
                    for _ in 0..2_000 {
                        {
                            let a = shared.borrow();
                            let b = shared.borrow();
                            assert_eq!(a.0, b.1);
                            assert!(shared.try_borrow_mut().is_err());
                        }
                        let mut pair = shared.borrow_mut();
                        assert!(shared.try_borrow().is_err());
                        assert!(shared.try_borrow_mut().is_err());
                        pair.0 += 1;
                        pair.1 += 1;
                    }
                })
            })
            .collect();
        for worker in workers {
            worker.join().unwrap();
        }
        assert_eq!(*shared.borrow(), (16_000, 16_000));
    }

    #[test]
    fn gilcell_clone_deep_copies() {
        let a = GilCell::new(vec![1, 2, 3]);
        let b = a.clone();
        b.borrow_mut().push(4);
        assert_eq!(*a.borrow(), vec![1, 2, 3]);
        assert_eq!(*b.borrow(), vec![1, 2, 3, 4]);
    }

    #[test]
    fn gilcell_reentrant_shared_borrow_on_same_thread() {
        let c = GilCell::new(7_i32);
        let a = c.borrow();
        let b = c.borrow();
        assert_eq!(*a, 7);
        assert_eq!(*b, 7);
    }

    #[test]
    #[should_panic(expected = "GilCell::borrow_mut")]
    fn gilcell_nested_borrow_mut_panics() {
        let c = GilCell::new(0_i32);
        let _a = c.borrow_mut();
        let _b = c.borrow_mut();
    }

    // ----- RealLock / RealRLock / RealEvent / RealSemaphore /
    // RealBarrier tests (RFC 0024) -----

    #[test]
    fn lock_basic_acquire_release() {
        let l = RealLock::new();
        assert!(!l.is_locked());
        assert!(l.try_acquire(1));
        assert!(l.is_locked());
        assert!(!l.try_acquire(2));
        l.release().unwrap();
        assert!(!l.is_locked());
    }

    #[test]
    fn rlock_reentrant() {
        let l = RealRLock::new();
        assert!(l.try_acquire(1));
        assert!(l.try_acquire(1));
        assert_eq!(l.depth(), 2);
        assert_eq!(l.release(1).unwrap(), 1);
        assert_eq!(l.release(1).unwrap(), 0);
    }

    #[test]
    fn event_signal_across_threads() {
        let e = Arc::new(RealEvent::new());
        let e2 = Arc::clone(&e);
        let handle = thread::spawn(move || e2.wait());
        thread::sleep(Duration::from_millis(20));
        e.set();
        assert!(handle.join().unwrap());
    }

    #[test]
    fn semaphore_blocks_at_zero() {
        let s = RealSemaphore::new(2);
        assert!(s.try_acquire());
        assert!(s.try_acquire());
        assert!(!s.try_acquire());
        s.release(1);
        assert!(s.try_acquire());
    }

    #[test]
    fn barrier_releases_all_parties() {
        let b = Arc::new(RealBarrier::new(3));
        let mut handles = Vec::new();
        for _ in 0..3 {
            let b2 = Arc::clone(&b);
            handles.push(thread::spawn(move || b2.wait(None)));
        }
        for h in handles {
            assert!(h.join().unwrap().is_some());
        }
    }
}

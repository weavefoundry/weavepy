import os
def leaf(x0, x1, x2, x3):
    return x0 + x1 + x2 + x3

def bench(n):
    f = leaf
    total = 0
    for i in range(n):
        total += f(i, 1, 2, 3)
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

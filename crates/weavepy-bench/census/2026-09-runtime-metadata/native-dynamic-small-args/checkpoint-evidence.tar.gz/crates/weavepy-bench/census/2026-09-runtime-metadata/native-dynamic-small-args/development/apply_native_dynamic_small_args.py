"""Use initialized inline positional arguments only in the generic call helper."""
from pathlib import Path
p=Path('crates/weavepy-vm/src/tier2.rs')
text=p.read_text()
assert 'enum DynCallArguments' not in text
start=text.index('    let n = (argc + kwc) as usize;',text.index('unsafe fn call_dyn_impl('))
end=text.index('\n/// RFC 0076 WS7 follow-up — charge one generic',start)
old=text[start:end]
text=text[:start]+'''    // Keep generic argument storage out of the compiled-callee entry path.
    // SAFETY: the same live frame/context and initialized marshal entries
    // are transferred to the generic helper; no borrow crosses Python here.
    unsafe { call_dyn_generic(jf, ctx, callee, argc, kwc, names, int_result) }
}

/// Small positional calls need no temporary heap argument vector. Keyword
/// calls retain the vector so their tail can move into the keyword list.
enum DynCallArguments {
    Small([Object; 4]),
    Large(Vec<Object>),
}

/// Generic dispatch owns its argument storage, including across nested calls.
/// Keeping it outlined avoids adding the inline array to compiled-callee entry.
///
/// # Safety
///
/// The live activation and initialized marshal entries match `wpjit_call_dyn`.
#[inline(never)]
unsafe fn call_dyn_generic(
    jf: &mut JitFrame,
    ctx: &mut CallCtx,
    callee: Object,
    argc: u32,
    kwc: u32,
    names: u32,
    int_result: bool,
) -> i64 {
    // SAFETY: the entering interpreter remains dormant during this helper.
    let interp = unsafe { &mut *ctx.interp };
'''+old+text[end:]
start=text.index('unsafe fn call_dyn_generic(')
prefix=text[:start]
body=text[start:]
body=body.replace('    let mut args: Vec<Object> = Vec::with_capacity(n);','''    let mut args = if kwc == 0 && n <= 4 {
        DynCallArguments::Small(std::array::from_fn(|_| Object::None))
    } else {
        DynCallArguments::Large(Vec::with_capacity(n))
    };''',1)
body=body.replace('        args.push(unpack_pins(bits, tag, &ctx.pins));','''        let value = unpack_pins(bits, tag, &ctx.pins);
        match &mut args {
            DynCallArguments::Small(items) => items[j] = value,
            DynCallArguments::Large(items) => items.push(value),
        }''',1)
body=body.replace('        for (c, v) in items.iter().zip(args.split_off(argc as usize)) {','''        let DynCallArguments::Large(args) = &mut args else {
            return CallStatus::Reject as i64;
        };
        for (c, v) in items.iter().zip(args.split_off(argc as usize)) {''',1)
body=body.replace('    // Arbitrary Python runs on behalf of this activation (RFC 0067','''    let positional = match &args {
        DynCallArguments::Small(items) => &items[..n],
        DynCallArguments::Large(items) => items.as_slice(),
    };
    // Arbitrary Python runs on behalf of this activation (RFC 0067''',1)
body=body.replace('i.call_object_with_globals(&callee, &args, &kwargs, &ctx.globals)','i.call_object_with_globals(&callee, positional, &kwargs, &ctx.globals)',1)
p.write_text(prefix+body)
print('Applied initialized short positional argument storage in an outlined generic helper.')

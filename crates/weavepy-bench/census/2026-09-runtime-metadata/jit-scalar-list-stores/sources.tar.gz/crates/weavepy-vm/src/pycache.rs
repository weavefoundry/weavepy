//! `__pycache__` (PEP 3147) cache for compiled bytecode.
//!
//! On every import from source we try to read a sibling
//! `__pycache__/<name>.<cache_tag>.pyc` file. If its header is valid,
//! the embedded code object is unmarshaled and returned, skipping the
//! parser + compiler entirely. If the cache file is missing,
//! outdated, or malformed, we fall back to recompiling and write a
//! fresh cache file on the way out (subject to `-B` /
//! `PYTHONDONTWRITEBYTECODE`).
//!
//! ## File layout
//!
//! The 16-byte header mirrors CPython's PEP 552 timestamp-invalidation
//! mode, with WeavePy's own magic so CPython and WeavePy can coexist
//! in the same `__pycache__` directory without confusion:
//!
//! ```text
//! +----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//! |  MAGIC (4)        |  FLAGS  (4) = 0   |  MTIME (4)        |  SIZE (4)         |
//! +----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+----+
//! |  marshal.dumps(code) ...                                                       |
//! ```
//!
//! - **MAGIC**: 4 bytes. `b"WPY0"` for this format version. Bumped
//!   when the bytecode shape changes incompatibly.
//! - **FLAGS**: 4 bytes, little-endian. Reserved for the future
//!   PEP 552 hash-mode bit; today always `0`.
//! - **MTIME**: little-endian u32 source mtime in seconds (Unix epoch).
//! - **SIZE**: little-endian u32 source file size in bytes. Used as a
//!   cheap second-line check against in-place edits that preserve mtime.
//! - **Body**: the output of `marshal.dumps(code_object)`.

use crate::sync::Rc;
use crate::sync::RefCell;
use std::fs;
use std::path::{Path, PathBuf};

use weavepy_compiler::CodeObject;

use crate::object::{DictData, Object};
use crate::stdlib::marshal_mod;

/// Bytecode magic. RFC 0033 adopts CPython's value (3.14's 3627,
/// `b"\x2b\x0e\x0d\x0a"`, surfaced via `importlib.util.MAGIC_NUMBER`
/// and `_imp.get_magic()`; RFC 0077 WS9 moved it from 3.13's 3571).
/// Collisions with CPython's own `.pyc` files are avoided by the
/// distinct [`CACHE_TAG`] in the filename, so adopting the real magic
/// costs nothing and buys tool interop. The single source is the
/// compiler's `MAGIC_NUMBER` so `marshal` and the cache can't drift.
pub const MAGIC: &[u8; 4] = &weavepy_compiler::cpython_code::MAGIC_NUMBER;

/// Cache tag — appears in `__pycache__/<name>.<tag>.pyc` and on
/// `sys.implementation.cache_tag`. Mirrors CPython's `cpython-314`
/// shape: `<impl>-<major><minor>` with **no dot** in the tag itself
/// (PEP 3147's `<name>.<tag>.pyc` parsing — e.g. `source_from_cache`,
/// which `runpy`/`make_legacy_pyc` rely on — keys off the first dot, so
/// a dotted tag like `weavepy-3.14` would corrupt the recovered source
/// name). Distinct from CPython's `cpython-314` so the artifacts never
/// collide.
///
/// The trailing `-<rev>` is WeavePy's **bytecode-format revision**, our
/// only lever for invalidating stale `.pyc` on a compiler change: we pin
/// [`MAGIC`] to CPython's value (so `importlib.util.MAGIC_NUMBER` /
/// `_imp.get_magic()` match for `test_importlib.test_magic_number` and
/// external-tool interop), which means we *cannot* bump the magic the way
/// CPython does. Bumping the tag changes the `.pyc` *filename*, so both
/// readers that key off `cache_tag` — the native [`cache_path_for`] and
/// the frozen `importlib._bootstrap_external` — uniformly miss the old
/// artifact and recompile from source. Both hyphens keep the tag dotless,
/// so PEP 3147 source recovery still resolves `<name>.py`.
///
/// - rev `2`: WTF-8 string constants. Pre-rev `.pyc` compiled lone
///   surrogates in literals (`'\udfff'`) lossily to U+FFFD; rev 2 stores
///   them faithfully (`test_posixpath.test_realpath_invalid_paths`,
///   `test_os`/`test_tarfile` surrogate paths).
/// - rev `3`: `SETUP_ANNOTATIONS` opcode. Module/class bodies containing
///   annotated statements now bind `__annotations__` at block entry
///   (create-if-absent) instead of lazily at the first annotation.
/// - rev `4`: RFC 0051 PEP 695 lowering. Type parameters now capture
///   `*Ts`/`**P` kinds, bounds/constraints, and PEP 696 defaults via
///   the `__weavepy_typevar__` intrinsic family and append the
///   implicit `Generic[…]` base; pre-rev `.pyc` baked the name-only
///   placeholder lowering.
/// - rev `12`: RFC 0056 WS4 invalidation. Rev-11 artifacts in the wild
///   were written across intermediate compiler changes (notably module
///   `__doc__` binding) without a bump, so a stale `.pyc` could import a
///   module with `__doc__ = None` (doctest found no module-level
///   examples in `test_doctest2`). One bump flushes them all.
/// - rev `13`: PEP 657 column spans in the location table (long entry
///   form). Rev-12 `.pyc`s carried the no-column form only, so modules
///   imported from cache lost traceback caret underlines
///   (test_doctest's error-report examples compare them textually).
/// - rev `14`: PEP 488 `.opt-N` variants + `source_to_code(_optimize=)`
///   honoured. Rev-13 `.opt-1`/`.opt-2` artifacts (written by
///   `py_compile`/`compileall`) contain *unoptimized* code under the
///   optimized filename; one bump flushes them before the native
///   reader starts trusting the suffix.
/// - rev `15`: class bodies store `__static_attributes__` *after* the
///   body statements (CPython 3.13's emission order, observed by
///   `__prepare__` mappings — test_metaclass), and comprehension
///   `GET_ITER`/`FOR_ITER` carry the iterable expression's column span
///   (test_dictcomps/test_listcomps `test_exception_locations`).
///   Rev-14 artifacts bake the old ordering and whole-comprehension
///   spans.
/// - rev `16`: `*x` splats lower through `LIST_EXTEND` /
///   `LIST_TO_TUPLE` (CPython's shape; the errors carry CPython's
///   "Value after * must be an iterable" / func-prefixed wording —
///   test_extcall), replacing the old `tuple(x)`-by-name lowering.
///   Rev-15 artifacts still call the possibly-shadowed `tuple` builtin.
/// - rev `17`: RFC 0057 match-codegen rewrite changed three encoding
///   conventions: `COPY` carries its real depth (was hardcoded 1),
///   `UNPACK_EX` uses CPython's byte order (before-star count in the
///   low byte; ours had it in the high byte), and `BINARY_OP` encodes
///   in-place operators as `NB_INPLACE_*` indexes (the augmented flag
///   was previously dropped). Rev-16 artifacts decode incorrectly
///   under all three.
/// - rev `18`: RFC 0057 trace-fidelity work changed codegen shape:
///   jump threading with CPython's synthetic/same-line eligibility,
///   `pass` lowered to a located NOP, and per-site `return None`
///   copies gated by the same eligibility. Rev-17 artifacts bake the
///   over-threaded jumps (spurious/missing `'line'` trace events).
/// - rev `19`: `PUSH_EXC_INFO` persists its handler-body-end tag (the
///   unwinder's cue for discarding handled-exception entries when an
///   exception escapes a handler) as an absolute code-unit oparg.
///   Rev-18 artifacts decode the tag as 0 (untagged), which loosens
///   handled-exception unwinding and corrupts `__context__` chains
///   (test_contextlib_async `test_exit_exception_chaining_reference`).
/// - rev `20`: RFC 0060 trace-fidelity: the `def` STORE carries the
///   `def` statement's location (was the unset line, tracing as line
///   1), and a decorated function's code starts at the first
///   decorator line (`co_firstlineno` / 'call' event parity).
/// - rev `21`: RFC 0060 trace-fidelity continued: function docstrings
///   emit no code (no traced NOP on the docstring line), class
///   `__doc__` stores carry the docstring statement's location, and
///   all-constant tuple displays fold to one `LoadConst`.
/// - rev `22`: RFC 0060 trace-fidelity continued: `break`/`continue`
///   emit a located NOP (their line traces before an inlined
///   `finally`), decorated classes start at the first decorator line,
///   `except*` prologue/match/no-match blocks carry the clause's
///   location while the PREP_RERAISE_STAR epilogue and named-exception
///   unbinds are NO_LOCATION, and the plain-`except` handler-exit
///   POP_EXCEPT/unbind are NO_LOCATION (CPython's flowgraph
///   propagation semantics for trace events).
/// - rev `24`: RFC 0066 WS6: a class body now owns the implicit
///   `__class__` cell when a method *locally binds and loads* `super`
///   (CPython symtable's "Special-case super" —
///   matplotlib `_mathtext.Parser.subsuper`); previously the method's
///   claimed freevar dangled and the class assembled with a bad cell
///   index.
/// - rev `25`: RFC 0068 WS1: production-compiler optimizations — AST
///   constant folding (ast_opt), `not`-inversion in branch positions,
///   the comprehension assignment idiom, unconditional-jump-to-return
///   inlining, and unreachable-code elimination all change emitted
///   bytecode shapes.
/// - rev `26`: RFC 0068 WS1: the internal call convention adopts
///   CPython's self-or-null slot (`PUSH_NULL`, method-flagged
///   `LOAD_ATTR`, self-riding `CALL`); every call-family instruction
///   changed its stack shape and `Call`/`CallSelf` arg meanings, so
///   rev-25 artifacts decode into miscounted calls.
/// - rev `27`: RFC 0068 WS1 (test_dis parity): loops end with CPython's
///   dead `END_FOR`/`POP_TOP` pair (the exhausted `FOR_ITER` skips it),
///   f-string conversions are a separate `CONVERT_VALUE` instruction
///   (`FORMAT_SIMPLE`/`FORMAT_WITH_SPEC` carry no conversion bits — a
///   rev-26 `FORMAT_*` with baked conversion bits decodes conversion-
///   less), and `COMPARE_OP` opargs carry the specialization mask +
///   branch-fused bool bit.
/// - rev `43`: RFC 0068 WS5 (test_inspect source retrieval): lambda code
///   objects report the lambda *expression's* line as `co_firstlineno`
///   (was the enclosing statement's line — `getsource` on a lambda in a
///   multiline display returned the whole statement), and a class body's
///   implicit `__firstlineno__` store honours a `nonlocal
///   __firstlineno__` declaration (STORE_DEREF, keeping it out of the
///   class namespace).
/// - rev `44`: RFC 0068 WS6 (test_source_encoding): source decoding
///   normalizes `\r\n`/`\r` line endings to `\n` before tokenizing
///   (CPython's `translate_newlines`), changing compiled string-literal
///   constants in CR/CRLF sources.
/// - rev `45`: RFC 0068 WS6 (test_pathlib): docstrings are cleaned at
///   compile time (CPython 3.13's `_PyCompile_CleanDoc`, gh-81283) —
///   tabs expanded, common leading whitespace stripped — changing the
///   `__doc__` constants baked into every cached module.
/// - rev `46`: RFC 0068 WS7 (test_bool): the AST constant folder keeps
///   `bool op bool` results bool for `&`/`|`/`^` and no longer folds
///   `~bool` (the runtime DeprecationWarning must fire, gh-103487),
///   changing folded constants.
/// - rev `47`: RFC 0068 WS8 (test_pdb): the return-path unwind now pops
///   `for`-loop iterators sitting above a `with`'s `__exit__` slot
///   (CPython's FOR_LOOP fblock unwind) — `return` inside `for` inside
///   `with` previously called the iterator as the exit function.
/// - rev `48`: RFC 0068 WS8 (test_pdb): an expression statement's POP_TOP
///   is emitted with NO_LOCATION like CPython's codegen_expr_stmt
///   (gh-127321) — at a boolop merge target it stays location-less,
///   changing line tables.
/// - rev `49`: RFC 0077 WS9 (CPython 3.14 codegen): the compiler now owns
///   the whole class-body prologue (`__module__ = __name__`, the
///   `__classdict__` seed and `__classdictcell__` store, `COPY 1;
///   RETURN_VALUE` of `__classcell__`), and `__build_class__` no longer
///   injects `__module__`; the flowgraph port also changed instruction
///   streams (wire marks, `BUILD_SLICE` 2/3, `NOT_TAKEN`, superinstruction
///   lowering). Rev-48 artifacts would build classes without `__module__`.
/// - rev `50`: RFC 0077 WS9 continued: `DICT_UPDATE` grew CPython's depth
///   oparg (`arg >> 1`; the mapping-pattern `**rest` copy is `DICT_UPDATE
///   2`), `BUILD_INTERPOLATION` adopted CPython's oparg layout (bit 0 =
///   format spec, `>> 2` = conversion), constant set displays fold through
///   `SET_UPDATE` (rev-49 artifacts written mid-wave folded to a set
///   *containing* the frozenset), `import a.b as c` stores before its
///   `POP_TOP`, and generator lambdas drop the StopIteration wrapper.
/// - rev `51`: RFC 0077 WS10: PEP 695 generics compile to CPython's
///   `CALL_INTRINSIC_1` / `CALL_INTRINSIC_2` shape (type-parameter
///   binders, `INTRINSIC_SUBSCRIPT_GENERIC`, `INTRINSIC_TYPEALIAS`,
///   `INTRINSIC_SET_FUNCTION_TYPE_PARAMS`) instead of calls to the
///   `__weavepy_typevar__` builtin family, which no longer exists.
/// - rev `52`: RFC 0077 Phase II (the 3.14 switch): the prefix becomes
///   `weavepy-314`, [`MAGIC`] becomes 3627, and the bundled stdlib is
///   CPython 3.14.7's, so every 3.13-era artifact is retired at once.
/// - rev `53`: RFC 0077 Phase II marshal-parity work changed folded
///   constants (3.14 mixed-mode complex arithmetic in the AST folder,
///   `patma` fold shapes, complex `**` by `_Py_c_prod`), the linetable
///   decoder, and `co_localsplusnames` for annotation scopes; rev-52
///   artifacts written mid-wave carry the old constant values.
pub const CACHE_TAG: &str = weavepy_version::vconcat!(weavepy_version::CACHE_TAG_PREFIX, "-53");

const HEADER_LEN: usize = 16;

/// Resolve the `__pycache__/<name>.<tag>[.opt-N].pyc` companion for a
/// source file. CPython routes the cache to `<source_dir>/__pycache__/...`
/// unless `sys.pycache_prefix` redirects elsewhere; we follow the
/// same shape. `optimize` selects the PEP 488 suffix: level 0 is
/// untagged, `-O`/`-OO` read and write `.opt-1`/`.opt-2` variants (an
/// import under `-O` updates exactly the `opt-1` artifact —
/// `test_compileall.HardlinkDedupTests.test_import`).
pub fn cache_path_for(source: &Path, optimize: u8) -> Option<PathBuf> {
    let stem = source.file_stem()?.to_string_lossy().into_owned();
    let dir = source.parent()?;
    let cache_dir = dir.join("__pycache__");
    let name = if optimize == 0 {
        format!("{stem}.{CACHE_TAG}.pyc")
    } else {
        format!("{stem}.{CACHE_TAG}.opt-{optimize}.pyc")
    };
    Some(cache_dir.join(name))
}

/// Returns true when the user has asked us not to persist `.pyc`s.
/// Reads `sys.dont_write_bytecode` (set by the CLI or by user code).
pub fn dont_write_bytecode(sys_module: &Rc<RefCell<DictData>>) -> bool {
    let dict = sys_module.borrow();
    match dict.get(&crate::object::DictKey(Object::from_static(
        "dont_write_bytecode",
    ))) {
        Some(Object::Bool(b)) => *b,
        Some(Object::Int(i)) => *i != 0,
        _ => false,
    }
}

/// Try to load a cached code object for `source_path`. Returns
/// `Some(code)` on a healthy hit; returns `None` if the cache is
/// missing, stale, or malformed (so the caller falls back to source
/// compilation).
pub fn try_load(source_path: &Path, optimize: u8) -> Option<CodeObject> {
    let cache_path = cache_path_for(source_path, optimize)?;
    let src_meta = fs::metadata(source_path).ok()?;
    let src_mtime = mtime_seconds(&src_meta);
    let src_size = u32::try_from(src_meta.len()).ok()?;
    let bytes = fs::read(&cache_path).ok()?;
    if bytes.len() < HEADER_LEN {
        return None;
    }
    if &bytes[0..4] != MAGIC {
        return None;
    }
    // FLAGS at [4..8] — reserved.
    let mtime_bytes: [u8; 4] = bytes[8..12].try_into().ok()?;
    let size_bytes: [u8; 4] = bytes[12..16].try_into().ok()?;
    let cache_mtime = u32::from_le_bytes(mtime_bytes);
    let cache_size = u32::from_le_bytes(size_bytes);
    if cache_mtime != src_mtime || cache_size != src_size {
        return None;
    }
    let body = &bytes[HEADER_LEN..];
    match marshal_mod::load_from_bytes(body).ok()? {
        Object::Code(c) => {
            let mut code = own_decoded_code(c);
            // The cache may have been written under a different spelling of
            // the same file (a symlinked `sys.path` entry — e.g. a vendored
            // `Lib -> /opt/.../python3.14`). CPython re-imports record the
            // *current* path in `co_filename` (each interpreter writes its
            // own pyc from the path it used); a stale spelling here would
            // diverge from the module's `__file__` and break consumers that
            // bridge the two (`warnings.warn(stacklevel=)` filename checks).
            let current = source_path.to_string_lossy();
            if code.filename != current {
                rewrite_filenames(&mut code, &current);
            }
            Some(code)
        }
        _ => None,
    }
}

/// Reuse freshly decoded code while preserving the shared-root clone fallback.
pub(crate) fn own_decoded_code(code: Rc<CodeObject>) -> CodeObject {
    // The decoder has released its reference table, so the normal case can
    // move the root and later relocate uniquely owned children in place.
    Rc::unwrap_or_clone(code)
}

/// Recursively stamp `filename` on a code object and every nested code
/// constant (function/class bodies, comprehensions).
pub(crate) fn rewrite_filenames(code: &mut CodeObject, filename: &str) {
    code.filename = filename.to_owned();
    fn walk(c: &mut weavepy_compiler::Constant, filename: &str) {
        match c {
            // Freshly decoded pools own their code Arcs uniquely, so
            // `make_mut` rewrites in place (no clone).
            weavepy_compiler::Constant::Code(inner) => {
                let inner = std::sync::Arc::make_mut(inner);
                rewrite_filenames(inner, filename)
            }
            weavepy_compiler::Constant::Tuple(items) => {
                for it in items {
                    walk(it, filename);
                }
            }
            _ => {}
        }
    }
    for c in &mut code.constants {
        walk(c, filename);
    }
}

/// Persist the compiled code object alongside its source. Errors are
/// silently swallowed (matching CPython): a read-only filesystem or a
/// missing parent directory shouldn't fail the import.
pub fn try_write(source_path: &Path, code: &CodeObject, optimize: u8) {
    let Some(cache_path) = cache_path_for(source_path, optimize) else {
        return;
    };
    let Ok(meta) = fs::metadata(source_path) else {
        return;
    };
    let mtime = mtime_seconds(&meta);
    let Ok(size) = u32::try_from(meta.len()) else {
        return;
    };
    if let Some(parent) = cache_path.parent() {
        let _ = fs::create_dir_all(parent);
    }
    let mut bytes = Vec::with_capacity(HEADER_LEN + 256);
    bytes.extend_from_slice(MAGIC);
    bytes.extend_from_slice(&0u32.to_le_bytes());
    bytes.extend_from_slice(&mtime.to_le_bytes());
    bytes.extend_from_slice(&size.to_le_bytes());
    let code_obj = Object::Code(Rc::new(code.clone()));
    let Ok(payload) = marshal_mod::b_dumps(&[code_obj]) else {
        return;
    };
    if let Object::Bytes(b) = payload {
        bytes.extend_from_slice(&b);
    } else {
        return;
    }
    // Atomic-ish write: write to a tempfile next door, then rename
    // so concurrent imports can't observe a half-written cache.
    // CPython's `_write_atomic` creates the file with the *source's*
    // permission bits (forced user-writable for later cache updates —
    // issue #6074) masked to 0o666, letting the umask apply at open
    // (test_import.FilePermissionTests).
    let tmp = cache_path.with_extension("pyc.tmp");
    #[cfg(unix)]
    {
        use std::io::Write;
        use std::os::unix::fs::{OpenOptionsExt, PermissionsExt};
        let mode = (meta.permissions().mode() | 0o200) & 0o666;
        let Ok(mut f) = fs::OpenOptions::new()
            .write(true)
            .create(true)
            .truncate(true)
            .mode(mode)
            .open(&tmp)
        else {
            return;
        };
        if f.write_all(&bytes).is_err() {
            drop(f);
            let _ = fs::remove_file(&tmp);
            return;
        }
    }
    #[cfg(not(unix))]
    if fs::write(&tmp, &bytes).is_err() {
        return;
    }
    let _ = fs::rename(&tmp, &cache_path);
}

fn mtime_seconds(meta: &fs::Metadata) -> u32 {
    use std::time::UNIX_EPOCH;
    meta.modified()
        .ok()
        .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
        .map(|d| u32::try_from(d.as_secs() & u64::from(u32::MAX)).unwrap_or(0))
        .unwrap_or(0)
}

#[cfg(test)]
mod ownership_tests {
    use super::*;
    use weavepy_compiler::{compile_module, Constant};

    #[test]
    fn decoded_code_relocates_without_copying_unique_children() {
        let module = weavepy_parser::parse_module(
            "def outer(x):\n    def inner(y):\n        return x + y\n    return inner\n",
        )
        .unwrap();
        let mut code = compile_module(&module).unwrap();
        rewrite_filenames(&mut code, "old/module.py");
        let Object::Bytes(bytes) = marshal_mod::b_dumps(&[Object::Code(Rc::new(code))]).unwrap()
        else {
            panic!("marshal must return bytes");
        };
        let Object::Code(decoded) = marshal_mod::load_from_bytes(&bytes).unwrap() else {
            panic!("marshal must return code");
        };
        assert_eq!(Rc::strong_count(&decoded), 1);
        let expected = (*decoded).clone();
        let mut code = own_decoded_code(decoded);
        assert_eq!(code, expected);
        drop(expected);
        fn collect(code: &CodeObject, rows: &mut Vec<(*const CodeObject, String)>) {
            for c in &code.constants {
                if let Constant::Code(inner) = c {
                    rows.push((Rc::as_ptr(inner), inner.filename.clone()));
                    collect(inner, rows);
                }
            }
        }
        let mut before = Vec::new();
        collect(&code, &mut before);
        assert_eq!(before.len(), 2);
        rewrite_filenames(&mut code, "relocated/module.py");
        let mut after = Vec::new();
        collect(&code, &mut after);
        assert_eq!(code.filename, "relocated/module.py");
        assert_eq!(before.len(), after.len());
        for ((old_ptr, old_name), (new_ptr, new_name)) in before.iter().zip(&after) {
            assert_eq!(old_ptr, new_ptr);
            assert_eq!(old_name, "old/module.py");
            assert_eq!(new_name, "relocated/module.py");
        }
    }

    #[test]
    fn relocation_preserves_shared_code_and_nested_tuple_constants() {
        let child = Rc::new(CodeObject {
            name: "child".to_owned(),
            filename: "original.py".to_owned(),
            ..CodeObject::default()
        });
        let root = Rc::new(CodeObject {
            filename: "original.py".to_owned(),
            constants: vec![Constant::Tuple(vec![Constant::Code(child.clone())])],
            ..CodeObject::default()
        });
        let mut moved = own_decoded_code(root.clone());
        rewrite_filenames(&mut moved, "relocated.py");
        assert_eq!(root.filename, "original.py");
        assert_eq!(child.filename, "original.py");
        let Constant::Tuple(items) = &moved.constants[0] else {
            panic!("expected tuple");
        };
        let Constant::Code(relocated) = &items[0] else {
            panic!("expected code");
        };
        assert_eq!(relocated.filename, "relocated.py");
        assert!(!Rc::ptr_eq(&child, relocated));
    }
}

"""Freeze generic native-call argument storage and declared measurement methods."""
from pathlib import Path
import hashlib
import json
import difflib

out = Path('target/native-dynamic-small-args-prebuild.json')
assert not out.exists()
original = json.loads(Path('target/ascii-time-format-prebuild.json').read_text())['sources']
changed = [p for p, digest in original.items() if hashlib.sha256(Path(p).read_bytes()).hexdigest() != digest]
assert set(changed) == {'crates/weavepy-vm/src/tier2.rs', 'crates/weavepy-vm/src/lib.rs'}, changed
paths = set(original)
paths.add('tests/regrtest/test_dynamic_argument_storage.py')
methods = [Path('target') / name for name in [
    'build_native_dynamic_small_args.sh', 'check_native_dynamic_small_args.sh', 'check_native_dynamic_small_args_native.sh',
    'validate_native_dynamic_small_args.sh', 'measure_native_dynamic_small_args_focused.sh', 'measure_native_dynamic_small_args_full.sh',
    'summarize_native_dynamic_small_args.py', 'verify_native_dynamic_small_args_ready.py', 'freeze_native_dynamic_small_args_sources.py',
    'native-dynamic-small-args-protocol.md', 'prepare_native_dynamic_small_args_inputs.py', 'prepare_native_dynamic_small_args_inputs_v2.py', 'prepare_native_dynamic_small_args_methods.py',
    'check_native_dynamic_small_args_coverage.py', 'apply_native_dynamic_small_args.py', 'native-dynamic-small-args-input-oracles-v2.json',
    'measure_verified_python_components.py', 'freeze_runtime_candidate.py', 'capture_runtime_environment.py',
    'run_serial_performance_gate.py', 'run_performance_under_load_gate.py', 'shared_slot_keys_startup_probes.py',
    'summarize_runtime_suite.py',
]]
methods += [Path('tools/bench_compare.py'), Path('tests/regrtest/expectations.toml'),
            Path('crates/weavepy-bench/census/2026-09-runtime-metadata/validate.py')]
methods += list(Path('target/native-dynamic-small-args-inputs-v2').rglob('*.py'))
methods += list(Path('target/native-dynamic-small-args-inputs-v2').rglob('preparation.json'))
def hashes(names):
    return {str(p): hashlib.sha256(Path(p).read_bytes()).hexdigest() for p in sorted(names)}
out.write_text(json.dumps({'sources': hashes(paths), 'methods': hashes(methods)}, indent=2) + '\n')
diff = []
for name in changed:
    before = (Path('target/native-dynamic-small-args-preimages') / Path(name).name).read_text()
    after = Path(name).read_text()
    diff += difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='predecessor/' + name, tofile='candidate/' + name)
Path('target/native-dynamic-small-args-review.diff').write_text(''.join(diff))
print('Frozen', len(paths), 'source identities and', len(methods), 'methods/inputs.')

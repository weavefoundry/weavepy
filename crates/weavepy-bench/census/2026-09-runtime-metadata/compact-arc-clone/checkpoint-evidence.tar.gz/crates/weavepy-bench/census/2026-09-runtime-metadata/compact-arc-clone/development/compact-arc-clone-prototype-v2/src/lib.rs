//! Unapplied compact Arc owner. Allocation layout and all reference counts stay with Arc.
use std::borrow::Borrow;
use std::fmt;
use std::hash::{Hash, Hasher};
use std::marker::PhantomData;
use std::mem::{size_of, ManuallyDrop};
use std::ops::Deref;
use std::ptr::{self, NonNull};
use std::sync::{Arc, Weak};

mod sealed {
    pub trait Sealed {}
}

/// Metadata needed to reconstruct exactly the original Arc pointee.
///
/// # Safety
/// metadata and pointer must round-trip every valid pointee, preserving its
/// address, metadata, size, alignment, validity, and destruction. Implementations
/// are sealed and may not infer a different allocation or modify the pointee.
pub unsafe trait ArcMetadata: sealed::Sealed {
    fn metadata(&self) -> usize;
    fn pointer(data: *const (), metadata: usize) -> *const Self;
}
impl<T> sealed::Sealed for [T] {}
// SAFETY: a slice's only pointer metadata is its unchanged element count.
unsafe impl<T> ArcMetadata for [T] {
    fn metadata(&self) -> usize {
        self.len()
    }
    fn pointer(data: *const (), len: usize) -> *const Self {
        ptr::slice_from_raw_parts(data.cast::<T>(), len)
    }
}
impl sealed::Sealed for str {}
// SAFETY: str has byte-slice metadata, and only valid Arc<str> values enter.
unsafe impl ArcMetadata for str {
    fn metadata(&self) -> usize {
        self.len()
    }
    fn pointer(data: *const (), len: usize) -> *const Self {
        ptr::slice_from_raw_parts(data.cast::<u8>(), len) as *const str
    }
}

const POINTER_BYTES: usize = size_of::<usize>();
const METADATA_BYTES: usize = if POINTER_BYTES == 8 { 7 } else { POINTER_BYTES };
const INDIRECT: [u8; METADATA_BYTES] = [u8::MAX; METADATA_BYTES];

/// An Arc strong reference with compact pointer metadata.
///
/// On 64-bit targets the handle is 15 bytes, aligned to one byte. Packed fields
/// are copied by value; no references to the potentially unaligned pointer are
/// formed. Metadata that doesn't fit is stored in an individually owned Box of
/// the original Arc, so compact metadata never imposes an allocation-size cap.
#[repr(C, packed)]
pub struct CompactArc<T: ?Sized + ArcMetadata> {
    data: NonNull<()>,
    metadata: [u8; METADATA_BYTES],
    ownership: PhantomData<Arc<T>>,
}
// SAFETY: the pointer only owns Arc references. These are Arc's Send/Sync
// bounds; packed pointer fields are read by value without misaligned references.
unsafe impl<T: ?Sized + ArcMetadata + Send + Sync> Send for CompactArc<T> {}
unsafe impl<T: ?Sized + ArcMetadata + Send + Sync> Sync for CompactArc<T> {}

pub struct CompactWeak<T: ?Sized + ArcMetadata>(Weak<T>);
impl<T: ?Sized + ArcMetadata> CompactArc<T> {
    pub fn from_arc(arc: Arc<T>) -> Self {
        let len = arc.metadata();
        let bytes = len.to_le_bytes();
        let mut metadata = [0; METADATA_BYTES];
        metadata.copy_from_slice(&bytes[..METADATA_BYTES]);
        if bytes[METADATA_BYTES..].iter().any(|&b| b != 0) || metadata == INDIRECT {
            return Self::indirect(arc);
        }
        let raw = Arc::into_raw(arc).cast::<()>().cast_mut();
        Self {
            // SAFETY: Arc::into_raw returns a non-null, live allocation pointer.
            data: unsafe { NonNull::new_unchecked(raw) },
            metadata,
            ownership: PhantomData,
        }
    }
    fn indirect(arc: Arc<T>) -> Self {
        Self {
            data: NonNull::from(Box::leak(Box::new(arc))).cast(),
            metadata: INDIRECT,
            ownership: PhantomData,
        }
    }
    #[cold]
    #[inline(never)]
    fn clone_indirect(&self) -> Self {
        Self::from_arc(Arc::clone(&self.arc_view()))
    }
    #[inline]
    fn inline_metadata(&self) -> usize {
        let mut bytes = [0; POINTER_BYTES];
        // Read exactly the stored bytes. An eight-byte load from a seven-byte
        // field could overread the enclosing owner, so don't use one here.
        bytes[..METADATA_BYTES].copy_from_slice(&self.metadata);
        usize::from_le_bytes(bytes)
    }
    #[inline]
    fn raw(&self) -> *const T {
        if self.metadata == INDIRECT {
            // SAFETY: this handle uniquely owns this Box<Arc<T>>. The Arc in
            // that box owns one reference to the original payload.
            let arc = unsafe { &*self.data.cast::<Arc<T>>().as_ptr() };
            Arc::as_ptr(arc)
        } else {
            T::pointer(self.data.as_ptr(), self.inline_metadata())
        }
    }
    #[inline]
    fn arc_view(&self) -> ManuallyDrop<Arc<T>> {
        // SAFETY: borrow our one accounted strong reference without releasing
        // it. For indirect handles the Box still owns that same Arc reference.
        ManuallyDrop::new(unsafe { Arc::from_raw(self.raw()) })
    }
    #[inline]
    pub fn as_ptr(this: &Self) -> *const T {
        this.raw()
    }
    #[inline]
    pub fn ptr_eq(this: &Self, other: &Self) -> bool {
        Arc::ptr_eq(&this.arc_view(), &other.arc_view())
    }
    pub fn strong_count(this: &Self) -> usize {
        Arc::strong_count(&this.arc_view())
    }
    pub fn weak_count(this: &Self) -> usize {
        Arc::weak_count(&this.arc_view())
    }
    pub fn downgrade(this: &Self) -> CompactWeak<T> {
        CompactWeak(Arc::downgrade(&this.arc_view()))
    }
    pub fn get_mut(this: &mut Self) -> Option<&mut T> {
        let mut view = this.arc_view();
        let raw = ptr::from_mut(Arc::get_mut(&mut view)?);
        // SAFETY: Arc checked unique strong ownership and no weak references.
        // The returned borrow is tied to &mut this; the temporary view neither
        // adds nor releases ownership. Slice metadata cannot change through it.
        unsafe { Some(&mut *raw) }
    }
}
impl<T: ?Sized + ArcMetadata> Clone for CompactArc<T> {
    #[inline]
    fn clone(&self) -> Self {
        if self.metadata == INDIRECT {
            return self.clone_indirect();
        }
        // SAFETY: this live owner already holds one strong Arc reference.
        // Increment it for the new owner, preserving the original pointee and
        // its metadata. Arc performs the same overflow check as Arc::clone.
        unsafe { Arc::increment_strong_count(self.raw()) };
        Self {
            data: self.data,
            metadata: self.metadata,
            ownership: PhantomData,
        }
    }
}
impl<T: ?Sized + ArcMetadata> Drop for CompactArc<T> {
    #[inline]
    fn drop(&mut self) {
        if self.metadata == INDIRECT {
            // SAFETY: exactly this strong handle owns this Box and its Arc.
            // Other indirect clones have distinct boxes and their own Arcs.
            unsafe { drop(Box::from_raw(self.data.cast::<Arc<T>>().as_ptr())) }
        } else {
            // SAFETY: release exactly the strong reference consumed by from_arc.
            unsafe { drop(Arc::from_raw(self.raw())) }
        }
    }
}
impl<T: ?Sized + ArcMetadata> Deref for CompactArc<T> {
    type Target = T;
    #[inline]
    fn deref(&self) -> &T {
        // SAFETY: reconstruction preserves the original initialized pointee,
        // which remains alive through this owner's accounted Arc reference.
        unsafe { &*self.raw() }
    }
}
impl<T: ?Sized + ArcMetadata> AsRef<T> for CompactArc<T> {
    fn as_ref(&self) -> &T {
        self
    }
}
impl<T: ?Sized + ArcMetadata + fmt::Debug> fmt::Debug for CompactArc<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}
impl<T: ?Sized + ArcMetadata + PartialEq> PartialEq for CompactArc<T> {
    fn eq(&self, other: &Self) -> bool {
        **self == **other
    }
}
impl<T: ?Sized + ArcMetadata + Eq> Eq for CompactArc<T> {}
impl<T: ?Sized + ArcMetadata + PartialOrd> PartialOrd for CompactArc<T> {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        (**self).partial_cmp(&**other)
    }
}
impl<T: ?Sized + ArcMetadata + Ord> Ord for CompactArc<T> {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        (**self).cmp(&**other)
    }
}
impl<T: ?Sized + ArcMetadata + Hash> Hash for CompactArc<T> {
    fn hash<H: Hasher>(&self, h: &mut H) {
        (**self).hash(h)
    }
}
impl<T: ?Sized + ArcMetadata> CompactWeak<T> {
    pub fn upgrade(&self) -> Option<CompactArc<T>> {
        self.0.upgrade().map(CompactArc::from_arc)
    }
    pub fn strong_count(&self) -> usize {
        self.0.strong_count()
    }
    pub fn weak_count(&self) -> usize {
        self.0.weak_count()
    }
}
impl<T: ?Sized + ArcMetadata> Clone for CompactWeak<T> {
    fn clone(&self) -> Self {
        Self(self.0.clone())
    }
}
impl<T: ?Sized + ArcMetadata> fmt::Debug for CompactWeak<T> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&self.0, f)
    }
}
pub type SharedSlice<T> = CompactArc<[T]>;
pub type WeakSlice<T> = CompactWeak<[T]>;
pub type SharedStr = CompactArc<str>;
pub type WeakStr = CompactWeak<str>;
impl<T> Borrow<[T]> for SharedSlice<T> {
    fn borrow(&self) -> &[T] {
        self
    }
}
impl Borrow<str> for SharedStr {
    fn borrow(&self) -> &str {
        self
    }
}
impl<T> From<Vec<T>> for SharedSlice<T> {
    fn from(value: Vec<T>) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl<T> From<Box<[T]>> for SharedSlice<T> {
    fn from(value: Box<[T]>) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl<T: Clone> From<&[T]> for SharedSlice<T> {
    fn from(value: &[T]) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl<T: Clone, const N: usize> From<&[T; N]> for SharedSlice<T> {
    fn from(value: &[T; N]) -> Self {
        Self::from(&value[..])
    }
}
impl From<&str> for SharedStr {
    fn from(value: &str) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl From<String> for SharedStr {
    fn from(value: String) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl From<&String> for SharedStr {
    fn from(value: &String) -> Self {
        Self::from(value.as_str())
    }
}
impl From<Box<str>> for SharedStr {
    fn from(value: Box<str>) -> Self {
        Self::from_arc(Arc::from(value))
    }
}
impl fmt::Display for SharedStr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[cfg(test)]
#[path = "tests.rs"]
mod tests;

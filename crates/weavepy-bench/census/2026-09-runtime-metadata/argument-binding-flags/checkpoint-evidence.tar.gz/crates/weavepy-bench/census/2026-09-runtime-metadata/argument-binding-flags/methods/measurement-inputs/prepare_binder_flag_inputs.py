"""Freeze small/large signature controls before binder flag candidate timing."""
import hashlib,json
from pathlib import Path
root=Path('target/binder-flag-inputs');root.mkdir()
cases={}
for count in [16,17,64,130]:
    params=', '.join('a'+str(i)+'='+str(i) for i in range(count))
    cases['defaults_'+str(count)]=f'''def leaf({params}):
    return a0 + a{count-1}

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(a{count-1}=5, a0=i)
    return total
'''
for count in [16,17,64]:
    params=', '.join('a'+str(i)+'='+str(i) for i in range(count))
    cases['keyword_only_'+str(count)]=f'''def leaf(*, {params}):
    return a0 + a{count-1}

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(a{count-1}=5, a0=i)
    return total
'''
for count in [14,15]:
    params=', '.join('a'+str(i)+'='+str(i) for i in range(count))
    cases['variadic_'+str(count)]=f'''def leaf({params}, *args, **kwargs):
    return a0 + a{count-1} + len(args) + len(kwargs)

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(a{count-1}=5, a0=i, spare=2)
    return total
'''
body='\n'.join('    body'+str(i)+' = a + '+str(i) for i in range(130))
cases['many_body_locals']=f'''def leaf(a, b=2):
{body}
    return body0 + body129 + b

def bench(n):
    total = 0
    for i in range(n):
        total += leaf(b=3, a=i)
    return total
'''
rows={};work=10000
for name,source in cases.items():
    p=root/(name+'.py');p.write_text(source)
    d=root/(name+'-verify.py');d.write_text(f'''import json, sys, types
module = types.ModuleType("_weavepy_bench")
module.__file__ = {str(p)!r}
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
first = module.bench({work})
for unused in range(3):
    module.bench({work})
last = module.bench({work})
print(json.dumps(first, sort_keys=True))
print(json.dumps(last, sort_keys=True))
''')
    rows[name]={'path':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'driver':str(d),'driver_sha256':hashlib.sha256(d.read_bytes()).hexdigest()}
(root/'preparation.json').write_text(json.dumps({'work':work,'rows':rows},indent=2)+'\n')
(root/'protocol.md').write_text('''# Binder flag storage controls

Prepared before any binder flag candidate build or timing. Ten signature controls
span the inline threshold, large default/keyword-only signatures, variadic slots,
and many body locals. Use seven paired samples, both modes, exact CPython values,
and per-binary frozen caches through the unchanged component helper. These add
to, not replace, the ten existing call shapes and four warm/four cold exceptions.
Perform native coverage checks before interpreting any timer as native work.
Preserve every sample and regression. Complete the current early-entry experiment
before applying the separate binder flag change or measuring these inputs.
''')
print('Prepared',len(cases),'new signature controls; no execution or timing.')

import os

import pickle

class Point:
    __slots__ = ("x", "y", "tag")

    def __init__(self, x, y, tag):
        self.x = x
        self.y = y
        self.tag = tag

class Record:
    def __init__(self, i):
        self.ident = i
        self.name = "record-%d" % i
        self.points = [Point(i + k, i - k, "p%d" % k) for k in range(4)]
        self.meta = {"kind": "rec", "seq": i, "flags": (True, False, None)}

payload = {
        "ints": list(range(200)),
        "floats": [x * 0.5 for x in range(100)],
        "strs": ["item-%d" % i for i in range(100)],
        "nested": {str(i): {"a": i, "b": [i, i + 1, i + 2]} for i in range(50)},
        "tuples": [(i, i * 2, "t") for i in range(50)],
        "bytes": bytes(range(256)) * 4,
    }
records = [Record(i) for i in range(20)]
protocol = 5
blob = pickle.dumps(payload, protocol=protocol)
def once():
    return pickle.dumps(payload, protocol=protocol)
def bench(n):
    total = 0
    for _ in range(n):
        result = once()
        total += len(result)
    return total

"""Capture real accelerated pickle calls and predecessor binding behavior."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root=Path('target/pickle-special-lookup-paths');root.mkdir()
source=Path('target/pickle_special_lookup_path_probe.py')
(root/source.name).write_bytes(source.read_bytes())
report={'probe_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'native_paths':{},'binding_observations':{}}
new='target/release/weavepy-runtime-pickle-special-lookup'
old='target/release/weavepy-runtime-jit-raise-call-spans'

def run(binary,jit,flags,source):
    env=dict(os.environ)
    for key in ['WEAVEPY_JIT_TRACE','WEAVEPY_VM_STATS','WEAVEPY_JIT_THRESHOLD']:
        env.pop(key,None)
    digest=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    env.update(WEAVEPY_JIT=jit,WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
               WEAVEPY_FROZEN_CACHE=str((root/'frozen'/digest).resolve()))
    command=[binary,*flags,str(source)]
    result=subprocess.run(command,env=env,text=True,capture_output=True,timeout=120)
    return {'command':command,'binary_sha256':digest,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}

def save():
    (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')

for mode,jit,flags in [('jit','1',[]),('interp','0',[]),('gil0','1',['-X','gil=0'])]:
    result=run(new,jit,flags,root/source.name)
    report['native_paths'][mode]=result;save()
    assert result['returncode']==0,(mode,result)
    print(mode,result['stdout'].strip(),flush=True)

probe=root/'binding-kinds.py'
probe.write_text('''import copyreg, json
class Example:
    def __getstate__(self):
        return {'value': 7}
obj = Example()
method = copyreg._lookup_special(obj, '__getstate__')
print(json.dumps({'binding_type': type(method).__name__,
                  'function_type_has_get': hasattr(type(Example.__getstate__), '__get__'),
                  'state': method()}, sort_keys=True))
''')
report['binding_probe_sha256']=hashlib.sha256(probe.read_bytes()).hexdigest()
for label,binary in [('base',old),('new',new)]:
    result=run(binary,'1',[],probe)
    report['binding_observations'][label]=result;save()
    assert result['returncode']==0,(label,result)
    print(label,result['stdout'].strip(),flush=True)
report['status']='passed';save()

import importlib.util
import json
spec = importlib.util.spec_from_file_location("assertion_control", '/Users/owencarey/Documents/weavefoundry/weavepy/target/assertion-exit-inputs/warm/assert_list.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(5000)
for _ in range(6):
    module.bench(5000)
last = module.bench(5000)
print(json.dumps(first))
print(json.dumps(last))

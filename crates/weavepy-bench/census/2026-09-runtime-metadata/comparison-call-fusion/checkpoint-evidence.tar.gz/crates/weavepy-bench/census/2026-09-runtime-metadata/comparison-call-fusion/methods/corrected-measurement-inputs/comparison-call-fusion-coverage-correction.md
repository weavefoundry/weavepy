# Exercise the unfused local-operand native path

The original semantic regression passed but cmp_fusion_local stayed interpreted:
the unseeded analyzer propagated the opaque result type into n and rejected
MixedArithTypes, so its TypeUnknown-only parameter-seeding retry never ran.
The native-coverage assertion correctly failed. All original logs, methods,
source hashes, and the first source snapshot remain preserved.

The corrected fixture adds n = n + 0 before the comparison, establishing the
integer lane for this integer-only control. It passed CPython and unchanged
e709 in three modes before replacing the active test. Runtime Rust sources and
binary c277 are unchanged; this Python test isn't part of the built executable.
Run its three candidate modes and a new combined 23-function coverage check.
Timing must use only the v2 focused launcher, which requires both corrected
checks. Do not count the first coverage attempt as successful or rerun its
results directory. No timing had started. Corrected source/method snapshots
are separate and explicitly post-build.

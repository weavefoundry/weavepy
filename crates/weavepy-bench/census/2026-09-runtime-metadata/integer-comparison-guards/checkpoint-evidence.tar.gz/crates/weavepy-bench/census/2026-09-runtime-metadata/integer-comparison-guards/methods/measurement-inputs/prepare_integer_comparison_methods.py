"""Prepare a distinct, prespecified comparison-guard experiment."""
from pathlib import Path
import json

prefix = 'integer-comparison-guards'
old = 'jit-assertion-exits'
items = [('build_jit_assertion_exits.sh', 'build_integer_comparison_guards.sh'),
         ('check_jit_assertion_exits.sh', 'check_integer_comparison_guards.sh'),
         ('validate_jit_assertion_exits.sh', 'validate_integer_comparison_guards.sh'),
         ('measure_jit_assertion_exits_focused_v2.sh', 'measure_integer_comparison_guards_focused.sh'),
         ('measure_jit_assertion_exits_full.sh', 'measure_integer_comparison_guards_full.sh'),
         ('summarize_jit_assertion_exits.py', 'summarize_integer_comparison_guards.py'),
         ('inspect_jit_assertion_exits.py', 'inspect_integer_comparison_guards.py')]
for source, destination in items:
    s = Path('target/' + source).read_text()
    s = s.replace(old, prefix).replace('weavepy-runtime-compact-intern-pools', 'weavepy-runtime-jit-assertion-exits')
    s = s.replace('jit_assertion_exits', 'integer_comparison_guards')
    # The assertion regression remains part of the unchanged targeted set.
    if source.startswith('check_'):
        s = s.replace('for test in test_integer_comparison_guards ', 'for test in test_integer_comparison_guards test_jit_assertion_exits ')
    if source.startswith('build_'):
        s = s.replace('target/measure_integer_comparison_guards_focused.sh', 'target/measure_integer_comparison_guards_focused.sh')
    if source.startswith('measure_') and 'focused' in source:
        s = '\n'.join(line for line in s.splitlines() if 'extra-discovery/report.json' not in line) + '\n'
        s = s.replace('assertion-exit-inputs', 'integer-comparison-inputs').replace('13 warm assertion/datetime/recovery', '15 warm comparison/datetime/recovery').replace('four cold assertion frequencies', 'four cold comparison frequencies')
    if source.startswith('summarize_'):
        s = s.replace('assertion-exit', 'comparison-guard').replace('("warm", 13)', '("warm", 15)').replace('== 17', '== 19').replace('All 17 controls', 'All 19 controls')
    if source.startswith('inspect_'):
        a=s.index('required = ');b=s.index('\nassert required <=',a)
        s=s[:a]+'required = {"cmp_" + op + "_" + side for op in ("lt", "le", "eq", "ne", "gt", "ge") for side in ("left", "right", "branch")} | {"cmp_loop"}'+s[b:]
        s=s.replace('assertion coverage', 'comparison coverage').replace('All six assertion functions', 'All 19 comparison functions')
    p=Path('target/'+destination);assert not p.exists();p.write_text(s)
print('Prepared',len(items),'methods; no candidate or timing yet.')

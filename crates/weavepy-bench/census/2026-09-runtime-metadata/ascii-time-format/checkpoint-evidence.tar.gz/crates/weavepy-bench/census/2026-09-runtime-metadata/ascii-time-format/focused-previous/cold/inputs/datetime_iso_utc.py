import os
from datetime import datetime, timezone
values = [datetime(2024, 2, 29, i % 24, i % 60, (i * 7) % 60, (i * 1999) % 1000000, tzinfo=timezone.utc) for i in range(64)]
def bench(n):
    total = 0
    for i in range(n):
        text = values[i & 63].isoformat()
        total += len(text) + ord(text[-1])
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))

# Borrow positional and keyword-only default overrides

The measured reference is retained bf2:
bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4.
The source predecessor is the fully measured positional-only trial 44c5:
44c5ae82231f44182d2aac1b216d64fccdf712edce4b812baff573d3ea39befb.
This experiment adds keyword-only borrowing and an all-arguments-supplied guard
to that predecessor. Report the combined change against bf2; no new direct
performance attribution against 44c5 is implied.

Preserve phase 73's positional borrowing and its regression test. In the adjacent
keyword-only block, skip default processing when all keyword-only arguments are
filled. Otherwise borrow the override dictionary, inspect the same plain-string
keys in the same order, and clone only values filling missing arguments. None
still clears defaults and compiled defaults remain the fallback. Release all
borrows before rendering errors or executing user code. Do not introduce string
hash probes that could call exotic-key equality under a dictionary borrow.
No unsafe operation or ownership/allocation layout changes.

The new oracle must pass on CPython and bf2 in JIT, interpreter, and GIL-disabled
modes. It covers sparse/all-supplied calls, unrelated keys, aliases, dictionary
mutation inside the callee, weak-reference liveness, None/deletion, compiled
defaults, code replacement, missing-argument errors, and bound methods. Run 347
VM tests, the full C API package, strict lint/format, and no-JIT compilation.
After building the release CLI, freeze source/method/input/binary identities.
Run 93 targeted Python checks and the unchanged 275-check outside-sandbox
compatibility suite. Existing ownership layouts do not require new Miri trials.

Retain the 12 phase 73 positional fixture sources unchanged and add 12 analogous
keyword-only controls: widths 1, 4, 16, and 64 with omitted or partially supplied
overrides, widths 4 and 64 with all keywords supplied, and widths 4 and 64 with
compiled defaults. The width-one partial-keyword control supplies every keyword
and exercises the new skip guard. Each of 24 cold and 24 warm controls performs
20,000 calls. Independently check CPython checksums. The unchanged sampler
verifies all variants against CPython before/after warmup, including GIL-disabled
correctness, then retains seven alternating pairs with one declared stabilization
cycle per row and unchanged per-binary-SHA frozen caches.

Run two stages sequentially against bf2: focused controls, then 31 startup/import
samples and five alternating pairs of the unchanged 24-fixture census. Keep the
historical 21-row, 23-workload, and 24-process cohorts distinct. Retain every
sample, loss, failure, load observation, VM/swap snapshot, and identity.
Use run_serial_performance_gate.py outside the filesystem sandbox; its lease
covers the entire gate and child. Inspect completion before each dependent
stage. The unchanged gate requires three 10-second observations with one- and
five-minute load averages at most half the CPU count, waiting up to 600 seconds
per attempt. No owned build/test/profile/install, runtime edit, or active-harness
edit may overlap a gate that can launch or a measurement. Never discard samples
because load later rises.

The goal remains unachieved. No universal, energy, controlled build-time,
portability, or native parallel-scaling claim follows from these experiments.

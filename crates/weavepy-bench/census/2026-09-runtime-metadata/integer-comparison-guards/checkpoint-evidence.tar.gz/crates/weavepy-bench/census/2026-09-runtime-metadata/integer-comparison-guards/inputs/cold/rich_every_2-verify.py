import importlib.util
import json
spec = importlib.util.spec_from_file_location("comparison_control", '/Users/owencarey/Documents/weavefoundry/weavepy/target/integer-comparison-inputs/cold/rich_every_2.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(5000)
for _ in range(6):
    module.bench(5000)
last = module.bench(5000)
print(json.dumps(first))
print(json.dumps(last))

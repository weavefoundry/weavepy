"""Declare the complete native unobserved-shell validation and timing protocol."""
from pathlib import Path

old='native-dynamic-small-args'
new='native-unobserved-shell'
def adapt(text):
    return text.replace(old,new).replace('native_dynamic_small_args','native_unobserved_shell').replace('test_dynamic_argument_storage','test_native_activation_shell_reuse')
def write(name,text):
    p=Path('target')/name;assert not p.exists(),p;p.write_text(text)
for stem in ['build','validate','measure']:
    suffixes=[''] if stem!='measure' else ['_focused','_full']
    for suffix in suffixes:
        name=f'{stem}_native_unobserved_shell{suffix}.sh'
        s=adapt(Path(f'target/{stem}_native_dynamic_small_args{suffix}.sh').read_text())
        s=s.replace('26 first-invocation','29 first-invocation').replace('26 repeated','29 repeated')
        write(name,s)
s=adapt(Path('target/check_native_dynamic_small_args.sh').read_text())
s += '''python3.14 target/check_native_unobserved_shell_frame_identity.py > target/native-unobserved-shell-checks/frame-identity.txt 2>&1
'''
s=s.replace("printf 'done\\n'  > target/native-unobserved-shell-check-stage.txt\n",'')
s += "printf 'done\\n' > target/native-unobserved-shell-check-stage.txt\n"
write('check_native_unobserved_shell.sh',s)
s=adapt(Path('target/summarize_native_dynamic_small_args.py').read_text()).replace("('cold',26),('warm',26)","('cold',29),('warm',29)")
write('summarize_native_unobserved_shell.py',s)
write('native-unobserved-shell-protocol.md','''# Reuse unobserved native activation frame shells

Phase 76 is deferred and its two source preimages and CLI were restored to 6810.
All 339 predecessor source hashes matched before this change. The direct
reference is 681043b9f62cbd4fdb3f73756ecdf8ac877c1923b6a509f11ff1128dc973443c.
The retained acceptance reference is bf2db3c58aae37ad8dee45c0859585a32af2cd44c97a2dcaed7a61f9f0df40e4.

Each CallCtx has a Cell containing at most one exclusively owned, unmaterialized
shell. Take it before a callback, refresh the exact call-site lasti, push a
clone, and release the spine clone after the callback. No cache or mutable shell
borrow crosses arbitrary Python. Retain the allocation only when has_materialized
is false and Rc::get_mut excludes both strong and weak observers. All four
context constructors initialize the cache empty; framed entries pass through.
The cache lasts only for this activation. Code, globals, builtins, and cells
already have owners in that context. Callback arguments/results are not cached.
There is no new raw pointer, allocator, or ownership representation.

Observed frames keep the predecessor's behavior. Native frame identity, full
locals materialization, clear/continuation semantics, and final instruction
positions are separate work. Preserve the independent frame-identity diagnostic:
CPython and interpreter mode keep one identity; predecessor JIT returns distinct
frames. Require no new divergence in that diagnostic. No identity-fix claim.

Require all 353 VM tests, 156 C API tests, strict format/lint, no-JIT check,
99 targeted Python checks, and the unchanged 275-check outside-sandbox suite.
The new Python oracle passes on CPython and predecessor JIT/interpreter/GIL0.
Test-only counters must show actual native allocation, at least 100 shell reuses,
and at least 10 observer exclusions. A Rust test excludes strong, weak, and
materialized observers. No release counters. Capture static stack prologues;
an additional context field and cached shells are potential memory tradeoffs.

All original 26 measured fixture sources are unchanged. The initial 28-input
set adds single-callback and observed-callback controls; retain it and its
baseline traces. The v2 set preserves all 28 and adds a recursive-callback
control to expose retention across nested native activations. All 29 independent
CPython checksums must pass twice. Before timing, capture untimed predecessor
and candidate paths and prove the intended generic drivers and compiled alias
controls compile. Single and recursive controls must compile their native
callee too. Require at least 30,000 relevant calls in the verification driver.
Document the original wide-argument and tuple-unpack controls that remain
interpreted, plus inherited formatter and binding controls with their actual
paths. Coverage traces are not timing evidence.

Freeze all source, method, input, and binary identities after the correct
release CLI build. Run four sequential timing stages: focused-previous,
full-previous, focused-retained, full-retained. Each focused stage keeps seven
alternating pairs for all 29 cold and warm controls with 20,000 work units.
Use the unchanged sampler, stabilization, CPython output checks before/after
warmup, correctness-only GIL0 checks, per-binary-SHA frozen caches, and unchanged
cache assertions. Each full stage retains 31 samples for nine startup/import
controls and five alternating pairs for the unchanged 24-fixture census.

Every stage runs outside the filesystem sandbox through the exclusive serial
lease and unchanged load gate. Inspect session completion, complete/0 gate JSON,
and stage done before a dependent launch. The gate requires three 10-second
observations with both one- and five-minute loads at most half the CPU count,
waiting at most 600 seconds before declining to launch. No owned build, test,
profile, install, runtime edit, or active-harness edit may overlap a gate that
can launch or measure. Do not filter or retry launched samples. Keep all gains,
losses, failures, raw samples, sources, identities, VM/swap snapshots, and load
observations. Separate the historical 21-row, 23-workload, and 24-process cohorts.
The user goal remains unachieved. No universal, energy, controlled build-time,
portability, or native parallel-scaling claim follows.
''')
s=adapt(Path('target/freeze_native_dynamic_small_args_sources.py').read_text())
s=s.replace("'native-unobserved-shell-protocol.md', 'prepare_native_unobserved_shell_inputs.py', 'prepare_native_unobserved_shell_inputs_v2.py', 'prepare_native_unobserved_shell_methods.py',", "'native-unobserved-shell-protocol.md', 'prepare_native_unobserved_shell_inputs.py', 'prepare_native_unobserved_shell_inputs_v2.py', 'prepare_native_unobserved_shell_methods.py',")
s=s.replace("'check_native_unobserved_shell_coverage.py', 'apply_native_unobserved_shell.py', 'native-unobserved-shell-input-oracles-v2.json',", "'check_native_unobserved_shell_coverage.py', 'check_native_unobserved_shell_frame_identity.py', 'native-unobserved-shell-input-oracles-v2.json', 'native-unobserved-shell-oracle.py', 'native-unobserved-shell-baseline-oracles/report.json', 'inspect_native_unobserved_shell_codegen.py',")
write('freeze_native_unobserved_shell_sources.py',s)
print('Prepared build, checks, freeze, summaries, and four-stage measurement protocol. Readiness and code-generation methods are prepared separately before freezing.')

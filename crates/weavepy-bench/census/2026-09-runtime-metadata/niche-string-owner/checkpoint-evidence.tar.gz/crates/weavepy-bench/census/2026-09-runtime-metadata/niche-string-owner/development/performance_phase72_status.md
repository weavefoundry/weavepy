# Phase72: aligned UTF-8 owner with reserved enum byte

The active candidate changes only shared_value.rs from retained bf2. All other
336 original source identities matched before application. The actual Object,
Option<Object>, and DictKey remain16 bytes, SharedStr becomes16 aligned bytes,
and bytes/WStr/tuple owners remain8 bytes. The tuple header is unchanged.

Standalone six-test ownership prototype passes ordinary tests, strict-provenance
Miri on ARM64/i686, and clippy. Preserve the initial formatting failure caused
by the then-missing tests.rs. Codegen wrapper observations are not VM speed proof.
Integrated native validation passed353 VM tests,156 C API tests, clippy,
no-JIT compilation, and14 Miri tests per architecture using exact storage
modules with Object/CachedHash stubs. No source correction was required.

Release build is running in session98405 via build_niche_string_owner.sh.
Expected snapshot/binary paths use niche-string-owner. After inspecting successful
completion, run check_niche_string_owner.sh, then outside-sandbox compatibility
and extra checks. Complete all before running verify_niche_string_owner_ready.py.

Two planned timing stages against bf2 only: niche-string-owner-focused-retained
and niche-string-owner-full-retained, with matching *-load.json files. Use the
mandatory run_serial_performance_gate.py exclusive lease wrapper outside the
sandbox. Inspect stage completion before launching a dependent stage. No build,
test, profile, runtime edit, or active-harness edit while a gate can launch or
measurements run. Keep all outcomes and logs. Protocol is frozen before build.

Phase70 packed-owner and phase71 direct-clone trials are deferred and fully
archived. The restoration proof is target/compact-arc-clone-restoration.json;
their old intermediate status files are superseded by final archive REPORTs.

Goal remains unachieved. No new commit or push in this continuation.

## Release and targeted checks

Release completed in4m04s observed, not a controlled build-time result.
Candidate SHA6b4d28aa0f39d9cd64c863d954f9af8355811aab79c9b26ed5f21a3bdaadcd3b;
44,137,120bytes. All336 source hashes and78 method/input hashes matched after
build. The87 targeted Python checks passed. Outside-sandbox compatibility then
extra checks are running sequentially in session7751. No timing gate has started.
An independent unapplied future default-binding oracle is saved in
borrowed-defaults-ownership-draft.py; it has not been run or added to this trial.

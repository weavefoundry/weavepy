#!/bin/bash
set -euo pipefail
python3.14 - <<'PYGATE'
import json
from pathlib import Path
r = json.loads(Path('target/jit-raise-call-spans-focused-load.json').read_text())
assert r['status'] == 'not_started' and 'child_pid' not in r
assert not Path('target/jit-raise-call-spans-focused').exists()
PYGATE
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
test "$(cat target/jit-raise-call-spans-validation-stage.txt)" = done
test ! -e target/jit-raise-call-spans-diagnostic-v2
mkdir target/jit-raise-call-spans-diagnostic-v2
vm_stat > target/jit-raise-call-spans-diagnostic-v2/vm-before.txt
sysctl hw.memsize vm.swapusage > target/jit-raise-call-spans-diagnostic-v2/memory-before.txt
for group in kernels calls exceptions cold-exceptions; do
    extra=(--samples 7)
    if [ "$group" = cold-exceptions ]; then extra+=(--cold); fi
    printf '%s\n' "$group" > target/jit-raise-call-spans-diagnostic-v2/stage.txt
    python3.14 target/measure_verified_python_components.py --binary target/release/weavepy-runtime-jit-raise-call-spans --previous target/release/weavepy-runtime-weakref-shared-keys --inputs "target/jit-raise-call-spans-inputs/$group" --out "target/jit-raise-call-spans-diagnostic-v2/$group" "${extra[@]}" > "target/jit-raise-call-spans-diagnostic-v2/$group.txt" 2>&1
done
vm_stat > target/jit-raise-call-spans-diagnostic-v2/vm-after.txt
sysctl hw.memsize vm.swapusage > target/jit-raise-call-spans-diagnostic-v2/memory-after.txt
printf 'done\n' > target/jit-raise-call-spans-diagnostic-v2/stage.txt

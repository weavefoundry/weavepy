
values = [tuple(range(i, i + 8)) for i in range(256)]
def bench(n):
    total = 0
    for i in range(n):
        value = values[i & 255]
        total += len(value) + value[0]
    return total

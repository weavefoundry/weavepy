"""Prepare generic-call sizes, compiled callees, and unchanged loss controls."""
from pathlib import Path
import hashlib
import json

root=Path('target/native-dynamic-small-args-inputs')
assert not root.exists()
work=20000
cases={}
for width in [0,1,2,3,4,5,8,16,32]:
    arguments=', '.join(['i']+[str(i) for i in range(1,width)]) if width else ''
    header='class Fn:\n    def __call__(self, *args):\n        return len(args) + 1\nFN = Fn()\n'
    cases[f'generic_pos_{width}']=(header,'f = FN',f'total += f({arguments})',work*(width+1))
for width in [0,1,4,8]:
    args=[('i' if i==0 else str(i)) for i in range(width)] + ['second=7','first=3']
    header='class Fn:\n    def __call__(self, *args, **kw):\n        return len(args) + kw["first"] + kw["second"]\nFN = Fn()\n'
    cases[f'generic_kw_{width}']=(header,'f = FN','total += f('+', '.join(args)+')',work*(width+10))
for width in [1,4]:
    args=', '.join(['i']+[str(i) for i in range(1,width)])
    header='class Fn:\n    def method(self, *args):\n        return len(args) + 1\nFN = Fn().method\n'
    cases[f'generic_method_{width}']=(header,'f = FN',f'total += f({args})',work*(width+1))
for width in [1,4,8]:
    names=[f'x{i}' for i in range(width)]
    header='def leaf('+', '.join(names)+'):\n    return '+' + '.join(names)+'\n'
    args=', '.join(['i']+[str(i) for i in range(1,width)])
    cases[f'compiled_alias_{width}']=(header,'f = leaf',f'total += f({args})',work*(work-1)//2+work*width*(width-1)//2)
cases['generic_object_1']=(
    'class Fn:\n    def __call__(self, value):\n        return len(value)\nFN = Fn()\nVALUE = "shared payload"\n',
    'f = FN\n    value = VALUE','total += f(value)',work*14)
cases['generic_object_4']=(
    'class Fn:\n    def __call__(self, a, b, c, d):\n        return len(a) + len(b) + len(c) + len(d)\nFN = Fn()\nA = [1, 2]\nB = (3, 4, 5)\nC = {"x": 7}\nD = "text"\n',
    'f = FN\n    a, b, c, d = A, B, C, D','total += f(a, b, c, d)',work*10)
inherited_names=['time_iso_auto','format_callback_fallback','override_64_all_supplied','kw_compiled_64_omitted','kw_override_16_omitted']
inherited_oracles=json.loads(Path('target/ascii-time-format-input-oracles.json').read_text())
for group in ['cold','warm']:
    folder=root/group
    folder.mkdir(parents=True)
    texts={}
    expected={name:row[3] for name,row in cases.items()}
    for name,(header,setup,body,_) in cases.items():
        texts[name]='import os\n'+header+'\ndef bench(n):\n    '+setup+'\n    total = 0\n    for i in range(n):\n        '+body+'\n    return total\n'
        texts[name]+='''
if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))
'''
    inherited=json.loads(Path(f'target/ascii-time-format-inputs/{group}/preparation.json').read_text())
    for name in inherited_names:
        texts[name]=Path(inherited['rows'][name]['path']).read_text()
        expected[name]=inherited_oracles[name]['expected_checksum']
    prepared={'purpose':__doc__,'work':work,'rows':{}}
    for name,text in texts.items():
        path=folder/(name+'.py')
        path.write_text(text)
        driver=folder/(name+'-verify.py')
        driver.write_text(f'''import importlib.util, json
spec = importlib.util.spec_from_file_location('call_control', {str(path.resolve())!r})
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first = module.bench(20000)
for _ in range(6):
    module.bench(64)
last = module.bench(20000)
print(json.dumps(first))
print(json.dumps(last))
''')
        prepared['rows'][name]={'path':str(path),'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                              'driver':str(driver),'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),
                              'expected_checksum':expected[name]}
    (folder/'preparation.json').write_text(json.dumps(prepared,indent=2)+'\n')
print('Prepared',len(texts),'cold and warm controls, including five unchanged controls.')

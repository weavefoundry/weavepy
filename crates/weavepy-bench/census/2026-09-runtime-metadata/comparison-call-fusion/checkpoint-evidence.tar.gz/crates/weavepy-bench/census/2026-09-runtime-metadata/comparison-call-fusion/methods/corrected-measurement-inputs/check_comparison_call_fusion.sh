#!/bin/bash
set -euo pipefail
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
export WEAVEPY_FROZEN_CACHE="$PWD/target/comparison-call-fusion-checks/frozen"
binary=target/release/weavepy-runtime-comparison-call-fusion
test "$(cat target/comparison-call-fusion-build-stage.txt)" = done
test ! -e target/comparison-call-fusion-checks
mkdir target/comparison-call-fusion-checks
printf 'targeted binding, native calls, and observability\n' > target/comparison-call-fusion-check-stage.txt
for test in test_comparison_call_fusion test_integer_comparison_guards test_jit_assertion_exits test_compact_intern_pools test_argument_binding_storage test_bound_native_entry test_default_suffix test_extcall_kwonly_messages test_jit_calls test_jit_dyn_calls test_jit_unboxed_calls test_jit_scalar_leaf_calls test_jit_object_lanes test_jit_raise_exits test_native_call_scratch test_native_pin_retirement test_native_pin_pressure test_frame_recycling test_recursion_guard test_cross_thread_heap test_native_generator_pin_retirement test_jit_cells test_small_slot_storage test_pickle_callables test_weakref_basic; do
    WEAVEPY_JIT=1 "$binary" "tests/regrtest/$test.py" > "target/comparison-call-fusion-checks/$test-jit.txt" 2>&1
    WEAVEPY_JIT=0 "$binary" "tests/regrtest/$test.py" > "target/comparison-call-fusion-checks/$test-interp.txt" 2>&1
    WEAVEPY_JIT=1 "$binary" -X gil=0 "tests/regrtest/$test.py" > "target/comparison-call-fusion-checks/$test-gil0.txt" 2>&1
done
WEAVEPY_JIT=1 WEAVEPY_JIT_TRACE=1 WEAVEPY_VM_STATS=1 "$binary" tests/regrtest/test_bound_native_entry.py > target/comparison-call-fusion-checks/native-coverage.stdout.txt 2> target/comparison-call-fusion-checks/native-coverage.stderr.txt
printf 'done\n' > target/comparison-call-fusion-check-stage.txt

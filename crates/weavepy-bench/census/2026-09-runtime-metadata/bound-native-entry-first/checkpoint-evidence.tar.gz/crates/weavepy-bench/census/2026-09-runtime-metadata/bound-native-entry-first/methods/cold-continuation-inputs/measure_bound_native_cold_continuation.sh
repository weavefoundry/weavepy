#!/bin/bash
set -euo pipefail
export WEAVEPY_BENCH_LAUNCH_CONTEXT="outside-tool-filesystem-sandbox (require_escalated)"
export WEAVEPY_STDLIB_CACHE="$PWD/target/performance-stdlib-cache"
python3.14 - <<'CHECK'
import json
from pathlib import Path
root = Path('target/bound-native-entry-focused')
gate = json.loads(Path('target/bound-native-entry-focused-load.json').read_text())
assert gate['status'] == 'command_failed' and 'child_pid' in gate
for group, count in [('calls', 10), ('exceptions', 4)]:
    data = json.loads((root / group / 'measurements.json').read_text())
    assert len(data['rows']) == count
    assert all('previous_comparisons' in row and row['frozen_cache']['unchanged']
               and all(len(samples) == 7 for samples in row['samples'].values())
               for row in data['rows'].values())
failed = json.loads((root / 'cold-exceptions/measurements.json').read_text())
assert not failed['rows']
CHECK
output=target/bound-native-entry-cold-continuation
test ! -e "$output"
mkdir "$output"
base="$(cat target/bound-native-entry-v3-previous.txt)"
binary=target/release/weavepy-runtime-bound-native-entry
vm_stat > "$output/vm-before.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-before.txt"
printf 'four cold exception frequencies\n' > "$output/stage.txt"
python3.14 target/measure_verified_python_components.py --binary "$binary" --previous "$base" --inputs target/bound-native-entry-inputs/cold-exceptions --out "$output/cold-exceptions" --samples 7 --cold > "$output/cold-exceptions.txt" 2>&1
vm_stat > "$output/vm-after.txt"
sysctl hw.memsize vm.swapusage > "$output/memory-after.txt"
printf 'done\n' > "$output/stage.txt"


from datetime import date, timedelta
dates = [date(2000, 1, 1) + timedelta(days=i * 7) for i in range(256)]
def bench(n):
    total = 0
    for i in range(n):
        total += dates[i & 255].toordinal()
    return total

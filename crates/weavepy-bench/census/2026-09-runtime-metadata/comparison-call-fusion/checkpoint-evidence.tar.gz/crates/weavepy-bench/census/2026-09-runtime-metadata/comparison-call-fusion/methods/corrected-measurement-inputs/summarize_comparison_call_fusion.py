"""Summarize all comparison-guard samples, including regressions and both modes."""
import hashlib
import json
import statistics
from pathlib import Path

root = Path("target/comparison-call-fusion-focused")
assert not (root / "summary.json").exists()
summary = {"purpose": __doc__, "groups": {}, "rows": {}}
identities = None
for group, count in [("warm", 15), ("cold", 4)]:
    p = root / group / "measurements.json"
    data = json.loads(p.read_text())
    assert len(data["rows"]) == count and data["samples"] == 7
    new_ids = {k: v["sha256"] for k, v in data["binaries"].items()}
    if identities is None:
        identities = new_ids
    assert identities == new_ids
    summary["groups"][group] = {"path": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                                 "samples": data["samples"], "cold_workload": data["cold_workload"]}
    for name, row in data["rows"].items():
        assert row["frozen_cache"]["unchanged"]
        assert all(len(samples) == 7 for samples in row["samples"].values())
        values = data["verification"][name]
        assert all(v["returncode"] == 0 and v["stdout"] == values["cpython"]["stdout"] for v in values.values())
        pairs = {}
        for reference in ("previous", "reference", "cpython"):
            pairs[reference] = {}
            for mode in ("jit", "interp"):
                pairs[reference][mode] = {}
                key = reference if reference == "cpython" else reference + "_" + mode
                for metric in row[reference + "_comparisons"][mode]:
                    ratios = [a[metric] / b[metric] for a, b in zip(row["samples"][mode], row["samples"][key], strict=True)]
                    pairs[reference][mode][metric] = {"ratios": ratios, "median": statistics.median(ratios),
                                                       "range": [min(ratios), max(ratios)], "improved_pairs": sum(r < 1 for r in ratios)}
        summary["rows"][group + "/" + name] = {"new_over_previous": row["previous_comparisons"],
            "new_over_reference": row["reference_comparisons"], "new_over_cpython": row["cpython_comparisons"], "pairs": pairs}
summary["binaries"] = identities
assert len(summary["rows"]) == 19
(root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print("All 19 controls, exact values, stable caches, and seven paired samples verified.")
for name, row in summary["rows"].items():
    for mode in ("jit", "interp"):
        print(name, mode, "time/previous", row["new_over_previous"][mode]["ns"],
              "RSS/previous", row["new_over_previous"][mode]["rss_bytes"],
              "time/CPython", row["new_over_cpython"][mode]["ns"], "RSS/CPython", row["new_over_cpython"][mode]["rss_bytes"])

# Native object indexing: source audit, no implementation

Finish and archive phase 77 before runtime edits, builds, tests, or diagnostics
that could overlap its timing gates. This is a source-based lead, not a measured
performance improvement or proof that a fixture will compile.

The unchanged deque_ops fixture currently rejects BinarySubscr on an Obj
container. It also adds two opaque subscript results, checks deque truth, and
iterates a generic iterator. Removing the first rejection alone is insufficient.
The integer_operand_guard in analyze.rs only accepts one Obj operand paired with
an integral operand; Obj plus Obj has no lane evidence and is rejected. Do not
restore the deferred comparison-guard/fusion experiments blindly.

Relevant paths:

- analyze.rs has separate BinarySubscr inference and emission arms, currently
  admitting typed lists, dicts, bytes, and strings. Obj results would also need
  correct downstream arithmetic typing. An unconditional integer assumption
  without a guarded exit is invalid. Even guarded speculation must measure
  noninteger controls and compilation/deoptimization costs.
- collections_native.rs supplies deque_getitem as a native class attribute of
  the Python deque implementation. It validates the receiver, coerces __index__,
  then reacquires backing storage because the index callback can reinitialize
  the deque. Exact integer indices avoid that callback. Any direct specialization
  needs actual method identity/class guards and must fall back before callbacks
  when an override or incompatible receiver is present. Matching an instance's
  private slot names alone is not sufficient admission evidence.
- Interpreter.subscr_get_step is the complete bytecode path. It handles instance
  descriptor dispatch, builtin-subclass __missing__, metaclass __getitem__,
  __class_getitem__, foreign objects, mapping proxies, generic aliases, and unions.
  It also promptly reaps the consumed instance container. accel_subscript and
  subscr_via_protocol cover a narrower surface and must not be substituted blindly.
  subscr_get_public is closer but uses builtin globals; compare it with the
  bytecode's caller globals and finalization behavior before sharing code.
- DynAttrGet lowering is a useful four-status example: success, raised with
  operands consumed, completed/parked result followed by a next-PC exit, and a
  refusal before Python with original operands restored. All inference/emission,
  stack reconstruction, helper registration, and pin-pressure classification
  sites must agree. Never replay __getitem__ or a producing callback after it
  has completed, including guard invalidation and unexpected result types.
- A Python-capable helper must set the exact call-site deopt_pc and preserve the
  parent activation for stack observers. Do not copy another helper's missing
  activation-shell wrapper. Native pin retirement and prompt weakref/finalizer
  behavior also need review; a pin table can retain a temporary after the
  bytecode would have consumed it.

An additional correctness constraint surfaced during review: broadening JIT
coverage can turn an interpreted caller with correct frame observation into a
frameless native caller with the known identity/locals/continuation limitations.
It is not enough to label those limitations preexisting when a new specialization
makes them reachable in previously interpreted code. Test custom __getitem__
callbacks that inspect or retain the caller, mutate f_locals, raise, or invalidate
globals. The phase 77 cache deliberately excludes observed shells and does not
solve these issues. A restricted, proven callback-free builtin specialization
could be considered separately; a general Python-capable indexing path needs
correct native materialization and handoff first.

Full native-frame support would need a stable observed PyFrame, current locals,
correct on_stack lifetime, exact lasti, tracing, and deoptimization handoff.
Adding an unguarded raw-pointer materializer to a shared FrameShell is not a safe
shortcut: other-thread stack access, greenlet lifetimes, GIL transitions, pin
roots, and retained frames need an ownership/synchronization proof. Eagerly boxing
all native locals for every callback is a possible correctness reference, not
an assumed optimization. See native-frame-shell-followup.md for the existing
handoff and lifetime audit. No implementation or benchmark claim follows here.

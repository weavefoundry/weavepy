def exact(i):
    return i
def compare(f, i):
    if f(i) >= 2500:
        return 7
    return 9
def bench(n):
    total = 0
    for i in range(n):
        total += compare(exact, i)
    return total

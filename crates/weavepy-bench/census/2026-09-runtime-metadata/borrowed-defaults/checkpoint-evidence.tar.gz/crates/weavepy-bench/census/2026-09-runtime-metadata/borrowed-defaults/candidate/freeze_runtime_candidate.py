"""Preserve exact changed sources, measurement inputs, and release identity."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--binary', required=True)
parser.add_argument('--previous', required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--extra', nargs='*', default=[])
args = parser.parse_args()
assert not args.out.exists(), 'Use a fresh snapshot directory.'
extra_inputs = ['target/capture_runtime_environment.py', __file__, *args.extra]
extra_names = [Path(name).name for name in extra_inputs]
assert len(extra_names) == len(set(extra_names)), 'Snapshot extra filenames must be distinct.'
assert not set(extra_names) & {'environment.json', 'README.md', 'source-changes.diff'}, \
    'Snapshot extras must not overwrite reserved output filenames.'
delta = subprocess.check_output(['git', 'diff', 'HEAD', '--binary'])
subprocess.run(['python3.14', 'target/capture_runtime_environment.py',
                args.binary, args.previous], check=True)
source = Path('crates/weavepy-bench/census/2026-09-runtime-metadata/environment.json')
env = json.loads(source.read_text())
assert hashlib.sha256(delta).hexdigest() == env['git_state']['tracked_delta_sha256']
args.out.mkdir(parents=True)
for group in ['sources', 'measurement_scripts']:
    for name, digest in env[group].items():
        path = Path(name)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, name
        dest = args.out / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)
env['extra_script_hashes'] = {}
for name in extra_inputs:
    path = Path(name)
    dest = args.out / path.name
    shutil.copy2(path, dest)
    env['extra_script_hashes'][path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
(args.out / 'environment.json').write_text(json.dumps(env, indent=2) + '\n')
(args.out / 'source-changes.diff').write_bytes(delta)
(args.out / 'README.md').write_text('''# Frozen candidate inputs

The environment file identifies the executable and all copied source and
measurement inputs. These files were captured after building and before full
compatibility validation and timing. Consult the adjacent results for their
outcomes; this snapshot alone makes no validation or performance claim.
''')
print(f'Frozen {len(env["sources"])} sources and {len(env["measurement_scripts"])} measurement inputs.')

"""Carry forward every existing exception-frequency control before timing."""
import ast
import hashlib
import json
from pathlib import Path

root = Path('target/bound-native-entry-inputs')
method = Path('target/prepare_bound_native_entry_inputs.py')
tree = ast.parse(method.read_text())
definition = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'save_group')
namespace = dict(root=root, Path=Path, hashlib=hashlib, json=json)
exec(compile(ast.Module(body=[definition], type_ignores=[]), str(method), 'exec'), namespace)
prior = Path('target/jit-raise-call-spans-inputs/exceptions')
prepared = json.loads((prior / 'preparation.json').read_text())
cases = {}
for name, case in prepared['rows'].items():
    source = Path(case['path'])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == case['source_sha256']
    cases[name] = source.read_text()
namespace['save_group']('exceptions', prepared['work'], cases)
with (root / 'protocol.md').open('a') as stream:
    stream.write('''

Before collecting any samples, add the four unchanged exception-frequency
controls from the corrected raise-exit experiment, work=5000. Measure each in
both warm and cold form with seven pairs. This makes 18 focused timing cases:
ten call shapes, four warm exception cases, and four cold exception cases.
Keep the groups and every individual result separate; these additions do not
change the historical or standard-suite cohorts. Existing no/rare/half/always
raising cases must all remain present, including the earlier always-raising
regression. Source bytes and work parameters are unchanged; verification
drivers point to the new copied input directory and have fresh hashes.
''')
print('Prepared four unchanged exception controls for warm and cold timing.')

"""Archive assertion-exit results and the corrected zero-test discovery gate."""
import gzip
import hashlib
import json
from pathlib import Path

parent = Path("crates/weavepy-bench/census/2026-09-runtime-metadata")
out = parent / "jit-assertion-exits"
assert not out.exists()
for group in ("focused", "full"):
    assert Path("target/jit-assertion-exits-" + group + "/stage.txt").read_text().strip() == "done"
    assert json.loads(Path("target/jit-assertion-exits-" + group + "-load.json").read_text())["status"] == "complete"
focused = json.loads(Path("target/jit-assertion-exits-focused/summary.json").read_text())
full = json.loads(Path("target/jit-assertion-exits-full/summary.json").read_text())
validation = json.loads(Path("target/jit-assertion-exits-validation/validation.json").read_text())
assert len(validation) == 275 and all(row["passed"] for row in validation)
assert json.loads(Path("target/jit-assertion-exits-extra-discovery/report.json").read_text())["status"] == "passed"
assert json.loads(Path("target/jit-assertion-exits-coverage/report.json").read_text())["assertions_passed"]
out.mkdir()
records = []


def copy(src, dst):
    src = Path(src)
    raw = src.read_bytes()
    data = raw
    if len(raw) >= 65536 and src.suffix in (".json", ".txt", ".diff") and not src.name.startswith("summary"):
        dst += ".gz"
        data = gzip.compress(raw, compresslevel=9, mtime=0)
    p = out / dst
    assert not p.exists(), dst
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    records.append({"path": dst, "source": str(src), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
                     "uncompressed_bytes": len(raw), "uncompressed_sha256": hashlib.sha256(raw).hexdigest()})


def folder(src, dst):
    src = Path(src)
    for p in sorted(src.iterdir()):
        if p.is_file() and p.suffix in (".py", ".json", ".txt", ".md", ".sh", ".patch"):
            copy(p, str(Path(dst) / p.name))


for group in ("focused", "full"):
    folder("target/jit-assertion-exits-" + group, group)
for group in ("warm", "cold"):
    copy("target/jit-assertion-exits-focused/" + group + "/measurements.json", "focused/" + group + ".json")
    folder("target/assertion-exit-inputs/" + group, "inputs/" + group)
for group in ("checks", "validation", "extra-checks", "extra-discovery", "coverage", "datetime-paths"):
    folder("target/jit-assertion-exits-" + group, "checks/" + group)
for group in ("measurement-inputs", "v2-measurement-inputs", "datetime-method"):
    folder("target/jit-assertion-exits-" + group, "methods/" + group)
for group in ("jit-assertion-exit-baseline-preflight", "jit-assertion-exit-baseline-preflight-v2", "assertion-exit-inputs-baseline"):
    folder("target/" + group, "checks/" + group)
copy("target/test_jit_assertion_exits.py", "checks/original-semantic-preflight.py")
for p in sorted(Path("target").glob("jit-assertion-exits-*.txt")):
    copy(p, "logs/" + p.name)
copy("target/assertion-exit-inputs-baseline.txt", "logs/assertion-exit-inputs-baseline.txt")
for name in ("jit-assertion-exits-focused-load.json", "jit-assertion-exits-full-load.json", "jit-assertion-exits-prebuild-sources.json", "performance_phase66_status.md"):
    copy("target/" + name, "conditions/" + name)
for name in ("environment.json", "source-changes.diff", "tests/regrtest/test_jit_assertion_exits.py"):
    copy("target/jit-assertion-exits-source-snapshot/" + name, "candidate/" + name)
for name in ("candidate.patch", "index.json", "README.md"):
    copy("target/jit-assertion-exit-draft/" + name, "draft/" + name)
copy(__file__, "methods/" + Path(__file__).name)

work = full["cohorts"]["all_23_workloads_excluding_startup"]["metrics"]["jit"]["ns"]
hist = full["cohorts"]["historical_21_including_startup"]["metrics"]["jit"]
proc = full["cohorts"]["all_processes_including_startup"]["metrics"]["jit"]
lines = ["# JIT exits before common exception constants", "",
    "The overall performance goal remains unachieved.", "",
    "Candidate ed99cdba treats only canonical AssertionError/NotImplementedError",
    "loads as exact-PC interpreter exits. Successful branches can compile while",
    "message construction, callbacks, and exceptions continue through the existing",
    "interpreter. Other common constants retain their original analysis. Existing",
    "plain-stack checks, spill/writeback, and marker-free call-span exclusion apply.",
    "No new runtime helper, object field, cache, unsafe code, or execution policy.",
    "The binary is 44,289,520 bytes, unchanged from immediate a1e87c1a. Earlier",
    "intern and native-entry changes, including their regressions, remain included.", "",
    "All 58 JIT tests, 342 VM tests, formatting, Clippy, no-default-feature check,",
    "69 targeted release checks, and 275 standard compatibility checks pass. Six",
    "assertion functions actually compile and rebuild their error continuations",
    "with CPython-equivalent results. The regression includes side effects, message",
    "identity, conditional messages, loop locals, exact traceback line, cleanup,",
    "builtin shadowing, exception context, tracing, recovery, and real bytecode",
    "loading the second common exception constant. Baseline checks are preserved.", "",
    "The original extra-suite script returned success for a submodule filter that",
    "selected ZERO tests. That isn't a passing assertion suite. Its method and raw",
    "result remain preserved. A separate check verified the original five nonempty",
    "call/inspection/copy suites and ran the discoverable unittest package, requiring",
    "a positive selected count and all modules passing. Timing used only the v2",
    "launcher, which requires this corrected check. No timed sample was replaced.", "",
    "Untimed datetime values agree with CPython. Compiled functions rise from 24",
    "to 26 (_cmp and _find_isoformat_datetime_separator), while _ymd2ord and field",
    "validators still encounter MixedArithTypes. Compilation counts aren't speed",
    "measurements. A later guarded-comparison draft is separate and unapplied.", "",
    "Focused timing uses 13 warm and four cold controls, work 5000, and seven",
    "paired samples of both modes of candidate, immediate a1e87c1a, retained 539c,",
    "and CPython. All values and per-binary frozen-cache checks pass. Lower is better.", "",
    "| Case | Mode | Time / predecessor | RSS / predecessor | Time / CPython |",
    "| --- | --- | ---: | ---: | ---: |"]
for name, row in focused["rows"].items():
    for mode in ("jit", "interp"):
        prev = row["new_over_previous"][mode]
        cp = row["new_over_cpython"][mode]
        lines.append(f"| {name} | {mode} | {prev['ns']:.4f} | {prev['rss_bytes']:.4f} | {cp['ns']:.4f} |")
lines += ["",
    "All frequency, recovery, cold-start, memory, and interpreter-only regressions",
    "remain in the table and raw results. The data retains every paired sample,",
    "range, workload/process wall and CPU metric, peak RSS, and cache observation.",
    "The four cold controls have process CPU measurements, but no separate",
    "workload CPU timer. Don't infer performance from native-coverage counts.", "",
    "The full suite retains 24 unchanged fixtures with five pairs and nine startup/",
    "import controls with 31 pairs. Its baseline is immediate a1e87c1a, isolating",
    "the assertion change. The startup helper disables JIT.", "",
    f"The 23-workload JIT mean is {work['new_over_base']:.6f} of its predecessor and",
    f"{work['new_over_cpython']:.6f} of CPython, with {work['weavepy_wins']} of 23 time wins.",
    f"The historical 21-fixture cohort is {hist['ns']['new_over_cpython']:.6f} of CPython,",
    f"or {hist['ratio_of_medians_new_over_cpython']:.6f} using ratios of medians.", "",
    f"All-24 process wall/CPU/RSS ratios to its predecessor are {proc['wall_ns']['new_over_base']:.6f},",
    f"{proc['cpu_ns']['new_over_base']:.6f}, and {proc['rss_bytes']['new_over_base']:.6f}.",
    f"Peak RSS is {proc['rss_bytes']['new_over_cpython']:.6f} of CPython, with {proc['rss_bytes']['weavepy_wins']} wins.", "",
    "Both timing gates qualified; all later samples and load/VM/swap observations",
    "remain. Keep the 21/23/24 cohorts distinct and use same-run paired ratios for",
    "attribution. No universal, energy, controlled build-time, portability, or",
    "free-threaded superiority is established. Large raw text is compressed",
    "losslessly; the index verifies stored and uncompressed hashes and sizes.",
    "Executables, frozen caches, and unselected temporary files remain local.", ""]
(out / "REPORT.md").write_text("\n".join(lines))
p = out / "REPORT.md"
records.append({"path": p.name, "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
(out / "index.json").write_text(json.dumps(records, indent=2) + "\n")
for row in records:
    data = (out / row["path"]).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row["sha256"]
    if "uncompressed_sha256" in row:
        raw = gzip.decompress(data) if row["path"].endswith(".gz") else data
        assert hashlib.sha256(raw).hexdigest() == row["uncompressed_sha256"]
with (parent / ".gitignore").open("a") as f:
    f.write("\n# Assertion exits, full paired evidence, and corrected discovery gate.\n")
    for p in sorted(out.rglob("*")):
        if p.is_file():
            f.write("!" + str(p.relative_to(parent)) + "\n")
with (parent / "README.md").open("a") as f:
    f.write("\nThe [assertion-exit experiment](jit-assertion-exits/REPORT.md) enables native\nsuccess paths around canonical exception constants. Its evidence includes\nfrequent-failure and recovery controls, all broader results, and a corrected\nextra-suite filter that initially selected zero tests. CPython gaps remain.\n")
print("Exported", len(records) + 1, "files;", sum(p.stat().st_size for p in out.rglob("*") if p.is_file()), "bytes; all stored and uncompressed hashes verified.")

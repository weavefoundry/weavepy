namespace = {"__name__": "path_audit"}
exec(compile(open('crates/weavepy-bench/fixtures/datetime_ops.py').read(), 'crates/weavepy-bench/fixtures/datetime_ops.py', "exec"), namespace)
for _ in range(4):
    print(namespace["bench"](1000))

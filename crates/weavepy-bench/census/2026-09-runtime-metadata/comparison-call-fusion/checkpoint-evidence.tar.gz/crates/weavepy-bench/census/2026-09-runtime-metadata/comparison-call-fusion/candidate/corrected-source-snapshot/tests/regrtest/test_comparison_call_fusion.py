"""Integer call-result fusion must preserve continuation effects and values."""
import sys

EVENTS = []
VALUE = 0
CAP = 3


def produce(value):
    EVENTS.append('produce')
    return VALUE


def exact(value):
    return value


def cmp_fusion_kw(f, n):
    return f(value=n) < 3


def cmp_fusion_bool(f, n):
    return f(n) == True


def cmp_fusion_global(f, n):
    return f(n) < CAP


def cmp_fusion_local(f, n):
    n = n + 0
    return f(n) < n


for i in range(250):
    assert cmp_fusion_kw(exact, i) == (i < 3)
    assert cmp_fusion_bool(exact, i) == (i == True)
    assert cmp_fusion_global(exact, i) == (i < CAP)
    assert cmp_fusion_local(exact, i) is False


class Token:
    def __bool__(self):
        EVENTS.append('truth')
        return True


TOKEN = Token()


class Rich:
    def __lt__(self, other):
        EVENTS.append(('lt', other))
        return TOKEN

    def __eq__(self, other):
        EVENTS.append(('eq', other))
        return TOKEN


VALUE = Rich()
for fn, op, rhs in [(cmp_fusion_kw, 'lt', 3), (cmp_fusion_bool, 'eq', True),
                    (cmp_fusion_global, 'lt', 3), (cmp_fusion_local, 'lt', 9)]:
    EVENTS.clear()
    assert fn(produce, 9) is TOKEN
    assert EVENTS == ['produce', (op, rhs)]

for VALUE in [False, True, 3.5, -(1 << 100), 1 << 100]:
    EVENTS.clear()
    assert cmp_fusion_kw(produce, 9) == (VALUE < 3)
    assert EVENTS == ['produce']
    EVENTS.clear()
    assert cmp_fusion_bool(produce, 9) == (VALUE == True)
    assert EVENTS == ['produce']


def change_cap(value):
    global CAP
    EVENTS.append('change_cap')
    CAP = 7
    return 6


EVENTS.clear()
assert cmp_fusion_global(change_cap, 0) is True
assert EVENTS == ['change_cap']
CAP = 3
assert cmp_fusion_global(exact, 6) is False

FAILURE = RuntimeError('producing callback')


def fail(value):
    EVENTS.append('fail')
    raise FAILURE


for fn in (cmp_fusion_kw, cmp_fusion_bool, cmp_fusion_global, cmp_fusion_local):
    EVENTS.clear()
    try:
        fn(fail, 9)
    except RuntimeError as error:
        assert error is FAILURE
    else:
        raise AssertionError('producer error lost')
    assert EVENTS == ['fail']

observed = []


def trace(frame, event, arg):
    if frame.f_code.co_name.startswith('cmp_fusion_'):
        observed.append(event)
    return trace


sys.settrace(trace)
try:
    assert cmp_fusion_kw(exact, 0) is True
finally:
    sys.settrace(None)
assert 'call' in observed and 'return' in observed
print('comparison call fusion: all checks passed')

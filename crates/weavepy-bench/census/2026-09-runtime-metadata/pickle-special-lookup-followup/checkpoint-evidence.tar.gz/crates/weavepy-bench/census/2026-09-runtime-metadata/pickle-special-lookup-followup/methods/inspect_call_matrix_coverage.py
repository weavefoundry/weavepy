"""Identify which unchanged call shapes still prevent native execution."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

root=Path('target/pickle-special-lookup-call-matrix');root.mkdir()
source=Path('crates/weavepy-bench/fixtures/call_overhead.py')
driver=root/'calls.py'
driver.write_text(f'''import sys, types
module = types.ModuleType("_weavepy_bench")
module.__file__ = {str(source)!r}
sys.modules[module.__name__] = module
with open(module.__file__) as source:
    exec(compile(source.read(), module.__file__, "exec"), module.__dict__)
for unused in range(3):
    print(module.bench(300))
''')
report={'purpose':__doc__,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'driver_sha256':hashlib.sha256(driver.read_bytes()).hexdigest(),'runs':{}}
for label,binary in [('cpython',shutil.which('python3.14')),
                     ('base','target/release/weavepy-runtime-jit-raise-call-spans'),
                     ('new','target/release/weavepy-runtime-pickle-special-lookup')]:
    digest=hashlib.sha256(Path(binary).read_bytes()).hexdigest()
    env=dict(os.environ)
    for key in ['WEAVEPY_JIT','WEAVEPY_JIT_TRACE','WEAVEPY_VM_STATS','WEAVEPY_JIT_THRESHOLD']:
        env.pop(key,None)
    if label!='cpython':
        env.update(WEAVEPY_JIT='1',WEAVEPY_JIT_TRACE='1',WEAVEPY_VM_STATS='1',
                   WEAVEPY_STDLIB_CACHE=str(Path('target/performance-stdlib-cache').resolve()),
                   WEAVEPY_FROZEN_CACHE=str((root/'frozen'/digest).resolve()))
    result=subprocess.run([binary,str(driver)],env=env,text=True,capture_output=True,timeout=120)
    trace=root/(label+'.trace.txt');trace.write_text(result.stderr)
    report['runs'][label]={'binary_sha256':digest,'returncode':result.returncode,'stdout':result.stdout,
                          'trace_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),
                          'compiled':sorted(set(re.findall(r'jit compile "([^"]+)"',result.stderr))),
                          'rejections':sorted(set(re.findall(r'jit reject .+',result.stderr))),
                          'stats':{k:int(v.replace(',','')) for k,v in re.findall(r'^- ([^:]+): \*\*([\d,]+)\*\*',result.stderr,re.M)}}
    (root/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    assert result.returncode==0 and result.stdout=='375000\n'*3,(label,result.stdout,result.stderr[-3000:])
    print(label,report['runs'][label]['compiled'],flush=True)
print('Exact call-matrix results agree; coverage is diagnostic, not timing.')

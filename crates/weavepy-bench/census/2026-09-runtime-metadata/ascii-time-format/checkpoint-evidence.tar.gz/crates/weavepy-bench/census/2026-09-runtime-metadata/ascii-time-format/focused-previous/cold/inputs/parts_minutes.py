import os
import _pydatetime as pure
def bench(n):
    total = 0
    for i in range(n):
        text = pure._format_time(i % 24, i % 60, (i * 7) % 60, (i * 1999) % 1000000, 'minutes')
        total += len(text) + ord(text[-1])
    return total

if __name__ == "__main__":
    import time
    n = int(os.environ.get("WEAVEPY_BENCH_WORK", "20000"))
    start = time.perf_counter_ns()
    bench(n)
    print("WEAVEPY_BENCH_NS=%d" % (time.perf_counter_ns() - start))
